package androidx.preference;

import android.content.Context;
import android.content.SharedPreferences;
import dbxyzptlk.v4.c;
import dbxyzptlk.v4.e;

public class b {
  public final Context a;
  
  public long b = 0L;
  
  public SharedPreferences c;
  
  public SharedPreferences.Editor d;
  
  public boolean e;
  
  public String f;
  
  public int g;
  
  public int h = 0;
  
  public PreferenceScreen i;
  
  public c j;
  
  public a k;
  
  public b l;
  
  public b(Context paramContext) {
    this.a = paramContext;
    s(d(paramContext));
  }
  
  public static SharedPreferences b(Context paramContext) {
    return paramContext.getSharedPreferences(d(paramContext), c());
  }
  
  public static int c() {
    return 0;
  }
  
  public static String d(Context paramContext) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramContext.getPackageName());
    stringBuilder.append("_preferences");
    return stringBuilder.toString();
  }
  
  public <T extends Preference> T a(CharSequence paramCharSequence) {
    PreferenceScreen preferenceScreen = this.i;
    return (T)((preferenceScreen == null) ? null : preferenceScreen.d1(paramCharSequence));
  }
  
  public SharedPreferences.Editor e() {
    if (this.e) {
      if (this.d == null)
        this.d = l().edit(); 
      return this.d;
    } 
    return l().edit();
  }
  
  public long f() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield b : J
    //   6: lstore_1
    //   7: aload_0
    //   8: lconst_1
    //   9: lload_1
    //   10: ladd
    //   11: putfield b : J
    //   14: aload_0
    //   15: monitorexit
    //   16: lload_1
    //   17: lreturn
    //   18: astore_3
    //   19: aload_0
    //   20: monitorexit
    //   21: aload_3
    //   22: athrow
    // Exception table:
    //   from	to	target	type
    //   2	16	18	finally
    //   19	21	18	finally
  }
  
  public b g() {
    return this.l;
  }
  
  public c h() {
    return this.j;
  }
  
  public d i() {
    return null;
  }
  
  public c j() {
    return null;
  }
  
  public PreferenceScreen k() {
    return this.i;
  }
  
  public SharedPreferences l() {
    j();
    if (this.c == null) {
      Context context;
      if (this.h != 1) {
        context = this.a;
      } else {
        context = dbxyzptlk.V1.b.b(this.a);
      } 
      this.c = context.getSharedPreferences(this.f, this.g);
    } 
    return this.c;
  }
  
  public PreferenceScreen m(Context paramContext, int paramInt, PreferenceScreen paramPreferenceScreen) {
    n(true);
    PreferenceScreen preferenceScreen = (PreferenceScreen)(new e(paramContext, this)).d(paramInt, (PreferenceGroup)paramPreferenceScreen);
    preferenceScreen.d0(this);
    n(false);
    return preferenceScreen;
  }
  
  public final void n(boolean paramBoolean) {
    if (!paramBoolean) {
      SharedPreferences.Editor editor = this.d;
      if (editor != null)
        editor.apply(); 
    } 
    this.e = paramBoolean;
  }
  
  public void o(a parama) {
    this.k = parama;
  }
  
  public void p(b paramb) {
    this.l = paramb;
  }
  
  public void q(c paramc) {
    this.j = paramc;
  }
  
  public boolean r(PreferenceScreen paramPreferenceScreen) {
    PreferenceScreen preferenceScreen = this.i;
    if (paramPreferenceScreen != preferenceScreen) {
      if (preferenceScreen != null)
        preferenceScreen.i0(); 
      this.i = paramPreferenceScreen;
      return true;
    } 
    return false;
  }
  
  public void s(String paramString) {
    this.f = paramString;
    this.c = null;
  }
  
  public boolean t() {
    return this.e ^ true;
  }
  
  public void u(Preference paramPreference) {
    a a1 = this.k;
    if (a1 != null)
      a1.F0(paramPreference); 
  }
  
  class b {}
  
  class b {}
  
  class b {}
  
  class b {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\preference\b.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */