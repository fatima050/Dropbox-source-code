package androidx.room;

import dbxyzptlk.CI.p;
import dbxyzptlk.tI.e;
import dbxyzptlk.tI.g;
import java.util.concurrent.atomic.AtomicInteger;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

@Metadata(d1 = {"\000(\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\007\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\005\b\001\030\000 \0262\0020\001:\001\nB\017\022\006\020\003\032\0020\002¢\006\004\b\004\020\005J\r\020\007\032\0020\006¢\006\004\b\007\020\bJ\r\020\t\032\0020\006¢\006\004\b\t\020\bR\032\020\003\032\0020\0028\000X\004¢\006\f\n\004\b\n\020\013\032\004\b\f\020\rR\024\020\021\032\0020\0168\002X\004¢\006\006\n\004\b\017\020\020R\032\020\025\032\b\022\004\022\0020\0000\0228VX\004¢\006\006\032\004\b\023\020\024¨\006\027"}, d2 = {"Landroidx/room/i;", "Ldbxyzptlk/tI/g$b;", "Ldbxyzptlk/tI/e;", "transactionDispatcher", "<init>", "(Ldbxyzptlk/tI/e;)V", "Ldbxyzptlk/pI/D;", "h", "()V", "k", "a", "Ldbxyzptlk/tI/e;", "j", "()Ldbxyzptlk/tI/e;", "Ljava/util/concurrent/atomic/AtomicInteger;", "b", "Ljava/util/concurrent/atomic/AtomicInteger;", "referenceCount", "Ldbxyzptlk/tI/g$c;", "getKey", "()Ldbxyzptlk/tI/g$c;", "key", "c", "room-ktx_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class i implements g.b {
  public static final a c = new a(null);
  
  public final e a;
  
  public final AtomicInteger b;
  
  public i(e parame) {
    this.a = parame;
    this.b = new AtomicInteger(0);
  }
  
  public <E extends g.b> E c(g.c<E> paramc) {
    return (E)g.b.a.b(this, paramc);
  }
  
  public <R> R g(R paramR, p<? super R, ? super g.b, ? extends R> paramp) {
    return (R)g.b.a.a(this, paramR, paramp);
  }
  
  public g.c<i> getKey() {
    return c;
  }
  
  public final void h() {
    this.b.incrementAndGet();
  }
  
  public final e j() {
    return this.a;
  }
  
  public final void k() {
    if (this.b.decrementAndGet() >= 0)
      return; 
    throw new IllegalStateException("Transaction was never started or was already released.");
  }
  
  public g l(g.c<?> paramc) {
    return g.b.a.c(this, paramc);
  }
  
  public g s(g paramg) {
    return g.b.a.d(this, paramg);
  }
  
  @Metadata(d1 = {"\000\020\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\003\b\003\030\0002\b\022\004\022\0020\0020\001B\t\b\002¢\006\004\b\003\020\004¨\006\005"}, d2 = {"Landroidx/room/i$a;", "Ldbxyzptlk/tI/g$c;", "Landroidx/room/i;", "<init>", "()V", "room-ktx_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class a implements g.c<i> {
    public a() {}
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\room\i.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */