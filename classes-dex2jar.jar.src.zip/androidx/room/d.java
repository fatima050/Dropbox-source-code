package androidx.room;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteException;
import androidx.lifecycle.LiveData;
import dbxyzptlk.DI.s;
import dbxyzptlk.F4.m;
import dbxyzptlk.F4.n;
import dbxyzptlk.F4.s;
import dbxyzptlk.L4.g;
import dbxyzptlk.L4.j;
import dbxyzptlk.L4.k;
import dbxyzptlk.YJ.t;
import dbxyzptlk.pI.D;
import dbxyzptlk.qI.A;
import dbxyzptlk.qI.P;
import dbxyzptlk.qI.X;
import dbxyzptlk.qI.Y;
import io.sentry.android.core.r0;
import java.io.Closeable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.Lock;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

@Metadata(d1 = {"\000®\001\n\002\030\002\n\002\020\000\n\002\030\002\n\000\n\002\020$\n\002\020\016\n\000\n\002\020\"\n\000\n\002\020\021\n\002\b\003\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\020\b\n\002\b\b\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\005\n\002\020\013\n\002\b\013\n\002\030\002\n\000\n\002\030\002\n\002\b\020\n\002\030\002\n\002\b\007\n\002\030\002\n\002\b\006\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\004\b\026\030\000 .2\0020\001:\005@D+->BS\b\007\022\006\020\003\032\0020\002\022\022\020\006\032\016\022\004\022\0020\005\022\004\022\0020\0050\004\022\030\020\b\032\024\022\004\022\0020\005\022\n\022\b\022\004\022\0020\0050\0070\004\022\022\020\n\032\n\022\006\b\001\022\0020\0050\t\"\0020\005¢\006\004\b\013\020\fJ\017\020\016\032\0020\rH\002¢\006\004\b\016\020\017J\037\020\024\032\0020\r2\006\020\021\032\0020\0202\006\020\023\032\0020\022H\002¢\006\004\b\024\020\025J\037\020\026\032\0020\r2\006\020\021\032\0020\0202\006\020\023\032\0020\022H\002¢\006\004\b\026\020\025J'\020\027\032\n\022\006\b\001\022\0020\0050\t2\016\020\n\032\n\022\006\b\001\022\0020\0050\tH\002¢\006\004\b\027\020\030J'\020\032\032\n\022\006\b\001\022\0020\0050\t2\016\020\031\032\n\022\006\b\001\022\0020\0050\tH\002¢\006\004\b\032\020\030J\027\020\035\032\0020\r2\006\020\034\032\0020\033H\000¢\006\004\b\035\020\036J\027\020\037\032\0020\r2\006\020\003\032\0020\020H\000¢\006\004\b\037\020 J'\020&\032\0020\r2\006\020\"\032\0020!2\006\020#\032\0020\0052\006\020%\032\0020$H\000¢\006\004\b&\020'J\017\020(\032\0020\rH\000¢\006\004\b(\020\017J\027\020+\032\0020\r2\006\020*\032\0020)H\027¢\006\004\b+\020,J\027\020-\032\0020\r2\006\020*\032\0020)H\027¢\006\004\b-\020,J\027\020.\032\0020\r2\006\020*\032\0020)H\027¢\006\004\b.\020,J\017\0200\032\0020/H\000¢\006\004\b0\0201J\017\0202\032\0020\rH\026¢\006\004\b2\020\017J\017\0203\032\0020\rH\027¢\006\004\b3\020\017J#\0205\032\0020\r2\022\0204\032\n\022\006\b\001\022\0020\0050\t\"\0020\005H\007¢\006\004\b5\0206J\027\0207\032\0020\r2\006\020\003\032\0020\020H\000¢\006\004\b7\020 J\017\0208\032\0020\rH\000¢\006\004\b8\020\017JC\020>\032\b\022\004\022\0028\0000=\"\004\b\000\02092\016\020\n\032\n\022\006\b\001\022\0020\0050\t2\006\020:\032\0020/2\016\020<\032\n\022\006\022\004\030\0018\0000;H\027¢\006\004\b>\020?R\032\020\003\032\0020\0028\000X\004¢\006\f\n\004\b@\020A\032\004\bB\020CR \020\006\032\016\022\004\022\0020\005\022\004\022\0020\0050\0048\002X\004¢\006\006\n\004\bD\020ER&\020\b\032\024\022\004\022\0020\005\022\n\022\b\022\004\022\0020\0050\0070\0048\002X\004¢\006\006\n\004\b+\020ER&\020H\032\016\022\004\022\0020\005\022\004\022\0020\0220\0048\000X\004¢\006\f\n\004\b-\020E\032\004\bF\020GR\"\020L\032\n\022\006\b\001\022\0020\0050\t8\000X\004¢\006\f\n\004\b>\020I\032\004\bJ\020KR\030\020\034\032\004\030\0010\0338\002@\002X\016¢\006\006\n\004\b0\020MR\032\020S\032\0020N8GX\004¢\006\f\n\004\bO\020P\032\004\bQ\020RR\026\020U\032\0020/8\002@\002X\016¢\006\006\n\004\bB\020TR$\020\\\032\004\030\0010V8\000@\000X\016¢\006\022\n\004\bW\020X\032\004\bO\020Y\"\004\bZ\020[R\024\020_\032\0020]8\002X\004¢\006\006\n\004\bQ\020^R\024\020b\032\0020`8\002X\004¢\006\006\n\004\bF\020aR&\020g\032\016\022\004\022\0020)\022\004\022\0020d0c8\000X\004¢\006\f\n\004\b\037\020e\032\004\bW\020fR\030\020j\032\004\030\0010h8\002@\002X\016¢\006\006\n\004\b5\020iR\024\020l\032\0020\0018\002X\004¢\006\006\n\004\b\016\020kR\024\020m\032\0020\0018\002X\004¢\006\006\n\004\b2\020kR\032\020q\032\0020n8\006X\004¢\006\f\n\004\b3\020o\022\004\bp\020\017¨\006r"}, d2 = {"Landroidx/room/d;", "", "Ldbxyzptlk/F4/s;", "database", "", "", "shadowTablesMap", "", "viewTables", "", "tableNames", "<init>", "(Ldbxyzptlk/F4/s;Ljava/util/Map;Ljava/util/Map;[Ljava/lang/String;)V", "Ldbxyzptlk/pI/D;", "n", "()V", "Ldbxyzptlk/L4/g;", "db", "", "tableId", "w", "(Ldbxyzptlk/L4/g;I)V", "u", "z", "([Ljava/lang/String;)[Ljava/lang/String;", "names", "r", "Ldbxyzptlk/F4/c;", "autoCloser", "s", "(Ldbxyzptlk/F4/c;)V", "l", "(Ldbxyzptlk/L4/g;)V", "Landroid/content/Context;", "context", "name", "Landroid/content/Intent;", "serviceIntent", "t", "(Landroid/content/Context;Ljava/lang/String;Landroid/content/Intent;)V", "v", "Landroidx/room/d$c;", "observer", "c", "(Landroidx/room/d$c;)V", "d", "q", "", "f", "()Z", "o", "p", "tables", "m", "([Ljava/lang/String;)V", "y", "x", "T", "inTransaction", "Ljava/util/concurrent/Callable;", "computeFunction", "Landroidx/lifecycle/LiveData;", "e", "([Ljava/lang/String;ZLjava/util/concurrent/Callable;)Landroidx/lifecycle/LiveData;", "a", "Ldbxyzptlk/F4/s;", "h", "()Ldbxyzptlk/F4/s;", "b", "Ljava/util/Map;", "k", "()Ljava/util/Map;", "tableIdLookup", "[Ljava/lang/String;", "getTablesNames$room_runtime_release", "()[Ljava/lang/String;", "tablesNames", "Ldbxyzptlk/F4/c;", "Ljava/util/concurrent/atomic/AtomicBoolean;", "g", "Ljava/util/concurrent/atomic/AtomicBoolean;", "j", "()Ljava/util/concurrent/atomic/AtomicBoolean;", "pendingRefresh", "Z", "initialized", "Ldbxyzptlk/L4/k;", "i", "Ldbxyzptlk/L4/k;", "()Ldbxyzptlk/L4/k;", "setCleanupStatement$room_runtime_release", "(Ldbxyzptlk/L4/k;)V", "cleanupStatement", "Landroidx/room/d$b;", "Landroidx/room/d$b;", "observedTableTracker", "Ldbxyzptlk/F4/m;", "Ldbxyzptlk/F4/m;", "invalidationLiveDataContainer", "Ldbxyzptlk/t/b;", "Landroidx/room/d$d;", "Ldbxyzptlk/t/b;", "()Ldbxyzptlk/t/b;", "observerMap", "Landroidx/room/e;", "Landroidx/room/e;", "multiInstanceInvalidationClient", "Ljava/lang/Object;", "syncTriggersLock", "trackerLock", "Ljava/lang/Runnable;", "Ljava/lang/Runnable;", "getRefreshRunnable$annotations", "refreshRunnable", "room-runtime_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public class d {
  public static final a q = new a(null);
  
  public static final String[] r = new String[] { "UPDATE", "DELETE", "INSERT" };
  
  public final s a;
  
  public final Map<String, String> b;
  
  public final Map<String, Set<String>> c;
  
  public final Map<String, Integer> d;
  
  public final String[] e;
  
  public dbxyzptlk.F4.c f;
  
  public final AtomicBoolean g;
  
  public volatile boolean h;
  
  public volatile k i;
  
  public final b j;
  
  public final m k;
  
  public final dbxyzptlk.t.b<c, d> l;
  
  public e m;
  
  public final Object n;
  
  public final Object o;
  
  public final Runnable p;
  
  public d(s params, Map<String, String> paramMap, Map<String, Set<String>> paramMap1, String... paramVarArgs) {
    this.a = params;
    this.b = paramMap;
    this.c = paramMap1;
    byte b1 = 0;
    this.g = new AtomicBoolean(false);
    this.j = new b(paramVarArgs.length);
    this.k = new m(params);
    this.l = new dbxyzptlk.t.b();
    this.n = new Object();
    this.o = new Object();
    this.d = new LinkedHashMap<>();
    int i = paramVarArgs.length;
    String[] arrayOfString = new String[i];
    while (b1 < i) {
      String str1;
      String str2 = paramVarArgs[b1];
      Locale locale = Locale.US;
      s.g(locale, "US");
      str2 = str2.toLowerCase(locale);
      s.g(str2, "this as java.lang.String).toLowerCase(locale)");
      this.d.put(str2, Integer.valueOf(b1));
      String str3 = this.b.get(paramVarArgs[b1]);
      if (str3 != null) {
        s.g(locale, "US");
        str1 = str3.toLowerCase(locale);
        s.g(str1, "this as java.lang.String).toLowerCase(locale)");
      } else {
        locale = null;
      } 
      if (locale == null)
        str1 = str2; 
      arrayOfString[b1] = str1;
      b1++;
    } 
    this.e = arrayOfString;
    for (Map.Entry<String, String> entry : this.b.entrySet()) {
      String str = (String)entry.getValue();
      Locale locale = Locale.US;
      s.g(locale, "US");
      str = str.toLowerCase(locale);
      s.g(str, "this as java.lang.String).toLowerCase(locale)");
      if (this.d.containsKey(str)) {
        String str2 = (String)entry.getKey();
        s.g(locale, "US");
        String str1 = str2.toLowerCase(locale);
        s.g(str1, "this as java.lang.String).toLowerCase(locale)");
        Map<String, Integer> map = this.d;
        map.put(str1, P.l(map, str));
      } 
    } 
    this.p = new f(this);
  }
  
  @SuppressLint({"RestrictedApi"})
  public void c(c paramc) {
    s.h(paramc, "observer");
    String[] arrayOfString = r(paramc.a());
    ArrayList<Integer> arrayList = new ArrayList(arrayOfString.length);
    int i = arrayOfString.length;
    byte b1 = 0;
    while (b1 < i) {
      String str1 = arrayOfString[b1];
      Map<String, Integer> map = this.d;
      Locale locale = Locale.US;
      s.g(locale, "US");
      String str2 = str1.toLowerCase(locale);
      s.g(str2, "this as java.lang.String).toLowerCase(locale)");
      Integer integer = map.get(str2);
      if (integer != null) {
        arrayList.add(integer);
        b1++;
        continue;
      } 
      null = new StringBuilder();
      null.append("There is no table with name ");
      null.append(str1);
      throw new IllegalArgumentException(null.toString());
    } 
    int[] arrayOfInt = A.k1(arrayList);
    d d1 = new d((c)null, arrayOfInt, arrayOfString);
    synchronized (this.l) {
      d d2 = (d)this.l.m(null, d1);
      if (d2 == null && this.j.b(Arrays.copyOf(arrayOfInt, arrayOfInt.length)))
        x(); 
      return;
    } 
  }
  
  public void d(c paramc) {
    s.h(paramc, "observer");
    c((c)new e(this, paramc));
  }
  
  public <T> LiveData<T> e(String[] paramArrayOfString, boolean paramBoolean, Callable<T> paramCallable) {
    s.h(paramArrayOfString, "tableNames");
    s.h(paramCallable, "computeFunction");
    return this.k.a(z(paramArrayOfString), paramBoolean, paramCallable);
  }
  
  public final boolean f() {
    if (!this.a.B())
      return false; 
    if (!this.h)
      this.a.o().getWritableDatabase(); 
    if (!this.h) {
      r0.d("ROOM", "database is not initialized even though it is open");
      return false;
    } 
    return true;
  }
  
  public final k g() {
    return this.i;
  }
  
  public final s h() {
    return this.a;
  }
  
  public final dbxyzptlk.t.b<c, d> i() {
    return this.l;
  }
  
  public final AtomicBoolean j() {
    return this.g;
  }
  
  public final Map<String, Integer> k() {
    return this.d;
  }
  
  public final void l(g paramg) {
    s.h(paramg, "database");
    Object object = this.o;
    /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
    try {
      if (this.h) {
        r0.d("ROOM", "Invalidation tracker is initialized twice :/.");
        /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
        return;
      } 
    } finally {}
    paramg.B1("PRAGMA temp_store = MEMORY;");
    paramg.B1("PRAGMA recursive_triggers='ON';");
    paramg.B1("CREATE TEMP TABLE room_table_modification_log (table_id INTEGER PRIMARY KEY, invalidated INTEGER NOT NULL DEFAULT 0)");
    y(paramg);
    this.i = paramg.B2("UPDATE room_table_modification_log SET invalidated = 0 WHERE invalidated = 1");
    this.h = true;
    D d1 = D.a;
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
  }
  
  public final void m(String... paramVarArgs) {
    s.h(paramVarArgs, "tables");
    dbxyzptlk.t.b<c, d> b1 = this.l;
    /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{dbxyzptlk/t/b<[InnerObjectType{ObjectType{androidx/room/d}.Landroidx/room/d$c;}, InnerObjectType{ObjectType{androidx/room/d}.Landroidx/room/d$d;}]>}, name=null} */
    try {
      for (Map.Entry entry : this.l) {
        s.g(entry, "(observer, wrapper)");
        c c1 = (c)entry.getKey();
        d d2 = (d)entry.getValue();
        if (!c1.b())
          d2.c(paramVarArgs); 
      } 
    } finally {}
    D d1 = D.a;
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{dbxyzptlk/t/b<[InnerObjectType{ObjectType{androidx/room/d}.Landroidx/room/d$c;}, InnerObjectType{ObjectType{androidx/room/d}.Landroidx/room/d$d;}]>}, name=null} */
  }
  
  public final void n() {
    Object object = this.o;
    /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
    try {
      this.h = false;
      this.j.d();
      k k1 = this.i;
      if (k1 != null) {
        k1.close();
        D d1 = D.a;
      } 
    } finally {
      Exception exception;
    } 
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
  }
  
  public void o() {
    if (this.g.compareAndSet(false, true)) {
      dbxyzptlk.F4.c c1 = this.f;
      if (c1 != null)
        c1.j(); 
      this.a.p().execute(this.p);
    } 
  }
  
  public void p() {
    dbxyzptlk.F4.c c1 = this.f;
    if (c1 != null)
      c1.j(); 
    x();
    this.p.run();
  }
  
  @SuppressLint({"RestrictedApi"})
  public void q(c paramc) {
    dbxyzptlk.t.b<c, d> b1;
    int[] arrayOfInt;
    s.h(paramc, "observer");
    synchronized (this.l) {
      d d1 = (d)this.l.p(paramc);
      if (d1 != null) {
        b b2 = this.j;
        arrayOfInt = d1.a();
        if (b2.c(Arrays.copyOf(arrayOfInt, arrayOfInt.length)))
          x(); 
      } 
      return;
    } 
  }
  
  public final String[] r(String[] paramArrayOfString) {
    Set<String> set = X.b();
    int i = paramArrayOfString.length;
    for (byte b1 = 0; b1 < i; b1++) {
      String str1 = paramArrayOfString[b1];
      Map<String, Set<String>> map = this.c;
      Locale locale = Locale.US;
      s.g(locale, "US");
      String str2 = str1.toLowerCase(locale);
      s.g(str2, "this as java.lang.String).toLowerCase(locale)");
      if (map.containsKey(str2)) {
        map = this.c;
        s.g(locale, "US");
        str1 = str1.toLowerCase(locale);
        s.g(str1, "this as java.lang.String).toLowerCase(locale)");
        str1 = (String)map.get(str1);
        s.e(str1);
        set.addAll((Collection)str1);
      } else {
        set.add(str1);
      } 
    } 
    return (String[])X.a(set).toArray((Object[])new String[0]);
  }
  
  public final void s(dbxyzptlk.F4.c paramc) {
    s.h(paramc, "autoCloser");
    this.f = paramc;
    paramc.m((Runnable)new n(this));
  }
  
  public final void t(Context paramContext, String paramString, Intent paramIntent) {
    s.h(paramContext, "context");
    s.h(paramString, "name");
    s.h(paramIntent, "serviceIntent");
    this.m = new e(paramContext, paramString, paramIntent, this, this.a.p());
  }
  
  public final void u(g paramg, int paramInt) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("INSERT OR IGNORE INTO room_table_modification_log VALUES(");
    stringBuilder.append(paramInt);
    stringBuilder.append(", 0)");
    paramg.B1(stringBuilder.toString());
    String str = this.e[paramInt];
    for (String str1 : r) {
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("CREATE TEMP TRIGGER IF NOT EXISTS ");
      stringBuilder1.append(q.b(str, str1));
      stringBuilder1.append(" AFTER ");
      stringBuilder1.append(str1);
      stringBuilder1.append(" ON `");
      stringBuilder1.append(str);
      stringBuilder1.append("` BEGIN UPDATE ");
      stringBuilder1.append("room_table_modification_log");
      stringBuilder1.append(" SET ");
      stringBuilder1.append("invalidated");
      stringBuilder1.append(" = 1");
      stringBuilder1.append(" WHERE ");
      stringBuilder1.append("table_id");
      stringBuilder1.append(" = ");
      stringBuilder1.append(paramInt);
      stringBuilder1.append(" AND ");
      stringBuilder1.append("invalidated");
      stringBuilder1.append(" = 0");
      stringBuilder1.append("; END");
      str1 = stringBuilder1.toString();
      s.g(str1, "StringBuilder().apply(builderAction).toString()");
      paramg.B1(str1);
    } 
  }
  
  public final void v() {
    e e1 = this.m;
    if (e1 != null)
      e1.o(); 
    this.m = null;
  }
  
  public final void w(g paramg, int paramInt) {
    String str = this.e[paramInt];
    String[] arrayOfString = r;
    int i = arrayOfString.length;
    for (paramInt = 0; paramInt < i; paramInt++) {
      String str1 = arrayOfString[paramInt];
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("DROP TRIGGER IF EXISTS ");
      stringBuilder.append(q.b(str, str1));
      str1 = stringBuilder.toString();
      s.g(str1, "StringBuilder().apply(builderAction).toString()");
      paramg.B1(str1);
    } 
  }
  
  public final void x() {
    if (!this.a.B())
      return; 
    y(this.a.o().getWritableDatabase());
  }
  
  public final void y(g paramg) {
    s.h(paramg, "database");
    if (paramg.Y2())
      return; 
    try {
      Lock lock = this.a.m();
      lock.lock();
      try {
        Object object = this.n;
        /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
        try {
          int[] arrayOfInt = this.j.a();
          if (arrayOfInt == null) {
            /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
            lock.unlock();
            return;
          } 
          q.a(paramg);
          try {
            int i = arrayOfInt.length;
            byte b2 = 0;
            for (byte b1 = 0; b2 < i; b1++) {
              int j = arrayOfInt[b2];
              if (j != 1) {
                if (j == 2)
                  w(paramg, b1); 
              } else {
                u(paramg, b1);
              } 
              b2++;
            } 
          } finally {}
          paramg.R1();
          paramg.p();
          D d1 = D.a;
          /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
          lock.unlock();
        } finally {}
      } finally {}
    } catch (IllegalStateException illegalStateException) {
      r0.e("ROOM", "Cannot run invalidation tracker. Is the db closed?", illegalStateException);
    } catch (SQLiteException sQLiteException) {}
  }
  
  public final String[] z(String[] paramArrayOfString) {
    String[] arrayOfString = r(paramArrayOfString);
    int i = arrayOfString.length;
    byte b1 = 0;
    while (b1 < i) {
      String str1 = arrayOfString[b1];
      Map<String, Integer> map = this.d;
      Locale locale = Locale.US;
      s.g(locale, "US");
      String str2 = str1.toLowerCase(locale);
      s.g(str2, "this as java.lang.String).toLowerCase(locale)");
      if (map.containsKey(str2)) {
        b1++;
        continue;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("There is no table with name ");
      stringBuilder.append(str1);
      throw new IllegalArgumentException(stringBuilder.toString().toString());
    } 
    return arrayOfString;
  }
  
  @Metadata(d1 = {"\000*\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\016\n\002\b\004\n\002\030\002\n\000\n\002\030\002\n\002\b\006\n\002\020\021\n\002\b\004\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\037\020\007\032\0020\0042\006\020\005\032\0020\0042\006\020\006\032\0020\004H\000¢\006\004\b\007\020\bJ\027\020\f\032\0020\0132\006\020\n\032\0020\tH\000¢\006\004\b\f\020\rR\024\020\016\032\0020\0048\002XT¢\006\006\n\004\b\016\020\017R\024\020\020\032\0020\0048\002XT¢\006\006\n\004\b\020\020\017R\024\020\021\032\0020\0048\002XT¢\006\006\n\004\b\021\020\017R\032\020\023\032\b\022\004\022\0020\0040\0228\002X\004¢\006\006\n\004\b\023\020\024R\024\020\025\032\0020\0048\002XT¢\006\006\n\004\b\025\020\017¨\006\026"}, d2 = {"Landroidx/room/d$a;", "", "<init>", "()V", "", "tableName", "triggerType", "b", "(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;", "Ldbxyzptlk/L4/g;", "database", "Ldbxyzptlk/pI/D;", "a", "(Ldbxyzptlk/L4/g;)V", "CREATE_TRACKING_TABLE_SQL", "Ljava/lang/String;", "INVALIDATED_COLUMN_NAME", "TABLE_ID_COLUMN_NAME", "", "TRIGGERS", "[Ljava/lang/String;", "UPDATE_TABLE_NAME", "room-runtime_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class a {
    public a() {}
    
    public final void a(g param1g) {
      s.h(param1g, "database");
      if (param1g.c3()) {
        param1g.j0();
      } else {
        param1g.k();
      } 
    }
    
    public final String b(String param1String1, String param1String2) {
      s.h(param1String1, "tableName");
      s.h(param1String2, "triggerType");
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("`room_table_modification_trigger_");
      stringBuilder.append(param1String1);
      stringBuilder.append('_');
      stringBuilder.append(param1String2);
      stringBuilder.append('`');
      return stringBuilder.toString();
    }
  }
  
  @Metadata(d1 = {"\0006\n\002\030\002\n\002\020\000\n\002\020\b\n\002\b\003\n\002\020\025\n\000\n\002\020\013\n\002\b\003\n\002\030\002\n\002\b\004\n\002\020\026\n\002\b\004\n\002\020\030\n\002\b\f\b\000\030\000 !2\0020\001:\001\017B\017\022\006\020\003\032\0020\002¢\006\004\b\004\020\005J\031\020\t\032\0020\b2\n\020\007\032\0020\006\"\0020\002¢\006\004\b\t\020\nJ\031\020\013\032\0020\b2\n\020\007\032\0020\006\"\0020\002¢\006\004\b\013\020\nJ\r\020\r\032\0020\f¢\006\004\b\r\020\016J\021\020\017\032\004\030\0010\006H\007¢\006\004\b\017\020\020R\027\020\025\032\0020\0218\006¢\006\f\n\004\b\017\020\022\032\004\b\023\020\024R\024\020\030\032\0020\0268\002X\004¢\006\006\n\004\b\t\020\027R\024\020\032\032\0020\0068\002X\004¢\006\006\n\004\b\013\020\031R\"\020 \032\0020\b8\006@\006X\016¢\006\022\n\004\b\r\020\033\032\004\b\034\020\035\"\004\b\036\020\037¨\006\""}, d2 = {"Landroidx/room/d$b;", "", "", "tableCount", "<init>", "(I)V", "", "tableIds", "", "b", "([I)Z", "c", "Ldbxyzptlk/pI/D;", "d", "()V", "a", "()[I", "", "[J", "getTableObservers", "()[J", "tableObservers", "", "[Z", "triggerStates", "[I", "triggerStateChanges", "Z", "getNeedsSync", "()Z", "setNeedsSync", "(Z)V", "needsSync", "e", "room-runtime_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class b {
    public static final a e = new a(null);
    
    public final long[] a;
    
    public final boolean[] b;
    
    public final int[] c;
    
    public boolean d;
    
    public b(int param1Int) {
      this.a = new long[param1Int];
      this.b = new boolean[param1Int];
      this.c = new int[param1Int];
    }
    
    public final int[] a() {
      /* monitor enter ThisExpression{InnerObjectType{ObjectType{androidx/room/d}.Landroidx/room/d$b;}} */
      try {
        boolean bool = this.d;
        if (!bool) {
          /* monitor exit ThisExpression{InnerObjectType{ObjectType{androidx/room/d}.Landroidx/room/d$b;}} */
          return null;
        } 
        long[] arrayOfLong = this.a;
        int i = arrayOfLong.length;
        byte b2 = 0;
        for (byte b1 = 0; b2 < i; b1++) {
          long l = arrayOfLong[b2];
          byte b3 = 1;
          if (l > 0L) {
            bool = true;
          } else {
            bool = false;
          } 
          boolean[] arrayOfBoolean = this.b;
          if (bool != arrayOfBoolean[b1]) {
            int[] arrayOfInt1 = this.c;
            if (!bool)
              b3 = 2; 
            arrayOfInt1[b1] = b3;
          } else {
            this.c[b1] = 0;
          } 
          arrayOfBoolean[b1] = bool;
          b2++;
        } 
      } finally {
        Exception exception;
      } 
      this.d = false;
      int[] arrayOfInt = (int[])this.c.clone();
      /* monitor exit ThisExpression{InnerObjectType{ObjectType{androidx/room/d}.Landroidx/room/d$b;}} */
      return arrayOfInt;
    }
    
    public final boolean b(int... param1VarArgs) {
      boolean bool;
      s.h(param1VarArgs, "tableIds");
      /* monitor enter ThisExpression{InnerObjectType{ObjectType{androidx/room/d}.Landroidx/room/d$b;}} */
      try {
        int i = param1VarArgs.length;
        byte b1 = 0;
        bool = false;
        while (b1 < i) {
          int j = param1VarArgs[b1];
          long[] arrayOfLong = this.a;
          long l = arrayOfLong[j];
          arrayOfLong[j] = 1L + l;
          if (l == 0L) {
            this.d = true;
            bool = true;
          } 
          b1++;
        } 
      } finally {}
      D d = D.a;
      /* monitor exit ThisExpression{InnerObjectType{ObjectType{androidx/room/d}.Landroidx/room/d$b;}} */
      return bool;
    }
    
    public final boolean c(int... param1VarArgs) {
      boolean bool;
      s.h(param1VarArgs, "tableIds");
      /* monitor enter ThisExpression{InnerObjectType{ObjectType{androidx/room/d}.Landroidx/room/d$b;}} */
      try {
        int i = param1VarArgs.length;
        byte b1 = 0;
        bool = false;
        while (b1 < i) {
          int j = param1VarArgs[b1];
          long[] arrayOfLong = this.a;
          long l = arrayOfLong[j];
          arrayOfLong[j] = l - 1L;
          if (l == 1L) {
            this.d = true;
            bool = true;
          } 
          b1++;
        } 
      } finally {}
      D d = D.a;
      /* monitor exit ThisExpression{InnerObjectType{ObjectType{androidx/room/d}.Landroidx/room/d$b;}} */
      return bool;
    }
    
    public final void d() {
      // Byte code:
      //   0: aload_0
      //   1: monitorenter
      //   2: aload_0
      //   3: getfield b : [Z
      //   6: iconst_0
      //   7: invokestatic fill : ([ZZ)V
      //   10: aload_0
      //   11: iconst_1
      //   12: putfield d : Z
      //   15: getstatic dbxyzptlk/pI/D.a : Ldbxyzptlk/pI/D;
      //   18: astore_1
      //   19: aload_0
      //   20: monitorexit
      //   21: return
      //   22: astore_1
      //   23: aload_0
      //   24: monitorexit
      //   25: aload_1
      //   26: athrow
      // Exception table:
      //   from	to	target	type
      //   2	19	22	finally
    }
    
    @Metadata(d1 = {"\000\024\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\b\n\002\b\005\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003R\024\020\005\032\0020\0048\006XT¢\006\006\n\004\b\005\020\006R\024\020\007\032\0020\0048\006XT¢\006\006\n\004\b\007\020\006R\024\020\b\032\0020\0048\006XT¢\006\006\n\004\b\b\020\006¨\006\t"}, d2 = {"Landroidx/room/d$b$a;", "", "<init>", "()V", "", "ADD", "I", "NO_OP", "REMOVE", "room-runtime_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
    public static final class a {
      public a() {}
    }
  }
  
  @Metadata(d1 = {"\000\024\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\b\n\002\b\005\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003R\024\020\005\032\0020\0048\006XT¢\006\006\n\004\b\005\020\006R\024\020\007\032\0020\0048\006XT¢\006\006\n\004\b\007\020\006R\024\020\b\032\0020\0048\006XT¢\006\006\n\004\b\b\020\006¨\006\t"}, d2 = {"Landroidx/room/d$b$a;", "", "<init>", "()V", "", "ADD", "I", "NO_OP", "REMOVE", "room-runtime_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class a {
    public a() {}
  }
  
  @Metadata(d1 = {"\000(\n\002\030\002\n\002\020\000\n\002\020\021\n\002\020\016\n\002\b\003\n\002\020\"\n\002\030\002\n\002\b\005\n\002\020\013\n\002\b\004\b&\030\0002\0020\001B\027\022\016\020\004\032\n\022\006\b\001\022\0020\0030\002¢\006\004\b\005\020\006J\035\020\t\032\0020\b2\f\020\004\032\b\022\004\022\0020\0030\007H&¢\006\004\b\t\020\nR\"\020\004\032\n\022\006\b\001\022\0020\0030\0028\000X\004¢\006\f\n\004\b\013\020\f\032\004\b\013\020\rR\024\020\021\032\0020\0168PX\004¢\006\006\032\004\b\017\020\020¨\006\022"}, d2 = {"Landroidx/room/d$c;", "", "", "", "tables", "<init>", "([Ljava/lang/String;)V", "", "Ldbxyzptlk/pI/D;", "c", "(Ljava/util/Set;)V", "a", "[Ljava/lang/String;", "()[Ljava/lang/String;", "", "b", "()Z", "isRemote", "room-runtime_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static abstract class c {
    public final String[] a;
    
    public c(String[] param1ArrayOfString) {
      this.a = param1ArrayOfString;
    }
    
    public final String[] a() {
      return this.a;
    }
    
    public boolean b() {
      return false;
    }
    
    public abstract void c(Set<String> param1Set);
  }
  
  @Metadata(d1 = {"\0002\n\002\030\002\n\002\020\000\n\002\030\002\n\000\n\002\020\025\n\000\n\002\020\021\n\002\020\016\n\002\b\003\n\002\020\"\n\002\020\b\n\000\n\002\030\002\n\002\b\020\b\000\030\0002\0020\001B'\022\006\020\003\032\0020\002\022\006\020\005\032\0020\004\022\016\020\b\032\n\022\006\b\001\022\0020\0070\006¢\006\004\b\t\020\nJ\037\020\017\032\0020\0162\016\020\r\032\n\022\006\022\004\030\0010\f0\013H\000¢\006\004\b\017\020\020J\037\020\022\032\0020\0162\016\020\021\032\n\022\006\b\001\022\0020\0070\006H\000¢\006\004\b\022\020\023R\032\020\003\032\0020\0028\000X\004¢\006\f\n\004\b\024\020\025\032\004\b\026\020\027R\032\020\005\032\0020\0048\000X\004¢\006\f\n\004\b\017\020\030\032\004\b\024\020\031R\034\020\b\032\n\022\006\b\001\022\0020\0070\0068\002X\004¢\006\006\n\004\b\022\020\032R\032\020\035\032\b\022\004\022\0020\0070\0138\002X\004¢\006\006\n\004\b\033\020\034¨\006\036"}, d2 = {"Landroidx/room/d$d;", "", "Landroidx/room/d$c;", "observer", "", "tableIds", "", "", "tableNames", "<init>", "(Landroidx/room/d$c;[I[Ljava/lang/String;)V", "", "", "invalidatedTablesIds", "Ldbxyzptlk/pI/D;", "b", "(Ljava/util/Set;)V", "tables", "c", "([Ljava/lang/String;)V", "a", "Landroidx/room/d$c;", "getObserver$room_runtime_release", "()Landroidx/room/d$c;", "[I", "()[I", "[Ljava/lang/String;", "d", "Ljava/util/Set;", "singleTableSet", "room-runtime_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class d {
    public final d.c a;
    
    public final int[] b;
    
    public final String[] c;
    
    public final Set<String> d;
    
    public d(d.c param1c, int[] param1ArrayOfint, String[] param1ArrayOfString) {
      Set<String> set;
      boolean bool;
      this.a = param1c;
      this.b = param1ArrayOfint;
      this.c = param1ArrayOfString;
      if (param1ArrayOfString.length == 0) {
        bool = true;
      } else {
        bool = false;
      } 
      if (!bool) {
        set = X.d(param1ArrayOfString[0]);
      } else {
        set = Y.e();
      } 
      this.d = set;
      if (param1ArrayOfint.length == param1ArrayOfString.length)
        return; 
      throw new IllegalStateException("Check failed.");
    }
    
    public final int[] a() {
      return this.b;
    }
    
    public final void b(Set<Integer> param1Set) {
      s.h(param1Set, "invalidatedTablesIds");
      int[] arrayOfInt = this.b;
      int i = arrayOfInt.length;
      if (i != 0) {
        Set<String> set;
        byte b = 0;
        if (i != 1) {
          set = X.b();
          int[] arrayOfInt1 = this.b;
          int j = arrayOfInt1.length;
          for (i = 0; b < j; i++) {
            if (param1Set.contains(Integer.valueOf(arrayOfInt1[b])))
              set.add(this.c[i]); 
            b++;
          } 
          param1Set = X.a(set);
        } else if (param1Set.contains(Integer.valueOf(set[0]))) {
          Set<String> set1 = this.d;
        } else {
          param1Set = Y.e();
        } 
      } else {
        param1Set = Y.e();
      } 
      if (!param1Set.isEmpty())
        this.a.c((Set)param1Set); 
    }
    
    public final void c(String[] param1ArrayOfString) {
      Set<String> set;
      s.h(param1ArrayOfString, "tables");
      int i = this.c.length;
      if (i != 0) {
        if (i != 1) {
          Set<String> set1 = X.b();
          int j = param1ArrayOfString.length;
          for (i = 0; i < j; i++) {
            String str = param1ArrayOfString[i];
            for (String str1 : this.c) {
              if (t.z(str1, str, true))
                set1.add(str1); 
            } 
          } 
          set = X.a(set1);
        } else {
          int j = set.length;
          i = 0;
          while (true) {
            if (i < j) {
              if (t.z((String)set[i], this.c[0], true)) {
                set = this.d;
                break;
              } 
              i++;
              continue;
            } 
            set = Y.e();
            break;
          } 
        } 
      } else {
        set = Y.e();
      } 
      if (!set.isEmpty())
        this.a.c(set); 
    }
  }
  
  class d {}
  
  @Metadata(d1 = {"\000\035\n\000\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\"\n\002\020\b\n\002\b\003*\001\000\b\n\030\0002\0020\001J\017\020\003\032\0020\002H\026¢\006\004\b\003\020\004J\025\020\007\032\b\022\004\022\0020\0060\005H\002¢\006\004\b\007\020\b¨\006\t"}, d2 = {"androidx/room/d$f", "Ljava/lang/Runnable;", "Ldbxyzptlk/pI/D;", "run", "()V", "", "", "a", "()Ljava/util/Set;", "room-runtime_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class f implements Runnable {
    public final d a;
    
    public f(d param1d) {}
    
    public final Set<Integer> a() {
      d d1 = this.a;
      Set<Integer> set = X.b();
      Closeable closeable = (Closeable)s.E(d1.h(), (j)new dbxyzptlk.L4.a("SELECT * FROM room_table_modification_log WHERE invalidated = 1;"), null, 2, null);
      try {
        Cursor cursor = (Cursor)closeable;
        while (cursor.moveToNext())
          set.add(Integer.valueOf(cursor.getInt(0))); 
      } finally {
        Exception exception;
      } 
      D d2 = D.a;
      dbxyzptlk.AI.b.a(closeable, null);
      set = X.a(set);
      if (!set.isEmpty())
        if (this.a.g() != null) {
          k k = this.a.g();
          if (k != null) {
            k.Z();
          } else {
            throw new IllegalArgumentException("Required value was null.");
          } 
        } else {
          throw new IllegalStateException("Required value was null.");
        }  
      return set;
    }
    
    public void run() {
      // Byte code:
      //   0: aload_0
      //   1: getfield a : Landroidx/room/d;
      //   4: invokevirtual h : ()Ldbxyzptlk/F4/s;
      //   7: invokevirtual m : ()Ljava/util/concurrent/locks/Lock;
      //   10: astore_2
      //   11: aload_2
      //   12: invokeinterface lock : ()V
      //   17: aload_0
      //   18: getfield a : Landroidx/room/d;
      //   21: invokevirtual f : ()Z
      //   24: istore_1
      //   25: iload_1
      //   26: ifne -> 52
      //   29: aload_2
      //   30: invokeinterface unlock : ()V
      //   35: aload_0
      //   36: getfield a : Landroidx/room/d;
      //   39: invokestatic b : (Landroidx/room/d;)Ldbxyzptlk/F4/c;
      //   42: astore_2
      //   43: aload_2
      //   44: ifnull -> 51
      //   47: aload_2
      //   48: invokevirtual e : ()V
      //   51: return
      //   52: aload_0
      //   53: getfield a : Landroidx/room/d;
      //   56: invokevirtual j : ()Ljava/util/concurrent/atomic/AtomicBoolean;
      //   59: iconst_1
      //   60: iconst_0
      //   61: invokevirtual compareAndSet : (ZZ)Z
      //   64: istore_1
      //   65: iload_1
      //   66: ifne -> 92
      //   69: aload_2
      //   70: invokeinterface unlock : ()V
      //   75: aload_0
      //   76: getfield a : Landroidx/room/d;
      //   79: invokestatic b : (Landroidx/room/d;)Ldbxyzptlk/F4/c;
      //   82: astore_2
      //   83: aload_2
      //   84: ifnull -> 91
      //   87: aload_2
      //   88: invokevirtual e : ()V
      //   91: return
      //   92: aload_0
      //   93: getfield a : Landroidx/room/d;
      //   96: invokevirtual h : ()Ldbxyzptlk/F4/s;
      //   99: invokevirtual u : ()Z
      //   102: istore_1
      //   103: iload_1
      //   104: ifeq -> 130
      //   107: aload_2
      //   108: invokeinterface unlock : ()V
      //   113: aload_0
      //   114: getfield a : Landroidx/room/d;
      //   117: invokestatic b : (Landroidx/room/d;)Ldbxyzptlk/F4/c;
      //   120: astore_2
      //   121: aload_2
      //   122: ifnull -> 129
      //   125: aload_2
      //   126: invokevirtual e : ()V
      //   129: return
      //   130: aload_0
      //   131: getfield a : Landroidx/room/d;
      //   134: invokevirtual h : ()Ldbxyzptlk/F4/s;
      //   137: invokevirtual o : ()Ldbxyzptlk/L4/h;
      //   140: invokeinterface getWritableDatabase : ()Ldbxyzptlk/L4/g;
      //   145: astore #4
      //   147: aload #4
      //   149: invokeinterface j0 : ()V
      //   154: aload_0
      //   155: invokevirtual a : ()Ljava/util/Set;
      //   158: astore_3
      //   159: aload #4
      //   161: invokeinterface R1 : ()V
      //   166: aload #4
      //   168: invokeinterface p : ()V
      //   173: aload_2
      //   174: invokeinterface unlock : ()V
      //   179: aload_0
      //   180: getfield a : Landroidx/room/d;
      //   183: invokestatic b : (Landroidx/room/d;)Ldbxyzptlk/F4/c;
      //   186: astore #4
      //   188: aload_3
      //   189: astore_2
      //   190: aload #4
      //   192: ifnull -> 311
      //   195: aload_3
      //   196: astore_2
      //   197: aload #4
      //   199: astore_3
      //   200: aload_3
      //   201: invokevirtual e : ()V
      //   204: goto -> 311
      //   207: astore_3
      //   208: goto -> 404
      //   211: astore_3
      //   212: goto -> 229
      //   215: astore_3
      //   216: goto -> 270
      //   219: astore_3
      //   220: aload #4
      //   222: invokeinterface p : ()V
      //   227: aload_3
      //   228: athrow
      //   229: ldc 'ROOM'
      //   231: ldc 'Cannot run invalidation tracker. Is the db closed?'
      //   233: aload_3
      //   234: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   237: pop
      //   238: invokestatic e : ()Ljava/util/Set;
      //   241: astore #4
      //   243: aload_2
      //   244: invokeinterface unlock : ()V
      //   249: aload_0
      //   250: getfield a : Landroidx/room/d;
      //   253: invokestatic b : (Landroidx/room/d;)Ldbxyzptlk/F4/c;
      //   256: astore_3
      //   257: aload #4
      //   259: astore_2
      //   260: aload_3
      //   261: ifnull -> 311
      //   264: aload #4
      //   266: astore_2
      //   267: goto -> 200
      //   270: ldc 'ROOM'
      //   272: ldc 'Cannot run invalidation tracker. Is the db closed?'
      //   274: aload_3
      //   275: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   278: pop
      //   279: invokestatic e : ()Ljava/util/Set;
      //   282: astore #4
      //   284: aload_2
      //   285: invokeinterface unlock : ()V
      //   290: aload_0
      //   291: getfield a : Landroidx/room/d;
      //   294: invokestatic b : (Landroidx/room/d;)Ldbxyzptlk/F4/c;
      //   297: astore_3
      //   298: aload #4
      //   300: astore_2
      //   301: aload_3
      //   302: ifnull -> 311
      //   305: aload #4
      //   307: astore_2
      //   308: goto -> 200
      //   311: aload_2
      //   312: checkcast java/util/Collection
      //   315: invokeinterface isEmpty : ()Z
      //   320: ifne -> 403
      //   323: aload_0
      //   324: getfield a : Landroidx/room/d;
      //   327: invokevirtual i : ()Ldbxyzptlk/t/b;
      //   330: astore_3
      //   331: aload_0
      //   332: getfield a : Landroidx/room/d;
      //   335: astore #4
      //   337: aload_3
      //   338: monitorenter
      //   339: aload #4
      //   341: invokevirtual i : ()Ldbxyzptlk/t/b;
      //   344: invokeinterface iterator : ()Ljava/util/Iterator;
      //   349: astore #4
      //   351: aload #4
      //   353: invokeinterface hasNext : ()Z
      //   358: ifeq -> 390
      //   361: aload #4
      //   363: invokeinterface next : ()Ljava/lang/Object;
      //   368: checkcast java/util/Map$Entry
      //   371: invokeinterface getValue : ()Ljava/lang/Object;
      //   376: checkcast androidx/room/d$d
      //   379: aload_2
      //   380: invokevirtual b : (Ljava/util/Set;)V
      //   383: goto -> 351
      //   386: astore_2
      //   387: goto -> 399
      //   390: getstatic dbxyzptlk/pI/D.a : Ldbxyzptlk/pI/D;
      //   393: astore_2
      //   394: aload_3
      //   395: monitorexit
      //   396: goto -> 403
      //   399: aload_3
      //   400: monitorexit
      //   401: aload_2
      //   402: athrow
      //   403: return
      //   404: aload_2
      //   405: invokeinterface unlock : ()V
      //   410: aload_0
      //   411: getfield a : Landroidx/room/d;
      //   414: invokestatic b : (Landroidx/room/d;)Ldbxyzptlk/F4/c;
      //   417: astore_2
      //   418: aload_2
      //   419: ifnull -> 426
      //   422: aload_2
      //   423: invokevirtual e : ()V
      //   426: aload_3
      //   427: athrow
      // Exception table:
      //   from	to	target	type
      //   17	25	215	java/lang/IllegalStateException
      //   17	25	211	android/database/sqlite/SQLiteException
      //   17	25	207	finally
      //   52	65	215	java/lang/IllegalStateException
      //   52	65	211	android/database/sqlite/SQLiteException
      //   52	65	207	finally
      //   92	103	215	java/lang/IllegalStateException
      //   92	103	211	android/database/sqlite/SQLiteException
      //   92	103	207	finally
      //   130	154	215	java/lang/IllegalStateException
      //   130	154	211	android/database/sqlite/SQLiteException
      //   130	154	207	finally
      //   154	166	219	finally
      //   166	173	215	java/lang/IllegalStateException
      //   166	173	211	android/database/sqlite/SQLiteException
      //   166	173	207	finally
      //   220	229	215	java/lang/IllegalStateException
      //   220	229	211	android/database/sqlite/SQLiteException
      //   220	229	207	finally
      //   229	243	207	finally
      //   270	284	207	finally
      //   339	351	386	finally
      //   351	383	386	finally
      //   390	394	386	finally
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\room\d.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */