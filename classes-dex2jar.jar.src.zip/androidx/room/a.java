package androidx.room;

import android.os.CancellationSignal;
import dbxyzptlk.CI.p;
import dbxyzptlk.F4.s;
import dbxyzptlk.bK.J;
import dbxyzptlk.bK.K;
import dbxyzptlk.dK.d;
import dbxyzptlk.eK.i;
import dbxyzptlk.eK.j;
import dbxyzptlk.eK.k;
import dbxyzptlk.pI.D;
import dbxyzptlk.pI.p;
import dbxyzptlk.tI.d;
import dbxyzptlk.uI.c;
import dbxyzptlk.vI.f;
import dbxyzptlk.vI.l;
import java.util.Set;
import java.util.concurrent.Callable;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

@Metadata(d1 = {"\000\f\n\002\030\002\n\002\020\000\n\002\b\002\b\007\030\000 \0022\0020\001:\001\002¨\006\003"}, d2 = {"Landroidx/room/a;", "", "a", "room-ktx_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class a {
  public static final a a = new a(null);
  
  public static final <R> i<R> a(s params, boolean paramBoolean, String[] paramArrayOfString, Callable<R> paramCallable) {
    return a.a(params, paramBoolean, paramArrayOfString, paramCallable);
  }
  
  public static final <R> Object b(s params, boolean paramBoolean, CancellationSignal paramCancellationSignal, Callable<R> paramCallable, d<? super R> paramd) {
    return a.b(params, paramBoolean, paramCancellationSignal, paramCallable, paramd);
  }
  
  public static final <R> Object c(s params, boolean paramBoolean, Callable<R> paramCallable, d<? super R> paramd) {
    return a.c(params, paramBoolean, paramCallable, paramd);
  }
  
  @Metadata(d1 = {"\000:\n\002\030\002\n\002\020\000\n\002\b\003\n\002\030\002\n\000\n\002\020\013\n\000\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\020\021\n\002\020\016\n\000\n\002\030\002\n\002\b\003\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J7\020\013\032\0028\000\"\004\b\000\020\0042\006\020\006\032\0020\0052\006\020\b\032\0020\0072\f\020\n\032\b\022\004\022\0028\0000\tH@ø\001\000¢\006\004\b\013\020\fJA\020\017\032\0028\000\"\004\b\000\020\0042\006\020\006\032\0020\0052\006\020\b\032\0020\0072\b\020\016\032\004\030\0010\r2\f\020\n\032\b\022\004\022\0028\0000\tH@ø\001\000¢\006\004\b\017\020\020JG\020\025\032\b\022\004\022\0028\0000\024\"\004\b\000\020\0042\006\020\006\032\0020\0052\006\020\b\032\0020\0072\f\020\023\032\b\022\004\022\0020\0220\0212\f\020\n\032\b\022\004\022\0028\0000\tH\007¢\006\004\b\025\020\026\002\004\n\002\b\031¨\006\027"}, d2 = {"Landroidx/room/a$a;", "", "<init>", "()V", "R", "Ldbxyzptlk/F4/s;", "db", "", "inTransaction", "Ljava/util/concurrent/Callable;", "callable", "c", "(Ldbxyzptlk/F4/s;ZLjava/util/concurrent/Callable;Ldbxyzptlk/tI/d;)Ljava/lang/Object;", "Landroid/os/CancellationSignal;", "cancellationSignal", "b", "(Ldbxyzptlk/F4/s;ZLandroid/os/CancellationSignal;Ljava/util/concurrent/Callable;Ldbxyzptlk/tI/d;)Ljava/lang/Object;", "", "", "tableNames", "Ldbxyzptlk/eK/i;", "a", "(Ldbxyzptlk/F4/s;Z[Ljava/lang/String;Ljava/util/concurrent/Callable;)Ldbxyzptlk/eK/i;", "room-ktx_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class a {
    public a() {}
    
    public final <R> i<R> a(s param1s, boolean param1Boolean, String[] param1ArrayOfString, Callable<R> param1Callable) {
      return k.P(new a(param1Boolean, param1s, param1ArrayOfString, param1Callable, null));
    }
    
    public final <R> Object b(s param1s, boolean param1Boolean, CancellationSignal param1CancellationSignal, Callable<R> param1Callable, d<? super R> param1d) {
      // Byte code:
      //   0: aload_1
      //   1: invokevirtual B : ()Z
      //   4: ifeq -> 22
      //   7: aload_1
      //   8: invokevirtual u : ()Z
      //   11: ifeq -> 22
      //   14: aload #4
      //   16: invokeinterface call : ()Ljava/lang/Object;
      //   21: areturn
      //   22: aload #5
      //   24: invokeinterface getContext : ()Ldbxyzptlk/tI/g;
      //   29: getstatic androidx/room/i.c : Landroidx/room/i$a;
      //   32: invokeinterface c : (Ldbxyzptlk/tI/g$c;)Ldbxyzptlk/tI/g$b;
      //   37: checkcast androidx/room/i
      //   40: astore #6
      //   42: aload #6
      //   44: ifnull -> 69
      //   47: aload #6
      //   49: invokevirtual j : ()Ldbxyzptlk/tI/e;
      //   52: astore #7
      //   54: aload #7
      //   56: astore #6
      //   58: aload #7
      //   60: ifnonnull -> 66
      //   63: goto -> 69
      //   66: goto -> 92
      //   69: iload_2
      //   70: ifeq -> 84
      //   73: aload_1
      //   74: invokestatic b : (Ldbxyzptlk/F4/s;)Ldbxyzptlk/bK/F;
      //   77: astore_1
      //   78: aload_1
      //   79: astore #6
      //   81: goto -> 66
      //   84: aload_1
      //   85: invokestatic a : (Ldbxyzptlk/F4/s;)Ldbxyzptlk/bK/F;
      //   88: astore_1
      //   89: goto -> 78
      //   92: new dbxyzptlk/bK/n
      //   95: dup
      //   96: aload #5
      //   98: invokestatic d : (Ldbxyzptlk/tI/d;)Ldbxyzptlk/tI/d;
      //   101: iconst_1
      //   102: invokespecial <init> : (Ldbxyzptlk/tI/d;I)V
      //   105: astore_1
      //   106: aload_1
      //   107: invokevirtual F : ()V
      //   110: aload_1
      //   111: new androidx/room/a$a$c
      //   114: dup
      //   115: aload_3
      //   116: getstatic dbxyzptlk/bK/o0.a : Ldbxyzptlk/bK/o0;
      //   119: aload #6
      //   121: aconst_null
      //   122: new androidx/room/a$a$d
      //   125: dup
      //   126: aload #4
      //   128: aload_1
      //   129: aconst_null
      //   130: invokespecial <init> : (Ljava/util/concurrent/Callable;Ldbxyzptlk/bK/m;Ldbxyzptlk/tI/d;)V
      //   133: iconst_2
      //   134: aconst_null
      //   135: invokestatic d : (Ldbxyzptlk/bK/J;Ldbxyzptlk/tI/g;Ldbxyzptlk/bK/L;Ldbxyzptlk/CI/p;ILjava/lang/Object;)Ldbxyzptlk/bK/w0;
      //   138: invokespecial <init> : (Landroid/os/CancellationSignal;Ldbxyzptlk/bK/w0;)V
      //   141: invokeinterface v : (Ldbxyzptlk/CI/l;)V
      //   146: aload_1
      //   147: invokevirtual w : ()Ljava/lang/Object;
      //   150: astore_1
      //   151: aload_1
      //   152: invokestatic g : ()Ljava/lang/Object;
      //   155: if_acmpne -> 163
      //   158: aload #5
      //   160: invokestatic c : (Ldbxyzptlk/tI/d;)V
      //   163: aload_1
      //   164: areturn
    }
    
    public final <R> Object c(s param1s, boolean param1Boolean, Callable<R> param1Callable, d<? super R> param1d) {
      // Byte code:
      //   0: aload_1
      //   1: invokevirtual B : ()Z
      //   4: ifeq -> 21
      //   7: aload_1
      //   8: invokevirtual u : ()Z
      //   11: ifeq -> 21
      //   14: aload_3
      //   15: invokeinterface call : ()Ljava/lang/Object;
      //   20: areturn
      //   21: aload #4
      //   23: invokeinterface getContext : ()Ldbxyzptlk/tI/g;
      //   28: getstatic androidx/room/i.c : Landroidx/room/i$a;
      //   31: invokeinterface c : (Ldbxyzptlk/tI/g$c;)Ldbxyzptlk/tI/g$b;
      //   36: checkcast androidx/room/i
      //   39: astore #5
      //   41: aload #5
      //   43: ifnull -> 62
      //   46: aload #5
      //   48: invokevirtual j : ()Ldbxyzptlk/tI/e;
      //   51: astore #6
      //   53: aload #6
      //   55: astore #5
      //   57: aload #6
      //   59: ifnonnull -> 85
      //   62: iload_2
      //   63: ifeq -> 77
      //   66: aload_1
      //   67: invokestatic b : (Ldbxyzptlk/F4/s;)Ldbxyzptlk/bK/F;
      //   70: astore_1
      //   71: aload_1
      //   72: astore #5
      //   74: goto -> 85
      //   77: aload_1
      //   78: invokestatic a : (Ldbxyzptlk/F4/s;)Ldbxyzptlk/bK/F;
      //   81: astore_1
      //   82: goto -> 71
      //   85: aload #5
      //   87: new androidx/room/a$a$b
      //   90: dup
      //   91: aload_3
      //   92: aconst_null
      //   93: invokespecial <init> : (Ljava/util/concurrent/Callable;Ldbxyzptlk/tI/d;)V
      //   96: aload #4
      //   98: invokestatic g : (Ldbxyzptlk/tI/g;Ldbxyzptlk/CI/p;Ldbxyzptlk/tI/d;)Ljava/lang/Object;
      //   101: areturn
    }
    
    @f(c = "androidx.room.CoroutinesRoom$Companion$createFlow$1", f = "CoroutinesRoom.kt", l = {111}, m = "invokeSuspend")
    @Metadata(d1 = {"\000\016\n\000\n\002\030\002\n\002\030\002\n\002\b\002\020\003\032\0020\002\"\004\b\000\020\000*\b\022\004\022\0028\0000\001H@¢\006\004\b\003\020\004"}, d2 = {"R", "Ldbxyzptlk/eK/j;", "Ldbxyzptlk/pI/D;", "<anonymous>", "(Ldbxyzptlk/eK/j;)V"}, k = 3, mv = {1, 8, 0})
    public static final class a extends l implements p<j<R>, d<? super D>, Object> {
      public int t;
      
      public Object u;
      
      public final boolean v;
      
      public final s w;
      
      public final String[] x;
      
      public final Callable<R> y;
      
      public a(boolean param2Boolean, s param2s, String[] param2ArrayOfString, Callable<R> param2Callable, d<? super a> param2d) {
        super(2, param2d);
      }
      
      public final Object a(j<R> param2j, d<? super D> param2d) {
        return ((a)create(param2j, param2d)).invokeSuspend(D.a);
      }
      
      public final d<D> create(Object param2Object, d<?> param2d) {
        a a1 = new a(this.v, this.w, this.x, this.y, (d)param2d);
        a1.u = param2Object;
        return (d<D>)a1;
      }
      
      public final Object invokeSuspend(Object param2Object) {
        Object object = c.g();
        int i = this.t;
        if (i != 0) {
          if (i == 1) {
            p.b(param2Object);
          } else {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
          } 
        } else {
          p.b(param2Object);
          param2Object = this.u;
          param2Object = new a(this.v, this.w, (j<R>)param2Object, this.x, this.y, null);
          this.t = 1;
          if (K.g((p)param2Object, (d)this) == object)
            return object; 
        } 
        return D.a;
      }
      
      @f(c = "androidx.room.CoroutinesRoom$Companion$createFlow$1$1", f = "CoroutinesRoom.kt", l = {137}, m = "invokeSuspend")
      @Metadata(d1 = {"\000\016\n\000\n\002\030\002\n\002\030\002\n\002\b\002\020\003\032\0020\002\"\004\b\000\020\000*\0020\001H@¢\006\004\b\003\020\004"}, d2 = {"R", "Ldbxyzptlk/bK/J;", "Ldbxyzptlk/pI/D;", "<anonymous>", "(Ldbxyzptlk/bK/J;)V"}, k = 3, mv = {1, 8, 0})
      public static final class a extends l implements p<J, d<? super D>, Object> {
        public int t;
        
        public Object u;
        
        public final boolean v;
        
        public final s w;
        
        public final j<R> x;
        
        public final String[] y;
        
        public final Callable<R> z;
        
        public a(boolean param3Boolean, s param3s, j<R> param3j, String[] param3ArrayOfString, Callable<R> param3Callable, d<? super a> param3d) {
          super(2, param3d);
        }
        
        public final d<D> create(Object param3Object, d<?> param3d) {
          a a1 = new a(this.v, this.w, this.x, this.y, this.z, (d)param3d);
          a1.u = param3Object;
          return (d<D>)a1;
        }
        
        public final Object invoke(J param3J, d<? super D> param3d) {
          return ((a)create(param3J, param3d)).invokeSuspend(D.a);
        }
        
        public final Object invokeSuspend(Object param3Object) {
          // Byte code:
          //   0: invokestatic g : ()Ljava/lang/Object;
          //   3: astore #4
          //   5: aload_0
          //   6: getfield t : I
          //   9: istore_2
          //   10: iload_2
          //   11: ifeq -> 36
          //   14: iload_2
          //   15: iconst_1
          //   16: if_icmpne -> 26
          //   19: aload_1
          //   20: invokestatic b : (Ljava/lang/Object;)V
          //   23: goto -> 211
          //   26: new java/lang/IllegalStateException
          //   29: dup
          //   30: ldc 'call to 'resume' before 'invoke' with coroutine'
          //   32: invokespecial <init> : (Ljava/lang/String;)V
          //   35: athrow
          //   36: aload_1
          //   37: invokestatic b : (Ljava/lang/Object;)V
          //   40: aload_0
          //   41: getfield u : Ljava/lang/Object;
          //   44: checkcast dbxyzptlk/bK/J
          //   47: astore #7
          //   49: iconst_m1
          //   50: aconst_null
          //   51: aconst_null
          //   52: bipush #6
          //   54: aconst_null
          //   55: invokestatic b : (ILdbxyzptlk/dK/a;Ldbxyzptlk/CI/l;ILjava/lang/Object;)Ldbxyzptlk/dK/d;
          //   58: astore #5
          //   60: new androidx/room/a$a$a$a$b
          //   63: dup
          //   64: aload_0
          //   65: getfield y : [Ljava/lang/String;
          //   68: aload #5
          //   70: invokespecial <init> : ([Ljava/lang/String;Ldbxyzptlk/dK/d;)V
          //   73: astore #6
          //   75: aload #5
          //   77: getstatic dbxyzptlk/pI/D.a : Ldbxyzptlk/pI/D;
          //   80: invokeinterface k : (Ljava/lang/Object;)Ljava/lang/Object;
          //   85: pop
          //   86: aload #7
          //   88: invokeinterface getCoroutineContext : ()Ldbxyzptlk/tI/g;
          //   93: getstatic androidx/room/i.c : Landroidx/room/i$a;
          //   96: invokeinterface c : (Ldbxyzptlk/tI/g$c;)Ldbxyzptlk/tI/g$b;
          //   101: checkcast androidx/room/i
          //   104: astore_1
          //   105: aload_1
          //   106: ifnull -> 120
          //   109: aload_1
          //   110: invokevirtual j : ()Ldbxyzptlk/tI/e;
          //   113: astore_3
          //   114: aload_3
          //   115: astore_1
          //   116: aload_3
          //   117: ifnonnull -> 146
          //   120: aload_0
          //   121: getfield v : Z
          //   124: ifeq -> 138
          //   127: aload_0
          //   128: getfield w : Ldbxyzptlk/F4/s;
          //   131: invokestatic b : (Ldbxyzptlk/F4/s;)Ldbxyzptlk/bK/F;
          //   134: astore_1
          //   135: goto -> 146
          //   138: aload_0
          //   139: getfield w : Ldbxyzptlk/F4/s;
          //   142: invokestatic a : (Ldbxyzptlk/F4/s;)Ldbxyzptlk/bK/F;
          //   145: astore_1
          //   146: iconst_0
          //   147: aconst_null
          //   148: aconst_null
          //   149: bipush #7
          //   151: aconst_null
          //   152: invokestatic b : (ILdbxyzptlk/dK/a;Ldbxyzptlk/CI/l;ILjava/lang/Object;)Ldbxyzptlk/dK/d;
          //   155: astore_3
          //   156: aload #7
          //   158: aload_1
          //   159: aconst_null
          //   160: new androidx/room/a$a$a$a$a
          //   163: dup
          //   164: aload_0
          //   165: getfield w : Ldbxyzptlk/F4/s;
          //   168: aload #6
          //   170: aload #5
          //   172: aload_0
          //   173: getfield z : Ljava/util/concurrent/Callable;
          //   176: aload_3
          //   177: aconst_null
          //   178: invokespecial <init> : (Ldbxyzptlk/F4/s;Landroidx/room/a$a$a$a$b;Ldbxyzptlk/dK/d;Ljava/util/concurrent/Callable;Ldbxyzptlk/dK/d;Ldbxyzptlk/tI/d;)V
          //   181: iconst_2
          //   182: aconst_null
          //   183: invokestatic d : (Ldbxyzptlk/bK/J;Ldbxyzptlk/tI/g;Ldbxyzptlk/bK/L;Ldbxyzptlk/CI/p;ILjava/lang/Object;)Ldbxyzptlk/bK/w0;
          //   186: pop
          //   187: aload_0
          //   188: getfield x : Ldbxyzptlk/eK/j;
          //   191: astore_1
          //   192: aload_0
          //   193: iconst_1
          //   194: putfield t : I
          //   197: aload_1
          //   198: aload_3
          //   199: aload_0
          //   200: invokestatic A : (Ldbxyzptlk/eK/j;Ldbxyzptlk/dK/s;Ldbxyzptlk/tI/d;)Ljava/lang/Object;
          //   203: aload #4
          //   205: if_acmpne -> 211
          //   208: aload #4
          //   210: areturn
          //   211: getstatic dbxyzptlk/pI/D.a : Ldbxyzptlk/pI/D;
          //   214: areturn
        }
        
        @f(c = "androidx.room.CoroutinesRoom$Companion$createFlow$1$1$1", f = "CoroutinesRoom.kt", l = {128, 130}, m = "invokeSuspend")
        @Metadata(d1 = {"\000\016\n\000\n\002\030\002\n\002\030\002\n\002\b\002\020\003\032\0020\002\"\004\b\000\020\000*\0020\001H@¢\006\004\b\003\020\004"}, d2 = {"R", "Ldbxyzptlk/bK/J;", "Ldbxyzptlk/pI/D;", "<anonymous>", "(Ldbxyzptlk/bK/J;)V"}, k = 3, mv = {1, 8, 0})
        public static final class a extends l implements p<J, d<? super D>, Object> {
          public Object t;
          
          public int u;
          
          public final s v;
          
          public final a.a.a.a.b w;
          
          public final d<D> x;
          
          public final Callable<R> y;
          
          public final d<R> z;
          
          public a(s param4s, a.a.a.a.b param4b, d<D> param4d1, Callable<R> param4Callable, d<R> param4d2, d param4d) {
            super(2, param4d);
          }
          
          public final d<D> create(Object param4Object, d<?> param4d) {
            return (d<D>)new a(this.v, this.w, this.x, this.y, this.z, param4d);
          }
          
          public final Object invoke(J param4J, d<? super D> param4d) {
            return ((a)create(param4J, param4d)).invokeSuspend(D.a);
          }
          
          public final Object invokeSuspend(Object<R> param4Object) {
            // Byte code:
            //   0: invokestatic g : ()Ljava/lang/Object;
            //   3: astore #5
            //   5: aload_0
            //   6: getfield u : I
            //   9: istore_2
            //   10: iload_2
            //   11: ifeq -> 73
            //   14: iload_2
            //   15: iconst_1
            //   16: if_icmpeq -> 55
            //   19: iload_2
            //   20: iconst_2
            //   21: if_icmpne -> 45
            //   24: aload_0
            //   25: getfield t : Ljava/lang/Object;
            //   28: checkcast dbxyzptlk/dK/f
            //   31: astore_3
            //   32: aload_1
            //   33: invokestatic b : (Ljava/lang/Object;)V
            //   36: aload_3
            //   37: astore_1
            //   38: goto -> 101
            //   41: astore_1
            //   42: goto -> 213
            //   45: new java/lang/IllegalStateException
            //   48: dup
            //   49: ldc 'call to 'resume' before 'invoke' with coroutine'
            //   51: invokespecial <init> : (Ljava/lang/String;)V
            //   54: athrow
            //   55: aload_0
            //   56: getfield t : Ljava/lang/Object;
            //   59: checkcast dbxyzptlk/dK/f
            //   62: astore_3
            //   63: aload_1
            //   64: invokestatic b : (Ljava/lang/Object;)V
            //   67: aload_1
            //   68: astore #4
            //   70: goto -> 132
            //   73: aload_1
            //   74: invokestatic b : (Ljava/lang/Object;)V
            //   77: aload_0
            //   78: getfield v : Ldbxyzptlk/F4/s;
            //   81: invokevirtual n : ()Landroidx/room/d;
            //   84: aload_0
            //   85: getfield w : Landroidx/room/a$a$a$a$b;
            //   88: invokevirtual c : (Landroidx/room/d$c;)V
            //   91: aload_0
            //   92: getfield x : Ldbxyzptlk/dK/d;
            //   95: invokeinterface iterator : ()Ldbxyzptlk/dK/f;
            //   100: astore_1
            //   101: aload_0
            //   102: aload_1
            //   103: putfield t : Ljava/lang/Object;
            //   106: aload_0
            //   107: iconst_1
            //   108: putfield u : I
            //   111: aload_1
            //   112: aload_0
            //   113: invokeinterface a : (Ldbxyzptlk/tI/d;)Ljava/lang/Object;
            //   118: astore #4
            //   120: aload #4
            //   122: aload #5
            //   124: if_acmpne -> 130
            //   127: aload #5
            //   129: areturn
            //   130: aload_1
            //   131: astore_3
            //   132: aload #4
            //   134: checkcast java/lang/Boolean
            //   137: invokevirtual booleanValue : ()Z
            //   140: ifeq -> 195
            //   143: aload_3
            //   144: invokeinterface next : ()Ljava/lang/Object;
            //   149: pop
            //   150: aload_0
            //   151: getfield y : Ljava/util/concurrent/Callable;
            //   154: invokeinterface call : ()Ljava/lang/Object;
            //   159: astore_1
            //   160: aload_0
            //   161: getfield z : Ldbxyzptlk/dK/d;
            //   164: astore #4
            //   166: aload_0
            //   167: aload_3
            //   168: putfield t : Ljava/lang/Object;
            //   171: aload_0
            //   172: iconst_2
            //   173: putfield u : I
            //   176: aload #4
            //   178: aload_1
            //   179: aload_0
            //   180: invokeinterface F : (Ljava/lang/Object;Ldbxyzptlk/tI/d;)Ljava/lang/Object;
            //   185: astore_1
            //   186: aload_1
            //   187: aload #5
            //   189: if_acmpne -> 36
            //   192: aload #5
            //   194: areturn
            //   195: aload_0
            //   196: getfield v : Ldbxyzptlk/F4/s;
            //   199: invokevirtual n : ()Landroidx/room/d;
            //   202: aload_0
            //   203: getfield w : Landroidx/room/a$a$a$a$b;
            //   206: invokevirtual q : (Landroidx/room/d$c;)V
            //   209: getstatic dbxyzptlk/pI/D.a : Ldbxyzptlk/pI/D;
            //   212: areturn
            //   213: aload_0
            //   214: getfield v : Ldbxyzptlk/F4/s;
            //   217: invokevirtual n : ()Landroidx/room/d;
            //   220: aload_0
            //   221: getfield w : Landroidx/room/a$a$a$a$b;
            //   224: invokevirtual q : (Landroidx/room/d$c;)V
            //   227: aload_1
            //   228: athrow
            // Exception table:
            //   from	to	target	type
            //   32	36	41	finally
            //   63	67	41	finally
            //   91	101	41	finally
            //   101	120	41	finally
            //   132	186	41	finally
          }
        }
        
        @Metadata(d1 = {"\000\033\n\000\n\002\030\002\n\002\020\"\n\002\020\016\n\000\n\002\030\002\n\002\b\003*\001\000\b\n\030\0002\0020\001J\035\020\006\032\0020\0052\f\020\004\032\b\022\004\022\0020\0030\002H\026¢\006\004\b\006\020\007¨\006\b"}, d2 = {"androidx/room/a$a$a$a$b", "Landroidx/room/d$c;", "", "", "tables", "Ldbxyzptlk/pI/D;", "c", "(Ljava/util/Set;)V", "room-ktx_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
        public static final class b extends d.c {
          public final d<D> b;
          
          public b(String[] param4ArrayOfString, d<D> param4d) {
            super(param4ArrayOfString);
          }
          
          public void c(Set<String> param4Set) {
            this.b.k(D.a);
          }
        }
      }
      
      @f(c = "androidx.room.CoroutinesRoom$Companion$createFlow$1$1$1", f = "CoroutinesRoom.kt", l = {128, 130}, m = "invokeSuspend")
      @Metadata(d1 = {"\000\016\n\000\n\002\030\002\n\002\030\002\n\002\b\002\020\003\032\0020\002\"\004\b\000\020\000*\0020\001H@¢\006\004\b\003\020\004"}, d2 = {"R", "Ldbxyzptlk/bK/J;", "Ldbxyzptlk/pI/D;", "<anonymous>", "(Ldbxyzptlk/bK/J;)V"}, k = 3, mv = {1, 8, 0})
      public static final class a extends l implements p<J, d<? super D>, Object> {
        public Object t;
        
        public int u;
        
        public final s v;
        
        public final a.a.a.a.b w;
        
        public final d<D> x;
        
        public final Callable<R> y;
        
        public final d<R> z;
        
        public a(s param3s, a.a.a.a.b param3b, d<D> param3d1, Callable<R> param3Callable, d<R> param3d2, d param3d) {
          super(2, param3d);
        }
        
        public final d<D> create(Object param3Object, d<?> param3d) {
          return (d<D>)new a(this.v, this.w, this.x, this.y, this.z, param3d);
        }
        
        public final Object invoke(J param3J, d<? super D> param3d) {
          return ((a)create(param3J, param3d)).invokeSuspend(D.a);
        }
        
        public final Object invokeSuspend(Object<R> param3Object) {
          // Byte code:
          //   0: invokestatic g : ()Ljava/lang/Object;
          //   3: astore #5
          //   5: aload_0
          //   6: getfield u : I
          //   9: istore_2
          //   10: iload_2
          //   11: ifeq -> 73
          //   14: iload_2
          //   15: iconst_1
          //   16: if_icmpeq -> 55
          //   19: iload_2
          //   20: iconst_2
          //   21: if_icmpne -> 45
          //   24: aload_0
          //   25: getfield t : Ljava/lang/Object;
          //   28: checkcast dbxyzptlk/dK/f
          //   31: astore_3
          //   32: aload_1
          //   33: invokestatic b : (Ljava/lang/Object;)V
          //   36: aload_3
          //   37: astore_1
          //   38: goto -> 101
          //   41: astore_1
          //   42: goto -> 213
          //   45: new java/lang/IllegalStateException
          //   48: dup
          //   49: ldc 'call to 'resume' before 'invoke' with coroutine'
          //   51: invokespecial <init> : (Ljava/lang/String;)V
          //   54: athrow
          //   55: aload_0
          //   56: getfield t : Ljava/lang/Object;
          //   59: checkcast dbxyzptlk/dK/f
          //   62: astore_3
          //   63: aload_1
          //   64: invokestatic b : (Ljava/lang/Object;)V
          //   67: aload_1
          //   68: astore #4
          //   70: goto -> 132
          //   73: aload_1
          //   74: invokestatic b : (Ljava/lang/Object;)V
          //   77: aload_0
          //   78: getfield v : Ldbxyzptlk/F4/s;
          //   81: invokevirtual n : ()Landroidx/room/d;
          //   84: aload_0
          //   85: getfield w : Landroidx/room/a$a$a$a$b;
          //   88: invokevirtual c : (Landroidx/room/d$c;)V
          //   91: aload_0
          //   92: getfield x : Ldbxyzptlk/dK/d;
          //   95: invokeinterface iterator : ()Ldbxyzptlk/dK/f;
          //   100: astore_1
          //   101: aload_0
          //   102: aload_1
          //   103: putfield t : Ljava/lang/Object;
          //   106: aload_0
          //   107: iconst_1
          //   108: putfield u : I
          //   111: aload_1
          //   112: aload_0
          //   113: invokeinterface a : (Ldbxyzptlk/tI/d;)Ljava/lang/Object;
          //   118: astore #4
          //   120: aload #4
          //   122: aload #5
          //   124: if_acmpne -> 130
          //   127: aload #5
          //   129: areturn
          //   130: aload_1
          //   131: astore_3
          //   132: aload #4
          //   134: checkcast java/lang/Boolean
          //   137: invokevirtual booleanValue : ()Z
          //   140: ifeq -> 195
          //   143: aload_3
          //   144: invokeinterface next : ()Ljava/lang/Object;
          //   149: pop
          //   150: aload_0
          //   151: getfield y : Ljava/util/concurrent/Callable;
          //   154: invokeinterface call : ()Ljava/lang/Object;
          //   159: astore_1
          //   160: aload_0
          //   161: getfield z : Ldbxyzptlk/dK/d;
          //   164: astore #4
          //   166: aload_0
          //   167: aload_3
          //   168: putfield t : Ljava/lang/Object;
          //   171: aload_0
          //   172: iconst_2
          //   173: putfield u : I
          //   176: aload #4
          //   178: aload_1
          //   179: aload_0
          //   180: invokeinterface F : (Ljava/lang/Object;Ldbxyzptlk/tI/d;)Ljava/lang/Object;
          //   185: astore_1
          //   186: aload_1
          //   187: aload #5
          //   189: if_acmpne -> 36
          //   192: aload #5
          //   194: areturn
          //   195: aload_0
          //   196: getfield v : Ldbxyzptlk/F4/s;
          //   199: invokevirtual n : ()Landroidx/room/d;
          //   202: aload_0
          //   203: getfield w : Landroidx/room/a$a$a$a$b;
          //   206: invokevirtual q : (Landroidx/room/d$c;)V
          //   209: getstatic dbxyzptlk/pI/D.a : Ldbxyzptlk/pI/D;
          //   212: areturn
          //   213: aload_0
          //   214: getfield v : Ldbxyzptlk/F4/s;
          //   217: invokevirtual n : ()Landroidx/room/d;
          //   220: aload_0
          //   221: getfield w : Landroidx/room/a$a$a$a$b;
          //   224: invokevirtual q : (Landroidx/room/d$c;)V
          //   227: aload_1
          //   228: athrow
          // Exception table:
          //   from	to	target	type
          //   32	36	41	finally
          //   63	67	41	finally
          //   91	101	41	finally
          //   101	120	41	finally
          //   132	186	41	finally
        }
      }
      
      @Metadata(d1 = {"\000\033\n\000\n\002\030\002\n\002\020\"\n\002\020\016\n\000\n\002\030\002\n\002\b\003*\001\000\b\n\030\0002\0020\001J\035\020\006\032\0020\0052\f\020\004\032\b\022\004\022\0020\0030\002H\026¢\006\004\b\006\020\007¨\006\b"}, d2 = {"androidx/room/a$a$a$a$b", "Landroidx/room/d$c;", "", "", "tables", "Ldbxyzptlk/pI/D;", "c", "(Ljava/util/Set;)V", "room-ktx_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
      public static final class b extends d.c {
        public final d<D> b;
        
        public b(String[] param3ArrayOfString, d<D> param3d) {
          super(param3ArrayOfString);
        }
        
        public void c(Set<String> param3Set) {
          this.b.k(D.a);
        }
      }
    }
    
    @f(c = "androidx.room.CoroutinesRoom$Companion$createFlow$1$1", f = "CoroutinesRoom.kt", l = {137}, m = "invokeSuspend")
    @Metadata(d1 = {"\000\016\n\000\n\002\030\002\n\002\030\002\n\002\b\002\020\003\032\0020\002\"\004\b\000\020\000*\0020\001H@¢\006\004\b\003\020\004"}, d2 = {"R", "Ldbxyzptlk/bK/J;", "Ldbxyzptlk/pI/D;", "<anonymous>", "(Ldbxyzptlk/bK/J;)V"}, k = 3, mv = {1, 8, 0})
    public static final class a extends l implements p<J, d<? super D>, Object> {
      public int t;
      
      public Object u;
      
      public final boolean v;
      
      public final s w;
      
      public final j<R> x;
      
      public final String[] y;
      
      public final Callable<R> z;
      
      public a(boolean param2Boolean, s param2s, j<R> param2j, String[] param2ArrayOfString, Callable<R> param2Callable, d<? super a> param2d) {
        super(2, param2d);
      }
      
      public final d<D> create(Object param2Object, d<?> param2d) {
        a a1 = new a(this.v, this.w, this.x, this.y, this.z, (d)param2d);
        a1.u = param2Object;
        return (d<D>)a1;
      }
      
      public final Object invoke(J param2J, d<? super D> param2d) {
        return ((a)create(param2J, param2d)).invokeSuspend(D.a);
      }
      
      public final Object invokeSuspend(Object param2Object) {
        // Byte code:
        //   0: invokestatic g : ()Ljava/lang/Object;
        //   3: astore #4
        //   5: aload_0
        //   6: getfield t : I
        //   9: istore_2
        //   10: iload_2
        //   11: ifeq -> 36
        //   14: iload_2
        //   15: iconst_1
        //   16: if_icmpne -> 26
        //   19: aload_1
        //   20: invokestatic b : (Ljava/lang/Object;)V
        //   23: goto -> 211
        //   26: new java/lang/IllegalStateException
        //   29: dup
        //   30: ldc 'call to 'resume' before 'invoke' with coroutine'
        //   32: invokespecial <init> : (Ljava/lang/String;)V
        //   35: athrow
        //   36: aload_1
        //   37: invokestatic b : (Ljava/lang/Object;)V
        //   40: aload_0
        //   41: getfield u : Ljava/lang/Object;
        //   44: checkcast dbxyzptlk/bK/J
        //   47: astore #7
        //   49: iconst_m1
        //   50: aconst_null
        //   51: aconst_null
        //   52: bipush #6
        //   54: aconst_null
        //   55: invokestatic b : (ILdbxyzptlk/dK/a;Ldbxyzptlk/CI/l;ILjava/lang/Object;)Ldbxyzptlk/dK/d;
        //   58: astore #5
        //   60: new androidx/room/a$a$a$a$b
        //   63: dup
        //   64: aload_0
        //   65: getfield y : [Ljava/lang/String;
        //   68: aload #5
        //   70: invokespecial <init> : ([Ljava/lang/String;Ldbxyzptlk/dK/d;)V
        //   73: astore #6
        //   75: aload #5
        //   77: getstatic dbxyzptlk/pI/D.a : Ldbxyzptlk/pI/D;
        //   80: invokeinterface k : (Ljava/lang/Object;)Ljava/lang/Object;
        //   85: pop
        //   86: aload #7
        //   88: invokeinterface getCoroutineContext : ()Ldbxyzptlk/tI/g;
        //   93: getstatic androidx/room/i.c : Landroidx/room/i$a;
        //   96: invokeinterface c : (Ldbxyzptlk/tI/g$c;)Ldbxyzptlk/tI/g$b;
        //   101: checkcast androidx/room/i
        //   104: astore_1
        //   105: aload_1
        //   106: ifnull -> 120
        //   109: aload_1
        //   110: invokevirtual j : ()Ldbxyzptlk/tI/e;
        //   113: astore_3
        //   114: aload_3
        //   115: astore_1
        //   116: aload_3
        //   117: ifnonnull -> 146
        //   120: aload_0
        //   121: getfield v : Z
        //   124: ifeq -> 138
        //   127: aload_0
        //   128: getfield w : Ldbxyzptlk/F4/s;
        //   131: invokestatic b : (Ldbxyzptlk/F4/s;)Ldbxyzptlk/bK/F;
        //   134: astore_1
        //   135: goto -> 146
        //   138: aload_0
        //   139: getfield w : Ldbxyzptlk/F4/s;
        //   142: invokestatic a : (Ldbxyzptlk/F4/s;)Ldbxyzptlk/bK/F;
        //   145: astore_1
        //   146: iconst_0
        //   147: aconst_null
        //   148: aconst_null
        //   149: bipush #7
        //   151: aconst_null
        //   152: invokestatic b : (ILdbxyzptlk/dK/a;Ldbxyzptlk/CI/l;ILjava/lang/Object;)Ldbxyzptlk/dK/d;
        //   155: astore_3
        //   156: aload #7
        //   158: aload_1
        //   159: aconst_null
        //   160: new androidx/room/a$a$a$a$a
        //   163: dup
        //   164: aload_0
        //   165: getfield w : Ldbxyzptlk/F4/s;
        //   168: aload #6
        //   170: aload #5
        //   172: aload_0
        //   173: getfield z : Ljava/util/concurrent/Callable;
        //   176: aload_3
        //   177: aconst_null
        //   178: invokespecial <init> : (Ldbxyzptlk/F4/s;Landroidx/room/a$a$a$a$b;Ldbxyzptlk/dK/d;Ljava/util/concurrent/Callable;Ldbxyzptlk/dK/d;Ldbxyzptlk/tI/d;)V
        //   181: iconst_2
        //   182: aconst_null
        //   183: invokestatic d : (Ldbxyzptlk/bK/J;Ldbxyzptlk/tI/g;Ldbxyzptlk/bK/L;Ldbxyzptlk/CI/p;ILjava/lang/Object;)Ldbxyzptlk/bK/w0;
        //   186: pop
        //   187: aload_0
        //   188: getfield x : Ldbxyzptlk/eK/j;
        //   191: astore_1
        //   192: aload_0
        //   193: iconst_1
        //   194: putfield t : I
        //   197: aload_1
        //   198: aload_3
        //   199: aload_0
        //   200: invokestatic A : (Ldbxyzptlk/eK/j;Ldbxyzptlk/dK/s;Ldbxyzptlk/tI/d;)Ljava/lang/Object;
        //   203: aload #4
        //   205: if_acmpne -> 211
        //   208: aload #4
        //   210: areturn
        //   211: getstatic dbxyzptlk/pI/D.a : Ldbxyzptlk/pI/D;
        //   214: areturn
      }
      
      @f(c = "androidx.room.CoroutinesRoom$Companion$createFlow$1$1$1", f = "CoroutinesRoom.kt", l = {128, 130}, m = "invokeSuspend")
      @Metadata(d1 = {"\000\016\n\000\n\002\030\002\n\002\030\002\n\002\b\002\020\003\032\0020\002\"\004\b\000\020\000*\0020\001H@¢\006\004\b\003\020\004"}, d2 = {"R", "Ldbxyzptlk/bK/J;", "Ldbxyzptlk/pI/D;", "<anonymous>", "(Ldbxyzptlk/bK/J;)V"}, k = 3, mv = {1, 8, 0})
      public static final class a extends l implements p<J, d<? super D>, Object> {
        public Object t;
        
        public int u;
        
        public final s v;
        
        public final a.a.a.a.b w;
        
        public final d<D> x;
        
        public final Callable<R> y;
        
        public final d<R> z;
        
        public a(s param4s, a.a.a.a.b param4b, d<D> param4d1, Callable<R> param4Callable, d<R> param4d2, d param4d) {
          super(2, param4d);
        }
        
        public final d<D> create(Object param4Object, d<?> param4d) {
          return (d<D>)new a(this.v, this.w, this.x, this.y, this.z, param4d);
        }
        
        public final Object invoke(J param4J, d<? super D> param4d) {
          return ((a)create(param4J, param4d)).invokeSuspend(D.a);
        }
        
        public final Object invokeSuspend(Object<R> param4Object) {
          // Byte code:
          //   0: invokestatic g : ()Ljava/lang/Object;
          //   3: astore #5
          //   5: aload_0
          //   6: getfield u : I
          //   9: istore_2
          //   10: iload_2
          //   11: ifeq -> 73
          //   14: iload_2
          //   15: iconst_1
          //   16: if_icmpeq -> 55
          //   19: iload_2
          //   20: iconst_2
          //   21: if_icmpne -> 45
          //   24: aload_0
          //   25: getfield t : Ljava/lang/Object;
          //   28: checkcast dbxyzptlk/dK/f
          //   31: astore_3
          //   32: aload_1
          //   33: invokestatic b : (Ljava/lang/Object;)V
          //   36: aload_3
          //   37: astore_1
          //   38: goto -> 101
          //   41: astore_1
          //   42: goto -> 213
          //   45: new java/lang/IllegalStateException
          //   48: dup
          //   49: ldc 'call to 'resume' before 'invoke' with coroutine'
          //   51: invokespecial <init> : (Ljava/lang/String;)V
          //   54: athrow
          //   55: aload_0
          //   56: getfield t : Ljava/lang/Object;
          //   59: checkcast dbxyzptlk/dK/f
          //   62: astore_3
          //   63: aload_1
          //   64: invokestatic b : (Ljava/lang/Object;)V
          //   67: aload_1
          //   68: astore #4
          //   70: goto -> 132
          //   73: aload_1
          //   74: invokestatic b : (Ljava/lang/Object;)V
          //   77: aload_0
          //   78: getfield v : Ldbxyzptlk/F4/s;
          //   81: invokevirtual n : ()Landroidx/room/d;
          //   84: aload_0
          //   85: getfield w : Landroidx/room/a$a$a$a$b;
          //   88: invokevirtual c : (Landroidx/room/d$c;)V
          //   91: aload_0
          //   92: getfield x : Ldbxyzptlk/dK/d;
          //   95: invokeinterface iterator : ()Ldbxyzptlk/dK/f;
          //   100: astore_1
          //   101: aload_0
          //   102: aload_1
          //   103: putfield t : Ljava/lang/Object;
          //   106: aload_0
          //   107: iconst_1
          //   108: putfield u : I
          //   111: aload_1
          //   112: aload_0
          //   113: invokeinterface a : (Ldbxyzptlk/tI/d;)Ljava/lang/Object;
          //   118: astore #4
          //   120: aload #4
          //   122: aload #5
          //   124: if_acmpne -> 130
          //   127: aload #5
          //   129: areturn
          //   130: aload_1
          //   131: astore_3
          //   132: aload #4
          //   134: checkcast java/lang/Boolean
          //   137: invokevirtual booleanValue : ()Z
          //   140: ifeq -> 195
          //   143: aload_3
          //   144: invokeinterface next : ()Ljava/lang/Object;
          //   149: pop
          //   150: aload_0
          //   151: getfield y : Ljava/util/concurrent/Callable;
          //   154: invokeinterface call : ()Ljava/lang/Object;
          //   159: astore_1
          //   160: aload_0
          //   161: getfield z : Ldbxyzptlk/dK/d;
          //   164: astore #4
          //   166: aload_0
          //   167: aload_3
          //   168: putfield t : Ljava/lang/Object;
          //   171: aload_0
          //   172: iconst_2
          //   173: putfield u : I
          //   176: aload #4
          //   178: aload_1
          //   179: aload_0
          //   180: invokeinterface F : (Ljava/lang/Object;Ldbxyzptlk/tI/d;)Ljava/lang/Object;
          //   185: astore_1
          //   186: aload_1
          //   187: aload #5
          //   189: if_acmpne -> 36
          //   192: aload #5
          //   194: areturn
          //   195: aload_0
          //   196: getfield v : Ldbxyzptlk/F4/s;
          //   199: invokevirtual n : ()Landroidx/room/d;
          //   202: aload_0
          //   203: getfield w : Landroidx/room/a$a$a$a$b;
          //   206: invokevirtual q : (Landroidx/room/d$c;)V
          //   209: getstatic dbxyzptlk/pI/D.a : Ldbxyzptlk/pI/D;
          //   212: areturn
          //   213: aload_0
          //   214: getfield v : Ldbxyzptlk/F4/s;
          //   217: invokevirtual n : ()Landroidx/room/d;
          //   220: aload_0
          //   221: getfield w : Landroidx/room/a$a$a$a$b;
          //   224: invokevirtual q : (Landroidx/room/d$c;)V
          //   227: aload_1
          //   228: athrow
          // Exception table:
          //   from	to	target	type
          //   32	36	41	finally
          //   63	67	41	finally
          //   91	101	41	finally
          //   101	120	41	finally
          //   132	186	41	finally
        }
      }
      
      @Metadata(d1 = {"\000\033\n\000\n\002\030\002\n\002\020\"\n\002\020\016\n\000\n\002\030\002\n\002\b\003*\001\000\b\n\030\0002\0020\001J\035\020\006\032\0020\0052\f\020\004\032\b\022\004\022\0020\0030\002H\026¢\006\004\b\006\020\007¨\006\b"}, d2 = {"androidx/room/a$a$a$a$b", "Landroidx/room/d$c;", "", "", "tables", "Ldbxyzptlk/pI/D;", "c", "(Ljava/util/Set;)V", "room-ktx_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
      public static final class b extends d.c {
        public final d<D> b;
        
        public b(String[] param4ArrayOfString, d<D> param4d) {
          super(param4ArrayOfString);
        }
        
        public void c(Set<String> param4Set) {
          this.b.k(D.a);
        }
      }
    }
    
    @f(c = "androidx.room.CoroutinesRoom$Companion$createFlow$1$1$1", f = "CoroutinesRoom.kt", l = {128, 130}, m = "invokeSuspend")
    @Metadata(d1 = {"\000\016\n\000\n\002\030\002\n\002\030\002\n\002\b\002\020\003\032\0020\002\"\004\b\000\020\000*\0020\001H@¢\006\004\b\003\020\004"}, d2 = {"R", "Ldbxyzptlk/bK/J;", "Ldbxyzptlk/pI/D;", "<anonymous>", "(Ldbxyzptlk/bK/J;)V"}, k = 3, mv = {1, 8, 0})
    public static final class a extends l implements p<J, d<? super D>, Object> {
      public Object t;
      
      public int u;
      
      public final s v;
      
      public final a.a.a.a.b w;
      
      public final d<D> x;
      
      public final Callable<R> y;
      
      public final d<R> z;
      
      public a(s param2s, a.a.a.a.b param2b, d<D> param2d1, Callable<R> param2Callable, d<R> param2d2, d param2d) {
        super(2, param2d);
      }
      
      public final d<D> create(Object param2Object, d<?> param2d) {
        return (d<D>)new a(this.v, this.w, this.x, this.y, this.z, param2d);
      }
      
      public final Object invoke(J param2J, d<? super D> param2d) {
        return ((a)create(param2J, param2d)).invokeSuspend(D.a);
      }
      
      public final Object invokeSuspend(Object<R> param2Object) {
        // Byte code:
        //   0: invokestatic g : ()Ljava/lang/Object;
        //   3: astore #5
        //   5: aload_0
        //   6: getfield u : I
        //   9: istore_2
        //   10: iload_2
        //   11: ifeq -> 73
        //   14: iload_2
        //   15: iconst_1
        //   16: if_icmpeq -> 55
        //   19: iload_2
        //   20: iconst_2
        //   21: if_icmpne -> 45
        //   24: aload_0
        //   25: getfield t : Ljava/lang/Object;
        //   28: checkcast dbxyzptlk/dK/f
        //   31: astore_3
        //   32: aload_1
        //   33: invokestatic b : (Ljava/lang/Object;)V
        //   36: aload_3
        //   37: astore_1
        //   38: goto -> 101
        //   41: astore_1
        //   42: goto -> 213
        //   45: new java/lang/IllegalStateException
        //   48: dup
        //   49: ldc 'call to 'resume' before 'invoke' with coroutine'
        //   51: invokespecial <init> : (Ljava/lang/String;)V
        //   54: athrow
        //   55: aload_0
        //   56: getfield t : Ljava/lang/Object;
        //   59: checkcast dbxyzptlk/dK/f
        //   62: astore_3
        //   63: aload_1
        //   64: invokestatic b : (Ljava/lang/Object;)V
        //   67: aload_1
        //   68: astore #4
        //   70: goto -> 132
        //   73: aload_1
        //   74: invokestatic b : (Ljava/lang/Object;)V
        //   77: aload_0
        //   78: getfield v : Ldbxyzptlk/F4/s;
        //   81: invokevirtual n : ()Landroidx/room/d;
        //   84: aload_0
        //   85: getfield w : Landroidx/room/a$a$a$a$b;
        //   88: invokevirtual c : (Landroidx/room/d$c;)V
        //   91: aload_0
        //   92: getfield x : Ldbxyzptlk/dK/d;
        //   95: invokeinterface iterator : ()Ldbxyzptlk/dK/f;
        //   100: astore_1
        //   101: aload_0
        //   102: aload_1
        //   103: putfield t : Ljava/lang/Object;
        //   106: aload_0
        //   107: iconst_1
        //   108: putfield u : I
        //   111: aload_1
        //   112: aload_0
        //   113: invokeinterface a : (Ldbxyzptlk/tI/d;)Ljava/lang/Object;
        //   118: astore #4
        //   120: aload #4
        //   122: aload #5
        //   124: if_acmpne -> 130
        //   127: aload #5
        //   129: areturn
        //   130: aload_1
        //   131: astore_3
        //   132: aload #4
        //   134: checkcast java/lang/Boolean
        //   137: invokevirtual booleanValue : ()Z
        //   140: ifeq -> 195
        //   143: aload_3
        //   144: invokeinterface next : ()Ljava/lang/Object;
        //   149: pop
        //   150: aload_0
        //   151: getfield y : Ljava/util/concurrent/Callable;
        //   154: invokeinterface call : ()Ljava/lang/Object;
        //   159: astore_1
        //   160: aload_0
        //   161: getfield z : Ldbxyzptlk/dK/d;
        //   164: astore #4
        //   166: aload_0
        //   167: aload_3
        //   168: putfield t : Ljava/lang/Object;
        //   171: aload_0
        //   172: iconst_2
        //   173: putfield u : I
        //   176: aload #4
        //   178: aload_1
        //   179: aload_0
        //   180: invokeinterface F : (Ljava/lang/Object;Ldbxyzptlk/tI/d;)Ljava/lang/Object;
        //   185: astore_1
        //   186: aload_1
        //   187: aload #5
        //   189: if_acmpne -> 36
        //   192: aload #5
        //   194: areturn
        //   195: aload_0
        //   196: getfield v : Ldbxyzptlk/F4/s;
        //   199: invokevirtual n : ()Landroidx/room/d;
        //   202: aload_0
        //   203: getfield w : Landroidx/room/a$a$a$a$b;
        //   206: invokevirtual q : (Landroidx/room/d$c;)V
        //   209: getstatic dbxyzptlk/pI/D.a : Ldbxyzptlk/pI/D;
        //   212: areturn
        //   213: aload_0
        //   214: getfield v : Ldbxyzptlk/F4/s;
        //   217: invokevirtual n : ()Landroidx/room/d;
        //   220: aload_0
        //   221: getfield w : Landroidx/room/a$a$a$a$b;
        //   224: invokevirtual q : (Landroidx/room/d$c;)V
        //   227: aload_1
        //   228: athrow
        // Exception table:
        //   from	to	target	type
        //   32	36	41	finally
        //   63	67	41	finally
        //   91	101	41	finally
        //   101	120	41	finally
        //   132	186	41	finally
      }
    }
    
    @Metadata(d1 = {"\000\033\n\000\n\002\030\002\n\002\020\"\n\002\020\016\n\000\n\002\030\002\n\002\b\003*\001\000\b\n\030\0002\0020\001J\035\020\006\032\0020\0052\f\020\004\032\b\022\004\022\0020\0030\002H\026¢\006\004\b\006\020\007¨\006\b"}, d2 = {"androidx/room/a$a$a$a$b", "Landroidx/room/d$c;", "", "", "tables", "Ldbxyzptlk/pI/D;", "c", "(Ljava/util/Set;)V", "room-ktx_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
    public static final class b extends d.c {
      public final d<D> b;
      
      public b(String[] param2ArrayOfString, d<D> param2d) {
        super(param2ArrayOfString);
      }
      
      public void c(Set<String> param2Set) {
        this.b.k(D.a);
      }
    }
  }
  
  @f(c = "androidx.room.CoroutinesRoom$Companion$createFlow$1", f = "CoroutinesRoom.kt", l = {111}, m = "invokeSuspend")
  @Metadata(d1 = {"\000\016\n\000\n\002\030\002\n\002\030\002\n\002\b\002\020\003\032\0020\002\"\004\b\000\020\000*\b\022\004\022\0028\0000\001H@¢\006\004\b\003\020\004"}, d2 = {"R", "Ldbxyzptlk/eK/j;", "Ldbxyzptlk/pI/D;", "<anonymous>", "(Ldbxyzptlk/eK/j;)V"}, k = 3, mv = {1, 8, 0})
  public static final class a extends l implements p<j<R>, d<? super D>, Object> {
    public int t;
    
    public Object u;
    
    public final boolean v;
    
    public final s w;
    
    public final String[] x;
    
    public final Callable<R> y;
    
    public a(boolean param1Boolean, s param1s, String[] param1ArrayOfString, Callable<R> param1Callable, d<? super a> param1d) {
      super(2, param1d);
    }
    
    public final Object a(j<R> param1j, d<? super D> param1d) {
      return ((a)create(param1j, param1d)).invokeSuspend(D.a);
    }
    
    public final d<D> create(Object param1Object, d<?> param1d) {
      a a1 = new a(this.v, this.w, this.x, this.y, (d)param1d);
      a1.u = param1Object;
      return (d<D>)a1;
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = c.g();
      int i = this.t;
      if (i != 0) {
        if (i == 1) {
          p.b(param1Object);
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        p.b(param1Object);
        param1Object = this.u;
        param1Object = new a(this.v, this.w, (j<R>)param1Object, this.x, this.y, null);
        this.t = 1;
        if (K.g((p)param1Object, (d)this) == object)
          return object; 
      } 
      return D.a;
    }
    
    @f(c = "androidx.room.CoroutinesRoom$Companion$createFlow$1$1", f = "CoroutinesRoom.kt", l = {137}, m = "invokeSuspend")
    @Metadata(d1 = {"\000\016\n\000\n\002\030\002\n\002\030\002\n\002\b\002\020\003\032\0020\002\"\004\b\000\020\000*\0020\001H@¢\006\004\b\003\020\004"}, d2 = {"R", "Ldbxyzptlk/bK/J;", "Ldbxyzptlk/pI/D;", "<anonymous>", "(Ldbxyzptlk/bK/J;)V"}, k = 3, mv = {1, 8, 0})
    public static final class a extends l implements p<J, d<? super D>, Object> {
      public int t;
      
      public Object u;
      
      public final boolean v;
      
      public final s w;
      
      public final j<R> x;
      
      public final String[] y;
      
      public final Callable<R> z;
      
      public a(boolean param3Boolean, s param3s, j<R> param3j, String[] param3ArrayOfString, Callable<R> param3Callable, d<? super a> param3d) {
        super(2, param3d);
      }
      
      public final d<D> create(Object param3Object, d<?> param3d) {
        a a1 = new a(this.v, this.w, this.x, this.y, this.z, (d)param3d);
        a1.u = param3Object;
        return (d<D>)a1;
      }
      
      public final Object invoke(J param3J, d<? super D> param3d) {
        return ((a)create(param3J, param3d)).invokeSuspend(D.a);
      }
      
      public final Object invokeSuspend(Object param3Object) {
        // Byte code:
        //   0: invokestatic g : ()Ljava/lang/Object;
        //   3: astore #4
        //   5: aload_0
        //   6: getfield t : I
        //   9: istore_2
        //   10: iload_2
        //   11: ifeq -> 36
        //   14: iload_2
        //   15: iconst_1
        //   16: if_icmpne -> 26
        //   19: aload_1
        //   20: invokestatic b : (Ljava/lang/Object;)V
        //   23: goto -> 211
        //   26: new java/lang/IllegalStateException
        //   29: dup
        //   30: ldc 'call to 'resume' before 'invoke' with coroutine'
        //   32: invokespecial <init> : (Ljava/lang/String;)V
        //   35: athrow
        //   36: aload_1
        //   37: invokestatic b : (Ljava/lang/Object;)V
        //   40: aload_0
        //   41: getfield u : Ljava/lang/Object;
        //   44: checkcast dbxyzptlk/bK/J
        //   47: astore #7
        //   49: iconst_m1
        //   50: aconst_null
        //   51: aconst_null
        //   52: bipush #6
        //   54: aconst_null
        //   55: invokestatic b : (ILdbxyzptlk/dK/a;Ldbxyzptlk/CI/l;ILjava/lang/Object;)Ldbxyzptlk/dK/d;
        //   58: astore #5
        //   60: new androidx/room/a$a$a$a$b
        //   63: dup
        //   64: aload_0
        //   65: getfield y : [Ljava/lang/String;
        //   68: aload #5
        //   70: invokespecial <init> : ([Ljava/lang/String;Ldbxyzptlk/dK/d;)V
        //   73: astore #6
        //   75: aload #5
        //   77: getstatic dbxyzptlk/pI/D.a : Ldbxyzptlk/pI/D;
        //   80: invokeinterface k : (Ljava/lang/Object;)Ljava/lang/Object;
        //   85: pop
        //   86: aload #7
        //   88: invokeinterface getCoroutineContext : ()Ldbxyzptlk/tI/g;
        //   93: getstatic androidx/room/i.c : Landroidx/room/i$a;
        //   96: invokeinterface c : (Ldbxyzptlk/tI/g$c;)Ldbxyzptlk/tI/g$b;
        //   101: checkcast androidx/room/i
        //   104: astore_1
        //   105: aload_1
        //   106: ifnull -> 120
        //   109: aload_1
        //   110: invokevirtual j : ()Ldbxyzptlk/tI/e;
        //   113: astore_3
        //   114: aload_3
        //   115: astore_1
        //   116: aload_3
        //   117: ifnonnull -> 146
        //   120: aload_0
        //   121: getfield v : Z
        //   124: ifeq -> 138
        //   127: aload_0
        //   128: getfield w : Ldbxyzptlk/F4/s;
        //   131: invokestatic b : (Ldbxyzptlk/F4/s;)Ldbxyzptlk/bK/F;
        //   134: astore_1
        //   135: goto -> 146
        //   138: aload_0
        //   139: getfield w : Ldbxyzptlk/F4/s;
        //   142: invokestatic a : (Ldbxyzptlk/F4/s;)Ldbxyzptlk/bK/F;
        //   145: astore_1
        //   146: iconst_0
        //   147: aconst_null
        //   148: aconst_null
        //   149: bipush #7
        //   151: aconst_null
        //   152: invokestatic b : (ILdbxyzptlk/dK/a;Ldbxyzptlk/CI/l;ILjava/lang/Object;)Ldbxyzptlk/dK/d;
        //   155: astore_3
        //   156: aload #7
        //   158: aload_1
        //   159: aconst_null
        //   160: new androidx/room/a$a$a$a$a
        //   163: dup
        //   164: aload_0
        //   165: getfield w : Ldbxyzptlk/F4/s;
        //   168: aload #6
        //   170: aload #5
        //   172: aload_0
        //   173: getfield z : Ljava/util/concurrent/Callable;
        //   176: aload_3
        //   177: aconst_null
        //   178: invokespecial <init> : (Ldbxyzptlk/F4/s;Landroidx/room/a$a$a$a$b;Ldbxyzptlk/dK/d;Ljava/util/concurrent/Callable;Ldbxyzptlk/dK/d;Ldbxyzptlk/tI/d;)V
        //   181: iconst_2
        //   182: aconst_null
        //   183: invokestatic d : (Ldbxyzptlk/bK/J;Ldbxyzptlk/tI/g;Ldbxyzptlk/bK/L;Ldbxyzptlk/CI/p;ILjava/lang/Object;)Ldbxyzptlk/bK/w0;
        //   186: pop
        //   187: aload_0
        //   188: getfield x : Ldbxyzptlk/eK/j;
        //   191: astore_1
        //   192: aload_0
        //   193: iconst_1
        //   194: putfield t : I
        //   197: aload_1
        //   198: aload_3
        //   199: aload_0
        //   200: invokestatic A : (Ldbxyzptlk/eK/j;Ldbxyzptlk/dK/s;Ldbxyzptlk/tI/d;)Ljava/lang/Object;
        //   203: aload #4
        //   205: if_acmpne -> 211
        //   208: aload #4
        //   210: areturn
        //   211: getstatic dbxyzptlk/pI/D.a : Ldbxyzptlk/pI/D;
        //   214: areturn
      }
      
      @f(c = "androidx.room.CoroutinesRoom$Companion$createFlow$1$1$1", f = "CoroutinesRoom.kt", l = {128, 130}, m = "invokeSuspend")
      @Metadata(d1 = {"\000\016\n\000\n\002\030\002\n\002\030\002\n\002\b\002\020\003\032\0020\002\"\004\b\000\020\000*\0020\001H@¢\006\004\b\003\020\004"}, d2 = {"R", "Ldbxyzptlk/bK/J;", "Ldbxyzptlk/pI/D;", "<anonymous>", "(Ldbxyzptlk/bK/J;)V"}, k = 3, mv = {1, 8, 0})
      public static final class a extends l implements p<J, d<? super D>, Object> {
        public Object t;
        
        public int u;
        
        public final s v;
        
        public final a.a.a.a.b w;
        
        public final d<D> x;
        
        public final Callable<R> y;
        
        public final d<R> z;
        
        public a(s param4s, a.a.a.a.b param4b, d<D> param4d1, Callable<R> param4Callable, d<R> param4d2, d param4d) {
          super(2, param4d);
        }
        
        public final d<D> create(Object param4Object, d<?> param4d) {
          return (d<D>)new a(this.v, this.w, this.x, this.y, this.z, param4d);
        }
        
        public final Object invoke(J param4J, d<? super D> param4d) {
          return ((a)create(param4J, param4d)).invokeSuspend(D.a);
        }
        
        public final Object invokeSuspend(Object<R> param4Object) {
          // Byte code:
          //   0: invokestatic g : ()Ljava/lang/Object;
          //   3: astore #5
          //   5: aload_0
          //   6: getfield u : I
          //   9: istore_2
          //   10: iload_2
          //   11: ifeq -> 73
          //   14: iload_2
          //   15: iconst_1
          //   16: if_icmpeq -> 55
          //   19: iload_2
          //   20: iconst_2
          //   21: if_icmpne -> 45
          //   24: aload_0
          //   25: getfield t : Ljava/lang/Object;
          //   28: checkcast dbxyzptlk/dK/f
          //   31: astore_3
          //   32: aload_1
          //   33: invokestatic b : (Ljava/lang/Object;)V
          //   36: aload_3
          //   37: astore_1
          //   38: goto -> 101
          //   41: astore_1
          //   42: goto -> 213
          //   45: new java/lang/IllegalStateException
          //   48: dup
          //   49: ldc 'call to 'resume' before 'invoke' with coroutine'
          //   51: invokespecial <init> : (Ljava/lang/String;)V
          //   54: athrow
          //   55: aload_0
          //   56: getfield t : Ljava/lang/Object;
          //   59: checkcast dbxyzptlk/dK/f
          //   62: astore_3
          //   63: aload_1
          //   64: invokestatic b : (Ljava/lang/Object;)V
          //   67: aload_1
          //   68: astore #4
          //   70: goto -> 132
          //   73: aload_1
          //   74: invokestatic b : (Ljava/lang/Object;)V
          //   77: aload_0
          //   78: getfield v : Ldbxyzptlk/F4/s;
          //   81: invokevirtual n : ()Landroidx/room/d;
          //   84: aload_0
          //   85: getfield w : Landroidx/room/a$a$a$a$b;
          //   88: invokevirtual c : (Landroidx/room/d$c;)V
          //   91: aload_0
          //   92: getfield x : Ldbxyzptlk/dK/d;
          //   95: invokeinterface iterator : ()Ldbxyzptlk/dK/f;
          //   100: astore_1
          //   101: aload_0
          //   102: aload_1
          //   103: putfield t : Ljava/lang/Object;
          //   106: aload_0
          //   107: iconst_1
          //   108: putfield u : I
          //   111: aload_1
          //   112: aload_0
          //   113: invokeinterface a : (Ldbxyzptlk/tI/d;)Ljava/lang/Object;
          //   118: astore #4
          //   120: aload #4
          //   122: aload #5
          //   124: if_acmpne -> 130
          //   127: aload #5
          //   129: areturn
          //   130: aload_1
          //   131: astore_3
          //   132: aload #4
          //   134: checkcast java/lang/Boolean
          //   137: invokevirtual booleanValue : ()Z
          //   140: ifeq -> 195
          //   143: aload_3
          //   144: invokeinterface next : ()Ljava/lang/Object;
          //   149: pop
          //   150: aload_0
          //   151: getfield y : Ljava/util/concurrent/Callable;
          //   154: invokeinterface call : ()Ljava/lang/Object;
          //   159: astore_1
          //   160: aload_0
          //   161: getfield z : Ldbxyzptlk/dK/d;
          //   164: astore #4
          //   166: aload_0
          //   167: aload_3
          //   168: putfield t : Ljava/lang/Object;
          //   171: aload_0
          //   172: iconst_2
          //   173: putfield u : I
          //   176: aload #4
          //   178: aload_1
          //   179: aload_0
          //   180: invokeinterface F : (Ljava/lang/Object;Ldbxyzptlk/tI/d;)Ljava/lang/Object;
          //   185: astore_1
          //   186: aload_1
          //   187: aload #5
          //   189: if_acmpne -> 36
          //   192: aload #5
          //   194: areturn
          //   195: aload_0
          //   196: getfield v : Ldbxyzptlk/F4/s;
          //   199: invokevirtual n : ()Landroidx/room/d;
          //   202: aload_0
          //   203: getfield w : Landroidx/room/a$a$a$a$b;
          //   206: invokevirtual q : (Landroidx/room/d$c;)V
          //   209: getstatic dbxyzptlk/pI/D.a : Ldbxyzptlk/pI/D;
          //   212: areturn
          //   213: aload_0
          //   214: getfield v : Ldbxyzptlk/F4/s;
          //   217: invokevirtual n : ()Landroidx/room/d;
          //   220: aload_0
          //   221: getfield w : Landroidx/room/a$a$a$a$b;
          //   224: invokevirtual q : (Landroidx/room/d$c;)V
          //   227: aload_1
          //   228: athrow
          // Exception table:
          //   from	to	target	type
          //   32	36	41	finally
          //   63	67	41	finally
          //   91	101	41	finally
          //   101	120	41	finally
          //   132	186	41	finally
        }
      }
      
      @Metadata(d1 = {"\000\033\n\000\n\002\030\002\n\002\020\"\n\002\020\016\n\000\n\002\030\002\n\002\b\003*\001\000\b\n\030\0002\0020\001J\035\020\006\032\0020\0052\f\020\004\032\b\022\004\022\0020\0030\002H\026¢\006\004\b\006\020\007¨\006\b"}, d2 = {"androidx/room/a$a$a$a$b", "Landroidx/room/d$c;", "", "", "tables", "Ldbxyzptlk/pI/D;", "c", "(Ljava/util/Set;)V", "room-ktx_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
      public static final class b extends d.c {
        public final d<D> b;
        
        public b(String[] param4ArrayOfString, d<D> param4d) {
          super(param4ArrayOfString);
        }
        
        public void c(Set<String> param4Set) {
          this.b.k(D.a);
        }
      }
    }
    
    @f(c = "androidx.room.CoroutinesRoom$Companion$createFlow$1$1$1", f = "CoroutinesRoom.kt", l = {128, 130}, m = "invokeSuspend")
    @Metadata(d1 = {"\000\016\n\000\n\002\030\002\n\002\030\002\n\002\b\002\020\003\032\0020\002\"\004\b\000\020\000*\0020\001H@¢\006\004\b\003\020\004"}, d2 = {"R", "Ldbxyzptlk/bK/J;", "Ldbxyzptlk/pI/D;", "<anonymous>", "(Ldbxyzptlk/bK/J;)V"}, k = 3, mv = {1, 8, 0})
    public static final class a extends l implements p<J, d<? super D>, Object> {
      public Object t;
      
      public int u;
      
      public final s v;
      
      public final a.a.a.a.b w;
      
      public final d<D> x;
      
      public final Callable<R> y;
      
      public final d<R> z;
      
      public a(s param3s, a.a.a.a.b param3b, d<D> param3d1, Callable<R> param3Callable, d<R> param3d2, d param3d) {
        super(2, param3d);
      }
      
      public final d<D> create(Object param3Object, d<?> param3d) {
        return (d<D>)new a(this.v, this.w, this.x, this.y, this.z, param3d);
      }
      
      public final Object invoke(J param3J, d<? super D> param3d) {
        return ((a)create(param3J, param3d)).invokeSuspend(D.a);
      }
      
      public final Object invokeSuspend(Object<R> param3Object) {
        // Byte code:
        //   0: invokestatic g : ()Ljava/lang/Object;
        //   3: astore #5
        //   5: aload_0
        //   6: getfield u : I
        //   9: istore_2
        //   10: iload_2
        //   11: ifeq -> 73
        //   14: iload_2
        //   15: iconst_1
        //   16: if_icmpeq -> 55
        //   19: iload_2
        //   20: iconst_2
        //   21: if_icmpne -> 45
        //   24: aload_0
        //   25: getfield t : Ljava/lang/Object;
        //   28: checkcast dbxyzptlk/dK/f
        //   31: astore_3
        //   32: aload_1
        //   33: invokestatic b : (Ljava/lang/Object;)V
        //   36: aload_3
        //   37: astore_1
        //   38: goto -> 101
        //   41: astore_1
        //   42: goto -> 213
        //   45: new java/lang/IllegalStateException
        //   48: dup
        //   49: ldc 'call to 'resume' before 'invoke' with coroutine'
        //   51: invokespecial <init> : (Ljava/lang/String;)V
        //   54: athrow
        //   55: aload_0
        //   56: getfield t : Ljava/lang/Object;
        //   59: checkcast dbxyzptlk/dK/f
        //   62: astore_3
        //   63: aload_1
        //   64: invokestatic b : (Ljava/lang/Object;)V
        //   67: aload_1
        //   68: astore #4
        //   70: goto -> 132
        //   73: aload_1
        //   74: invokestatic b : (Ljava/lang/Object;)V
        //   77: aload_0
        //   78: getfield v : Ldbxyzptlk/F4/s;
        //   81: invokevirtual n : ()Landroidx/room/d;
        //   84: aload_0
        //   85: getfield w : Landroidx/room/a$a$a$a$b;
        //   88: invokevirtual c : (Landroidx/room/d$c;)V
        //   91: aload_0
        //   92: getfield x : Ldbxyzptlk/dK/d;
        //   95: invokeinterface iterator : ()Ldbxyzptlk/dK/f;
        //   100: astore_1
        //   101: aload_0
        //   102: aload_1
        //   103: putfield t : Ljava/lang/Object;
        //   106: aload_0
        //   107: iconst_1
        //   108: putfield u : I
        //   111: aload_1
        //   112: aload_0
        //   113: invokeinterface a : (Ldbxyzptlk/tI/d;)Ljava/lang/Object;
        //   118: astore #4
        //   120: aload #4
        //   122: aload #5
        //   124: if_acmpne -> 130
        //   127: aload #5
        //   129: areturn
        //   130: aload_1
        //   131: astore_3
        //   132: aload #4
        //   134: checkcast java/lang/Boolean
        //   137: invokevirtual booleanValue : ()Z
        //   140: ifeq -> 195
        //   143: aload_3
        //   144: invokeinterface next : ()Ljava/lang/Object;
        //   149: pop
        //   150: aload_0
        //   151: getfield y : Ljava/util/concurrent/Callable;
        //   154: invokeinterface call : ()Ljava/lang/Object;
        //   159: astore_1
        //   160: aload_0
        //   161: getfield z : Ldbxyzptlk/dK/d;
        //   164: astore #4
        //   166: aload_0
        //   167: aload_3
        //   168: putfield t : Ljava/lang/Object;
        //   171: aload_0
        //   172: iconst_2
        //   173: putfield u : I
        //   176: aload #4
        //   178: aload_1
        //   179: aload_0
        //   180: invokeinterface F : (Ljava/lang/Object;Ldbxyzptlk/tI/d;)Ljava/lang/Object;
        //   185: astore_1
        //   186: aload_1
        //   187: aload #5
        //   189: if_acmpne -> 36
        //   192: aload #5
        //   194: areturn
        //   195: aload_0
        //   196: getfield v : Ldbxyzptlk/F4/s;
        //   199: invokevirtual n : ()Landroidx/room/d;
        //   202: aload_0
        //   203: getfield w : Landroidx/room/a$a$a$a$b;
        //   206: invokevirtual q : (Landroidx/room/d$c;)V
        //   209: getstatic dbxyzptlk/pI/D.a : Ldbxyzptlk/pI/D;
        //   212: areturn
        //   213: aload_0
        //   214: getfield v : Ldbxyzptlk/F4/s;
        //   217: invokevirtual n : ()Landroidx/room/d;
        //   220: aload_0
        //   221: getfield w : Landroidx/room/a$a$a$a$b;
        //   224: invokevirtual q : (Landroidx/room/d$c;)V
        //   227: aload_1
        //   228: athrow
        // Exception table:
        //   from	to	target	type
        //   32	36	41	finally
        //   63	67	41	finally
        //   91	101	41	finally
        //   101	120	41	finally
        //   132	186	41	finally
      }
    }
    
    @Metadata(d1 = {"\000\033\n\000\n\002\030\002\n\002\020\"\n\002\020\016\n\000\n\002\030\002\n\002\b\003*\001\000\b\n\030\0002\0020\001J\035\020\006\032\0020\0052\f\020\004\032\b\022\004\022\0020\0030\002H\026¢\006\004\b\006\020\007¨\006\b"}, d2 = {"androidx/room/a$a$a$a$b", "Landroidx/room/d$c;", "", "", "tables", "Ldbxyzptlk/pI/D;", "c", "(Ljava/util/Set;)V", "room-ktx_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
    public static final class b extends d.c {
      public final d<D> b;
      
      public b(String[] param3ArrayOfString, d<D> param3d) {
        super(param3ArrayOfString);
      }
      
      public void c(Set<String> param3Set) {
        this.b.k(D.a);
      }
    }
  }
  
  @f(c = "androidx.room.CoroutinesRoom$Companion$createFlow$1$1", f = "CoroutinesRoom.kt", l = {137}, m = "invokeSuspend")
  @Metadata(d1 = {"\000\016\n\000\n\002\030\002\n\002\030\002\n\002\b\002\020\003\032\0020\002\"\004\b\000\020\000*\0020\001H@¢\006\004\b\003\020\004"}, d2 = {"R", "Ldbxyzptlk/bK/J;", "Ldbxyzptlk/pI/D;", "<anonymous>", "(Ldbxyzptlk/bK/J;)V"}, k = 3, mv = {1, 8, 0})
  public static final class a extends l implements p<J, d<? super D>, Object> {
    public int t;
    
    public Object u;
    
    public final boolean v;
    
    public final s w;
    
    public final j<R> x;
    
    public final String[] y;
    
    public final Callable<R> z;
    
    public a(boolean param1Boolean, s param1s, j<R> param1j, String[] param1ArrayOfString, Callable<R> param1Callable, d<? super a> param1d) {
      super(2, param1d);
    }
    
    public final d<D> create(Object param1Object, d<?> param1d) {
      a a1 = new a(this.v, this.w, this.x, this.y, this.z, (d)param1d);
      a1.u = param1Object;
      return (d<D>)a1;
    }
    
    public final Object invoke(J param1J, d<? super D> param1d) {
      return ((a)create(param1J, param1d)).invokeSuspend(D.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      // Byte code:
      //   0: invokestatic g : ()Ljava/lang/Object;
      //   3: astore #4
      //   5: aload_0
      //   6: getfield t : I
      //   9: istore_2
      //   10: iload_2
      //   11: ifeq -> 36
      //   14: iload_2
      //   15: iconst_1
      //   16: if_icmpne -> 26
      //   19: aload_1
      //   20: invokestatic b : (Ljava/lang/Object;)V
      //   23: goto -> 211
      //   26: new java/lang/IllegalStateException
      //   29: dup
      //   30: ldc 'call to 'resume' before 'invoke' with coroutine'
      //   32: invokespecial <init> : (Ljava/lang/String;)V
      //   35: athrow
      //   36: aload_1
      //   37: invokestatic b : (Ljava/lang/Object;)V
      //   40: aload_0
      //   41: getfield u : Ljava/lang/Object;
      //   44: checkcast dbxyzptlk/bK/J
      //   47: astore #7
      //   49: iconst_m1
      //   50: aconst_null
      //   51: aconst_null
      //   52: bipush #6
      //   54: aconst_null
      //   55: invokestatic b : (ILdbxyzptlk/dK/a;Ldbxyzptlk/CI/l;ILjava/lang/Object;)Ldbxyzptlk/dK/d;
      //   58: astore #5
      //   60: new androidx/room/a$a$a$a$b
      //   63: dup
      //   64: aload_0
      //   65: getfield y : [Ljava/lang/String;
      //   68: aload #5
      //   70: invokespecial <init> : ([Ljava/lang/String;Ldbxyzptlk/dK/d;)V
      //   73: astore #6
      //   75: aload #5
      //   77: getstatic dbxyzptlk/pI/D.a : Ldbxyzptlk/pI/D;
      //   80: invokeinterface k : (Ljava/lang/Object;)Ljava/lang/Object;
      //   85: pop
      //   86: aload #7
      //   88: invokeinterface getCoroutineContext : ()Ldbxyzptlk/tI/g;
      //   93: getstatic androidx/room/i.c : Landroidx/room/i$a;
      //   96: invokeinterface c : (Ldbxyzptlk/tI/g$c;)Ldbxyzptlk/tI/g$b;
      //   101: checkcast androidx/room/i
      //   104: astore_1
      //   105: aload_1
      //   106: ifnull -> 120
      //   109: aload_1
      //   110: invokevirtual j : ()Ldbxyzptlk/tI/e;
      //   113: astore_3
      //   114: aload_3
      //   115: astore_1
      //   116: aload_3
      //   117: ifnonnull -> 146
      //   120: aload_0
      //   121: getfield v : Z
      //   124: ifeq -> 138
      //   127: aload_0
      //   128: getfield w : Ldbxyzptlk/F4/s;
      //   131: invokestatic b : (Ldbxyzptlk/F4/s;)Ldbxyzptlk/bK/F;
      //   134: astore_1
      //   135: goto -> 146
      //   138: aload_0
      //   139: getfield w : Ldbxyzptlk/F4/s;
      //   142: invokestatic a : (Ldbxyzptlk/F4/s;)Ldbxyzptlk/bK/F;
      //   145: astore_1
      //   146: iconst_0
      //   147: aconst_null
      //   148: aconst_null
      //   149: bipush #7
      //   151: aconst_null
      //   152: invokestatic b : (ILdbxyzptlk/dK/a;Ldbxyzptlk/CI/l;ILjava/lang/Object;)Ldbxyzptlk/dK/d;
      //   155: astore_3
      //   156: aload #7
      //   158: aload_1
      //   159: aconst_null
      //   160: new androidx/room/a$a$a$a$a
      //   163: dup
      //   164: aload_0
      //   165: getfield w : Ldbxyzptlk/F4/s;
      //   168: aload #6
      //   170: aload #5
      //   172: aload_0
      //   173: getfield z : Ljava/util/concurrent/Callable;
      //   176: aload_3
      //   177: aconst_null
      //   178: invokespecial <init> : (Ldbxyzptlk/F4/s;Landroidx/room/a$a$a$a$b;Ldbxyzptlk/dK/d;Ljava/util/concurrent/Callable;Ldbxyzptlk/dK/d;Ldbxyzptlk/tI/d;)V
      //   181: iconst_2
      //   182: aconst_null
      //   183: invokestatic d : (Ldbxyzptlk/bK/J;Ldbxyzptlk/tI/g;Ldbxyzptlk/bK/L;Ldbxyzptlk/CI/p;ILjava/lang/Object;)Ldbxyzptlk/bK/w0;
      //   186: pop
      //   187: aload_0
      //   188: getfield x : Ldbxyzptlk/eK/j;
      //   191: astore_1
      //   192: aload_0
      //   193: iconst_1
      //   194: putfield t : I
      //   197: aload_1
      //   198: aload_3
      //   199: aload_0
      //   200: invokestatic A : (Ldbxyzptlk/eK/j;Ldbxyzptlk/dK/s;Ldbxyzptlk/tI/d;)Ljava/lang/Object;
      //   203: aload #4
      //   205: if_acmpne -> 211
      //   208: aload #4
      //   210: areturn
      //   211: getstatic dbxyzptlk/pI/D.a : Ldbxyzptlk/pI/D;
      //   214: areturn
    }
    
    @f(c = "androidx.room.CoroutinesRoom$Companion$createFlow$1$1$1", f = "CoroutinesRoom.kt", l = {128, 130}, m = "invokeSuspend")
    @Metadata(d1 = {"\000\016\n\000\n\002\030\002\n\002\030\002\n\002\b\002\020\003\032\0020\002\"\004\b\000\020\000*\0020\001H@¢\006\004\b\003\020\004"}, d2 = {"R", "Ldbxyzptlk/bK/J;", "Ldbxyzptlk/pI/D;", "<anonymous>", "(Ldbxyzptlk/bK/J;)V"}, k = 3, mv = {1, 8, 0})
    public static final class a extends l implements p<J, d<? super D>, Object> {
      public Object t;
      
      public int u;
      
      public final s v;
      
      public final a.a.a.a.b w;
      
      public final d<D> x;
      
      public final Callable<R> y;
      
      public final d<R> z;
      
      public a(s param4s, a.a.a.a.b param4b, d<D> param4d1, Callable<R> param4Callable, d<R> param4d2, d param4d) {
        super(2, param4d);
      }
      
      public final d<D> create(Object param4Object, d<?> param4d) {
        return (d<D>)new a(this.v, this.w, this.x, this.y, this.z, param4d);
      }
      
      public final Object invoke(J param4J, d<? super D> param4d) {
        return ((a)create(param4J, param4d)).invokeSuspend(D.a);
      }
      
      public final Object invokeSuspend(Object<R> param4Object) {
        // Byte code:
        //   0: invokestatic g : ()Ljava/lang/Object;
        //   3: astore #5
        //   5: aload_0
        //   6: getfield u : I
        //   9: istore_2
        //   10: iload_2
        //   11: ifeq -> 73
        //   14: iload_2
        //   15: iconst_1
        //   16: if_icmpeq -> 55
        //   19: iload_2
        //   20: iconst_2
        //   21: if_icmpne -> 45
        //   24: aload_0
        //   25: getfield t : Ljava/lang/Object;
        //   28: checkcast dbxyzptlk/dK/f
        //   31: astore_3
        //   32: aload_1
        //   33: invokestatic b : (Ljava/lang/Object;)V
        //   36: aload_3
        //   37: astore_1
        //   38: goto -> 101
        //   41: astore_1
        //   42: goto -> 213
        //   45: new java/lang/IllegalStateException
        //   48: dup
        //   49: ldc 'call to 'resume' before 'invoke' with coroutine'
        //   51: invokespecial <init> : (Ljava/lang/String;)V
        //   54: athrow
        //   55: aload_0
        //   56: getfield t : Ljava/lang/Object;
        //   59: checkcast dbxyzptlk/dK/f
        //   62: astore_3
        //   63: aload_1
        //   64: invokestatic b : (Ljava/lang/Object;)V
        //   67: aload_1
        //   68: astore #4
        //   70: goto -> 132
        //   73: aload_1
        //   74: invokestatic b : (Ljava/lang/Object;)V
        //   77: aload_0
        //   78: getfield v : Ldbxyzptlk/F4/s;
        //   81: invokevirtual n : ()Landroidx/room/d;
        //   84: aload_0
        //   85: getfield w : Landroidx/room/a$a$a$a$b;
        //   88: invokevirtual c : (Landroidx/room/d$c;)V
        //   91: aload_0
        //   92: getfield x : Ldbxyzptlk/dK/d;
        //   95: invokeinterface iterator : ()Ldbxyzptlk/dK/f;
        //   100: astore_1
        //   101: aload_0
        //   102: aload_1
        //   103: putfield t : Ljava/lang/Object;
        //   106: aload_0
        //   107: iconst_1
        //   108: putfield u : I
        //   111: aload_1
        //   112: aload_0
        //   113: invokeinterface a : (Ldbxyzptlk/tI/d;)Ljava/lang/Object;
        //   118: astore #4
        //   120: aload #4
        //   122: aload #5
        //   124: if_acmpne -> 130
        //   127: aload #5
        //   129: areturn
        //   130: aload_1
        //   131: astore_3
        //   132: aload #4
        //   134: checkcast java/lang/Boolean
        //   137: invokevirtual booleanValue : ()Z
        //   140: ifeq -> 195
        //   143: aload_3
        //   144: invokeinterface next : ()Ljava/lang/Object;
        //   149: pop
        //   150: aload_0
        //   151: getfield y : Ljava/util/concurrent/Callable;
        //   154: invokeinterface call : ()Ljava/lang/Object;
        //   159: astore_1
        //   160: aload_0
        //   161: getfield z : Ldbxyzptlk/dK/d;
        //   164: astore #4
        //   166: aload_0
        //   167: aload_3
        //   168: putfield t : Ljava/lang/Object;
        //   171: aload_0
        //   172: iconst_2
        //   173: putfield u : I
        //   176: aload #4
        //   178: aload_1
        //   179: aload_0
        //   180: invokeinterface F : (Ljava/lang/Object;Ldbxyzptlk/tI/d;)Ljava/lang/Object;
        //   185: astore_1
        //   186: aload_1
        //   187: aload #5
        //   189: if_acmpne -> 36
        //   192: aload #5
        //   194: areturn
        //   195: aload_0
        //   196: getfield v : Ldbxyzptlk/F4/s;
        //   199: invokevirtual n : ()Landroidx/room/d;
        //   202: aload_0
        //   203: getfield w : Landroidx/room/a$a$a$a$b;
        //   206: invokevirtual q : (Landroidx/room/d$c;)V
        //   209: getstatic dbxyzptlk/pI/D.a : Ldbxyzptlk/pI/D;
        //   212: areturn
        //   213: aload_0
        //   214: getfield v : Ldbxyzptlk/F4/s;
        //   217: invokevirtual n : ()Landroidx/room/d;
        //   220: aload_0
        //   221: getfield w : Landroidx/room/a$a$a$a$b;
        //   224: invokevirtual q : (Landroidx/room/d$c;)V
        //   227: aload_1
        //   228: athrow
        // Exception table:
        //   from	to	target	type
        //   32	36	41	finally
        //   63	67	41	finally
        //   91	101	41	finally
        //   101	120	41	finally
        //   132	186	41	finally
      }
    }
    
    @Metadata(d1 = {"\000\033\n\000\n\002\030\002\n\002\020\"\n\002\020\016\n\000\n\002\030\002\n\002\b\003*\001\000\b\n\030\0002\0020\001J\035\020\006\032\0020\0052\f\020\004\032\b\022\004\022\0020\0030\002H\026¢\006\004\b\006\020\007¨\006\b"}, d2 = {"androidx/room/a$a$a$a$b", "Landroidx/room/d$c;", "", "", "tables", "Ldbxyzptlk/pI/D;", "c", "(Ljava/util/Set;)V", "room-ktx_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
    public static final class b extends d.c {
      public final d<D> b;
      
      public b(String[] param4ArrayOfString, d<D> param4d) {
        super(param4ArrayOfString);
      }
      
      public void c(Set<String> param4Set) {
        this.b.k(D.a);
      }
    }
  }
  
  @f(c = "androidx.room.CoroutinesRoom$Companion$createFlow$1$1$1", f = "CoroutinesRoom.kt", l = {128, 130}, m = "invokeSuspend")
  @Metadata(d1 = {"\000\016\n\000\n\002\030\002\n\002\030\002\n\002\b\002\020\003\032\0020\002\"\004\b\000\020\000*\0020\001H@¢\006\004\b\003\020\004"}, d2 = {"R", "Ldbxyzptlk/bK/J;", "Ldbxyzptlk/pI/D;", "<anonymous>", "(Ldbxyzptlk/bK/J;)V"}, k = 3, mv = {1, 8, 0})
  public static final class a extends l implements p<J, d<? super D>, Object> {
    public Object t;
    
    public int u;
    
    public final s v;
    
    public final a.a.a.a.b w;
    
    public final d<D> x;
    
    public final Callable<R> y;
    
    public final d<R> z;
    
    public a(s param1s, a.a.a.a.b param1b, d<D> param1d1, Callable<R> param1Callable, d<R> param1d2, d param1d) {
      super(2, param1d);
    }
    
    public final d<D> create(Object param1Object, d<?> param1d) {
      return (d<D>)new a(this.v, this.w, this.x, this.y, this.z, param1d);
    }
    
    public final Object invoke(J param1J, d<? super D> param1d) {
      return ((a)create(param1J, param1d)).invokeSuspend(D.a);
    }
    
    public final Object invokeSuspend(Object<R> param1Object) {
      // Byte code:
      //   0: invokestatic g : ()Ljava/lang/Object;
      //   3: astore #5
      //   5: aload_0
      //   6: getfield u : I
      //   9: istore_2
      //   10: iload_2
      //   11: ifeq -> 73
      //   14: iload_2
      //   15: iconst_1
      //   16: if_icmpeq -> 55
      //   19: iload_2
      //   20: iconst_2
      //   21: if_icmpne -> 45
      //   24: aload_0
      //   25: getfield t : Ljava/lang/Object;
      //   28: checkcast dbxyzptlk/dK/f
      //   31: astore_3
      //   32: aload_1
      //   33: invokestatic b : (Ljava/lang/Object;)V
      //   36: aload_3
      //   37: astore_1
      //   38: goto -> 101
      //   41: astore_1
      //   42: goto -> 213
      //   45: new java/lang/IllegalStateException
      //   48: dup
      //   49: ldc 'call to 'resume' before 'invoke' with coroutine'
      //   51: invokespecial <init> : (Ljava/lang/String;)V
      //   54: athrow
      //   55: aload_0
      //   56: getfield t : Ljava/lang/Object;
      //   59: checkcast dbxyzptlk/dK/f
      //   62: astore_3
      //   63: aload_1
      //   64: invokestatic b : (Ljava/lang/Object;)V
      //   67: aload_1
      //   68: astore #4
      //   70: goto -> 132
      //   73: aload_1
      //   74: invokestatic b : (Ljava/lang/Object;)V
      //   77: aload_0
      //   78: getfield v : Ldbxyzptlk/F4/s;
      //   81: invokevirtual n : ()Landroidx/room/d;
      //   84: aload_0
      //   85: getfield w : Landroidx/room/a$a$a$a$b;
      //   88: invokevirtual c : (Landroidx/room/d$c;)V
      //   91: aload_0
      //   92: getfield x : Ldbxyzptlk/dK/d;
      //   95: invokeinterface iterator : ()Ldbxyzptlk/dK/f;
      //   100: astore_1
      //   101: aload_0
      //   102: aload_1
      //   103: putfield t : Ljava/lang/Object;
      //   106: aload_0
      //   107: iconst_1
      //   108: putfield u : I
      //   111: aload_1
      //   112: aload_0
      //   113: invokeinterface a : (Ldbxyzptlk/tI/d;)Ljava/lang/Object;
      //   118: astore #4
      //   120: aload #4
      //   122: aload #5
      //   124: if_acmpne -> 130
      //   127: aload #5
      //   129: areturn
      //   130: aload_1
      //   131: astore_3
      //   132: aload #4
      //   134: checkcast java/lang/Boolean
      //   137: invokevirtual booleanValue : ()Z
      //   140: ifeq -> 195
      //   143: aload_3
      //   144: invokeinterface next : ()Ljava/lang/Object;
      //   149: pop
      //   150: aload_0
      //   151: getfield y : Ljava/util/concurrent/Callable;
      //   154: invokeinterface call : ()Ljava/lang/Object;
      //   159: astore_1
      //   160: aload_0
      //   161: getfield z : Ldbxyzptlk/dK/d;
      //   164: astore #4
      //   166: aload_0
      //   167: aload_3
      //   168: putfield t : Ljava/lang/Object;
      //   171: aload_0
      //   172: iconst_2
      //   173: putfield u : I
      //   176: aload #4
      //   178: aload_1
      //   179: aload_0
      //   180: invokeinterface F : (Ljava/lang/Object;Ldbxyzptlk/tI/d;)Ljava/lang/Object;
      //   185: astore_1
      //   186: aload_1
      //   187: aload #5
      //   189: if_acmpne -> 36
      //   192: aload #5
      //   194: areturn
      //   195: aload_0
      //   196: getfield v : Ldbxyzptlk/F4/s;
      //   199: invokevirtual n : ()Landroidx/room/d;
      //   202: aload_0
      //   203: getfield w : Landroidx/room/a$a$a$a$b;
      //   206: invokevirtual q : (Landroidx/room/d$c;)V
      //   209: getstatic dbxyzptlk/pI/D.a : Ldbxyzptlk/pI/D;
      //   212: areturn
      //   213: aload_0
      //   214: getfield v : Ldbxyzptlk/F4/s;
      //   217: invokevirtual n : ()Landroidx/room/d;
      //   220: aload_0
      //   221: getfield w : Landroidx/room/a$a$a$a$b;
      //   224: invokevirtual q : (Landroidx/room/d$c;)V
      //   227: aload_1
      //   228: athrow
      // Exception table:
      //   from	to	target	type
      //   32	36	41	finally
      //   63	67	41	finally
      //   91	101	41	finally
      //   101	120	41	finally
      //   132	186	41	finally
    }
  }
  
  @Metadata(d1 = {"\000\033\n\000\n\002\030\002\n\002\020\"\n\002\020\016\n\000\n\002\030\002\n\002\b\003*\001\000\b\n\030\0002\0020\001J\035\020\006\032\0020\0052\f\020\004\032\b\022\004\022\0020\0030\002H\026¢\006\004\b\006\020\007¨\006\b"}, d2 = {"androidx/room/a$a$a$a$b", "Landroidx/room/d$c;", "", "", "tables", "Ldbxyzptlk/pI/D;", "c", "(Ljava/util/Set;)V", "room-ktx_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class b extends d.c {
    public final d<D> b;
    
    public b(String[] param1ArrayOfString, d<D> param1d) {
      super(param1ArrayOfString);
    }
    
    public void c(Set<String> param1Set) {
      this.b.k(D.a);
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\room\a.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */