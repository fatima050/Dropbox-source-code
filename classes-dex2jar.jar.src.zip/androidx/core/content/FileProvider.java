package androidx.core.content;

import android.annotation.SuppressLint;
import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.ProviderInfo;
import android.content.res.XmlResourceParser;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.webkit.MimeTypeMap;
import dbxyzptlk.V1.b;
import dbxyzptlk.g2.d;
import io.sentry.android.core.performance.e;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import org.xmlpull.v1.XmlPullParserException;

public class FileProvider extends ContentProvider {
  private static final String ATTR_NAME = "name";
  
  private static final String ATTR_PATH = "path";
  
  private static final String[] COLUMNS = new String[] { "_display_name", "_size" };
  
  private static final File DEVICE_ROOT = new File("/");
  
  private static final String DISPLAYNAME_FIELD = "displayName";
  
  private static final String META_DATA_FILE_PROVIDER_PATHS = "android.support.FILE_PROVIDER_PATHS";
  
  private static final String TAG_CACHE_PATH = "cache-path";
  
  private static final String TAG_EXTERNAL = "external-path";
  
  private static final String TAG_EXTERNAL_CACHE = "external-cache-path";
  
  private static final String TAG_EXTERNAL_FILES = "external-files-path";
  
  private static final String TAG_EXTERNAL_MEDIA = "external-media-path";
  
  private static final String TAG_FILES_PATH = "files-path";
  
  private static final String TAG_ROOT_PATH = "root-path";
  
  private static final HashMap<String, b> sCache = new HashMap<>();
  
  private String mAuthority;
  
  private b mLocalPathStrategy;
  
  private final Object mLock = new Object();
  
  private final int mResourceId;
  
  public FileProvider() {
    this(0);
  }
  
  public FileProvider(int paramInt) {
    this.mResourceId = paramInt;
  }
  
  private static File buildPath(File paramFile, String... paramVarArgs) {
    int i = paramVarArgs.length;
    byte b1 = 0;
    File file;
    for (file = paramFile; b1 < i; file = paramFile) {
      String str = paramVarArgs[b1];
      paramFile = file;
      if (str != null)
        paramFile = new File(file, str); 
      b1++;
    } 
    return file;
  }
  
  private static Object[] copyOf(Object[] paramArrayOfObject, int paramInt) {
    Object[] arrayOfObject = new Object[paramInt];
    System.arraycopy(paramArrayOfObject, 0, arrayOfObject, 0, paramInt);
    return arrayOfObject;
  }
  
  private static String[] copyOf(String[] paramArrayOfString, int paramInt) {
    String[] arrayOfString = new String[paramInt];
    System.arraycopy(paramArrayOfString, 0, arrayOfString, 0, paramInt);
    return arrayOfString;
  }
  
  public static XmlResourceParser getFileProviderPathsMetaData(Context paramContext, String paramString, ProviderInfo paramProviderInfo, int paramInt) {
    Bundle bundle;
    if (paramProviderInfo != null) {
      if (paramProviderInfo.metaData == null && paramInt != 0) {
        bundle = new Bundle(1);
        paramProviderInfo.metaData = bundle;
        bundle.putInt("android.support.FILE_PROVIDER_PATHS", paramInt);
      } 
      XmlResourceParser xmlResourceParser = paramProviderInfo.loadXmlMetaData(paramContext.getPackageManager(), "android.support.FILE_PROVIDER_PATHS");
      if (xmlResourceParser != null)
        return xmlResourceParser; 
      throw new IllegalArgumentException("Missing android.support.FILE_PROVIDER_PATHS meta-data");
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Couldn't find meta-data for provider with authority ");
    stringBuilder.append((String)bundle);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  private b getLocalPathStrategy() {
    Object object = this.mLock;
    /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
    try {
      d.d(this.mAuthority, "mAuthority is null. Did you override attachInfo and did not call super.attachInfo()?");
      if (this.mLocalPathStrategy == null)
        this.mLocalPathStrategy = getPathStrategy(getContext(), this.mAuthority, this.mResourceId); 
    } finally {
      Exception exception;
    } 
    b b1 = this.mLocalPathStrategy;
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
    return b1;
  }
  
  private static b getPathStrategy(Context paramContext, String paramString, int paramInt) {
    b b1;
    HashMap<String, b> hashMap = sCache;
    /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{java/util/HashMap<[ObjectType{java/lang/String}, InnerObjectType{ObjectType{androidx/core/content/FileProvider}.Landroidx/core/content/FileProvider$b;}]>}, name=null} */
    try {
      b b2 = hashMap.get(paramString);
      b1 = b2;
      if (b2 == null)
        try {
          b1 = parsePathStrategy(paramContext, paramString, paramInt);
          hashMap.put(paramString, b1);
        } catch (IOException iOException) {
          IllegalArgumentException illegalArgumentException = new IllegalArgumentException();
          this("Failed to parse android.support.FILE_PROVIDER_PATHS meta-data", iOException);
          throw illegalArgumentException;
        } catch (XmlPullParserException xmlPullParserException) {
          IllegalArgumentException illegalArgumentException = new IllegalArgumentException();
          this("Failed to parse android.support.FILE_PROVIDER_PATHS meta-data", (Throwable)xmlPullParserException);
          throw illegalArgumentException;
        }  
    } finally {}
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/util/HashMap<[ObjectType{java/lang/String}, InnerObjectType{ObjectType{androidx/core/content/FileProvider}.Landroidx/core/content/FileProvider$b;}]>}, name=null} */
    return b1;
  }
  
  public static Uri getUriForFile(Context paramContext, String paramString, File paramFile) {
    return getPathStrategy(paramContext, paramString, 0).a(paramFile);
  }
  
  @SuppressLint({"StreamFiles"})
  public static Uri getUriForFile(Context paramContext, String paramString1, File paramFile, String paramString2) {
    return getUriForFile(paramContext, paramString1, paramFile).buildUpon().appendQueryParameter("displayName", paramString2).build();
  }
  
  private static int modeToMode(String paramString) {
    int i;
    if ("r".equals(paramString)) {
      i = 268435456;
    } else {
      if ("w".equals(paramString) || "wt".equals(paramString))
        return 738197504; 
      if ("wa".equals(paramString)) {
        i = 704643072;
      } else if ("rw".equals(paramString)) {
        i = 939524096;
      } else if ("rwt".equals(paramString)) {
        i = 1006632960;
      } else {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Invalid mode: ");
        stringBuilder.append(paramString);
        throw new IllegalArgumentException(stringBuilder.toString());
      } 
    } 
    return i;
  }
  
  private static b parsePathStrategy(Context paramContext, String paramString, int paramInt) throws IOException, XmlPullParserException {
    c c = new c(paramString);
    XmlResourceParser xmlResourceParser = getFileProviderPathsMetaData(paramContext, paramString, paramContext.getPackageManager().resolveContentProvider(paramString, 128), paramInt);
    while (true) {
      paramInt = xmlResourceParser.next();
      if (paramInt != 1) {
        if (paramInt == 2) {
          File file;
          String str4 = xmlResourceParser.getName();
          String str1 = null;
          String str3 = xmlResourceParser.getAttributeValue(null, "name");
          String str2 = xmlResourceParser.getAttributeValue(null, "path");
          if ("root-path".equals(str4)) {
            file = DEVICE_ROOT;
          } else if ("files-path".equals(str4)) {
            file = paramContext.getFilesDir();
          } else if ("cache-path".equals(str4)) {
            file = paramContext.getCacheDir();
          } else if ("external-path".equals(str4)) {
            file = Environment.getExternalStorageDirectory();
          } else {
            File[] arrayOfFile;
            if ("external-files-path".equals(str4)) {
              arrayOfFile = b.g(paramContext, null);
              paramString = str1;
              if (arrayOfFile.length > 0)
                file = arrayOfFile[0]; 
            } else if ("external-cache-path".equals(arrayOfFile)) {
              arrayOfFile = b.f(paramContext);
              paramString = str1;
              if (arrayOfFile.length > 0)
                file = arrayOfFile[0]; 
            } else {
              paramString = str1;
              if ("external-media-path".equals(arrayOfFile)) {
                arrayOfFile = a.a(paramContext);
                paramString = str1;
                if (arrayOfFile.length > 0)
                  file = arrayOfFile[0]; 
              } 
            } 
          } 
          if (file != null)
            c.c(str3, buildPath(file, new String[] { str2 })); 
        } 
        continue;
      } 
      return (b)c;
    } 
  }
  
  private static String removeTrailingSlash(String paramString) {
    String str = paramString;
    if (paramString.length() > 0) {
      str = paramString;
      if (paramString.charAt(paramString.length() - 1) == '/')
        str = paramString.substring(0, paramString.length() - 1); 
    } 
    return str;
  }
  
  public void attachInfo(Context paramContext, ProviderInfo paramProviderInfo) {
    super.attachInfo(paramContext, paramProviderInfo);
    if (!paramProviderInfo.exported) {
      if (paramProviderInfo.grantUriPermissions) {
        null = paramProviderInfo.authority.split(";")[0];
        synchronized (this.mLock) {
          this.mAuthority = null;
          synchronized (sCache) {
            null.remove(null);
            return;
          } 
        } 
      } 
      throw new SecurityException("Provider must grant uri permissions");
    } 
    throw new SecurityException("Provider must not be exported");
  }
  
  public int delete(Uri paramUri, String paramString, String[] paramArrayOfString) {
    return getLocalPathStrategy().b(paramUri).delete();
  }
  
  public String getType(Uri paramUri) {
    File file = getLocalPathStrategy().b(paramUri);
    int i = file.getName().lastIndexOf('.');
    if (i >= 0) {
      String str = file.getName().substring(i + 1);
      str = MimeTypeMap.getSingleton().getMimeTypeFromExtension(str);
      if (str != null)
        return str; 
    } 
    return "application/octet-stream";
  }
  
  public String getTypeAnonymous(Uri paramUri) {
    return "application/octet-stream";
  }
  
  public Uri insert(Uri paramUri, ContentValues paramContentValues) {
    throw new UnsupportedOperationException("No external inserts");
  }
  
  public boolean onCreate() {
    e.t((ContentProvider)this);
    e.u((ContentProvider)this);
    return true;
  }
  
  @SuppressLint({"UnknownNullness"})
  public ParcelFileDescriptor openFile(Uri paramUri, String paramString) throws FileNotFoundException {
    return ParcelFileDescriptor.open(getLocalPathStrategy().b(paramUri), modeToMode(paramString));
  }
  
  public Cursor query(Uri paramUri, String[] paramArrayOfString1, String paramString1, String[] paramArrayOfString2, String paramString2) {
    Object object;
    int i;
    File file = getLocalPathStrategy().b(paramUri);
    paramString1 = paramUri.getQueryParameter("displayName");
    String[] arrayOfString1 = paramArrayOfString1;
    if (paramArrayOfString1 == null)
      arrayOfString1 = COLUMNS; 
    String[] arrayOfString2 = new String[arrayOfString1.length];
    Object[] arrayOfObject2 = new Object[arrayOfString1.length];
    int j = arrayOfString1.length;
    byte b1 = 0;
    boolean bool = false;
    while (b1 < j) {
      String str = arrayOfString1[b1];
      if ("_display_name".equals(str)) {
        arrayOfString2[object] = "_display_name";
        int m = object + 1;
        if (paramString1 == null) {
          str = file.getName();
        } else {
          str = paramString1;
        } 
        arrayOfObject2[object] = str;
        i = m;
      } else {
        int m = i;
        if ("_size".equals(str)) {
          arrayOfString2[i] = "_size";
          m = i + 1;
          arrayOfObject2[i] = Long.valueOf(file.length());
          i = m;
        } else {
          continue;
        } 
      } 
      int k = i;
      continue;
      b1++;
      object = SYNTHETIC_LOCAL_VARIABLE_8;
    } 
    arrayOfString1 = copyOf(arrayOfString2, i);
    Object[] arrayOfObject1 = copyOf(arrayOfObject2, i);
    MatrixCursor matrixCursor = new MatrixCursor(arrayOfString1, 1);
    matrixCursor.addRow(arrayOfObject1);
    return (Cursor)matrixCursor;
  }
  
  public int update(Uri paramUri, ContentValues paramContentValues, String paramString, String[] paramArrayOfString) {
    throw new UnsupportedOperationException("No external updates");
  }
  
  class FileProvider {}
  
  class FileProvider {}
  
  class FileProvider {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\core\content\FileProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */