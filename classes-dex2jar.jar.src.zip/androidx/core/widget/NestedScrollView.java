package androidx.core.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.FocusFinder;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityRecord;
import android.view.animation.AnimationUtils;
import android.widget.EdgeEffect;
import android.widget.FrameLayout;
import android.widget.OverScroller;
import android.widget.ScrollView;
import androidx.core.view.ScrollingView;
import dbxyzptlk.h2.H;
import dbxyzptlk.h2.I;
import dbxyzptlk.h2.K;
import dbxyzptlk.h2.M;
import dbxyzptlk.h2.N;
import dbxyzptlk.h2.h0;
import dbxyzptlk.h2.t;
import dbxyzptlk.h2.u;
import dbxyzptlk.i2.t;
import dbxyzptlk.i2.v;
import dbxyzptlk.n2.g;
import io.sentry.android.core.r0;

public class NestedScrollView extends FrameLayout implements M, I, ScrollingView {
  public static final float D = (float)(Math.log(0.78D) / Math.log(0.9D));
  
  public static final a E = new a();
  
  public static final int[] F = new int[] { 16843130 };
  
  public d A;
  
  public final c B;
  
  public t C;
  
  public final float a;
  
  public long b;
  
  public final Rect c = new Rect();
  
  public OverScroller d;
  
  public EdgeEffect e;
  
  public EdgeEffect f;
  
  public int g;
  
  public boolean h = true;
  
  public boolean i = false;
  
  public View j = null;
  
  public boolean k = false;
  
  public VelocityTracker l;
  
  public boolean m;
  
  public boolean n = true;
  
  public int o;
  
  public int p;
  
  public int q;
  
  public int r = -1;
  
  public final int[] s = new int[2];
  
  public final int[] t = new int[2];
  
  public int u;
  
  public int v;
  
  public e w;
  
  public final N x;
  
  public final K y;
  
  public float z;
  
  public NestedScrollView(Context paramContext) {
    this(paramContext, null);
  }
  
  public NestedScrollView(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, dbxyzptlk.S1.a.nestedScrollViewStyle);
  }
  
  public NestedScrollView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    c c1 = new c(this);
    this.B = c1;
    this.C = new t(getContext(), c1);
    this.e = g.a(paramContext, paramAttributeSet);
    this.f = g.a(paramContext, paramAttributeSet);
    this.a = (paramContext.getResources().getDisplayMetrics()).density * 160.0F * 386.0878F * 0.84F;
    v();
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, F, paramInt, 0);
    setFillViewport(typedArray.getBoolean(0, false));
    typedArray.recycle();
    this.x = new N((ViewGroup)this);
    this.y = new K((View)this);
    setNestedScrollingEnabled(true);
    h0.q0((View)this, E);
  }
  
  private static int f(int paramInt1, int paramInt2, int paramInt3) {
    return (paramInt2 >= paramInt3 || paramInt1 < 0) ? 0 : ((paramInt2 + paramInt1 > paramInt3) ? (paramInt3 - paramInt2) : paramInt1);
  }
  
  public static boolean z(View paramView1, View paramView2) {
    boolean bool = true;
    if (paramView1 == paramView2)
      return true; 
    ViewParent viewParent = paramView1.getParent();
    if (!(viewParent instanceof ViewGroup) || !z((View)viewParent, paramView2))
      bool = false; 
    return bool;
  }
  
  public final boolean A(View paramView, int paramInt1, int paramInt2) {
    boolean bool;
    paramView.getDrawingRect(this.c);
    offsetDescendantRectToMyCoords(paramView, this.c);
    if (this.c.bottom + paramInt1 >= getScrollY() && this.c.top - paramInt1 <= getScrollY() + paramInt2) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public final void B(int paramInt1, int paramInt2, int[] paramArrayOfint) {
    int i = getScrollY();
    scrollBy(0, paramInt1);
    i = getScrollY() - i;
    if (paramArrayOfint != null)
      paramArrayOfint[1] = paramArrayOfint[1] + i; 
    this.y.e(0, i, 0, paramInt1 - i, null, paramInt2, paramArrayOfint);
  }
  
  public final void C(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getActionIndex();
    if (paramMotionEvent.getPointerId(i) == this.r) {
      if (i == 0) {
        i = 1;
      } else {
        i = 0;
      } 
      this.g = (int)paramMotionEvent.getY(i);
      this.r = paramMotionEvent.getPointerId(i);
      VelocityTracker velocityTracker = this.l;
      if (velocityTracker != null)
        velocityTracker.clear(); 
    } 
  }
  
  public boolean D(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, boolean paramBoolean) {
    boolean bool1;
    int k = getOverScrollMode();
    int j = computeHorizontalScrollRange();
    int i = computeHorizontalScrollExtent();
    boolean bool2 = false;
    if (j > i) {
      i = 1;
    } else {
      i = 0;
    } 
    if (computeVerticalScrollRange() > computeVerticalScrollExtent()) {
      j = 1;
    } else {
      j = 0;
    } 
    if (k == 0 || (k == 1 && i != 0)) {
      i = 1;
    } else {
      i = 0;
    } 
    if (k == 0 || (k == 1 && j != 0)) {
      j = 1;
    } else {
      j = 0;
    } 
    paramInt3 += paramInt1;
    if (i == 0) {
      paramInt1 = 0;
    } else {
      paramInt1 = paramInt7;
    } 
    paramInt4 += paramInt2;
    if (j == 0) {
      paramInt2 = 0;
    } else {
      paramInt2 = paramInt8;
    } 
    paramInt7 = -paramInt1;
    paramInt1 += paramInt5;
    paramInt5 = -paramInt2;
    paramInt2 += paramInt6;
    if (paramInt3 > paramInt1) {
      paramBoolean = true;
    } else if (paramInt3 < paramInt7) {
      paramBoolean = true;
      paramInt1 = paramInt7;
    } else {
      paramBoolean = false;
      paramInt1 = paramInt3;
    } 
    if (paramInt4 > paramInt2) {
      bool1 = true;
    } else if (paramInt4 < paramInt5) {
      bool1 = true;
      paramInt2 = paramInt5;
    } else {
      bool1 = false;
      paramInt2 = paramInt4;
    } 
    if (bool1 && !s(1))
      this.d.springBack(paramInt1, paramInt2, 0, 0, 0, getScrollRange()); 
    onOverScrolled(paramInt1, paramInt2, paramBoolean, bool1);
    if (!paramBoolean) {
      paramBoolean = bool2;
      return bool1 ? true : paramBoolean;
    } 
    return true;
  }
  
  public boolean E(int paramInt) {
    if (paramInt == 130) {
      i = 1;
    } else {
      i = 0;
    } 
    int j = getHeight();
    if (i) {
      this.c.top = getScrollY() + j;
      i = getChildCount();
      if (i > 0) {
        View view = getChildAt(i - 1);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
        i = view.getBottom() + layoutParams.bottomMargin + getPaddingBottom();
        Rect rect1 = this.c;
        if (rect1.top + j > i)
          rect1.top = i - j; 
      } 
    } else {
      this.c.top = getScrollY() - j;
      Rect rect1 = this.c;
      if (rect1.top < 0)
        rect1.top = 0; 
    } 
    Rect rect = this.c;
    int i = rect.top;
    j += i;
    rect.bottom = j;
    return I(paramInt, i, j);
  }
  
  public final void F() {
    VelocityTracker velocityTracker = this.l;
    if (velocityTracker != null) {
      velocityTracker.recycle();
      this.l = null;
    } 
  }
  
  public final int G(int paramInt, float paramFloat) {
    float f2 = paramFloat / getWidth();
    float f1 = paramInt / getHeight();
    float f3 = g.c(this.e);
    paramFloat = 0.0F;
    if (f3 != 0.0F) {
      f1 = -g.h(this.e, -f1, f2);
      paramFloat = f1;
      if (g.c(this.e) == 0.0F) {
        this.e.onRelease();
        paramFloat = f1;
      } 
    } else if (g.c(this.f) != 0.0F) {
      f1 = g.h(this.f, f1, 1.0F - f2);
      paramFloat = f1;
      if (g.c(this.f) == 0.0F) {
        this.f.onRelease();
        paramFloat = f1;
      } 
    } 
    paramInt = Math.round(paramFloat * getHeight());
    if (paramInt != 0)
      invalidate(); 
    return paramInt;
  }
  
  public final void H(boolean paramBoolean) {
    if (paramBoolean) {
      S(2, 1);
    } else {
      stopNestedScroll(1);
    } 
    this.v = getScrollY();
    postInvalidateOnAnimation();
  }
  
  public final boolean I(int paramInt1, int paramInt2, int paramInt3) {
    boolean bool1;
    NestedScrollView nestedScrollView;
    int j = getHeight();
    int i = getScrollY();
    j += i;
    boolean bool2 = false;
    if (paramInt1 == 33) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    View view2 = o(bool1, paramInt2, paramInt3);
    View view1 = view2;
    if (view2 == null)
      nestedScrollView = this; 
    if (paramInt2 >= i && paramInt3 <= j) {
      bool1 = bool2;
    } else {
      if (bool1) {
        paramInt2 -= i;
      } else {
        paramInt2 = paramInt3 - j;
      } 
      J(paramInt2, 0, 1, true);
      bool1 = true;
    } 
    if (nestedScrollView != findFocus())
      nestedScrollView.requestFocus(paramInt1); 
    return bool1;
  }
  
  public final int J(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean) {
    byte b;
    int i;
    boolean bool1;
    if (paramInt3 == 1)
      S(2, paramInt3); 
    boolean bool = i(0, paramInt1, this.t, this.s, paramInt3);
    boolean bool2 = false;
    if (bool) {
      i = this.t[1];
      b = this.s[1];
      i = paramInt1 - i;
    } else {
      b = 0;
      i = paramInt1;
    } 
    int k = getScrollY();
    int j = getScrollRange();
    if (d() && !paramBoolean) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    if (D(0, i, 0, k, 0, j, 0, 0, true) && !s(paramInt3)) {
      paramInt1 = 1;
    } else {
      paramInt1 = 0;
    } 
    int m = getScrollY() - k;
    int[] arrayOfInt = this.t;
    arrayOfInt[1] = 0;
    j(0, m, 0, i - m, this.s, paramInt3, arrayOfInt);
    m = this.s[1];
    i -= this.t[1];
    k += i;
    if (k < 0) {
      if (bool1) {
        g.h(this.e, -i / getHeight(), paramInt2 / getWidth());
        if (!this.f.isFinished())
          this.f.onRelease(); 
      } 
    } else if (k > j && bool1) {
      g.h(this.f, i / getHeight(), 1.0F - paramInt2 / getWidth());
      if (!this.e.isFinished())
        this.e.onRelease(); 
    } 
    if (!this.e.isFinished() || !this.f.isFinished()) {
      postInvalidateOnAnimation();
      paramInt1 = bool2;
    } 
    if (paramInt1 != 0 && paramInt3 == 0) {
      VelocityTracker velocityTracker = this.l;
      if (velocityTracker != null)
        velocityTracker.clear(); 
    } 
    if (paramInt3 == 1) {
      stopNestedScroll(paramInt3);
      this.e.onRelease();
      this.f.onRelease();
    } 
    return b + m;
  }
  
  public final void K(View paramView) {
    paramView.getDrawingRect(this.c);
    offsetDescendantRectToMyCoords(paramView, this.c);
    int i = g(this.c);
    if (i != 0)
      scrollBy(0, i); 
  }
  
  public final boolean L(Rect paramRect, boolean paramBoolean) {
    boolean bool;
    int i = g(paramRect);
    if (i != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool)
      if (paramBoolean) {
        scrollBy(0, i);
      } else {
        N(0, i);
      }  
    return bool;
  }
  
  public final boolean M(EdgeEffect paramEdgeEffect, int paramInt) {
    boolean bool = true;
    if (paramInt > 0)
      return true; 
    float f1 = g.c(paramEdgeEffect);
    float f2 = getHeight();
    if (r(-paramInt) >= f1 * f2)
      bool = false; 
    return bool;
  }
  
  public final void N(int paramInt1, int paramInt2) {
    O(paramInt1, paramInt2, 250, false);
  }
  
  public final void O(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean) {
    if (getChildCount() == 0)
      return; 
    if (AnimationUtils.currentAnimationTimeMillis() - this.b > 250L) {
      View view = getChildAt(0);
      FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
      int n = view.getHeight();
      int k = layoutParams.topMargin;
      int i1 = layoutParams.bottomMargin;
      int j = getHeight();
      int m = getPaddingTop();
      int i = getPaddingBottom();
      paramInt1 = getScrollY();
      paramInt2 = Math.max(0, Math.min(paramInt2 + paramInt1, Math.max(0, n + k + i1 - j - m - i)));
      this.d.startScroll(getScrollX(), paramInt1, 0, paramInt2 - paramInt1, paramInt3);
      H(paramBoolean);
    } else {
      if (!this.d.isFinished())
        a(); 
      scrollBy(paramInt1, paramInt2);
    } 
    this.b = AnimationUtils.currentAnimationTimeMillis();
  }
  
  public final void P(int paramInt1, int paramInt2) {
    Q(paramInt1, paramInt2, 250, false);
  }
  
  public void Q(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean) {
    O(paramInt1 - getScrollX(), paramInt2 - getScrollY(), paramInt3, paramBoolean);
  }
  
  public void R(int paramInt1, int paramInt2, boolean paramBoolean) {
    Q(paramInt1, paramInt2, 250, paramBoolean);
  }
  
  public boolean S(int paramInt1, int paramInt2) {
    return this.y.q(paramInt1, paramInt2);
  }
  
  public final boolean T(MotionEvent paramMotionEvent) {
    boolean bool1;
    float f = g.c(this.e);
    boolean bool2 = true;
    if (f != 0.0F) {
      g.h(this.e, 0.0F, paramMotionEvent.getX() / getWidth());
      bool1 = true;
    } else {
      bool1 = false;
    } 
    if (g.c(this.f) != 0.0F) {
      g.h(this.f, 0.0F, 1.0F - paramMotionEvent.getX() / getWidth());
      bool1 = bool2;
    } 
    return bool1;
  }
  
  public final void a() {
    this.d.abortAnimation();
    stopNestedScroll(1);
  }
  
  public void addView(View paramView) {
    if (getChildCount() <= 0) {
      super.addView(paramView);
      return;
    } 
    throw new IllegalStateException("ScrollView can host only one direct child");
  }
  
  public void addView(View paramView, int paramInt) {
    if (getChildCount() <= 0) {
      super.addView(paramView, paramInt);
      return;
    } 
    throw new IllegalStateException("ScrollView can host only one direct child");
  }
  
  public void addView(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams) {
    if (getChildCount() <= 0) {
      super.addView(paramView, paramInt, paramLayoutParams);
      return;
    } 
    throw new IllegalStateException("ScrollView can host only one direct child");
  }
  
  public void addView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    if (getChildCount() <= 0) {
      super.addView(paramView, paramLayoutParams);
      return;
    } 
    throw new IllegalStateException("ScrollView can host only one direct child");
  }
  
  public boolean c(int paramInt) {
    View view2 = findFocus();
    View view1 = view2;
    if (view2 == this)
      view1 = null; 
    view2 = FocusFinder.getInstance().findNextFocus((ViewGroup)this, view1, paramInt);
    int i = getMaxScrollAmount();
    if (view2 != null && A(view2, i, getHeight())) {
      view2.getDrawingRect(this.c);
      offsetDescendantRectToMyCoords(view2, this.c);
      J(g(this.c), 0, 1, true);
      view2.requestFocus(paramInt);
    } else {
      int j;
      if (paramInt == 33 && getScrollY() < i) {
        j = getScrollY();
      } else {
        j = i;
        if (paramInt == 130) {
          j = i;
          if (getChildCount() > 0) {
            view2 = getChildAt(0);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view2.getLayoutParams();
            j = Math.min(view2.getBottom() + layoutParams.bottomMargin - getScrollY() + getHeight() - getPaddingBottom(), i);
          } 
        } 
      } 
      if (j == 0)
        return false; 
      if (paramInt != 130)
        j = -j; 
      J(j, 0, 1, true);
    } 
    if (view1 != null && view1.isFocused() && y(view1)) {
      paramInt = getDescendantFocusability();
      setDescendantFocusability(131072);
      requestFocus();
      setDescendantFocusability(paramInt);
    } 
    return true;
  }
  
  public int computeHorizontalScrollExtent() {
    return super.computeHorizontalScrollExtent();
  }
  
  public int computeHorizontalScrollOffset() {
    return super.computeHorizontalScrollOffset();
  }
  
  public int computeHorizontalScrollRange() {
    return super.computeHorizontalScrollRange();
  }
  
  public void computeScroll() {
    if (this.d.isFinished())
      return; 
    this.d.computeScrollOffset();
    int i = this.d.getCurrY();
    int j = h(i - this.v);
    this.v = i;
    int[] arrayOfInt = this.t;
    arrayOfInt[1] = 0;
    i(0, j, arrayOfInt, null, 1);
    j -= this.t[1];
    int k = getScrollRange();
    i = j;
    if (j != 0) {
      i = getScrollY();
      D(0, j, getScrollX(), i, 0, k, 0, 0, false);
      i = getScrollY() - i;
      j -= i;
      arrayOfInt = this.t;
      arrayOfInt[1] = 0;
      j(0, i, 0, j, this.s, 1, arrayOfInt);
      i = j - this.t[1];
    } 
    if (i != 0) {
      j = getOverScrollMode();
      if (j == 0 || (j == 1 && k > 0))
        if (i < 0) {
          if (this.e.isFinished())
            this.e.onAbsorb((int)this.d.getCurrVelocity()); 
        } else if (this.f.isFinished()) {
          this.f.onAbsorb((int)this.d.getCurrVelocity());
        }  
      a();
    } 
    if (!this.d.isFinished()) {
      postInvalidateOnAnimation();
    } else {
      stopNestedScroll(1);
    } 
  }
  
  public int computeVerticalScrollExtent() {
    return super.computeVerticalScrollExtent();
  }
  
  public int computeVerticalScrollOffset() {
    return Math.max(0, super.computeVerticalScrollOffset());
  }
  
  public int computeVerticalScrollRange() {
    int j = getChildCount();
    int i = getHeight() - getPaddingBottom() - getPaddingTop();
    if (j == 0)
      return i; 
    View view = getChildAt(0);
    FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
    j = view.getBottom() + layoutParams.bottomMargin;
    int k = getScrollY();
    int m = Math.max(0, j - i);
    if (k < 0) {
      i = j - k;
    } else {
      i = j;
      if (k > m)
        i = j + k - m; 
    } 
    return i;
  }
  
  public final boolean d() {
    int i = getOverScrollMode();
    boolean bool2 = true;
    boolean bool1 = bool2;
    if (i != 0)
      if (i == 1 && getScrollRange() > 0) {
        bool1 = bool2;
      } else {
        bool1 = false;
      }  
    return bool1;
  }
  
  public boolean dispatchKeyEvent(KeyEvent paramKeyEvent) {
    return (super.dispatchKeyEvent(paramKeyEvent) || n(paramKeyEvent));
  }
  
  public boolean dispatchNestedFling(float paramFloat1, float paramFloat2, boolean paramBoolean) {
    return this.y.a(paramFloat1, paramFloat2, paramBoolean);
  }
  
  public boolean dispatchNestedPreFling(float paramFloat1, float paramFloat2) {
    return this.y.b(paramFloat1, paramFloat2);
  }
  
  public boolean dispatchNestedPreScroll(int paramInt1, int paramInt2, int[] paramArrayOfint1, int[] paramArrayOfint2) {
    return i(paramInt1, paramInt2, paramArrayOfint1, paramArrayOfint2, 0);
  }
  
  public boolean dispatchNestedScroll(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfint) {
    return this.y.f(paramInt1, paramInt2, paramInt3, paramInt4, paramArrayOfint);
  }
  
  public void draw(Canvas paramCanvas) {
    super.draw(paramCanvas);
    int i = getScrollY();
    boolean bool = this.e.isFinished();
    byte b = 0;
    if (!bool) {
      boolean bool1;
      int i2 = paramCanvas.save();
      int j = getWidth();
      int i1 = getHeight();
      int n = Math.min(0, i);
      if (b.a((ViewGroup)this)) {
        j -= getPaddingLeft() + getPaddingRight();
        bool1 = getPaddingLeft();
      } else {
        bool1 = false;
      } 
      int m = i1;
      int k = n;
      if (b.a((ViewGroup)this)) {
        m = i1 - getPaddingTop() + getPaddingBottom();
        k = n + getPaddingTop();
      } 
      paramCanvas.translate(bool1, k);
      this.e.setSize(j, m);
      if (this.e.draw(paramCanvas))
        postInvalidateOnAnimation(); 
      paramCanvas.restoreToCount(i2);
    } 
    if (!this.f.isFinished()) {
      int i3 = paramCanvas.save();
      int m = getWidth();
      int i2 = getHeight();
      int i1 = Math.max(getScrollRange(), i) + i2;
      int k = b;
      int j = m;
      if (b.a((ViewGroup)this)) {
        j = m - getPaddingLeft() + getPaddingRight();
        k = getPaddingLeft();
      } 
      int n = i1;
      m = i2;
      if (b.a((ViewGroup)this)) {
        m = i2 - getPaddingTop() + getPaddingBottom();
        n = i1 - getPaddingBottom();
      } 
      paramCanvas.translate((k - j), n);
      paramCanvas.rotate(180.0F, j, 0.0F);
      this.f.setSize(j, m);
      if (this.f.draw(paramCanvas))
        postInvalidateOnAnimation(); 
      paramCanvas.restoreToCount(i3);
    } 
  }
  
  public final boolean e() {
    int i = getChildCount();
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (i > 0) {
      View view = getChildAt(0);
      FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
      bool1 = bool2;
      if (view.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin > getHeight() - getPaddingTop() - getPaddingBottom())
        bool1 = true; 
    } 
    return bool1;
  }
  
  public int g(Rect paramRect) {
    int i = getChildCount();
    boolean bool = false;
    if (i == 0)
      return 0; 
    int n = getHeight();
    i = getScrollY();
    int m = i + n;
    int k = getVerticalFadingEdgeLength();
    int j = i;
    if (paramRect.top > 0)
      j = i + k; 
    View view = getChildAt(0);
    FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
    if (paramRect.bottom < view.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin) {
      k = m - k;
    } else {
      k = m;
    } 
    int i1 = paramRect.bottom;
    if (i1 > k && paramRect.top > j) {
      if (paramRect.height() > n) {
        i = paramRect.top - j;
      } else {
        i = paramRect.bottom - k;
      } 
      i = Math.min(i, view.getBottom() + layoutParams.bottomMargin - m);
    } else {
      i = bool;
      if (paramRect.top < j) {
        i = bool;
        if (i1 < k) {
          if (paramRect.height() > n) {
            i = 0 - k - paramRect.bottom;
          } else {
            i = 0 - j - paramRect.top;
          } 
          i = Math.max(i, -getScrollY());
        } 
      } 
    } 
    return i;
  }
  
  public float getBottomFadingEdgeStrength() {
    if (getChildCount() == 0)
      return 0.0F; 
    View view = getChildAt(0);
    FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
    int i = getVerticalFadingEdgeLength();
    int j = getHeight();
    int k = getPaddingBottom();
    j = view.getBottom() + layoutParams.bottomMargin - getScrollY() - j - k;
    return (j < i) ? (j / i) : 1.0F;
  }
  
  public int getMaxScrollAmount() {
    return (int)(getHeight() * 0.5F);
  }
  
  public int getNestedScrollAxes() {
    return this.x.a();
  }
  
  public int getScrollRange() {
    int j = getChildCount();
    int i = 0;
    if (j > 0) {
      View view = getChildAt(0);
      FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
      i = Math.max(0, view.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin - getHeight() - getPaddingTop() - getPaddingBottom());
    } 
    return i;
  }
  
  public float getTopFadingEdgeStrength() {
    if (getChildCount() == 0)
      return 0.0F; 
    int i = getVerticalFadingEdgeLength();
    int j = getScrollY();
    return (j < i) ? (j / i) : 1.0F;
  }
  
  public float getVerticalScrollFactorCompat() {
    if (this.z == 0.0F) {
      TypedValue typedValue = new TypedValue();
      Context context = getContext();
      if (context.getTheme().resolveAttribute(16842829, typedValue, true)) {
        this.z = typedValue.getDimension(context.getResources().getDisplayMetrics());
      } else {
        throw new IllegalStateException("Expected theme to define listPreferredItemHeight.");
      } 
    } 
    return this.z;
  }
  
  public int h(int paramInt) {
    int j = getHeight();
    if (paramInt > 0 && g.c(this.e) != 0.0F) {
      float f = -paramInt * 4.0F / j;
      int k = Math.round(-j / 4.0F * g.h(this.e, f, 0.5F));
      if (k != paramInt)
        this.e.finish(); 
      return paramInt - k;
    } 
    int i = paramInt;
    if (paramInt < 0) {
      i = paramInt;
      if (g.c(this.f) != 0.0F) {
        float f2 = paramInt;
        float f1 = j;
        f2 = f2 * 4.0F / f1;
        i = Math.round(f1 / 4.0F * g.h(this.f, f2, 0.5F));
        if (i != paramInt)
          this.f.finish(); 
        i = paramInt - i;
      } 
    } 
    return i;
  }
  
  public boolean hasNestedScrollingParent() {
    return s(0);
  }
  
  public boolean i(int paramInt1, int paramInt2, int[] paramArrayOfint1, int[] paramArrayOfint2, int paramInt3) {
    return this.y.d(paramInt1, paramInt2, paramArrayOfint1, paramArrayOfint2, paramInt3);
  }
  
  public boolean isNestedScrollingEnabled() {
    return this.y.m();
  }
  
  public void j(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfint1, int paramInt5, int[] paramArrayOfint2) {
    this.y.e(paramInt1, paramInt2, paramInt3, paramInt4, paramArrayOfint1, paramInt5, paramArrayOfint2);
  }
  
  public final void k(int paramInt) {
    if (paramInt != 0)
      if (this.n) {
        N(0, paramInt);
      } else {
        scrollBy(0, paramInt);
      }  
  }
  
  public final boolean l(int paramInt) {
    if (g.c(this.e) != 0.0F) {
      if (M(this.e, paramInt)) {
        this.e.onAbsorb(paramInt);
      } else {
        p(-paramInt);
      } 
    } else if (g.c(this.f) != 0.0F) {
      EdgeEffect edgeEffect = this.f;
      paramInt = -paramInt;
      if (M(edgeEffect, paramInt)) {
        this.f.onAbsorb(paramInt);
      } else {
        p(paramInt);
      } 
    } else {
      return false;
    } 
    return true;
  }
  
  public final void m() {
    this.r = -1;
    this.k = false;
    F();
    stopNestedScroll(0);
    this.e.onRelease();
    this.f.onRelease();
  }
  
  public void measureChild(View paramView, int paramInt1, int paramInt2) {
    ViewGroup.LayoutParams layoutParams = paramView.getLayoutParams();
    paramView.measure(ViewGroup.getChildMeasureSpec(paramInt1, getPaddingLeft() + getPaddingRight(), layoutParams.width), View.MeasureSpec.makeMeasureSpec(0, 0));
  }
  
  public void measureChildWithMargins(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    paramView.measure(ViewGroup.getChildMeasureSpec(paramInt1, getPaddingLeft() + getPaddingRight() + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + paramInt2, marginLayoutParams.width), View.MeasureSpec.makeMeasureSpec(marginLayoutParams.topMargin + marginLayoutParams.bottomMargin, 0));
  }
  
  public boolean n(KeyEvent paramKeyEvent) {
    View view;
    this.c.setEmpty();
    boolean bool = e();
    boolean bool1 = false;
    boolean bool2 = false;
    char c1 = '';
    if (!bool) {
      bool = bool2;
      if (isFocused()) {
        bool = bool2;
        if (paramKeyEvent.getKeyCode() != 4) {
          View view1 = findFocus();
          view = view1;
          if (view1 == this)
            view = null; 
          view = FocusFinder.getInstance().findNextFocus((ViewGroup)this, view, 130);
          bool = bool2;
          if (view != null) {
            bool = bool2;
            if (view != this) {
              bool = bool2;
              if (view.requestFocus(130))
                bool = true; 
            } 
          } 
        } 
      } 
      return bool;
    } 
    bool = bool1;
    if (view.getAction() == 0) {
      int i = view.getKeyCode();
      if (i != 19) {
        if (i != 20) {
          if (i != 62) {
            if (i != 92) {
              if (i != 93) {
                if (i != 122) {
                  if (i != 123) {
                    bool = bool1;
                  } else {
                    E(130);
                    bool = bool1;
                  } 
                } else {
                  E(33);
                  bool = bool1;
                } 
              } else {
                bool = q(130);
              } 
            } else {
              bool = q(33);
            } 
          } else {
            if (view.isShiftPressed())
              c1 = '!'; 
            E(c1);
            bool = bool1;
          } 
        } else if (view.isAltPressed()) {
          bool = q(130);
        } else {
          bool = c(130);
        } 
      } else if (view.isAltPressed()) {
        bool = q(33);
      } else {
        bool = c(33);
      } 
    } 
    return bool;
  }
  
  public final View o(boolean paramBoolean, int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: iconst_2
    //   2: invokevirtual getFocusables : (I)Ljava/util/ArrayList;
    //   5: astore #14
    //   7: aload #14
    //   9: invokeinterface size : ()I
    //   14: istore #9
    //   16: aconst_null
    //   17: astore #13
    //   19: iconst_0
    //   20: istore #6
    //   22: iconst_0
    //   23: istore #7
    //   25: iload #6
    //   27: iload #9
    //   29: if_icmpge -> 246
    //   32: aload #14
    //   34: iload #6
    //   36: invokeinterface get : (I)Ljava/lang/Object;
    //   41: checkcast android/view/View
    //   44: astore #12
    //   46: aload #12
    //   48: invokevirtual getTop : ()I
    //   51: istore #10
    //   53: aload #12
    //   55: invokevirtual getBottom : ()I
    //   58: istore #8
    //   60: aload #13
    //   62: astore #11
    //   64: iload #7
    //   66: istore #5
    //   68: iload_2
    //   69: iload #8
    //   71: if_icmpge -> 232
    //   74: aload #13
    //   76: astore #11
    //   78: iload #7
    //   80: istore #5
    //   82: iload #10
    //   84: iload_3
    //   85: if_icmpge -> 232
    //   88: iload_2
    //   89: iload #10
    //   91: if_icmpge -> 106
    //   94: iload #8
    //   96: iload_3
    //   97: if_icmpge -> 106
    //   100: iconst_1
    //   101: istore #4
    //   103: goto -> 109
    //   106: iconst_0
    //   107: istore #4
    //   109: aload #13
    //   111: ifnonnull -> 125
    //   114: aload #12
    //   116: astore #11
    //   118: iload #4
    //   120: istore #5
    //   122: goto -> 232
    //   125: iload_1
    //   126: ifeq -> 139
    //   129: iload #10
    //   131: aload #13
    //   133: invokevirtual getTop : ()I
    //   136: if_icmplt -> 153
    //   139: iload_1
    //   140: ifne -> 159
    //   143: iload #8
    //   145: aload #13
    //   147: invokevirtual getBottom : ()I
    //   150: if_icmple -> 159
    //   153: iconst_1
    //   154: istore #8
    //   156: goto -> 162
    //   159: iconst_0
    //   160: istore #8
    //   162: iload #7
    //   164: ifeq -> 196
    //   167: aload #13
    //   169: astore #11
    //   171: iload #7
    //   173: istore #5
    //   175: iload #4
    //   177: ifeq -> 232
    //   180: aload #13
    //   182: astore #11
    //   184: iload #7
    //   186: istore #5
    //   188: iload #8
    //   190: ifeq -> 232
    //   193: goto -> 224
    //   196: iload #4
    //   198: ifeq -> 211
    //   201: aload #12
    //   203: astore #11
    //   205: iconst_1
    //   206: istore #5
    //   208: goto -> 232
    //   211: aload #13
    //   213: astore #11
    //   215: iload #7
    //   217: istore #5
    //   219: iload #8
    //   221: ifeq -> 232
    //   224: aload #12
    //   226: astore #11
    //   228: iload #7
    //   230: istore #5
    //   232: iinc #6, 1
    //   235: aload #11
    //   237: astore #13
    //   239: iload #5
    //   241: istore #7
    //   243: goto -> 25
    //   246: aload #13
    //   248: areturn
  }
  
  public void onAttachedToWindow() {
    super.onAttachedToWindow();
    this.i = false;
  }
  
  public boolean onGenericMotionEvent(MotionEvent paramMotionEvent) {
    if (paramMotionEvent.getAction() == 8 && !this.k) {
      float f;
      boolean bool1;
      boolean bool2;
      if (H.f(paramMotionEvent, 2)) {
        bool1 = true;
        f = paramMotionEvent.getAxisValue(9);
        bool2 = (int)paramMotionEvent.getX();
      } else if (H.f(paramMotionEvent, 4194304)) {
        f = paramMotionEvent.getAxisValue(26);
        bool2 = getWidth() / 2;
        bool1 = true;
      } else {
        bool1 = false;
        bool2 = false;
        f = 0.0F;
      } 
      if (f != 0.0F) {
        int i = (int)(f * getVerticalScrollFactorCompat());
        boolean bool = H.f(paramMotionEvent, 8194);
        J(-i, bool2, 1, bool);
        if (bool1)
          this.C.g(paramMotionEvent, bool1); 
        return true;
      } 
    } 
    return false;
  }
  
  public boolean onInterceptTouchEvent(MotionEvent paramMotionEvent) {
    ViewParent viewParent;
    int i = paramMotionEvent.getAction();
    boolean bool2 = true;
    boolean bool1 = true;
    if (i == 2 && this.k)
      return true; 
    i &= 0xFF;
    if (i != 0) {
      if (i != 1)
        if (i != 2) {
          if (i != 3) {
            if (i == 6)
              C(paramMotionEvent); 
            return this.k;
          } 
        } else {
          i = this.r;
          if (i != -1) {
            StringBuilder stringBuilder;
            int j = paramMotionEvent.findPointerIndex(i);
            if (j == -1) {
              stringBuilder = new StringBuilder();
              stringBuilder.append("Invalid pointerId=");
              stringBuilder.append(i);
              stringBuilder.append(" in onInterceptTouchEvent");
              r0.d("NestedScrollView", stringBuilder.toString());
            } else {
              i = (int)stringBuilder.getY(j);
              if (Math.abs(i - this.g) > this.o && (0x2 & getNestedScrollAxes()) == 0) {
                this.k = true;
                this.g = i;
                w();
                this.l.addMovement((MotionEvent)stringBuilder);
                this.u = 0;
                viewParent = getParent();
                if (viewParent != null)
                  viewParent.requestDisallowInterceptTouchEvent(true); 
              } 
            } 
          } 
          return this.k;
        }  
      this.k = false;
      this.r = -1;
      F();
      if (this.d.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange()))
        postInvalidateOnAnimation(); 
      stopNestedScroll(0);
    } else {
      i = (int)viewParent.getY();
      if (!t((int)viewParent.getX(), i)) {
        boolean bool = bool1;
        if (!T((MotionEvent)viewParent))
          if (!this.d.isFinished()) {
            bool = bool1;
          } else {
            bool = false;
          }  
        this.k = bool;
        F();
      } else {
        this.g = i;
        this.r = viewParent.getPointerId(0);
        u();
        this.l.addMovement((MotionEvent)viewParent);
        this.d.computeScrollOffset();
        boolean bool = bool2;
        if (!T((MotionEvent)viewParent))
          if (!this.d.isFinished()) {
            bool = bool2;
          } else {
            bool = false;
          }  
        this.k = bool;
        S(2, 0);
      } 
    } 
    return this.k;
  }
  
  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
    paramInt1 = 0;
    this.h = false;
    View view = this.j;
    if (view != null && z(view, (View)this))
      K(this.j); 
    this.j = null;
    if (!this.i) {
      if (this.w != null) {
        scrollTo(getScrollX(), this.w.a);
        this.w = null;
      } 
      if (getChildCount() > 0) {
        view = getChildAt(0);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
        paramInt1 = view.getMeasuredHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
      } 
      int j = getPaddingTop();
      int i = getPaddingBottom();
      paramInt3 = getScrollY();
      paramInt1 = f(paramInt3, paramInt4 - paramInt2 - j - i, paramInt1);
      if (paramInt1 != paramInt3)
        scrollTo(getScrollX(), paramInt1); 
    } 
    scrollTo(getScrollX(), getScrollY());
    this.i = true;
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    super.onMeasure(paramInt1, paramInt2);
    if (!this.m)
      return; 
    if (View.MeasureSpec.getMode(paramInt2) == 0)
      return; 
    if (getChildCount() > 0) {
      View view = getChildAt(0);
      FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
      paramInt2 = view.getMeasuredHeight();
      int i = getMeasuredHeight() - getPaddingTop() - getPaddingBottom() - layoutParams.topMargin - layoutParams.bottomMargin;
      if (paramInt2 < i)
        view.measure(ViewGroup.getChildMeasureSpec(paramInt1, getPaddingLeft() + getPaddingRight() + layoutParams.leftMargin + layoutParams.rightMargin, layoutParams.width), View.MeasureSpec.makeMeasureSpec(i, 1073741824)); 
    } 
  }
  
  public boolean onNestedFling(View paramView, float paramFloat1, float paramFloat2, boolean paramBoolean) {
    if (!paramBoolean) {
      dispatchNestedFling(0.0F, paramFloat2, true);
      p((int)paramFloat2);
      return true;
    } 
    return false;
  }
  
  public boolean onNestedPreFling(View paramView, float paramFloat1, float paramFloat2) {
    return dispatchNestedPreFling(paramFloat1, paramFloat2);
  }
  
  public void onNestedPreScroll(View paramView, int paramInt1, int paramInt2, int[] paramArrayOfint) {
    onNestedPreScroll(paramView, paramInt1, paramInt2, paramArrayOfint, 0);
  }
  
  public void onNestedPreScroll(View paramView, int paramInt1, int paramInt2, int[] paramArrayOfint, int paramInt3) {
    i(paramInt1, paramInt2, paramArrayOfint, null, paramInt3);
  }
  
  public void onNestedScroll(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    B(paramInt4, 0, null);
  }
  
  public void onNestedScroll(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    B(paramInt4, paramInt5, null);
  }
  
  public void onNestedScroll(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int[] paramArrayOfint) {
    B(paramInt4, paramInt5, paramArrayOfint);
  }
  
  public void onNestedScrollAccepted(View paramView1, View paramView2, int paramInt) {
    onNestedScrollAccepted(paramView1, paramView2, paramInt, 0);
  }
  
  public void onNestedScrollAccepted(View paramView1, View paramView2, int paramInt1, int paramInt2) {
    this.x.c(paramView1, paramView2, paramInt1, paramInt2);
    S(2, paramInt2);
  }
  
  public void onOverScrolled(int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2) {
    super.scrollTo(paramInt1, paramInt2);
  }
  
  public boolean onRequestFocusInDescendants(int paramInt, Rect paramRect) {
    int i;
    View view;
    if (paramInt == 2) {
      i = 130;
    } else {
      i = paramInt;
      if (paramInt == 1)
        i = 33; 
    } 
    if (paramRect == null) {
      view = FocusFinder.getInstance().findNextFocus((ViewGroup)this, null, i);
    } else {
      view = FocusFinder.getInstance().findNextFocusFromRect((ViewGroup)this, paramRect, i);
    } 
    return (view == null) ? false : (y(view) ? false : view.requestFocus(i, paramRect));
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable) {
    if (!(paramParcelable instanceof e)) {
      super.onRestoreInstanceState(paramParcelable);
      return;
    } 
    e e1 = (e)paramParcelable;
    super.onRestoreInstanceState(e1.getSuperState());
    this.w = e1;
    requestLayout();
  }
  
  public Parcelable onSaveInstanceState() {
    e e1 = new e(super.onSaveInstanceState());
    e1.a = getScrollY();
    return (Parcelable)e1;
  }
  
  public void onScrollChanged(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onScrollChanged(paramInt1, paramInt2, paramInt3, paramInt4);
    d d1 = this.A;
    if (d1 != null)
      d1.a(this, paramInt1, paramInt2, paramInt3, paramInt4); 
  }
  
  public void onSizeChanged(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onSizeChanged(paramInt1, paramInt2, paramInt3, paramInt4);
    View view = findFocus();
    if (view != null && this != view && A(view, 0, paramInt4)) {
      view.getDrawingRect(this.c);
      offsetDescendantRectToMyCoords(view, this.c);
      k(g(this.c));
    } 
  }
  
  public boolean onStartNestedScroll(View paramView1, View paramView2, int paramInt) {
    return onStartNestedScroll(paramView1, paramView2, paramInt, 0);
  }
  
  public boolean onStartNestedScroll(View paramView1, View paramView2, int paramInt1, int paramInt2) {
    boolean bool;
    if ((paramInt1 & 0x2) != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public void onStopNestedScroll(View paramView) {
    onStopNestedScroll(paramView, 0);
  }
  
  public void onStopNestedScroll(View paramView, int paramInt) {
    this.x.e(paramView, paramInt);
    stopNestedScroll(paramInt);
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    w();
    int i = paramMotionEvent.getActionMasked();
    if (i == 0)
      this.u = 0; 
    MotionEvent motionEvent = MotionEvent.obtain(paramMotionEvent);
    motionEvent.offsetLocation(0.0F, this.u);
    if (i != 0) {
      if (i != 1) {
        if (i != 2) {
          if (i != 3) {
            if (i != 5) {
              if (i == 6) {
                C(paramMotionEvent);
                this.g = (int)paramMotionEvent.getY(paramMotionEvent.findPointerIndex(this.r));
              } 
            } else {
              i = paramMotionEvent.getActionIndex();
              this.g = (int)paramMotionEvent.getY(i);
              this.r = paramMotionEvent.getPointerId(i);
            } 
          } else {
            if (this.k && getChildCount() > 0 && this.d.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange()))
              postInvalidateOnAnimation(); 
            m();
          } 
        } else {
          StringBuilder stringBuilder;
          int j = paramMotionEvent.findPointerIndex(this.r);
          if (j == -1) {
            stringBuilder = new StringBuilder();
            stringBuilder.append("Invalid pointerId=");
            stringBuilder.append(this.r);
            stringBuilder.append(" in onTouchEvent");
            r0.d("NestedScrollView", stringBuilder.toString());
          } else {
            int m = (int)stringBuilder.getY(j);
            i = this.g - m;
            int k = i - G(i, stringBuilder.getX(j));
            i = k;
            if (!this.k) {
              i = k;
              if (Math.abs(k) > this.o) {
                ViewParent viewParent = getParent();
                if (viewParent != null)
                  viewParent.requestDisallowInterceptTouchEvent(true); 
                this.k = true;
                if (k > 0) {
                  i = k - this.o;
                } else {
                  i = k + this.o;
                } 
              } 
            } 
            if (this.k) {
              i = J(i, (int)stringBuilder.getX(j), 0, false);
              this.g = m - i;
              this.u += i;
            } 
          } 
        } 
      } else {
        velocityTracker = this.l;
        velocityTracker.computeCurrentVelocity(1000, this.q);
        i = (int)velocityTracker.getYVelocity(this.r);
        if (Math.abs(i) >= this.p) {
          if (!l(i)) {
            i = -i;
            float f = i;
            if (!dispatchNestedPreFling(0.0F, f)) {
              dispatchNestedFling(0.0F, f, true);
              p(i);
            } 
          } 
        } else if (this.d.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange())) {
          postInvalidateOnAnimation();
        } 
        m();
      } 
    } else {
      if (getChildCount() == 0)
        return false; 
      if (this.k) {
        ViewParent viewParent = getParent();
        if (viewParent != null)
          viewParent.requestDisallowInterceptTouchEvent(true); 
      } 
      if (!this.d.isFinished())
        a(); 
      x((int)velocityTracker.getY(), velocityTracker.getPointerId(0));
    } 
    VelocityTracker velocityTracker = this.l;
    if (velocityTracker != null)
      velocityTracker.addMovement(motionEvent); 
    motionEvent.recycle();
    return true;
  }
  
  public void p(int paramInt) {
    if (getChildCount() > 0) {
      this.d.fling(getScrollX(), getScrollY(), 0, paramInt, 0, 0, -2147483648, 2147483647, 0, 0);
      H(true);
    } 
  }
  
  public boolean q(int paramInt) {
    int i;
    if (paramInt == 130) {
      i = 1;
    } else {
      i = 0;
    } 
    int j = getHeight();
    Rect rect = this.c;
    rect.top = 0;
    rect.bottom = j;
    if (i) {
      i = getChildCount();
      if (i > 0) {
        View view = getChildAt(i - 1);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
        this.c.bottom = view.getBottom() + layoutParams.bottomMargin + getPaddingBottom();
        Rect rect1 = this.c;
        rect1.top = rect1.bottom - j;
      } 
    } 
    rect = this.c;
    return I(paramInt, rect.top, rect.bottom);
  }
  
  public final float r(int paramInt) {
    double d1 = Math.log((Math.abs(paramInt) * 0.35F / this.a * 0.015F));
    float f = D;
    double d2 = f;
    return (float)((this.a * 0.015F) * Math.exp(f / (d2 - 1.0D) * d1));
  }
  
  public void requestChildFocus(View paramView1, View paramView2) {
    if (!this.h) {
      K(paramView2);
    } else {
      this.j = paramView2;
    } 
    super.requestChildFocus(paramView1, paramView2);
  }
  
  public boolean requestChildRectangleOnScreen(View paramView, Rect paramRect, boolean paramBoolean) {
    paramRect.offset(paramView.getLeft() - paramView.getScrollX(), paramView.getTop() - paramView.getScrollY());
    return L(paramRect, paramBoolean);
  }
  
  public void requestDisallowInterceptTouchEvent(boolean paramBoolean) {
    if (paramBoolean)
      F(); 
    super.requestDisallowInterceptTouchEvent(paramBoolean);
  }
  
  public void requestLayout() {
    this.h = true;
    super.requestLayout();
  }
  
  public boolean s(int paramInt) {
    return this.y.l(paramInt);
  }
  
  public void scrollTo(int paramInt1, int paramInt2) {
    if (getChildCount() > 0) {
      View view = getChildAt(0);
      FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
      int i5 = getWidth();
      int i3 = getPaddingLeft();
      int i2 = getPaddingRight();
      int i4 = view.getWidth();
      int i7 = layoutParams.leftMargin;
      int i6 = layoutParams.rightMargin;
      int k = getHeight();
      int i = getPaddingTop();
      int j = getPaddingBottom();
      int i1 = view.getHeight();
      int m = layoutParams.topMargin;
      int n = layoutParams.bottomMargin;
      paramInt1 = f(paramInt1, i5 - i3 - i2, i4 + i7 + i6);
      paramInt2 = f(paramInt2, k - i - j, i1 + m + n);
      if (paramInt1 != getScrollX() || paramInt2 != getScrollY())
        super.scrollTo(paramInt1, paramInt2); 
    } 
  }
  
  public void setFillViewport(boolean paramBoolean) {
    if (paramBoolean != this.m) {
      this.m = paramBoolean;
      requestLayout();
    } 
  }
  
  public void setNestedScrollingEnabled(boolean paramBoolean) {
    this.y.n(paramBoolean);
  }
  
  public void setOnScrollChangeListener(d paramd) {
    this.A = paramd;
  }
  
  public void setSmoothScrollingEnabled(boolean paramBoolean) {
    this.n = paramBoolean;
  }
  
  public boolean shouldDelayChildPressedState() {
    return true;
  }
  
  public boolean startNestedScroll(int paramInt) {
    return S(paramInt, 0);
  }
  
  public void stopNestedScroll() {
    stopNestedScroll(0);
  }
  
  public void stopNestedScroll(int paramInt) {
    this.y.s(paramInt);
  }
  
  public final boolean t(int paramInt1, int paramInt2) {
    int i = getChildCount();
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (i > 0) {
      i = getScrollY();
      View view = getChildAt(0);
      bool1 = bool2;
      if (paramInt2 >= view.getTop() - i) {
        bool1 = bool2;
        if (paramInt2 < view.getBottom() - i) {
          bool1 = bool2;
          if (paramInt1 >= view.getLeft()) {
            bool1 = bool2;
            if (paramInt1 < view.getRight())
              bool1 = true; 
          } 
        } 
      } 
    } 
    return bool1;
  }
  
  public final void u() {
    VelocityTracker velocityTracker = this.l;
    if (velocityTracker == null) {
      this.l = VelocityTracker.obtain();
    } else {
      velocityTracker.clear();
    } 
  }
  
  public final void v() {
    this.d = new OverScroller(getContext());
    setFocusable(true);
    setDescendantFocusability(262144);
    setWillNotDraw(false);
    ViewConfiguration viewConfiguration = ViewConfiguration.get(getContext());
    this.o = viewConfiguration.getScaledTouchSlop();
    this.p = viewConfiguration.getScaledMinimumFlingVelocity();
    this.q = viewConfiguration.getScaledMaximumFlingVelocity();
  }
  
  public final void w() {
    if (this.l == null)
      this.l = VelocityTracker.obtain(); 
  }
  
  public final void x(int paramInt1, int paramInt2) {
    this.g = paramInt1;
    this.r = paramInt2;
    S(2, 0);
  }
  
  public final boolean y(View paramView) {
    return A(paramView, 0, getHeight()) ^ true;
  }
  
  public static class a extends dbxyzptlk.h2.a {
    public void onInitializeAccessibilityEvent(View param1View, AccessibilityEvent param1AccessibilityEvent) {
      boolean bool;
      super.onInitializeAccessibilityEvent(param1View, param1AccessibilityEvent);
      NestedScrollView nestedScrollView = (NestedScrollView)param1View;
      param1AccessibilityEvent.setClassName(ScrollView.class.getName());
      if (nestedScrollView.getScrollRange() > 0) {
        bool = true;
      } else {
        bool = false;
      } 
      param1AccessibilityEvent.setScrollable(bool);
      param1AccessibilityEvent.setScrollX(nestedScrollView.getScrollX());
      param1AccessibilityEvent.setScrollY(nestedScrollView.getScrollY());
      v.a((AccessibilityRecord)param1AccessibilityEvent, nestedScrollView.getScrollX());
      v.b((AccessibilityRecord)param1AccessibilityEvent, nestedScrollView.getScrollRange());
    }
    
    public void onInitializeAccessibilityNodeInfo(View param1View, t param1t) {
      super.onInitializeAccessibilityNodeInfo(param1View, param1t);
      NestedScrollView nestedScrollView = (NestedScrollView)param1View;
      param1t.i0(ScrollView.class.getName());
      if (nestedScrollView.isEnabled()) {
        int i = nestedScrollView.getScrollRange();
        if (i > 0) {
          param1t.K0(true);
          if (nestedScrollView.getScrollY() > 0) {
            param1t.b(t.a.r);
            param1t.b(t.a.C);
          } 
          if (nestedScrollView.getScrollY() < i) {
            param1t.b(t.a.q);
            param1t.b(t.a.E);
          } 
        } 
      } 
    }
    
    public boolean performAccessibilityAction(View param1View, int param1Int, Bundle param1Bundle) {
      if (super.performAccessibilityAction(param1View, param1Int, param1Bundle))
        return true; 
      NestedScrollView nestedScrollView = (NestedScrollView)param1View;
      if (!nestedScrollView.isEnabled())
        return false; 
      int j = nestedScrollView.getHeight();
      Rect rect = new Rect();
      int i = j;
      if (nestedScrollView.getMatrix().isIdentity()) {
        i = j;
        if (nestedScrollView.getGlobalVisibleRect(rect))
          i = rect.height(); 
      } 
      if (param1Int != 4096)
        if (param1Int != 8192 && param1Int != 16908344) {
          if (param1Int != 16908346)
            return false; 
        } else {
          param1Int = nestedScrollView.getPaddingBottom();
          j = nestedScrollView.getPaddingTop();
          param1Int = Math.max(nestedScrollView.getScrollY() - i - param1Int - j, 0);
          if (param1Int != nestedScrollView.getScrollY()) {
            nestedScrollView.R(0, param1Int, true);
            return true;
          } 
          return false;
        }  
      param1Int = nestedScrollView.getPaddingBottom();
      j = nestedScrollView.getPaddingTop();
      param1Int = Math.min(nestedScrollView.getScrollY() + i - param1Int - j, nestedScrollView.getScrollRange());
      if (param1Int != nestedScrollView.getScrollY()) {
        nestedScrollView.R(0, param1Int, true);
        return true;
      } 
      return false;
    }
  }
  
  class NestedScrollView {}
  
  public class c implements u {
    public final NestedScrollView a;
    
    public c(NestedScrollView this$0) {}
    
    public float a() {
      return -this.a.getVerticalScrollFactorCompat();
    }
    
    public boolean b(float param1Float) {
      if (param1Float == 0.0F)
        return false; 
      c();
      this.a.p((int)param1Float);
      return true;
    }
    
    public void c() {
      NestedScrollView.b(this.a).abortAnimation();
    }
  }
  
  class NestedScrollView {}
  
  class NestedScrollView {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\core\widget\NestedScrollView.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */