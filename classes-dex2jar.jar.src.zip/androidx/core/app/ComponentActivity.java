package androidx.core.app;

import android.app.Activity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.f;
import androidx.lifecycle.j;
import androidx.lifecycle.n;
import dbxyzptlk.DI.s;
import dbxyzptlk.V.E;
import dbxyzptlk.h2.y;
import kotlin.Metadata;

@Metadata(d1 = {"\000d\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\021\n\002\020\016\n\000\n\002\020\013\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\006\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\006\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\005\b\027\030\0002\0020\0012\0020\0022\0020\003:\001/B\007¢\006\004\b\004\020\005J\037\020\n\032\0020\t2\016\020\b\032\n\022\004\022\0020\007\030\0010\006H\002¢\006\004\b\n\020\013J\027\020\017\032\0020\0162\006\020\r\032\0020\fH\027¢\006\004\b\017\020\020J\031\020\023\032\0020\0162\b\020\022\032\004\030\0010\021H\024¢\006\004\b\023\020\024J\027\020\026\032\0020\0162\006\020\025\032\0020\021H\025¢\006\004\b\026\020\024J)\020\032\032\004\030\0018\000\"\b\b\000\020\027*\0020\f2\f\020\031\032\b\022\004\022\0028\0000\030H\027¢\006\004\b\032\020\033J\027\020\036\032\0020\t2\006\020\035\032\0020\034H\027¢\006\004\b\036\020\037J\027\020 \032\0020\t2\006\020\035\032\0020\034H\026¢\006\004\b \020\037J\027\020!\032\0020\t2\006\020\035\032\0020\034H\026¢\006\004\b!\020\037J\037\020\"\032\0020\t2\016\020\b\032\n\022\004\022\0020\007\030\0010\006H\004¢\006\004\b\"\020\013R.\020$\032\026\022\f\022\n\022\006\b\001\022\0020\f0\030\022\004\022\0020\f0#8\002X\004¢\006\f\n\004\b$\020%\022\004\b&\020\005R\032\020(\032\0020'8\002X\004¢\006\f\n\004\b(\020)\022\004\b*\020\005R\024\020.\032\0020+8VX\004¢\006\006\032\004\b,\020-¨\0060"}, d2 = {"Landroidx/core/app/ComponentActivity;", "Landroid/app/Activity;", "Landroidx/lifecycle/LifecycleOwner;", "Ldbxyzptlk/h2/y$a;", "<init>", "()V", "", "", "args", "", "shouldSkipDump", "([Ljava/lang/String;)Z", "Landroidx/core/app/ComponentActivity$a;", "extraData", "Ldbxyzptlk/pI/D;", "putExtraData", "(Landroidx/core/app/ComponentActivity$a;)V", "Landroid/os/Bundle;", "savedInstanceState", "onCreate", "(Landroid/os/Bundle;)V", "outState", "onSaveInstanceState", "T", "Ljava/lang/Class;", "extraDataClass", "getExtraData", "(Ljava/lang/Class;)Landroidx/core/app/ComponentActivity$a;", "Landroid/view/KeyEvent;", "event", "superDispatchKeyEvent", "(Landroid/view/KeyEvent;)Z", "dispatchKeyShortcutEvent", "dispatchKeyEvent", "shouldDumpInternalState", "Ldbxyzptlk/V/E;", "extraDataMap", "Ldbxyzptlk/V/E;", "getExtraDataMap$annotations", "Landroidx/lifecycle/j;", "lifecycleRegistry", "Landroidx/lifecycle/j;", "getLifecycleRegistry$annotations", "Landroidx/lifecycle/f;", "getLifecycle", "()Landroidx/lifecycle/f;", "lifecycle", "a", "core_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public class ComponentActivity extends Activity implements LifecycleOwner, y.a {
  private final E<Class<? extends a>, a> extraDataMap = new E();
  
  private final j lifecycleRegistry = new j((LifecycleOwner)this);
  
  private final boolean shouldSkipDump(String[] paramArrayOfString) {
    // Byte code:
    //   0: iconst_0
    //   1: istore #5
    //   3: iconst_0
    //   4: istore #4
    //   6: iconst_0
    //   7: istore_3
    //   8: iload #4
    //   10: istore_2
    //   11: aload_1
    //   12: ifnull -> 209
    //   15: aload_1
    //   16: arraylength
    //   17: ifne -> 26
    //   20: iload #4
    //   22: istore_2
    //   23: goto -> 209
    //   26: aload_1
    //   27: iconst_0
    //   28: aaload
    //   29: astore_1
    //   30: aload_1
    //   31: invokevirtual hashCode : ()I
    //   34: lookupswitch default -> 84, -645125871 -> 181, 100470631 -> 151, 472614934 -> 136, 1159329357 -> 107, 1455016274 -> 90
    //   84: iload #4
    //   86: istore_2
    //   87: goto -> 209
    //   90: aload_1
    //   91: ldc '--autofill'
    //   93: invokevirtual equals : (Ljava/lang/Object;)Z
    //   96: ifne -> 105
    //   99: iload #4
    //   101: istore_2
    //   102: goto -> 209
    //   105: iconst_1
    //   106: ireturn
    //   107: aload_1
    //   108: ldc '--contentcapture'
    //   110: invokevirtual equals : (Ljava/lang/Object;)Z
    //   113: ifne -> 122
    //   116: iload #4
    //   118: istore_2
    //   119: goto -> 209
    //   122: iload_3
    //   123: istore_2
    //   124: getstatic android/os/Build$VERSION.SDK_INT : I
    //   127: bipush #29
    //   129: if_icmplt -> 134
    //   132: iconst_1
    //   133: istore_2
    //   134: iload_2
    //   135: ireturn
    //   136: aload_1
    //   137: ldc '--list-dumpables'
    //   139: invokevirtual equals : (Ljava/lang/Object;)Z
    //   142: ifne -> 166
    //   145: iload #4
    //   147: istore_2
    //   148: goto -> 209
    //   151: aload_1
    //   152: ldc '--dump-dumpable'
    //   154: invokevirtual equals : (Ljava/lang/Object;)Z
    //   157: ifne -> 166
    //   160: iload #4
    //   162: istore_2
    //   163: goto -> 209
    //   166: iload #5
    //   168: istore_2
    //   169: getstatic android/os/Build$VERSION.SDK_INT : I
    //   172: bipush #33
    //   174: if_icmplt -> 179
    //   177: iconst_1
    //   178: istore_2
    //   179: iload_2
    //   180: ireturn
    //   181: aload_1
    //   182: ldc '--translation'
    //   184: invokevirtual equals : (Ljava/lang/Object;)Z
    //   187: ifne -> 196
    //   190: iload #4
    //   192: istore_2
    //   193: goto -> 209
    //   196: iload #4
    //   198: istore_2
    //   199: getstatic android/os/Build$VERSION.SDK_INT : I
    //   202: bipush #31
    //   204: if_icmplt -> 209
    //   207: iconst_1
    //   208: istore_2
    //   209: iload_2
    //   210: ireturn
  }
  
  public boolean dispatchKeyEvent(KeyEvent paramKeyEvent) {
    boolean bool;
    s.h(paramKeyEvent, "event");
    View view = getWindow().getDecorView();
    s.g(view, "window.decorView");
    if (y.d(view, paramKeyEvent)) {
      bool = true;
    } else {
      bool = y.e((y.a)this, view, (Window.Callback)this, paramKeyEvent);
    } 
    return bool;
  }
  
  public boolean dispatchKeyShortcutEvent(KeyEvent paramKeyEvent) {
    boolean bool;
    s.h(paramKeyEvent, "event");
    View view = getWindow().getDecorView();
    s.g(view, "window.decorView");
    if (y.d(view, paramKeyEvent)) {
      bool = true;
    } else {
      bool = super.dispatchKeyShortcutEvent(paramKeyEvent);
    } 
    return bool;
  }
  
  public <T extends a> T getExtraData(Class<T> paramClass) {
    s.h(paramClass, "extraDataClass");
    return (T)this.extraDataMap.get(paramClass);
  }
  
  public f getLifecycle() {
    return (f)this.lifecycleRegistry;
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    n.b.c((Activity)this);
  }
  
  public void onSaveInstanceState(Bundle paramBundle) {
    s.h(paramBundle, "outState");
    this.lifecycleRegistry.n(f.b.CREATED);
    super.onSaveInstanceState(paramBundle);
  }
  
  public void putExtraData(a parama) {
    s.h(parama, "extraData");
    this.extraDataMap.put(parama.getClass(), parama);
  }
  
  public final boolean shouldDumpInternalState(String[] paramArrayOfString) {
    return shouldSkipDump(paramArrayOfString) ^ true;
  }
  
  public boolean superDispatchKeyEvent(KeyEvent paramKeyEvent) {
    s.h(paramKeyEvent, "event");
    return super.dispatchKeyEvent(paramKeyEvent);
  }
  
  class ComponentActivity {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\core\app\ComponentActivity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */