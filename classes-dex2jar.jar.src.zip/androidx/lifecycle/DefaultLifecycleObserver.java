package androidx.lifecycle;

import dbxyzptlk.DI.s;
import dbxyzptlk.U2.h;
import kotlin.Metadata;

@Metadata(d1 = {"\000\026\n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\b\bf\030\0002\0020\001J\027\020\005\032\0020\0042\006\020\003\032\0020\002H\026¢\006\004\b\005\020\006J\027\020\007\032\0020\0042\006\020\003\032\0020\002H\026¢\006\004\b\007\020\006J\027\020\b\032\0020\0042\006\020\003\032\0020\002H\026¢\006\004\b\b\020\006J\027\020\t\032\0020\0042\006\020\003\032\0020\002H\026¢\006\004\b\t\020\006J\027\020\n\032\0020\0042\006\020\003\032\0020\002H\026¢\006\004\b\n\020\006J\027\020\013\032\0020\0042\006\020\003\032\0020\002H\026¢\006\004\b\013\020\006ø\001\000\002\006\n\004\b!0\001¨\006\fÀ\006\001"}, d2 = {"Landroidx/lifecycle/DefaultLifecycleObserver;", "Ldbxyzptlk/U2/h;", "Landroidx/lifecycle/LifecycleOwner;", "owner", "Ldbxyzptlk/pI/D;", "onCreate", "(Landroidx/lifecycle/LifecycleOwner;)V", "onStart", "onResume", "onPause", "onStop", "onDestroy", "lifecycle-common"}, k = 1, mv = {1, 8, 0}, xi = 48)
public interface DefaultLifecycleObserver extends h {
  default void onCreate(LifecycleOwner paramLifecycleOwner) {
    s.h(paramLifecycleOwner, "owner");
  }
  
  default void onDestroy(LifecycleOwner paramLifecycleOwner) {
    s.h(paramLifecycleOwner, "owner");
  }
  
  default void onPause(LifecycleOwner paramLifecycleOwner) {
    s.h(paramLifecycleOwner, "owner");
  }
  
  default void onResume(LifecycleOwner paramLifecycleOwner) {
    s.h(paramLifecycleOwner, "owner");
  }
  
  default void onStart(LifecycleOwner paramLifecycleOwner) {
    s.h(paramLifecycleOwner, "owner");
  }
  
  default void onStop(LifecycleOwner paramLifecycleOwner) {
    s.h(paramLifecycleOwner, "owner");
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\lifecycle\DefaultLifecycleObserver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */