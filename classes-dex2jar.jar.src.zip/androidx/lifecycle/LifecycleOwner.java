package androidx.lifecycle;

import kotlin.Metadata;

@Metadata(d1 = {"\000\020\n\002\030\002\n\002\020\000\n\002\030\002\n\002\b\004\bf\030\0002\0020\001R\024\020\005\032\0020\0028&X¦\004¢\006\006\032\004\b\003\020\004ø\001\000\002\006\n\004\b!0\001¨\006\006À\006\001"}, d2 = {"Landroidx/lifecycle/LifecycleOwner;", "", "Landroidx/lifecycle/f;", "getLifecycle", "()Landroidx/lifecycle/f;", "lifecycle", "lifecycle-common"}, k = 1, mv = {1, 8, 0}, xi = 48)
public interface LifecycleOwner {
  f getLifecycle();
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\lifecycle\LifecycleOwner.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */