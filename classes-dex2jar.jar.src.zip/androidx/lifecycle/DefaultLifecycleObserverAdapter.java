package androidx.lifecycle;

import dbxyzptlk.DI.s;
import kotlin.Metadata;

@Metadata(d1 = {"\000$\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\004\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\007\b\000\030\0002\0020\001B\031\022\006\020\003\032\0020\002\022\b\020\004\032\004\030\0010\001¢\006\004\b\005\020\006J\037\020\f\032\0020\0132\006\020\b\032\0020\0072\006\020\n\032\0020\tH\026¢\006\004\b\f\020\rR\024\020\003\032\0020\0028\002X\004¢\006\006\n\004\b\016\020\017R\026\020\004\032\004\030\0010\0018\002X\004¢\006\006\n\004\b\020\020\021¨\006\022"}, d2 = {"Landroidx/lifecycle/DefaultLifecycleObserverAdapter;", "Landroidx/lifecycle/LifecycleEventObserver;", "Landroidx/lifecycle/DefaultLifecycleObserver;", "defaultLifecycleObserver", "lifecycleEventObserver", "<init>", "(Landroidx/lifecycle/DefaultLifecycleObserver;Landroidx/lifecycle/LifecycleEventObserver;)V", "Landroidx/lifecycle/LifecycleOwner;", "source", "Landroidx/lifecycle/f$a;", "event", "Ldbxyzptlk/pI/D;", "f", "(Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/f$a;)V", "a", "Landroidx/lifecycle/DefaultLifecycleObserver;", "b", "Landroidx/lifecycle/LifecycleEventObserver;", "lifecycle-common"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class DefaultLifecycleObserverAdapter implements LifecycleEventObserver {
  public final DefaultLifecycleObserver a;
  
  public final LifecycleEventObserver b;
  
  public DefaultLifecycleObserverAdapter(DefaultLifecycleObserver paramDefaultLifecycleObserver, LifecycleEventObserver paramLifecycleEventObserver) {
    this.a = paramDefaultLifecycleObserver;
    this.b = paramLifecycleEventObserver;
  }
  
  public void f(LifecycleOwner paramLifecycleOwner, f.a parama) {
    s.h(paramLifecycleOwner, "source");
    s.h(parama, "event");
    switch (a.a[parama.ordinal()]) {
      case 7:
        throw new IllegalArgumentException("ON_ANY must not been send by anybody");
      case 6:
        this.a.onDestroy(paramLifecycleOwner);
        break;
      case 5:
        this.a.onStop(paramLifecycleOwner);
        break;
      case 4:
        this.a.onPause(paramLifecycleOwner);
        break;
      case 3:
        this.a.onResume(paramLifecycleOwner);
        break;
      case 2:
        this.a.onStart(paramLifecycleOwner);
        break;
      case 1:
        this.a.onCreate(paramLifecycleOwner);
        break;
    } 
    LifecycleEventObserver lifecycleEventObserver = this.b;
    if (lifecycleEventObserver != null)
      lifecycleEventObserver.f(paramLifecycleOwner, parama); 
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\lifecycle\DefaultLifecycleObserverAdapter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */