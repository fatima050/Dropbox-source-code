package androidx.lifecycle;

import dbxyzptlk.DI.s;
import dbxyzptlk.U2.s;
import kotlin.Metadata;

@Metadata(d1 = {"\000$\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\003\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\005\b\000\030\0002\0020\001B\017\022\006\020\003\032\0020\002¢\006\004\b\004\020\005J\037\020\013\032\0020\n2\006\020\007\032\0020\0062\006\020\t\032\0020\bH\026¢\006\004\b\013\020\fR\024\020\003\032\0020\0028\002X\004¢\006\006\n\004\b\r\020\016¨\006\017"}, d2 = {"Landroidx/lifecycle/SavedStateHandleAttacher;", "Landroidx/lifecycle/LifecycleEventObserver;", "Ldbxyzptlk/U2/s;", "provider", "<init>", "(Ldbxyzptlk/U2/s;)V", "Landroidx/lifecycle/LifecycleOwner;", "source", "Landroidx/lifecycle/f$a;", "event", "Ldbxyzptlk/pI/D;", "f", "(Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/f$a;)V", "a", "Ldbxyzptlk/U2/s;", "lifecycle-viewmodel-savedstate_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class SavedStateHandleAttacher implements LifecycleEventObserver {
  public final s a;
  
  public SavedStateHandleAttacher(s params) {
    this.a = params;
  }
  
  public void f(LifecycleOwner paramLifecycleOwner, f.a parama) {
    s.h(paramLifecycleOwner, "source");
    s.h(parama, "event");
    if (parama == f.a.ON_CREATE) {
      paramLifecycleOwner.getLifecycle().d(this);
      this.a.c();
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Next event must be ON_CREATE, it was ");
    stringBuilder.append(parama);
    throw new IllegalStateException(stringBuilder.toString().toString());
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\lifecycle\SavedStateHandleAttacher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */