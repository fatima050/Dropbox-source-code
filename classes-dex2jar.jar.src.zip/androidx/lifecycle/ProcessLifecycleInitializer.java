package androidx.lifecycle;

import android.content.Context;
import dbxyzptlk.DI.s;
import dbxyzptlk.O4.a;
import dbxyzptlk.O4.b;
import dbxyzptlk.qI.s;
import java.util.List;
import kotlin.Metadata;

@Metadata(d1 = {"\000$\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\003\n\002\020 \n\002\030\002\n\002\b\003\030\0002\b\022\004\022\0020\0020\001B\007¢\006\004\b\003\020\004J\027\020\007\032\0020\0022\006\020\006\032\0020\005H\026¢\006\004\b\007\020\bJ!\020\013\032\024\022\020\022\016\022\n\b\001\022\006\022\002\b\0030\0010\n0\tH\026¢\006\004\b\013\020\f¨\006\r"}, d2 = {"Landroidx/lifecycle/ProcessLifecycleInitializer;", "Ldbxyzptlk/O4/b;", "Landroidx/lifecycle/LifecycleOwner;", "<init>", "()V", "Landroid/content/Context;", "context", "b", "(Landroid/content/Context;)Landroidx/lifecycle/LifecycleOwner;", "", "Ljava/lang/Class;", "dependencies", "()Ljava/util/List;", "lifecycle-process_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class ProcessLifecycleInitializer implements b<LifecycleOwner> {
  public LifecycleOwner b(Context paramContext) {
    s.h(paramContext, "context");
    a a = a.e(paramContext);
    s.g(a, "getInstance(context)");
    if (a.g(ProcessLifecycleInitializer.class)) {
      h.a(paramContext);
      ProcessLifecycleOwner.b b1 = ProcessLifecycleOwner.i;
      b1.b(paramContext);
      return b1.a();
    } 
    throw new IllegalStateException("ProcessLifecycleInitializer cannot be initialized lazily.\n               Please ensure that you have:\n               <meta-data\n                   android:name='androidx.lifecycle.ProcessLifecycleInitializer'\n                   android:value='androidx.startup' />\n               under InitializationProvider in your AndroidManifest.xml");
  }
  
  public List<Class<? extends b<?>>> dependencies() {
    return s.m();
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\lifecycle\ProcessLifecycleInitializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */