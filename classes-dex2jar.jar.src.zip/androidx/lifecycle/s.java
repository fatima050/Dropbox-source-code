package androidx.lifecycle;

import dbxyzptlk.BI.a;
import dbxyzptlk.CI.a;
import dbxyzptlk.LI.d;
import dbxyzptlk.U2.v;
import dbxyzptlk.U2.y;
import dbxyzptlk.X2.a;
import dbxyzptlk.pI.j;
import kotlin.Metadata;

@Metadata(d1 = {"\0004\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\020\013\n\002\b\r\030\000*\b\b\000\020\002*\0020\0012\b\022\004\022\0028\0000\003BC\b\007\022\f\020\005\032\b\022\004\022\0028\0000\004\022\f\020\b\032\b\022\004\022\0020\0070\006\022\f\020\n\032\b\022\004\022\0020\t0\006\022\016\b\002\020\f\032\b\022\004\022\0020\0130\006¢\006\004\b\r\020\016J\017\020\020\032\0020\017H\026¢\006\004\b\020\020\021R\032\020\005\032\b\022\004\022\0028\0000\0048\002X\004¢\006\006\n\004\b\020\020\022R\032\020\b\032\b\022\004\022\0020\0070\0068\002X\004¢\006\006\n\004\b\023\020\024R\032\020\n\032\b\022\004\022\0020\t0\0068\002X\004¢\006\006\n\004\b\025\020\024R\032\020\f\032\b\022\004\022\0020\0130\0068\002X\004¢\006\006\n\004\b\026\020\024R\030\020\031\032\004\030\0018\0008\002@\002X\016¢\006\006\n\004\b\027\020\030R\024\020\033\032\0028\0008VX\004¢\006\006\032\004\b\023\020\032¨\006\034"}, d2 = {"Landroidx/lifecycle/s;", "Ldbxyzptlk/U2/v;", "VM", "Ldbxyzptlk/pI/j;", "Ldbxyzptlk/LI/d;", "viewModelClass", "Lkotlin/Function0;", "Ldbxyzptlk/U2/y;", "storeProducer", "Landroidx/lifecycle/t$b;", "factoryProducer", "Ldbxyzptlk/X2/a;", "extrasProducer", "<init>", "(Ldbxyzptlk/LI/d;Ldbxyzptlk/CI/a;Ldbxyzptlk/CI/a;Ldbxyzptlk/CI/a;)V", "", "a", "()Z", "Ldbxyzptlk/LI/d;", "b", "Ldbxyzptlk/CI/a;", "c", "d", "e", "Ldbxyzptlk/U2/v;", "cached", "()Ldbxyzptlk/U2/v;", "value", "lifecycle-viewmodel_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class s<VM extends v> implements j<VM> {
  public final d<VM> a;
  
  public final a<y> b;
  
  public final a<t.b> c;
  
  public final a<a> d;
  
  public VM e;
  
  public s(d<VM> paramd, a<? extends y> parama, a<? extends t.b> parama1, a<? extends a> parama2) {
    this.a = paramd;
    this.b = (a)parama;
    this.c = (a)parama1;
    this.d = (a)parama2;
  }
  
  public boolean a() {
    boolean bool;
    if (this.e != null) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public VM b() {
    t.b b;
    VM vM2 = this.e;
    VM vM1 = vM2;
    if (vM2 == null) {
      b = (t.b)this.c.invoke();
      b = (new t((y)this.b.invoke(), b, (a)this.d.invoke())).a(a.b(this.a));
      this.e = (VM)b;
    } 
    return (VM)b;
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\lifecycle\s.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */