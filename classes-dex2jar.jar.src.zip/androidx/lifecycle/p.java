package androidx.lifecycle;

import android.os.Bundle;
import dbxyzptlk.DI.s;
import dbxyzptlk.U2.s;
import dbxyzptlk.U2.t;
import dbxyzptlk.U2.z;
import kotlin.Metadata;

@Metadata(d1 = {"\000F\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\004\n\002\020\016\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\004\032!\020\004\032\0020\003\"\f\b\000\020\002*\0020\000*\0020\001*\0028\000H\007¢\006\004\b\004\020\005\0321\020\r\032\0020\f2\006\020\006\032\0020\0002\006\020\007\032\0020\0012\006\020\t\032\0020\b2\b\020\013\032\004\030\0010\nH\002¢\006\004\b\r\020\016\032\023\020\020\032\0020\f*\0020\017H\007¢\006\004\b\020\020\021\"\032\020\024\032\b\022\004\022\0020\0000\0228\006X\004¢\006\006\n\004\b\r\020\023\"\032\020\025\032\b\022\004\022\0020\0010\0228\006X\004¢\006\006\n\004\b\020\020\023\"\032\020\026\032\b\022\004\022\0020\n0\0228\006X\004¢\006\006\n\004\b\004\020\023\"\030\020\032\032\0020\027*\0020\0018@X\004¢\006\006\032\004\b\030\020\031\"\030\020\036\032\0020\033*\0020\0008@X\004¢\006\006\032\004\b\034\020\035¨\006\037"}, d2 = {"Ldbxyzptlk/J4/d;", "Ldbxyzptlk/U2/z;", "T", "Ldbxyzptlk/pI/D;", "c", "(Ldbxyzptlk/J4/d;)V", "savedStateRegistryOwner", "viewModelStoreOwner", "", "key", "Landroid/os/Bundle;", "defaultArgs", "Landroidx/lifecycle/o;", "a", "(Ldbxyzptlk/J4/d;Ldbxyzptlk/U2/z;Ljava/lang/String;Landroid/os/Bundle;)Landroidx/lifecycle/o;", "Ldbxyzptlk/X2/a;", "b", "(Ldbxyzptlk/X2/a;)Landroidx/lifecycle/o;", "Ldbxyzptlk/X2/a$b;", "Ldbxyzptlk/X2/a$b;", "SAVED_STATE_REGISTRY_OWNER_KEY", "VIEW_MODEL_STORE_OWNER_KEY", "DEFAULT_ARGS_KEY", "Ldbxyzptlk/U2/t;", "e", "(Ldbxyzptlk/U2/z;)Ldbxyzptlk/U2/t;", "savedStateHandlesVM", "Ldbxyzptlk/U2/s;", "d", "(Ldbxyzptlk/J4/d;)Ldbxyzptlk/U2/s;", "savedStateHandlesProvider", "lifecycle-viewmodel-savedstate_release"}, k = 2, mv = {1, 8, 0}, xi = 48)
public final class p {
  public static final dbxyzptlk.X2.a.b<dbxyzptlk.J4.d> a = new b();
  
  public static final dbxyzptlk.X2.a.b<z> b = new c();
  
  public static final dbxyzptlk.X2.a.b<Bundle> c = new a();
  
  public static final o a(dbxyzptlk.J4.d paramd, z paramz, String paramString, Bundle paramBundle) {
    s s = d(paramd);
    t t = e(paramz);
    o o2 = (o)t.F().get(paramString);
    o o1 = o2;
    if (o2 == null) {
      o1 = o.f.a(s.a(paramString), paramBundle);
      t.F().put(paramString, o1);
    } 
    return o1;
  }
  
  public static final o b(dbxyzptlk.X2.a parama) {
    s.h(parama, "<this>");
    dbxyzptlk.J4.d d = (dbxyzptlk.J4.d)parama.a(a);
    if (d != null) {
      z z = (z)parama.a(b);
      if (z != null) {
        Bundle bundle = (Bundle)parama.a(c);
        String str = (String)parama.a(t.c.d);
        if (str != null)
          return a(d, z, str, bundle); 
        throw new IllegalArgumentException("CreationExtras must have a value by `VIEW_MODEL_KEY`");
      } 
      throw new IllegalArgumentException("CreationExtras must have a value by `VIEW_MODEL_STORE_OWNER_KEY`");
    } 
    throw new IllegalArgumentException("CreationExtras must have a value by `SAVED_STATE_REGISTRY_OWNER_KEY`");
  }
  
  public static final <T extends dbxyzptlk.J4.d & z> void c(T paramT) {
    s.h(paramT, "<this>");
    f.b b1 = paramT.getLifecycle().b();
    if (b1 == f.b.INITIALIZED || b1 == f.b.CREATED) {
      if (paramT.getSavedStateRegistry().c("androidx.lifecycle.internal.SavedStateHandlesProvider") == null) {
        s s = new s(paramT.getSavedStateRegistry(), (z)paramT);
        paramT.getSavedStateRegistry().i("androidx.lifecycle.internal.SavedStateHandlesProvider", (androidx.savedstate.a.c)s);
        paramT.getLifecycle().a(new SavedStateHandleAttacher(s));
      } 
      return;
    } 
    throw new IllegalArgumentException("Failed requirement.");
  }
  
  public static final s d(dbxyzptlk.J4.d paramd) {
    s.h(paramd, "<this>");
    androidx.savedstate.a.c c = paramd.getSavedStateRegistry().c("androidx.lifecycle.internal.SavedStateHandlesProvider");
    if (c instanceof s) {
      s s = (s)c;
    } else {
      c = null;
    } 
    if (c != null)
      return (s)c; 
    throw new IllegalStateException("enableSavedStateHandles() wasn't called prior to createSavedStateHandle() call");
  }
  
  public static final t e(z paramz) {
    s.h(paramz, "<this>");
    return (new t(paramz, new d())).<t>b("androidx.lifecycle.internal.SavedStateHandlesVM", t.class);
  }
  
  @Metadata(d1 = {"\000\017\n\000\n\002\030\002\n\002\030\002\n\000*\001\000\b\n\030\0002\b\022\004\022\0020\0020\001¨\006\003"}, d2 = {"androidx/lifecycle/p$a", "Ldbxyzptlk/X2/a$b;", "Landroid/os/Bundle;", "lifecycle-viewmodel-savedstate_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class a implements dbxyzptlk.X2.a.b<Bundle> {}
  
  @Metadata(d1 = {"\000\017\n\000\n\002\030\002\n\002\030\002\n\000*\001\000\b\n\030\0002\b\022\004\022\0020\0020\001¨\006\003"}, d2 = {"androidx/lifecycle/p$b", "Ldbxyzptlk/X2/a$b;", "Ldbxyzptlk/J4/d;", "lifecycle-viewmodel-savedstate_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class b implements dbxyzptlk.X2.a.b<dbxyzptlk.J4.d> {}
  
  @Metadata(d1 = {"\000\017\n\000\n\002\030\002\n\002\030\002\n\000*\001\000\b\n\030\0002\b\022\004\022\0020\0020\001¨\006\003"}, d2 = {"androidx/lifecycle/p$c", "Ldbxyzptlk/X2/a$b;", "Ldbxyzptlk/U2/z;", "lifecycle-viewmodel-savedstate_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class c implements dbxyzptlk.X2.a.b<z> {}
  
  @Metadata(d1 = {"\000\035\n\000\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\004*\001\000\b\n\030\0002\0020\001J/\020\b\032\0028\000\"\b\b\000\020\003*\0020\0022\f\020\005\032\b\022\004\022\0028\0000\0042\006\020\007\032\0020\006H\026¢\006\004\b\b\020\t¨\006\n"}, d2 = {"androidx/lifecycle/p$d", "Landroidx/lifecycle/t$b;", "Ldbxyzptlk/U2/v;", "T", "Ljava/lang/Class;", "modelClass", "Ldbxyzptlk/X2/a;", "extras", "a", "(Ljava/lang/Class;Ldbxyzptlk/X2/a;)Ldbxyzptlk/U2/v;", "lifecycle-viewmodel-savedstate_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class d implements t.b {
    public <T extends dbxyzptlk.U2.v> T a(Class<T> param1Class, dbxyzptlk.X2.a param1a) {
      s.h(param1Class, "modelClass");
      s.h(param1a, "extras");
      return (T)new t();
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\lifecycle\p.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */