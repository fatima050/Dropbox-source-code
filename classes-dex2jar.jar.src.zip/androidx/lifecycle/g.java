package androidx.lifecycle;

import dbxyzptlk.DI.s;
import dbxyzptlk.U2.d;
import dbxyzptlk.U2.f;
import dbxyzptlk.U2.h;
import dbxyzptlk.bK.w0;
import kotlin.Metadata;

@Metadata(d1 = {"\0002\n\002\030\002\n\002\020\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\007\n\002\030\002\n\002\b\004\b\001\030\0002\0020\001B'\022\006\020\003\032\0020\002\022\006\020\005\032\0020\004\022\006\020\007\032\0020\006\022\006\020\t\032\0020\b¢\006\004\b\n\020\013J\017\020\r\032\0020\fH\007¢\006\004\b\r\020\016R\024\020\003\032\0020\0028\002X\004¢\006\006\n\004\b\017\020\020R\024\020\005\032\0020\0048\002X\004¢\006\006\n\004\b\r\020\021R\024\020\007\032\0020\0068\002X\004¢\006\006\n\004\b\022\020\023R\024\020\027\032\0020\0248\002X\004¢\006\006\n\004\b\025\020\026¨\006\030"}, d2 = {"Landroidx/lifecycle/g;", "", "Landroidx/lifecycle/f;", "lifecycle", "Landroidx/lifecycle/f$b;", "minState", "Ldbxyzptlk/U2/d;", "dispatchQueue", "Ldbxyzptlk/bK/w0;", "parentJob", "<init>", "(Landroidx/lifecycle/f;Landroidx/lifecycle/f$b;Ldbxyzptlk/U2/d;Ldbxyzptlk/bK/w0;)V", "Ldbxyzptlk/pI/D;", "b", "()V", "a", "Landroidx/lifecycle/f;", "Landroidx/lifecycle/f$b;", "c", "Ldbxyzptlk/U2/d;", "Landroidx/lifecycle/LifecycleEventObserver;", "d", "Landroidx/lifecycle/LifecycleEventObserver;", "observer", "lifecycle-common"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class g {
  public final f a;
  
  public final f.b b;
  
  public final d c;
  
  public final LifecycleEventObserver d;
  
  public g(f paramf, f.b paramb, d paramd, w0 paramw0) {
    this.a = paramf;
    this.b = paramb;
    this.c = paramd;
    f f1 = new f(this, paramw0);
    this.d = (LifecycleEventObserver)f1;
    if (paramf.b() == f.b.DESTROYED) {
      w0.a.a(paramw0, null, 1, null);
      b();
    } else {
      paramf.a((h)f1);
    } 
  }
  
  public static final void c(g paramg, w0 paramw0, LifecycleOwner paramLifecycleOwner, f.a parama) {
    s.h(paramg, "this$0");
    s.h(paramw0, "$parentJob");
    s.h(paramLifecycleOwner, "source");
    s.h(parama, "<anonymous parameter 1>");
    if (paramLifecycleOwner.getLifecycle().b() == f.b.DESTROYED) {
      w0.a.a(paramw0, null, 1, null);
      paramg.b();
    } else if (paramLifecycleOwner.getLifecycle().b().compareTo(paramg.b) < 0) {
      paramg.c.h();
    } else {
      paramg.c.i();
    } 
  }
  
  public final void b() {
    this.a.d(this.d);
    this.c.g();
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\lifecycle\g.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */