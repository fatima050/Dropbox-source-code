package androidx.lifecycle;

import dbxyzptlk.U2.h;
import kotlin.Metadata;

@Metadata(d1 = {"\000\034\n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\003\bæ\001\030\0002\0020\001J\037\020\007\032\0020\0062\006\020\003\032\0020\0022\006\020\005\032\0020\004H&¢\006\004\b\007\020\bø\001\000\002\006\n\004\b!0\001¨\006\tÀ\006\001"}, d2 = {"Landroidx/lifecycle/LifecycleEventObserver;", "Ldbxyzptlk/U2/h;", "Landroidx/lifecycle/LifecycleOwner;", "source", "Landroidx/lifecycle/f$a;", "event", "Ldbxyzptlk/pI/D;", "f", "(Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/f$a;)V", "lifecycle-common"}, k = 1, mv = {1, 8, 0}, xi = 48)
public interface LifecycleEventObserver extends h {
  void f(LifecycleOwner paramLifecycleOwner, f.a parama);
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\lifecycle\LifecycleEventObserver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */