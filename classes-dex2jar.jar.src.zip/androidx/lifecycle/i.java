package androidx.lifecycle;

import dbxyzptlk.DI.s;
import dbxyzptlk.Q.f;
import dbxyzptlk.U2.g;
import dbxyzptlk.bK.T0;
import dbxyzptlk.bK.Z;
import dbxyzptlk.tI.g;
import kotlin.Metadata;

@Metadata(d1 = {"\000\f\n\002\030\002\n\002\030\002\n\002\b\004\"\025\020\004\032\0020\001*\0020\0008F¢\006\006\032\004\b\002\020\003¨\006\005"}, d2 = {"Landroidx/lifecycle/f;", "Ldbxyzptlk/U2/g;", "a", "(Landroidx/lifecycle/f;)Ldbxyzptlk/U2/g;", "coroutineScope", "lifecycle-common"}, k = 2, mv = {1, 8, 0}, xi = 48)
public final class i {
  public static final g a(f paramf) {
    s.h(paramf, "<this>");
    while (true) {
      LifecycleCoroutineScopeImpl lifecycleCoroutineScopeImpl = (LifecycleCoroutineScopeImpl)paramf.c().get();
      if (lifecycleCoroutineScopeImpl != null)
        return lifecycleCoroutineScopeImpl; 
      lifecycleCoroutineScopeImpl = new LifecycleCoroutineScopeImpl(paramf, T0.b(null, 1, null).s((g)Z.c().y0()));
      if (f.a(paramf.c(), null, lifecycleCoroutineScopeImpl)) {
        lifecycleCoroutineScopeImpl.e();
        return lifecycleCoroutineScopeImpl;
      } 
    } 
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\lifecycle\i.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */