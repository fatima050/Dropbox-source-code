package androidx.lifecycle;

import dbxyzptlk.CI.p;
import dbxyzptlk.U2.o;
import dbxyzptlk.bK.J;
import dbxyzptlk.bK.Z;
import dbxyzptlk.bK.h;
import dbxyzptlk.bK.w0;
import dbxyzptlk.pI.D;
import dbxyzptlk.pI.p;
import dbxyzptlk.tI.d;
import dbxyzptlk.tI.g;
import dbxyzptlk.uI.c;
import dbxyzptlk.vI.f;
import dbxyzptlk.vI.l;
import kotlin.Metadata;

@Metadata(d1 = {"\000*\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\000\n\002\b\003\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\004\032>\020\007\032\0028\000\"\004\b\000\020\000*\0020\0012\"\020\006\032\036\b\001\022\004\022\0020\003\022\n\022\b\022\004\022\0028\0000\004\022\006\022\004\030\0010\0050\002H@¢\006\004\b\007\020\b\032>\020\n\032\0028\000\"\004\b\000\020\000*\0020\t2\"\020\006\032\036\b\001\022\004\022\0020\003\022\n\022\b\022\004\022\0028\0000\004\022\006\022\004\030\0010\0050\002H@¢\006\004\b\n\020\013\032>\020\f\032\0028\000\"\004\b\000\020\000*\0020\0012\"\020\006\032\036\b\001\022\004\022\0020\003\022\n\022\b\022\004\022\0028\0000\004\022\006\022\004\030\0010\0050\002H@¢\006\004\b\f\020\b\032>\020\r\032\0028\000\"\004\b\000\020\000*\0020\0012\"\020\006\032\036\b\001\022\004\022\0020\003\022\n\022\b\022\004\022\0028\0000\004\022\006\022\004\030\0010\0050\002H@¢\006\004\b\r\020\b\032F\020\020\032\0028\000\"\004\b\000\020\000*\0020\0012\006\020\017\032\0020\0162\"\020\006\032\036\b\001\022\004\022\0020\003\022\n\022\b\022\004\022\0028\0000\004\022\006\022\004\030\0010\0050\002H@¢\006\004\b\020\020\021¨\006\022"}, d2 = {"T", "Landroidx/lifecycle/f;", "Lkotlin/Function2;", "Ldbxyzptlk/bK/J;", "Ldbxyzptlk/tI/d;", "", "block", "a", "(Landroidx/lifecycle/f;Ldbxyzptlk/CI/p;Ldbxyzptlk/tI/d;)Ljava/lang/Object;", "Landroidx/lifecycle/LifecycleOwner;", "d", "(Landroidx/lifecycle/LifecycleOwner;Ldbxyzptlk/CI/p;Ldbxyzptlk/tI/d;)Ljava/lang/Object;", "c", "b", "Landroidx/lifecycle/f$b;", "minState", "e", "(Landroidx/lifecycle/f;Landroidx/lifecycle/f$b;Ldbxyzptlk/CI/p;Ldbxyzptlk/tI/d;)Ljava/lang/Object;", "lifecycle-common"}, k = 2, mv = {1, 8, 0}, xi = 48)
public final class m {
  public static final <T> Object a(f paramf, p<? super J, ? super d<? super T>, ? extends Object> paramp, d<? super T> paramd) {
    return e(paramf, f.b.CREATED, paramp, paramd);
  }
  
  public static final <T> Object b(f paramf, p<? super J, ? super d<? super T>, ? extends Object> paramp, d<? super T> paramd) {
    return e(paramf, f.b.RESUMED, paramp, paramd);
  }
  
  public static final <T> Object c(f paramf, p<? super J, ? super d<? super T>, ? extends Object> paramp, d<? super T> paramd) {
    return e(paramf, f.b.STARTED, paramp, paramd);
  }
  
  public static final <T> Object d(LifecycleOwner paramLifecycleOwner, p<? super J, ? super d<? super T>, ? extends Object> paramp, d<? super T> paramd) {
    return c(paramLifecycleOwner.getLifecycle(), paramp, paramd);
  }
  
  public static final <T> Object e(f paramf, f.b paramb, p<? super J, ? super d<? super T>, ? extends Object> paramp, d<? super T> paramd) {
    return h.g((g)Z.c().y0(), new a(paramf, paramb, paramp, null), paramd);
  }
  
  @f(c = "androidx.lifecycle.PausingDispatcherKt$whenStateAtLeast$2", f = "PausingDispatcher.kt", l = {203}, m = "invokeSuspend")
  @Metadata(d1 = {"\000\b\n\000\n\002\030\002\n\000\020\002\032\0028\000\"\004\b\000\020\000*\0020\001H@"}, d2 = {"T", "Ldbxyzptlk/bK/J;", "<anonymous>"}, k = 3, mv = {1, 8, 0})
  public static final class a extends l implements p<J, d<? super T>, Object> {
    public int t;
    
    public Object u;
    
    public final f v;
    
    public final f.b w;
    
    public final p<J, d<? super T>, Object> x;
    
    public a(f param1f, f.b param1b, p<? super J, ? super d<? super T>, ? extends Object> param1p, d<? super a> param1d) {
      super(2, param1d);
    }
    
    public final d<D> create(Object param1Object, d<?> param1d) {
      a a1 = new a(this.v, this.w, this.x, (d)param1d);
      a1.u = param1Object;
      return (d<D>)a1;
    }
    
    public final Object invoke(J param1J, d<? super T> param1d) {
      return ((a)create(param1J, param1d)).invokeSuspend(D.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = c.g();
      int i = this.t;
      if (i != 0) {
        if (i == 1) {
          Object object1 = this.u;
          try {
            p.b(param1Object);
          } finally {
            param1Object = null;
            object = object1;
          } 
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        p.b(param1Object);
        param1Object = ((J)this.u).getCoroutineContext().c((g.c)w0.Ia);
        if (param1Object != null) {
          null = new o();
          param1Object = new g(this.v, this.w, null.c, (w0)param1Object);
          try {
            p<J, d<? super T>, Object> p1 = this.x;
            this.u = param1Object;
            this.t = 1;
            Object object1 = h.g((g)null, p1, (d)this);
            if (object1 == object)
              return object; 
            return object1;
          } finally {
            object = param1Object;
            object.b();
          } 
        } 
        throw new IllegalStateException("when[State] methods should have a parent job");
      } 
      object.b();
      return SYNTHETIC_LOCAL_VARIABLE_3;
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\lifecycle\m.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */