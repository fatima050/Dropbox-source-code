package androidx.lifecycle;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.os.Bundle;
import dbxyzptlk.DI.s;
import dbxyzptlk.U2.e;
import java.util.concurrent.atomic.AtomicBoolean;
import kotlin.Metadata;

@Metadata(d1 = {"\000\"\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\004\bÀ\002\030\0002\0020\001:\001\007B\t\b\002¢\006\004\b\002\020\003J\027\020\007\032\0020\0062\006\020\005\032\0020\004H\007¢\006\004\b\007\020\bR\024\020\f\032\0020\t8\002X\004¢\006\006\n\004\b\n\020\013¨\006\r"}, d2 = {"Landroidx/lifecycle/h;", "", "<init>", "()V", "Landroid/content/Context;", "context", "Ldbxyzptlk/pI/D;", "a", "(Landroid/content/Context;)V", "Ljava/util/concurrent/atomic/AtomicBoolean;", "b", "Ljava/util/concurrent/atomic/AtomicBoolean;", "initialized", "lifecycle-process_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class h {
  public static final h a = new h();
  
  public static final AtomicBoolean b = new AtomicBoolean(false);
  
  public static final void a(Context paramContext) {
    s.h(paramContext, "context");
    if (b.getAndSet(true))
      return; 
    paramContext = paramContext.getApplicationContext();
    s.f(paramContext, "null cannot be cast to non-null type android.app.Application");
    ((Application)paramContext).registerActivityLifecycleCallbacks((Application.ActivityLifecycleCallbacks)new a());
  }
  
  @Metadata(d1 = {"\000 \n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\003\b\001\030\0002\0020\001B\007¢\006\004\b\002\020\003J!\020\t\032\0020\b2\006\020\005\032\0020\0042\b\020\007\032\004\030\0010\006H\026¢\006\004\b\t\020\n¨\006\013"}, d2 = {"Landroidx/lifecycle/h$a;", "Ldbxyzptlk/U2/e;", "<init>", "()V", "Landroid/app/Activity;", "activity", "Landroid/os/Bundle;", "savedInstanceState", "Ldbxyzptlk/pI/D;", "onActivityCreated", "(Landroid/app/Activity;Landroid/os/Bundle;)V", "lifecycle-process_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class a extends e {
    public void onActivityCreated(Activity param1Activity, Bundle param1Bundle) {
      s.h(param1Activity, "activity");
      n.b.c(param1Activity);
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\lifecycle\h.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */