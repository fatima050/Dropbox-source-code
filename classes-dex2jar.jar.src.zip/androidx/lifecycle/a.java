package androidx.lifecycle;

import android.os.Bundle;
import dbxyzptlk.DI.s;
import dbxyzptlk.J4.d;
import dbxyzptlk.U2.v;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

@Metadata(d1 = {"\000Z\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\020\016\n\000\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\004\b&\030\000 \0322\0020\0012\0020\002:\001\024B\t\b\026¢\006\004\b\003\020\004B\033\b\026\022\006\020\006\032\0020\005\022\b\020\b\032\004\030\0010\007¢\006\004\b\003\020\tJ/\020\020\032\0028\000\"\b\b\000\020\013*\0020\n2\006\020\r\032\0020\f2\f\020\017\032\b\022\004\022\0028\0000\016H\002¢\006\004\b\020\020\021J/\020\024\032\0028\000\"\b\b\000\020\013*\0020\n2\f\020\017\032\b\022\004\022\0028\0000\0162\006\020\023\032\0020\022H\026¢\006\004\b\024\020\025J'\020\026\032\0028\000\"\b\b\000\020\013*\0020\n2\f\020\017\032\b\022\004\022\0028\0000\016H\026¢\006\004\b\026\020\027J7\020\032\032\0028\000\"\b\b\000\020\013*\0020\n2\006\020\r\032\0020\f2\f\020\017\032\b\022\004\022\0028\0000\0162\006\020\031\032\0020\030H$¢\006\004\b\032\020\033J\027\020\036\032\0020\0352\006\020\034\032\0020\nH\027¢\006\004\b\036\020\037R\030\020\"\032\004\030\0010 8\002@\002X\016¢\006\006\n\004\b\026\020!R\030\020%\032\004\030\0010#8\002@\002X\016¢\006\006\n\004\b\036\020$R\030\020\b\032\004\030\0010\0078\002@\002X\016¢\006\006\n\004\b\020\020&¨\006'"}, d2 = {"Landroidx/lifecycle/a;", "Landroidx/lifecycle/t$d;", "Landroidx/lifecycle/t$b;", "<init>", "()V", "Ldbxyzptlk/J4/d;", "owner", "Landroid/os/Bundle;", "defaultArgs", "(Ldbxyzptlk/J4/d;Landroid/os/Bundle;)V", "Ldbxyzptlk/U2/v;", "T", "", "key", "Ljava/lang/Class;", "modelClass", "d", "(Ljava/lang/String;Ljava/lang/Class;)Ldbxyzptlk/U2/v;", "Ldbxyzptlk/X2/a;", "extras", "a", "(Ljava/lang/Class;Ldbxyzptlk/X2/a;)Ldbxyzptlk/U2/v;", "b", "(Ljava/lang/Class;)Ldbxyzptlk/U2/v;", "Landroidx/lifecycle/o;", "handle", "e", "(Ljava/lang/String;Ljava/lang/Class;Landroidx/lifecycle/o;)Ldbxyzptlk/U2/v;", "viewModel", "Ldbxyzptlk/pI/D;", "c", "(Ldbxyzptlk/U2/v;)V", "Landroidx/savedstate/a;", "Landroidx/savedstate/a;", "savedStateRegistry", "Landroidx/lifecycle/f;", "Landroidx/lifecycle/f;", "lifecycle", "Landroid/os/Bundle;", "lifecycle-viewmodel-savedstate_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public abstract class a extends t.d implements t.b {
  public static final a e = new a(null);
  
  public androidx.savedstate.a b;
  
  public f c;
  
  public Bundle d;
  
  public a() {}
  
  public a(d paramd, Bundle paramBundle) {
    this.b = paramd.getSavedStateRegistry();
    this.c = paramd.getLifecycle();
    this.d = paramBundle;
  }
  
  private final <T extends v> T d(String paramString, Class<T> paramClass) {
    androidx.savedstate.a a1 = this.b;
    s.e(a1);
    f f1 = this.c;
    s.e(f1);
    SavedStateHandleController savedStateHandleController = LegacySavedStateHandleController.b(a1, f1, paramString, this.d);
    paramString = e(paramString, (Class)paramClass, savedStateHandleController.b());
    paramString.setTagIfAbsent("androidx.lifecycle.savedstate.vm.tag", savedStateHandleController);
    return (T)paramString;
  }
  
  public <T extends v> T a(Class<T> paramClass, dbxyzptlk.X2.a parama) {
    s.h(paramClass, "modelClass");
    s.h(parama, "extras");
    String str = (String)parama.a(t.c.d);
    if (str != null) {
      if (this.b != null) {
        paramClass = d(str, (Class)paramClass);
      } else {
        paramClass = e(str, (Class)paramClass, p.b(parama));
      } 
      return (T)paramClass;
    } 
    throw new IllegalStateException("VIEW_MODEL_KEY must always be provided by ViewModelProvider");
  }
  
  public <T extends v> T b(Class<T> paramClass) {
    s.h(paramClass, "modelClass");
    String str = paramClass.getCanonicalName();
    if (str != null) {
      if (this.c != null)
        return d(str, paramClass); 
      throw new UnsupportedOperationException("AbstractSavedStateViewModelFactory constructed with empty constructor supports only calls to create(modelClass: Class<T>, extras: CreationExtras).");
    } 
    throw new IllegalArgumentException("Local and anonymous classes can not be ViewModels");
  }
  
  public void c(v paramv) {
    s.h(paramv, "viewModel");
    androidx.savedstate.a a1 = this.b;
    if (a1 != null) {
      s.e(a1);
      f f1 = this.c;
      s.e(f1);
      LegacySavedStateHandleController.a(paramv, a1, f1);
    } 
  }
  
  public abstract <T extends v> T e(String paramString, Class<T> paramClass, o paramo);
  
  @Metadata(d1 = {"\000\024\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\016\n\002\b\003\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003R\024\020\005\032\0020\0048\000XT¢\006\006\n\004\b\005\020\006¨\006\007"}, d2 = {"Landroidx/lifecycle/a$a;", "", "<init>", "()V", "", "TAG_SAVED_STATE_HANDLE_CONTROLLER", "Ljava/lang/String;", "lifecycle-viewmodel-savedstate_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class a {
    public a() {}
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\lifecycle\a.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */