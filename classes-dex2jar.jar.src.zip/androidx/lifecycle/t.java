package androidx.lifecycle;

import android.app.Application;
import dbxyzptlk.DI.s;
import dbxyzptlk.U2.v;
import dbxyzptlk.U2.x;
import dbxyzptlk.U2.y;
import dbxyzptlk.U2.z;
import java.lang.reflect.InvocationTargetException;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

@Metadata(d1 = {"\000:\n\002\030\002\n\002\020\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\020\016\n\002\b\t\b\026\030\0002\0020\001:\004\022\026\032\034B#\b\007\022\006\020\003\032\0020\002\022\006\020\005\032\0020\004\022\b\b\002\020\007\032\0020\006¢\006\004\b\b\020\tB\021\b\026\022\006\020\013\032\0020\n¢\006\004\b\b\020\fB\031\b\026\022\006\020\013\032\0020\n\022\006\020\005\032\0020\004¢\006\004\b\b\020\rJ(\020\022\032\0028\000\"\b\b\000\020\017*\0020\0162\f\020\021\032\b\022\004\022\0028\0000\020H\002¢\006\004\b\022\020\023J0\020\026\032\0028\000\"\b\b\000\020\017*\0020\0162\006\020\025\032\0020\0242\f\020\021\032\b\022\004\022\0028\0000\020H\002¢\006\004\b\026\020\027R\024\020\003\032\0020\0028\002X\004¢\006\006\n\004\b\022\020\030R\024\020\005\032\0020\0048\002X\004¢\006\006\n\004\b\026\020\031R\024\020\007\032\0020\0068\002X\004¢\006\006\n\004\b\032\020\033¨\006\035"}, d2 = {"Landroidx/lifecycle/t;", "", "Ldbxyzptlk/U2/y;", "store", "Landroidx/lifecycle/t$b;", "factory", "Ldbxyzptlk/X2/a;", "defaultCreationExtras", "<init>", "(Ldbxyzptlk/U2/y;Landroidx/lifecycle/t$b;Ldbxyzptlk/X2/a;)V", "Ldbxyzptlk/U2/z;", "owner", "(Ldbxyzptlk/U2/z;)V", "(Ldbxyzptlk/U2/z;Landroidx/lifecycle/t$b;)V", "Ldbxyzptlk/U2/v;", "T", "Ljava/lang/Class;", "modelClass", "a", "(Ljava/lang/Class;)Ldbxyzptlk/U2/v;", "", "key", "b", "(Ljava/lang/String;Ljava/lang/Class;)Ldbxyzptlk/U2/v;", "Ldbxyzptlk/U2/y;", "Landroidx/lifecycle/t$b;", "c", "Ldbxyzptlk/X2/a;", "d", "lifecycle-viewmodel_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public class t {
  public final y a;
  
  public final b b;
  
  public final dbxyzptlk.X2.a c;
  
  public t(y paramy, b paramb) {
    this(paramy, paramb, null, 4, null);
  }
  
  public t(y paramy, b paramb, dbxyzptlk.X2.a parama) {
    this.a = paramy;
    this.b = paramb;
    this.c = parama;
  }
  
  public t(z paramz) {
    this(paramz.getViewModelStore(), a.f.a(paramz), x.a(paramz));
  }
  
  public t(z paramz, b paramb) {
    this(paramz.getViewModelStore(), paramb, x.a(paramz));
  }
  
  public <T extends v> T a(Class<T> paramClass) {
    s.h(paramClass, "modelClass");
    String str = paramClass.getCanonicalName();
    if (str != null) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("androidx.lifecycle.ViewModelProvider.DefaultKey:");
      stringBuilder.append(str);
      return b(stringBuilder.toString(), paramClass);
    } 
    throw new IllegalArgumentException("Local and anonymous classes can not be ViewModels");
  }
  
  public <T extends v> T b(String paramString, Class<T> paramClass) {
    b b1;
    dbxyzptlk.X2.b b2;
    s.h(paramString, "key");
    s.h(paramClass, "modelClass");
    v v = this.a.b(paramString);
    if (paramClass.isInstance(v)) {
      b1 = this.b;
      if (b1 instanceof d) {
        d d = (d)b1;
      } else {
        b1 = null;
      } 
      if (b1 != null) {
        s.e(v);
        b1.c(v);
      } 
      s.f(v, "null cannot be cast to non-null type T of androidx.lifecycle.ViewModelProvider.get");
      return (T)v;
    } 
    dbxyzptlk.X2.b b3 = new dbxyzptlk.X2.b(this.c);
    b3.c(c.d, b1);
    try {
      b3 = this.b.a((Class)paramClass, (dbxyzptlk.X2.a)b3);
      b2 = b3;
    } catch (AbstractMethodError abstractMethodError) {
      b2 = this.b.b((Class<dbxyzptlk.X2.b>)b2);
    } 
    this.a.d((String)b1, (v)b2);
    return (T)b2;
  }
  
  @Metadata(d1 = {"\000*\n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\020\b\n\002\b\005\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\f\b\026\030\000 \0312\0020\001:\001\020B\033\b\002\022\b\020\003\032\004\030\0010\002\022\006\020\005\032\0020\004¢\006\004\b\006\020\007B\t\b\026¢\006\004\b\006\020\bB\021\b\026\022\006\020\003\032\0020\002¢\006\004\b\006\020\tJ/\020\020\032\0028\000\"\b\b\000\020\013*\0020\n2\f\020\r\032\b\022\004\022\0028\0000\f2\006\020\017\032\0020\016H\026¢\006\004\b\020\020\021J'\020\022\032\0028\000\"\b\b\000\020\013*\0020\n2\f\020\r\032\b\022\004\022\0028\0000\fH\026¢\006\004\b\022\020\023J/\020\025\032\0028\000\"\b\b\000\020\013*\0020\n2\f\020\r\032\b\022\004\022\0028\0000\f2\006\020\024\032\0020\002H\002¢\006\004\b\025\020\026R\026\020\003\032\004\030\0010\0028\002X\004¢\006\006\n\004\b\027\020\030¨\006\032"}, d2 = {"Landroidx/lifecycle/t$a;", "Landroidx/lifecycle/t$c;", "Landroid/app/Application;", "application", "", "unused", "<init>", "(Landroid/app/Application;I)V", "()V", "(Landroid/app/Application;)V", "Ldbxyzptlk/U2/v;", "T", "Ljava/lang/Class;", "modelClass", "Ldbxyzptlk/X2/a;", "extras", "a", "(Ljava/lang/Class;Ldbxyzptlk/X2/a;)Ldbxyzptlk/U2/v;", "b", "(Ljava/lang/Class;)Ldbxyzptlk/U2/v;", "app", "g", "(Ljava/lang/Class;Landroid/app/Application;)Ldbxyzptlk/U2/v;", "e", "Landroid/app/Application;", "f", "lifecycle-viewmodel_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static class a extends c {
    public static final a f = new a(null);
    
    public static a g;
    
    public static final dbxyzptlk.X2.a.b<Application> h = a.a.a;
    
    public final Application e;
    
    public a() {
      this(null, 0);
    }
    
    public a(Application param1Application) {
      this(param1Application, 0);
    }
    
    public a(Application param1Application, int param1Int) {
      this.e = param1Application;
    }
    
    public <T extends v> T a(Class<T> param1Class, dbxyzptlk.X2.a param1a) {
      s.h(param1Class, "modelClass");
      s.h(param1a, "extras");
      if (this.e != null) {
        param1Class = b((Class)param1Class);
      } else {
        Application application = (Application)param1a.a(h);
        if (application != null) {
          param1Class = g((Class)param1Class, application);
        } else {
          if (!dbxyzptlk.U2.a.class.isAssignableFrom(param1Class))
            return (T)super.b((Class)param1Class); 
          throw new IllegalArgumentException("CreationExtras must have an application by `APPLICATION_KEY`");
        } 
      } 
      return (T)param1Class;
    }
    
    public <T extends v> T b(Class<T> param1Class) {
      s.h(param1Class, "modelClass");
      Application application = this.e;
      if (application != null)
        return g(param1Class, application); 
      throw new UnsupportedOperationException("AndroidViewModelFactory constructed with empty constructor works only with create(modelClass: Class<T>, extras: CreationExtras).");
    }
    
    public final <T extends v> T g(Class<T> param1Class, Application param1Application) {
      v v;
      if (dbxyzptlk.U2.a.class.isAssignableFrom(param1Class)) {
        try {
          v v1 = param1Class.getConstructor(new Class[] { Application.class }).newInstance(new Object[] { param1Application });
          s.g(v1, "{\n                try {\n…          }\n            }");
          v = v1;
        } catch (NoSuchMethodException noSuchMethodException) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Cannot create an instance of ");
          stringBuilder.append(v);
          throw new RuntimeException(stringBuilder.toString(), noSuchMethodException);
        } catch (IllegalAccessException illegalAccessException) {
        
        } catch (InstantiationException instantiationException) {
        
        } catch (InvocationTargetException invocationTargetException) {}
      } else {
        v = super.b((Class<v>)v);
      } 
      return (T)v;
    }
    
    @Metadata(d1 = {"\0008\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\020\016\n\002\b\005\b\003\030\0002\0020\001:\001\007B\t\b\002¢\006\004\b\002\020\003J\027\020\007\032\0020\0062\006\020\005\032\0020\004H\000¢\006\004\b\007\020\bJ\027\020\f\032\0020\0132\006\020\n\032\0020\tH\007¢\006\004\b\f\020\rR\032\020\017\032\b\022\004\022\0020\t0\0168\006X\004¢\006\006\n\004\b\017\020\020R\024\020\022\032\0020\0218\000XT¢\006\006\n\004\b\022\020\023R\030\020\024\032\004\030\0010\0138\002@\002X\016¢\006\006\n\004\b\024\020\025¨\006\026"}, d2 = {"Landroidx/lifecycle/t$a$a;", "", "<init>", "()V", "Ldbxyzptlk/U2/z;", "owner", "Landroidx/lifecycle/t$b;", "a", "(Ldbxyzptlk/U2/z;)Landroidx/lifecycle/t$b;", "Landroid/app/Application;", "application", "Landroidx/lifecycle/t$a;", "b", "(Landroid/app/Application;)Landroidx/lifecycle/t$a;", "Ldbxyzptlk/X2/a$b;", "APPLICATION_KEY", "Ldbxyzptlk/X2/a$b;", "", "DEFAULT_KEY", "Ljava/lang/String;", "sInstance", "Landroidx/lifecycle/t$a;", "lifecycle-viewmodel_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
    public static final class a {
      public a() {}
      
      public final t.b a(z param2z) {
        t.b b;
        s.h(param2z, "owner");
        if (param2z instanceof e) {
          b = ((e)param2z).getDefaultViewModelProviderFactory();
        } else {
          b = t.c.b.a();
        } 
        return b;
      }
      
      public final t.a b(Application param2Application) {
        s.h(param2Application, "application");
        if (t.a.e() == null)
          t.a.f(new t.a(param2Application)); 
        t.a a1 = t.a.e();
        s.e(a1);
        return a1;
      }
      
      @Metadata(d1 = {"\000\020\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\003\bÂ\002\030\0002\b\022\004\022\0020\0020\001B\t\b\002¢\006\004\b\003\020\004¨\006\005"}, d2 = {"Landroidx/lifecycle/t$a$a$a;", "Ldbxyzptlk/X2/a$b;", "Landroid/app/Application;", "<init>", "()V", "lifecycle-viewmodel_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
      public static final class a implements dbxyzptlk.X2.a.b<Application> {
        public static final a a = new a();
      }
    }
    
    @Metadata(d1 = {"\000\020\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\003\bÂ\002\030\0002\b\022\004\022\0020\0020\001B\t\b\002¢\006\004\b\003\020\004¨\006\005"}, d2 = {"Landroidx/lifecycle/t$a$a$a;", "Ldbxyzptlk/X2/a$b;", "Landroid/app/Application;", "<init>", "()V", "lifecycle-viewmodel_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
    public static final class a implements dbxyzptlk.X2.a.b<Application> {
      public static final a a = new a();
    }
  }
  
  @Metadata(d1 = {"\0008\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\020\016\n\002\b\005\b\003\030\0002\0020\001:\001\007B\t\b\002¢\006\004\b\002\020\003J\027\020\007\032\0020\0062\006\020\005\032\0020\004H\000¢\006\004\b\007\020\bJ\027\020\f\032\0020\0132\006\020\n\032\0020\tH\007¢\006\004\b\f\020\rR\032\020\017\032\b\022\004\022\0020\t0\0168\006X\004¢\006\006\n\004\b\017\020\020R\024\020\022\032\0020\0218\000XT¢\006\006\n\004\b\022\020\023R\030\020\024\032\004\030\0010\0138\002@\002X\016¢\006\006\n\004\b\024\020\025¨\006\026"}, d2 = {"Landroidx/lifecycle/t$a$a;", "", "<init>", "()V", "Ldbxyzptlk/U2/z;", "owner", "Landroidx/lifecycle/t$b;", "a", "(Ldbxyzptlk/U2/z;)Landroidx/lifecycle/t$b;", "Landroid/app/Application;", "application", "Landroidx/lifecycle/t$a;", "b", "(Landroid/app/Application;)Landroidx/lifecycle/t$a;", "Ldbxyzptlk/X2/a$b;", "APPLICATION_KEY", "Ldbxyzptlk/X2/a$b;", "", "DEFAULT_KEY", "Ljava/lang/String;", "sInstance", "Landroidx/lifecycle/t$a;", "lifecycle-viewmodel_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class a {
    public a() {}
    
    public final t.b a(z param1z) {
      t.b b;
      s.h(param1z, "owner");
      if (param1z instanceof e) {
        b = ((e)param1z).getDefaultViewModelProviderFactory();
      } else {
        b = t.c.b.a();
      } 
      return b;
    }
    
    public final t.a b(Application param1Application) {
      s.h(param1Application, "application");
      if (t.a.e() == null)
        t.a.f(new t.a(param1Application)); 
      t.a a1 = t.a.e();
      s.e(a1);
      return a1;
    }
    
    @Metadata(d1 = {"\000\020\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\003\bÂ\002\030\0002\b\022\004\022\0020\0020\001B\t\b\002¢\006\004\b\003\020\004¨\006\005"}, d2 = {"Landroidx/lifecycle/t$a$a$a;", "Ldbxyzptlk/X2/a$b;", "Landroid/app/Application;", "<init>", "()V", "lifecycle-viewmodel_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
    public static final class a implements dbxyzptlk.X2.a.b<Application> {
      public static final a a = new a();
    }
  }
  
  @Metadata(d1 = {"\000\020\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\003\bÂ\002\030\0002\b\022\004\022\0020\0020\001B\t\b\002¢\006\004\b\003\020\004¨\006\005"}, d2 = {"Landroidx/lifecycle/t$a$a$a;", "Ldbxyzptlk/X2/a$b;", "Landroid/app/Application;", "<init>", "()V", "lifecycle-viewmodel_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class a implements dbxyzptlk.X2.a.b<Application> {
    public static final a a = new a();
  }
  
  @Metadata(d1 = {"\000\036\n\002\030\002\n\002\020\000\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\004\bf\030\000 \n2\0020\001:\001\nJ'\020\006\032\0028\000\"\b\b\000\020\003*\0020\0022\f\020\005\032\b\022\004\022\0028\0000\004H\026¢\006\004\b\006\020\007J/\020\n\032\0028\000\"\b\b\000\020\003*\0020\0022\f\020\005\032\b\022\004\022\0028\0000\0042\006\020\t\032\0020\bH\026¢\006\004\b\n\020\013ø\001\000\002\006\n\004\b!0\001¨\006\fÀ\006\001"}, d2 = {"Landroidx/lifecycle/t$b;", "", "Ldbxyzptlk/U2/v;", "T", "Ljava/lang/Class;", "modelClass", "b", "(Ljava/lang/Class;)Ldbxyzptlk/U2/v;", "Ldbxyzptlk/X2/a;", "extras", "a", "(Ljava/lang/Class;Ldbxyzptlk/X2/a;)Ldbxyzptlk/U2/v;", "lifecycle-viewmodel_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static interface b {
    public static final a a = a.a;
    
    default <T extends v> T a(Class<T> param1Class, dbxyzptlk.X2.a param1a) {
      s.h(param1Class, "modelClass");
      s.h(param1a, "extras");
      return b(param1Class);
    }
    
    default <T extends v> T b(Class<T> param1Class) {
      s.h(param1Class, "modelClass");
      throw new UnsupportedOperationException("Factory.create(String) is unsupported.  This Factory requires `CreationExtras` to be passed into `create` method.");
    }
    
    @Metadata(d1 = {"\000\f\n\002\030\002\n\002\020\000\n\002\b\003\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003¨\006\004"}, d2 = {"Landroidx/lifecycle/t$b$a;", "", "<init>", "()V", "lifecycle-viewmodel_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
    public static final class a {
      public static final a a = new a();
    }
  }
  
  @Metadata(d1 = {"\000\f\n\002\030\002\n\002\020\000\n\002\b\003\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003¨\006\004"}, d2 = {"Landroidx/lifecycle/t$b$a;", "", "<init>", "()V", "lifecycle-viewmodel_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class a {
    public static final a a = new a();
  }
  
  @Metadata(d1 = {"\000\032\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\005\b\026\030\000 \b2\0020\001:\001\nB\007¢\006\004\b\002\020\003J'\020\b\032\0028\000\"\b\b\000\020\005*\0020\0042\f\020\007\032\b\022\004\022\0028\0000\006H\026¢\006\004\b\b\020\t¨\006\013"}, d2 = {"Landroidx/lifecycle/t$c;", "Landroidx/lifecycle/t$b;", "<init>", "()V", "Ldbxyzptlk/U2/v;", "T", "Ljava/lang/Class;", "modelClass", "b", "(Ljava/lang/Class;)Ldbxyzptlk/U2/v;", "a", "lifecycle-viewmodel_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static class c implements b {
    public static final a b = new a(null);
    
    public static c c;
    
    public static final dbxyzptlk.X2.a.b<String> d = a.a.a;
    
    public <T extends v> T b(Class<T> param1Class) {
      s.h(param1Class, "modelClass");
      try {
        null = (v)param1Class.getDeclaredConstructor(null).newInstance(null);
        s.g(null, "{\n                modelC…wInstance()\n            }");
        return (T)null;
      } catch (NoSuchMethodException noSuchMethodException) {
      
      } catch (InstantiationException instantiationException) {
      
      } catch (IllegalAccessException illegalAccessException) {}
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Cannot create an instance of ");
      stringBuilder.append(param1Class);
      throw new RuntimeException(stringBuilder.toString(), illegalAccessException);
    }
    
    @Metadata(d1 = {"\000 \n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\b\004\n\002\030\002\n\002\020\016\n\002\b\005\b\003\030\0002\0020\001:\001\005B\t\b\002¢\006\004\b\002\020\003R\032\020\b\032\0020\0048GX\004¢\006\f\022\004\b\007\020\003\032\004\b\005\020\006R\032\020\013\032\b\022\004\022\0020\n0\t8\006X\004¢\006\006\n\004\b\013\020\fR\030\020\r\032\004\030\0010\0048\002@\002X\016¢\006\006\n\004\b\r\020\016¨\006\017"}, d2 = {"Landroidx/lifecycle/t$c$a;", "", "<init>", "()V", "Landroidx/lifecycle/t$c;", "a", "()Landroidx/lifecycle/t$c;", "getInstance$annotations", "instance", "Ldbxyzptlk/X2/a$b;", "", "VIEW_MODEL_KEY", "Ldbxyzptlk/X2/a$b;", "sInstance", "Landroidx/lifecycle/t$c;", "lifecycle-viewmodel_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
    public static final class a {
      public a() {}
      
      public final t.c a() {
        if (t.c.c() == null)
          t.c.d(new t.c()); 
        t.c c = t.c.c();
        s.e(c);
        return c;
      }
      
      @Metadata(d1 = {"\000\020\n\002\030\002\n\002\030\002\n\002\020\016\n\002\b\003\bÂ\002\030\0002\b\022\004\022\0020\0020\001B\t\b\002¢\006\004\b\003\020\004¨\006\005"}, d2 = {"Landroidx/lifecycle/t$c$a$a;", "Ldbxyzptlk/X2/a$b;", "", "<init>", "()V", "lifecycle-viewmodel_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
      public static final class a implements dbxyzptlk.X2.a.b<String> {
        public static final a a = new a();
      }
    }
    
    @Metadata(d1 = {"\000\020\n\002\030\002\n\002\030\002\n\002\020\016\n\002\b\003\bÂ\002\030\0002\b\022\004\022\0020\0020\001B\t\b\002¢\006\004\b\003\020\004¨\006\005"}, d2 = {"Landroidx/lifecycle/t$c$a$a;", "Ldbxyzptlk/X2/a$b;", "", "<init>", "()V", "lifecycle-viewmodel_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
    public static final class a implements dbxyzptlk.X2.a.b<String> {
      public static final a a = new a();
    }
  }
  
  @Metadata(d1 = {"\000 \n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\b\004\n\002\030\002\n\002\020\016\n\002\b\005\b\003\030\0002\0020\001:\001\005B\t\b\002¢\006\004\b\002\020\003R\032\020\b\032\0020\0048GX\004¢\006\f\022\004\b\007\020\003\032\004\b\005\020\006R\032\020\013\032\b\022\004\022\0020\n0\t8\006X\004¢\006\006\n\004\b\013\020\fR\030\020\r\032\004\030\0010\0048\002@\002X\016¢\006\006\n\004\b\r\020\016¨\006\017"}, d2 = {"Landroidx/lifecycle/t$c$a;", "", "<init>", "()V", "Landroidx/lifecycle/t$c;", "a", "()Landroidx/lifecycle/t$c;", "getInstance$annotations", "instance", "Ldbxyzptlk/X2/a$b;", "", "VIEW_MODEL_KEY", "Ldbxyzptlk/X2/a$b;", "sInstance", "Landroidx/lifecycle/t$c;", "lifecycle-viewmodel_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class a {
    public a() {}
    
    public final t.c a() {
      if (t.c.c() == null)
        t.c.d(new t.c()); 
      t.c c = t.c.c();
      s.e(c);
      return c;
    }
    
    @Metadata(d1 = {"\000\020\n\002\030\002\n\002\030\002\n\002\020\016\n\002\b\003\bÂ\002\030\0002\b\022\004\022\0020\0020\001B\t\b\002¢\006\004\b\003\020\004¨\006\005"}, d2 = {"Landroidx/lifecycle/t$c$a$a;", "Ldbxyzptlk/X2/a$b;", "", "<init>", "()V", "lifecycle-viewmodel_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
    public static final class a implements dbxyzptlk.X2.a.b<String> {
      public static final a a = new a();
    }
  }
  
  @Metadata(d1 = {"\000\020\n\002\030\002\n\002\030\002\n\002\020\016\n\002\b\003\bÂ\002\030\0002\b\022\004\022\0020\0020\001B\t\b\002¢\006\004\b\003\020\004¨\006\005"}, d2 = {"Landroidx/lifecycle/t$c$a$a;", "Ldbxyzptlk/X2/a$b;", "", "<init>", "()V", "lifecycle-viewmodel_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class a implements dbxyzptlk.X2.a.b<String> {
    public static final a a = new a();
  }
  
  @Metadata(d1 = {"\000\032\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\003\b\027\030\0002\0020\001B\007¢\006\004\b\002\020\003J\027\020\007\032\0020\0062\006\020\005\032\0020\004H\026¢\006\004\b\007\020\b¨\006\t"}, d2 = {"Landroidx/lifecycle/t$d;", "", "<init>", "()V", "Ldbxyzptlk/U2/v;", "viewModel", "Ldbxyzptlk/pI/D;", "c", "(Ldbxyzptlk/U2/v;)V", "lifecycle-viewmodel_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static class d {
    public void c(v param1v) {
      s.h(param1v, "viewModel");
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\lifecycle\t.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */