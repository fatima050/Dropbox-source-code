package androidx.lifecycle;

import android.app.Activity;
import android.app.Application;
import android.app.Fragment;
import android.app.FragmentManager;
import android.os.Build;
import android.os.Bundle;
import dbxyzptlk.DI.s;
import dbxyzptlk.U2.j;
import dbxyzptlk.U2.q;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

@Metadata(d1 = {"\000*\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\007\n\002\030\002\n\002\b\007\n\002\030\002\n\002\b\005\b\027\030\000 \0232\0020\001:\003\030\023\025B\007¢\006\004\b\002\020\003J\031\020\007\032\0020\0062\b\020\005\032\004\030\0010\004H\026¢\006\004\b\007\020\bJ\017\020\t\032\0020\006H\026¢\006\004\b\t\020\003J\017\020\n\032\0020\006H\026¢\006\004\b\n\020\003J\017\020\013\032\0020\006H\026¢\006\004\b\013\020\003J\017\020\f\032\0020\006H\026¢\006\004\b\f\020\003J\017\020\r\032\0020\006H\026¢\006\004\b\r\020\003J\027\020\020\032\0020\0062\b\020\017\032\004\030\0010\016¢\006\004\b\020\020\021J\031\020\023\032\0020\0062\b\020\022\032\004\030\0010\016H\002¢\006\004\b\023\020\021J\031\020\024\032\0020\0062\b\020\022\032\004\030\0010\016H\002¢\006\004\b\024\020\021J\031\020\025\032\0020\0062\b\020\022\032\004\030\0010\016H\002¢\006\004\b\025\020\021J\027\020\030\032\0020\0062\006\020\027\032\0020\026H\002¢\006\004\b\030\020\031R\030\020\017\032\004\030\0010\0168\002@\002X\016¢\006\006\n\004\b\030\020\032¨\006\033"}, d2 = {"Landroidx/lifecycle/n;", "Landroid/app/Fragment;", "<init>", "()V", "Landroid/os/Bundle;", "savedInstanceState", "Ldbxyzptlk/pI/D;", "onActivityCreated", "(Landroid/os/Bundle;)V", "onStart", "onResume", "onPause", "onStop", "onDestroy", "Landroidx/lifecycle/n$a;", "processListener", "e", "(Landroidx/lifecycle/n$a;)V", "listener", "b", "d", "c", "Landroidx/lifecycle/f$a;", "event", "a", "(Landroidx/lifecycle/f$a;)V", "Landroidx/lifecycle/n$a;", "lifecycle-runtime_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public class n extends Fragment {
  public static final b b = new b(null);
  
  public a a;
  
  public final void a(f.a parama) {
    if (Build.VERSION.SDK_INT < 29) {
      b b1 = b;
      Activity activity = getActivity();
      s.g(activity, "activity");
      b1.a(activity, parama);
    } 
  }
  
  public final void b(a parama) {
    if (parama != null)
      parama.onCreate(); 
  }
  
  public final void c(a parama) {
    if (parama != null)
      parama.onResume(); 
  }
  
  public final void d(a parama) {
    if (parama != null)
      parama.a(); 
  }
  
  public final void e(a parama) {
    this.a = parama;
  }
  
  public void onActivityCreated(Bundle paramBundle) {
    super.onActivityCreated(paramBundle);
    b(this.a);
    a(f.a.ON_CREATE);
  }
  
  public void onDestroy() {
    super.onDestroy();
    a(f.a.ON_DESTROY);
    this.a = null;
  }
  
  public void onPause() {
    super.onPause();
    a(f.a.ON_PAUSE);
  }
  
  public void onResume() {
    super.onResume();
    c(this.a);
    a(f.a.ON_RESUME);
  }
  
  public void onStart() {
    super.onStart();
    d(this.a);
    a(f.a.ON_START);
  }
  
  public void onStop() {
    super.onStop();
    a(f.a.ON_STOP);
  }
  
  @Metadata(d1 = {"\000\020\n\002\030\002\n\002\020\000\n\002\030\002\n\002\b\005\bf\030\0002\0020\001J\017\020\003\032\0020\002H&¢\006\004\b\003\020\004J\017\020\005\032\0020\002H&¢\006\004\b\005\020\004J\017\020\006\032\0020\002H&¢\006\004\b\006\020\004ø\001\000\002\006\n\004\b!0\001¨\006\007À\006\001"}, d2 = {"Landroidx/lifecycle/n$a;", "", "Ldbxyzptlk/pI/D;", "onCreate", "()V", "a", "onResume", "lifecycle-runtime_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static interface a {
    void a();
    
    void onCreate();
    
    void onResume();
  }
  
  @Metadata(d1 = {"\0002\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\004\n\002\020\016\n\002\b\003\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\027\020\007\032\0020\0062\006\020\005\032\0020\004H\007¢\006\004\b\007\020\bJ\037\020\013\032\0020\0062\006\020\005\032\0020\0042\006\020\n\032\0020\tH\001¢\006\004\b\013\020\fR\036\020\021\032\0020\r*\0020\0048GX\004¢\006\f\022\004\b\020\020\b\032\004\b\016\020\017R\024\020\023\032\0020\0228\002XT¢\006\006\n\004\b\023\020\024¨\006\025"}, d2 = {"Landroidx/lifecycle/n$b;", "", "<init>", "()V", "Landroid/app/Activity;", "activity", "Ldbxyzptlk/pI/D;", "c", "(Landroid/app/Activity;)V", "Landroidx/lifecycle/f$a;", "event", "a", "(Landroid/app/Activity;Landroidx/lifecycle/f$a;)V", "Landroidx/lifecycle/n;", "b", "(Landroid/app/Activity;)Landroidx/lifecycle/n;", "get$annotations", "reportFragment", "", "REPORT_FRAGMENT_TAG", "Ljava/lang/String;", "lifecycle-runtime_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class b {
    public b() {}
    
    public final void a(Activity param1Activity, f.a param1a) {
      s.h(param1Activity, "activity");
      s.h(param1a, "event");
      if (param1Activity instanceof j) {
        ((j)param1Activity).getLifecycle().i(param1a);
        return;
      } 
      if (param1Activity instanceof LifecycleOwner) {
        f f = ((LifecycleOwner)param1Activity).getLifecycle();
        if (f instanceof j)
          ((j)f).i(param1a); 
      } 
    }
    
    public final n b(Activity param1Activity) {
      s.h(param1Activity, "<this>");
      Fragment fragment = param1Activity.getFragmentManager().findFragmentByTag("androidx.lifecycle.LifecycleDispatcher.report_fragment_tag");
      s.f(fragment, "null cannot be cast to non-null type androidx.lifecycle.ReportFragment");
      return (n)fragment;
    }
    
    public final void c(Activity param1Activity) {
      s.h(param1Activity, "activity");
      if (Build.VERSION.SDK_INT >= 29)
        n.c.Companion.a(param1Activity); 
      FragmentManager fragmentManager = param1Activity.getFragmentManager();
      if (fragmentManager.findFragmentByTag("androidx.lifecycle.LifecycleDispatcher.report_fragment_tag") == null) {
        fragmentManager.beginTransaction().add(new n(), "androidx.lifecycle.LifecycleDispatcher.report_fragment_tag").commit();
        fragmentManager.executePendingTransactions();
      } 
    }
  }
  
  @Metadata(d1 = {"\000 \n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\023\b\001\030\000 \0312\0020\001:\001\032B\007¢\006\004\b\002\020\003J!\020\t\032\0020\b2\006\020\005\032\0020\0042\b\020\007\032\004\030\0010\006H\026¢\006\004\b\t\020\nJ!\020\f\032\0020\b2\006\020\005\032\0020\0042\b\020\013\032\004\030\0010\006H\026¢\006\004\b\f\020\nJ\027\020\r\032\0020\b2\006\020\005\032\0020\004H\026¢\006\004\b\r\020\016J\027\020\017\032\0020\b2\006\020\005\032\0020\004H\026¢\006\004\b\017\020\016J\027\020\020\032\0020\b2\006\020\005\032\0020\004H\026¢\006\004\b\020\020\016J\027\020\021\032\0020\b2\006\020\005\032\0020\004H\026¢\006\004\b\021\020\016J\027\020\022\032\0020\b2\006\020\005\032\0020\004H\026¢\006\004\b\022\020\016J\027\020\023\032\0020\b2\006\020\005\032\0020\004H\026¢\006\004\b\023\020\016J\027\020\024\032\0020\b2\006\020\005\032\0020\004H\026¢\006\004\b\024\020\016J\027\020\025\032\0020\b2\006\020\005\032\0020\004H\026¢\006\004\b\025\020\016J\037\020\026\032\0020\b2\006\020\005\032\0020\0042\006\020\007\032\0020\006H\026¢\006\004\b\026\020\nJ\027\020\027\032\0020\b2\006\020\005\032\0020\004H\026¢\006\004\b\027\020\016J\027\020\030\032\0020\b2\006\020\005\032\0020\004H\026¢\006\004\b\030\020\016¨\006\033"}, d2 = {"Landroidx/lifecycle/n$c;", "Landroid/app/Application$ActivityLifecycleCallbacks;", "<init>", "()V", "Landroid/app/Activity;", "activity", "Landroid/os/Bundle;", "bundle", "Ldbxyzptlk/pI/D;", "onActivityCreated", "(Landroid/app/Activity;Landroid/os/Bundle;)V", "savedInstanceState", "onActivityPostCreated", "onActivityStarted", "(Landroid/app/Activity;)V", "onActivityPostStarted", "onActivityResumed", "onActivityPostResumed", "onActivityPrePaused", "onActivityPaused", "onActivityPreStopped", "onActivityStopped", "onActivitySaveInstanceState", "onActivityPreDestroyed", "onActivityDestroyed", "Companion", "a", "lifecycle-runtime_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class c implements Application.ActivityLifecycleCallbacks {
    public static final a Companion = new a(null);
    
    public static final void registerIn(Activity param1Activity) {
      Companion.a(param1Activity);
    }
    
    public void onActivityCreated(Activity param1Activity, Bundle param1Bundle) {
      s.h(param1Activity, "activity");
    }
    
    public void onActivityDestroyed(Activity param1Activity) {
      s.h(param1Activity, "activity");
    }
    
    public void onActivityPaused(Activity param1Activity) {
      s.h(param1Activity, "activity");
    }
    
    public void onActivityPostCreated(Activity param1Activity, Bundle param1Bundle) {
      s.h(param1Activity, "activity");
      n.b.a(param1Activity, f.a.ON_CREATE);
    }
    
    public void onActivityPostResumed(Activity param1Activity) {
      s.h(param1Activity, "activity");
      n.b.a(param1Activity, f.a.ON_RESUME);
    }
    
    public void onActivityPostStarted(Activity param1Activity) {
      s.h(param1Activity, "activity");
      n.b.a(param1Activity, f.a.ON_START);
    }
    
    public void onActivityPreDestroyed(Activity param1Activity) {
      s.h(param1Activity, "activity");
      n.b.a(param1Activity, f.a.ON_DESTROY);
    }
    
    public void onActivityPrePaused(Activity param1Activity) {
      s.h(param1Activity, "activity");
      n.b.a(param1Activity, f.a.ON_PAUSE);
    }
    
    public void onActivityPreStopped(Activity param1Activity) {
      s.h(param1Activity, "activity");
      n.b.a(param1Activity, f.a.ON_STOP);
    }
    
    public void onActivityResumed(Activity param1Activity) {
      s.h(param1Activity, "activity");
    }
    
    public void onActivitySaveInstanceState(Activity param1Activity, Bundle param1Bundle) {
      s.h(param1Activity, "activity");
      s.h(param1Bundle, "bundle");
    }
    
    public void onActivityStarted(Activity param1Activity) {
      s.h(param1Activity, "activity");
    }
    
    public void onActivityStopped(Activity param1Activity) {
      s.h(param1Activity, "activity");
    }
    
    @Metadata(d1 = {"\000\032\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\003\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\027\020\007\032\0020\0062\006\020\005\032\0020\004H\007¢\006\004\b\007\020\b¨\006\t"}, d2 = {"Landroidx/lifecycle/n$c$a;", "", "<init>", "()V", "Landroid/app/Activity;", "activity", "Ldbxyzptlk/pI/D;", "a", "(Landroid/app/Activity;)V", "lifecycle-runtime_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
    public static final class a {
      public a() {}
      
      public final void a(Activity param2Activity) {
        s.h(param2Activity, "activity");
        q.a(param2Activity, new n.c());
      }
    }
  }
  
  @Metadata(d1 = {"\000\032\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\003\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\027\020\007\032\0020\0062\006\020\005\032\0020\004H\007¢\006\004\b\007\020\b¨\006\t"}, d2 = {"Landroidx/lifecycle/n$c$a;", "", "<init>", "()V", "Landroid/app/Activity;", "activity", "Ldbxyzptlk/pI/D;", "a", "(Landroid/app/Activity;)V", "lifecycle-runtime_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class a {
    public a() {}
    
    public final void a(Activity param1Activity) {
      s.h(param1Activity, "activity");
      q.a(param1Activity, new n.c());
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\lifecycle\n.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */