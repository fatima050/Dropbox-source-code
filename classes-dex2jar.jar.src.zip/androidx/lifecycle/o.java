package androidx.lifecycle;

import android.os.Binder;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Size;
import android.util.SizeF;
import android.util.SparseArray;
import dbxyzptlk.DI.s;
import dbxyzptlk.U2.m;
import dbxyzptlk.U2.r;
import dbxyzptlk.d2.d;
import dbxyzptlk.eK.C;
import dbxyzptlk.eK.S;
import dbxyzptlk.eK.U;
import dbxyzptlk.eK.k;
import dbxyzptlk.pI.n;
import dbxyzptlk.pI.t;
import dbxyzptlk.qI.P;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

@Metadata(d1 = {"\000T\n\002\030\002\n\002\020\000\n\002\020$\n\002\020\016\n\002\b\004\n\002\030\002\n\002\b\003\n\002\020\013\n\002\b\003\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\006\n\002\020%\n\002\b\005\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\005\030\000 \0272\0020\001:\002\"%B\037\b\026\022\024\020\004\032\020\022\004\022\0020\003\022\006\022\004\030\0010\0010\002¢\006\004\b\005\020\006B\t\b\026¢\006\004\b\005\020\007J\017\020\t\032\0020\bH\007¢\006\004\b\t\020\nJ\030\020\r\032\0020\f2\006\020\013\032\0020\003H\002¢\006\004\b\r\020\016J#\020\021\032\b\022\004\022\0028\0000\020\"\004\b\000\020\0172\006\020\013\032\0020\003H\007¢\006\004\b\021\020\022J+\020\025\032\b\022\004\022\0028\0000\024\"\004\b\000\020\0172\006\020\013\032\0020\0032\006\020\023\032\0028\000H\007¢\006\004\b\025\020\026J \020\027\032\004\030\0018\000\"\004\b\000\020\0172\006\020\013\032\0020\003H\002¢\006\004\b\027\020\030J(\020\033\032\0020\032\"\004\b\000\020\0172\006\020\013\032\0020\0032\b\020\031\032\004\030\0018\000H\002¢\006\004\b\033\020\034J\037\020\035\032\004\030\0018\000\"\004\b\000\020\0172\006\020\013\032\0020\003H\007¢\006\004\b\035\020\030J3\020\037\032\b\022\004\022\0028\0000\020\"\004\b\000\020\0172\006\020\013\032\0020\0032\006\020\036\032\0020\f2\006\020\023\032\0028\000H\002¢\006\004\b\037\020 R\"\020$\032\020\022\004\022\0020\003\022\006\022\004\030\0010\0010!8\002X\004¢\006\006\n\004\b\"\020#R \020&\032\016\022\004\022\0020\003\022\004\022\0020\b0!8\002X\004¢\006\006\n\004\b%\020#R$\020)\032\022\022\004\022\0020\003\022\b\022\006\022\002\b\0030'0!8\002X\004¢\006\006\n\004\b(\020#R(\020,\032\026\022\004\022\0020\003\022\f\022\n\022\006\022\004\030\0010\0010*0!8\002X\004¢\006\006\n\004\b+\020#R\024\020.\032\0020\b8\002X\004¢\006\006\n\004\b\r\020-¨\006/"}, d2 = {"Landroidx/lifecycle/o;", "", "", "", "initialState", "<init>", "(Ljava/util/Map;)V", "()V", "Landroidx/savedstate/a$c;", "k", "()Landroidx/savedstate/a$c;", "key", "", "e", "(Ljava/lang/String;)Z", "T", "Ldbxyzptlk/U2/m;", "g", "(Ljava/lang/String;)Ldbxyzptlk/U2/m;", "initialValue", "Ldbxyzptlk/eK/S;", "i", "(Ljava/lang/String;Ljava/lang/Object;)Ldbxyzptlk/eK/S;", "f", "(Ljava/lang/String;)Ljava/lang/Object;", "value", "Ldbxyzptlk/pI/D;", "m", "(Ljava/lang/String;Ljava/lang/Object;)V", "j", "hasInitialValue", "h", "(Ljava/lang/String;ZLjava/lang/Object;)Ldbxyzptlk/U2/m;", "", "a", "Ljava/util/Map;", "regular", "b", "savedStateProviders", "Landroidx/lifecycle/o$b;", "c", "liveDatas", "Ldbxyzptlk/eK/C;", "d", "flows", "Landroidx/savedstate/a$c;", "savedStateProvider", "lifecycle-viewmodel-savedstate_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class o {
  public static final a f = new a(null);
  
  public static final Class<? extends Object>[] g = new Class[] { 
      boolean.class, boolean[].class, double.class, double[].class, int.class, int[].class, long.class, long[].class, String.class, String[].class, 
      Binder.class, Bundle.class, byte.class, byte[].class, char.class, char[].class, CharSequence.class, CharSequence[].class, ArrayList.class, float.class, 
      float[].class, Parcelable.class, Parcelable[].class, Serializable.class, short.class, short[].class, SparseArray.class, Size.class, SizeF.class };
  
  public final Map<String, Object> a;
  
  public final Map<String, androidx.savedstate.a.c> b;
  
  public final Map<String, b<?>> c;
  
  public final Map<String, C<Object>> d;
  
  public final androidx.savedstate.a.c e;
  
  public o() {
    this.a = new LinkedHashMap<>();
    this.b = new LinkedHashMap<>();
    this.c = new LinkedHashMap<>();
    this.d = new LinkedHashMap<>();
    this.e = (androidx.savedstate.a.c)new r(this);
  }
  
  public o(Map<String, ? extends Object> paramMap) {
    LinkedHashMap<Object, Object> linkedHashMap = new LinkedHashMap<>();
    this.a = (Map)linkedHashMap;
    this.b = new LinkedHashMap<>();
    this.c = new LinkedHashMap<>();
    this.d = new LinkedHashMap<>();
    this.e = (androidx.savedstate.a.c)new r(this);
    linkedHashMap.putAll(paramMap);
  }
  
  public static final Bundle l(o paramo) {
    s.h(paramo, "this$0");
    for (Map.Entry entry : P.x(paramo.b).entrySet())
      paramo.m((String)entry.getKey(), ((androidx.savedstate.a.c)entry.getValue()).e()); 
    Set<String> set = paramo.a.keySet();
    ArrayList<String> arrayList = new ArrayList(set.size());
    ArrayList arrayList1 = new ArrayList(arrayList.size());
    for (String str : set) {
      arrayList.add(str);
      arrayList1.add(paramo.a.get(str));
    } 
    return d.a(new n[] { t.a("keys", arrayList), t.a("values", arrayList1) });
  }
  
  public final boolean e(String paramString) {
    s.h(paramString, "key");
    return this.a.containsKey(paramString);
  }
  
  public final <T> T f(String paramString) {
    Object object;
    s.h(paramString, "key");
    try {
      Object object1 = this.a.get(paramString);
      object = object1;
    } catch (ClassCastException classCastException) {
      j((String)object);
      object = null;
    } 
    return (T)object;
  }
  
  public final <T> m<T> g(String paramString) {
    s.h(paramString, "key");
    m<?> m = h(paramString, false, null);
    s.f(m, "null cannot be cast to non-null type androidx.lifecycle.MutableLiveData<T of androidx.lifecycle.SavedStateHandle.getLiveData>");
    return (m)m;
  }
  
  public final <T> m<T> h(String paramString, boolean paramBoolean, T paramT) {
    b<?> b;
    m<T> m = (m<T>)this.c.get(paramString);
    if (m instanceof m) {
      m = m;
    } else {
      m = null;
    } 
    if (m != null)
      return m; 
    if (this.a.containsKey(paramString)) {
      b = new b(this, paramString, this.a.get(paramString));
    } else if (paramBoolean) {
      this.a.put(paramString, b);
      b = new b(this, paramString, b);
    } else {
      b = new b(this, paramString);
    } 
    this.c.put(paramString, b);
    return (m)b;
  }
  
  public final <T> S<T> i(String paramString, T paramT) {
    s.h(paramString, "key");
    Map<String, C<Object>> map = this.d;
    C<Object> c2 = (C<Object>)map.get(paramString);
    C<Object> c1 = c2;
    if (c2 == null) {
      if (!this.a.containsKey(paramString))
        this.a.put(paramString, paramT); 
      c1 = U.a(this.a.get(paramString));
      this.d.put(paramString, c1);
      map.put(paramString, c1);
    } 
    S<T> s = k.d(c1);
    s.f(s, "null cannot be cast to non-null type kotlinx.coroutines.flow.StateFlow<T of androidx.lifecycle.SavedStateHandle.getStateFlow>");
    return s;
  }
  
  public final <T> T j(String paramString) {
    s.h(paramString, "key");
    Object object = this.a.remove(paramString);
    b b = this.c.remove(paramString);
    if (b != null)
      b.q(); 
    this.d.remove(paramString);
    return (T)object;
  }
  
  public final androidx.savedstate.a.c k() {
    return this.e;
  }
  
  public final <T> void m(String paramString, T paramT) {
    s.h(paramString, "key");
    if (f.b(paramT)) {
      m m = (m)this.c.get(paramString);
      if (m instanceof m) {
        m = m;
      } else {
        m = null;
      } 
      if (m != null) {
        m.p(paramT);
      } else {
        this.a.put(paramString, paramT);
      } 
      C c1 = this.d.get(paramString);
      if (c1 != null)
        c1.setValue(paramT); 
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Can't put value with type ");
    s.e(paramT);
    stringBuilder.append(paramT.getClass());
    stringBuilder.append(" into saved state");
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  @Metadata(d1 = {"\0008\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\003\n\002\020\013\n\002\b\002\n\002\020\021\n\002\030\002\n\002\b\002\n\002\020\016\n\002\b\004\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J#\020\b\032\0020\0072\b\020\005\032\004\030\0010\0042\b\020\006\032\004\030\0010\004H\007¢\006\004\b\b\020\tJ\031\020\f\032\0020\0132\b\020\n\032\004\030\0010\001H\007¢\006\004\b\f\020\rR$\020\020\032\022\022\016\022\f\022\006\b\001\022\0020\001\030\0010\0170\0168\002X\004¢\006\006\n\004\b\020\020\021R\024\020\023\032\0020\0228\002XT¢\006\006\n\004\b\023\020\024R\024\020\025\032\0020\0228\002XT¢\006\006\n\004\b\025\020\024¨\006\026"}, d2 = {"Landroidx/lifecycle/o$a;", "", "<init>", "()V", "Landroid/os/Bundle;", "restoredState", "defaultState", "Landroidx/lifecycle/o;", "a", "(Landroid/os/Bundle;Landroid/os/Bundle;)Landroidx/lifecycle/o;", "value", "", "b", "(Ljava/lang/Object;)Z", "", "Ljava/lang/Class;", "ACCEPTABLE_CLASSES", "[Ljava/lang/Class;", "", "KEYS", "Ljava/lang/String;", "VALUES", "lifecycle-viewmodel-savedstate_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class a {
    public a() {}
    
    public final o a(Bundle param1Bundle1, Bundle param1Bundle2) {
      o o;
      if (param1Bundle1 == null) {
        if (param1Bundle2 == null) {
          o = new o();
        } else {
          HashMap<Object, Object> hashMap = new HashMap<>();
          for (String str : param1Bundle2.keySet()) {
            s.g(str, "key");
            hashMap.put(str, param1Bundle2.get(str));
          } 
          o = new o((Map)hashMap);
        } 
        return o;
      } 
      ClassLoader classLoader = o.class.getClassLoader();
      s.e(classLoader);
      o.setClassLoader(classLoader);
      ArrayList<Object> arrayList1 = o.getParcelableArrayList("keys");
      ArrayList arrayList = o.getParcelableArrayList("values");
      if (arrayList1 != null && arrayList != null && arrayList1.size() == arrayList.size()) {
        LinkedHashMap<Object, Object> linkedHashMap = new LinkedHashMap<>();
        int i = arrayList1.size();
        for (byte b = 0; b < i; b++) {
          String str = (String)arrayList1.get(b);
          s.f(str, "null cannot be cast to non-null type kotlin.String");
          linkedHashMap.put(str, arrayList.get(b));
        } 
        return new o((Map)linkedHashMap);
      } 
      throw new IllegalStateException("Invalid bundle passed as restored state");
    }
    
    public final boolean b(Object param1Object) {
      if (param1Object == null)
        return true; 
      for (Class clazz : o.b()) {
        s.e(clazz);
        if (clazz.isInstance(param1Object))
          return true; 
      } 
      return false;
    }
  }
  
  class o {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\lifecycle\o.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */