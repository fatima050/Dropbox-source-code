package androidx.lifecycle;

import dbxyzptlk.U2.n;
import java.util.Map;

public abstract class LiveData<T> {
  public static final Object k = new Object();
  
  public final Object a = new Object();
  
  public dbxyzptlk.t.b<n<? super T>, c> b = new dbxyzptlk.t.b();
  
  public int c = 0;
  
  public boolean d;
  
  public volatile Object e;
  
  public volatile Object f;
  
  public int g;
  
  public boolean h;
  
  public boolean i;
  
  public final Runnable j;
  
  public LiveData() {
    Object object = k;
    this.f = object;
    this.j = new a(this);
    this.e = object;
    this.g = -1;
  }
  
  public LiveData(T paramT) {
    this.f = k;
    this.j = new a(this);
    this.e = paramT;
    this.g = 0;
  }
  
  public static void b(String paramString) {
    if (dbxyzptlk.s.c.h().c())
      return; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Cannot invoke ");
    stringBuilder.append(paramString);
    stringBuilder.append(" on a background thread");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public void c(int paramInt) {
    int i = this.c;
    this.c = paramInt + i;
    if (this.d)
      return; 
    this.d = true;
    while (true) {
      try {
        int j = this.c;
        if (i != j) {
          if (i == 0 && j > 0) {
            paramInt = 1;
          } else {
            paramInt = 0;
          } 
          if (i > 0 && j == 0) {
            i = 1;
          } else {
            i = 0;
          } 
          if (paramInt != 0) {
            l();
          } else if (i != 0) {
            m();
          } 
          i = j;
          continue;
        } 
      } finally {
        Exception exception;
      } 
      this.d = false;
      return;
    } 
  }
  
  public final void d(c paramc) {
    if (!paramc.b)
      return; 
    if (!paramc.d()) {
      paramc.a(false);
      return;
    } 
    int i = paramc.c;
    int j = this.g;
    if (i >= j)
      return; 
    paramc.c = j;
    paramc.a.a(this.e);
  }
  
  public void e(c paramc) {
    if (this.h) {
      this.i = true;
      return;
    } 
    this.h = true;
    while (true) {
      c c1;
      this.i = false;
      if (paramc != null) {
        d(paramc);
        c1 = null;
      } else {
        dbxyzptlk.t.b.d<Map.Entry> d = this.b.j();
        while (true) {
          c1 = paramc;
          if (d.hasNext()) {
            d((c)((Map.Entry)d.next()).getValue());
            if (this.i) {
              c1 = paramc;
              break;
            } 
            continue;
          } 
          break;
        } 
      } 
      paramc = c1;
      if (!this.i) {
        this.h = false;
        return;
      } 
    } 
  }
  
  public T f() {
    Object object = this.e;
    return (T)((object != k) ? object : null);
  }
  
  public int g() {
    return this.g;
  }
  
  public boolean h() {
    boolean bool;
    if (this.c > 0) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public boolean i() {
    boolean bool;
    if (this.e != k) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public void j(LifecycleOwner paramLifecycleOwner, n<? super T> paramn) {
    b("observe");
    if (paramLifecycleOwner.getLifecycle().b() == f.b.DESTROYED)
      return; 
    LifecycleBoundObserver lifecycleBoundObserver = new LifecycleBoundObserver(this, paramLifecycleOwner, paramn);
    c c = (c)this.b.m(paramn, lifecycleBoundObserver);
    if (c == null || c.c(paramLifecycleOwner)) {
      if (c != null)
        return; 
      paramLifecycleOwner.getLifecycle().a(lifecycleBoundObserver);
      return;
    } 
    throw new IllegalArgumentException("Cannot add the same observer with different lifecycles");
  }
  
  public void k(n<? super T> paramn) {
    b("observeForever");
    b b1 = new b(this, paramn);
    c c = (c)this.b.m(paramn, b1);
    if (!(c instanceof LifecycleBoundObserver)) {
      if (c != null)
        return; 
      b1.a(true);
      return;
    } 
    throw new IllegalArgumentException("Cannot add the same observer with different lifecycles");
  }
  
  public void l() {}
  
  public void m() {}
  
  public void n(T paramT) {
    synchronized (this.a) {
      boolean bool;
      if (this.f == k) {
        bool = true;
      } else {
        bool = false;
      } 
      this.f = paramT;
      if (!bool)
        return; 
      dbxyzptlk.s.c.h().d(this.j);
      return;
    } 
  }
  
  public void o(n<? super T> paramn) {
    b("removeObserver");
    c c = (c)this.b.p(paramn);
    if (c == null)
      return; 
    c.b();
    c.a(false);
  }
  
  public void p(T paramT) {
    b("setValue");
    this.g++;
    this.e = paramT;
    e(null);
  }
  
  public class LifecycleBoundObserver extends c implements LifecycleEventObserver {
    public final LifecycleOwner e;
    
    public final LiveData f;
    
    public LifecycleBoundObserver(LiveData this$0, LifecycleOwner param1LifecycleOwner, n<? super T> param1n) {
      super(this$0, param1n);
      this.e = param1LifecycleOwner;
    }
    
    public void b() {
      this.e.getLifecycle().d(this);
    }
    
    public boolean c(LifecycleOwner param1LifecycleOwner) {
      boolean bool;
      if (this.e == param1LifecycleOwner) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    public boolean d() {
      return this.e.getLifecycle().b().isAtLeast(f.b.STARTED);
    }
    
    public void f(LifecycleOwner param1LifecycleOwner, f.a param1a) {
      f.b b = this.e.getLifecycle().b();
      if (b == f.b.DESTROYED) {
        this.f.o(this.a);
        return;
      } 
      param1a = null;
      while (param1a != b) {
        a(d());
        f.b b2 = this.e.getLifecycle().b();
        f.b b1 = b;
        b = b2;
      } 
    }
  }
  
  public class a implements Runnable {
    public final LiveData a;
    
    public a(LiveData this$0) {}
    
    public void run() {
      synchronized (this.a.a) {
        Object object = this.a.f;
        this.a.f = LiveData.k;
        this.a.p(object);
        return;
      } 
    }
  }
  
  public class b extends c {
    public final LiveData e;
    
    public b(LiveData this$0, n<? super T> param1n) {
      super(this$0, param1n);
    }
    
    public boolean d() {
      return true;
    }
  }
  
  public abstract class c {
    public final n<? super T> a;
    
    public boolean b;
    
    public int c = -1;
    
    public final LiveData d;
    
    public c(LiveData this$0, n<? super T> param1n) {
      this.a = param1n;
    }
    
    public void a(boolean param1Boolean) {
      byte b;
      if (param1Boolean == this.b)
        return; 
      this.b = param1Boolean;
      LiveData liveData = this.d;
      if (param1Boolean) {
        b = 1;
      } else {
        b = -1;
      } 
      liveData.c(b);
      if (this.b)
        this.d.e(this); 
    }
    
    public void b() {}
    
    public boolean c(LifecycleOwner param1LifecycleOwner) {
      return false;
    }
    
    public abstract boolean d();
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\lifecycle\LiveData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */