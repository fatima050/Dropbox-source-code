package androidx.lifecycle;

import dbxyzptlk.CI.p;
import dbxyzptlk.DI.K;
import dbxyzptlk.U2.h;
import dbxyzptlk.bK.J;
import dbxyzptlk.bK.K;
import dbxyzptlk.bK.Z;
import dbxyzptlk.bK.h;
import dbxyzptlk.bK.m;
import dbxyzptlk.bK.w0;
import dbxyzptlk.pI.D;
import dbxyzptlk.pI.o;
import dbxyzptlk.pI.p;
import dbxyzptlk.tI.d;
import dbxyzptlk.tI.g;
import dbxyzptlk.uI.c;
import dbxyzptlk.vI.f;
import dbxyzptlk.vI.l;
import kotlin.Metadata;

@Metadata(d1 = {"\000*\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\000\n\002\b\003\n\002\030\002\n\002\b\003\032@\020\t\032\0020\006*\0020\0002\006\020\002\032\0020\0012\"\020\b\032\036\b\001\022\004\022\0020\004\022\n\022\b\022\004\022\0020\0060\005\022\006\022\004\030\0010\0070\003H@¢\006\004\b\t\020\n\032@\020\f\032\0020\006*\0020\0132\006\020\002\032\0020\0012\"\020\b\032\036\b\001\022\004\022\0020\004\022\n\022\b\022\004\022\0020\0060\005\022\006\022\004\030\0010\0070\003H@¢\006\004\b\f\020\r¨\006\016"}, d2 = {"Landroidx/lifecycle/f;", "Landroidx/lifecycle/f$b;", "state", "Lkotlin/Function2;", "Ldbxyzptlk/bK/J;", "Ldbxyzptlk/tI/d;", "Ldbxyzptlk/pI/D;", "", "block", "a", "(Landroidx/lifecycle/f;Landroidx/lifecycle/f$b;Ldbxyzptlk/CI/p;Ldbxyzptlk/tI/d;)Ljava/lang/Object;", "Landroidx/lifecycle/LifecycleOwner;", "b", "(Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/f$b;Ldbxyzptlk/CI/p;Ldbxyzptlk/tI/d;)Ljava/lang/Object;", "lifecycle-runtime-ktx_release"}, k = 2, mv = {1, 8, 0}, xi = 48)
public final class RepeatOnLifecycleKt {
  public static final Object a(f paramf, f.b paramb, p<? super J, ? super d<? super D>, ? extends Object> paramp, d<? super D> paramd) {
    if (paramb != f.b.INITIALIZED) {
      if (paramf.b() == f.b.DESTROYED)
        return D.a; 
      Object object = K.g(new RepeatOnLifecycleKt$repeatOnLifecycle$3(paramf, paramb, paramp, null), paramd);
      return (object == c.g()) ? object : D.a;
    } 
    throw new IllegalArgumentException("repeatOnLifecycle cannot start work with the INITIALIZED lifecycle state.");
  }
  
  public static final Object b(LifecycleOwner paramLifecycleOwner, f.b paramb, p<? super J, ? super d<? super D>, ? extends Object> paramp, d<? super D> paramd) {
    Object object = a(paramLifecycleOwner.getLifecycle(), paramb, paramp, paramd);
    return (object == c.g()) ? object : D.a;
  }
  
  @f(c = "androidx.lifecycle.RepeatOnLifecycleKt$repeatOnLifecycle$3", f = "RepeatOnLifecycle.kt", l = {84}, m = "invokeSuspend")
  @Metadata(d1 = {"\000\f\n\002\030\002\n\002\030\002\n\002\b\002\020\002\032\0020\001*\0020\000H@¢\006\004\b\002\020\003"}, d2 = {"Ldbxyzptlk/bK/J;", "Ldbxyzptlk/pI/D;", "<anonymous>", "(Ldbxyzptlk/bK/J;)V"}, k = 3, mv = {1, 8, 0})
  public static final class RepeatOnLifecycleKt$repeatOnLifecycle$3 extends l implements p<J, d<? super D>, Object> {
    public int t;
    
    public Object u;
    
    public final f v;
    
    public final f.b w;
    
    public final p<J, d<? super D>, Object> x;
    
    public RepeatOnLifecycleKt$repeatOnLifecycle$3(f param1f, f.b param1b, p<? super J, ? super d<? super D>, ? extends Object> param1p, d<? super RepeatOnLifecycleKt$repeatOnLifecycle$3> param1d) {
      super(2, param1d);
    }
    
    public final d<D> create(Object param1Object, d<?> param1d) {
      RepeatOnLifecycleKt$repeatOnLifecycle$3 repeatOnLifecycleKt$repeatOnLifecycle$3 = new RepeatOnLifecycleKt$repeatOnLifecycle$3(this.v, this.w, this.x, (d)param1d);
      repeatOnLifecycleKt$repeatOnLifecycle$3.u = param1Object;
      return (d<D>)repeatOnLifecycleKt$repeatOnLifecycle$3;
    }
    
    public final Object invoke(J param1J, d<? super D> param1d) {
      return ((RepeatOnLifecycleKt$repeatOnLifecycle$3)create(param1J, param1d)).invokeSuspend(D.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = c.g();
      int i = this.t;
      if (i != 0) {
        if (i == 1) {
          p.b(param1Object);
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        p.b(param1Object);
        J j = (J)this.u;
        param1Object = Z.c().y0();
        p<J, d<? super D>, Object> p1 = new p<J, d<? super D>, Object>(this.v, this.w, j, this.x, null) {
            public final f A;
            
            public final f.b B;
            
            public final J C;
            
            public final p<J, d<? super D>, Object> D;
            
            public Object t;
            
            public Object u;
            
            public Object v;
            
            public Object w;
            
            public Object x;
            
            public Object y;
            
            public int z;
            
            public final d<D> create(Object param1Object, d<?> param1d) {
              return (d)new p<>(this.A, this.B, this.C, this.D, (d)param1d);
            }
            
            public final Object invoke(J param1J, d<? super D> param1d) {
              return ((null)create(param1J, param1d)).invokeSuspend(D.a);
            }
            
            public final Object invokeSuspend(Object param1Object) {
              K<w0> k;
              Object object = c.g();
              int i = this.z;
              if (i != 0) {
                if (i == 1) {
                  p p1 = (p)this.y;
                  J j = (J)this.x;
                  f f1 = (f)this.w;
                  f.b b1 = (f.b)this.v;
                  object = this.u;
                  k = (K)this.t;
                  try {
                    p.b(param1Object);
                  } finally {}
                } else {
                  throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                } 
              } else {
                Object object1;
                p.b(param1Object);
                if (this.A.b() == f.b.DESTROYED)
                  return D.a; 
                k = new K();
                param1Object = new K();
              } 
              param1Object = k.a;
              if (param1Object != null)
                w0.a.a((w0)param1Object, null, 1, null); 
              param1Object = ((K)object).a;
              if (param1Object != null)
                this.A.d((h)param1Object); 
              return D.a;
            }
          };
        this.t = 1;
        if (h.g((g)param1Object, p1, (d)this) == object)
          return object; 
      } 
      return D.a;
    }
  }
  
  @f(c = "androidx.lifecycle.RepeatOnLifecycleKt$repeatOnLifecycle$3$1", f = "RepeatOnLifecycle.kt", l = {166}, m = "invokeSuspend")
  @Metadata(d1 = {"\000\f\n\002\030\002\n\002\030\002\n\002\b\002\020\002\032\0020\001*\0020\000H@¢\006\004\b\002\020\003"}, d2 = {"Ldbxyzptlk/bK/J;", "Ldbxyzptlk/pI/D;", "<anonymous>", "(Ldbxyzptlk/bK/J;)V"}, k = 3, mv = {1, 8, 0})
  public static final class null extends l implements p<J, d<? super D>, Object> {
    public final f A;
    
    public final f.b B;
    
    public final J C;
    
    public final p<J, d<? super D>, Object> D;
    
    public Object t;
    
    public Object u;
    
    public Object v;
    
    public Object w;
    
    public Object x;
    
    public Object y;
    
    public int z;
    
    public null(f param1f, f.b param1b, J param1J, p<? super J, ? super d<? super D>, ? extends Object> param1p, d<? super null> param1d) {
      super(2, param1d);
    }
    
    public final d<D> create(Object param1Object, d<?> param1d) {
      return (d)new p<>(this.A, this.B, this.C, this.D, (d)param1d);
    }
    
    public final Object invoke(J param1J, d<? super D> param1d) {
      return ((null)create(param1J, param1d)).invokeSuspend(D.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      K<w0> k;
      Object object = c.g();
      int i = this.z;
      if (i != 0) {
        if (i == 1) {
          p p1 = (p)this.y;
          J j = (J)this.x;
          f f1 = (f)this.w;
          f.b b1 = (f.b)this.v;
          object = this.u;
          k = (K)this.t;
          try {
            p.b(param1Object);
          } finally {}
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        Object object1;
        p.b(param1Object);
        if (this.A.b() == f.b.DESTROYED)
          return D.a; 
        k = new K();
        param1Object = new K();
      } 
      param1Object = k.a;
      if (param1Object != null)
        w0.a.a((w0)param1Object, null, 1, null); 
      param1Object = ((K)object).a;
      if (param1Object != null)
        this.A.d((h)param1Object); 
      return D.a;
    }
  }
  
  @Metadata(d1 = {"\000\024\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\002\020\005\032\0020\0042\006\020\001\032\0020\0002\006\020\003\032\0020\002H\n¢\006\004\b\005\020\006"}, d2 = {"Landroidx/lifecycle/LifecycleOwner;", "<anonymous parameter 0>", "Landroidx/lifecycle/f$a;", "event", "Ldbxyzptlk/pI/D;", "f", "(Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/f$a;)V"}, k = 3, mv = {1, 8, 0})
  public static final class RepeatOnLifecycleKt$repeatOnLifecycle$3$1$1$1 implements LifecycleEventObserver {
    public final f.a a;
    
    public final K<w0> b;
    
    public final J c;
    
    public final f.a d;
    
    public final m<D> e;
    
    public final dbxyzptlk.mK.a f;
    
    public final p<J, d<? super D>, Object> g;
    
    public RepeatOnLifecycleKt$repeatOnLifecycle$3$1$1$1(f.a param1a1, K<w0> param1K, J param1J, f.a param1a2, m<? super D> param1m, dbxyzptlk.mK.a param1a, p<? super J, ? super d<? super D>, ? extends Object> param1p) {}
    
    public final void f(LifecycleOwner param1LifecycleOwner, f.a param1a) {
      if (param1a == this.a) {
        this.b.a = h.d(this.c, null, null, new a(this.f, this.g, null), 3, null);
        return;
      } 
      if (param1a == this.d) {
        w0 w0 = (w0)this.b.a;
        if (w0 != null)
          w0.a.a(w0, null, 1, null); 
        this.b.a = null;
      } 
      if (param1a == f.a.ON_DESTROY) {
        m<D> m1 = this.e;
        o.a a1 = o.b;
        m1.resumeWith(o.b(D.a));
      } 
    }
    
    @f(c = "androidx.lifecycle.RepeatOnLifecycleKt$repeatOnLifecycle$3$1$1$1$1", f = "RepeatOnLifecycle.kt", l = {171, 110}, m = "invokeSuspend")
    @Metadata(d1 = {"\000\f\n\002\030\002\n\002\030\002\n\002\b\002\020\002\032\0020\001*\0020\000H@¢\006\004\b\002\020\003"}, d2 = {"Ldbxyzptlk/bK/J;", "Ldbxyzptlk/pI/D;", "<anonymous>", "(Ldbxyzptlk/bK/J;)V"}, k = 3, mv = {1, 8, 0})
    public static final class a extends l implements p<J, d<? super D>, Object> {
      public Object t;
      
      public Object u;
      
      public int v;
      
      public final dbxyzptlk.mK.a w;
      
      public final p<J, d<? super D>, Object> x;
      
      public a(dbxyzptlk.mK.a param1a, p<? super J, ? super d<? super D>, ? extends Object> param1p, d<? super a> param1d) {
        super(2, param1d);
      }
      
      public final d<D> create(Object param1Object, d<?> param1d) {
        return (d<D>)new a(this.w, this.x, (d)param1d);
      }
      
      public final Object invoke(J param1J, d<? super D> param1d) {
        return ((a)create(param1J, param1d)).invokeSuspend(D.a);
      }
      
      public final Object invokeSuspend(Object param1Object) {
        // Byte code:
        //   0: invokestatic g : ()Ljava/lang/Object;
        //   3: astore #5
        //   5: aload_0
        //   6: getfield v : I
        //   9: istore_2
        //   10: iload_2
        //   11: ifeq -> 92
        //   14: iload_2
        //   15: iconst_1
        //   16: if_icmpeq -> 65
        //   19: iload_2
        //   20: iconst_2
        //   21: if_icmpne -> 55
        //   24: aload_0
        //   25: getfield t : Ljava/lang/Object;
        //   28: checkcast dbxyzptlk/mK/a
        //   31: astore #4
        //   33: aload #4
        //   35: astore_3
        //   36: aload_1
        //   37: invokestatic b : (Ljava/lang/Object;)V
        //   40: aload #4
        //   42: astore_1
        //   43: goto -> 186
        //   46: astore_1
        //   47: aload_3
        //   48: astore #4
        //   50: aload_1
        //   51: astore_3
        //   52: goto -> 208
        //   55: new java/lang/IllegalStateException
        //   58: dup
        //   59: ldc 'call to 'resume' before 'invoke' with coroutine'
        //   61: invokespecial <init> : (Ljava/lang/String;)V
        //   64: athrow
        //   65: aload_0
        //   66: getfield u : Ljava/lang/Object;
        //   69: checkcast dbxyzptlk/CI/p
        //   72: astore_3
        //   73: aload_0
        //   74: getfield t : Ljava/lang/Object;
        //   77: checkcast dbxyzptlk/mK/a
        //   80: astore #4
        //   82: aload_1
        //   83: invokestatic b : (Ljava/lang/Object;)V
        //   86: aload #4
        //   88: astore_1
        //   89: goto -> 143
        //   92: aload_1
        //   93: invokestatic b : (Ljava/lang/Object;)V
        //   96: aload_0
        //   97: getfield w : Ldbxyzptlk/mK/a;
        //   100: astore #4
        //   102: aload_0
        //   103: getfield x : Ldbxyzptlk/CI/p;
        //   106: astore_3
        //   107: aload_0
        //   108: aload #4
        //   110: putfield t : Ljava/lang/Object;
        //   113: aload_0
        //   114: aload_3
        //   115: putfield u : Ljava/lang/Object;
        //   118: aload_0
        //   119: iconst_1
        //   120: putfield v : I
        //   123: aload #4
        //   125: astore_1
        //   126: aload #4
        //   128: aconst_null
        //   129: aload_0
        //   130: invokeinterface a : (Ljava/lang/Object;Ldbxyzptlk/tI/d;)Ljava/lang/Object;
        //   135: aload #5
        //   137: if_acmpne -> 143
        //   140: aload #5
        //   142: areturn
        //   143: new androidx/lifecycle/RepeatOnLifecycleKt$repeatOnLifecycle$3$1$1$1$a$a
        //   146: astore #4
        //   148: aload #4
        //   150: aload_3
        //   151: aconst_null
        //   152: invokespecial <init> : (Ldbxyzptlk/CI/p;Ldbxyzptlk/tI/d;)V
        //   155: aload_0
        //   156: aload_1
        //   157: putfield t : Ljava/lang/Object;
        //   160: aload_0
        //   161: aconst_null
        //   162: putfield u : Ljava/lang/Object;
        //   165: aload_0
        //   166: iconst_2
        //   167: putfield v : I
        //   170: aload #4
        //   172: aload_0
        //   173: invokestatic g : (Ldbxyzptlk/CI/p;Ldbxyzptlk/tI/d;)Ljava/lang/Object;
        //   176: astore_3
        //   177: aload_3
        //   178: aload #5
        //   180: if_acmpne -> 186
        //   183: aload #5
        //   185: areturn
        //   186: aload_1
        //   187: astore_3
        //   188: getstatic dbxyzptlk/pI/D.a : Ldbxyzptlk/pI/D;
        //   191: astore #4
        //   193: aload_1
        //   194: aconst_null
        //   195: invokeinterface d : (Ljava/lang/Object;)V
        //   200: getstatic dbxyzptlk/pI/D.a : Ldbxyzptlk/pI/D;
        //   203: areturn
        //   204: astore_3
        //   205: aload_1
        //   206: astore #4
        //   208: aload #4
        //   210: aconst_null
        //   211: invokeinterface d : (Ljava/lang/Object;)V
        //   216: aload_3
        //   217: athrow
        // Exception table:
        //   from	to	target	type
        //   36	40	46	finally
        //   143	177	204	finally
        //   188	193	46	finally
      }
      
      @f(c = "androidx.lifecycle.RepeatOnLifecycleKt$repeatOnLifecycle$3$1$1$1$1$1$1", f = "RepeatOnLifecycle.kt", l = {111}, m = "invokeSuspend")
      @Metadata(d1 = {"\000\f\n\002\030\002\n\002\030\002\n\002\b\002\020\002\032\0020\001*\0020\000H@¢\006\004\b\002\020\003"}, d2 = {"Ldbxyzptlk/bK/J;", "Ldbxyzptlk/pI/D;", "<anonymous>", "(Ldbxyzptlk/bK/J;)V"}, k = 3, mv = {1, 8, 0})
      public static final class a extends l implements p<J, d<? super D>, Object> {
        public int t;
        
        public Object u;
        
        public final p<J, d<? super D>, Object> v;
        
        public a(p<? super J, ? super d<? super D>, ? extends Object> param2p, d<? super a> param2d) {
          super(2, param2d);
        }
        
        public final d<D> create(Object param2Object, d<?> param2d) {
          a a1 = new a(this.v, (d)param2d);
          a1.u = param2Object;
          return (d<D>)a1;
        }
        
        public final Object invoke(J param2J, d<? super D> param2d) {
          return ((a)create(param2J, param2d)).invokeSuspend(D.a);
        }
        
        public final Object invokeSuspend(Object param2Object) {
          Object object = c.g();
          int i = this.t;
          if (i != 0) {
            if (i == 1) {
              p.b(param2Object);
            } else {
              throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            } 
          } else {
            p.b(param2Object);
            param2Object = this.u;
            p<J, d<? super D>, Object> p1 = this.v;
            this.t = 1;
            if (p1.invoke(param2Object, this) == object)
              return object; 
          } 
          return D.a;
        }
      }
    }
    
    @f(c = "androidx.lifecycle.RepeatOnLifecycleKt$repeatOnLifecycle$3$1$1$1$1$1$1", f = "RepeatOnLifecycle.kt", l = {111}, m = "invokeSuspend")
    @Metadata(d1 = {"\000\f\n\002\030\002\n\002\030\002\n\002\b\002\020\002\032\0020\001*\0020\000H@¢\006\004\b\002\020\003"}, d2 = {"Ldbxyzptlk/bK/J;", "Ldbxyzptlk/pI/D;", "<anonymous>", "(Ldbxyzptlk/bK/J;)V"}, k = 3, mv = {1, 8, 0})
    public static final class a extends l implements p<J, d<? super D>, Object> {
      public int t;
      
      public Object u;
      
      public final p<J, d<? super D>, Object> v;
      
      public a(p<? super J, ? super d<? super D>, ? extends Object> param1p, d<? super a> param1d) {
        super(2, param1d);
      }
      
      public final d<D> create(Object param1Object, d<?> param1d) {
        a a1 = new a(this.v, (d)param1d);
        a1.u = param1Object;
        return (d<D>)a1;
      }
      
      public final Object invoke(J param1J, d<? super D> param1d) {
        return ((a)create(param1J, param1d)).invokeSuspend(D.a);
      }
      
      public final Object invokeSuspend(Object param1Object) {
        Object object = c.g();
        int i = this.t;
        if (i != 0) {
          if (i == 1) {
            p.b(param1Object);
          } else {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
          } 
        } else {
          p.b(param1Object);
          param1Object = this.u;
          p<J, d<? super D>, Object> p1 = this.v;
          this.t = 1;
          if (p1.invoke(param1Object, this) == object)
            return object; 
        } 
        return D.a;
      }
    }
  }
  
  @f(c = "androidx.lifecycle.RepeatOnLifecycleKt$repeatOnLifecycle$3$1$1$1$1", f = "RepeatOnLifecycle.kt", l = {171, 110}, m = "invokeSuspend")
  @Metadata(d1 = {"\000\f\n\002\030\002\n\002\030\002\n\002\b\002\020\002\032\0020\001*\0020\000H@¢\006\004\b\002\020\003"}, d2 = {"Ldbxyzptlk/bK/J;", "Ldbxyzptlk/pI/D;", "<anonymous>", "(Ldbxyzptlk/bK/J;)V"}, k = 3, mv = {1, 8, 0})
  public static final class a extends l implements p<J, d<? super D>, Object> {
    public Object t;
    
    public Object u;
    
    public int v;
    
    public final dbxyzptlk.mK.a w;
    
    public final p<J, d<? super D>, Object> x;
    
    public a(dbxyzptlk.mK.a param1a, p<? super J, ? super d<? super D>, ? extends Object> param1p, d<? super a> param1d) {
      super(2, param1d);
    }
    
    public final d<D> create(Object param1Object, d<?> param1d) {
      return (d<D>)new a(this.w, this.x, (d)param1d);
    }
    
    public final Object invoke(J param1J, d<? super D> param1d) {
      return ((a)create(param1J, param1d)).invokeSuspend(D.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      // Byte code:
      //   0: invokestatic g : ()Ljava/lang/Object;
      //   3: astore #5
      //   5: aload_0
      //   6: getfield v : I
      //   9: istore_2
      //   10: iload_2
      //   11: ifeq -> 92
      //   14: iload_2
      //   15: iconst_1
      //   16: if_icmpeq -> 65
      //   19: iload_2
      //   20: iconst_2
      //   21: if_icmpne -> 55
      //   24: aload_0
      //   25: getfield t : Ljava/lang/Object;
      //   28: checkcast dbxyzptlk/mK/a
      //   31: astore #4
      //   33: aload #4
      //   35: astore_3
      //   36: aload_1
      //   37: invokestatic b : (Ljava/lang/Object;)V
      //   40: aload #4
      //   42: astore_1
      //   43: goto -> 186
      //   46: astore_1
      //   47: aload_3
      //   48: astore #4
      //   50: aload_1
      //   51: astore_3
      //   52: goto -> 208
      //   55: new java/lang/IllegalStateException
      //   58: dup
      //   59: ldc 'call to 'resume' before 'invoke' with coroutine'
      //   61: invokespecial <init> : (Ljava/lang/String;)V
      //   64: athrow
      //   65: aload_0
      //   66: getfield u : Ljava/lang/Object;
      //   69: checkcast dbxyzptlk/CI/p
      //   72: astore_3
      //   73: aload_0
      //   74: getfield t : Ljava/lang/Object;
      //   77: checkcast dbxyzptlk/mK/a
      //   80: astore #4
      //   82: aload_1
      //   83: invokestatic b : (Ljava/lang/Object;)V
      //   86: aload #4
      //   88: astore_1
      //   89: goto -> 143
      //   92: aload_1
      //   93: invokestatic b : (Ljava/lang/Object;)V
      //   96: aload_0
      //   97: getfield w : Ldbxyzptlk/mK/a;
      //   100: astore #4
      //   102: aload_0
      //   103: getfield x : Ldbxyzptlk/CI/p;
      //   106: astore_3
      //   107: aload_0
      //   108: aload #4
      //   110: putfield t : Ljava/lang/Object;
      //   113: aload_0
      //   114: aload_3
      //   115: putfield u : Ljava/lang/Object;
      //   118: aload_0
      //   119: iconst_1
      //   120: putfield v : I
      //   123: aload #4
      //   125: astore_1
      //   126: aload #4
      //   128: aconst_null
      //   129: aload_0
      //   130: invokeinterface a : (Ljava/lang/Object;Ldbxyzptlk/tI/d;)Ljava/lang/Object;
      //   135: aload #5
      //   137: if_acmpne -> 143
      //   140: aload #5
      //   142: areturn
      //   143: new androidx/lifecycle/RepeatOnLifecycleKt$repeatOnLifecycle$3$1$1$1$a$a
      //   146: astore #4
      //   148: aload #4
      //   150: aload_3
      //   151: aconst_null
      //   152: invokespecial <init> : (Ldbxyzptlk/CI/p;Ldbxyzptlk/tI/d;)V
      //   155: aload_0
      //   156: aload_1
      //   157: putfield t : Ljava/lang/Object;
      //   160: aload_0
      //   161: aconst_null
      //   162: putfield u : Ljava/lang/Object;
      //   165: aload_0
      //   166: iconst_2
      //   167: putfield v : I
      //   170: aload #4
      //   172: aload_0
      //   173: invokestatic g : (Ldbxyzptlk/CI/p;Ldbxyzptlk/tI/d;)Ljava/lang/Object;
      //   176: astore_3
      //   177: aload_3
      //   178: aload #5
      //   180: if_acmpne -> 186
      //   183: aload #5
      //   185: areturn
      //   186: aload_1
      //   187: astore_3
      //   188: getstatic dbxyzptlk/pI/D.a : Ldbxyzptlk/pI/D;
      //   191: astore #4
      //   193: aload_1
      //   194: aconst_null
      //   195: invokeinterface d : (Ljava/lang/Object;)V
      //   200: getstatic dbxyzptlk/pI/D.a : Ldbxyzptlk/pI/D;
      //   203: areturn
      //   204: astore_3
      //   205: aload_1
      //   206: astore #4
      //   208: aload #4
      //   210: aconst_null
      //   211: invokeinterface d : (Ljava/lang/Object;)V
      //   216: aload_3
      //   217: athrow
      // Exception table:
      //   from	to	target	type
      //   36	40	46	finally
      //   143	177	204	finally
      //   188	193	46	finally
    }
    
    @f(c = "androidx.lifecycle.RepeatOnLifecycleKt$repeatOnLifecycle$3$1$1$1$1$1$1", f = "RepeatOnLifecycle.kt", l = {111}, m = "invokeSuspend")
    @Metadata(d1 = {"\000\f\n\002\030\002\n\002\030\002\n\002\b\002\020\002\032\0020\001*\0020\000H@¢\006\004\b\002\020\003"}, d2 = {"Ldbxyzptlk/bK/J;", "Ldbxyzptlk/pI/D;", "<anonymous>", "(Ldbxyzptlk/bK/J;)V"}, k = 3, mv = {1, 8, 0})
    public static final class a extends l implements p<J, d<? super D>, Object> {
      public int t;
      
      public Object u;
      
      public final p<J, d<? super D>, Object> v;
      
      public a(p<? super J, ? super d<? super D>, ? extends Object> param2p, d<? super a> param2d) {
        super(2, param2d);
      }
      
      public final d<D> create(Object param2Object, d<?> param2d) {
        a a1 = new a(this.v, (d)param2d);
        a1.u = param2Object;
        return (d<D>)a1;
      }
      
      public final Object invoke(J param2J, d<? super D> param2d) {
        return ((a)create(param2J, param2d)).invokeSuspend(D.a);
      }
      
      public final Object invokeSuspend(Object param2Object) {
        Object object = c.g();
        int i = this.t;
        if (i != 0) {
          if (i == 1) {
            p.b(param2Object);
          } else {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
          } 
        } else {
          p.b(param2Object);
          param2Object = this.u;
          p<J, d<? super D>, Object> p1 = this.v;
          this.t = 1;
          if (p1.invoke(param2Object, this) == object)
            return object; 
        } 
        return D.a;
      }
    }
  }
  
  @f(c = "androidx.lifecycle.RepeatOnLifecycleKt$repeatOnLifecycle$3$1$1$1$1$1$1", f = "RepeatOnLifecycle.kt", l = {111}, m = "invokeSuspend")
  @Metadata(d1 = {"\000\f\n\002\030\002\n\002\030\002\n\002\b\002\020\002\032\0020\001*\0020\000H@¢\006\004\b\002\020\003"}, d2 = {"Ldbxyzptlk/bK/J;", "Ldbxyzptlk/pI/D;", "<anonymous>", "(Ldbxyzptlk/bK/J;)V"}, k = 3, mv = {1, 8, 0})
  public static final class a extends l implements p<J, d<? super D>, Object> {
    public int t;
    
    public Object u;
    
    public final p<J, d<? super D>, Object> v;
    
    public a(p<? super J, ? super d<? super D>, ? extends Object> param1p, d<? super a> param1d) {
      super(2, param1d);
    }
    
    public final d<D> create(Object param1Object, d<?> param1d) {
      a a1 = new a(this.v, (d)param1d);
      a1.u = param1Object;
      return (d<D>)a1;
    }
    
    public final Object invoke(J param1J, d<? super D> param1d) {
      return ((a)create(param1J, param1d)).invokeSuspend(D.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = c.g();
      int i = this.t;
      if (i != 0) {
        if (i == 1) {
          p.b(param1Object);
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        p.b(param1Object);
        param1Object = this.u;
        p<J, d<? super D>, Object> p1 = this.v;
        this.t = 1;
        if (p1.invoke(param1Object, this) == object)
          return object; 
      } 
      return D.a;
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\lifecycle\RepeatOnLifecycleKt.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */