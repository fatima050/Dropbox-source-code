package androidx.lifecycle;

import dbxyzptlk.DI.s;
import dbxyzptlk.U2.h;
import dbxyzptlk.YJ.t;
import dbxyzptlk.qI.r;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import kotlin.Metadata;

@Metadata(d1 = {"\000P\n\002\030\002\n\002\020\000\n\002\b\003\n\002\030\002\n\002\b\002\n\002\020\016\n\002\b\003\n\002\030\002\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\020\b\n\002\b\003\n\002\020\013\n\002\b\002\n\002\020%\n\002\b\002\n\002\020 \n\002\b\002\bÇ\002\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\027\020\006\032\0020\0052\006\020\004\032\0020\001H\007¢\006\004\b\006\020\007J\027\020\n\032\0020\b2\006\020\t\032\0020\bH\007¢\006\004\b\n\020\013J'\020\017\032\0020\r2\016\020\016\032\n\022\006\b\001\022\0020\r0\f2\006\020\004\032\0020\001H\002¢\006\004\b\017\020\020J%\020\023\032\f\022\006\b\001\022\0020\r\030\0010\f2\n\020\022\032\006\022\002\b\0030\021H\002¢\006\004\b\023\020\024J\033\020\026\032\0020\0252\n\020\022\032\006\022\002\b\0030\021H\002¢\006\004\b\026\020\027J\033\020\030\032\0020\0252\n\020\022\032\006\022\002\b\0030\021H\002¢\006\004\b\030\020\027J\035\020\032\032\0020\0312\f\020\022\032\b\022\002\b\003\030\0010\021H\002¢\006\004\b\032\020\033R$\020\036\032\022\022\b\022\006\022\002\b\0030\021\022\004\022\0020\0250\0348\002X\004¢\006\006\n\004\b\023\020\035R2\020 \032 \022\b\022\006\022\002\b\0030\021\022\022\022\020\022\f\022\n\022\006\b\001\022\0020\r0\f0\0370\0348\002X\004¢\006\006\n\004\b\n\020\035¨\006!"}, d2 = {"Landroidx/lifecycle/k;", "", "<init>", "()V", "object", "Landroidx/lifecycle/LifecycleEventObserver;", "f", "(Ljava/lang/Object;)Landroidx/lifecycle/LifecycleEventObserver;", "", "className", "c", "(Ljava/lang/String;)Ljava/lang/String;", "Ljava/lang/reflect/Constructor;", "Landroidx/lifecycle/d;", "constructor", "a", "(Ljava/lang/reflect/Constructor;Ljava/lang/Object;)Landroidx/lifecycle/d;", "Ljava/lang/Class;", "klass", "b", "(Ljava/lang/Class;)Ljava/lang/reflect/Constructor;", "", "d", "(Ljava/lang/Class;)I", "g", "", "e", "(Ljava/lang/Class;)Z", "", "Ljava/util/Map;", "callbackCache", "", "classToAdapters", "lifecycle-common"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class k {
  public static final k a = new k();
  
  public static final Map<Class<?>, Integer> b = new HashMap<>();
  
  public static final Map<Class<?>, List<Constructor<? extends d>>> c = new HashMap<>();
  
  public static final String c(String paramString) {
    s.h(paramString, "className");
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(t.J(paramString, ".", "_", false, 4, null));
    stringBuilder.append("_LifecycleAdapter");
    return stringBuilder.toString();
  }
  
  public static final LifecycleEventObserver f(Object paramObject) {
    s.h(paramObject, "object");
    boolean bool2 = paramObject instanceof LifecycleEventObserver;
    boolean bool1 = paramObject instanceof DefaultLifecycleObserver;
    if (bool2 && bool1)
      return new DefaultLifecycleObserverAdapter((DefaultLifecycleObserver)paramObject, (LifecycleEventObserver)paramObject); 
    if (bool1)
      return new DefaultLifecycleObserverAdapter((DefaultLifecycleObserver)paramObject, null); 
    if (bool2)
      return (LifecycleEventObserver)paramObject; 
    Class<?> clazz = paramObject.getClass();
    k k1 = a;
    if (k1.d(clazz) == 2) {
      clazz = (Class<?>)c.get(clazz);
      s.e(clazz);
      List<Constructor<? extends d>> list = (List)clazz;
      int i = list.size();
      byte b = 0;
      if (i == 1)
        return (LifecycleEventObserver)new SingleGeneratedAdapterObserver(k1.a(list.get(0), paramObject)); 
      i = list.size();
      d[] arrayOfD = new d[i];
      while (b < i) {
        arrayOfD[b] = a.a(list.get(b), paramObject);
        b++;
      } 
      return (LifecycleEventObserver)new CompositeGeneratedAdaptersObserver(arrayOfD);
    } 
    return (LifecycleEventObserver)new ReflectiveGenericLifecycleObserver(paramObject);
  }
  
  public final d a(Constructor<? extends d> paramConstructor, Object paramObject) {
    try {
      paramConstructor = (Constructor<? extends d>)paramConstructor.newInstance(new Object[] { paramObject });
      s.g(paramConstructor, "{\n            constructo…tance(`object`)\n        }");
      return (d)paramConstructor;
    } catch (IllegalAccessException illegalAccessException) {
    
    } catch (InstantiationException instantiationException) {
    
    } catch (InvocationTargetException invocationTargetException) {}
    throw new RuntimeException(invocationTargetException);
  }
  
  public final Constructor<? extends d> b(Class<?> paramClass) {
    try {
      String str1;
      Package package_ = paramClass.getPackage();
      String str2 = paramClass.getCanonicalName();
      if (package_ != null) {
        str1 = package_.getName();
      } else {
        str1 = "";
      } 
      s.g(str1, "fullPackage");
      if (str1.length() != 0) {
        s.g(str2, "name");
        str2 = str2.substring(str1.length() + 1);
        s.g(str2, "this as java.lang.String).substring(startIndex)");
      } 
      s.g(str2, "if (fullPackage.isEmpty(…g(fullPackage.length + 1)");
      str2 = c(str2);
      if (str1.length() == 0) {
        str1 = str2;
      } else {
        StringBuilder stringBuilder = new StringBuilder();
        this();
        stringBuilder.append(str1);
        stringBuilder.append('.');
        stringBuilder.append(str2);
        str1 = stringBuilder.toString();
      } 
      Class<?> clazz = Class.forName(str1);
      s.f(clazz, "null cannot be cast to non-null type java.lang.Class<out androidx.lifecycle.GeneratedAdapter>");
      Constructor<?> constructor2 = clazz.getDeclaredConstructor(new Class[] { paramClass });
      Constructor<?> constructor1 = constructor2;
      if (!constructor2.isAccessible()) {
        constructor2.setAccessible(true);
        constructor1 = constructor2;
      } 
    } catch (ClassNotFoundException classNotFoundException) {
      classNotFoundException = null;
    } catch (NoSuchMethodException noSuchMethodException) {
      throw new RuntimeException(noSuchMethodException);
    } 
    return (Constructor<? extends d>)noSuchMethodException;
  }
  
  public final int d(Class<?> paramClass) {
    Map<Class<?>, Integer> map = b;
    Integer integer = map.get(paramClass);
    if (integer != null)
      return integer.intValue(); 
    int i = g(paramClass);
    map.put(paramClass, Integer.valueOf(i));
    return i;
  }
  
  public final boolean e(Class<?> paramClass) {
    boolean bool;
    if (paramClass != null && h.class.isAssignableFrom(paramClass)) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public final int g(Class<?> paramClass) {
    Class<?> clazz2;
    ArrayList<Constructor<? extends d>> arrayList;
    if (paramClass.getCanonicalName() == null)
      return 1; 
    Constructor<? extends d> constructor = b(paramClass);
    if (constructor != null) {
      c.put(paramClass, r.e(constructor));
      return 2;
    } 
    if (b.c.d(paramClass))
      return 1; 
    Class<?> clazz1 = paramClass.getSuperclass();
    if (e(clazz1)) {
      s.g(clazz1, "superclass");
      if (d(clazz1) == 1)
        return 1; 
      clazz1 = (Class<?>)c.get(clazz1);
      s.e(clazz1);
      clazz2 = (Class<?>)new ArrayList((Collection)clazz1);
    } else {
      clazz2 = null;
    } 
    Class[] arrayOfClass = paramClass.getInterfaces();
    s.g(arrayOfClass, "klass.interfaces");
    int i = arrayOfClass.length;
    byte b = 0;
    while (b < i) {
      ArrayList<Constructor<? extends d>> arrayList1;
      Class<?> clazz = arrayOfClass[b];
      if (!e(clazz)) {
        clazz1 = clazz2;
      } else {
        s.g(clazz, "intrface");
        if (d(clazz) == 1)
          return 1; 
        clazz1 = clazz2;
        if (clazz2 == null)
          arrayList1 = new ArrayList(); 
        clazz2 = (Class<?>)c.get(clazz);
        s.e(clazz2);
        arrayList1.addAll((Collection)clazz2);
      } 
      b++;
      arrayList = arrayList1;
    } 
    if (arrayList != null) {
      c.put(paramClass, arrayList);
      return 2;
    } 
    return 1;
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\lifecycle\k.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */