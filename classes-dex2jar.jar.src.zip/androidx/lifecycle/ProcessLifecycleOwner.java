package androidx.lifecycle;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import dbxyzptlk.DI.s;
import dbxyzptlk.U2.e;
import dbxyzptlk.U2.p;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

@Metadata(d1 = {"\000T\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\006\n\002\030\002\n\002\b\003\n\002\020\b\n\002\b\005\n\002\020\013\n\002\b\004\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\005\030\000 *2\0020\001:\002\020\023B\t\b\002¢\006\004\b\002\020\003J\017\020\005\032\0020\004H\000¢\006\004\b\005\020\003J\017\020\006\032\0020\004H\000¢\006\004\b\006\020\003J\017\020\007\032\0020\004H\000¢\006\004\b\007\020\003J\017\020\b\032\0020\004H\000¢\006\004\b\b\020\003J\017\020\t\032\0020\004H\000¢\006\004\b\t\020\003J\017\020\n\032\0020\004H\000¢\006\004\b\n\020\003J\027\020\r\032\0020\0042\006\020\f\032\0020\013H\000¢\006\004\b\r\020\016R\026\020\022\032\0020\0178\002@\002X\016¢\006\006\n\004\b\020\020\021R\026\020\024\032\0020\0178\002@\002X\016¢\006\006\n\004\b\023\020\021R\026\020\030\032\0020\0258\002@\002X\016¢\006\006\n\004\b\026\020\027R\026\020\031\032\0020\0258\002@\002X\016¢\006\006\n\004\b\007\020\027R\030\020\034\032\004\030\0010\0328\002@\002X\016¢\006\006\n\004\b\006\020\033R\024\020\037\032\0020\0358\002X\004¢\006\006\n\004\b\005\020\036R\024\020\"\032\0020 8\002X\004¢\006\006\n\004\b\b\020!R\024\020%\032\0020#8\002X\004¢\006\006\n\004\b\r\020$R\024\020)\032\0020&8VX\004¢\006\006\032\004\b'\020(¨\006+"}, d2 = {"Landroidx/lifecycle/ProcessLifecycleOwner;", "Landroidx/lifecycle/LifecycleOwner;", "<init>", "()V", "Ldbxyzptlk/pI/D;", "f", "e", "d", "g", "j", "k", "Landroid/content/Context;", "context", "h", "(Landroid/content/Context;)V", "", "a", "I", "startedCounter", "b", "resumedCounter", "", "c", "Z", "pauseSent", "stopSent", "Landroid/os/Handler;", "Landroid/os/Handler;", "handler", "Landroidx/lifecycle/j;", "Landroidx/lifecycle/j;", "registry", "Ljava/lang/Runnable;", "Ljava/lang/Runnable;", "delayedPauseRunnable", "Landroidx/lifecycle/n$a;", "Landroidx/lifecycle/n$a;", "initializationListener", "Landroidx/lifecycle/f;", "getLifecycle", "()Landroidx/lifecycle/f;", "lifecycle", "i", "lifecycle-process_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class ProcessLifecycleOwner implements LifecycleOwner {
  public static final b i = new b(null);
  
  public static final ProcessLifecycleOwner j = new ProcessLifecycleOwner();
  
  public int a;
  
  public int b;
  
  public boolean c = true;
  
  public boolean d = true;
  
  public Handler e;
  
  public final j f = new j(this);
  
  public final Runnable g = (Runnable)new p(this);
  
  public final n.a h = new d(this);
  
  public static final void i(ProcessLifecycleOwner paramProcessLifecycleOwner) {
    s.h(paramProcessLifecycleOwner, "this$0");
    paramProcessLifecycleOwner.j();
    paramProcessLifecycleOwner.k();
  }
  
  public static final LifecycleOwner l() {
    return i.a();
  }
  
  public final void d() {
    int i = this.b - 1;
    this.b = i;
    if (i == 0) {
      Handler handler = this.e;
      s.e(handler);
      handler.postDelayed(this.g, 700L);
    } 
  }
  
  public final void e() {
    int i = this.b + 1;
    this.b = i;
    if (i == 1)
      if (this.c) {
        this.f.i(f.a.ON_RESUME);
        this.c = false;
      } else {
        Handler handler = this.e;
        s.e(handler);
        handler.removeCallbacks(this.g);
      }  
  }
  
  public final void f() {
    int i = this.a + 1;
    this.a = i;
    if (i == 1 && this.d) {
      this.f.i(f.a.ON_START);
      this.d = false;
    } 
  }
  
  public final void g() {
    this.a--;
    k();
  }
  
  public f getLifecycle() {
    return this.f;
  }
  
  public final void h(Context paramContext) {
    s.h(paramContext, "context");
    this.e = new Handler();
    this.f.i(f.a.ON_CREATE);
    paramContext = paramContext.getApplicationContext();
    s.f(paramContext, "null cannot be cast to non-null type android.app.Application");
    ((Application)paramContext).registerActivityLifecycleCallbacks((Application.ActivityLifecycleCallbacks)new c());
  }
  
  public final void j() {
    if (this.b == 0) {
      this.c = true;
      this.f.i(f.a.ON_PAUSE);
    } 
  }
  
  public final void k() {
    if (this.a == 0 && this.c) {
      this.f.i(f.a.ON_STOP);
      this.d = true;
    } 
  }
  
  @Metadata(d1 = {"\000 \n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\003\bÁ\002\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\037\020\t\032\0020\b2\006\020\005\032\0020\0042\006\020\007\032\0020\006H\007¢\006\004\b\t\020\n¨\006\013"}, d2 = {"Landroidx/lifecycle/ProcessLifecycleOwner$a;", "", "<init>", "()V", "Landroid/app/Activity;", "activity", "Landroid/app/Application$ActivityLifecycleCallbacks;", "callback", "Ldbxyzptlk/pI/D;", "a", "(Landroid/app/Activity;Landroid/app/Application$ActivityLifecycleCallbacks;)V", "lifecycle-process_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class a {
    public static final a a = new a();
    
    public static final void a(Activity param1Activity, Application.ActivityLifecycleCallbacks param1ActivityLifecycleCallbacks) {
      s.h(param1Activity, "activity");
      s.h(param1ActivityLifecycleCallbacks, "callback");
      param1Activity.registerActivityLifecycleCallbacks(param1ActivityLifecycleCallbacks);
    }
  }
  
  @Metadata(d1 = {"\000*\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\003\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\017\020\005\032\0020\004H\007¢\006\004\b\005\020\006J\027\020\n\032\0020\t2\006\020\b\032\0020\007H\001¢\006\004\b\n\020\013R\024\020\r\032\0020\f8\002X\004¢\006\006\n\004\b\r\020\016¨\006\017"}, d2 = {"Landroidx/lifecycle/ProcessLifecycleOwner$b;", "", "<init>", "()V", "Landroidx/lifecycle/LifecycleOwner;", "a", "()Landroidx/lifecycle/LifecycleOwner;", "Landroid/content/Context;", "context", "Ldbxyzptlk/pI/D;", "b", "(Landroid/content/Context;)V", "Landroidx/lifecycle/ProcessLifecycleOwner;", "newInstance", "Landroidx/lifecycle/ProcessLifecycleOwner;", "lifecycle-process_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class b {
    public b() {}
    
    public final LifecycleOwner a() {
      return ProcessLifecycleOwner.c();
    }
    
    public final void b(Context param1Context) {
      s.h(param1Context, "context");
      ProcessLifecycleOwner.c().h(param1Context);
    }
  }
  
  @Metadata(d1 = {"\000\035\n\000\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\007*\001\000\b\n\030\0002\0020\001J!\020\007\032\0020\0062\006\020\003\032\0020\0022\b\020\005\032\004\030\0010\004H\027¢\006\004\b\007\020\bJ!\020\t\032\0020\0062\006\020\003\032\0020\0022\b\020\005\032\004\030\0010\004H\026¢\006\004\b\t\020\bJ\027\020\n\032\0020\0062\006\020\003\032\0020\002H\026¢\006\004\b\n\020\013J\027\020\f\032\0020\0062\006\020\003\032\0020\002H\026¢\006\004\b\f\020\013¨\006\r"}, d2 = {"androidx/lifecycle/ProcessLifecycleOwner$c", "Ldbxyzptlk/U2/e;", "Landroid/app/Activity;", "activity", "Landroid/os/Bundle;", "savedInstanceState", "Ldbxyzptlk/pI/D;", "onActivityPreCreated", "(Landroid/app/Activity;Landroid/os/Bundle;)V", "onActivityCreated", "onActivityPaused", "(Landroid/app/Activity;)V", "onActivityStopped", "lifecycle-process_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class c extends e {
    final ProcessLifecycleOwner this$0;
    
    public void onActivityCreated(Activity param1Activity, Bundle param1Bundle) {
      s.h(param1Activity, "activity");
      if (Build.VERSION.SDK_INT < 29)
        n.b.b(param1Activity).e(ProcessLifecycleOwner.b(ProcessLifecycleOwner.this)); 
    }
    
    public void onActivityPaused(Activity param1Activity) {
      s.h(param1Activity, "activity");
      ProcessLifecycleOwner.this.d();
    }
    
    public void onActivityPreCreated(Activity param1Activity, Bundle param1Bundle) {
      s.h(param1Activity, "activity");
      ProcessLifecycleOwner.a.a(param1Activity, (Application.ActivityLifecycleCallbacks)new a());
    }
    
    public void onActivityStopped(Activity param1Activity) {
      s.h(param1Activity, "activity");
      ProcessLifecycleOwner.this.g();
    }
    
    @Metadata(d1 = {"\000\027\n\000\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\004*\001\000\b\n\030\0002\0020\001J\027\020\005\032\0020\0042\006\020\003\032\0020\002H\026¢\006\004\b\005\020\006J\027\020\007\032\0020\0042\006\020\003\032\0020\002H\026¢\006\004\b\007\020\006¨\006\b"}, d2 = {"androidx/lifecycle/ProcessLifecycleOwner$c$a", "Ldbxyzptlk/U2/e;", "Landroid/app/Activity;", "activity", "Ldbxyzptlk/pI/D;", "onActivityPostStarted", "(Landroid/app/Activity;)V", "onActivityPostResumed", "lifecycle-process_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
    public static final class a extends e {
      final ProcessLifecycleOwner this$0;
      
      public void onActivityPostResumed(Activity param2Activity) {
        s.h(param2Activity, "activity");
        ProcessLifecycleOwner.this.e();
      }
      
      public void onActivityPostStarted(Activity param2Activity) {
        s.h(param2Activity, "activity");
        ProcessLifecycleOwner.this.f();
      }
    }
  }
  
  @Metadata(d1 = {"\000\027\n\000\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\004*\001\000\b\n\030\0002\0020\001J\027\020\005\032\0020\0042\006\020\003\032\0020\002H\026¢\006\004\b\005\020\006J\027\020\007\032\0020\0042\006\020\003\032\0020\002H\026¢\006\004\b\007\020\006¨\006\b"}, d2 = {"androidx/lifecycle/ProcessLifecycleOwner$c$a", "Ldbxyzptlk/U2/e;", "Landroid/app/Activity;", "activity", "Ldbxyzptlk/pI/D;", "onActivityPostStarted", "(Landroid/app/Activity;)V", "onActivityPostResumed", "lifecycle-process_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class a extends e {
    final ProcessLifecycleOwner this$0;
    
    public void onActivityPostResumed(Activity param1Activity) {
      s.h(param1Activity, "activity");
      ProcessLifecycleOwner.this.e();
    }
    
    public void onActivityPostStarted(Activity param1Activity) {
      s.h(param1Activity, "activity");
      ProcessLifecycleOwner.this.f();
    }
  }
  
  @Metadata(d1 = {"\000\021\n\000\n\002\030\002\n\002\030\002\n\002\b\005*\001\000\b\n\030\0002\0020\001J\017\020\003\032\0020\002H\026¢\006\004\b\003\020\004J\017\020\005\032\0020\002H\026¢\006\004\b\005\020\004J\017\020\006\032\0020\002H\026¢\006\004\b\006\020\004¨\006\007"}, d2 = {"androidx/lifecycle/ProcessLifecycleOwner$d", "Landroidx/lifecycle/n$a;", "Ldbxyzptlk/pI/D;", "onCreate", "()V", "a", "onResume", "lifecycle-process_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class d implements n.a {
    public final ProcessLifecycleOwner a;
    
    public d(ProcessLifecycleOwner param1ProcessLifecycleOwner) {}
    
    public void a() {
      this.a.f();
    }
    
    public void onCreate() {}
    
    public void onResume() {
      this.a.e();
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\lifecycle\ProcessLifecycleOwner.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */