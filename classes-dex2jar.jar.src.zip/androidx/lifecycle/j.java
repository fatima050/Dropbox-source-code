package androidx.lifecycle;

import android.annotation.SuppressLint;
import dbxyzptlk.DI.s;
import dbxyzptlk.U2.h;
import dbxyzptlk.eK.C;
import dbxyzptlk.eK.U;
import dbxyzptlk.s.c;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

@Metadata(d1 = {"\000j\n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\020\013\n\002\b\004\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\r\n\002\020\016\n\002\b\005\n\002\030\002\n\002\030\002\n\002\b\004\n\002\030\002\n\000\n\002\020\b\n\002\b\004\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\t\b\026\030\000 \0252\0020\001:\002\020%B\031\b\002\022\006\020\003\032\0020\002\022\006\020\005\032\0020\004¢\006\004\b\006\020\007B\021\b\026\022\006\020\003\032\0020\002¢\006\004\b\006\020\bJ\027\020\f\032\0020\0132\006\020\n\032\0020\tH\026¢\006\004\b\f\020\rJ\027\020\020\032\0020\0132\006\020\017\032\0020\016H\026¢\006\004\b\020\020\021J\027\020\022\032\0020\0132\006\020\017\032\0020\016H\026¢\006\004\b\022\020\021J\027\020\025\032\0020\0132\006\020\024\032\0020\023H\002¢\006\004\b\025\020\026J\027\020\027\032\0020\0232\006\020\017\032\0020\016H\002¢\006\004\b\027\020\030J\017\020\031\032\0020\013H\002¢\006\004\b\031\020\032J\027\020\034\032\0020\0132\006\020\033\032\0020\023H\002¢\006\004\b\034\020\026J\027\020\036\032\0020\0132\006\020\035\032\0020\002H\002¢\006\004\b\036\020\bJ\027\020\037\032\0020\0132\006\020\035\032\0020\002H\002¢\006\004\b\037\020\bJ\017\020 \032\0020\013H\002¢\006\004\b \020\032J\027\020#\032\0020\0132\006\020\"\032\0020!H\003¢\006\004\b#\020$R\024\020\005\032\0020\0048\002X\004¢\006\006\n\004\b%\020&R\"\020+\032\016\022\004\022\0020\016\022\004\022\0020(0'8\002@\002X\016¢\006\006\n\004\b)\020*R\026\020\033\032\0020\0238\002@\002X\016¢\006\006\n\004\b\022\020,R\032\020\035\032\b\022\004\022\0020\0020-8\002X\004¢\006\006\n\004\b\037\020.R\026\0201\032\0020/8\002@\002X\016¢\006\006\n\004\b\027\0200R\026\0202\032\0020\0048\002@\002X\016¢\006\006\n\004\b#\020&R\026\0203\032\0020\0048\002@\002X\016¢\006\006\n\004\b\036\020&R&\0207\032\022\022\004\022\0020\02304j\b\022\004\022\0020\023`58\002@\002X\016¢\006\006\n\004\b\f\0206R\032\020;\032\b\022\004\022\0020\023088\002X\004¢\006\006\n\004\b9\020:R$\020>\032\0020\0232\006\020\033\032\0020\0238V@VX\016¢\006\f\032\004\b%\020<\"\004\b=\020\026R\024\020@\032\0020\0048BX\004¢\006\006\032\004\b9\020?¨\006A"}, d2 = {"Landroidx/lifecycle/j;", "Landroidx/lifecycle/f;", "Landroidx/lifecycle/LifecycleOwner;", "provider", "", "enforceMainThread", "<init>", "(Landroidx/lifecycle/LifecycleOwner;Z)V", "(Landroidx/lifecycle/LifecycleOwner;)V", "Landroidx/lifecycle/f$a;", "event", "Ldbxyzptlk/pI/D;", "i", "(Landroidx/lifecycle/f$a;)V", "Ldbxyzptlk/U2/h;", "observer", "a", "(Ldbxyzptlk/U2/h;)V", "d", "Landroidx/lifecycle/f$b;", "next", "k", "(Landroidx/lifecycle/f$b;)V", "f", "(Ldbxyzptlk/U2/h;)Landroidx/lifecycle/f$b;", "l", "()V", "state", "m", "lifecycleOwner", "h", "e", "o", "", "methodName", "g", "(Ljava/lang/String;)V", "b", "Z", "Ldbxyzptlk/t/a;", "Landroidx/lifecycle/j$b;", "c", "Ldbxyzptlk/t/a;", "observerMap", "Landroidx/lifecycle/f$b;", "Ljava/lang/ref/WeakReference;", "Ljava/lang/ref/WeakReference;", "", "I", "addingObserverCounter", "handlingEvent", "newEventOccurred", "Ljava/util/ArrayList;", "Lkotlin/collections/ArrayList;", "Ljava/util/ArrayList;", "parentStates", "Ldbxyzptlk/eK/C;", "j", "Ldbxyzptlk/eK/C;", "_currentStateFlow", "()Landroidx/lifecycle/f$b;", "n", "currentState", "()Z", "isSynced", "lifecycle-runtime_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public class j extends f {
  public static final a k = new a(null);
  
  public final boolean b;
  
  public dbxyzptlk.t.a<h, b> c;
  
  public f.b d;
  
  public final WeakReference<LifecycleOwner> e;
  
  public int f;
  
  public boolean g;
  
  public boolean h;
  
  public ArrayList<f.b> i;
  
  public final C<f.b> j;
  
  public j(LifecycleOwner paramLifecycleOwner) {
    this(paramLifecycleOwner, true);
  }
  
  public j(LifecycleOwner paramLifecycleOwner, boolean paramBoolean) {
    this.b = paramBoolean;
    this.c = new dbxyzptlk.t.a();
    f.b b1 = f.b.INITIALIZED;
    this.d = b1;
    this.i = new ArrayList<>();
    this.e = new WeakReference<>(paramLifecycleOwner);
    this.j = U.a(b1);
  }
  
  public void a(h paramh) {
    boolean bool;
    s.h(paramh, "observer");
    g("addObserver");
    f.b b3 = this.d;
    f.b b1 = f.b.DESTROYED;
    if (b3 != b1)
      b1 = f.b.INITIALIZED; 
    b b2 = new b(paramh, b1);
    if ((b)this.c.m(paramh, b2) != null)
      return; 
    LifecycleOwner lifecycleOwner = this.e.get();
    if (lifecycleOwner == null)
      return; 
    if (this.f != 0 || this.g) {
      bool = true;
    } else {
      bool = false;
    } 
    b1 = f(paramh);
    this.f++;
    while (b2.b().compareTo(b1) < 0 && this.c.contains(paramh)) {
      m(b2.b());
      f.a a1 = f.a.Companion.c(b2.b());
      if (a1 != null) {
        b2.a(lifecycleOwner, a1);
        l();
        f.b b4 = f(paramh);
        continue;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("no event up from ");
      stringBuilder.append(b2.b());
      throw new IllegalStateException(stringBuilder.toString());
    } 
    if (!bool)
      o(); 
    this.f--;
  }
  
  public f.b b() {
    return this.d;
  }
  
  public void d(h paramh) {
    s.h(paramh, "observer");
    g("removeObserver");
    this.c.p(paramh);
  }
  
  public final void e(LifecycleOwner paramLifecycleOwner) {
    Iterator<Map.Entry> iterator = this.c.descendingIterator();
    s.g(iterator, "observerMap.descendingIterator()");
    while (iterator.hasNext() && !this.h) {
      Map.Entry entry = iterator.next();
      s.g(entry, "next()");
      h h = (h)entry.getKey();
      b b1 = (b)entry.getValue();
      while (b1.b().compareTo(this.d) > 0 && !this.h && this.c.contains(h)) {
        f.a a1 = f.a.Companion.a(b1.b());
        if (a1 != null) {
          m(a1.getTargetState());
          b1.a(paramLifecycleOwner, a1);
          l();
          continue;
        } 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("no event down from ");
        stringBuilder.append(b1.b());
        throw new IllegalStateException(stringBuilder.toString());
      } 
    } 
  }
  
  public final f.b f(h paramh) {
    // Byte code:
    //   0: aload_0
    //   1: getfield c : Ldbxyzptlk/t/a;
    //   4: aload_1
    //   5: invokevirtual r : (Ljava/lang/Object;)Ljava/util/Map$Entry;
    //   8: astore_1
    //   9: aconst_null
    //   10: astore_2
    //   11: aload_1
    //   12: ifnull -> 37
    //   15: aload_1
    //   16: invokeinterface getValue : ()Ljava/lang/Object;
    //   21: checkcast androidx/lifecycle/j$b
    //   24: astore_1
    //   25: aload_1
    //   26: ifnull -> 37
    //   29: aload_1
    //   30: invokevirtual b : ()Landroidx/lifecycle/f$b;
    //   33: astore_1
    //   34: goto -> 39
    //   37: aconst_null
    //   38: astore_1
    //   39: aload_0
    //   40: getfield i : Ljava/util/ArrayList;
    //   43: invokeinterface isEmpty : ()Z
    //   48: ifne -> 70
    //   51: aload_0
    //   52: getfield i : Ljava/util/ArrayList;
    //   55: astore_2
    //   56: aload_2
    //   57: aload_2
    //   58: invokevirtual size : ()I
    //   61: iconst_1
    //   62: isub
    //   63: invokevirtual get : (I)Ljava/lang/Object;
    //   66: checkcast androidx/lifecycle/f$b
    //   69: astore_2
    //   70: getstatic androidx/lifecycle/j.k : Landroidx/lifecycle/j$a;
    //   73: astore_3
    //   74: aload_3
    //   75: aload_3
    //   76: aload_0
    //   77: getfield d : Landroidx/lifecycle/f$b;
    //   80: aload_1
    //   81: invokevirtual b : (Landroidx/lifecycle/f$b;Landroidx/lifecycle/f$b;)Landroidx/lifecycle/f$b;
    //   84: aload_2
    //   85: invokevirtual b : (Landroidx/lifecycle/f$b;Landroidx/lifecycle/f$b;)Landroidx/lifecycle/f$b;
    //   88: areturn
  }
  
  @SuppressLint({"RestrictedApi"})
  public final void g(String paramString) {
    if (!this.b || c.h().c())
      return; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Method ");
    stringBuilder.append(paramString);
    stringBuilder.append(" must be called on the main thread");
    throw new IllegalStateException(stringBuilder.toString().toString());
  }
  
  public final void h(LifecycleOwner paramLifecycleOwner) {
    dbxyzptlk.t.b.d<Map.Entry> d = this.c.j();
    s.g(d, "observerMap.iteratorWithAdditions()");
    while (d.hasNext() && !this.h) {
      Map.Entry entry = d.next();
      h h = (h)entry.getKey();
      b b1 = (b)entry.getValue();
      while (b1.b().compareTo(this.d) < 0 && !this.h && this.c.contains(h)) {
        m(b1.b());
        f.a a1 = f.a.Companion.c(b1.b());
        if (a1 != null) {
          b1.a(paramLifecycleOwner, a1);
          l();
          continue;
        } 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("no event up from ");
        stringBuilder.append(b1.b());
        throw new IllegalStateException(stringBuilder.toString());
      } 
    } 
  }
  
  public void i(f.a parama) {
    s.h(parama, "event");
    g("handleLifecycleEvent");
    k(parama.getTargetState());
  }
  
  public final boolean j() {
    int i = this.c.size();
    boolean bool = true;
    if (i == 0)
      return true; 
    Map.Entry entry1 = this.c.b();
    s.e(entry1);
    f.b b1 = ((b)entry1.getValue()).b();
    Map.Entry entry2 = this.c.k();
    s.e(entry2);
    f.b b2 = ((b)entry2.getValue()).b();
    if (b1 != b2 || this.d != b2)
      bool = false; 
    return bool;
  }
  
  public final void k(f.b paramb) {
    f.b b1 = this.d;
    if (b1 == paramb)
      return; 
    if (b1 != f.b.INITIALIZED || paramb != f.b.DESTROYED) {
      this.d = paramb;
      if (this.g || this.f != 0) {
        this.h = true;
        return;
      } 
      this.g = true;
      o();
      this.g = false;
      if (this.d == f.b.DESTROYED)
        this.c = new dbxyzptlk.t.a(); 
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("no event down from ");
    stringBuilder.append(this.d);
    stringBuilder.append(" in component ");
    stringBuilder.append(this.e.get());
    throw new IllegalStateException(stringBuilder.toString().toString());
  }
  
  public final void l() {
    ArrayList<f.b> arrayList = this.i;
    arrayList.remove(arrayList.size() - 1);
  }
  
  public final void m(f.b paramb) {
    this.i.add(paramb);
  }
  
  public void n(f.b paramb) {
    s.h(paramb, "state");
    g("setCurrentState");
    k(paramb);
  }
  
  public final void o() {
    LifecycleOwner lifecycleOwner = this.e.get();
    if (lifecycleOwner != null) {
      while (!j()) {
        this.h = false;
        f.b b1 = this.d;
        Map.Entry entry2 = this.c.b();
        s.e(entry2);
        if (b1.compareTo(((b)entry2.getValue()).b()) < 0)
          e(lifecycleOwner); 
        Map.Entry entry1 = this.c.k();
        if (!this.h && entry1 != null && this.d.compareTo(((b)entry1.getValue()).b()) > 0)
          h(lifecycleOwner); 
      } 
      this.h = false;
      this.j.setValue(b());
      return;
    } 
    throw new IllegalStateException("LifecycleOwner of this LifecycleRegistry is already garbage collected. It is too late to change lifecycle state.");
  }
  
  @Metadata(d1 = {"\000\"\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\005\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\027\020\007\032\0020\0062\006\020\005\032\0020\004H\007¢\006\004\b\007\020\bJ!\020\f\032\0020\t2\006\020\n\032\0020\t2\b\020\013\032\004\030\0010\tH\001¢\006\004\b\f\020\r¨\006\016"}, d2 = {"Landroidx/lifecycle/j$a;", "", "<init>", "()V", "Landroidx/lifecycle/LifecycleOwner;", "owner", "Landroidx/lifecycle/j;", "a", "(Landroidx/lifecycle/LifecycleOwner;)Landroidx/lifecycle/j;", "Landroidx/lifecycle/f$b;", "state1", "state2", "b", "(Landroidx/lifecycle/f$b;Landroidx/lifecycle/f$b;)Landroidx/lifecycle/f$b;", "lifecycle-runtime_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class a {
    public a() {}
    
    public final j a(LifecycleOwner param1LifecycleOwner) {
      s.h(param1LifecycleOwner, "owner");
      return new j(param1LifecycleOwner, false, null);
    }
    
    public final f.b b(f.b param1b1, f.b param1b2) {
      s.h(param1b1, "state1");
      f.b b1 = param1b1;
      if (param1b2 != null) {
        b1 = param1b1;
        if (param1b2.compareTo(param1b1) < 0)
          b1 = param1b2; 
      } 
      return b1;
    }
  }
  
  @Metadata(d1 = {"\0002\n\002\030\002\n\002\020\000\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\b\n\002\030\002\n\002\b\007\b\000\030\0002\0020\001B\031\022\b\020\003\032\004\030\0010\002\022\006\020\005\032\0020\004¢\006\004\b\006\020\007J\037\020\r\032\0020\f2\b\020\t\032\004\030\0010\b2\006\020\013\032\0020\n¢\006\004\b\r\020\016R\"\020\024\032\0020\0048\006@\006X\016¢\006\022\n\004\b\r\020\017\032\004\b\020\020\021\"\004\b\022\020\023R\"\020\033\032\0020\0258\006@\006X\016¢\006\022\n\004\b\020\020\026\032\004\b\027\020\030\"\004\b\031\020\032¨\006\034"}, d2 = {"Landroidx/lifecycle/j$b;", "", "Ldbxyzptlk/U2/h;", "observer", "Landroidx/lifecycle/f$b;", "initialState", "<init>", "(Ldbxyzptlk/U2/h;Landroidx/lifecycle/f$b;)V", "Landroidx/lifecycle/LifecycleOwner;", "owner", "Landroidx/lifecycle/f$a;", "event", "Ldbxyzptlk/pI/D;", "a", "(Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/f$a;)V", "Landroidx/lifecycle/f$b;", "b", "()Landroidx/lifecycle/f$b;", "setState", "(Landroidx/lifecycle/f$b;)V", "state", "Landroidx/lifecycle/LifecycleEventObserver;", "Landroidx/lifecycle/LifecycleEventObserver;", "getLifecycleObserver", "()Landroidx/lifecycle/LifecycleEventObserver;", "setLifecycleObserver", "(Landroidx/lifecycle/LifecycleEventObserver;)V", "lifecycleObserver", "lifecycle-runtime_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class b {
    public f.b a;
    
    public LifecycleEventObserver b;
    
    public b(h param1h, f.b param1b) {
      s.e(param1h);
      this.b = k.f(param1h);
      this.a = param1b;
    }
    
    public final void a(LifecycleOwner param1LifecycleOwner, f.a param1a) {
      s.h(param1a, "event");
      f.b b1 = param1a.getTargetState();
      this.a = j.k.b(this.a, b1);
      LifecycleEventObserver lifecycleEventObserver = this.b;
      s.e(param1LifecycleOwner);
      lifecycleEventObserver.f(param1LifecycleOwner, param1a);
      this.a = b1;
    }
    
    public final f.b b() {
      return this.a;
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\lifecycle\j.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */