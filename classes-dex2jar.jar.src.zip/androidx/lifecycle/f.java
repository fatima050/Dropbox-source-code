package androidx.lifecycle;

import dbxyzptlk.DI.s;
import dbxyzptlk.U2.h;
import java.util.concurrent.atomic.AtomicReference;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

@Metadata(d1 = {"\000*\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\007\n\002\030\002\n\002\b\004\b&\030\0002\0020\001:\002\007\023B\007¢\006\004\b\002\020\003J\027\020\007\032\0020\0062\006\020\005\032\0020\004H'¢\006\004\b\007\020\bJ\027\020\t\032\0020\0062\006\020\005\032\0020\004H'¢\006\004\b\t\020\bR6\020\021\032\b\022\004\022\0020\0010\n2\f\020\013\032\b\022\004\022\0020\0010\n8G@GX\016¢\006\022\n\004\b\007\020\f\032\004\b\r\020\016\"\004\b\017\020\020R\024\020\025\032\0020\0228gX¦\004¢\006\006\032\004\b\023\020\024¨\006\026"}, d2 = {"Landroidx/lifecycle/f;", "", "<init>", "()V", "Ldbxyzptlk/U2/h;", "observer", "Ldbxyzptlk/pI/D;", "a", "(Ldbxyzptlk/U2/h;)V", "d", "Ljava/util/concurrent/atomic/AtomicReference;", "<set-?>", "Ljava/util/concurrent/atomic/AtomicReference;", "c", "()Ljava/util/concurrent/atomic/AtomicReference;", "setInternalScopeRef", "(Ljava/util/concurrent/atomic/AtomicReference;)V", "internalScopeRef", "Landroidx/lifecycle/f$b;", "b", "()Landroidx/lifecycle/f$b;", "currentState", "lifecycle-common"}, k = 1, mv = {1, 8, 0}, xi = 48)
public abstract class f {
  public AtomicReference<Object> a = new AtomicReference();
  
  public abstract void a(h paramh);
  
  public abstract b b();
  
  public final AtomicReference<Object> c() {
    return this.a;
  }
  
  public abstract void d(h paramh);
  
  @Metadata(d1 = {"\000\024\n\002\030\002\n\002\020\020\n\002\b\002\n\002\030\002\n\002\b\r\b\001\030\000 \b2\b\022\004\022\0020\0000\001:\001\tB\t\b\002¢\006\004\b\002\020\003R\021\020\007\032\0020\0048F¢\006\006\032\004\b\005\020\006j\002\b\nj\002\b\013j\002\b\fj\002\b\rj\002\b\016j\002\b\017j\002\b\020¨\006\021"}, d2 = {"Landroidx/lifecycle/f$a;", "", "<init>", "(Ljava/lang/String;I)V", "Landroidx/lifecycle/f$b;", "getTargetState", "()Landroidx/lifecycle/f$b;", "targetState", "Companion", "a", "ON_CREATE", "ON_START", "ON_RESUME", "ON_PAUSE", "ON_STOP", "ON_DESTROY", "ON_ANY", "lifecycle-common"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public enum a {
    ON_ANY, ON_CREATE, ON_DESTROY, ON_PAUSE, ON_RESUME, ON_START, ON_STOP;
    
    private static final a[] $VALUES;
    
    public static final a Companion;
    
    static {
      ON_PAUSE = new a("ON_PAUSE", 3);
      ON_STOP = new a("ON_STOP", 4);
      ON_DESTROY = new a("ON_DESTROY", 5);
      ON_ANY = new a("ON_ANY", 6);
      $VALUES = $values();
      Companion = new a(null);
    }
    
    public static final a downFrom(f.b param1b) {
      return Companion.a(param1b);
    }
    
    public static final a downTo(f.b param1b) {
      return Companion.b(param1b);
    }
    
    public static final a upFrom(f.b param1b) {
      return Companion.c(param1b);
    }
    
    public static final a upTo(f.b param1b) {
      return Companion.d(param1b);
    }
    
    public final f.b getTargetState() {
      StringBuilder stringBuilder;
      switch (b.a[ordinal()]) {
        default:
          stringBuilder = new StringBuilder();
          stringBuilder.append(this);
          stringBuilder.append(" has no target state");
          throw new IllegalArgumentException(stringBuilder.toString());
        case 6:
          return f.b.DESTROYED;
        case 5:
          return f.b.RESUMED;
        case 3:
        case 4:
          return f.b.STARTED;
        case 1:
        case 2:
          break;
      } 
      return f.b.CREATED;
    }
    
    @Metadata(d1 = {"\000\032\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\006\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\031\020\007\032\004\030\0010\0062\006\020\005\032\0020\004H\007¢\006\004\b\007\020\bJ\031\020\t\032\004\030\0010\0062\006\020\005\032\0020\004H\007¢\006\004\b\t\020\bJ\031\020\n\032\004\030\0010\0062\006\020\005\032\0020\004H\007¢\006\004\b\n\020\bJ\031\020\013\032\004\030\0010\0062\006\020\005\032\0020\004H\007¢\006\004\b\013\020\b¨\006\f"}, d2 = {"Landroidx/lifecycle/f$a$a;", "", "<init>", "()V", "Landroidx/lifecycle/f$b;", "state", "Landroidx/lifecycle/f$a;", "a", "(Landroidx/lifecycle/f$b;)Landroidx/lifecycle/f$a;", "b", "c", "d", "lifecycle-common"}, k = 1, mv = {1, 8, 0}, xi = 48)
    public static final class a {
      public a() {}
      
      public final f.a a(f.b param2b) {
        f.a a1;
        s.h(param2b, "state");
        int i = a.a[param2b.ordinal()];
        if (i != 1) {
          if (i != 2) {
            if (i != 3) {
              param2b = null;
            } else {
              a1 = f.a.ON_PAUSE;
            } 
          } else {
            a1 = f.a.ON_STOP;
          } 
        } else {
          a1 = f.a.ON_DESTROY;
        } 
        return a1;
      }
      
      public final f.a b(f.b param2b) {
        f.a a1;
        s.h(param2b, "state");
        int i = a.a[param2b.ordinal()];
        if (i != 1) {
          if (i != 2) {
            if (i != 4) {
              param2b = null;
            } else {
              a1 = f.a.ON_DESTROY;
            } 
          } else {
            a1 = f.a.ON_PAUSE;
          } 
        } else {
          a1 = f.a.ON_STOP;
        } 
        return a1;
      }
      
      public final f.a c(f.b param2b) {
        f.a a1;
        s.h(param2b, "state");
        int i = a.a[param2b.ordinal()];
        if (i != 1) {
          if (i != 2) {
            if (i != 5) {
              param2b = null;
            } else {
              a1 = f.a.ON_CREATE;
            } 
          } else {
            a1 = f.a.ON_RESUME;
          } 
        } else {
          a1 = f.a.ON_START;
        } 
        return a1;
      }
      
      public final f.a d(f.b param2b) {
        f.a a1;
        s.h(param2b, "state");
        int i = a.a[param2b.ordinal()];
        if (i != 1) {
          if (i != 2) {
            if (i != 3) {
              param2b = null;
            } else {
              a1 = f.a.ON_RESUME;
            } 
          } else {
            a1 = f.a.ON_START;
          } 
        } else {
          a1 = f.a.ON_CREATE;
        } 
        return a1;
      }
    }
  }
  
  @Metadata(d1 = {"\000\032\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\006\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\031\020\007\032\004\030\0010\0062\006\020\005\032\0020\004H\007¢\006\004\b\007\020\bJ\031\020\t\032\004\030\0010\0062\006\020\005\032\0020\004H\007¢\006\004\b\t\020\bJ\031\020\n\032\004\030\0010\0062\006\020\005\032\0020\004H\007¢\006\004\b\n\020\bJ\031\020\013\032\004\030\0010\0062\006\020\005\032\0020\004H\007¢\006\004\b\013\020\b¨\006\f"}, d2 = {"Landroidx/lifecycle/f$a$a;", "", "<init>", "()V", "Landroidx/lifecycle/f$b;", "state", "Landroidx/lifecycle/f$a;", "a", "(Landroidx/lifecycle/f$b;)Landroidx/lifecycle/f$a;", "b", "c", "d", "lifecycle-common"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class a {
    public a() {}
    
    public final f.a a(f.b param1b) {
      f.a a1;
      s.h(param1b, "state");
      int i = a.a[param1b.ordinal()];
      if (i != 1) {
        if (i != 2) {
          if (i != 3) {
            param1b = null;
          } else {
            a1 = f.a.ON_PAUSE;
          } 
        } else {
          a1 = f.a.ON_STOP;
        } 
      } else {
        a1 = f.a.ON_DESTROY;
      } 
      return a1;
    }
    
    public final f.a b(f.b param1b) {
      f.a a1;
      s.h(param1b, "state");
      int i = a.a[param1b.ordinal()];
      if (i != 1) {
        if (i != 2) {
          if (i != 4) {
            param1b = null;
          } else {
            a1 = f.a.ON_DESTROY;
          } 
        } else {
          a1 = f.a.ON_PAUSE;
        } 
      } else {
        a1 = f.a.ON_STOP;
      } 
      return a1;
    }
    
    public final f.a c(f.b param1b) {
      f.a a1;
      s.h(param1b, "state");
      int i = a.a[param1b.ordinal()];
      if (i != 1) {
        if (i != 2) {
          if (i != 5) {
            param1b = null;
          } else {
            a1 = f.a.ON_CREATE;
          } 
        } else {
          a1 = f.a.ON_RESUME;
        } 
      } else {
        a1 = f.a.ON_START;
      } 
      return a1;
    }
    
    public final f.a d(f.b param1b) {
      f.a a1;
      s.h(param1b, "state");
      int i = a.a[param1b.ordinal()];
      if (i != 1) {
        if (i != 2) {
          if (i != 3) {
            param1b = null;
          } else {
            a1 = f.a.ON_RESUME;
          } 
        } else {
          a1 = f.a.ON_START;
        } 
      } else {
        a1 = f.a.ON_CREATE;
      } 
      return a1;
    }
  }
  
  @Metadata(d1 = {"\000\024\n\002\030\002\n\002\020\020\n\002\b\003\n\002\020\013\n\002\b\b\b\001\030\0002\b\022\004\022\0020\0000\001B\t\b\002¢\006\004\b\002\020\003J\025\020\006\032\0020\0052\006\020\004\032\0020\000¢\006\004\b\006\020\007j\002\b\bj\002\b\tj\002\b\nj\002\b\013j\002\b\f¨\006\r"}, d2 = {"Landroidx/lifecycle/f$b;", "", "<init>", "(Ljava/lang/String;I)V", "state", "", "isAtLeast", "(Landroidx/lifecycle/f$b;)Z", "DESTROYED", "INITIALIZED", "CREATED", "STARTED", "RESUMED", "lifecycle-common"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public enum b {
    DESTROYED, CREATED, INITIALIZED, RESUMED, STARTED;
    
    private static final b[] $VALUES;
    
    static {
      RESUMED = new b("RESUMED", 4);
      $VALUES = $values();
    }
    
    public final boolean isAtLeast(b param1b) {
      boolean bool;
      s.h(param1b, "state");
      if (compareTo((E)param1b) >= 0) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\lifecycle\f.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */