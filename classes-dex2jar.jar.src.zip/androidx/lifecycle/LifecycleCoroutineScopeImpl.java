package androidx.lifecycle;

import dbxyzptlk.CI.p;
import dbxyzptlk.DI.s;
import dbxyzptlk.U2.g;
import dbxyzptlk.bK.J;
import dbxyzptlk.bK.Z;
import dbxyzptlk.bK.h;
import dbxyzptlk.bK.z0;
import dbxyzptlk.pI.D;
import dbxyzptlk.pI.p;
import dbxyzptlk.tI.d;
import dbxyzptlk.tI.g;
import dbxyzptlk.uI.c;
import dbxyzptlk.vI.f;
import dbxyzptlk.vI.l;
import kotlin.Metadata;

@Metadata(d1 = {"\0000\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\013\b\000\030\0002\0020\0012\0020\002B\027\022\006\020\004\032\0020\003\022\006\020\006\032\0020\005¢\006\004\b\007\020\bJ\r\020\n\032\0020\t¢\006\004\b\n\020\013J\037\020\020\032\0020\t2\006\020\r\032\0020\f2\006\020\017\032\0020\016H\026¢\006\004\b\020\020\021R\032\020\004\032\0020\0038\020X\004¢\006\f\n\004\b\022\020\023\032\004\b\022\020\024R\032\020\006\032\0020\0058\026X\004¢\006\f\n\004\b\025\020\026\032\004\b\027\020\030¨\006\031"}, d2 = {"Landroidx/lifecycle/LifecycleCoroutineScopeImpl;", "Ldbxyzptlk/U2/g;", "Landroidx/lifecycle/LifecycleEventObserver;", "Landroidx/lifecycle/f;", "lifecycle", "Ldbxyzptlk/tI/g;", "coroutineContext", "<init>", "(Landroidx/lifecycle/f;Ldbxyzptlk/tI/g;)V", "Ldbxyzptlk/pI/D;", "e", "()V", "Landroidx/lifecycle/LifecycleOwner;", "source", "Landroidx/lifecycle/f$a;", "event", "f", "(Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/f$a;)V", "a", "Landroidx/lifecycle/f;", "()Landroidx/lifecycle/f;", "b", "Ldbxyzptlk/tI/g;", "getCoroutineContext", "()Ldbxyzptlk/tI/g;", "lifecycle-common"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class LifecycleCoroutineScopeImpl extends g implements LifecycleEventObserver {
  public final f a;
  
  public final g b;
  
  public LifecycleCoroutineScopeImpl(f paramf, g paramg) {
    this.a = paramf;
    this.b = paramg;
    if (a().b() == f.b.DESTROYED)
      z0.f(getCoroutineContext(), null, 1, null); 
  }
  
  public f a() {
    return this.a;
  }
  
  public final void e() {
    h.d((J)this, (g)Z.c().y0(), null, new a(this, null), 2, null);
  }
  
  public void f(LifecycleOwner paramLifecycleOwner, f.a parama) {
    s.h(paramLifecycleOwner, "source");
    s.h(parama, "event");
    if (a().b().compareTo(f.b.DESTROYED) <= 0) {
      a().d(this);
      z0.f(getCoroutineContext(), null, 1, null);
    } 
  }
  
  public g getCoroutineContext() {
    return this.b;
  }
  
  @f(c = "androidx.lifecycle.LifecycleCoroutineScopeImpl$register$1", f = "Lifecycle.kt", l = {}, m = "invokeSuspend")
  @Metadata(d1 = {"\000\f\n\002\030\002\n\002\030\002\n\002\b\002\020\002\032\0020\001*\0020\000H@¢\006\004\b\002\020\003"}, d2 = {"Ldbxyzptlk/bK/J;", "Ldbxyzptlk/pI/D;", "<anonymous>", "(Ldbxyzptlk/bK/J;)V"}, k = 3, mv = {1, 8, 0})
  public static final class a extends l implements p<J, d<? super D>, Object> {
    public int t;
    
    public Object u;
    
    public final LifecycleCoroutineScopeImpl v;
    
    public a(LifecycleCoroutineScopeImpl param1LifecycleCoroutineScopeImpl, d<? super a> param1d) {
      super(2, param1d);
    }
    
    public final d<D> create(Object param1Object, d<?> param1d) {
      a a1 = new a(this.v, (d)param1d);
      a1.u = param1Object;
      return (d<D>)a1;
    }
    
    public final Object invoke(J param1J, d<? super D> param1d) {
      return ((a)create(param1J, param1d)).invokeSuspend(D.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      c.g();
      if (this.t == 0) {
        p.b(param1Object);
        param1Object = this.u;
        if (this.v.a().b().compareTo(f.b.INITIALIZED) >= 0) {
          this.v.a().a(this.v);
        } else {
          z0.f(param1Object.getCoroutineContext(), null, 1, null);
        } 
        return D.a;
      } 
      throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\lifecycle\LifecycleCoroutineScopeImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */