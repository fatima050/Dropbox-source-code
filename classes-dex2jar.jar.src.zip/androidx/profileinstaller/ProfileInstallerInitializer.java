package androidx.profileinstaller;

import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.Choreographer;
import dbxyzptlk.B4.f;
import dbxyzptlk.B4.g;
import dbxyzptlk.B4.h;
import dbxyzptlk.B4.i;
import dbxyzptlk.O4.b;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class ProfileInstallerInitializer implements b<ProfileInstallerInitializer.c> {
  public static void k(Context paramContext) {
    (new ThreadPoolExecutor(0, 1, 0L, TimeUnit.MILLISECONDS, new LinkedBlockingQueue<>())).execute((Runnable)new h(paramContext));
  }
  
  public List<Class<? extends b<?>>> dependencies() {
    return Collections.emptyList();
  }
  
  public c e(Context paramContext) {
    f(paramContext.getApplicationContext());
    return new c();
  }
  
  public void f(Context paramContext) {
    a.c((Runnable)new f(this, paramContext));
  }
  
  public void g(Context paramContext) {
    Handler handler;
    if (Build.VERSION.SDK_INT >= 28) {
      handler = b.a(Looper.getMainLooper());
    } else {
      handler = new Handler(Looper.getMainLooper());
    } 
    int i = (new Random()).nextInt(Math.max(1000, 1));
    handler.postDelayed((Runnable)new g(paramContext), (i + 5000));
  }
  
  public static class a {
    public static void c(Runnable param1Runnable) {
      Choreographer.getInstance().postFrameCallback((Choreographer.FrameCallback)new i(param1Runnable));
    }
  }
  
  public static class b {
    public static Handler a(Looper param1Looper) {
      return dbxyzptlk.F2.b.a(param1Looper);
    }
  }
  
  public static class c {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\profileinstaller\ProfileInstallerInitializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */