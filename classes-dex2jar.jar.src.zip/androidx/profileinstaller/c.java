package androidx.profileinstaller;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.AssetManager;
import android.util.Log;
import dbxyzptlk.A4.m;
import dbxyzptlk.B4.e;
import io.sentry.android.core.r0;
import io.sentry.instrumentation.file.h;
import io.sentry.instrumentation.file.l;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.concurrent.Executor;

public class c {
  public static final c a = new a();
  
  public static final c b = new b();
  
  public static boolean b(File paramFile) {
    return (new File(paramFile, "profileinstaller_profileWrittenFor_lastUpdateTime.dat")).delete();
  }
  
  public static void c(Context paramContext, Executor paramExecutor, c paramc) {
    b(paramContext.getFilesDir());
    g(paramExecutor, paramc, 11, null);
  }
  
  public static boolean d(PackageInfo paramPackageInfo, File paramFile, c paramc) {
    File file = new File(paramFile, "profileinstaller_profileWrittenFor_lastUpdateTime.dat");
    boolean bool1 = file.exists();
    boolean bool = false;
    if (!bool1)
      return false; 
    try {
      DataInputStream dataInputStream = new DataInputStream();
      FileInputStream fileInputStream = new FileInputStream();
      this(file);
      this(h.b.a(fileInputStream, file));
      try {
        long l = dataInputStream.readLong();
        dataInputStream.close();
        if (l == paramPackageInfo.lastUpdateTime)
          bool = true; 
        return bool;
      } finally {
        try {
          dataInputStream.close();
        } finally {
          dataInputStream = null;
        } 
      } 
    } catch (IOException iOException) {
      return false;
    } 
  }
  
  public static void f(PackageInfo paramPackageInfo, File paramFile) {
    File file = new File(paramFile, "profileinstaller_profileWrittenFor_lastUpdateTime.dat");
    try {
      DataOutputStream dataOutputStream = new DataOutputStream();
      FileOutputStream fileOutputStream = new FileOutputStream();
      this(file);
      this(l.b.a(fileOutputStream, file));
      try {
        dataOutputStream.writeLong(paramPackageInfo.lastUpdateTime);
      } finally {
        try {
          dataOutputStream.close();
        } finally {
          dataOutputStream = null;
        } 
      } 
    } catch (IOException iOException) {}
  }
  
  public static void g(Executor paramExecutor, c paramc, int paramInt, Object paramObject) {
    paramExecutor.execute((Runnable)new e(paramc, paramInt, paramObject));
  }
  
  public static boolean h(AssetManager paramAssetManager, String paramString1, PackageInfo paramPackageInfo, File paramFile, String paramString2, Executor paramExecutor, c paramc) {
    b b = new b(paramAssetManager, paramExecutor, paramc, paramString2, "dexopt/baseline.prof", "dexopt/baseline.profm", new File(new File("/data/misc/profiles/cur/0", paramString1), "primary.prof"));
    if (!b.e())
      return false; 
    boolean bool = b.i().m().n();
    if (bool)
      f(paramPackageInfo, paramFile); 
    return bool;
  }
  
  public static void i(Context paramContext) {
    j(paramContext, (Executor)new m(), a);
  }
  
  public static void j(Context paramContext, Executor paramExecutor, c paramc) {
    k(paramContext, paramExecutor, paramc, false);
  }
  
  public static void k(Context paramContext, Executor paramExecutor, c paramc, boolean paramBoolean) {
    Context context = paramContext.getApplicationContext();
    String str1 = context.getPackageName();
    ApplicationInfo applicationInfo = context.getApplicationInfo();
    AssetManager assetManager = context.getAssets();
    String str2 = (new File(applicationInfo.sourceDir)).getName();
    PackageManager packageManager = paramContext.getPackageManager();
    boolean bool = false;
    try {
      PackageInfo packageInfo = packageManager.getPackageInfo(str1, 0);
      File file = paramContext.getFilesDir();
      if (paramBoolean || !d(packageInfo, file, paramc)) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("Installing profile for ");
        stringBuilder1.append(paramContext.getPackageName());
        Log.d("ProfileInstaller", stringBuilder1.toString());
        boolean bool1 = bool;
        if (h(assetManager, str1, packageInfo, file, str2, paramExecutor, paramc)) {
          bool1 = bool;
          if (paramBoolean)
            bool1 = true; 
        } 
        d.c(paramContext, bool1);
        return;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Skipping profile installation for ");
      stringBuilder.append(paramContext.getPackageName());
      Log.d("ProfileInstaller", stringBuilder.toString());
      d.c(paramContext, false);
      return;
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
      paramc.a(7, nameNotFoundException);
      d.c(paramContext, false);
      return;
    } 
  }
  
  public static void l(Context paramContext, Executor paramExecutor, c paramc) {
    String str = paramContext.getApplicationContext().getPackageName();
    PackageManager packageManager = paramContext.getPackageManager();
    try {
      PackageInfo packageInfo = packageManager.getPackageInfo(str, 0);
      f(packageInfo, paramContext.getFilesDir());
      g(paramExecutor, paramc, 10, null);
      return;
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
      g(paramExecutor, paramc, 7, nameNotFoundException);
      return;
    } 
  }
  
  public class a implements c {
    public void a(int param1Int, Object param1Object) {}
    
    public void b(int param1Int, Object param1Object) {}
  }
  
  public class b implements c {
    public void a(int param1Int, Object param1Object) {
      String str;
      switch (param1Int) {
        default:
          str = "";
          break;
        case 11:
          str = "RESULT_DELETE_SKIP_FILE_SUCCESS";
          break;
        case 10:
          str = "RESULT_INSTALL_SKIP_FILE_SUCCESS";
          break;
        case 8:
          str = "RESULT_PARSE_EXCEPTION";
          break;
        case 7:
          str = "RESULT_IO_EXCEPTION";
          break;
        case 6:
          str = "RESULT_BASELINE_PROFILE_NOT_FOUND";
          break;
        case 5:
          str = "RESULT_DESIRED_FORMAT_UNSUPPORTED";
          break;
        case 4:
          str = "RESULT_NOT_WRITABLE";
          break;
        case 3:
          str = "RESULT_UNSUPPORTED_ART_VERSION";
          break;
        case 2:
          str = "RESULT_ALREADY_INSTALLED";
          break;
        case 1:
          str = "RESULT_INSTALL_SUCCESS";
          break;
      } 
      if (param1Int != 6 && param1Int != 7 && param1Int != 8) {
        Log.d("ProfileInstaller", str);
      } else {
        r0.e("ProfileInstaller", str, (Throwable)param1Object);
      } 
    }
    
    public void b(int param1Int, Object param1Object) {
      if (param1Int != 1) {
        if (param1Int != 2) {
          if (param1Int != 3) {
            if (param1Int != 4) {
              if (param1Int != 5) {
                param1Object = "";
              } else {
                param1Object = "DIAGNOSTIC_PROFILE_IS_COMPRESSED";
              } 
            } else {
              param1Object = "DIAGNOSTIC_REF_PROFILE_DOES_NOT_EXIST";
            } 
          } else {
            param1Object = "DIAGNOSTIC_REF_PROFILE_EXISTS";
          } 
        } else {
          param1Object = "DIAGNOSTIC_CURRENT_PROFILE_DOES_NOT_EXIST";
        } 
      } else {
        param1Object = "DIAGNOSTIC_CURRENT_PROFILE_EXISTS";
      } 
      Log.d("ProfileInstaller", (String)param1Object);
    }
  }
  
  class c {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\profileinstaller\c.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */