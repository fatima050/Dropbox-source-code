package androidx.profileinstaller;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Process;
import dbxyzptlk.A4.m;
import java.util.concurrent.Executor;

public class ProfileInstallReceiver extends BroadcastReceiver {
  public static void a(c.c paramc) {
    Process.sendSignal(Process.myPid(), 10);
    paramc.a(12, null);
  }
  
  public void onReceive(Context paramContext, Intent paramIntent) {
    if (paramIntent == null)
      return; 
    String str = paramIntent.getAction();
    if ("androidx.profileinstaller.action.INSTALL_PROFILE".equals(str)) {
      c.k(paramContext, (Executor)new m(), new a(this), true);
    } else {
      String str1;
      if ("androidx.profileinstaller.action.SKIP_FILE".equals(str)) {
        Bundle bundle = paramIntent.getExtras();
        if (bundle != null) {
          str1 = bundle.getString("EXTRA_SKIP_FILE_OPERATION");
          if ("WRITE_SKIP_FILE".equals(str1)) {
            c.l(paramContext, (Executor)new m(), new a(this));
          } else if ("DELETE_SKIP_FILE".equals(str1)) {
            c.c(paramContext, (Executor)new m(), new a(this));
          } 
        } 
      } else if ("androidx.profileinstaller.action.SAVE_PROFILE".equals(str)) {
        a(new a(this));
      } else if ("androidx.profileinstaller.action.BENCHMARK_OPERATION".equals(str)) {
        Bundle bundle = str1.getExtras();
        if (bundle != null) {
          String str2 = bundle.getString("EXTRA_BENCHMARK_OPERATION");
          a a = new a(this);
          if ("DROP_SHADER_CACHE".equals(str2)) {
            a.b(paramContext, a);
          } else {
            a.a(16, null);
          } 
        } 
      } 
    } 
  }
  
  public class a implements c.c {
    public final ProfileInstallReceiver a;
    
    public a(ProfileInstallReceiver this$0) {}
    
    public void a(int param1Int, Object param1Object) {
      c.b.a(param1Int, param1Object);
      this.a.setResultCode(param1Int);
    }
    
    public void b(int param1Int, Object param1Object) {
      c.b.b(param1Int, param1Object);
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\profileinstaller\ProfileInstallReceiver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */