package androidx.profileinstaller;

import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import io.sentry.instrumentation.file.h;
import io.sentry.instrumentation.file.l;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Objects;

public final class d {
  public static final dbxyzptlk.E1.d<c> a = dbxyzptlk.E1.d.J();
  
  public static final Object b = new Object();
  
  public static c c = null;
  
  public static long a(Context paramContext) throws PackageManager.NameNotFoundException {
    PackageManager packageManager = paramContext.getApplicationContext().getPackageManager();
    return (Build.VERSION.SDK_INT >= 33) ? (a.a(packageManager, paramContext)).lastUpdateTime : (packageManager.getPackageInfo(paramContext.getPackageName(), 0)).lastUpdateTime;
  }
  
  public static c b(int paramInt, boolean paramBoolean1, boolean paramBoolean2) {
    c c1 = new c(paramInt, paramBoolean1, paramBoolean2);
    c = c1;
    a.F(c1);
    return c;
  }
  
  public static c c(Context paramContext, boolean paramBoolean) {
    // Byte code:
    //   0: iload_1
    //   1: ifne -> 17
    //   4: getstatic androidx/profileinstaller/d.c : Landroidx/profileinstaller/d$c;
    //   7: astore #13
    //   9: aload #13
    //   11: ifnull -> 17
    //   14: aload #13
    //   16: areturn
    //   17: getstatic androidx/profileinstaller/d.b : Ljava/lang/Object;
    //   20: astore #13
    //   22: aload #13
    //   24: monitorenter
    //   25: iload_1
    //   26: ifne -> 49
    //   29: getstatic androidx/profileinstaller/d.c : Landroidx/profileinstaller/d$c;
    //   32: astore #14
    //   34: aload #14
    //   36: ifnull -> 49
    //   39: aload #13
    //   41: monitorexit
    //   42: aload #14
    //   44: areturn
    //   45: astore_0
    //   46: goto -> 457
    //   49: getstatic android/os/Build$VERSION.SDK_INT : I
    //   52: istore_3
    //   53: iconst_0
    //   54: istore_2
    //   55: iload_3
    //   56: bipush #28
    //   58: if_icmplt -> 444
    //   61: iload_3
    //   62: bipush #30
    //   64: if_icmpne -> 70
    //   67: goto -> 444
    //   70: new java/io/File
    //   73: astore #14
    //   75: new java/io/File
    //   78: astore #15
    //   80: aload #15
    //   82: ldc '/data/misc/profiles/ref/'
    //   84: aload_0
    //   85: invokevirtual getPackageName : ()Ljava/lang/String;
    //   88: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;)V
    //   91: aload #14
    //   93: aload #15
    //   95: ldc 'primary.prof'
    //   97: invokespecial <init> : (Ljava/io/File;Ljava/lang/String;)V
    //   100: aload #14
    //   102: invokevirtual length : ()J
    //   105: lstore #6
    //   107: aload #14
    //   109: invokevirtual exists : ()Z
    //   112: ifeq -> 128
    //   115: lload #6
    //   117: lconst_0
    //   118: lcmp
    //   119: ifle -> 128
    //   122: iconst_1
    //   123: istore #10
    //   125: goto -> 131
    //   128: iconst_0
    //   129: istore #10
    //   131: new java/io/File
    //   134: astore #15
    //   136: new java/io/File
    //   139: astore #14
    //   141: aload #14
    //   143: ldc '/data/misc/profiles/cur/0/'
    //   145: aload_0
    //   146: invokevirtual getPackageName : ()Ljava/lang/String;
    //   149: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;)V
    //   152: aload #15
    //   154: aload #14
    //   156: ldc 'primary.prof'
    //   158: invokespecial <init> : (Ljava/io/File;Ljava/lang/String;)V
    //   161: aload #15
    //   163: invokevirtual length : ()J
    //   166: lstore #8
    //   168: aload #15
    //   170: invokevirtual exists : ()Z
    //   173: istore #11
    //   175: iload #11
    //   177: ifeq -> 193
    //   180: lload #8
    //   182: lconst_0
    //   183: lcmp
    //   184: ifle -> 193
    //   187: iconst_1
    //   188: istore #11
    //   190: goto -> 196
    //   193: iconst_0
    //   194: istore #11
    //   196: aload_0
    //   197: invokestatic a : (Landroid/content/Context;)J
    //   200: lstore #4
    //   202: new java/io/File
    //   205: astore #14
    //   207: aload #14
    //   209: aload_0
    //   210: invokevirtual getFilesDir : ()Ljava/io/File;
    //   213: ldc 'profileInstalled'
    //   215: invokespecial <init> : (Ljava/io/File;Ljava/lang/String;)V
    //   218: aload #14
    //   220: invokevirtual exists : ()Z
    //   223: istore #12
    //   225: iload #12
    //   227: ifeq -> 255
    //   230: aload #14
    //   232: invokestatic a : (Ljava/io/File;)Landroidx/profileinstaller/d$b;
    //   235: astore_0
    //   236: goto -> 257
    //   239: astore_0
    //   240: ldc 131072
    //   242: iload #10
    //   244: iload #11
    //   246: invokestatic b : (IZZ)Landroidx/profileinstaller/d$c;
    //   249: astore_0
    //   250: aload #13
    //   252: monitorexit
    //   253: aload_0
    //   254: areturn
    //   255: aconst_null
    //   256: astore_0
    //   257: aload_0
    //   258: ifnull -> 289
    //   261: aload_0
    //   262: getfield c : J
    //   265: lload #4
    //   267: lcmp
    //   268: ifne -> 289
    //   271: aload_0
    //   272: getfield b : I
    //   275: istore_3
    //   276: iload_3
    //   277: iconst_2
    //   278: if_icmpne -> 284
    //   281: goto -> 289
    //   284: iload_3
    //   285: istore_2
    //   286: goto -> 306
    //   289: iload #10
    //   291: ifeq -> 299
    //   294: iconst_1
    //   295: istore_2
    //   296: goto -> 306
    //   299: iload #11
    //   301: ifeq -> 306
    //   304: iconst_2
    //   305: istore_2
    //   306: iload_2
    //   307: istore_3
    //   308: iload_1
    //   309: ifeq -> 328
    //   312: iload_2
    //   313: istore_3
    //   314: iload #11
    //   316: ifeq -> 328
    //   319: iload_2
    //   320: istore_3
    //   321: iload_2
    //   322: iconst_1
    //   323: if_icmpeq -> 328
    //   326: iconst_2
    //   327: istore_3
    //   328: iload_3
    //   329: istore_2
    //   330: aload_0
    //   331: ifnull -> 365
    //   334: iload_3
    //   335: istore_2
    //   336: aload_0
    //   337: getfield b : I
    //   340: iconst_2
    //   341: if_icmpne -> 365
    //   344: iload_3
    //   345: istore_2
    //   346: iload_3
    //   347: iconst_1
    //   348: if_icmpne -> 365
    //   351: iload_3
    //   352: istore_2
    //   353: lload #6
    //   355: aload_0
    //   356: getfield d : J
    //   359: lcmp
    //   360: ifge -> 365
    //   363: iconst_3
    //   364: istore_2
    //   365: new androidx/profileinstaller/d$b
    //   368: astore #15
    //   370: aload #15
    //   372: iconst_1
    //   373: iload_2
    //   374: lload #4
    //   376: lload #8
    //   378: invokespecial <init> : (IIJJ)V
    //   381: aload_0
    //   382: ifnull -> 398
    //   385: aload_0
    //   386: aload #15
    //   388: invokevirtual equals : (Ljava/lang/Object;)Z
    //   391: istore_1
    //   392: iload_2
    //   393: istore_3
    //   394: iload_1
    //   395: ifne -> 414
    //   398: aload #15
    //   400: aload #14
    //   402: invokevirtual b : (Ljava/io/File;)V
    //   405: iload_2
    //   406: istore_3
    //   407: goto -> 414
    //   410: astore_0
    //   411: ldc 196608
    //   413: istore_3
    //   414: iload_3
    //   415: iload #10
    //   417: iload #11
    //   419: invokestatic b : (IZZ)Landroidx/profileinstaller/d$c;
    //   422: astore_0
    //   423: aload #13
    //   425: monitorexit
    //   426: aload_0
    //   427: areturn
    //   428: astore_0
    //   429: ldc 65536
    //   431: iload #10
    //   433: iload #11
    //   435: invokestatic b : (IZZ)Landroidx/profileinstaller/d$c;
    //   438: astore_0
    //   439: aload #13
    //   441: monitorexit
    //   442: aload_0
    //   443: areturn
    //   444: ldc 262144
    //   446: iconst_0
    //   447: iconst_0
    //   448: invokestatic b : (IZZ)Landroidx/profileinstaller/d$c;
    //   451: astore_0
    //   452: aload #13
    //   454: monitorexit
    //   455: aload_0
    //   456: areturn
    //   457: aload #13
    //   459: monitorexit
    //   460: aload_0
    //   461: athrow
    // Exception table:
    //   from	to	target	type
    //   29	34	45	finally
    //   39	42	45	finally
    //   49	53	45	finally
    //   70	115	45	finally
    //   131	175	45	finally
    //   196	202	428	android/content/pm/PackageManager$NameNotFoundException
    //   196	202	45	finally
    //   202	225	45	finally
    //   230	236	239	java/io/IOException
    //   230	236	45	finally
    //   240	253	45	finally
    //   261	276	45	finally
    //   336	344	45	finally
    //   353	363	45	finally
    //   365	381	45	finally
    //   385	392	45	finally
    //   398	405	410	java/io/IOException
    //   398	405	45	finally
    //   414	426	45	finally
    //   429	442	45	finally
    //   444	455	45	finally
    //   457	460	45	finally
  }
  
  class d {}
  
  public static class b {
    public final int a;
    
    public final int b;
    
    public final long c;
    
    public final long d;
    
    public b(int param1Int1, int param1Int2, long param1Long1, long param1Long2) {
      this.a = param1Int1;
      this.b = param1Int2;
      this.c = param1Long1;
      this.d = param1Long2;
    }
    
    public static b a(File param1File) throws IOException {
      DataInputStream dataInputStream = new DataInputStream(h.b.a(new FileInputStream(param1File), param1File));
      try {
        return new b(dataInputStream.readInt(), dataInputStream.readInt(), dataInputStream.readLong(), dataInputStream.readLong());
      } finally {
        try {
          dataInputStream.close();
        } finally {
          dataInputStream = null;
        } 
      } 
    }
    
    public void b(File param1File) throws IOException {
      param1File.delete();
      DataOutputStream dataOutputStream = new DataOutputStream(l.b.a(new FileOutputStream(param1File), param1File));
      try {
        dataOutputStream.writeInt(this.a);
        dataOutputStream.writeInt(this.b);
        dataOutputStream.writeLong(this.c);
        dataOutputStream.writeLong(this.d);
        return;
      } finally {
        try {
          dataOutputStream.close();
        } finally {
          dataOutputStream = null;
        } 
      } 
    }
    
    public boolean equals(Object param1Object) {
      boolean bool = true;
      if (this == param1Object)
        return true; 
      if (param1Object == null || !(param1Object instanceof b))
        return false; 
      param1Object = param1Object;
      if (this.b != ((b)param1Object).b || this.c != ((b)param1Object).c || this.a != ((b)param1Object).a || this.d != ((b)param1Object).d)
        bool = false; 
      return bool;
    }
    
    public int hashCode() {
      return Objects.hash(new Object[] { Integer.valueOf(this.b), Long.valueOf(this.c), Integer.valueOf(this.a), Long.valueOf(this.d) });
    }
  }
  
  public static class c {
    public final int a;
    
    public final boolean b;
    
    public final boolean c;
    
    public c(int param1Int, boolean param1Boolean1, boolean param1Boolean2) {
      this.a = param1Int;
      this.c = param1Boolean2;
      this.b = param1Boolean1;
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\profileinstaller\d.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */