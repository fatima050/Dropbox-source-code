package androidx.coordinatorlayout.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Region;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.SystemClock;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewTreeObserver;
import androidx.customview.view.AbsSavedState;
import dbxyzptlk.g2.f;
import dbxyzptlk.g2.h;
import dbxyzptlk.h2.J0;
import dbxyzptlk.h2.L;
import dbxyzptlk.h2.M;
import dbxyzptlk.h2.N;
import dbxyzptlk.h2.O;
import dbxyzptlk.h2.h0;
import dbxyzptlk.h2.x;
import io.sentry.android.core.r0;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CoordinatorLayout extends ViewGroup implements L, M {
  static final Class<?>[] CONSTRUCTOR_PARAMS;
  
  static final int EVENT_NESTED_SCROLL = 1;
  
  static final int EVENT_PRE_DRAW = 0;
  
  static final int EVENT_VIEW_REMOVED = 2;
  
  static final String TAG = "CoordinatorLayout";
  
  static final Comparator<View> TOP_SORTED_CHILDREN_COMPARATOR;
  
  private static final int TYPE_ON_INTERCEPT = 0;
  
  private static final int TYPE_ON_TOUCH = 1;
  
  static final String WIDGET_PACKAGE_NAME;
  
  static final ThreadLocal<Map<String, Constructor<Behavior>>> sConstructors;
  
  private static final f<Rect> sRectPool;
  
  private O mApplyWindowInsetsListener;
  
  private final int[] mBehaviorConsumed;
  
  private View mBehaviorTouchView;
  
  private final dbxyzptlk.R1.a<View> mChildDag;
  
  private final List<View> mDependencySortedChildren;
  
  private boolean mDisallowInterceptReset;
  
  private boolean mDrawStatusBarBackground;
  
  private boolean mIsAttachedToWindow;
  
  private int[] mKeylines;
  
  private J0 mLastInsets;
  
  private boolean mNeedsPreDrawListener;
  
  private final N mNestedScrollingParentHelper;
  
  private View mNestedScrollingTarget;
  
  private final int[] mNestedScrollingV2ConsumedCompat;
  
  ViewGroup.OnHierarchyChangeListener mOnHierarchyChangeListener;
  
  private f mOnPreDrawListener;
  
  private Paint mScrimPaint;
  
  private Drawable mStatusBarBackground;
  
  private final List<View> mTempList1;
  
  static {
    Package package_ = CoordinatorLayout.class.getPackage();
    if (package_ != null) {
      String str = package_.getName();
    } else {
      package_ = null;
    } 
    WIDGET_PACKAGE_NAME = (String)package_;
    TOP_SORTED_CHILDREN_COMPARATOR = new g();
    CONSTRUCTOR_PARAMS = new Class[] { Context.class, AttributeSet.class };
    sConstructors = new ThreadLocal<>();
    sRectPool = (f<Rect>)new h(12);
  }
  
  public CoordinatorLayout(Context paramContext) {
    this(paramContext, null);
  }
  
  public CoordinatorLayout(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, dbxyzptlk.Q1.a.coordinatorLayoutStyle);
  }
  
  public CoordinatorLayout(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    TypedArray typedArray;
    this.mDependencySortedChildren = new ArrayList<>();
    this.mChildDag = new dbxyzptlk.R1.a();
    this.mTempList1 = new ArrayList<>();
    this.mBehaviorConsumed = new int[2];
    this.mNestedScrollingV2ConsumedCompat = new int[2];
    this.mNestedScrollingParentHelper = new N((ViewGroup)this);
    boolean bool = false;
    if (paramInt == 0) {
      typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, dbxyzptlk.Q1.c.CoordinatorLayout, 0, dbxyzptlk.Q1.b.Widget_Support_CoordinatorLayout);
    } else {
      typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, dbxyzptlk.Q1.c.CoordinatorLayout, paramInt, 0);
    } 
    if (paramInt == 0) {
      h0.o0((View)this, paramContext, dbxyzptlk.Q1.c.CoordinatorLayout, paramAttributeSet, typedArray, 0, dbxyzptlk.Q1.b.Widget_Support_CoordinatorLayout);
    } else {
      h0.o0((View)this, paramContext, dbxyzptlk.Q1.c.CoordinatorLayout, paramAttributeSet, typedArray, paramInt, 0);
    } 
    paramInt = typedArray.getResourceId(dbxyzptlk.Q1.c.CoordinatorLayout_keylines, 0);
    if (paramInt != 0) {
      Resources resources = paramContext.getResources();
      this.mKeylines = resources.getIntArray(paramInt);
      float f1 = (resources.getDisplayMetrics()).density;
      int i = this.mKeylines.length;
      for (paramInt = bool; paramInt < i; paramInt++) {
        int[] arrayOfInt = this.mKeylines;
        arrayOfInt[paramInt] = (int)(arrayOfInt[paramInt] * f1);
      } 
    } 
    this.mStatusBarBackground = typedArray.getDrawable(dbxyzptlk.Q1.c.CoordinatorLayout_statusBarBackground);
    typedArray.recycle();
    setupForInsets();
    super.setOnHierarchyChangeListener(new d(this));
    if (h0.y((View)this) == 0)
      h0.A0((View)this, 1); 
  }
  
  private static Rect acquireTempRect() {
    Rect rect2 = (Rect)sRectPool.a();
    Rect rect1 = rect2;
    if (rect2 == null)
      rect1 = new Rect(); 
    return rect1;
  }
  
  private void cancelInterceptBehaviors() {
    int i = getChildCount();
    MotionEvent motionEvent = null;
    byte b = 0;
    while (b < i) {
      View view = getChildAt(b);
      Behavior behavior = ((e)view.getLayoutParams()).f();
      MotionEvent motionEvent1 = motionEvent;
      if (behavior != null) {
        motionEvent1 = motionEvent;
        if (motionEvent == null) {
          long l = SystemClock.uptimeMillis();
          motionEvent1 = MotionEvent.obtain(l, l, 3, 0.0F, 0.0F, 0);
        } 
        behavior.onInterceptTouchEvent(this, view, motionEvent1);
      } 
      b++;
      motionEvent = motionEvent1;
    } 
    if (motionEvent != null)
      motionEvent.recycle(); 
  }
  
  private static int clamp(int paramInt1, int paramInt2, int paramInt3) {
    return (paramInt1 < paramInt2) ? paramInt2 : ((paramInt1 > paramInt3) ? paramInt3 : paramInt1);
  }
  
  private void constrainChildRect(e parame, Rect paramRect, int paramInt1, int paramInt2) {
    int i = getWidth();
    int j = getHeight();
    i = Math.max(getPaddingLeft() + parame.leftMargin, Math.min(paramRect.left, i - getPaddingRight() - paramInt1 - parame.rightMargin));
    j = Math.max(getPaddingTop() + parame.topMargin, Math.min(paramRect.top, j - getPaddingBottom() - paramInt2 - parame.bottomMargin));
    paramRect.set(i, j, paramInt1 + i, paramInt2 + j);
  }
  
  private J0 dispatchApplyWindowInsetsToBehaviors(J0 paramJ0) {
    J0 j0;
    if (paramJ0.r())
      return paramJ0; 
    int i = getChildCount();
    byte b = 0;
    while (true) {
      j0 = paramJ0;
      if (b < i) {
        View view = getChildAt(b);
        j0 = paramJ0;
        if (h0.x(view)) {
          Behavior behavior = ((e)view.getLayoutParams()).f();
          j0 = paramJ0;
          if (behavior != null) {
            paramJ0 = behavior.onApplyWindowInsets(this, view, paramJ0);
            j0 = paramJ0;
            if (paramJ0.r()) {
              j0 = paramJ0;
              break;
            } 
          } 
        } 
        b++;
        paramJ0 = j0;
        continue;
      } 
      break;
    } 
    return j0;
  }
  
  private void getDesiredAnchoredChildRectWithoutConstraints(int paramInt1, Rect paramRect1, Rect paramRect2, e parame, int paramInt2, int paramInt3) {
    int i = x.b(resolveAnchoredChildGravity(parame.c), paramInt1);
    paramInt1 = x.b(resolveGravity(parame.d), paramInt1);
    int m = i & 0x7;
    int k = i & 0x70;
    int j = paramInt1 & 0x7;
    i = paramInt1 & 0x70;
    if (j != 1) {
      if (j != 5) {
        paramInt1 = paramRect1.left;
      } else {
        paramInt1 = paramRect1.right;
      } 
    } else {
      paramInt1 = paramRect1.left + paramRect1.width() / 2;
    } 
    if (i != 16) {
      if (i != 80) {
        i = paramRect1.top;
      } else {
        i = paramRect1.bottom;
      } 
    } else {
      i = paramRect1.top + paramRect1.height() / 2;
    } 
    if (m != 1) {
      j = paramInt1;
      if (m != 5)
        j = paramInt1 - paramInt2; 
    } else {
      j = paramInt1 - paramInt2 / 2;
    } 
    if (k != 16) {
      paramInt1 = i;
      if (k != 80)
        paramInt1 = i - paramInt3; 
    } else {
      paramInt1 = i - paramInt3 / 2;
    } 
    paramRect2.set(j, paramInt1, paramInt2 + j, paramInt3 + paramInt1);
  }
  
  private int getKeyline(int paramInt) {
    StringBuilder stringBuilder;
    int[] arrayOfInt = this.mKeylines;
    if (arrayOfInt == null) {
      stringBuilder = new StringBuilder();
      stringBuilder.append("No keylines defined for ");
      stringBuilder.append(this);
      stringBuilder.append(" - attempted index lookup ");
      stringBuilder.append(paramInt);
      r0.d("CoordinatorLayout", stringBuilder.toString());
      return 0;
    } 
    if (paramInt < 0 || paramInt >= stringBuilder.length) {
      stringBuilder = new StringBuilder();
      stringBuilder.append("Keyline index ");
      stringBuilder.append(paramInt);
      stringBuilder.append(" out of range for ");
      stringBuilder.append(this);
      r0.d("CoordinatorLayout", stringBuilder.toString());
      return 0;
    } 
    return stringBuilder[paramInt];
  }
  
  private void getTopSortedChildren(List<View> paramList) {
    paramList.clear();
    boolean bool = isChildrenDrawingOrderEnabled();
    int j = getChildCount();
    for (int i = j - 1; i >= 0; i--) {
      int k;
      if (bool) {
        k = getChildDrawingOrder(j, i);
      } else {
        k = i;
      } 
      paramList.add(getChildAt(k));
    } 
    Comparator<View> comparator = TOP_SORTED_CHILDREN_COMPARATOR;
    if (comparator != null)
      Collections.sort(paramList, comparator); 
  }
  
  private boolean hasDependencies(View paramView) {
    return this.mChildDag.k(paramView);
  }
  
  private void layoutChild(View paramView, int paramInt) {
    e e = (e)paramView.getLayoutParams();
    Rect rect1 = acquireTempRect();
    rect1.set(getPaddingLeft() + e.leftMargin, getPaddingTop() + e.topMargin, getWidth() - getPaddingRight() - e.rightMargin, getHeight() - getPaddingBottom() - e.bottomMargin);
    if (this.mLastInsets != null && h0.x((View)this) && !h0.x(paramView)) {
      rect1.left += this.mLastInsets.k();
      rect1.top += this.mLastInsets.m();
      rect1.right -= this.mLastInsets.l();
      rect1.bottom -= this.mLastInsets.j();
    } 
    Rect rect2 = acquireTempRect();
    x.a(resolveGravity(e.c), paramView.getMeasuredWidth(), paramView.getMeasuredHeight(), rect1, rect2, paramInt);
    paramView.layout(rect2.left, rect2.top, rect2.right, rect2.bottom);
    releaseTempRect(rect1);
    releaseTempRect(rect2);
  }
  
  private void layoutChildWithAnchor(View paramView1, View paramView2, int paramInt) {
    Rect rect2 = acquireTempRect();
    Rect rect1 = acquireTempRect();
    try {
      getDescendantRect(paramView2, rect2);
      getDesiredAnchoredChildRect(paramView1, paramInt, rect2, rect1);
      paramView1.layout(rect1.left, rect1.top, rect1.right, rect1.bottom);
      return;
    } finally {
      releaseTempRect(rect2);
      releaseTempRect(rect1);
    } 
  }
  
  private void layoutChildWithKeyline(View paramView, int paramInt1, int paramInt2) {
    e e = (e)paramView.getLayoutParams();
    int i = x.b(resolveKeylineGravity(e.c), paramInt2);
    int i2 = i & 0x7;
    int i1 = i & 0x70;
    int n = getWidth();
    int m = getHeight();
    int k = paramView.getMeasuredWidth();
    int j = paramView.getMeasuredHeight();
    i = paramInt1;
    if (paramInt2 == 1)
      i = n - paramInt1; 
    paramInt1 = getKeyline(i) - k;
    if (i2 != 1) {
      if (i2 == 5)
        paramInt1 += k; 
    } else {
      paramInt1 += k / 2;
    } 
    if (i1 != 16) {
      if (i1 != 80) {
        paramInt2 = 0;
      } else {
        paramInt2 = j;
      } 
    } else {
      paramInt2 = j / 2;
    } 
    paramInt1 = Math.max(getPaddingLeft() + e.leftMargin, Math.min(paramInt1, n - getPaddingRight() - k - e.rightMargin));
    paramInt2 = Math.max(getPaddingTop() + e.topMargin, Math.min(paramInt2, m - getPaddingBottom() - j - e.bottomMargin));
    paramView.layout(paramInt1, paramInt2, k + paramInt1, j + paramInt2);
  }
  
  private MotionEvent obtainCancelEvent(MotionEvent paramMotionEvent) {
    paramMotionEvent = MotionEvent.obtain(paramMotionEvent);
    paramMotionEvent.setAction(3);
    return paramMotionEvent;
  }
  
  private void offsetChildByInset(View paramView, Rect paramRect, int paramInt) {
    // Byte code:
    //   0: aload_1
    //   1: invokestatic U : (Landroid/view/View;)Z
    //   4: ifne -> 8
    //   7: return
    //   8: aload_1
    //   9: invokevirtual getWidth : ()I
    //   12: ifle -> 461
    //   15: aload_1
    //   16: invokevirtual getHeight : ()I
    //   19: ifgt -> 25
    //   22: goto -> 461
    //   25: aload_1
    //   26: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   29: checkcast androidx/coordinatorlayout/widget/CoordinatorLayout$e
    //   32: astore #12
    //   34: aload #12
    //   36: invokevirtual f : ()Landroidx/coordinatorlayout/widget/CoordinatorLayout$Behavior;
    //   39: astore #11
    //   41: invokestatic acquireTempRect : ()Landroid/graphics/Rect;
    //   44: astore #9
    //   46: invokestatic acquireTempRect : ()Landroid/graphics/Rect;
    //   49: astore #10
    //   51: aload #10
    //   53: aload_1
    //   54: invokevirtual getLeft : ()I
    //   57: aload_1
    //   58: invokevirtual getTop : ()I
    //   61: aload_1
    //   62: invokevirtual getRight : ()I
    //   65: aload_1
    //   66: invokevirtual getBottom : ()I
    //   69: invokevirtual set : (IIII)V
    //   72: aload #11
    //   74: ifnull -> 158
    //   77: aload #11
    //   79: aload_0
    //   80: aload_1
    //   81: aload #9
    //   83: invokevirtual getInsetDodgeRect : (Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/graphics/Rect;)Z
    //   86: ifeq -> 158
    //   89: aload #10
    //   91: aload #9
    //   93: invokevirtual contains : (Landroid/graphics/Rect;)Z
    //   96: ifeq -> 102
    //   99: goto -> 165
    //   102: new java/lang/StringBuilder
    //   105: dup
    //   106: invokespecial <init> : ()V
    //   109: astore_1
    //   110: aload_1
    //   111: ldc_w 'Rect should be within the child's bounds. Rect:'
    //   114: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   117: pop
    //   118: aload_1
    //   119: aload #9
    //   121: invokevirtual toShortString : ()Ljava/lang/String;
    //   124: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   127: pop
    //   128: aload_1
    //   129: ldc_w ' | Bounds:'
    //   132: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   135: pop
    //   136: aload_1
    //   137: aload #10
    //   139: invokevirtual toShortString : ()Ljava/lang/String;
    //   142: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   145: pop
    //   146: new java/lang/IllegalArgumentException
    //   149: dup
    //   150: aload_1
    //   151: invokevirtual toString : ()Ljava/lang/String;
    //   154: invokespecial <init> : (Ljava/lang/String;)V
    //   157: athrow
    //   158: aload #9
    //   160: aload #10
    //   162: invokevirtual set : (Landroid/graphics/Rect;)V
    //   165: aload #10
    //   167: invokestatic releaseTempRect : (Landroid/graphics/Rect;)V
    //   170: aload #9
    //   172: invokevirtual isEmpty : ()Z
    //   175: ifeq -> 184
    //   178: aload #9
    //   180: invokestatic releaseTempRect : (Landroid/graphics/Rect;)V
    //   183: return
    //   184: aload #12
    //   186: getfield h : I
    //   189: iload_3
    //   190: invokestatic b : (II)I
    //   193: istore #6
    //   195: iconst_1
    //   196: istore #5
    //   198: iload #6
    //   200: bipush #48
    //   202: iand
    //   203: bipush #48
    //   205: if_icmpne -> 252
    //   208: aload #9
    //   210: getfield top : I
    //   213: aload #12
    //   215: getfield topMargin : I
    //   218: isub
    //   219: aload #12
    //   221: getfield j : I
    //   224: isub
    //   225: istore #4
    //   227: aload_2
    //   228: getfield top : I
    //   231: istore_3
    //   232: iload #4
    //   234: iload_3
    //   235: if_icmpge -> 252
    //   238: aload_0
    //   239: aload_1
    //   240: iload_3
    //   241: iload #4
    //   243: isub
    //   244: invokespecial setInsetOffsetY : (Landroid/view/View;I)V
    //   247: iconst_1
    //   248: istore_3
    //   249: goto -> 254
    //   252: iconst_0
    //   253: istore_3
    //   254: iload_3
    //   255: istore #4
    //   257: iload #6
    //   259: bipush #80
    //   261: iand
    //   262: bipush #80
    //   264: if_icmpne -> 320
    //   267: aload_0
    //   268: invokevirtual getHeight : ()I
    //   271: aload #9
    //   273: getfield bottom : I
    //   276: isub
    //   277: aload #12
    //   279: getfield bottomMargin : I
    //   282: isub
    //   283: aload #12
    //   285: getfield j : I
    //   288: iadd
    //   289: istore #7
    //   291: aload_2
    //   292: getfield bottom : I
    //   295: istore #8
    //   297: iload_3
    //   298: istore #4
    //   300: iload #7
    //   302: iload #8
    //   304: if_icmpge -> 320
    //   307: aload_0
    //   308: aload_1
    //   309: iload #7
    //   311: iload #8
    //   313: isub
    //   314: invokespecial setInsetOffsetY : (Landroid/view/View;I)V
    //   317: iconst_1
    //   318: istore #4
    //   320: iload #4
    //   322: ifne -> 331
    //   325: aload_0
    //   326: aload_1
    //   327: iconst_0
    //   328: invokespecial setInsetOffsetY : (Landroid/view/View;I)V
    //   331: iload #6
    //   333: iconst_3
    //   334: iand
    //   335: iconst_3
    //   336: if_icmpne -> 383
    //   339: aload #9
    //   341: getfield left : I
    //   344: aload #12
    //   346: getfield leftMargin : I
    //   349: isub
    //   350: aload #12
    //   352: getfield i : I
    //   355: isub
    //   356: istore #4
    //   358: aload_2
    //   359: getfield left : I
    //   362: istore_3
    //   363: iload #4
    //   365: iload_3
    //   366: if_icmpge -> 383
    //   369: aload_0
    //   370: aload_1
    //   371: iload_3
    //   372: iload #4
    //   374: isub
    //   375: invokespecial setInsetOffsetX : (Landroid/view/View;I)V
    //   378: iconst_1
    //   379: istore_3
    //   380: goto -> 385
    //   383: iconst_0
    //   384: istore_3
    //   385: iload #6
    //   387: iconst_5
    //   388: iand
    //   389: iconst_5
    //   390: if_icmpne -> 446
    //   393: aload_0
    //   394: invokevirtual getWidth : ()I
    //   397: aload #9
    //   399: getfield right : I
    //   402: isub
    //   403: aload #12
    //   405: getfield rightMargin : I
    //   408: isub
    //   409: aload #12
    //   411: getfield i : I
    //   414: iadd
    //   415: istore #4
    //   417: aload_2
    //   418: getfield right : I
    //   421: istore #6
    //   423: iload #4
    //   425: iload #6
    //   427: if_icmpge -> 446
    //   430: aload_0
    //   431: aload_1
    //   432: iload #4
    //   434: iload #6
    //   436: isub
    //   437: invokespecial setInsetOffsetX : (Landroid/view/View;I)V
    //   440: iload #5
    //   442: istore_3
    //   443: goto -> 446
    //   446: iload_3
    //   447: ifne -> 456
    //   450: aload_0
    //   451: aload_1
    //   452: iconst_0
    //   453: invokespecial setInsetOffsetX : (Landroid/view/View;I)V
    //   456: aload #9
    //   458: invokestatic releaseTempRect : (Landroid/graphics/Rect;)V
    //   461: return
  }
  
  public static Behavior parseBehavior(Context paramContext, AttributeSet paramAttributeSet, String paramString) {
    Map<Object, Object> map;
    String str;
    if (TextUtils.isEmpty(paramString))
      return null; 
    if (paramString.startsWith(".")) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(paramContext.getPackageName());
      stringBuilder.append(paramString);
      str = stringBuilder.toString();
    } else if (paramString.indexOf('.') >= 0) {
      str = paramString;
    } else {
      String str1 = WIDGET_PACKAGE_NAME;
      str = paramString;
      if (!TextUtils.isEmpty(str1)) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(str1);
        stringBuilder.append('.');
        stringBuilder.append(paramString);
        str = stringBuilder.toString();
      } 
    } 
    try {
      ThreadLocal<Map<String, Constructor<Behavior>>> threadLocal = sConstructors;
      Map<Object, Object> map1 = (Map)threadLocal.get();
      map = map1;
      if (map1 == null) {
        map = new HashMap<>();
        super();
        threadLocal.set(map);
      } 
    } catch (Exception exception) {}
    Constructor<?> constructor2 = (Constructor)map.get(str);
    Constructor<?> constructor1 = constructor2;
    if (constructor2 == null) {
      constructor1 = Class.forName(str, false, paramContext.getClassLoader()).getConstructor(CONSTRUCTOR_PARAMS);
      constructor1.setAccessible(true);
      map.put(str, constructor1);
    } 
    return (Behavior)constructor1.newInstance(new Object[] { paramContext, exception });
  }
  
  private boolean performEvent(Behavior paramBehavior, View paramView, MotionEvent paramMotionEvent, int paramInt) {
    if (paramInt != 0) {
      if (paramInt == 1)
        return paramBehavior.onTouchEvent(this, paramView, paramMotionEvent); 
      throw new IllegalArgumentException();
    } 
    return paramBehavior.onInterceptTouchEvent(this, paramView, paramMotionEvent);
  }
  
  private boolean performIntercept(MotionEvent paramMotionEvent, int paramInt) {
    boolean bool1;
    MotionEvent motionEvent;
    int j = paramMotionEvent.getActionMasked();
    List<View> list = this.mTempList1;
    getTopSortedChildren(list);
    int i = list.size();
    e e = null;
    byte b = 0;
    boolean bool2 = false;
    boolean bool3 = bool2;
    while (true) {
      e e1 = e;
      bool1 = bool2;
      if (b < i) {
        boolean bool4;
        boolean bool5;
        MotionEvent motionEvent2;
        View view = list.get(b);
        e e2 = (e)view.getLayoutParams();
        Behavior behavior = e2.f();
        if ((bool2 || bool3) && j != 0) {
          e2 = e;
          bool4 = bool2;
          bool5 = bool3;
          if (behavior != null) {
            e2 = e;
            if (e == null)
              motionEvent2 = obtainCancelEvent(paramMotionEvent); 
            performEvent(behavior, view, motionEvent2, paramInt);
            bool4 = bool2;
            bool5 = bool3;
          } 
        } else {
          e1 = e;
          bool1 = bool2;
          if (!bool3) {
            e1 = e;
            bool1 = bool2;
            if (!bool2) {
              e1 = e;
              bool1 = bool2;
              if (behavior != null) {
                bool2 = performEvent(behavior, view, paramMotionEvent, paramInt);
                e1 = e;
                bool1 = bool2;
                if (bool2) {
                  this.mBehaviorTouchView = view;
                  e1 = e;
                  bool1 = bool2;
                  if (j != 3) {
                    e1 = e;
                    bool1 = bool2;
                    if (j != 1) {
                      byte b1 = 0;
                      while (true) {
                        e1 = e;
                        bool1 = bool2;
                        if (b1 < b) {
                          View view1 = list.get(b1);
                          Behavior behavior1 = ((e)view1.getLayoutParams()).f();
                          e1 = e;
                          if (behavior1 != null) {
                            e1 = e;
                            if (e == null)
                              motionEvent = obtainCancelEvent(paramMotionEvent); 
                            performEvent(behavior1, view1, motionEvent, paramInt);
                          } 
                          b1++;
                          MotionEvent motionEvent3 = motionEvent;
                          continue;
                        } 
                        break;
                      } 
                    } 
                  } 
                } 
              } 
            } 
          } 
          bool2 = motionEvent2.c();
          bool3 = motionEvent2.i(this, view);
          if (bool3 && !bool2) {
            bool2 = true;
          } else {
            bool2 = false;
          } 
          motionEvent2 = motionEvent;
          bool4 = bool1;
          bool5 = bool2;
          if (bool3) {
            motionEvent2 = motionEvent;
            bool4 = bool1;
            bool5 = bool2;
            if (!bool2)
              break; 
          } 
        } 
        b++;
        MotionEvent motionEvent1 = motionEvent2;
        bool2 = bool4;
        bool3 = bool5;
        continue;
      } 
      break;
    } 
    list.clear();
    if (motionEvent != null)
      motionEvent.recycle(); 
    return bool1;
  }
  
  private void prepareChildren() {
    this.mDependencySortedChildren.clear();
    this.mChildDag.c();
    int i = getChildCount();
    for (byte b = 0; b < i; b++) {
      View view = getChildAt(b);
      e e = getResolvedLayoutParams(view);
      e.d(this, view);
      this.mChildDag.b(view);
      for (byte b1 = 0; b1 < i; b1++) {
        if (b1 != b) {
          View view1 = getChildAt(b1);
          if (e.b(this, view, view1)) {
            if (!this.mChildDag.d(view1))
              this.mChildDag.b(view1); 
            this.mChildDag.a(view1, view);
          } 
        } 
      } 
    } 
    this.mDependencySortedChildren.addAll(this.mChildDag.j());
    Collections.reverse(this.mDependencySortedChildren);
  }
  
  private static void releaseTempRect(Rect paramRect) {
    paramRect.setEmpty();
    sRectPool.b(paramRect);
  }
  
  private void resetTouchBehaviors() {
    View view = this.mBehaviorTouchView;
    if (view != null) {
      Behavior behavior = ((e)view.getLayoutParams()).f();
      if (behavior != null) {
        long l = SystemClock.uptimeMillis();
        MotionEvent motionEvent = MotionEvent.obtain(l, l, 3, 0.0F, 0.0F, 0);
        behavior.onTouchEvent(this, this.mBehaviorTouchView, motionEvent);
        motionEvent.recycle();
      } 
      this.mBehaviorTouchView = null;
    } 
    int i = getChildCount();
    for (byte b = 0; b < i; b++)
      ((e)getChildAt(b).getLayoutParams()).m(); 
    this.mDisallowInterceptReset = false;
  }
  
  private static int resolveAnchoredChildGravity(int paramInt) {
    int i = paramInt;
    if (paramInt == 0)
      i = 17; 
    return i;
  }
  
  private static int resolveGravity(int paramInt) {
    int i = paramInt;
    if ((paramInt & 0x7) == 0)
      i = paramInt | 0x800003; 
    paramInt = i;
    if ((i & 0x70) == 0)
      paramInt = i | 0x30; 
    return paramInt;
  }
  
  private static int resolveKeylineGravity(int paramInt) {
    int i = paramInt;
    if (paramInt == 0)
      i = 8388661; 
    return i;
  }
  
  private void setInsetOffsetX(View paramView, int paramInt) {
    e e = (e)paramView.getLayoutParams();
    int i = e.i;
    if (i != paramInt) {
      h0.a0(paramView, paramInt - i);
      e.i = paramInt;
    } 
  }
  
  private void setInsetOffsetY(View paramView, int paramInt) {
    e e = (e)paramView.getLayoutParams();
    int i = e.j;
    if (i != paramInt) {
      h0.b0(paramView, paramInt - i);
      e.j = paramInt;
    } 
  }
  
  private void setupForInsets() {
    if (h0.x((View)this)) {
      if (this.mApplyWindowInsetsListener == null)
        this.mApplyWindowInsetsListener = (O)new a(this); 
      h0.G0((View)this, this.mApplyWindowInsetsListener);
      setSystemUiVisibility(1280);
    } else {
      h0.G0((View)this, null);
    } 
  }
  
  public void addPreDrawListener() {
    if (this.mIsAttachedToWindow) {
      if (this.mOnPreDrawListener == null)
        this.mOnPreDrawListener = new f(this); 
      getViewTreeObserver().addOnPreDrawListener((ViewTreeObserver.OnPreDrawListener)this.mOnPreDrawListener);
    } 
    this.mNeedsPreDrawListener = true;
  }
  
  public boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    boolean bool;
    if (paramLayoutParams instanceof e && super.checkLayoutParams(paramLayoutParams)) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public void dispatchDependentViewsChanged(View paramView) {
    ArrayList<View> arrayList = this.mChildDag.h(paramView);
    if (arrayList != null && !arrayList.isEmpty())
      for (byte b = 0; b < arrayList.size(); b++) {
        View view = arrayList.get(b);
        Behavior behavior = ((e)view.getLayoutParams()).f();
        if (behavior != null)
          behavior.onDependentViewChanged(this, view, paramView); 
      }  
  }
  
  public boolean doViewsOverlap(View paramView1, View paramView2) {
    int i = paramView1.getVisibility();
    boolean bool = false;
    if (i == 0 && paramView2.getVisibility() == 0) {
      Rect rect2 = acquireTempRect();
      if (paramView1.getParent() != this) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      getChildRect(paramView1, bool1, rect2);
      Rect rect1 = acquireTempRect();
      if (paramView2.getParent() != this) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      getChildRect(paramView2, bool1, rect1);
      boolean bool1 = bool;
      try {
        if (rect2.left <= rect1.right) {
          bool1 = bool;
          if (rect2.top <= rect1.bottom) {
            bool1 = bool;
            if (rect2.right >= rect1.left) {
              i = rect2.bottom;
              int j = rect1.top;
              bool1 = bool;
              if (i >= j)
                bool1 = true; 
            } 
          } 
        } 
      } finally {}
      releaseTempRect(rect2);
      releaseTempRect(rect1);
      return bool1;
    } 
    return false;
  }
  
  public boolean drawChild(Canvas paramCanvas, View paramView, long paramLong) {
    e e = (e)paramView.getLayoutParams();
    Behavior behavior = e.a;
    if (behavior != null) {
      float f1 = behavior.getScrimOpacity(this, paramView);
      if (f1 > 0.0F) {
        if (this.mScrimPaint == null)
          this.mScrimPaint = new Paint(); 
        this.mScrimPaint.setColor(e.a.getScrimColor(this, paramView));
        this.mScrimPaint.setAlpha(clamp(Math.round(f1 * 255.0F), 0, 255));
        int i = paramCanvas.save();
        if (paramView.isOpaque())
          paramCanvas.clipRect(paramView.getLeft(), paramView.getTop(), paramView.getRight(), paramView.getBottom(), Region.Op.DIFFERENCE); 
        paramCanvas.drawRect(getPaddingLeft(), getPaddingTop(), (getWidth() - getPaddingRight()), (getHeight() - getPaddingBottom()), this.mScrimPaint);
        paramCanvas.restoreToCount(i);
      } 
    } 
    return super.drawChild(paramCanvas, paramView, paramLong);
  }
  
  public void drawableStateChanged() {
    boolean bool;
    super.drawableStateChanged();
    int[] arrayOfInt = getDrawableState();
    Drawable drawable = this.mStatusBarBackground;
    if (drawable != null && drawable.isStateful()) {
      bool = drawable.setState(arrayOfInt);
    } else {
      bool = false;
    } 
    if (bool)
      invalidate(); 
  }
  
  public void ensurePreDrawListener() {
    boolean bool1;
    int i = getChildCount();
    boolean bool2 = false;
    byte b = 0;
    while (true) {
      bool1 = bool2;
      if (b < i) {
        if (hasDependencies(getChildAt(b))) {
          bool1 = true;
          break;
        } 
        b++;
        continue;
      } 
      break;
    } 
    if (bool1 != this.mNeedsPreDrawListener)
      if (bool1) {
        addPreDrawListener();
      } else {
        removePreDrawListener();
      }  
  }
  
  public e generateDefaultLayoutParams() {
    return new e(-2, -2);
  }
  
  public e generateLayoutParams(AttributeSet paramAttributeSet) {
    return new e(getContext(), paramAttributeSet);
  }
  
  public e generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (paramLayoutParams instanceof e) ? new e((e)paramLayoutParams) : ((paramLayoutParams instanceof ViewGroup.MarginLayoutParams) ? new e((ViewGroup.MarginLayoutParams)paramLayoutParams) : new e(paramLayoutParams));
  }
  
  public void getChildRect(View paramView, boolean paramBoolean, Rect paramRect) {
    if (paramView.isLayoutRequested() || paramView.getVisibility() == 8) {
      paramRect.setEmpty();
      return;
    } 
    if (paramBoolean) {
      getDescendantRect(paramView, paramRect);
    } else {
      paramRect.set(paramView.getLeft(), paramView.getTop(), paramView.getRight(), paramView.getBottom());
    } 
  }
  
  public List<View> getDependencies(View paramView) {
    List<?> list2 = this.mChildDag.i(paramView);
    List<?> list1 = list2;
    if (list2 == null)
      list1 = Collections.emptyList(); 
    return (List)list1;
  }
  
  public final List<View> getDependencySortedChildren() {
    prepareChildren();
    return Collections.unmodifiableList(this.mDependencySortedChildren);
  }
  
  public List<View> getDependents(View paramView) {
    List<?> list2 = this.mChildDag.g(paramView);
    List<?> list1 = list2;
    if (list2 == null)
      list1 = Collections.emptyList(); 
    return (List)list1;
  }
  
  public void getDescendantRect(View paramView, Rect paramRect) {
    dbxyzptlk.R1.b.a((ViewGroup)this, paramView, paramRect);
  }
  
  public void getDesiredAnchoredChildRect(View paramView, int paramInt, Rect paramRect1, Rect paramRect2) {
    e e = (e)paramView.getLayoutParams();
    int j = paramView.getMeasuredWidth();
    int i = paramView.getMeasuredHeight();
    getDesiredAnchoredChildRectWithoutConstraints(paramInt, paramRect1, paramRect2, e, j, i);
    constrainChildRect(e, paramRect2, j, i);
  }
  
  public void getLastChildRect(View paramView, Rect paramRect) {
    paramRect.set(((e)paramView.getLayoutParams()).h());
  }
  
  public final J0 getLastWindowInsets() {
    return this.mLastInsets;
  }
  
  public int getNestedScrollAxes() {
    return this.mNestedScrollingParentHelper.a();
  }
  
  public e getResolvedLayoutParams(View paramView) {
    e e = (e)paramView.getLayoutParams();
    if (!e.b) {
      Behavior behavior;
      if (paramView instanceof b) {
        behavior = ((b)paramView).getBehavior();
        if (behavior == null)
          r0.d("CoordinatorLayout", "Attached behavior class is null"); 
        e.o(behavior);
        e.b = true;
      } else {
        c c;
        Class<?> clazz = behavior.getClass();
        behavior = null;
        while (clazz != null) {
          c c1 = clazz.<c>getAnnotation(c.class);
          c = c1;
          if (c1 == null) {
            clazz = clazz.getSuperclass();
            c = c1;
          } 
        } 
        if (c != null)
          try {
            e.o(c.value().getDeclaredConstructor(null).newInstance(null));
          } catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Default behavior class ");
            stringBuilder.append(c.value().getName());
            stringBuilder.append(" could not be instantiated. Did you forget a default constructor?");
            r0.e("CoordinatorLayout", stringBuilder.toString(), exception);
          }  
        e.b = true;
      } 
    } 
    return e;
  }
  
  public Drawable getStatusBarBackground() {
    return this.mStatusBarBackground;
  }
  
  public int getSuggestedMinimumHeight() {
    return Math.max(super.getSuggestedMinimumHeight(), getPaddingTop() + getPaddingBottom());
  }
  
  public int getSuggestedMinimumWidth() {
    return Math.max(super.getSuggestedMinimumWidth(), getPaddingLeft() + getPaddingRight());
  }
  
  public boolean isPointInChildBounds(View paramView, int paramInt1, int paramInt2) {
    Rect rect = acquireTempRect();
    getDescendantRect(paramView, rect);
    try {
      return rect.contains(paramInt1, paramInt2);
    } finally {
      releaseTempRect(rect);
    } 
  }
  
  public void offsetChildToAnchor(View paramView, int paramInt) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   4: checkcast androidx/coordinatorlayout/widget/CoordinatorLayout$e
    //   7: astore #8
    //   9: aload #8
    //   11: getfield k : Landroid/view/View;
    //   14: ifnull -> 211
    //   17: invokestatic acquireTempRect : ()Landroid/graphics/Rect;
    //   20: astore #10
    //   22: invokestatic acquireTempRect : ()Landroid/graphics/Rect;
    //   25: astore #6
    //   27: invokestatic acquireTempRect : ()Landroid/graphics/Rect;
    //   30: astore #7
    //   32: aload_0
    //   33: aload #8
    //   35: getfield k : Landroid/view/View;
    //   38: aload #10
    //   40: invokevirtual getDescendantRect : (Landroid/view/View;Landroid/graphics/Rect;)V
    //   43: iconst_0
    //   44: istore_3
    //   45: aload_0
    //   46: aload_1
    //   47: iconst_0
    //   48: aload #6
    //   50: invokevirtual getChildRect : (Landroid/view/View;ZLandroid/graphics/Rect;)V
    //   53: aload_1
    //   54: invokevirtual getMeasuredWidth : ()I
    //   57: istore #4
    //   59: aload_1
    //   60: invokevirtual getMeasuredHeight : ()I
    //   63: istore #5
    //   65: aload_0
    //   66: iload_2
    //   67: aload #10
    //   69: aload #7
    //   71: aload #8
    //   73: iload #4
    //   75: iload #5
    //   77: invokespecial getDesiredAnchoredChildRectWithoutConstraints : (ILandroid/graphics/Rect;Landroid/graphics/Rect;Landroidx/coordinatorlayout/widget/CoordinatorLayout$e;II)V
    //   80: aload #7
    //   82: getfield left : I
    //   85: aload #6
    //   87: getfield left : I
    //   90: if_icmpne -> 108
    //   93: iload_3
    //   94: istore_2
    //   95: aload #7
    //   97: getfield top : I
    //   100: aload #6
    //   102: getfield top : I
    //   105: if_icmpeq -> 110
    //   108: iconst_1
    //   109: istore_2
    //   110: aload_0
    //   111: aload #8
    //   113: aload #7
    //   115: iload #4
    //   117: iload #5
    //   119: invokespecial constrainChildRect : (Landroidx/coordinatorlayout/widget/CoordinatorLayout$e;Landroid/graphics/Rect;II)V
    //   122: aload #7
    //   124: getfield left : I
    //   127: aload #6
    //   129: getfield left : I
    //   132: isub
    //   133: istore #4
    //   135: aload #7
    //   137: getfield top : I
    //   140: aload #6
    //   142: getfield top : I
    //   145: isub
    //   146: istore_3
    //   147: iload #4
    //   149: ifeq -> 158
    //   152: aload_1
    //   153: iload #4
    //   155: invokestatic a0 : (Landroid/view/View;I)V
    //   158: iload_3
    //   159: ifeq -> 167
    //   162: aload_1
    //   163: iload_3
    //   164: invokestatic b0 : (Landroid/view/View;I)V
    //   167: iload_2
    //   168: ifeq -> 196
    //   171: aload #8
    //   173: invokevirtual f : ()Landroidx/coordinatorlayout/widget/CoordinatorLayout$Behavior;
    //   176: astore #9
    //   178: aload #9
    //   180: ifnull -> 196
    //   183: aload #9
    //   185: aload_0
    //   186: aload_1
    //   187: aload #8
    //   189: getfield k : Landroid/view/View;
    //   192: invokevirtual onDependentViewChanged : (Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/View;)Z
    //   195: pop
    //   196: aload #10
    //   198: invokestatic releaseTempRect : (Landroid/graphics/Rect;)V
    //   201: aload #6
    //   203: invokestatic releaseTempRect : (Landroid/graphics/Rect;)V
    //   206: aload #7
    //   208: invokestatic releaseTempRect : (Landroid/graphics/Rect;)V
    //   211: return
  }
  
  public void onAttachedToWindow() {
    super.onAttachedToWindow();
    resetTouchBehaviors();
    if (this.mNeedsPreDrawListener) {
      if (this.mOnPreDrawListener == null)
        this.mOnPreDrawListener = new f(this); 
      getViewTreeObserver().addOnPreDrawListener((ViewTreeObserver.OnPreDrawListener)this.mOnPreDrawListener);
    } 
    if (this.mLastInsets == null && h0.x((View)this))
      h0.n0((View)this); 
    this.mIsAttachedToWindow = true;
  }
  
  public final void onChildViewsChanged(int paramInt) {
    int i = h0.A((View)this);
    int j = this.mDependencySortedChildren.size();
    Rect rect1 = acquireTempRect();
    Rect rect2 = acquireTempRect();
    Rect rect3 = acquireTempRect();
    for (byte b = 0; b < j; b++) {
      View view = this.mDependencySortedChildren.get(b);
      e e = (e)view.getLayoutParams();
      if (paramInt == 0 && view.getVisibility() == 8)
        continue; 
      int k;
      for (k = 0; k < b; k++) {
        View view1 = this.mDependencySortedChildren.get(k);
        if (e.l == view1)
          offsetChildToAnchor(view, i); 
      } 
      getChildRect(view, true, rect2);
      if (e.g != 0 && !rect2.isEmpty()) {
        k = x.b(e.g, i);
        int m = k & 0x70;
        if (m != 48) {
          if (m == 80)
            rect1.bottom = Math.max(rect1.bottom, getHeight() - rect2.top); 
        } else {
          rect1.top = Math.max(rect1.top, rect2.bottom);
        } 
        k &= 0x7;
        if (k != 3) {
          if (k == 5)
            rect1.right = Math.max(rect1.right, getWidth() - rect2.left); 
        } else {
          rect1.left = Math.max(rect1.left, rect2.right);
        } 
      } 
      if (e.h != 0 && view.getVisibility() == 0)
        offsetChildByInset(view, rect1, i); 
      if (paramInt != 2) {
        getLastChildRect(view, rect3);
        if (rect3.equals(rect2))
          continue; 
        recordLastChildRect(view, rect2);
      } 
      for (k = b + 1; k < j; k++) {
        View view1 = this.mDependencySortedChildren.get(k);
        e e1 = (e)view1.getLayoutParams();
        Behavior behavior = e1.f();
        if (behavior != null && behavior.layoutDependsOn(this, view1, view))
          if (paramInt == 0 && e1.g()) {
            e1.k();
          } else {
            boolean bool;
            if (paramInt != 2) {
              bool = behavior.onDependentViewChanged(this, view1, view);
            } else {
              behavior.onDependentViewRemoved(this, view1, view);
              bool = true;
            } 
            if (paramInt == 1)
              e1.p(bool); 
          }  
      } 
      continue;
    } 
    releaseTempRect(rect1);
    releaseTempRect(rect2);
    releaseTempRect(rect3);
  }
  
  public void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    resetTouchBehaviors();
    if (this.mNeedsPreDrawListener && this.mOnPreDrawListener != null)
      getViewTreeObserver().removeOnPreDrawListener((ViewTreeObserver.OnPreDrawListener)this.mOnPreDrawListener); 
    View view = this.mNestedScrollingTarget;
    if (view != null)
      onStopNestedScroll(view); 
    this.mIsAttachedToWindow = false;
  }
  
  public void onDraw(Canvas paramCanvas) {
    super.onDraw(paramCanvas);
    if (this.mDrawStatusBarBackground && this.mStatusBarBackground != null) {
      boolean bool;
      J0 j0 = this.mLastInsets;
      if (j0 != null) {
        bool = j0.m();
      } else {
        bool = false;
      } 
      if (bool) {
        this.mStatusBarBackground.setBounds(0, 0, getWidth(), bool);
        this.mStatusBarBackground.draw(paramCanvas);
      } 
    } 
  }
  
  public boolean onInterceptTouchEvent(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getActionMasked();
    if (i == 0)
      resetTouchBehaviors(); 
    boolean bool = performIntercept(paramMotionEvent, 0);
    if (i == 1 || i == 3) {
      this.mBehaviorTouchView = null;
      resetTouchBehaviors();
    } 
    return bool;
  }
  
  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    paramInt3 = h0.A((View)this);
    paramInt2 = this.mDependencySortedChildren.size();
    for (paramInt1 = 0; paramInt1 < paramInt2; paramInt1++) {
      View view = this.mDependencySortedChildren.get(paramInt1);
      if (view.getVisibility() != 8) {
        Behavior behavior = ((e)view.getLayoutParams()).f();
        if (behavior == null || !behavior.onLayoutChild(this, view, paramInt3))
          onLayoutChild(view, paramInt3); 
      } 
    } 
  }
  
  public void onLayoutChild(View paramView, int paramInt) {
    e e = (e)paramView.getLayoutParams();
    if (!e.a()) {
      View view = e.k;
      if (view != null) {
        layoutChildWithAnchor(paramView, view, paramInt);
      } else {
        int i = e.e;
        if (i >= 0) {
          layoutChildWithKeyline(paramView, i, paramInt);
        } else {
          layoutChild(paramView, paramInt);
        } 
      } 
      return;
    } 
    throw new IllegalStateException("An anchor may not be changed after CoordinatorLayout measurement begins before layout is complete.");
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial prepareChildren : ()V
    //   4: aload_0
    //   5: invokevirtual ensurePreDrawListener : ()V
    //   8: aload_0
    //   9: invokevirtual getPaddingLeft : ()I
    //   12: istore #14
    //   14: aload_0
    //   15: invokevirtual getPaddingTop : ()I
    //   18: istore #16
    //   20: aload_0
    //   21: invokevirtual getPaddingRight : ()I
    //   24: istore #17
    //   26: aload_0
    //   27: invokevirtual getPaddingBottom : ()I
    //   30: istore #18
    //   32: aload_0
    //   33: invokestatic A : (Landroid/view/View;)I
    //   36: istore #15
    //   38: iload #15
    //   40: iconst_1
    //   41: if_icmpne -> 50
    //   44: iconst_1
    //   45: istore #4
    //   47: goto -> 53
    //   50: iconst_0
    //   51: istore #4
    //   53: iload_1
    //   54: invokestatic getMode : (I)I
    //   57: istore #22
    //   59: iload_1
    //   60: invokestatic getSize : (I)I
    //   63: istore #21
    //   65: iload_2
    //   66: invokestatic getMode : (I)I
    //   69: istore #20
    //   71: iload_2
    //   72: invokestatic getSize : (I)I
    //   75: istore #19
    //   77: aload_0
    //   78: invokevirtual getSuggestedMinimumWidth : ()I
    //   81: istore #10
    //   83: aload_0
    //   84: invokevirtual getSuggestedMinimumHeight : ()I
    //   87: istore #9
    //   89: aload_0
    //   90: getfield mLastInsets : Ldbxyzptlk/h2/J0;
    //   93: ifnull -> 109
    //   96: aload_0
    //   97: invokestatic x : (Landroid/view/View;)Z
    //   100: ifeq -> 109
    //   103: iconst_1
    //   104: istore #5
    //   106: goto -> 112
    //   109: iconst_0
    //   110: istore #5
    //   112: aload_0
    //   113: getfield mDependencySortedChildren : Ljava/util/List;
    //   116: invokeinterface size : ()I
    //   121: istore #6
    //   123: iconst_0
    //   124: istore #11
    //   126: iconst_0
    //   127: istore #7
    //   129: iload #14
    //   131: istore_3
    //   132: iload_3
    //   133: istore #8
    //   135: iload #7
    //   137: iload #6
    //   139: if_icmpge -> 512
    //   142: aload_0
    //   143: getfield mDependencySortedChildren : Ljava/util/List;
    //   146: iload #7
    //   148: invokeinterface get : (I)Ljava/lang/Object;
    //   153: checkcast android/view/View
    //   156: astore #25
    //   158: aload #25
    //   160: invokevirtual getVisibility : ()I
    //   163: bipush #8
    //   165: if_icmpne -> 171
    //   168: goto -> 503
    //   171: aload #25
    //   173: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   176: checkcast androidx/coordinatorlayout/widget/CoordinatorLayout$e
    //   179: astore #26
    //   181: aload #26
    //   183: getfield e : I
    //   186: istore_3
    //   187: iload_3
    //   188: iflt -> 294
    //   191: iload #22
    //   193: ifeq -> 294
    //   196: aload_0
    //   197: iload_3
    //   198: invokespecial getKeyline : (I)I
    //   201: istore_3
    //   202: aload #26
    //   204: getfield c : I
    //   207: invokestatic resolveKeylineGravity : (I)I
    //   210: iload #15
    //   212: invokestatic b : (II)I
    //   215: bipush #7
    //   217: iand
    //   218: istore #12
    //   220: iload #12
    //   222: iconst_3
    //   223: if_icmpne -> 231
    //   226: iload #4
    //   228: ifeq -> 242
    //   231: iload #12
    //   233: iconst_5
    //   234: if_icmpne -> 257
    //   237: iload #4
    //   239: ifeq -> 257
    //   242: iconst_0
    //   243: iload #21
    //   245: iload #17
    //   247: isub
    //   248: iload_3
    //   249: isub
    //   250: invokestatic max : (II)I
    //   253: istore_3
    //   254: goto -> 299
    //   257: iload #12
    //   259: iconst_5
    //   260: if_icmpne -> 268
    //   263: iload #4
    //   265: ifeq -> 279
    //   268: iload #12
    //   270: iconst_3
    //   271: if_icmpne -> 291
    //   274: iload #4
    //   276: ifeq -> 291
    //   279: iconst_0
    //   280: iload_3
    //   281: iload #8
    //   283: isub
    //   284: invokestatic max : (II)I
    //   287: istore_3
    //   288: goto -> 299
    //   291: goto -> 297
    //   294: goto -> 291
    //   297: iconst_0
    //   298: istore_3
    //   299: iload #5
    //   301: ifeq -> 381
    //   304: aload #25
    //   306: invokestatic x : (Landroid/view/View;)Z
    //   309: ifne -> 381
    //   312: aload_0
    //   313: getfield mLastInsets : Ldbxyzptlk/h2/J0;
    //   316: invokevirtual k : ()I
    //   319: istore #13
    //   321: aload_0
    //   322: getfield mLastInsets : Ldbxyzptlk/h2/J0;
    //   325: invokevirtual l : ()I
    //   328: istore #24
    //   330: aload_0
    //   331: getfield mLastInsets : Ldbxyzptlk/h2/J0;
    //   334: invokevirtual m : ()I
    //   337: istore #23
    //   339: aload_0
    //   340: getfield mLastInsets : Ldbxyzptlk/h2/J0;
    //   343: invokevirtual j : ()I
    //   346: istore #12
    //   348: iload #21
    //   350: iload #13
    //   352: iload #24
    //   354: iadd
    //   355: isub
    //   356: iload #22
    //   358: invokestatic makeMeasureSpec : (II)I
    //   361: istore #13
    //   363: iload #19
    //   365: iload #23
    //   367: iload #12
    //   369: iadd
    //   370: isub
    //   371: iload #20
    //   373: invokestatic makeMeasureSpec : (II)I
    //   376: istore #12
    //   378: goto -> 387
    //   381: iload_1
    //   382: istore #13
    //   384: iload_2
    //   385: istore #12
    //   387: aload #26
    //   389: invokevirtual f : ()Landroidx/coordinatorlayout/widget/CoordinatorLayout$Behavior;
    //   392: astore #27
    //   394: aload #27
    //   396: ifnull -> 419
    //   399: aload #27
    //   401: aload_0
    //   402: aload #25
    //   404: iload #13
    //   406: iload_3
    //   407: iload #12
    //   409: iconst_0
    //   410: invokevirtual onMeasureChild : (Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;IIII)Z
    //   413: ifne -> 431
    //   416: goto -> 419
    //   419: aload_0
    //   420: aload #25
    //   422: iload #13
    //   424: iload_3
    //   425: iload #12
    //   427: iconst_0
    //   428: invokevirtual onMeasureChild : (Landroid/view/View;IIII)V
    //   431: iload #10
    //   433: iload #14
    //   435: iload #17
    //   437: iadd
    //   438: aload #25
    //   440: invokevirtual getMeasuredWidth : ()I
    //   443: iadd
    //   444: aload #26
    //   446: getfield leftMargin : I
    //   449: iadd
    //   450: aload #26
    //   452: getfield rightMargin : I
    //   455: iadd
    //   456: invokestatic max : (II)I
    //   459: istore #10
    //   461: iload #9
    //   463: iload #16
    //   465: iload #18
    //   467: iadd
    //   468: aload #25
    //   470: invokevirtual getMeasuredHeight : ()I
    //   473: iadd
    //   474: aload #26
    //   476: getfield topMargin : I
    //   479: iadd
    //   480: aload #26
    //   482: getfield bottomMargin : I
    //   485: iadd
    //   486: invokestatic max : (II)I
    //   489: istore #9
    //   491: iload #11
    //   493: aload #25
    //   495: invokevirtual getMeasuredState : ()I
    //   498: invokestatic combineMeasuredStates : (II)I
    //   501: istore #11
    //   503: iinc #7, 1
    //   506: iload #8
    //   508: istore_3
    //   509: goto -> 132
    //   512: aload_0
    //   513: iload #10
    //   515: iload_1
    //   516: ldc_w -16777216
    //   519: iload #11
    //   521: iand
    //   522: invokestatic resolveSizeAndState : (III)I
    //   525: iload #9
    //   527: iload_2
    //   528: iload #11
    //   530: bipush #16
    //   532: ishl
    //   533: invokestatic resolveSizeAndState : (III)I
    //   536: invokevirtual setMeasuredDimension : (II)V
    //   539: return
  }
  
  public void onMeasureChild(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    measureChildWithMargins(paramView, paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public boolean onNestedFling(View paramView, float paramFloat1, float paramFloat2, boolean paramBoolean) {
    int i = getChildCount();
    byte b = 0;
    boolean bool;
    for (bool = false; b < i; bool = bool1) {
      boolean bool1;
      View view = getChildAt(b);
      if (view.getVisibility() == 8) {
        bool1 = bool;
      } else {
        e e = (e)view.getLayoutParams();
        if (!e.j(0)) {
          bool1 = bool;
        } else {
          Behavior behavior = e.f();
          bool1 = bool;
          if (behavior != null)
            bool1 = bool | behavior.onNestedFling(this, view, paramView, paramFloat1, paramFloat2, paramBoolean); 
        } 
      } 
      b++;
    } 
    if (bool)
      onChildViewsChanged(1); 
    return bool;
  }
  
  public boolean onNestedPreFling(View paramView, float paramFloat1, float paramFloat2) {
    int i = getChildCount();
    byte b = 0;
    boolean bool;
    for (bool = false; b < i; bool = bool1) {
      boolean bool1;
      View view = getChildAt(b);
      if (view.getVisibility() == 8) {
        bool1 = bool;
      } else {
        e e = (e)view.getLayoutParams();
        if (!e.j(0)) {
          bool1 = bool;
        } else {
          Behavior behavior = e.f();
          bool1 = bool;
          if (behavior != null)
            bool1 = bool | behavior.onNestedPreFling(this, view, paramView, paramFloat1, paramFloat2); 
        } 
      } 
      b++;
    } 
    return bool;
  }
  
  public void onNestedPreScroll(View paramView, int paramInt1, int paramInt2, int[] paramArrayOfint) {
    onNestedPreScroll(paramView, paramInt1, paramInt2, paramArrayOfint, 0);
  }
  
  public void onNestedPreScroll(View paramView, int paramInt1, int paramInt2, int[] paramArrayOfint, int paramInt3) {
    int m = getChildCount();
    boolean bool = false;
    byte b = 0;
    int i = b;
    int j = i;
    int k = i;
    while (b < m) {
      int n;
      View view = getChildAt(b);
      if (view.getVisibility() == 8) {
        n = k;
        i = j;
      } else {
        e e = (e)view.getLayoutParams();
        if (!e.j(paramInt3)) {
          n = k;
          i = j;
        } else {
          Behavior behavior = e.f();
          n = k;
          i = j;
          if (behavior != null) {
            int[] arrayOfInt = this.mBehaviorConsumed;
            arrayOfInt[0] = 0;
            arrayOfInt[1] = 0;
            behavior.onNestedPreScroll(this, view, paramView, paramInt1, paramInt2, arrayOfInt, paramInt3);
            if (paramInt1 > 0) {
              i = Math.max(k, this.mBehaviorConsumed[0]);
            } else {
              i = Math.min(k, this.mBehaviorConsumed[0]);
            } 
            n = i;
            if (paramInt2 > 0) {
              i = Math.max(j, this.mBehaviorConsumed[1]);
            } else {
              i = Math.min(j, this.mBehaviorConsumed[1]);
            } 
            bool = true;
          } 
        } 
      } 
      b++;
      k = n;
      j = i;
    } 
    paramArrayOfint[0] = k;
    paramArrayOfint[1] = j;
    if (bool)
      onChildViewsChanged(1); 
  }
  
  public void onNestedScroll(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    onNestedScroll(paramView, paramInt1, paramInt2, paramInt3, paramInt4, 0);
  }
  
  public void onNestedScroll(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    onNestedScroll(paramView, paramInt1, paramInt2, paramInt3, paramInt4, 0, this.mNestedScrollingV2ConsumedCompat);
  }
  
  public void onNestedScroll(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int[] paramArrayOfint) {
    int m = getChildCount();
    boolean bool = false;
    byte b = 0;
    int i = b;
    int j = i;
    int k = i;
    while (b < m) {
      int n;
      View view = getChildAt(b);
      if (view.getVisibility() == 8) {
        n = k;
        i = j;
      } else {
        e e = (e)view.getLayoutParams();
        if (!e.j(paramInt5)) {
          n = k;
          i = j;
        } else {
          Behavior behavior = e.f();
          n = k;
          i = j;
          if (behavior != null) {
            int[] arrayOfInt = this.mBehaviorConsumed;
            arrayOfInt[0] = 0;
            arrayOfInt[1] = 0;
            behavior.onNestedScroll(this, view, paramView, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, arrayOfInt);
            if (paramInt3 > 0) {
              i = Math.max(k, this.mBehaviorConsumed[0]);
            } else {
              i = Math.min(k, this.mBehaviorConsumed[0]);
            } 
            k = i;
            if (paramInt4 > 0) {
              i = Math.max(j, this.mBehaviorConsumed[1]);
            } else {
              i = Math.min(j, this.mBehaviorConsumed[1]);
            } 
            bool = true;
            n = k;
          } 
        } 
      } 
      b++;
      k = n;
      j = i;
    } 
    paramArrayOfint[0] = paramArrayOfint[0] + k;
    paramArrayOfint[1] = paramArrayOfint[1] + j;
    if (bool)
      onChildViewsChanged(1); 
  }
  
  public void onNestedScrollAccepted(View paramView1, View paramView2, int paramInt) {
    onNestedScrollAccepted(paramView1, paramView2, paramInt, 0);
  }
  
  public void onNestedScrollAccepted(View paramView1, View paramView2, int paramInt1, int paramInt2) {
    this.mNestedScrollingParentHelper.c(paramView1, paramView2, paramInt1, paramInt2);
    this.mNestedScrollingTarget = paramView2;
    int i = getChildCount();
    for (byte b = 0; b < i; b++) {
      View view = getChildAt(b);
      e e = (e)view.getLayoutParams();
      if (e.j(paramInt2)) {
        Behavior behavior = e.f();
        if (behavior != null)
          behavior.onNestedScrollAccepted(this, view, paramView1, paramView2, paramInt1, paramInt2); 
      } 
    } 
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable) {
    if (!(paramParcelable instanceof SavedState)) {
      super.onRestoreInstanceState(paramParcelable);
      return;
    } 
    SavedState savedState = (SavedState)paramParcelable;
    super.onRestoreInstanceState(savedState.getSuperState());
    SparseArray<Parcelable> sparseArray = savedState.f;
    int i = getChildCount();
    for (byte b = 0; b < i; b++) {
      View view = getChildAt(b);
      int j = view.getId();
      Behavior behavior = getResolvedLayoutParams(view).f();
      if (j != -1 && behavior != null) {
        Parcelable parcelable = (Parcelable)sparseArray.get(j);
        if (parcelable != null)
          behavior.onRestoreInstanceState(this, view, parcelable); 
      } 
    } 
  }
  
  public Parcelable onSaveInstanceState() {
    SavedState savedState = new SavedState(super.onSaveInstanceState());
    SparseArray<Parcelable> sparseArray = new SparseArray();
    int i = getChildCount();
    for (byte b = 0; b < i; b++) {
      View view = getChildAt(b);
      int j = view.getId();
      Behavior behavior = ((e)view.getLayoutParams()).f();
      if (j != -1 && behavior != null) {
        Parcelable parcelable = behavior.onSaveInstanceState(this, view);
        if (parcelable != null)
          sparseArray.append(j, parcelable); 
      } 
    } 
    savedState.f = sparseArray;
    return (Parcelable)savedState;
  }
  
  public boolean onStartNestedScroll(View paramView1, View paramView2, int paramInt) {
    return onStartNestedScroll(paramView1, paramView2, paramInt, 0);
  }
  
  public boolean onStartNestedScroll(View paramView1, View paramView2, int paramInt1, int paramInt2) {
    int i = getChildCount();
    byte b = 0;
    boolean bool = false;
    while (b < i) {
      View view = getChildAt(b);
      if (view.getVisibility() != 8) {
        e e = (e)view.getLayoutParams();
        Behavior behavior = e.f();
        if (behavior != null) {
          boolean bool1 = behavior.onStartNestedScroll(this, view, paramView1, paramView2, paramInt1, paramInt2);
          bool |= bool1;
          e.r(paramInt2, bool1);
        } else {
          e.r(paramInt2, false);
        } 
      } 
      b++;
    } 
    return bool;
  }
  
  public void onStopNestedScroll(View paramView) {
    onStopNestedScroll(paramView, 0);
  }
  
  public void onStopNestedScroll(View paramView, int paramInt) {
    this.mNestedScrollingParentHelper.e(paramView, paramInt);
    int i = getChildCount();
    for (byte b = 0; b < i; b++) {
      View view = getChildAt(b);
      e e = (e)view.getLayoutParams();
      if (e.j(paramInt)) {
        Behavior behavior = e.f();
        if (behavior != null)
          behavior.onStopNestedScroll(this, view, paramView, paramInt); 
        e.l(paramInt);
        e.k();
      } 
    } 
    this.mNestedScrollingTarget = null;
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    boolean bool1;
    boolean bool3;
    boolean bool4;
    int i = paramMotionEvent.getActionMasked();
    View view = this.mBehaviorTouchView;
    boolean bool2 = false;
    if (view != null) {
      Behavior behavior = ((e)view.getLayoutParams()).f();
      if (behavior != null) {
        bool3 = behavior.onTouchEvent(this, this.mBehaviorTouchView, paramMotionEvent);
        bool1 = bool2;
      } else {
        bool3 = false;
        bool1 = bool2;
      } 
    } else {
      bool4 = performIntercept(paramMotionEvent, 1);
      bool3 = bool4;
      bool1 = bool2;
      if (i != 0) {
        bool3 = bool4;
        bool1 = bool2;
        if (bool4) {
          bool1 = true;
          bool3 = bool4;
        } 
      } 
    } 
    if (this.mBehaviorTouchView == null || i == 3) {
      bool4 = bool3 | super.onTouchEvent(paramMotionEvent);
    } else {
      bool4 = bool3;
      if (bool1) {
        paramMotionEvent = obtainCancelEvent(paramMotionEvent);
        super.onTouchEvent(paramMotionEvent);
        paramMotionEvent.recycle();
        bool4 = bool3;
      } 
    } 
    if (i == 1 || i == 3) {
      this.mBehaviorTouchView = null;
      resetTouchBehaviors();
    } 
    return bool4;
  }
  
  public void recordLastChildRect(View paramView, Rect paramRect) {
    ((e)paramView.getLayoutParams()).q(paramRect);
  }
  
  public void removePreDrawListener() {
    if (this.mIsAttachedToWindow && this.mOnPreDrawListener != null)
      getViewTreeObserver().removeOnPreDrawListener((ViewTreeObserver.OnPreDrawListener)this.mOnPreDrawListener); 
    this.mNeedsPreDrawListener = false;
  }
  
  public boolean requestChildRectangleOnScreen(View paramView, Rect paramRect, boolean paramBoolean) {
    Behavior behavior = ((e)paramView.getLayoutParams()).f();
    return (behavior != null && behavior.onRequestChildRectangleOnScreen(this, paramView, paramRect, paramBoolean)) ? true : super.requestChildRectangleOnScreen(paramView, paramRect, paramBoolean);
  }
  
  public void requestDisallowInterceptTouchEvent(boolean paramBoolean) {
    super.requestDisallowInterceptTouchEvent(paramBoolean);
    if (paramBoolean && !this.mDisallowInterceptReset) {
      if (this.mBehaviorTouchView == null)
        cancelInterceptBehaviors(); 
      resetTouchBehaviors();
      this.mDisallowInterceptReset = true;
    } 
  }
  
  public void setFitsSystemWindows(boolean paramBoolean) {
    super.setFitsSystemWindows(paramBoolean);
    setupForInsets();
  }
  
  public void setOnHierarchyChangeListener(ViewGroup.OnHierarchyChangeListener paramOnHierarchyChangeListener) {
    this.mOnHierarchyChangeListener = paramOnHierarchyChangeListener;
  }
  
  public void setStatusBarBackground(Drawable paramDrawable) {
    Drawable drawable = this.mStatusBarBackground;
    if (drawable != paramDrawable) {
      Drawable drawable1 = null;
      if (drawable != null)
        drawable.setCallback(null); 
      if (paramDrawable != null)
        drawable1 = paramDrawable.mutate(); 
      this.mStatusBarBackground = drawable1;
      if (drawable1 != null) {
        boolean bool;
        if (drawable1.isStateful())
          this.mStatusBarBackground.setState(getDrawableState()); 
        dbxyzptlk.Z1.a.m(this.mStatusBarBackground, h0.A((View)this));
        paramDrawable = this.mStatusBarBackground;
        if (getVisibility() == 0) {
          bool = true;
        } else {
          bool = false;
        } 
        paramDrawable.setVisible(bool, false);
        this.mStatusBarBackground.setCallback((Drawable.Callback)this);
      } 
      h0.h0((View)this);
    } 
  }
  
  public void setStatusBarBackgroundColor(int paramInt) {
    setStatusBarBackground((Drawable)new ColorDrawable(paramInt));
  }
  
  public void setStatusBarBackgroundResource(int paramInt) {
    Drawable drawable;
    if (paramInt != 0) {
      drawable = dbxyzptlk.V1.b.e(getContext(), paramInt);
    } else {
      drawable = null;
    } 
    setStatusBarBackground(drawable);
  }
  
  public void setVisibility(int paramInt) {
    boolean bool;
    super.setVisibility(paramInt);
    if (paramInt == 0) {
      bool = true;
    } else {
      bool = false;
    } 
    Drawable drawable = this.mStatusBarBackground;
    if (drawable != null && drawable.isVisible() != bool)
      this.mStatusBarBackground.setVisible(bool, false); 
  }
  
  public final J0 setWindowInsets(J0 paramJ0) {
    J0 j0 = paramJ0;
    if (!dbxyzptlk.g2.d.a(this.mLastInsets, paramJ0)) {
      boolean bool2;
      this.mLastInsets = paramJ0;
      boolean bool3 = false;
      if (paramJ0 != null && paramJ0.m() > 0) {
        bool2 = true;
      } else {
        bool2 = false;
      } 
      this.mDrawStatusBarBackground = bool2;
      boolean bool1 = bool3;
      if (!bool2) {
        bool1 = bool3;
        if (getBackground() == null)
          bool1 = true; 
      } 
      setWillNotDraw(bool1);
      j0 = dispatchApplyWindowInsetsToBehaviors(paramJ0);
      requestLayout();
    } 
    return j0;
  }
  
  public boolean verifyDrawable(Drawable paramDrawable) {
    return (super.verifyDrawable(paramDrawable) || paramDrawable == this.mStatusBarBackground);
  }
  
  class CoordinatorLayout {}
  
  public static class SavedState extends AbsSavedState {
    public static final Parcelable.Creator<SavedState> CREATOR = (Parcelable.Creator<SavedState>)new a();
    
    public SparseArray<Parcelable> f;
    
    public SavedState(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      super(param1Parcel, param1ClassLoader);
      int i = param1Parcel.readInt();
      int[] arrayOfInt = new int[i];
      param1Parcel.readIntArray(arrayOfInt);
      Parcelable[] arrayOfParcelable = param1Parcel.readParcelableArray(param1ClassLoader);
      this.f = new SparseArray(i);
      for (byte b = 0; b < i; b++)
        this.f.append(arrayOfInt[b], arrayOfParcelable[b]); 
    }
    
    public SavedState(Parcelable param1Parcelable) {
      super(param1Parcelable);
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      byte b1;
      super.writeToParcel(param1Parcel, param1Int);
      SparseArray<Parcelable> sparseArray = this.f;
      byte b2 = 0;
      if (sparseArray != null) {
        b1 = sparseArray.size();
      } else {
        b1 = 0;
      } 
      param1Parcel.writeInt(b1);
      int[] arrayOfInt = new int[b1];
      Parcelable[] arrayOfParcelable = new Parcelable[b1];
      while (b2 < b1) {
        arrayOfInt[b2] = this.f.keyAt(b2);
        arrayOfParcelable[b2] = (Parcelable)this.f.valueAt(b2);
        b2++;
      } 
      param1Parcel.writeIntArray(arrayOfInt);
      param1Parcel.writeParcelableArray(arrayOfParcelable, param1Int);
    }
    
    public class a implements Parcelable.ClassLoaderCreator<SavedState> {
      public CoordinatorLayout.SavedState a(Parcel param2Parcel) {
        return new CoordinatorLayout.SavedState(param2Parcel, null);
      }
      
      public CoordinatorLayout.SavedState b(Parcel param2Parcel, ClassLoader param2ClassLoader) {
        return new CoordinatorLayout.SavedState(param2Parcel, param2ClassLoader);
      }
      
      public CoordinatorLayout.SavedState[] c(int param2Int) {
        return new CoordinatorLayout.SavedState[param2Int];
      }
    }
  }
  
  public class a implements Parcelable.ClassLoaderCreator<SavedState> {
    public CoordinatorLayout.SavedState a(Parcel param1Parcel) {
      return new CoordinatorLayout.SavedState(param1Parcel, null);
    }
    
    public CoordinatorLayout.SavedState b(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      return new CoordinatorLayout.SavedState(param1Parcel, param1ClassLoader);
    }
    
    public CoordinatorLayout.SavedState[] c(int param1Int) {
      return new CoordinatorLayout.SavedState[param1Int];
    }
  }
  
  public static interface b {
    CoordinatorLayout.Behavior getBehavior();
  }
  
  @Deprecated
  @Retention(RetentionPolicy.RUNTIME)
  public static @interface c {
    Class<? extends CoordinatorLayout.Behavior> value();
  }
  
  public class d implements ViewGroup.OnHierarchyChangeListener {
    public final CoordinatorLayout a;
    
    public d(CoordinatorLayout this$0) {}
    
    public void onChildViewAdded(View param1View1, View param1View2) {
      ViewGroup.OnHierarchyChangeListener onHierarchyChangeListener = this.a.mOnHierarchyChangeListener;
      if (onHierarchyChangeListener != null)
        onHierarchyChangeListener.onChildViewAdded(param1View1, param1View2); 
    }
    
    public void onChildViewRemoved(View param1View1, View param1View2) {
      this.a.onChildViewsChanged(2);
      ViewGroup.OnHierarchyChangeListener onHierarchyChangeListener = this.a.mOnHierarchyChangeListener;
      if (onHierarchyChangeListener != null)
        onHierarchyChangeListener.onChildViewRemoved(param1View1, param1View2); 
    }
  }
  
  public static class e extends ViewGroup.MarginLayoutParams {
    public CoordinatorLayout.Behavior a;
    
    public boolean b = false;
    
    public int c = 0;
    
    public int d = 0;
    
    public int e = -1;
    
    public int f = -1;
    
    public int g = 0;
    
    public int h = 0;
    
    public int i;
    
    public int j;
    
    public View k;
    
    public View l;
    
    public boolean m;
    
    public boolean n;
    
    public boolean o;
    
    public boolean p;
    
    public final Rect q = new Rect();
    
    public Object r;
    
    public e(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
    }
    
    public e(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
      TypedArray typedArray = param1Context.obtainStyledAttributes(param1AttributeSet, dbxyzptlk.Q1.c.CoordinatorLayout_Layout);
      this.c = typedArray.getInteger(dbxyzptlk.Q1.c.CoordinatorLayout_Layout_android_layout_gravity, 0);
      this.f = typedArray.getResourceId(dbxyzptlk.Q1.c.CoordinatorLayout_Layout_layout_anchor, -1);
      this.d = typedArray.getInteger(dbxyzptlk.Q1.c.CoordinatorLayout_Layout_layout_anchorGravity, 0);
      this.e = typedArray.getInteger(dbxyzptlk.Q1.c.CoordinatorLayout_Layout_layout_keyline, -1);
      this.g = typedArray.getInt(dbxyzptlk.Q1.c.CoordinatorLayout_Layout_layout_insetEdge, 0);
      this.h = typedArray.getInt(dbxyzptlk.Q1.c.CoordinatorLayout_Layout_layout_dodgeInsetEdges, 0);
      boolean bool = typedArray.hasValue(dbxyzptlk.Q1.c.CoordinatorLayout_Layout_layout_behavior);
      this.b = bool;
      if (bool)
        this.a = CoordinatorLayout.parseBehavior(param1Context, param1AttributeSet, typedArray.getString(dbxyzptlk.Q1.c.CoordinatorLayout_Layout_layout_behavior)); 
      typedArray.recycle();
      CoordinatorLayout.Behavior behavior = this.a;
      if (behavior != null)
        behavior.onAttachedToLayoutParams(this); 
    }
    
    public e(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public e(ViewGroup.MarginLayoutParams param1MarginLayoutParams) {
      super(param1MarginLayoutParams);
    }
    
    public e(e param1e) {
      super(param1e);
    }
    
    public boolean a() {
      boolean bool;
      if (this.k == null && this.f != -1) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    public boolean b(CoordinatorLayout param1CoordinatorLayout, View param1View1, View param1View2) {
      if (param1View2 != this.l && !s(param1View2, h0.A((View)param1CoordinatorLayout))) {
        CoordinatorLayout.Behavior behavior = this.a;
        return (behavior != null && behavior.layoutDependsOn(param1CoordinatorLayout, param1View1, param1View2));
      } 
      return true;
    }
    
    public boolean c() {
      if (this.a == null)
        this.m = false; 
      return this.m;
    }
    
    public View d(CoordinatorLayout param1CoordinatorLayout, View param1View) {
      if (this.f == -1) {
        this.l = null;
        this.k = null;
        return null;
      } 
      if (this.k == null || !t(param1View, param1CoordinatorLayout))
        n(param1View, param1CoordinatorLayout); 
      return this.k;
    }
    
    public int e() {
      return this.f;
    }
    
    public CoordinatorLayout.Behavior f() {
      return this.a;
    }
    
    public boolean g() {
      return this.p;
    }
    
    public Rect h() {
      return this.q;
    }
    
    public boolean i(CoordinatorLayout param1CoordinatorLayout, View param1View) {
      boolean bool1;
      boolean bool2 = this.m;
      if (bool2)
        return true; 
      CoordinatorLayout.Behavior behavior = this.a;
      if (behavior != null) {
        bool1 = behavior.blocksInteractionBelow(param1CoordinatorLayout, param1View);
      } else {
        bool1 = false;
      } 
      bool1 |= bool2;
      this.m = bool1;
      return bool1;
    }
    
    public boolean j(int param1Int) {
      return (param1Int != 0) ? ((param1Int != 1) ? false : this.o) : this.n;
    }
    
    public void k() {
      this.p = false;
    }
    
    public void l(int param1Int) {
      r(param1Int, false);
    }
    
    public void m() {
      this.m = false;
    }
    
    public final void n(View param1View, CoordinatorLayout param1CoordinatorLayout) {
      View view = param1CoordinatorLayout.findViewById(this.f);
      this.k = view;
      if (view != null) {
        if (view == param1CoordinatorLayout) {
          if (param1CoordinatorLayout.isInEditMode()) {
            this.l = null;
            this.k = null;
            return;
          } 
          throw new IllegalStateException("View can not be anchored to the the parent CoordinatorLayout");
        } 
        for (ViewParent viewParent = view.getParent(); viewParent != param1CoordinatorLayout && viewParent != null; viewParent = viewParent.getParent()) {
          if (viewParent == param1View) {
            if (param1CoordinatorLayout.isInEditMode()) {
              this.l = null;
              this.k = null;
              return;
            } 
            throw new IllegalStateException("Anchor must not be a descendant of the anchored view");
          } 
          if (viewParent instanceof View)
            view = (View)viewParent; 
        } 
        this.l = view;
        return;
      } 
      if (param1CoordinatorLayout.isInEditMode()) {
        this.l = null;
        this.k = null;
        return;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Could not find CoordinatorLayout descendant view with id ");
      stringBuilder.append(param1CoordinatorLayout.getResources().getResourceName(this.f));
      stringBuilder.append(" to anchor view ");
      stringBuilder.append(param1View);
      throw new IllegalStateException(stringBuilder.toString());
    }
    
    public void o(CoordinatorLayout.Behavior param1Behavior) {
      CoordinatorLayout.Behavior behavior = this.a;
      if (behavior != param1Behavior) {
        if (behavior != null)
          behavior.onDetachedFromLayoutParams(); 
        this.a = param1Behavior;
        this.r = null;
        this.b = true;
        if (param1Behavior != null)
          param1Behavior.onAttachedToLayoutParams(this); 
      } 
    }
    
    public void p(boolean param1Boolean) {
      this.p = param1Boolean;
    }
    
    public void q(Rect param1Rect) {
      this.q.set(param1Rect);
    }
    
    public void r(int param1Int, boolean param1Boolean) {
      if (param1Int != 0) {
        if (param1Int == 1)
          this.o = param1Boolean; 
      } else {
        this.n = param1Boolean;
      } 
    }
    
    public final boolean s(View param1View, int param1Int) {
      boolean bool;
      int i = x.b(((e)param1View.getLayoutParams()).g, param1Int);
      if (i != 0 && (x.b(this.h, param1Int) & i) == i) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    public final boolean t(View param1View, CoordinatorLayout param1CoordinatorLayout) {
      if (this.k.getId() != this.f)
        return false; 
      View view = this.k;
      for (ViewParent viewParent = view.getParent(); viewParent != param1CoordinatorLayout; viewParent = viewParent.getParent()) {
        if (viewParent == null || viewParent == param1View) {
          this.l = null;
          this.k = null;
          return false;
        } 
        if (viewParent instanceof View)
          view = (View)viewParent; 
      } 
      this.l = view;
      return true;
    }
  }
  
  class CoordinatorLayout {}
  
  public static class g implements Comparator<View> {
    public int a(View param1View1, View param1View2) {
      float f2 = h0.O(param1View1);
      float f1 = h0.O(param1View2);
      return (f2 > f1) ? -1 : ((f2 < f1) ? 1 : 0);
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\coordinatorlayout\widget\CoordinatorLayout.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */