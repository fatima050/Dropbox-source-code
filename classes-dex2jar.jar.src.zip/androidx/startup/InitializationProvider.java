package androidx.startup;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import dbxyzptlk.O4.a;
import io.sentry.android.core.performance.e;

public class InitializationProvider extends ContentProvider {
  public final int delete(Uri paramUri, String paramString, String[] paramArrayOfString) {
    throw new IllegalStateException("Not allowed.");
  }
  
  public final String getType(Uri paramUri) {
    throw new IllegalStateException("Not allowed.");
  }
  
  public final Uri insert(Uri paramUri, ContentValues paramContentValues) {
    throw new IllegalStateException("Not allowed.");
  }
  
  public final boolean onCreate() {
    e.t(this);
    Context context = getContext();
    if (context != null) {
      if (context.getApplicationContext() != null)
        a.e(context).a(); 
      e.u(this);
      return true;
    } 
    StartupException startupException = new StartupException("Context cannot be null");
    e.u(this);
    throw startupException;
  }
  
  public final Cursor query(Uri paramUri, String[] paramArrayOfString1, String paramString1, String[] paramArrayOfString2, String paramString2) {
    throw new IllegalStateException("Not allowed.");
  }
  
  public final int update(Uri paramUri, ContentValues paramContentValues, String paramString, String[] paramArrayOfString) {
    throw new IllegalStateException("Not allowed.");
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\startup\InitializationProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */