package androidx.emoji2.text;

import android.content.Context;
import androidx.lifecycle.DefaultLifecycleObserver;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.ProcessLifecycleInitializer;
import androidx.lifecycle.f;
import dbxyzptlk.F2.d;
import dbxyzptlk.O4.b;
import dbxyzptlk.U2.h;
import dbxyzptlk.d2.p;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ThreadPoolExecutor;

public class EmojiCompatInitializer implements b<Boolean> {
  public Boolean b(Context paramContext) {
    c.j(new a(paramContext));
    c(paramContext);
    return Boolean.TRUE;
  }
  
  public void c(Context paramContext) {
    f f = ((LifecycleOwner)dbxyzptlk.O4.a.e(paramContext).f(ProcessLifecycleInitializer.class)).getLifecycle();
    f.a((h)new DefaultLifecycleObserver(this, f) {
          public final f a;
          
          public final EmojiCompatInitializer b;
          
          public void onResume(LifecycleOwner param1LifecycleOwner) {
            this.b.d();
            this.a.d((h)this);
          }
        });
  }
  
  public void d() {
    dbxyzptlk.F2.c.d().postDelayed(new c(), 500L);
  }
  
  public List<Class<? extends b<?>>> dependencies() {
    return (List)Collections.singletonList(ProcessLifecycleInitializer.class);
  }
  
  public static class a extends c.c {
    public a(Context param1Context) {
      super(new EmojiCompatInitializer.b(param1Context));
      b(1);
    }
  }
  
  public static class b implements c.h {
    public final Context a;
    
    public b(Context param1Context) {
      this.a = param1Context.getApplicationContext();
    }
    
    public void a(c.i param1i) {
      ThreadPoolExecutor threadPoolExecutor = dbxyzptlk.F2.c.b("EmojiCompatInitializer");
      threadPoolExecutor.execute((Runnable)new d(this, param1i, threadPoolExecutor));
    }
    
    public void c(c.i param1i, ThreadPoolExecutor param1ThreadPoolExecutor) {
      try {
      
      } finally {
        Exception exception = null;
        param1i.a(exception);
      } 
    }
    
    public class a extends c.i {
      public final c.i a;
      
      public final ThreadPoolExecutor b;
      
      public final EmojiCompatInitializer.b c;
      
      public a(EmojiCompatInitializer.b this$0, c.i param2i, ThreadPoolExecutor param2ThreadPoolExecutor) {}
      
      public void a(Throwable param2Throwable) {
        try {
          this.a.a(param2Throwable);
          return;
        } finally {
          this.b.shutdown();
        } 
      }
      
      public void b(f param2f) {
        try {
          this.a.b(param2f);
          return;
        } finally {
          this.b.shutdown();
        } 
      }
    }
  }
  
  public class a extends c.i {
    public final c.i a;
    
    public final ThreadPoolExecutor b;
    
    public final EmojiCompatInitializer.b c;
    
    public a(EmojiCompatInitializer this$0, c.i param1i, ThreadPoolExecutor param1ThreadPoolExecutor) {}
    
    public void a(Throwable param1Throwable) {
      try {
        this.a.a(param1Throwable);
        return;
      } finally {
        this.b.shutdown();
      } 
    }
    
    public void b(f param1f) {
      try {
        this.a.b(param1f);
        return;
      } finally {
        this.b.shutdown();
      } 
    }
  }
  
  public static class c implements Runnable {
    public void run() {
      try {
        p.a("EmojiCompat.EmojiCompatInitializer.run");
        if (c.k())
          c.c().n(); 
      } finally {
        Exception exception;
      } 
      p.b();
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\emoji2\text\EmojiCompatInitializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */