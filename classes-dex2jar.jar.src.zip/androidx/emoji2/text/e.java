package androidx.emoji2.text;

import android.content.Context;
import android.content.pm.PackageManager;
import android.database.ContentObserver;
import android.graphics.Typeface;
import android.os.Handler;
import dbxyzptlk.F2.c;
import dbxyzptlk.F2.g;
import dbxyzptlk.Y1.n;
import dbxyzptlk.d2.p;
import dbxyzptlk.e2.g;
import dbxyzptlk.g2.i;
import java.nio.ByteBuffer;
import java.util.concurrent.Executor;
import java.util.concurrent.ThreadPoolExecutor;

public class e extends c.c {
  public static final a k = new a();
  
  public e(Context paramContext, dbxyzptlk.e2.e parame) {
    super(new b(paramContext, parame, k));
  }
  
  public e c(Executor paramExecutor) {
    ((b)a()).f(paramExecutor);
    return this;
  }
  
  public static class a {
    public Typeface a(Context param1Context, g.b param1b) throws PackageManager.NameNotFoundException {
      return g.a(param1Context, null, new g.b[] { param1b });
    }
    
    public g.a b(Context param1Context, dbxyzptlk.e2.e param1e) throws PackageManager.NameNotFoundException {
      return g.b(param1Context, null, param1e);
    }
    
    public void c(Context param1Context, ContentObserver param1ContentObserver) {
      param1Context.getContentResolver().unregisterContentObserver(param1ContentObserver);
    }
  }
  
  public static class b implements c.h {
    public final Context a;
    
    public final dbxyzptlk.e2.e b;
    
    public final e.a c;
    
    public final Object d = new Object();
    
    public Handler e;
    
    public Executor f;
    
    public ThreadPoolExecutor g;
    
    public c.i h;
    
    public ContentObserver i;
    
    public Runnable j;
    
    public b(Context param1Context, dbxyzptlk.e2.e param1e, e.a param1a) {
      i.h(param1Context, "Context cannot be null");
      i.h(param1e, "FontRequest cannot be null");
      this.a = param1Context.getApplicationContext();
      this.b = param1e;
      this.c = param1a;
    }
    
    public void a(c.i param1i) {
      i.h(param1i, "LoaderCallback cannot be null");
      synchronized (this.d) {
        this.h = param1i;
        d();
        return;
      } 
    }
    
    public final void b() {
      Object object = this.d;
      /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
      try {
        this.h = null;
        ContentObserver contentObserver = this.i;
        if (contentObserver != null) {
          this.c.c(this.a, contentObserver);
          this.i = null;
        } 
      } finally {
        Exception exception;
      } 
      Handler handler = this.e;
      if (handler != null)
        handler.removeCallbacks(this.j); 
      this.e = null;
      ThreadPoolExecutor threadPoolExecutor = this.g;
      if (threadPoolExecutor != null)
        threadPoolExecutor.shutdown(); 
      this.f = null;
      this.g = null;
      /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
    }
    
    public void c() {
      int j;
      Exception exception;
      Object object = this.d;
      /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
      try {
        if (this.h == null) {
          /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
          return;
        } 
      } finally {}
      /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
      try {
        g.b b1 = e();
        j = b1.b();
        if (j == 2)
          synchronized (this.d) {
          
          }  
      } finally {}
      if (j == 0) {
        try {
          p.a("EmojiCompat.FontRequestEmojiCompatConfig.buildTypeface");
          object = this.c.a(this.a, (g.b)exception);
          ByteBuffer byteBuffer = n.e(this.a, null, exception.d());
        } finally {
          p.b();
        } 
      } else {
        object = new RuntimeException();
        StringBuilder stringBuilder = new StringBuilder();
        this();
        stringBuilder.append("fetchFonts result is not OK. (");
        stringBuilder.append(j);
        stringBuilder.append(")");
        super(stringBuilder.toString());
        throw object;
      } 
    }
    
    public void d() {
      Object object = this.d;
      /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
      try {
        if (this.h == null) {
          /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
          return;
        } 
      } finally {
        Exception exception;
      } 
      if (this.f == null) {
        ThreadPoolExecutor threadPoolExecutor = c.b("emojiCompat");
        this.g = threadPoolExecutor;
        this.f = threadPoolExecutor;
      } 
      Executor executor = this.f;
      g g = new g();
      this(this);
      executor.execute((Runnable)g);
      /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
    }
    
    public final g.b e() {
      try {
        g.b[] arrayOfB;
        g.a a1 = this.c.b(this.a, this.b);
        if (a1.c() == 0) {
          arrayOfB = a1.b();
          if (arrayOfB != null && arrayOfB.length != 0)
            return arrayOfB[0]; 
          throw new RuntimeException("fetchFonts failed (empty result)");
        } 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("fetchFonts failed (");
        stringBuilder.append(arrayOfB.c());
        stringBuilder.append(")");
        throw new RuntimeException(stringBuilder.toString());
      } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
        throw new RuntimeException("provider not found", nameNotFoundException);
      } 
    }
    
    public void f(Executor param1Executor) {
      synchronized (this.d) {
        this.f = param1Executor;
        return;
      } 
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\emoji2\text\e.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */