package androidx.emoji2.text;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.view.KeyEvent;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import dbxyzptlk.F2.k;
import java.util.ArrayList;
import java.util.Set;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public class c {
  public static final Object o = new Object();
  
  public static final Object p = new Object();
  
  public static volatile c q;
  
  public final ReadWriteLock a = new ReentrantReadWriteLock();
  
  public final Set<f> b;
  
  public volatile int c = 3;
  
  public final Handler d;
  
  public final b e;
  
  public final h f;
  
  public final j g;
  
  public final boolean h;
  
  public final boolean i;
  
  public final int[] j;
  
  public final boolean k;
  
  public final int l;
  
  public final int m;
  
  public final e n;
  
  public c(c paramc) {
    this.h = paramc.c;
    this.i = paramc.d;
    this.j = paramc.e;
    this.k = paramc.g;
    this.l = paramc.h;
    this.f = paramc.a;
    this.m = paramc.i;
    this.n = paramc.j;
    this.d = new Handler(Looper.getMainLooper());
    dbxyzptlk.V.b<f> b1 = new dbxyzptlk.V.b();
    this.b = (Set<f>)b1;
    j j1 = paramc.b;
    if (j1 == null)
      j1 = new d(); 
    this.g = j1;
    Set<f> set = paramc.f;
    if (set != null && !set.isEmpty())
      b1.addAll(paramc.f); 
    this.e = new a(this);
    o();
  }
  
  public static c c() {
    synchronized (o) {
      boolean bool;
      c c1 = q;
      if (c1 != null) {
        bool = true;
      } else {
        bool = false;
      } 
      dbxyzptlk.g2.i.j(bool, "EmojiCompat is not initialized.\n\nYou must initialize EmojiCompat prior to referencing the EmojiCompat instance.\n\nThe most likely cause of this error is disabling the EmojiCompatInitializer\neither explicitly in AndroidManifest.xml, or by including\nandroidx.emoji2:emoji2-bundled.\n\nAutomatic initialization is typically performed by EmojiCompatInitializer. If\nyou are not expecting to initialize EmojiCompat manually in your application,\nplease check to ensure it has not been removed from your APK's manifest. You can\ndo this in Android Studio using Build > Analyze APK.\n\nIn the APK Analyzer, ensure that the startup entry for\nEmojiCompatInitializer and InitializationProvider is present in\n AndroidManifest.xml. If it is missing or contains tools:node=\"remove\", and you\nintend to use automatic configuration, verify:\n\n  1. Your application does not include emoji2-bundled\n  2. All modules do not contain an exclusion manifest rule for\n     EmojiCompatInitializer or InitializationProvider. For more information\n     about manifest exclusions see the documentation for the androidx startup\n     library.\n\nIf you intend to use emoji2-bundled, please call EmojiCompat.init. You can\nlearn more in the documentation for BundledEmojiCompatConfig.\n\nIf you intended to perform manual configuration, it is recommended that you call\nEmojiCompat.init immediately on application startup.\n\nIf you still cannot resolve this issue, please open a bug with your specific\nconfiguration to help improve error message.");
      return c1;
    } 
  }
  
  public static boolean h(InputConnection paramInputConnection, Editable paramEditable, int paramInt1, int paramInt2, boolean paramBoolean) {
    return d.d(paramInputConnection, paramEditable, paramInt1, paramInt2, paramBoolean);
  }
  
  public static boolean i(Editable paramEditable, int paramInt, KeyEvent paramKeyEvent) {
    return d.e(paramEditable, paramInt, paramKeyEvent);
  }
  
  public static c j(c paramc) {
    c c2 = q;
    c c1 = c2;
    if (c2 == null) {
      Object object = o;
      /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
      try {
        c2 = q;
        c1 = c2;
        if (c2 == null) {
          c1 = new c();
          this(paramc);
          q = c1;
        } 
      } finally {}
      /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
    } 
    return c1;
  }
  
  public static boolean k() {
    boolean bool;
    if (q != null) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public int d(CharSequence paramCharSequence, int paramInt) {
    return this.e.a(paramCharSequence, paramInt);
  }
  
  public int e() {
    return this.l;
  }
  
  public int f(CharSequence paramCharSequence, int paramInt) {
    return this.e.b(paramCharSequence, paramInt);
  }
  
  public int g() {
    this.a.readLock().lock();
    try {
      return this.c;
    } finally {
      this.a.readLock().unlock();
    } 
  }
  
  public boolean l() {
    return this.k;
  }
  
  public final boolean m() {
    int i = g();
    boolean bool = true;
    if (i != 1)
      bool = false; 
    return bool;
  }
  
  public void n() {
    int i = this.m;
    boolean bool = true;
    if (i != 1)
      bool = false; 
    dbxyzptlk.g2.i.j(bool, "Set metadataLoadStrategy to LOAD_STRATEGY_MANUAL to execute manual loading");
    if (m())
      return; 
    this.a.writeLock().lock();
    try {
      i = this.c;
      if (i == 0)
        return; 
      this.c = 0;
      this.a.writeLock().unlock();
      return;
    } finally {
      this.a.writeLock().unlock();
    } 
  }
  
  public final void o() {
    this.a.writeLock().lock();
    try {
      if (this.m == 0)
        this.c = 0; 
    } finally {
      Exception exception;
    } 
    this.a.writeLock().unlock();
    if (g() == 0)
      this.e.c(); 
  }
  
  public void p(Throwable paramThrowable) {
    ArrayList<f> arrayList = new ArrayList();
    this.a.writeLock().lock();
    try {
      this.c = 2;
      arrayList.addAll(this.b);
      this.b.clear();
      this.a.writeLock().unlock();
      return;
    } finally {
      this.a.writeLock().unlock();
    } 
  }
  
  public void q() {
    null = new ArrayList();
    this.a.writeLock().lock();
    try {
      this.c = 1;
      null.addAll(this.b);
      this.b.clear();
      this.a.writeLock().unlock();
      return;
    } finally {
      this.a.writeLock().unlock();
    } 
  }
  
  public CharSequence r(CharSequence paramCharSequence) {
    int i;
    if (paramCharSequence == null) {
      i = 0;
    } else {
      i = paramCharSequence.length();
    } 
    return s(paramCharSequence, 0, i);
  }
  
  public CharSequence s(CharSequence paramCharSequence, int paramInt1, int paramInt2) {
    return t(paramCharSequence, paramInt1, paramInt2, 2147483647);
  }
  
  public CharSequence t(CharSequence paramCharSequence, int paramInt1, int paramInt2, int paramInt3) {
    return u(paramCharSequence, paramInt1, paramInt2, paramInt3, 0);
  }
  
  public CharSequence u(CharSequence paramCharSequence, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    boolean bool1;
    dbxyzptlk.g2.i.j(m(), "Not initialized yet");
    dbxyzptlk.g2.i.e(paramInt1, "start cannot be negative");
    dbxyzptlk.g2.i.e(paramInt2, "end cannot be negative");
    dbxyzptlk.g2.i.e(paramInt3, "maxEmojiCount cannot be negative");
    boolean bool2 = false;
    if (paramInt1 <= paramInt2) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    dbxyzptlk.g2.i.b(bool1, "start should be <= than end");
    if (paramCharSequence == null)
      return null; 
    if (paramInt1 <= paramCharSequence.length()) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    dbxyzptlk.g2.i.b(bool1, "start should be < than charSequence length");
    if (paramInt2 <= paramCharSequence.length()) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    dbxyzptlk.g2.i.b(bool1, "end should be < than charSequence length");
    CharSequence charSequence = paramCharSequence;
    if (paramCharSequence.length() != 0)
      if (paramInt1 == paramInt2) {
        charSequence = paramCharSequence;
      } else {
        if (paramInt4 != 1) {
          bool1 = bool2;
          if (paramInt4 != 2)
            bool1 = this.h; 
        } else {
          bool1 = true;
        } 
        charSequence = this.e.d(paramCharSequence, paramInt1, paramInt2, paramInt3, bool1);
      }  
    return charSequence;
  }
  
  public void v(f paramf) {
    dbxyzptlk.g2.i.h(paramf, "initCallback cannot be null");
    this.a.writeLock().lock();
    try {
      if (this.c == 1 || this.c == 2) {
        Handler handler = this.d;
        g g = new g();
        this(paramf, this.c);
        handler.post((Runnable)g);
      } else {
        this.b.add(paramf);
      } 
    } finally {}
    this.a.writeLock().unlock();
  }
  
  public void w(f paramf) {
    dbxyzptlk.g2.i.h(paramf, "initCallback cannot be null");
    this.a.writeLock().lock();
    try {
      this.b.remove(paramf);
      return;
    } finally {
      this.a.writeLock().unlock();
    } 
  }
  
  public void x(EditorInfo paramEditorInfo) {
    if (m() && paramEditorInfo != null) {
      if (paramEditorInfo.extras == null)
        paramEditorInfo.extras = new Bundle(); 
      this.e.e(paramEditorInfo);
    } 
  }
  
  public static final class a extends b {
    public volatile d b;
    
    public volatile f c;
    
    public a(c param1c) {
      super(param1c);
    }
    
    public int a(CharSequence param1CharSequence, int param1Int) {
      return this.b.b(param1CharSequence, param1Int);
    }
    
    public int b(CharSequence param1CharSequence, int param1Int) {
      return this.b.c(param1CharSequence, param1Int);
    }
    
    public void c() {
      try {
        a a1 = new a();
        this(this);
        this.a.f.a(a1);
      } finally {
        Exception exception = null;
      } 
    }
    
    public CharSequence d(CharSequence param1CharSequence, int param1Int1, int param1Int2, int param1Int3, boolean param1Boolean) {
      return this.b.j(param1CharSequence, param1Int1, param1Int2, param1Int3, param1Boolean);
    }
    
    public void e(EditorInfo param1EditorInfo) {
      param1EditorInfo.extras.putInt("android.support.text.emoji.emojiCompat_metadataVersion", this.c.e());
      param1EditorInfo.extras.putBoolean("android.support.text.emoji.emojiCompat_replaceAll", this.a.h);
    }
    
    public void f(f param1f) {
      if (param1f == null) {
        this.a.p(new IllegalArgumentException("metadataRepo cannot be null"));
        return;
      } 
      this.c = param1f;
      f f1 = this.c;
      c.j j = c.a(this.a);
      c.e e = c.b(this.a);
      c c = this.a;
      this.b = new d(f1, j, e, c.i, c.j, dbxyzptlk.F2.e.a());
      this.a.q();
    }
    
    public class a extends c.i {
      public final c.a a;
      
      public a(c.a this$0) {}
      
      public void a(Throwable param2Throwable) {
        this.a.a.p(param2Throwable);
      }
      
      public void b(f param2f) {
        this.a.f(param2f);
      }
    }
  }
  
  public class a extends i {
    public final c.a a;
    
    public a(c this$0) {}
    
    public void a(Throwable param1Throwable) {
      this.a.a.p(param1Throwable);
    }
    
    public void b(f param1f) {
      this.a.f(param1f);
    }
  }
  
  public static class b {
    public final c a;
    
    public b(c param1c) {
      this.a = param1c;
    }
    
    public int a(CharSequence param1CharSequence, int param1Int) {
      throw null;
    }
    
    public int b(CharSequence param1CharSequence, int param1Int) {
      throw null;
    }
    
    public void c() {
      throw null;
    }
    
    public CharSequence d(CharSequence param1CharSequence, int param1Int1, int param1Int2, int param1Int3, boolean param1Boolean) {
      throw null;
    }
    
    public void e(EditorInfo param1EditorInfo) {
      throw null;
    }
  }
  
  public static abstract class c {
    public final c.h a;
    
    public c.j b;
    
    public boolean c;
    
    public boolean d;
    
    public int[] e;
    
    public Set<c.f> f;
    
    public boolean g;
    
    public int h = -16711936;
    
    public int i = 0;
    
    public c.e j = new b();
    
    public c(c.h param1h) {
      dbxyzptlk.g2.i.h(param1h, "metadataLoader cannot be null.");
      this.a = param1h;
    }
    
    public final c.h a() {
      return this.a;
    }
    
    public c b(int param1Int) {
      this.i = param1Int;
      return this;
    }
  }
  
  public static class d implements j {
    public dbxyzptlk.F2.f a(dbxyzptlk.F2.j param1j) {
      return (dbxyzptlk.F2.f)new k(param1j);
    }
  }
  
  public static interface e {
    boolean a(CharSequence param1CharSequence, int param1Int1, int param1Int2, int param1Int3);
  }
  
  public static abstract class f {
    public void a(Throwable param1Throwable) {}
    
    public void b() {}
  }
  
  class c {}
  
  public static interface h {
    void a(c.i param1i);
  }
  
  public static abstract class i {
    public abstract void a(Throwable param1Throwable);
    
    public abstract void b(f param1f);
  }
  
  public static interface j {
    dbxyzptlk.F2.f a(dbxyzptlk.F2.j param1j);
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\emoji2\text\c.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */