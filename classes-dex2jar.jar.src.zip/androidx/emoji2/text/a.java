package androidx.emoji2.text;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ProviderInfo;
import android.content.pm.ResolveInfo;
import android.content.pm.Signature;
import android.os.Build;
import dbxyzptlk.e2.e;
import dbxyzptlk.g2.i;
import io.sentry.android.core.r0;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class a {
  public static e a(Context paramContext) {
    return (e)(new a(null)).c(paramContext);
  }
  
  public static class a {
    public final a.b a;
    
    public a(a.b param1b) {
      if (param1b == null)
        param1b = e(); 
      this.a = param1b;
    }
    
    public static a.b e() {
      return (Build.VERSION.SDK_INT >= 28) ? new a.d() : new a.c();
    }
    
    public final c.c a(Context param1Context, e param1e) {
      return (param1e == null) ? null : new e(param1Context, param1e);
    }
    
    public final List<List<byte[]>> b(Signature[] param1ArrayOfSignature) {
      ArrayList<byte[]> arrayList = new ArrayList();
      int i = param1ArrayOfSignature.length;
      for (byte b1 = 0; b1 < i; b1++)
        arrayList.add(param1ArrayOfSignature[b1].toByteArray()); 
      return (List)Collections.singletonList(arrayList);
    }
    
    public c.c c(Context param1Context) {
      return a(param1Context, h(param1Context));
    }
    
    public final e d(ProviderInfo param1ProviderInfo, PackageManager param1PackageManager) throws PackageManager.NameNotFoundException {
      String str2 = param1ProviderInfo.authority;
      String str1 = param1ProviderInfo.packageName;
      return new e(str2, str1, "emojicompat-emoji-font", b(this.a.b(param1PackageManager, str1)));
    }
    
    public final boolean f(ProviderInfo param1ProviderInfo) {
      if (param1ProviderInfo != null) {
        ApplicationInfo applicationInfo = param1ProviderInfo.applicationInfo;
        if (applicationInfo != null) {
          int i = applicationInfo.flags;
          boolean bool = true;
          if ((i & 0x1) == 1)
            return bool; 
        } 
      } 
      return false;
    }
    
    public final ProviderInfo g(PackageManager param1PackageManager) {
      for (ResolveInfo resolveInfo : this.a.c(param1PackageManager, new Intent("androidx.content.action.LOAD_EMOJI_FONT"), 0)) {
        ProviderInfo providerInfo = this.a.a(resolveInfo);
        if (f(providerInfo))
          return providerInfo; 
      } 
      return null;
    }
    
    public e h(Context param1Context) {
      PackageManager packageManager = param1Context.getPackageManager();
      i.h(packageManager, "Package manager required to locate emoji font provider");
      ProviderInfo providerInfo = g(packageManager);
      if (providerInfo == null)
        return null; 
      try {
        return d(providerInfo, packageManager);
      } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
        r0.k("emoji2.text.DefaultEmojiConfig", (Throwable)nameNotFoundException);
        return null;
      } 
    }
  }
  
  public static class b {
    public ProviderInfo a(ResolveInfo param1ResolveInfo) {
      throw null;
    }
    
    public Signature[] b(PackageManager param1PackageManager, String param1String) throws PackageManager.NameNotFoundException {
      return (param1PackageManager.getPackageInfo(param1String, 64)).signatures;
    }
    
    public List<ResolveInfo> c(PackageManager param1PackageManager, Intent param1Intent, int param1Int) {
      throw null;
    }
  }
  
  public static class c extends b {
    public ProviderInfo a(ResolveInfo param1ResolveInfo) {
      return param1ResolveInfo.providerInfo;
    }
    
    public List<ResolveInfo> c(PackageManager param1PackageManager, Intent param1Intent, int param1Int) {
      return param1PackageManager.queryIntentContentProviders(param1Intent, param1Int);
    }
  }
  
  public static class d extends c {
    public Signature[] b(PackageManager param1PackageManager, String param1String) throws PackageManager.NameNotFoundException {
      return (param1PackageManager.getPackageInfo(param1String, 64)).signatures;
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\emoji2\text\a.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */