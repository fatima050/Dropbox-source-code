package androidx.emoji2.text;

import android.graphics.Paint;
import android.text.TextPaint;
import dbxyzptlk.Y1.f;

public class b implements c.e {
  public static final ThreadLocal<StringBuilder> b = new ThreadLocal<>();
  
  public final TextPaint a;
  
  public b() {
    TextPaint textPaint = new TextPaint();
    this.a = textPaint;
    textPaint.setTextSize(10.0F);
  }
  
  public static StringBuilder b() {
    ThreadLocal<StringBuilder> threadLocal = b;
    if (threadLocal.get() == null)
      threadLocal.set(new StringBuilder()); 
    return threadLocal.get();
  }
  
  public boolean a(CharSequence paramCharSequence, int paramInt1, int paramInt2, int paramInt3) {
    StringBuilder stringBuilder = b();
    stringBuilder.setLength(0);
    while (paramInt1 < paramInt2) {
      stringBuilder.append(paramCharSequence.charAt(paramInt1));
      paramInt1++;
    } 
    return f.a((Paint)this.a, stringBuilder.toString());
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\emoji2\text\b.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */