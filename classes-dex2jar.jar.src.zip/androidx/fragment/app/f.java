package androidx.fragment.app;

import dbxyzptlk.V.E;

public class f {
  public static final E<ClassLoader, E<String, Class<?>>> a = new E();
  
  public static boolean b(ClassLoader paramClassLoader, String paramString) {
    try {
      return Fragment.class.isAssignableFrom(c(paramClassLoader, paramString));
    } catch (ClassNotFoundException classNotFoundException) {
      return false;
    } 
  }
  
  public static Class<?> c(ClassLoader paramClassLoader, String paramString) throws ClassNotFoundException {
    E<ClassLoader, E<String, Class<?>>> e = a;
    E e2 = (E)e.get(paramClassLoader);
    E e1 = e2;
    if (e2 == null) {
      e1 = new E();
      e.put(paramClassLoader, e1);
    } 
    Class<?> clazz2 = (Class)e1.get(paramString);
    Class<?> clazz1 = clazz2;
    if (clazz2 == null) {
      clazz1 = Class.forName(paramString, false, paramClassLoader);
      e1.put(paramString, clazz1);
    } 
    return clazz1;
  }
  
  public static Class<? extends Fragment> d(ClassLoader paramClassLoader, String paramString) {
    try {
      return (Class)c(paramClassLoader, paramString);
    } catch (ClassNotFoundException classNotFoundException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Unable to instantiate fragment ");
      stringBuilder.append(paramString);
      stringBuilder.append(": make sure class name exists");
      throw new Fragment.InstantiationException(stringBuilder.toString(), classNotFoundException);
    } catch (ClassCastException classCastException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Unable to instantiate fragment ");
      stringBuilder.append(paramString);
      stringBuilder.append(": make sure class is a valid subclass of Fragment");
      throw new Fragment.InstantiationException(stringBuilder.toString(), classCastException);
    } 
  }
  
  public Fragment a(ClassLoader paramClassLoader, String paramString) {
    throw null;
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\fragment\app\f.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */