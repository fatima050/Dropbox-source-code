package androidx.fragment.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.IntentSender;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Looper;
import android.os.Parcelable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import androidx.activity.OnBackPressedDispatcher;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.IntentSenderRequest;
import androidx.lifecycle.LifecycleEventObserver;
import androidx.lifecycle.LifecycleOwner;
import dbxyzptlk.K2.A;
import dbxyzptlk.K2.F;
import dbxyzptlk.K2.J;
import dbxyzptlk.K2.n;
import dbxyzptlk.K2.p;
import dbxyzptlk.K2.s;
import dbxyzptlk.K2.t;
import dbxyzptlk.K2.u;
import dbxyzptlk.K2.v;
import dbxyzptlk.K2.w;
import dbxyzptlk.K2.y;
import dbxyzptlk.T1.s;
import dbxyzptlk.T1.t;
import dbxyzptlk.T1.v;
import dbxyzptlk.U2.y;
import dbxyzptlk.U2.z;
import dbxyzptlk.e.E;
import dbxyzptlk.e.H;
import dbxyzptlk.h2.B;
import dbxyzptlk.h2.G;
import io.sentry.android.core.r0;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.io.Writer;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;

public abstract class FragmentManager {
  public static boolean S = false;
  
  public f A = new d(this);
  
  public J B = null;
  
  public J C = new e(this);
  
  public dbxyzptlk.h.b<Intent> D;
  
  public dbxyzptlk.h.b<IntentSenderRequest> E;
  
  public dbxyzptlk.h.b<String[]> F;
  
  public ArrayDeque<l> G = new ArrayDeque<>();
  
  public boolean H;
  
  public boolean I;
  
  public boolean J;
  
  public boolean K;
  
  public boolean L;
  
  public ArrayList<a> M;
  
  public ArrayList<Boolean> N;
  
  public ArrayList<Fragment> O;
  
  public j P;
  
  public dbxyzptlk.L2.b.c Q;
  
  public Runnable R = new f(this);
  
  public final ArrayList<o> a = new ArrayList<>();
  
  public boolean b;
  
  public final n c = new n();
  
  public ArrayList<a> d;
  
  public ArrayList<Fragment> e;
  
  public final g f = new g(this);
  
  public OnBackPressedDispatcher g;
  
  public final E h = new b(this, false);
  
  public final AtomicInteger i = new AtomicInteger();
  
  public final Map<String, c> j = Collections.synchronizedMap(new HashMap<>());
  
  public final Map<String, Bundle> k = Collections.synchronizedMap(new HashMap<>());
  
  public final Map<String, m> l = Collections.synchronizedMap(new HashMap<>());
  
  public ArrayList<n> m;
  
  public final h n = new h(this);
  
  public final CopyOnWriteArrayList<y> o = new CopyOnWriteArrayList<>();
  
  public final dbxyzptlk.g2.a<Configuration> p = (dbxyzptlk.g2.a<Configuration>)new s(this);
  
  public final dbxyzptlk.g2.a<Integer> q = (dbxyzptlk.g2.a<Integer>)new t(this);
  
  public final dbxyzptlk.g2.a<dbxyzptlk.T1.k> r = (dbxyzptlk.g2.a<dbxyzptlk.T1.k>)new u(this);
  
  public final dbxyzptlk.g2.a<v> s = (dbxyzptlk.g2.a<v>)new v(this);
  
  public final G t = new c(this);
  
  public int u = -1;
  
  public p<?> v;
  
  public n w;
  
  public Fragment x;
  
  public Fragment y;
  
  public f z = null;
  
  public static int C1(int paramInt) {
    char c1 = ' ';
    char c2 = 'ခ';
    if (paramInt != 4097) {
      c1 = c2;
      if (paramInt != 8194) {
        c1 = 'င';
        c2 = ' ';
        if (paramInt != 8197)
          if (paramInt != 4099) {
            c1 = c2;
            if (paramInt != 4100)
              c1 = Character.MIN_VALUE; 
          } else {
            c1 = 'ဃ';
          }  
      } 
    } 
    return c1;
  }
  
  public static Fragment K0(View paramView) {
    Object object = paramView.getTag(dbxyzptlk.J2.b.fragment_container_view_tag);
    return (object instanceof Fragment) ? (Fragment)object : null;
  }
  
  public static boolean Q0(int paramInt) {
    return (S || Log.isLoggable("FragmentManager", paramInt));
  }
  
  public static void f0(ArrayList<a> paramArrayList, ArrayList<Boolean> paramArrayList1, int paramInt1, int paramInt2) {
    while (paramInt1 < paramInt2) {
      a a1 = paramArrayList.get(paramInt1);
      if (((Boolean)paramArrayList1.get(paramInt1)).booleanValue()) {
        a1.D(-1);
        a1.J();
      } else {
        a1.D(1);
        a1.I();
      } 
      paramInt1++;
    } 
  }
  
  public static <F extends Fragment> F k0(View paramView) {
    Fragment fragment = p0(paramView);
    if (fragment != null)
      return (F)fragment; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("View ");
    stringBuilder.append(paramView);
    stringBuilder.append(" does not have a Fragment set");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public static FragmentManager o0(View paramView) {
    FragmentManager fragmentManager;
    Fragment fragment = p0(paramView);
    if (fragment != null) {
      if (fragment.isAdded()) {
        fragmentManager = fragment.getChildFragmentManager();
      } else {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("The Fragment ");
        stringBuilder.append(fragment);
        stringBuilder.append(" that owns View ");
        stringBuilder.append(fragmentManager);
        stringBuilder.append(" has already been destroyed. Nested fragments should always use the child FragmentManager.");
        throw new IllegalStateException(stringBuilder.toString());
      } 
    } else {
      Context context = fragmentManager.getContext();
      while (true) {
        if (context instanceof ContextWrapper) {
          FragmentActivity fragmentActivity;
          if (context instanceof FragmentActivity) {
            fragmentActivity = (FragmentActivity)context;
            break;
          } 
          Context context1 = ((ContextWrapper)fragmentActivity).getBaseContext();
          continue;
        } 
        context = null;
        break;
      } 
      if (context != null)
        return context.getSupportFragmentManager(); 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("View ");
      stringBuilder.append(fragmentManager);
      stringBuilder.append(" is not within a subclass of FragmentActivity.");
      throw new IllegalStateException(stringBuilder.toString());
    } 
    return fragmentManager;
  }
  
  public static Fragment p0(View paramView) {
    while (paramView != null) {
      Fragment fragment = K0(paramView);
      if (fragment != null)
        return fragment; 
      ViewParent viewParent = paramView.getParent();
      if (viewParent instanceof View) {
        View view = (View)viewParent;
        continue;
      } 
      viewParent = null;
    } 
    return null;
  }
  
  public void A() {
    this.I = false;
    this.J = false;
    this.P.Q(false);
    V(4);
  }
  
  public f A0() {
    f f1 = this.z;
    if (f1 != null)
      return f1; 
    Fragment fragment = this.x;
    return (fragment != null) ? fragment.mFragmentManager.A0() : this.A;
  }
  
  public boolean A1(ArrayList<a> paramArrayList, ArrayList<Boolean> paramArrayList1, String paramString) {
    c c1 = this.j.remove(paramString);
    if (c1 == null)
      return false; 
    HashMap<Object, Object> hashMap = new HashMap<>();
    for (a a1 : paramArrayList) {
      if (a1.w) {
        Iterator<o.a> iterator1 = a1.c.iterator();
        while (iterator1.hasNext()) {
          Fragment fragment = ((o.a)iterator1.next()).b;
          if (fragment != null)
            hashMap.put(fragment.mWho, fragment); 
        } 
      } 
    } 
    Iterator<a> iterator = c1.a(this, hashMap).iterator();
    label25: while (true) {
      boolean bool = false;
      while (iterator.hasNext()) {
        if (((a)iterator.next()).a(paramArrayList, paramArrayList1) || bool) {
          bool = true;
          continue;
        } 
        continue label25;
      } 
      return bool;
    } 
  }
  
  public void B() {
    this.I = false;
    this.J = false;
    this.P.Q(false);
    V(0);
  }
  
  public n B0() {
    return this.c;
  }
  
  public void B1(Parcelable paramParcelable) {
    if (paramParcelable == null)
      return; 
    Bundle bundle = (Bundle)paramParcelable;
    for (String str1 : bundle.keySet()) {
      if (str1.startsWith("result_")) {
        Bundle bundle1 = bundle.getBundle(str1);
        if (bundle1 != null) {
          bundle1.setClassLoader(this.v.f().getClassLoader());
          str1 = str1.substring(7);
          this.k.put(str1, bundle1);
        } 
      } 
    } 
    HashMap<Object, Object> hashMap = new HashMap<>();
    for (String str1 : bundle.keySet()) {
      if (str1.startsWith("fragment_")) {
        Bundle bundle1 = bundle.getBundle(str1);
        if (bundle1 != null) {
          bundle1.setClassLoader(this.v.f().getClassLoader());
          hashMap.put(str1.substring(9), bundle1);
        } 
      } 
    } 
    this.c.x((HashMap)hashMap);
    i i = (i)bundle.getParcelable("state");
    if (i == null)
      return; 
    this.c.v();
    for (String str1 : i.a) {
      Bundle bundle1 = this.c.B(str1, null);
      if (bundle1 != null) {
        l l;
        k k = (k)bundle1.getParcelable("state");
        Fragment fragment = this.P.J(k.b);
        if (fragment != null) {
          if (Q0(2)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("restoreSaveState: re-attaching retained ");
            stringBuilder.append(fragment);
            Log.v("FragmentManager", stringBuilder.toString());
          } 
          l = new l(this.n, this.c, fragment, bundle1);
        } else {
          l = new l(this.n, this.c, this.v.f().getClassLoader(), A0(), bundle1);
        } 
        fragment = l.k();
        fragment.mSavedFragmentState = bundle1;
        fragment.mFragmentManager = this;
        if (Q0(2)) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("restoreSaveState: active (");
          stringBuilder.append(fragment.mWho);
          stringBuilder.append("): ");
          stringBuilder.append(fragment);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
        l.o(this.v.f().getClassLoader());
        this.c.r(l);
        l.t(this.u);
      } 
    } 
    for (Fragment fragment : this.P.M()) {
      if (!this.c.c(fragment.mWho)) {
        if (Q0(2)) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Discarding retained Fragment ");
          stringBuilder.append(fragment);
          stringBuilder.append(" that was not found in the set of active Fragments ");
          stringBuilder.append(i.a);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
        this.P.P(fragment);
        fragment.mFragmentManager = this;
        l l = new l(this.n, this.c, fragment);
        l.t(1);
        l.m();
        fragment.mRemoving = true;
        l.m();
      } 
    } 
    this.c.w(i.b);
    b[] arrayOfB = i.c;
    byte b1 = 0;
    if (arrayOfB != null) {
      this.d = new ArrayList<>(i.c.length);
      byte b2 = 0;
      while (true) {
        arrayOfB = i.c;
        if (b2 < arrayOfB.length) {
          a a1 = arrayOfB[b2].b(this);
          if (Q0(2)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("restoreAllState: back stack #");
            stringBuilder.append(b2);
            stringBuilder.append(" (index ");
            stringBuilder.append(a1.v);
            stringBuilder.append("): ");
            stringBuilder.append(a1);
            Log.v("FragmentManager", stringBuilder.toString());
            PrintWriter printWriter = new PrintWriter((Writer)new F("FragmentManager"));
            a1.H("  ", printWriter, false);
            printWriter.close();
          } 
          this.d.add(a1);
          b2++;
          continue;
        } 
        break;
      } 
    } else {
      this.d = null;
    } 
    this.i.set(i.d);
    String str = i.e;
    if (str != null) {
      Fragment fragment = i0(str);
      this.y = fragment;
      O(fragment);
    } 
    ArrayList<String> arrayList = i.f;
    if (arrayList != null)
      for (byte b2 = b1; b2 < arrayList.size(); b2++)
        this.j.put(arrayList.get(b2), i.g.get(b2));  
    this.G = new ArrayDeque<>(i.h);
  }
  
  public void C(Configuration paramConfiguration, boolean paramBoolean) {
    if (paramBoolean && this.v instanceof dbxyzptlk.V1.e)
      Q1(new IllegalStateException("Do not call dispatchConfigurationChanged() on host. Host implements OnConfigurationChangedProvider and automatically dispatches configuration changes to fragments.")); 
    for (Fragment fragment : this.c.o()) {
      if (fragment != null) {
        fragment.performConfigurationChanged(paramConfiguration);
        if (paramBoolean)
          fragment.mChildFragmentManager.C(paramConfiguration, true); 
      } 
    } 
  }
  
  public List<Fragment> C0() {
    return this.c.o();
  }
  
  public boolean D(MenuItem paramMenuItem) {
    if (this.u < 1)
      return false; 
    for (Fragment fragment : this.c.o()) {
      if (fragment != null && fragment.performContextItemSelected(paramMenuItem))
        return true; 
    } 
    return false;
  }
  
  public p<?> D0() {
    return this.v;
  }
  
  public Bundle D1() {
    // Byte code:
    //   0: new android/os/Bundle
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore #5
    //   9: aload_0
    //   10: invokevirtual q0 : ()V
    //   13: aload_0
    //   14: invokevirtual a0 : ()V
    //   17: aload_0
    //   18: iconst_1
    //   19: invokevirtual d0 : (Z)Z
    //   22: pop
    //   23: aload_0
    //   24: iconst_1
    //   25: putfield I : Z
    //   28: aload_0
    //   29: getfield P : Landroidx/fragment/app/j;
    //   32: iconst_1
    //   33: invokevirtual Q : (Z)V
    //   36: aload_0
    //   37: getfield c : Landroidx/fragment/app/n;
    //   40: invokevirtual y : ()Ljava/util/ArrayList;
    //   43: astore #7
    //   45: aload_0
    //   46: getfield c : Landroidx/fragment/app/n;
    //   49: invokevirtual m : ()Ljava/util/HashMap;
    //   52: astore #6
    //   54: aload #6
    //   56: invokevirtual isEmpty : ()Z
    //   59: ifeq -> 81
    //   62: iconst_2
    //   63: invokestatic Q0 : (I)Z
    //   66: ifeq -> 503
    //   69: ldc 'FragmentManager'
    //   71: ldc_w 'saveAllState: no fragments!'
    //   74: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   77: pop
    //   78: goto -> 503
    //   81: aload_0
    //   82: getfield c : Landroidx/fragment/app/n;
    //   85: invokevirtual z : ()Ljava/util/ArrayList;
    //   88: astore #8
    //   90: aload_0
    //   91: getfield d : Ljava/util/ArrayList;
    //   94: astore_3
    //   95: aload_3
    //   96: ifnull -> 212
    //   99: aload_3
    //   100: invokevirtual size : ()I
    //   103: istore_2
    //   104: iload_2
    //   105: ifle -> 212
    //   108: iload_2
    //   109: anewarray androidx/fragment/app/b
    //   112: astore #4
    //   114: iconst_0
    //   115: istore_1
    //   116: aload #4
    //   118: astore_3
    //   119: iload_1
    //   120: iload_2
    //   121: if_icmpge -> 214
    //   124: aload #4
    //   126: iload_1
    //   127: new androidx/fragment/app/b
    //   130: dup
    //   131: aload_0
    //   132: getfield d : Ljava/util/ArrayList;
    //   135: iload_1
    //   136: invokevirtual get : (I)Ljava/lang/Object;
    //   139: checkcast androidx/fragment/app/a
    //   142: invokespecial <init> : (Landroidx/fragment/app/a;)V
    //   145: aastore
    //   146: iconst_2
    //   147: invokestatic Q0 : (I)Z
    //   150: ifeq -> 206
    //   153: new java/lang/StringBuilder
    //   156: dup
    //   157: invokespecial <init> : ()V
    //   160: astore_3
    //   161: aload_3
    //   162: ldc_w 'saveAllState: adding back stack #'
    //   165: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   168: pop
    //   169: aload_3
    //   170: iload_1
    //   171: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   174: pop
    //   175: aload_3
    //   176: ldc_w ': '
    //   179: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   182: pop
    //   183: aload_3
    //   184: aload_0
    //   185: getfield d : Ljava/util/ArrayList;
    //   188: iload_1
    //   189: invokevirtual get : (I)Ljava/lang/Object;
    //   192: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   195: pop
    //   196: ldc 'FragmentManager'
    //   198: aload_3
    //   199: invokevirtual toString : ()Ljava/lang/String;
    //   202: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   205: pop
    //   206: iinc #1, 1
    //   209: goto -> 116
    //   212: aconst_null
    //   213: astore_3
    //   214: new androidx/fragment/app/i
    //   217: dup
    //   218: invokespecial <init> : ()V
    //   221: astore #4
    //   223: aload #4
    //   225: aload #7
    //   227: putfield a : Ljava/util/ArrayList;
    //   230: aload #4
    //   232: aload #8
    //   234: putfield b : Ljava/util/ArrayList;
    //   237: aload #4
    //   239: aload_3
    //   240: putfield c : [Landroidx/fragment/app/b;
    //   243: aload #4
    //   245: aload_0
    //   246: getfield i : Ljava/util/concurrent/atomic/AtomicInteger;
    //   249: invokevirtual get : ()I
    //   252: putfield d : I
    //   255: aload_0
    //   256: getfield y : Landroidx/fragment/app/Fragment;
    //   259: astore_3
    //   260: aload_3
    //   261: ifnull -> 273
    //   264: aload #4
    //   266: aload_3
    //   267: getfield mWho : Ljava/lang/String;
    //   270: putfield e : Ljava/lang/String;
    //   273: aload #4
    //   275: getfield f : Ljava/util/ArrayList;
    //   278: aload_0
    //   279: getfield j : Ljava/util/Map;
    //   282: invokeinterface keySet : ()Ljava/util/Set;
    //   287: invokevirtual addAll : (Ljava/util/Collection;)Z
    //   290: pop
    //   291: aload #4
    //   293: getfield g : Ljava/util/ArrayList;
    //   296: aload_0
    //   297: getfield j : Ljava/util/Map;
    //   300: invokeinterface values : ()Ljava/util/Collection;
    //   305: invokevirtual addAll : (Ljava/util/Collection;)Z
    //   308: pop
    //   309: aload #4
    //   311: new java/util/ArrayList
    //   314: dup
    //   315: aload_0
    //   316: getfield G : Ljava/util/ArrayDeque;
    //   319: invokespecial <init> : (Ljava/util/Collection;)V
    //   322: putfield h : Ljava/util/ArrayList;
    //   325: aload #5
    //   327: ldc_w 'state'
    //   330: aload #4
    //   332: invokevirtual putParcelable : (Ljava/lang/String;Landroid/os/Parcelable;)V
    //   335: aload_0
    //   336: getfield k : Ljava/util/Map;
    //   339: invokeinterface keySet : ()Ljava/util/Set;
    //   344: invokeinterface iterator : ()Ljava/util/Iterator;
    //   349: astore_3
    //   350: aload_3
    //   351: invokeinterface hasNext : ()Z
    //   356: ifeq -> 423
    //   359: aload_3
    //   360: invokeinterface next : ()Ljava/lang/Object;
    //   365: checkcast java/lang/String
    //   368: astore #4
    //   370: new java/lang/StringBuilder
    //   373: dup
    //   374: invokespecial <init> : ()V
    //   377: astore #7
    //   379: aload #7
    //   381: ldc_w 'result_'
    //   384: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   387: pop
    //   388: aload #7
    //   390: aload #4
    //   392: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   395: pop
    //   396: aload #5
    //   398: aload #7
    //   400: invokevirtual toString : ()Ljava/lang/String;
    //   403: aload_0
    //   404: getfield k : Ljava/util/Map;
    //   407: aload #4
    //   409: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   414: checkcast android/os/Bundle
    //   417: invokevirtual putBundle : (Ljava/lang/String;Landroid/os/Bundle;)V
    //   420: goto -> 350
    //   423: aload #6
    //   425: invokevirtual keySet : ()Ljava/util/Set;
    //   428: invokeinterface iterator : ()Ljava/util/Iterator;
    //   433: astore_3
    //   434: aload_3
    //   435: invokeinterface hasNext : ()Z
    //   440: ifeq -> 503
    //   443: aload_3
    //   444: invokeinterface next : ()Ljava/lang/Object;
    //   449: checkcast java/lang/String
    //   452: astore #4
    //   454: new java/lang/StringBuilder
    //   457: dup
    //   458: invokespecial <init> : ()V
    //   461: astore #7
    //   463: aload #7
    //   465: ldc_w 'fragment_'
    //   468: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   471: pop
    //   472: aload #7
    //   474: aload #4
    //   476: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   479: pop
    //   480: aload #5
    //   482: aload #7
    //   484: invokevirtual toString : ()Ljava/lang/String;
    //   487: aload #6
    //   489: aload #4
    //   491: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   494: checkcast android/os/Bundle
    //   497: invokevirtual putBundle : (Ljava/lang/String;Landroid/os/Bundle;)V
    //   500: goto -> 434
    //   503: aload #5
    //   505: areturn
  }
  
  public void E() {
    this.I = false;
    this.J = false;
    this.P.Q(false);
    V(1);
  }
  
  public LayoutInflater.Factory2 E0() {
    return this.f;
  }
  
  public void E1(String paramString) {
    b0((o)new r(this, paramString), false);
  }
  
  public boolean F(Menu paramMenu, MenuInflater paramMenuInflater) {
    int i = this.u;
    byte b1 = 0;
    if (i < 1)
      return false; 
    Iterator<Fragment> iterator = this.c.o().iterator();
    ArrayList<Fragment> arrayList = null;
    boolean bool = false;
    while (iterator.hasNext()) {
      Fragment fragment = iterator.next();
      if (fragment != null && U0(fragment) && fragment.performCreateOptionsMenu(paramMenu, paramMenuInflater)) {
        ArrayList<Fragment> arrayList1 = arrayList;
        if (arrayList == null)
          arrayList1 = new ArrayList(); 
        arrayList1.add(fragment);
        bool = true;
        arrayList = arrayList1;
      } 
    } 
    if (this.e != null)
      while (b1 < this.e.size()) {
        Fragment fragment = this.e.get(b1);
        if (arrayList == null || !arrayList.contains(fragment))
          fragment.onDestroyOptionsMenu(); 
        b1++;
      }  
    this.e = arrayList;
    return bool;
  }
  
  public h F0() {
    return this.n;
  }
  
  public boolean F1(ArrayList<a> paramArrayList, ArrayList<Boolean> paramArrayList1, String paramString) {
    int i = j0(paramString, -1, true);
    if (i < 0)
      return false; 
    int k;
    for (k = i; k < this.d.size(); k++) {
      a a1 = this.d.get(k);
      if (!a1.r) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("saveBackStack(\"");
        stringBuilder.append(paramString);
        stringBuilder.append("\") included FragmentTransactions must use setReorderingAllowed(true) to ensure that the back stack can be restored as an atomic operation. Found ");
        stringBuilder.append(a1);
        stringBuilder.append(" that did not use setReorderingAllowed(true).");
        Q1(new IllegalArgumentException(stringBuilder.toString()));
      } 
    } 
    HashSet<?> hashSet = new HashSet();
    for (k = i; k < this.d.size(); k++) {
      a a1 = this.d.get(k);
      HashSet hashSet1 = new HashSet();
      HashSet<Object> hashSet2 = new HashSet();
      Iterator<o.a> iterator1 = a1.c.iterator();
      while (true) {
        while (true)
          break; 
        if (SYNTHETIC_LOCAL_VARIABLE_6 == true || SYNTHETIC_LOCAL_VARIABLE_6 == 2)
          hashSet2.add(SYNTHETIC_LOCAL_VARIABLE_13); 
      } 
      hashSet1.removeAll(hashSet2);
      if (!hashSet1.isEmpty()) {
        String str;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("saveBackStack(\"");
        stringBuilder.append(paramString);
        stringBuilder.append("\") must be self contained and not reference fragments from non-saved FragmentTransactions. Found reference to fragment");
        if (hashSet1.size() == 1) {
          StringBuilder stringBuilder1 = new StringBuilder();
          stringBuilder1.append(" ");
          stringBuilder1.append(hashSet1.iterator().next());
          str = stringBuilder1.toString();
        } else {
          StringBuilder stringBuilder1 = new StringBuilder();
          stringBuilder1.append("s ");
          stringBuilder1.append(str);
          str = stringBuilder1.toString();
        } 
        stringBuilder.append(str);
        stringBuilder.append(" in ");
        stringBuilder.append(a1);
        stringBuilder.append(" that were previously added to the FragmentManager through a separate FragmentTransaction.");
        Q1(new IllegalArgumentException(stringBuilder.toString()));
      } 
    } 
    ArrayDeque<Fragment> arrayDeque = new ArrayDeque(hashSet);
    while (!arrayDeque.isEmpty()) {
      Fragment fragment = arrayDeque.removeFirst();
      if (fragment.mRetainInstance) {
        String str;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("saveBackStack(\"");
        stringBuilder.append(paramString);
        stringBuilder.append("\") must not contain retained fragments. Found ");
        if (hashSet.contains(fragment)) {
          str = "direct reference to retained ";
        } else {
          str = "retained child ";
        } 
        stringBuilder.append(str);
        stringBuilder.append("fragment ");
        stringBuilder.append(fragment);
        Q1(new IllegalArgumentException(stringBuilder.toString()));
      } 
      for (Fragment fragment1 : fragment.mChildFragmentManager.t0()) {
        if (fragment1 != null)
          arrayDeque.addLast(fragment1); 
      } 
    } 
    ArrayList<String> arrayList1 = new ArrayList();
    Iterator<?> iterator = hashSet.iterator();
    while (iterator.hasNext())
      arrayList1.add(((Fragment)iterator.next()).mWho); 
    ArrayList<b> arrayList = new ArrayList(this.d.size() - i);
    for (k = i; k < this.d.size(); k++)
      arrayList.add(null); 
    c c1 = new c(arrayList1, arrayList);
    for (k = this.d.size() - 1; k >= i; k--) {
      a a2 = this.d.remove(k);
      a a1 = new a(a2);
      a1.E();
      arrayList.set(k - i, new b(a1));
      a2.w = true;
      paramArrayList.add(a2);
      paramArrayList1.add(Boolean.TRUE);
    } 
    this.j.put(paramString, c1);
    return true;
  }
  
  public void G() {
    this.K = true;
    d0(true);
    a0();
    u();
    V(-1);
    p<?> p1 = this.v;
    if (p1 instanceof dbxyzptlk.V1.f)
      ((dbxyzptlk.V1.f)p1).removeOnTrimMemoryListener(this.q); 
    p1 = this.v;
    if (p1 instanceof dbxyzptlk.V1.e)
      ((dbxyzptlk.V1.e)p1).removeOnConfigurationChangedListener(this.p); 
    p1 = this.v;
    if (p1 instanceof s)
      ((s)p1).removeOnMultiWindowModeChangedListener(this.r); 
    p1 = this.v;
    if (p1 instanceof t)
      ((t)p1).removeOnPictureInPictureModeChangedListener(this.s); 
    p1 = this.v;
    if (p1 instanceof B && this.x == null)
      ((B)p1).removeMenuProvider(this.t); 
    this.v = null;
    this.w = null;
    this.x = null;
    if (this.g != null) {
      this.h.k();
      this.g = null;
    } 
    dbxyzptlk.h.b<Intent> b1 = this.D;
    if (b1 != null) {
      b1.c();
      this.E.c();
      this.F.c();
    } 
  }
  
  public Fragment G0() {
    return this.x;
  }
  
  public Fragment.SavedState G1(Fragment paramFragment) {
    l l = this.c.n(paramFragment.mWho);
    if (l == null || !l.k().equals(paramFragment)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Fragment ");
      stringBuilder.append(paramFragment);
      stringBuilder.append(" is not currently in the FragmentManager");
      Q1(new IllegalStateException(stringBuilder.toString()));
    } 
    return l.q();
  }
  
  public void H() {
    V(1);
  }
  
  public Fragment H0() {
    return this.y;
  }
  
  public void H1() {
    ArrayList<o> arrayList = this.a;
    /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{java/util/ArrayList<InnerObjectType{ObjectType{androidx/fragment/app/FragmentManager}.Landroidx/fragment/app/FragmentManager$o;}>}, name=null} */
    try {
      if (this.a.size() == 1) {
        this.v.g().removeCallbacks(this.R);
        this.v.g().post(this.R);
        S1();
      } 
    } finally {
      Exception exception;
    } 
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/util/ArrayList<InnerObjectType{ObjectType{androidx/fragment/app/FragmentManager}.Landroidx/fragment/app/FragmentManager$o;}>}, name=null} */
  }
  
  public void I(boolean paramBoolean) {
    if (paramBoolean && this.v instanceof dbxyzptlk.V1.f)
      Q1(new IllegalStateException("Do not call dispatchLowMemory() on host. Host implements OnTrimMemoryProvider and automatically dispatches low memory callbacks to fragments.")); 
    for (Fragment fragment : this.c.o()) {
      if (fragment != null) {
        fragment.performLowMemory();
        if (paramBoolean)
          fragment.mChildFragmentManager.I(true); 
      } 
    } 
  }
  
  public J I0() {
    J j1 = this.B;
    if (j1 != null)
      return j1; 
    Fragment fragment = this.x;
    return (fragment != null) ? fragment.mFragmentManager.I0() : this.C;
  }
  
  public void I1(Fragment paramFragment, boolean paramBoolean) {
    ViewGroup viewGroup = z0(paramFragment);
    if (viewGroup != null && viewGroup instanceof FragmentContainerView)
      ((FragmentContainerView)viewGroup).setDrawDisappearingViewsLast(paramBoolean ^ true); 
  }
  
  public void J(boolean paramBoolean1, boolean paramBoolean2) {
    if (paramBoolean2 && this.v instanceof s)
      Q1(new IllegalStateException("Do not call dispatchMultiWindowModeChanged() on host. Host implements OnMultiWindowModeChangedProvider and automatically dispatches multi-window mode changes to fragments.")); 
    for (Fragment fragment : this.c.o()) {
      if (fragment != null) {
        fragment.performMultiWindowModeChanged(paramBoolean1);
        if (paramBoolean2)
          fragment.mChildFragmentManager.J(paramBoolean1, true); 
      } 
    } 
  }
  
  public dbxyzptlk.L2.b.c J0() {
    return this.Q;
  }
  
  public final void J1(String paramString, Bundle paramBundle) {
    m m = this.l.get(paramString);
    if (m != null && m.b(androidx.lifecycle.f.b.STARTED)) {
      m.a(paramString, paramBundle);
    } else {
      this.k.put(paramString, paramBundle);
    } 
    if (Q0(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Setting fragment result with key ");
      stringBuilder.append(paramString);
      stringBuilder.append(" and result ");
      stringBuilder.append(paramBundle);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
  }
  
  public void K(Fragment paramFragment) {
    Iterator<y> iterator = this.o.iterator();
    while (iterator.hasNext())
      ((y)iterator.next()).a(this, paramFragment); 
  }
  
  @SuppressLint({"SyntheticAccessor"})
  public final void K1(String paramString, LifecycleOwner paramLifecycleOwner, A paramA) {
    androidx.lifecycle.f f1 = paramLifecycleOwner.getLifecycle();
    if (f1.b() == androidx.lifecycle.f.b.DESTROYED)
      return; 
    Object object = new Object(this, paramString, paramA, f1);
    m m = this.l.put(paramString, new m(f1, paramA, (LifecycleEventObserver)object));
    if (m != null)
      m.c(); 
    if (Q0(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Setting FragmentResultListener with key ");
      stringBuilder.append(paramString);
      stringBuilder.append(" lifecycleOwner ");
      stringBuilder.append(f1);
      stringBuilder.append(" and listener ");
      stringBuilder.append(paramA);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    f1.a((dbxyzptlk.U2.h)object);
  }
  
  public void L() {
    for (Fragment fragment : this.c.l()) {
      if (fragment != null) {
        fragment.onHiddenChanged(fragment.isHidden());
        fragment.mChildFragmentManager.L();
      } 
    } 
  }
  
  public y L0(Fragment paramFragment) {
    return this.P.N(paramFragment);
  }
  
  public void L1(Fragment paramFragment, androidx.lifecycle.f.b paramb) {
    if (paramFragment.equals(i0(paramFragment.mWho)) && (paramFragment.mHost == null || paramFragment.mFragmentManager == this)) {
      paramFragment.mMaxState = paramb;
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(paramFragment);
    stringBuilder.append(" is not an active fragment of FragmentManager ");
    stringBuilder.append(this);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public boolean M(MenuItem paramMenuItem) {
    if (this.u < 1)
      return false; 
    for (Fragment fragment : this.c.o()) {
      if (fragment != null && fragment.performOptionsItemSelected(paramMenuItem))
        return true; 
    } 
    return false;
  }
  
  public void M0() {
    d0(true);
    if (this.h.j()) {
      o1();
    } else {
      this.g.l();
    } 
  }
  
  public void M1(Fragment paramFragment) {
    if (paramFragment == null || (paramFragment.equals(i0(paramFragment.mWho)) && (paramFragment.mHost == null || paramFragment.mFragmentManager == this))) {
      Fragment fragment = this.y;
      this.y = paramFragment;
      O(fragment);
      O(this.y);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(paramFragment);
    stringBuilder.append(" is not an active fragment of FragmentManager ");
    stringBuilder.append(this);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public void N(Menu paramMenu) {
    if (this.u < 1)
      return; 
    for (Fragment fragment : this.c.o()) {
      if (fragment != null)
        fragment.performOptionsMenuClosed(paramMenu); 
    } 
  }
  
  public void N0(Fragment paramFragment) {
    if (Q0(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("hide: ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    if (!paramFragment.mHidden) {
      paramFragment.mHidden = true;
      paramFragment.mHiddenChanged = true ^ paramFragment.mHiddenChanged;
      N1(paramFragment);
    } 
  }
  
  public final void N1(Fragment paramFragment) {
    ViewGroup viewGroup = z0(paramFragment);
    if (viewGroup != null && paramFragment.getEnterAnim() + paramFragment.getExitAnim() + paramFragment.getPopEnterAnim() + paramFragment.getPopExitAnim() > 0) {
      if (viewGroup.getTag(dbxyzptlk.J2.b.visible_removing_fragment_view_tag) == null)
        viewGroup.setTag(dbxyzptlk.J2.b.visible_removing_fragment_view_tag, paramFragment); 
      ((Fragment)viewGroup.getTag(dbxyzptlk.J2.b.visible_removing_fragment_view_tag)).setPopDirection(paramFragment.getPopDirection());
    } 
  }
  
  public final void O(Fragment paramFragment) {
    if (paramFragment != null && paramFragment.equals(i0(paramFragment.mWho)))
      paramFragment.performPrimaryNavigationFragmentChanged(); 
  }
  
  public void O0(Fragment paramFragment) {
    if (paramFragment.mAdded && R0(paramFragment))
      this.H = true; 
  }
  
  public void O1(Fragment paramFragment) {
    if (Q0(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("show: ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    if (paramFragment.mHidden) {
      paramFragment.mHidden = false;
      paramFragment.mHiddenChanged ^= 0x1;
    } 
  }
  
  public void P() {
    V(5);
  }
  
  public boolean P0() {
    return this.K;
  }
  
  public final void P1() {
    Iterator<l> iterator = this.c.k().iterator();
    while (iterator.hasNext())
      j1(iterator.next()); 
  }
  
  public void Q(boolean paramBoolean1, boolean paramBoolean2) {
    if (paramBoolean2 && this.v instanceof t)
      Q1(new IllegalStateException("Do not call dispatchPictureInPictureModeChanged() on host. Host implements OnPictureInPictureModeChangedProvider and automatically dispatches picture-in-picture mode changes to fragments.")); 
    for (Fragment fragment : this.c.o()) {
      if (fragment != null) {
        fragment.performPictureInPictureModeChanged(paramBoolean1);
        if (paramBoolean2)
          fragment.mChildFragmentManager.Q(paramBoolean1, true); 
      } 
    } 
  }
  
  public final void Q1(RuntimeException paramRuntimeException) {
    r0.d("FragmentManager", paramRuntimeException.getMessage());
    r0.d("FragmentManager", "Activity state:");
    PrintWriter printWriter = new PrintWriter((Writer)new F("FragmentManager"));
    p<?> p1 = this.v;
    if (p1 != null) {
      try {
        p1.h("  ", null, printWriter, new String[0]);
      } catch (Exception exception) {
        r0.e("FragmentManager", "Failed dumping state", exception);
      } 
    } else {
      try {
        Z("  ", null, printWriter, new String[0]);
      } catch (Exception exception) {
        r0.e("FragmentManager", "Failed dumping state", exception);
      } 
    } 
    throw paramRuntimeException;
  }
  
  public boolean R(Menu paramMenu) {
    int i = this.u;
    boolean bool = false;
    if (i < 1)
      return false; 
    for (Fragment fragment : this.c.o()) {
      if (fragment != null && U0(fragment) && fragment.performPrepareOptionsMenu(paramMenu))
        bool = true; 
    } 
    return bool;
  }
  
  public final boolean R0(Fragment paramFragment) {
    boolean bool;
    if ((paramFragment.mHasMenu && paramFragment.mMenuVisible) || paramFragment.mChildFragmentManager.r()) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public void R1(FragmentLifecycleCallbacks paramFragmentLifecycleCallbacks) {
    this.n.p(paramFragmentLifecycleCallbacks);
  }
  
  public void S() {
    S1();
    O(this.y);
  }
  
  public final boolean S0() {
    Fragment fragment = this.x;
    boolean bool = true;
    if (fragment == null)
      return true; 
    if (!fragment.isAdded() || !this.x.getParentFragmentManager().S0())
      bool = false; 
    return bool;
  }
  
  public final void S1() {
    boolean bool;
    ArrayList<o> arrayList = this.a;
    /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{java/util/ArrayList<InnerObjectType{ObjectType{androidx/fragment/app/FragmentManager}.Landroidx/fragment/app/FragmentManager$o;}>}, name=null} */
    try {
      boolean bool1 = this.a.isEmpty();
      bool = true;
      if (!bool1) {
        this.h.m(true);
        /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/util/ArrayList<InnerObjectType{ObjectType{androidx/fragment/app/FragmentManager}.Landroidx/fragment/app/FragmentManager$o;}>}, name=null} */
        return;
      } 
    } finally {
      Exception exception;
    } 
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/util/ArrayList<InnerObjectType{ObjectType{androidx/fragment/app/FragmentManager}.Landroidx/fragment/app/FragmentManager$o;}>}, name=null} */
    E e = this.h;
    if (v0() <= 0 || !V0(this.x))
      bool = false; 
    e.m(bool);
  }
  
  public void T() {
    this.I = false;
    this.J = false;
    this.P.Q(false);
    V(7);
  }
  
  public boolean T0(Fragment paramFragment) {
    return (paramFragment == null) ? false : paramFragment.isHidden();
  }
  
  public void U() {
    this.I = false;
    this.J = false;
    this.P.Q(false);
    V(5);
  }
  
  public boolean U0(Fragment paramFragment) {
    return (paramFragment == null) ? true : paramFragment.isMenuVisible();
  }
  
  public final void V(int paramInt) {
    try {
      this.b = true;
      this.c.d(paramInt);
      g1(paramInt, false);
      Iterator<q> iterator = w().iterator();
      while (iterator.hasNext())
        ((q)iterator.next()).n(); 
    } finally {
      Exception exception;
    } 
    this.b = false;
    d0(true);
  }
  
  public boolean V0(Fragment paramFragment) {
    boolean bool = true;
    if (paramFragment == null)
      return true; 
    FragmentManager fragmentManager = paramFragment.mFragmentManager;
    if (!paramFragment.equals(fragmentManager.H0()) || !V0(fragmentManager.x))
      bool = false; 
    return bool;
  }
  
  public void W() {
    this.J = true;
    this.P.Q(true);
    V(4);
  }
  
  public boolean W0(int paramInt) {
    boolean bool;
    if (this.u >= paramInt) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public void X() {
    V(2);
  }
  
  public boolean X0() {
    return (this.I || this.J);
  }
  
  public final void Y() {
    if (this.L) {
      this.L = false;
      P1();
    } 
  }
  
  public void Z(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString) {
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append(paramString);
    stringBuilder2.append("    ");
    String str = stringBuilder2.toString();
    this.c.e(paramString, paramFileDescriptor, paramPrintWriter, paramArrayOfString);
    ArrayList<Fragment> arrayList2 = this.e;
    byte b1 = 0;
    if (arrayList2 != null) {
      int i = arrayList2.size();
      if (i > 0) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.println("Fragments Created Menus:");
        for (byte b2 = 0; b2 < i; b2++) {
          Fragment fragment = this.e.get(b2);
          paramPrintWriter.print(paramString);
          paramPrintWriter.print("  #");
          paramPrintWriter.print(b2);
          paramPrintWriter.print(": ");
          paramPrintWriter.println(fragment.toString());
        } 
      } 
    } 
    ArrayList<a> arrayList1 = this.d;
    if (arrayList1 != null) {
      int i = arrayList1.size();
      if (i > 0) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.println("Back Stack:");
        for (byte b2 = 0; b2 < i; b2++) {
          a a1 = this.d.get(b2);
          paramPrintWriter.print(paramString);
          paramPrintWriter.print("  #");
          paramPrintWriter.print(b2);
          paramPrintWriter.print(": ");
          paramPrintWriter.println(a1.toString());
          a1.G(str, paramPrintWriter);
        } 
      } 
    } 
    paramPrintWriter.print(paramString);
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append("Back Stack Index: ");
    stringBuilder1.append(this.i.get());
    paramPrintWriter.println(stringBuilder1.toString());
    ArrayList<o> arrayList = this.a;
    /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{java/util/ArrayList<InnerObjectType{ObjectType{androidx/fragment/app/FragmentManager}.Landroidx/fragment/app/FragmentManager$o;}>}, name=null} */
    try {
      int i = this.a.size();
      if (i > 0) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.println("Pending Actions:");
        for (byte b2 = b1; b2 < i; b2++) {
          o o = this.a.get(b2);
          paramPrintWriter.print(paramString);
          paramPrintWriter.print("  #");
          paramPrintWriter.print(b2);
          paramPrintWriter.print(": ");
          paramPrintWriter.println(o);
        } 
      } 
    } finally {}
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/util/ArrayList<InnerObjectType{ObjectType{androidx/fragment/app/FragmentManager}.Landroidx/fragment/app/FragmentManager$o;}>}, name=null} */
    paramPrintWriter.print(paramString);
    paramPrintWriter.println("FragmentManager misc state:");
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("  mHost=");
    paramPrintWriter.println(this.v);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("  mContainer=");
    paramPrintWriter.println(this.w);
    if (this.x != null) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("  mParent=");
      paramPrintWriter.println(this.x);
    } 
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("  mCurState=");
    paramPrintWriter.print(this.u);
    paramPrintWriter.print(" mStateSaved=");
    paramPrintWriter.print(this.I);
    paramPrintWriter.print(" mStopped=");
    paramPrintWriter.print(this.J);
    paramPrintWriter.print(" mDestroyed=");
    paramPrintWriter.println(this.K);
    if (this.H) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("  mNeedMenuInvalidate=");
      paramPrintWriter.println(this.H);
    } 
  }
  
  public final void a0() {
    Iterator<q> iterator = w().iterator();
    while (iterator.hasNext())
      ((q)iterator.next()).n(); 
  }
  
  public void b0(o paramo, boolean paramBoolean) {
    if (!paramBoolean) {
      if (this.v == null) {
        if (this.K)
          throw new IllegalStateException("FragmentManager has been destroyed"); 
        throw new IllegalStateException("FragmentManager has not been attached to a host.");
      } 
      s();
    } 
    ArrayList<o> arrayList = this.a;
    /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{java/util/ArrayList<InnerObjectType{ObjectType{androidx/fragment/app/FragmentManager}.Landroidx/fragment/app/FragmentManager$o;}>}, name=null} */
    try {
      if (this.v == null) {
        if (paramBoolean) {
          /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/util/ArrayList<InnerObjectType{ObjectType{androidx/fragment/app/FragmentManager}.Landroidx/fragment/app/FragmentManager$o;}>}, name=null} */
          return;
        } 
        IllegalStateException illegalStateException = new IllegalStateException();
        this("Activity has been destroyed");
        throw illegalStateException;
      } 
    } finally {}
    this.a.add(paramo);
    H1();
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/util/ArrayList<InnerObjectType{ObjectType{androidx/fragment/app/FragmentManager}.Landroidx/fragment/app/FragmentManager$o;}>}, name=null} */
  }
  
  public final void c0(boolean paramBoolean) {
    if (!this.b) {
      if (this.v == null) {
        if (this.K)
          throw new IllegalStateException("FragmentManager has been destroyed"); 
        throw new IllegalStateException("FragmentManager has not been attached to a host.");
      } 
      if (Looper.myLooper() == this.v.g().getLooper()) {
        if (!paramBoolean)
          s(); 
        if (this.M == null) {
          this.M = new ArrayList<>();
          this.N = new ArrayList<>();
        } 
        return;
      } 
      throw new IllegalStateException("Must be called from main thread of fragment host");
    } 
    throw new IllegalStateException("FragmentManager is already executing transactions");
  }
  
  public boolean d0(boolean paramBoolean) {
    c0(paramBoolean);
    paramBoolean = false;
    while (s0(this.M, this.N)) {
      paramBoolean = true;
      this.b = true;
      try {
        w1(this.M, this.N);
      } finally {
        t();
      } 
    } 
    S1();
    Y();
    this.c.b();
    return paramBoolean;
  }
  
  public void d1(Fragment paramFragment, String[] paramArrayOfString, int paramInt) {
    l l;
    if (this.F != null) {
      l = new l(paramFragment.mWho, paramInt);
      this.G.addLast(l);
      this.F.a(paramArrayOfString);
    } else {
      this.v.k((Fragment)l, paramArrayOfString, paramInt);
    } 
  }
  
  public void e0(o paramo, boolean paramBoolean) {
    if (paramBoolean && (this.v == null || this.K))
      return; 
    c0(paramBoolean);
    if (paramo.a(this.M, this.N)) {
      this.b = true;
      try {
        w1(this.M, this.N);
      } finally {
        t();
      } 
    } 
    S1();
    Y();
    this.c.b();
  }
  
  public void e1(Fragment paramFragment, Intent paramIntent, int paramInt, Bundle paramBundle) {
    l l;
    if (this.D != null) {
      l = new l(paramFragment.mWho, paramInt);
      this.G.addLast(l);
      if (paramBundle != null)
        paramIntent.putExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE", paramBundle); 
      this.D.a(paramIntent);
    } else {
      this.v.m((Fragment)l, paramIntent, paramInt, paramBundle);
    } 
  }
  
  public void f1(Fragment paramFragment, IntentSender paramIntentSender, int paramInt1, Intent paramIntent, int paramInt2, int paramInt3, int paramInt4, Bundle paramBundle) throws IntentSender.SendIntentException {
    IntentSenderRequest intentSenderRequest;
    StringBuilder stringBuilder;
    if (this.E != null) {
      if (paramBundle != null) {
        if (paramIntent == null) {
          paramIntent = new Intent();
          paramIntent.putExtra("androidx.fragment.extra.ACTIVITY_OPTIONS_BUNDLE", true);
        } 
        if (Q0(2)) {
          StringBuilder stringBuilder1 = new StringBuilder();
          stringBuilder1.append("ActivityOptions ");
          stringBuilder1.append(paramBundle);
          stringBuilder1.append(" were added to fillInIntent ");
          stringBuilder1.append(paramIntent);
          stringBuilder1.append(" for fragment ");
          stringBuilder1.append(paramFragment);
          Log.v("FragmentManager", stringBuilder1.toString());
        } 
        paramIntent.putExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE", paramBundle);
      } 
      intentSenderRequest = (new IntentSenderRequest.a(paramIntentSender)).b(paramIntent).c(paramInt3, paramInt2).a();
      l l = new l(paramFragment.mWho, paramInt1);
      this.G.addLast(l);
      if (Q0(2)) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("Fragment ");
        stringBuilder.append(paramFragment);
        stringBuilder.append("is launching an IntentSender for result ");
        Log.v("FragmentManager", stringBuilder.toString());
      } 
      this.E.a(intentSenderRequest);
    } else {
      this.v.n(paramFragment, (IntentSender)intentSenderRequest, paramInt1, (Intent)stringBuilder, paramInt2, paramInt3, paramInt4, paramBundle);
    } 
  }
  
  public final void g0(ArrayList<a> paramArrayList, ArrayList<Boolean> paramArrayList1, int paramInt1, int paramInt2) {
    boolean bool1 = ((a)paramArrayList.get(paramInt1)).r;
    ArrayList<Fragment> arrayList = this.O;
    if (arrayList == null) {
      this.O = new ArrayList<>();
    } else {
      arrayList.clear();
    } 
    this.O.addAll(this.c.o());
    Fragment fragment = H0();
    int i = paramInt1;
    boolean bool = false;
    while (i < paramInt2) {
      a a1 = paramArrayList.get(i);
      if (!((Boolean)paramArrayList1.get(i)).booleanValue()) {
        fragment = a1.K(this.O, fragment);
      } else {
        fragment = a1.M(this.O, fragment);
      } 
      if (bool || a1.i) {
        bool = true;
      } else {
        bool = false;
      } 
      i++;
    } 
    this.O.clear();
    if (!bool1 && this.u >= 1)
      for (i = paramInt1; i < paramInt2; i++) {
        Iterator<o.a> iterator1 = ((a)paramArrayList.get(i)).c.iterator();
        while (iterator1.hasNext()) {
          Fragment fragment1 = ((o.a)iterator1.next()).b;
          if (fragment1 != null && fragment1.mFragmentManager != null) {
            l l = y(fragment1);
            this.c.r(l);
          } 
        } 
      }  
    f0(paramArrayList, paramArrayList1, paramInt1, paramInt2);
    bool1 = ((Boolean)paramArrayList1.get(paramInt2 - 1)).booleanValue();
    if (bool) {
      ArrayList<n> arrayList1 = this.m;
      if (arrayList1 != null && !arrayList1.isEmpty()) {
        LinkedHashSet<Fragment> linkedHashSet = new LinkedHashSet();
        Iterator<a> iterator1 = paramArrayList.iterator();
        while (iterator1.hasNext())
          linkedHashSet.addAll(r0(iterator1.next())); 
        for (n n1 : this.m) {
          Iterator<Fragment> iterator2 = linkedHashSet.iterator();
          while (iterator2.hasNext())
            n1.a(iterator2.next(), bool1); 
        } 
        for (n n1 : this.m) {
          iterator1 = (Iterator)linkedHashSet.iterator();
          while (iterator1.hasNext())
            n1.b((Fragment)iterator1.next(), bool1); 
        } 
      } 
    } 
    for (i = paramInt1; i < paramInt2; i++) {
      a a1 = paramArrayList.get(i);
      if (bool1) {
        for (int k = a1.c.size() - 1; k >= 0; k--) {
          Fragment fragment1 = ((o.a)a1.c.get(k)).b;
          if (fragment1 != null)
            y(fragment1).m(); 
        } 
      } else {
        Iterator<o.a> iterator1 = a1.c.iterator();
        while (iterator1.hasNext()) {
          Fragment fragment1 = ((o.a)iterator1.next()).b;
          if (fragment1 != null)
            y(fragment1).m(); 
        } 
      } 
    } 
    g1(this.u, true);
    Iterator<q> iterator = x(paramArrayList, paramInt1, paramInt2).iterator();
    while (true) {
      i = paramInt1;
      if (iterator.hasNext()) {
        q q = iterator.next();
        q.v(bool1);
        q.t();
        q.k();
        continue;
      } 
      break;
    } 
    while (i < paramInt2) {
      a a1 = paramArrayList.get(i);
      if (((Boolean)paramArrayList1.get(i)).booleanValue() && a1.v >= 0)
        a1.v = -1; 
      a1.L();
      i++;
    } 
    if (bool)
      y1(); 
  }
  
  public void g1(int paramInt, boolean paramBoolean) {
    if (this.v != null || paramInt == -1) {
      if (!paramBoolean && paramInt == this.u)
        return; 
      this.u = paramInt;
      this.c.t();
      P1();
      if (this.H) {
        p<?> p1 = this.v;
        if (p1 != null && this.u == 7) {
          p1.o();
          this.H = false;
        } 
      } 
      return;
    } 
    throw new IllegalStateException("No activity");
  }
  
  public boolean h0() {
    boolean bool = d0(true);
    q0();
    return bool;
  }
  
  public void h1() {
    if (this.v == null)
      return; 
    this.I = false;
    this.J = false;
    this.P.Q(false);
    for (Fragment fragment : this.c.o()) {
      if (fragment != null)
        fragment.noteStateNotSaved(); 
    } 
  }
  
  public void i(a parama) {
    if (this.d == null)
      this.d = new ArrayList<>(); 
    this.d.add(parama);
  }
  
  public Fragment i0(String paramString) {
    return this.c.f(paramString);
  }
  
  public void i1(FragmentContainerView paramFragmentContainerView) {
    for (l l : this.c.k()) {
      Fragment fragment = l.k();
      if (fragment.mContainerId == paramFragmentContainerView.getId()) {
        View view = fragment.mView;
        if (view != null && view.getParent() == null) {
          fragment.mContainer = (ViewGroup)paramFragmentContainerView;
          l.b();
        } 
      } 
    } 
  }
  
  public l j(Fragment paramFragment) {
    String str = paramFragment.mPreviousWho;
    if (str != null)
      dbxyzptlk.L2.b.f(paramFragment, str); 
    if (Q0(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("add: ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    l l = y(paramFragment);
    paramFragment.mFragmentManager = this;
    this.c.r(l);
    if (!paramFragment.mDetached) {
      this.c.a(paramFragment);
      paramFragment.mRemoving = false;
      if (paramFragment.mView == null)
        paramFragment.mHiddenChanged = false; 
      if (R0(paramFragment))
        this.H = true; 
    } 
    return l;
  }
  
  public final int j0(String paramString, int paramInt, boolean paramBoolean) {
    int k;
    ArrayList<a> arrayList = this.d;
    if (arrayList == null || arrayList.isEmpty())
      return -1; 
    if (paramString == null && paramInt < 0)
      return paramBoolean ? 0 : (this.d.size() - 1); 
    int i;
    for (i = this.d.size() - 1; i >= 0; i--) {
      a a1 = this.d.get(i);
      if ((paramString != null && paramString.equals(a1.getName())) || (paramInt >= 0 && paramInt == a1.v))
        break; 
    } 
    if (i < 0)
      return i; 
    if (paramBoolean) {
      while (true) {
        k = i;
        if (i > 0) {
          a a1 = this.d.get(i - 1);
          if (paramString == null || !paramString.equals(a1.getName())) {
            k = i;
            if (paramInt >= 0) {
              k = i;
              if (paramInt == a1.v)
                continue; 
            } 
            break;
          } 
          continue;
        } 
        break;
        i--;
      } 
    } else {
      if (i == this.d.size() - 1)
        return -1; 
      k = i + 1;
    } 
    return k;
  }
  
  public void j1(l paraml) {
    Fragment fragment = paraml.k();
    if (fragment.mDeferStart) {
      if (this.b) {
        this.L = true;
        return;
      } 
      fragment.mDeferStart = false;
      paraml.m();
    } 
  }
  
  public void k(y paramy) {
    this.o.add(paramy);
  }
  
  public void k1() {
    b0((o)new p(this, null, -1, 0), false);
  }
  
  public void l(n paramn) {
    if (this.m == null)
      this.m = new ArrayList<>(); 
    this.m.add(paramn);
  }
  
  public Fragment l0(int paramInt) {
    return this.c.g(paramInt);
  }
  
  public void l1(int paramInt1, int paramInt2) {
    m1(paramInt1, paramInt2, false);
  }
  
  public void m(Fragment paramFragment) {
    this.P.F(paramFragment);
  }
  
  public Fragment m0(String paramString) {
    return this.c.h(paramString);
  }
  
  public void m1(int paramInt1, int paramInt2, boolean paramBoolean) {
    if (paramInt1 >= 0) {
      b0((o)new p(this, null, paramInt1, paramInt2), paramBoolean);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Bad id: ");
    stringBuilder.append(paramInt1);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public int n() {
    return this.i.getAndIncrement();
  }
  
  public Fragment n0(String paramString) {
    return this.c.i(paramString);
  }
  
  public void n1(String paramString, int paramInt) {
    b0((o)new p(this, paramString, -1, paramInt), false);
  }
  
  @SuppressLint({"SyntheticAccessor"})
  public void o(p<?> paramp, n paramn, Fragment paramFragment) {
    if (this.v == null) {
      this.v = paramp;
      this.w = paramn;
      this.x = paramFragment;
      if (paramFragment != null) {
        k(new g(this, paramFragment));
      } else if (paramp instanceof y) {
        k((y)paramp);
      } 
      if (this.x != null)
        S1(); 
      if (paramp instanceof H) {
        Fragment fragment;
        H h1 = (H)paramp;
        OnBackPressedDispatcher onBackPressedDispatcher = h1.getOnBackPressedDispatcher();
        this.g = onBackPressedDispatcher;
        if (paramFragment != null)
          fragment = paramFragment; 
        onBackPressedDispatcher.h(fragment, this.h);
      } 
      if (paramFragment != null) {
        this.P = paramFragment.mFragmentManager.w0(paramFragment);
      } else if (paramp instanceof z) {
        this.P = j.L(((z)paramp).getViewModelStore());
      } else {
        this.P = new j(false);
      } 
      this.P.Q(X0());
      this.c.A(this.P);
      paramp = this.v;
      if (paramp instanceof dbxyzptlk.J4.d && paramFragment == null) {
        androidx.savedstate.a a1 = ((dbxyzptlk.J4.d)paramp).getSavedStateRegistry();
        a1.i("android:support:fragments", (androidx.savedstate.a.c)new w(this));
        Bundle bundle = a1.b("android:support:fragments");
        if (bundle != null)
          B1((Parcelable)bundle); 
      } 
      paramp = this.v;
      if (paramp instanceof dbxyzptlk.h.e) {
        dbxyzptlk.h.d d = ((dbxyzptlk.h.e)paramp).getActivityResultRegistry();
        if (paramFragment != null) {
          StringBuilder stringBuilder1 = new StringBuilder();
          stringBuilder1.append(paramFragment.mWho);
          stringBuilder1.append(":");
          str = stringBuilder1.toString();
        } else {
          str = "";
        } 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("FragmentManager:");
        stringBuilder.append(str);
        String str = stringBuilder.toString();
        stringBuilder = new StringBuilder();
        stringBuilder.append(str);
        stringBuilder.append("StartActivityForResult");
        this.D = d.m(stringBuilder.toString(), (dbxyzptlk.i.a)new dbxyzptlk.i.d(), new h(this));
        stringBuilder = new StringBuilder();
        stringBuilder.append(str);
        stringBuilder.append("StartIntentSenderForResult");
        this.E = d.m(stringBuilder.toString(), new k(), new i(this));
        stringBuilder = new StringBuilder();
        stringBuilder.append(str);
        stringBuilder.append("RequestPermissions");
        this.F = d.m(stringBuilder.toString(), (dbxyzptlk.i.a)new dbxyzptlk.i.b(), new a(this));
      } 
      paramp = this.v;
      if (paramp instanceof dbxyzptlk.V1.e)
        ((dbxyzptlk.V1.e)paramp).addOnConfigurationChangedListener(this.p); 
      paramp = this.v;
      if (paramp instanceof dbxyzptlk.V1.f)
        ((dbxyzptlk.V1.f)paramp).addOnTrimMemoryListener(this.q); 
      paramp = this.v;
      if (paramp instanceof s)
        ((s)paramp).addOnMultiWindowModeChangedListener(this.r); 
      paramp = this.v;
      if (paramp instanceof t)
        ((t)paramp).addOnPictureInPictureModeChangedListener(this.s); 
      paramp = this.v;
      if (paramp instanceof B && paramFragment == null)
        ((B)paramp).addMenuProvider(this.t); 
      return;
    } 
    throw new IllegalStateException("Already attached");
  }
  
  public boolean o1() {
    return r1(null, -1, 0);
  }
  
  public void p(Fragment paramFragment) {
    if (Q0(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("attach: ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    if (paramFragment.mDetached) {
      paramFragment.mDetached = false;
      if (!paramFragment.mAdded) {
        this.c.a(paramFragment);
        if (Q0(2)) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("add from attach: ");
          stringBuilder.append(paramFragment);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
        if (R0(paramFragment))
          this.H = true; 
      } 
    } 
  }
  
  public boolean p1(int paramInt1, int paramInt2) {
    if (paramInt1 >= 0)
      return r1(null, paramInt1, paramInt2); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Bad id: ");
    stringBuilder.append(paramInt1);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public o q() {
    return new a(this);
  }
  
  public final void q0() {
    Iterator<q> iterator = w().iterator();
    while (iterator.hasNext())
      ((q)iterator.next()).o(); 
  }
  
  public boolean q1(String paramString, int paramInt) {
    return r1(paramString, -1, paramInt);
  }
  
  public boolean r() {
    Iterator<Fragment> iterator = this.c.l().iterator();
    boolean bool = false;
    while (iterator.hasNext()) {
      Fragment fragment = iterator.next();
      boolean bool1 = bool;
      if (fragment != null)
        bool1 = R0(fragment); 
      bool = bool1;
      if (bool1)
        return true; 
    } 
    return false;
  }
  
  public final Set<Fragment> r0(a parama) {
    HashSet<Fragment> hashSet = new HashSet();
    for (byte b1 = 0; b1 < parama.c.size(); b1++) {
      Fragment fragment = ((o.a)parama.c.get(b1)).b;
      if (fragment != null && parama.i)
        hashSet.add(fragment); 
    } 
    return hashSet;
  }
  
  public final boolean r1(String paramString, int paramInt1, int paramInt2) {
    d0(false);
    c0(true);
    Fragment fragment = this.y;
    if (fragment != null && paramInt1 < 0 && paramString == null && fragment.getChildFragmentManager().o1())
      return true; 
    boolean bool = s1(this.M, this.N, paramString, paramInt1, paramInt2);
    if (bool) {
      this.b = true;
      try {
        w1(this.M, this.N);
      } finally {
        t();
      } 
    } 
    S1();
    Y();
    this.c.b();
    return bool;
  }
  
  public final void s() {
    if (!X0())
      return; 
    throw new IllegalStateException("Can not perform this action after onSaveInstanceState");
  }
  
  public final boolean s0(ArrayList<a> paramArrayList, ArrayList<Boolean> paramArrayList1) {
    byte b1;
    boolean bool;
    ArrayList<o> arrayList = this.a;
    /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{java/util/ArrayList<InnerObjectType{ObjectType{androidx/fragment/app/FragmentManager}.Landroidx/fragment/app/FragmentManager$o;}>}, name=null} */
    try {
      bool = this.a.isEmpty();
      b1 = 0;
      if (bool) {
        /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/util/ArrayList<InnerObjectType{ObjectType{androidx/fragment/app/FragmentManager}.Landroidx/fragment/app/FragmentManager$o;}>}, name=null} */
        return false;
      } 
    } finally {}
    try {
      int i = this.a.size();
      bool = false;
      while (b1 < i) {
        boolean bool1 = ((o)this.a.get(b1)).a(paramArrayList, paramArrayList1);
        bool |= bool1;
        b1++;
      } 
    } finally {}
    this.a.clear();
    this.v.g().removeCallbacks(this.R);
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/util/ArrayList<InnerObjectType{ObjectType{androidx/fragment/app/FragmentManager}.Landroidx/fragment/app/FragmentManager$o;}>}, name=null} */
    return bool;
  }
  
  public boolean s1(ArrayList<a> paramArrayList, ArrayList<Boolean> paramArrayList1, String paramString, int paramInt1, int paramInt2) {
    boolean bool;
    if ((paramInt2 & 0x1) != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    paramInt2 = j0(paramString, paramInt1, bool);
    if (paramInt2 < 0)
      return false; 
    for (paramInt1 = this.d.size() - 1; paramInt1 >= paramInt2; paramInt1--) {
      paramArrayList.add(this.d.remove(paramInt1));
      paramArrayList1.add(Boolean.TRUE);
    } 
    return true;
  }
  
  public final void t() {
    this.b = false;
    this.N.clear();
    this.M.clear();
  }
  
  public List<Fragment> t0() {
    return this.c.l();
  }
  
  public void t1(Bundle paramBundle, String paramString, Fragment paramFragment) {
    if (paramFragment.mFragmentManager != this) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Fragment ");
      stringBuilder.append(paramFragment);
      stringBuilder.append(" is not currently in the FragmentManager");
      Q1(new IllegalStateException(stringBuilder.toString()));
    } 
    paramBundle.putString(paramString, paramFragment.mWho);
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder(128);
    stringBuilder.append("FragmentManager{");
    stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
    stringBuilder.append(" in ");
    Fragment fragment = this.x;
    if (fragment != null) {
      stringBuilder.append(fragment.getClass().getSimpleName());
      stringBuilder.append("{");
      stringBuilder.append(Integer.toHexString(System.identityHashCode(this.x)));
      stringBuilder.append("}");
    } else {
      p<?> p1 = this.v;
      if (p1 != null) {
        stringBuilder.append(p1.getClass().getSimpleName());
        stringBuilder.append("{");
        stringBuilder.append(Integer.toHexString(System.identityHashCode(this.v)));
        stringBuilder.append("}");
      } else {
        stringBuilder.append("null");
      } 
    } 
    stringBuilder.append("}}");
    return stringBuilder.toString();
  }
  
  public final void u() {
    boolean bool;
    p<?> p1 = this.v;
    if (p1 instanceof z) {
      bool = this.c.p().O();
    } else if (p1.f() instanceof Activity) {
      bool = ((Activity)this.v.f()).isChangingConfigurations() ^ true;
    } else {
      bool = true;
    } 
    if (bool) {
      Iterator iterator = this.j.values().iterator();
      while (iterator.hasNext()) {
        for (String str : ((c)iterator.next()).a)
          this.c.p().H(str, false); 
      } 
    } 
  }
  
  public j u0(int paramInt) {
    return this.d.get(paramInt);
  }
  
  public void u1(FragmentLifecycleCallbacks paramFragmentLifecycleCallbacks, boolean paramBoolean) {
    this.n.o(paramFragmentLifecycleCallbacks, paramBoolean);
  }
  
  public final void v(String paramString) {
    this.k.remove(paramString);
    if (Q0(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Clearing fragment result with key ");
      stringBuilder.append(paramString);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
  }
  
  public int v0() {
    boolean bool;
    ArrayList<a> arrayList = this.d;
    if (arrayList != null) {
      bool = arrayList.size();
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public void v1(Fragment paramFragment) {
    if (Q0(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("remove: ");
      stringBuilder.append(paramFragment);
      stringBuilder.append(" nesting=");
      stringBuilder.append(paramFragment.mBackStackNesting);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    boolean bool = paramFragment.isInBackStack();
    if (!paramFragment.mDetached || !bool) {
      this.c.u(paramFragment);
      if (R0(paramFragment))
        this.H = true; 
      paramFragment.mRemoving = true;
      N1(paramFragment);
    } 
  }
  
  public final Set<q> w() {
    HashSet<q> hashSet = new HashSet();
    Iterator<l> iterator = this.c.k().iterator();
    while (iterator.hasNext()) {
      ViewGroup viewGroup = (((l)iterator.next()).k()).mContainer;
      if (viewGroup != null)
        hashSet.add(q.s(viewGroup, I0())); 
    } 
    return hashSet;
  }
  
  public final j w0(Fragment paramFragment) {
    return this.P.K(paramFragment);
  }
  
  public final void w1(ArrayList<a> paramArrayList, ArrayList<Boolean> paramArrayList1) {
    if (paramArrayList.isEmpty())
      return; 
    if (paramArrayList.size() == paramArrayList1.size()) {
      int m = paramArrayList.size();
      int i = 0;
      int k;
      for (k = 0; i < m; k = i1) {
        int i2 = i;
        int i1 = k;
        if (!((a)paramArrayList.get(i)).r) {
          if (k != i)
            g0(paramArrayList, paramArrayList1, k, i); 
          k = i + 1;
          i1 = k;
          if (((Boolean)paramArrayList1.get(i)).booleanValue())
            while (true) {
              i1 = k;
              if (k < m) {
                i1 = k;
                if (((Boolean)paramArrayList1.get(k)).booleanValue()) {
                  i1 = k;
                  if (!((a)paramArrayList.get(k)).r) {
                    k++;
                    continue;
                  } 
                } 
              } 
              break;
            }  
          g0(paramArrayList, paramArrayList1, i, i1);
          i2 = i1 - 1;
        } 
        i = i2 + 1;
      } 
      if (k != m)
        g0(paramArrayList, paramArrayList1, k, m); 
      return;
    } 
    throw new IllegalStateException("Internal error with the back stack records");
  }
  
  public final Set<q> x(ArrayList<a> paramArrayList, int paramInt1, int paramInt2) {
    HashSet<q> hashSet = new HashSet();
    while (paramInt1 < paramInt2) {
      Iterator<o.a> iterator = ((a)paramArrayList.get(paramInt1)).c.iterator();
      while (iterator.hasNext()) {
        Fragment fragment = ((o.a)iterator.next()).b;
        if (fragment != null) {
          ViewGroup viewGroup = fragment.mContainer;
          if (viewGroup != null)
            hashSet.add(q.r(viewGroup, this)); 
        } 
      } 
      paramInt1++;
    } 
    return hashSet;
  }
  
  public n x0() {
    return this.w;
  }
  
  public void x1(Fragment paramFragment) {
    this.P.P(paramFragment);
  }
  
  public l y(Fragment paramFragment) {
    l l2 = this.c.n(paramFragment.mWho);
    if (l2 != null)
      return l2; 
    l l1 = new l(this.n, this.c, paramFragment);
    l1.o(this.v.f().getClassLoader());
    l1.t(this.u);
    return l1;
  }
  
  public Fragment y0(Bundle paramBundle, String paramString) {
    String str = paramBundle.getString(paramString);
    if (str == null)
      return null; 
    Fragment fragment = i0(str);
    if (fragment == null) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Fragment no longer exists for key ");
      stringBuilder.append(paramString);
      stringBuilder.append(": unique id ");
      stringBuilder.append(str);
      Q1(new IllegalStateException(stringBuilder.toString()));
    } 
    return fragment;
  }
  
  public final void y1() {
    if (this.m != null)
      for (byte b1 = 0; b1 < this.m.size(); b1++)
        ((n)this.m.get(b1)).onBackStackChanged();  
  }
  
  public void z(Fragment paramFragment) {
    if (Q0(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("detach: ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    if (!paramFragment.mDetached) {
      paramFragment.mDetached = true;
      if (paramFragment.mAdded) {
        if (Q0(2)) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("remove from detach: ");
          stringBuilder.append(paramFragment);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
        this.c.u(paramFragment);
        if (R0(paramFragment))
          this.H = true; 
        N1(paramFragment);
      } 
    } 
  }
  
  public final ViewGroup z0(Fragment paramFragment) {
    ViewGroup viewGroup = paramFragment.mContainer;
    if (viewGroup != null)
      return viewGroup; 
    if (paramFragment.mContainerId <= 0)
      return null; 
    if (this.w.d()) {
      View view = this.w.c(paramFragment.mContainerId);
      if (view instanceof ViewGroup)
        return (ViewGroup)view; 
    } 
    return null;
  }
  
  public void z1(String paramString) {
    b0((o)new q(this, paramString), false);
  }
  
  public static abstract class FragmentLifecycleCallbacks {
    @Deprecated
    public void d(FragmentManager param1FragmentManager, Fragment param1Fragment, Bundle param1Bundle) {}
    
    public void e(FragmentManager param1FragmentManager, Fragment param1Fragment, Context param1Context) {}
    
    public void f(FragmentManager param1FragmentManager, Fragment param1Fragment, Bundle param1Bundle) {}
    
    public void g(FragmentManager param1FragmentManager, Fragment param1Fragment) {}
    
    public void h(FragmentManager param1FragmentManager, Fragment param1Fragment) {}
    
    public void i(FragmentManager param1FragmentManager, Fragment param1Fragment) {}
    
    public void j(FragmentManager param1FragmentManager, Fragment param1Fragment, Context param1Context) {}
    
    public void k(FragmentManager param1FragmentManager, Fragment param1Fragment, Bundle param1Bundle) {}
    
    public void l(FragmentManager param1FragmentManager, Fragment param1Fragment) {}
    
    public void m(FragmentManager param1FragmentManager, Fragment param1Fragment, Bundle param1Bundle) {}
    
    public void n(FragmentManager param1FragmentManager, Fragment param1Fragment) {}
    
    public void o(FragmentManager param1FragmentManager, Fragment param1Fragment) {}
    
    public void p(FragmentManager param1FragmentManager, Fragment param1Fragment, View param1View, Bundle param1Bundle) {}
    
    public void q(FragmentManager param1FragmentManager, Fragment param1Fragment) {}
  }
  
  public class a implements dbxyzptlk.h.a<Map<String, Boolean>> {
    public final FragmentManager a;
    
    public a(FragmentManager this$0) {}
    
    @SuppressLint({"SyntheticAccessor"})
    public void a(Map<String, Boolean> param1Map) {
      StringBuilder stringBuilder;
      String[] arrayOfString = (String[])param1Map.keySet().toArray((Object[])new String[0]);
      ArrayList<Boolean> arrayList = new ArrayList(param1Map.values());
      int[] arrayOfInt = new int[arrayList.size()];
      int i;
      for (i = 0; i < arrayList.size(); i++) {
        byte b;
        if (((Boolean)arrayList.get(i)).booleanValue()) {
          b = 0;
        } else {
          b = -1;
        } 
        arrayOfInt[i] = b;
      } 
      FragmentManager.l l = this.a.G.pollFirst();
      if (l == null) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("No permissions were requested for ");
        stringBuilder1.append(this);
        r0.f("FragmentManager", stringBuilder1.toString());
        return;
      } 
      String str = l.a;
      i = l.b;
      Fragment fragment = FragmentManager.h(this.a).i(str);
      if (fragment == null) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("Permission request result delivered for unknown Fragment ");
        stringBuilder.append(str);
        r0.f("FragmentManager", stringBuilder.toString());
        return;
      } 
      fragment.onRequestPermissionsResult(i, (String[])stringBuilder, arrayOfInt);
    }
  }
  
  public class b extends E {
    public final FragmentManager d;
    
    public b(FragmentManager this$0, boolean param1Boolean) {
      super(param1Boolean);
    }
    
    public void g() {
      this.d.M0();
    }
  }
  
  public class c implements G {
    public final FragmentManager a;
    
    public c(FragmentManager this$0) {}
    
    public void a(Menu param1Menu, MenuInflater param1MenuInflater) {
      this.a.F(param1Menu, param1MenuInflater);
    }
    
    public void b(Menu param1Menu) {
      this.a.N(param1Menu);
    }
    
    public void c(Menu param1Menu) {
      this.a.R(param1Menu);
    }
    
    public boolean d(MenuItem param1MenuItem) {
      return this.a.M(param1MenuItem);
    }
  }
  
  public class d extends f {
    public final FragmentManager b;
    
    public d(FragmentManager this$0) {}
    
    public Fragment a(ClassLoader param1ClassLoader, String param1String) {
      return this.b.D0().b(this.b.D0().f(), param1String, null);
    }
  }
  
  public class e implements J {
    public final FragmentManager a;
    
    public e(FragmentManager this$0) {}
    
    public q a(ViewGroup param1ViewGroup) {
      return new d(param1ViewGroup);
    }
  }
  
  public class f implements Runnable {
    public final FragmentManager a;
    
    public f(FragmentManager this$0) {}
    
    public void run() {
      this.a.d0(true);
    }
  }
  
  public class g implements y {
    public final Fragment a;
    
    public final FragmentManager b;
    
    public g(FragmentManager this$0, Fragment param1Fragment) {}
    
    public void a(FragmentManager param1FragmentManager, Fragment param1Fragment) {
      this.a.onAttachFragment(param1Fragment);
    }
  }
  
  public class h implements dbxyzptlk.h.a<ActivityResult> {
    public final FragmentManager a;
    
    public h(FragmentManager this$0) {}
    
    public void a(ActivityResult param1ActivityResult) {
      StringBuilder stringBuilder;
      FragmentManager.l l = this.a.G.pollLast();
      if (l == null) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("No Activities were started for result for ");
        stringBuilder.append(this);
        r0.f("FragmentManager", stringBuilder.toString());
        return;
      } 
      String str = l.a;
      int i = l.b;
      Fragment fragment = FragmentManager.h(this.a).i(str);
      if (fragment == null) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("Activity result delivered for unknown Fragment ");
        stringBuilder.append(str);
        r0.f("FragmentManager", stringBuilder.toString());
        return;
      } 
      fragment.onActivityResult(i, stringBuilder.b(), stringBuilder.a());
    }
  }
  
  public class i implements dbxyzptlk.h.a<ActivityResult> {
    public final FragmentManager a;
    
    public i(FragmentManager this$0) {}
    
    public void a(ActivityResult param1ActivityResult) {
      StringBuilder stringBuilder;
      FragmentManager.l l = this.a.G.pollFirst();
      if (l == null) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("No IntentSenders were started for ");
        stringBuilder.append(this);
        r0.f("FragmentManager", stringBuilder.toString());
        return;
      } 
      String str = l.a;
      int j = l.b;
      Fragment fragment = FragmentManager.h(this.a).i(str);
      if (fragment == null) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("Intent Sender result delivered for unknown Fragment ");
        stringBuilder.append(str);
        r0.f("FragmentManager", stringBuilder.toString());
        return;
      } 
      fragment.onActivityResult(j, stringBuilder.b(), stringBuilder.a());
    }
  }
  
  public static interface j {
    int getId();
    
    String getName();
  }
  
  public static class k extends dbxyzptlk.i.a<IntentSenderRequest, ActivityResult> {
    public Intent a(Context param1Context, IntentSenderRequest param1IntentSenderRequest) {
      Intent intent1 = new Intent("androidx.activity.result.contract.action.INTENT_SENDER_REQUEST");
      Intent intent2 = param1IntentSenderRequest.a();
      IntentSenderRequest intentSenderRequest = param1IntentSenderRequest;
      if (intent2 != null) {
        Bundle bundle = intent2.getBundleExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE");
        intentSenderRequest = param1IntentSenderRequest;
        if (bundle != null) {
          intent1.putExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE", bundle);
          intent2.removeExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE");
          intentSenderRequest = param1IntentSenderRequest;
          if (intent2.getBooleanExtra("androidx.fragment.extra.ACTIVITY_OPTIONS_BUNDLE", false))
            intentSenderRequest = (new IntentSenderRequest.a(param1IntentSenderRequest.d())).b(null).c(param1IntentSenderRequest.c(), param1IntentSenderRequest.b()).a(); 
        } 
      } 
      intent1.putExtra("androidx.activity.result.contract.extra.INTENT_SENDER_REQUEST", (Parcelable)intentSenderRequest);
      if (FragmentManager.Q0(2)) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("CreateIntent created the following intent: ");
        stringBuilder.append(intent1);
        Log.v("FragmentManager", stringBuilder.toString());
      } 
      return intent1;
    }
    
    public ActivityResult b(int param1Int, Intent param1Intent) {
      return new ActivityResult(param1Int, param1Intent);
    }
  }
  
  class FragmentManager {}
  
  class FragmentManager {}
  
  class FragmentManager {}
  
  public static interface o {
    boolean a(ArrayList<a> param1ArrayList, ArrayList<Boolean> param1ArrayList1);
  }
  
  class FragmentManager {}
  
  class FragmentManager {}
  
  class FragmentManager {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\fragment\app\FragmentManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */