package androidx.fragment.app;

import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import dbxyzptlk.DI.s;
import dbxyzptlk.K2.G;
import dbxyzptlk.K2.H;
import dbxyzptlk.K2.I;
import dbxyzptlk.K2.J;
import dbxyzptlk.d2.e;
import dbxyzptlk.h2.h0;
import dbxyzptlk.pI.D;
import dbxyzptlk.qI.A;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.ListIterator;
import java.util.Set;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

@Metadata(d1 = {"\000P\n\002\030\002\n\002\020\000\n\002\030\002\n\002\b\003\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\006\n\002\020\013\n\002\b\b\n\002\020 \n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\f\n\002\020!\n\002\b\n\b \030\000 \0162\0020\001:\003+0(B\017\022\006\020\003\032\0020\002¢\006\004\b\004\020\005J\027\020\t\032\004\030\0010\b2\006\020\007\032\0020\006¢\006\004\b\t\020\nJ\035\020\016\032\0020\r2\006\020\f\032\0020\0132\006\020\007\032\0020\006¢\006\004\b\016\020\017J\025\020\020\032\0020\r2\006\020\007\032\0020\006¢\006\004\b\020\020\021J\025\020\022\032\0020\r2\006\020\007\032\0020\006¢\006\004\b\022\020\021J\025\020\023\032\0020\r2\006\020\007\032\0020\006¢\006\004\b\023\020\021J\025\020\026\032\0020\r2\006\020\025\032\0020\024¢\006\004\b\026\020\027J\r\020\030\032\0020\r¢\006\004\b\030\020\031J\r\020\032\032\0020\r¢\006\004\b\032\020\031J\r\020\033\032\0020\r¢\006\004\b\033\020\031J\r\020\034\032\0020\r¢\006\004\b\034\020\031J%\020 \032\0020\r2\f\020\037\032\b\022\004\022\0020\0360\0352\006\020\025\032\0020\024H&¢\006\004\b \020!J\031\020$\032\004\030\0010\0362\006\020#\032\0020\"H\002¢\006\004\b$\020%J\031\020&\032\004\030\0010\0362\006\020#\032\0020\"H\002¢\006\004\b&\020%J'\020(\032\0020\r2\006\020\f\032\0020\0132\006\020'\032\0020\b2\006\020\007\032\0020\006H\002¢\006\004\b(\020)J\017\020*\032\0020\rH\002¢\006\004\b*\020\031R\027\020\003\032\0020\0028\006¢\006\f\n\004\b+\020,\032\004\b-\020.R\032\0202\032\b\022\004\022\0020\0360/8\002X\004¢\006\006\n\004\b0\0201R\032\0203\032\b\022\004\022\0020\0360/8\002X\004¢\006\006\n\004\b(\0201R\026\0206\032\0020\0248\002@\002X\016¢\006\006\n\004\b4\0205R\026\0208\032\0020\0248\002@\002X\016¢\006\006\n\004\b7\0205¨\0069"}, d2 = {"Landroidx/fragment/app/q;", "", "Landroid/view/ViewGroup;", "container", "<init>", "(Landroid/view/ViewGroup;)V", "Landroidx/fragment/app/l;", "fragmentStateManager", "Landroidx/fragment/app/q$c$a;", "p", "(Landroidx/fragment/app/l;)Landroidx/fragment/app/q$c$a;", "Landroidx/fragment/app/q$c$b;", "finalState", "Ldbxyzptlk/pI/D;", "f", "(Landroidx/fragment/app/q$c$b;Landroidx/fragment/app/l;)V", "i", "(Landroidx/fragment/app/l;)V", "g", "h", "", "isPop", "v", "(Z)V", "t", "()V", "o", "k", "n", "", "Landroidx/fragment/app/q$c;", "operations", "j", "(Ljava/util/List;Z)V", "Landroidx/fragment/app/Fragment;", "fragment", "l", "(Landroidx/fragment/app/Fragment;)Landroidx/fragment/app/q$c;", "m", "lifecycleImpact", "c", "(Landroidx/fragment/app/q$c$b;Landroidx/fragment/app/q$c$a;Landroidx/fragment/app/l;)V", "u", "a", "Landroid/view/ViewGroup;", "q", "()Landroid/view/ViewGroup;", "", "b", "Ljava/util/List;", "pendingOperations", "runningOperations", "d", "Z", "operationDirectionIsPop", "e", "isContainerPostponed", "fragment_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public abstract class q {
  public static final a f = new a(null);
  
  public final ViewGroup a;
  
  public final List<c> b;
  
  public final List<c> c;
  
  public boolean d;
  
  public boolean e;
  
  public q(ViewGroup paramViewGroup) {
    this.a = paramViewGroup;
    this.b = new ArrayList<>();
    this.c = new ArrayList<>();
  }
  
  public static final void d(q paramq, b paramb) {
    s.h(paramq, "this$0");
    s.h(paramb, "$operation");
    if (paramq.b.contains(paramb)) {
      c.b b1 = paramb.g();
      View view = (paramb.h()).mView;
      s.g(view, "operation.fragment.mView");
      b1.applyState(view);
    } 
  }
  
  public static final void e(q paramq, b paramb) {
    s.h(paramq, "this$0");
    s.h(paramb, "$operation");
    paramq.b.remove(paramb);
    paramq.c.remove(paramb);
  }
  
  public static final q r(ViewGroup paramViewGroup, FragmentManager paramFragmentManager) {
    return f.a(paramViewGroup, paramFragmentManager);
  }
  
  public static final q s(ViewGroup paramViewGroup, J paramJ) {
    return f.b(paramViewGroup, paramJ);
  }
  
  public final void c(c.b paramb, c.a parama, l paraml) {
    List<c> list = this.b;
    /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{java/util/List<InnerObjectType{ObjectType{androidx/fragment/app/q}.Landroidx/fragment/app/q$c;}>}, name=null} */
    try {
      e = new e();
      this();
      Fragment fragment = paraml.k();
      s.g(fragment, "fragmentStateManager.fragment");
      c c = l(fragment);
      if (c != null) {
        c.m(paramb, parama);
        /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/util/List<InnerObjectType{ObjectType{androidx/fragment/app/q}.Landroidx/fragment/app/q$c;}>}, name=null} */
        return;
      } 
    } finally {}
    b b1 = new b();
    this(paramb, parama, paraml, e);
    e e;
    this.b.add(b1);
    G g = new G();
    this(this, b1);
    b1.c((Runnable)g);
    H h = new H();
    this(this, b1);
    b1.c((Runnable)h);
    D d = D.a;
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/util/List<InnerObjectType{ObjectType{androidx/fragment/app/q}.Landroidx/fragment/app/q$c;}>}, name=null} */
  }
  
  public final void f(c.b paramb, l paraml) {
    s.h(paramb, "finalState");
    s.h(paraml, "fragmentStateManager");
    if (FragmentManager.Q0(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("SpecialEffectsController: Enqueuing add operation for fragment ");
      stringBuilder.append(paraml.k());
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    c(paramb, c.a.ADDING, paraml);
  }
  
  public final void g(l paraml) {
    s.h(paraml, "fragmentStateManager");
    if (FragmentManager.Q0(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("SpecialEffectsController: Enqueuing hide operation for fragment ");
      stringBuilder.append(paraml.k());
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    c(c.b.GONE, c.a.NONE, paraml);
  }
  
  public final void h(l paraml) {
    s.h(paraml, "fragmentStateManager");
    if (FragmentManager.Q0(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("SpecialEffectsController: Enqueuing remove operation for fragment ");
      stringBuilder.append(paraml.k());
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    c(c.b.REMOVED, c.a.REMOVING, paraml);
  }
  
  public final void i(l paraml) {
    s.h(paraml, "fragmentStateManager");
    if (FragmentManager.Q0(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("SpecialEffectsController: Enqueuing show operation for fragment ");
      stringBuilder.append(paraml.k());
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    c(c.b.VISIBLE, c.a.NONE, paraml);
  }
  
  public abstract void j(List<c> paramList, boolean paramBoolean);
  
  public final void k() {
    if (this.e)
      return; 
    if (!h0.T((View)this.a)) {
      n();
      this.d = false;
      return;
    } 
    List<c> list = this.b;
    /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{java/util/List<InnerObjectType{ObjectType{androidx/fragment/app/q}.Landroidx/fragment/app/q$c;}>}, name=null} */
    try {
      if (!this.b.isEmpty()) {
        List list1 = A.o1(this.c);
        this.c.clear();
        for (c c : list1) {
          if (FragmentManager.Q0(2)) {
            StringBuilder stringBuilder = new StringBuilder();
            this();
            stringBuilder.append("SpecialEffectsController: Cancelling operation ");
            stringBuilder.append(c);
            Log.v("FragmentManager", stringBuilder.toString());
          } 
          c.d();
          if (!c.k())
            this.c.add(c); 
        } 
        u();
        List<? extends c> list2 = A.o1(this.b);
        this.b.clear();
        this.c.addAll(list2);
        if (FragmentManager.Q0(2))
          Log.v("FragmentManager", "SpecialEffectsController: Executing pending operations"); 
        Iterator<? extends c> iterator = list2.iterator();
        while (iterator.hasNext())
          ((c)iterator.next()).n(); 
        j((List)list2, this.d);
        this.d = false;
        if (FragmentManager.Q0(2))
          Log.v("FragmentManager", "SpecialEffectsController: Finished executing pending operations"); 
      } 
    } finally {
      Exception exception;
    } 
    D d = D.a;
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/util/List<InnerObjectType{ObjectType{androidx/fragment/app/q}.Landroidx/fragment/app/q$c;}>}, name=null} */
  }
  
  public final c l(Fragment paramFragment) {
    // Byte code:
    //   0: aload_0
    //   1: getfield b : Ljava/util/List;
    //   4: checkcast java/lang/Iterable
    //   7: invokeinterface iterator : ()Ljava/util/Iterator;
    //   12: astore_3
    //   13: aload_3
    //   14: invokeinterface hasNext : ()Z
    //   19: ifeq -> 60
    //   22: aload_3
    //   23: invokeinterface next : ()Ljava/lang/Object;
    //   28: astore_2
    //   29: aload_2
    //   30: checkcast androidx/fragment/app/q$c
    //   33: astore #4
    //   35: aload #4
    //   37: invokevirtual h : ()Landroidx/fragment/app/Fragment;
    //   40: aload_1
    //   41: invokestatic c : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   44: ifeq -> 13
    //   47: aload #4
    //   49: invokevirtual j : ()Z
    //   52: ifne -> 13
    //   55: aload_2
    //   56: astore_1
    //   57: goto -> 62
    //   60: aconst_null
    //   61: astore_1
    //   62: aload_1
    //   63: checkcast androidx/fragment/app/q$c
    //   66: areturn
  }
  
  public final c m(Fragment paramFragment) {
    // Byte code:
    //   0: aload_0
    //   1: getfield c : Ljava/util/List;
    //   4: checkcast java/lang/Iterable
    //   7: invokeinterface iterator : ()Ljava/util/Iterator;
    //   12: astore_3
    //   13: aload_3
    //   14: invokeinterface hasNext : ()Z
    //   19: ifeq -> 60
    //   22: aload_3
    //   23: invokeinterface next : ()Ljava/lang/Object;
    //   28: astore_2
    //   29: aload_2
    //   30: checkcast androidx/fragment/app/q$c
    //   33: astore #4
    //   35: aload #4
    //   37: invokevirtual h : ()Landroidx/fragment/app/Fragment;
    //   40: aload_1
    //   41: invokestatic c : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   44: ifeq -> 13
    //   47: aload #4
    //   49: invokevirtual j : ()Z
    //   52: ifne -> 13
    //   55: aload_2
    //   56: astore_1
    //   57: goto -> 62
    //   60: aconst_null
    //   61: astore_1
    //   62: aload_1
    //   63: checkcast androidx/fragment/app/q$c
    //   66: areturn
  }
  
  public final void n() {
    if (FragmentManager.Q0(2))
      Log.v("FragmentManager", "SpecialEffectsController: Forcing all operations to complete"); 
    boolean bool = h0.T((View)this.a);
    List<c> list = this.b;
    /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{java/util/List<InnerObjectType{ObjectType{androidx/fragment/app/q}.Landroidx/fragment/app/q$c;}>}, name=null} */
    try {
      u();
      Iterator<c> iterator = this.b.iterator();
      while (iterator.hasNext())
        ((c)iterator.next()).n(); 
    } finally {
      Exception exception;
    } 
    for (c c : A.o1(this.c)) {
      if (FragmentManager.Q0(2)) {
        String str;
        if (bool) {
          str = "";
        } else {
          StringBuilder stringBuilder1 = new StringBuilder();
          this();
          stringBuilder1.append("Container ");
          stringBuilder1.append(this.a);
          stringBuilder1.append(" is not attached to window. ");
          str = stringBuilder1.toString();
        } 
        StringBuilder stringBuilder = new StringBuilder();
        this();
        stringBuilder.append("SpecialEffectsController: ");
        stringBuilder.append(str);
        stringBuilder.append("Cancelling running operation ");
        stringBuilder.append(c);
        Log.v("FragmentManager", stringBuilder.toString());
      } 
      c.d();
    } 
    for (c c : A.o1(this.b)) {
      if (FragmentManager.Q0(2)) {
        String str;
        if (bool) {
          str = "";
        } else {
          StringBuilder stringBuilder1 = new StringBuilder();
          this();
          stringBuilder1.append("Container ");
          stringBuilder1.append(this.a);
          stringBuilder1.append(" is not attached to window. ");
          str = stringBuilder1.toString();
        } 
        StringBuilder stringBuilder = new StringBuilder();
        this();
        stringBuilder.append("SpecialEffectsController: ");
        stringBuilder.append(str);
        stringBuilder.append("Cancelling pending operation ");
        stringBuilder.append(c);
        Log.v("FragmentManager", stringBuilder.toString());
      } 
      c.d();
    } 
    D d = D.a;
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/util/List<InnerObjectType{ObjectType{androidx/fragment/app/q}.Landroidx/fragment/app/q$c;}>}, name=null} */
  }
  
  public final void o() {
    if (this.e) {
      if (FragmentManager.Q0(2))
        Log.v("FragmentManager", "SpecialEffectsController: Forcing postponed operations"); 
      this.e = false;
      k();
    } 
  }
  
  public final c.a p(l paraml) {
    c.a a1;
    int i;
    s.h(paraml, "fragmentStateManager");
    Fragment fragment = paraml.k();
    s.g(fragment, "fragmentStateManager.fragment");
    c c1 = l(fragment);
    c.a a2 = null;
    if (c1 != null) {
      a1 = c1.i();
    } else {
      c1 = null;
    } 
    c c2 = m(fragment);
    if (c2 != null)
      a2 = c2.i(); 
    if (c1 == null) {
      i = -1;
    } else {
      i = d.a[c1.ordinal()];
    } 
    if (i == -1 || i == 1)
      a1 = a2; 
    return a1;
  }
  
  public final ViewGroup q() {
    return this.a;
  }
  
  public final void t() {
    boolean bool;
    Fragment fragment;
    Exception exception2;
    List<c> list = this.b;
    /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{java/util/List<InnerObjectType{ObjectType{androidx/fragment/app/q}.Landroidx/fragment/app/q$c;}>}, name=null} */
    try {
      u();
      List<c> list1 = this.b;
      ListIterator<c> listIterator = list1.listIterator(list1.size());
      while (true) {
        bool = listIterator.hasPrevious();
        exception2 = null;
        if (bool) {
          list1 = (List<c>)listIterator.previous();
          c c1 = (c)list1;
          c.b.a a1 = c.b.Companion;
          View view = (c1.h()).mView;
          s.g(view, "operation.fragment.mView");
          c.b b1 = a1.a(view);
          c.b b3 = c1.g();
          c.b b2 = c.b.VISIBLE;
          if (b3 == b2 && b1 != b2)
            break; 
          continue;
        } 
        list1 = null;
        break;
      } 
    } finally {}
    c c = (c)exception1;
    Exception exception1 = exception2;
    if (c != null)
      fragment = c.h(); 
    if (fragment != null) {
      bool = fragment.isPostponed();
    } else {
      bool = false;
    } 
    this.e = bool;
    D d = D.a;
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/util/List<InnerObjectType{ObjectType{androidx/fragment/app/q}.Landroidx/fragment/app/q$c;}>}, name=null} */
  }
  
  public final void u() {
    for (c c : this.b) {
      if (c.i() == c.a.ADDING) {
        View view = c.h().requireView();
        s.g(view, "fragment.requireView()");
        c.m(c.b.Companion.b(view.getVisibility()), c.a.NONE);
      } 
    } 
  }
  
  public final void v(boolean paramBoolean) {
    this.d = paramBoolean;
  }
  
  @Metadata(d1 = {"\000(\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\004\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\037\020\t\032\0020\b2\006\020\005\032\0020\0042\006\020\007\032\0020\006H\007¢\006\004\b\t\020\nJ\037\020\r\032\0020\b2\006\020\005\032\0020\0042\006\020\f\032\0020\013H\007¢\006\004\b\r\020\016¨\006\017"}, d2 = {"Landroidx/fragment/app/q$a;", "", "<init>", "()V", "Landroid/view/ViewGroup;", "container", "Landroidx/fragment/app/FragmentManager;", "fragmentManager", "Landroidx/fragment/app/q;", "a", "(Landroid/view/ViewGroup;Landroidx/fragment/app/FragmentManager;)Landroidx/fragment/app/q;", "Ldbxyzptlk/K2/J;", "factory", "b", "(Landroid/view/ViewGroup;Ldbxyzptlk/K2/J;)Landroidx/fragment/app/q;", "fragment_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class a {
    public a() {}
    
    public final q a(ViewGroup param1ViewGroup, FragmentManager param1FragmentManager) {
      s.h(param1ViewGroup, "container");
      s.h(param1FragmentManager, "fragmentManager");
      J j = param1FragmentManager.I0();
      s.g(j, "fragmentManager.specialEffectsControllerFactory");
      return b(param1ViewGroup, j);
    }
    
    public final q b(ViewGroup param1ViewGroup, J param1J) {
      s.h(param1ViewGroup, "container");
      s.h(param1J, "factory");
      Object object = param1ViewGroup.getTag(dbxyzptlk.J2.b.special_effects_controller_view_tag);
      if (object instanceof q)
        return (q)object; 
      q q = param1J.a(param1ViewGroup);
      s.g(q, "factory.createController(container)");
      param1ViewGroup.setTag(dbxyzptlk.J2.b.special_effects_controller_view_tag, q);
      return q;
    }
  }
  
  @Metadata(d1 = {"\000*\n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\006\b\002\030\0002\0020\001B'\022\006\020\003\032\0020\002\022\006\020\005\032\0020\004\022\006\020\007\032\0020\006\022\006\020\t\032\0020\b¢\006\004\b\n\020\013J\017\020\r\032\0020\fH\026¢\006\004\b\r\020\016J\017\020\017\032\0020\fH\026¢\006\004\b\017\020\016R\024\020\007\032\0020\0068\002X\004¢\006\006\n\004\b\020\020\021¨\006\022"}, d2 = {"Landroidx/fragment/app/q$b;", "Landroidx/fragment/app/q$c;", "Landroidx/fragment/app/q$c$b;", "finalState", "Landroidx/fragment/app/q$c$a;", "lifecycleImpact", "Landroidx/fragment/app/l;", "fragmentStateManager", "Ldbxyzptlk/d2/e;", "cancellationSignal", "<init>", "(Landroidx/fragment/app/q$c$b;Landroidx/fragment/app/q$c$a;Landroidx/fragment/app/l;Ldbxyzptlk/d2/e;)V", "Ldbxyzptlk/pI/D;", "n", "()V", "e", "h", "Landroidx/fragment/app/l;", "fragment_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class b extends c {
    public final l h;
    
    public b(q.c.b param1b, q.c.a param1a, l param1l, e param1e) {
      super(param1b, param1a, fragment, param1e);
      this.h = param1l;
    }
    
    public void e() {
      super.e();
      this.h.m();
    }
    
    public void n() {
      if (i() == q.c.a.ADDING) {
        Fragment fragment = this.h.k();
        s.g(fragment, "fragmentStateManager.fragment");
        View view2 = fragment.mView.findFocus();
        if (view2 != null) {
          fragment.setFocusedView(view2);
          if (FragmentManager.Q0(2)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("requestFocus: Saved focused view ");
            stringBuilder.append(view2);
            stringBuilder.append(" for Fragment ");
            stringBuilder.append(fragment);
            Log.v("FragmentManager", stringBuilder.toString());
          } 
        } 
        View view1 = h().requireView();
        s.g(view1, "this.fragment.requireView()");
        if (view1.getParent() == null) {
          this.h.b();
          view1.setAlpha(0.0F);
        } 
        if (view1.getAlpha() == 0.0F && view1.getVisibility() == 0)
          view1.setVisibility(4); 
        view1.setAlpha(fragment.getPostOnViewCreatedAlpha());
      } else if (i() == q.c.a.REMOVING) {
        Fragment fragment = this.h.k();
        s.g(fragment, "fragmentStateManager.fragment");
        View view = fragment.requireView();
        s.g(view, "fragment.requireView()");
        if (FragmentManager.Q0(2)) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Clearing focus ");
          stringBuilder.append(view.findFocus());
          stringBuilder.append(" on view ");
          stringBuilder.append(view);
          stringBuilder.append(" for Fragment ");
          stringBuilder.append(fragment);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
        view.clearFocus();
      } 
    }
  }
  
  @Metadata(d1 = {"\000R\n\002\030\002\n\002\020\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\020\016\n\002\b\002\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\030\n\002\020!\n\002\b\002\n\002\020#\n\002\b\002\n\002\020\013\n\002\b\b\b\020\030\0002\0020\001:\002\036$B'\022\006\020\003\032\0020\002\022\006\020\005\032\0020\004\022\006\020\007\032\0020\006\022\006\020\t\032\0020\b¢\006\004\b\n\020\013J\017\020\r\032\0020\fH\026¢\006\004\b\r\020\016J\r\020\020\032\0020\017¢\006\004\b\020\020\021J\035\020\022\032\0020\0172\006\020\003\032\0020\0022\006\020\005\032\0020\004¢\006\004\b\022\020\023J\025\020\026\032\0020\0172\006\020\025\032\0020\024¢\006\004\b\026\020\027J\017\020\030\032\0020\017H\026¢\006\004\b\030\020\021J\025\020\032\032\0020\0172\006\020\031\032\0020\b¢\006\004\b\032\020\033J\025\020\034\032\0020\0172\006\020\031\032\0020\b¢\006\004\b\034\020\033J\017\020\035\032\0020\017H\027¢\006\004\b\035\020\021R\"\020\003\032\0020\0028\006@\006X\016¢\006\022\n\004\b\036\020\037\032\004\b \020!\"\004\b\"\020#R\"\020\005\032\0020\0048\006@\006X\016¢\006\022\n\004\b$\020%\032\004\b&\020'\"\004\b(\020)R\027\020\007\032\0020\0068\006¢\006\f\n\004\b\026\020*\032\004\b+\020,R\032\020/\032\b\022\004\022\0020\0240-8\002X\004¢\006\006\n\004\b\020\020.R\032\0202\032\b\022\004\022\0020\b008\002X\004¢\006\006\n\004\b\035\0201R$\0208\032\002032\006\0204\032\002038\006@BX\016¢\006\f\n\004\b\034\0205\032\004\b6\0207R$\020:\032\002032\006\0204\032\002038\006@BX\016¢\006\f\n\004\b \0205\032\004\b9\0207¨\006;"}, d2 = {"Landroidx/fragment/app/q$c;", "", "Landroidx/fragment/app/q$c$b;", "finalState", "Landroidx/fragment/app/q$c$a;", "lifecycleImpact", "Landroidx/fragment/app/Fragment;", "fragment", "Ldbxyzptlk/d2/e;", "cancellationSignal", "<init>", "(Landroidx/fragment/app/q$c$b;Landroidx/fragment/app/q$c$a;Landroidx/fragment/app/Fragment;Ldbxyzptlk/d2/e;)V", "", "toString", "()Ljava/lang/String;", "Ldbxyzptlk/pI/D;", "d", "()V", "m", "(Landroidx/fragment/app/q$c$b;Landroidx/fragment/app/q$c$a;)V", "Ljava/lang/Runnable;", "listener", "c", "(Ljava/lang/Runnable;)V", "n", "signal", "l", "(Ldbxyzptlk/d2/e;)V", "f", "e", "a", "Landroidx/fragment/app/q$c$b;", "g", "()Landroidx/fragment/app/q$c$b;", "setFinalState", "(Landroidx/fragment/app/q$c$b;)V", "b", "Landroidx/fragment/app/q$c$a;", "i", "()Landroidx/fragment/app/q$c$a;", "setLifecycleImpact", "(Landroidx/fragment/app/q$c$a;)V", "Landroidx/fragment/app/Fragment;", "h", "()Landroidx/fragment/app/Fragment;", "", "Ljava/util/List;", "completionListeners", "", "Ljava/util/Set;", "specialEffectsSignals", "", "<set-?>", "Z", "j", "()Z", "isCanceled", "k", "isComplete", "fragment_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static class c {
    public b a;
    
    public a b;
    
    public final Fragment c;
    
    public final List<Runnable> d;
    
    public final Set<e> e;
    
    public boolean f;
    
    public boolean g;
    
    public c(b param1b, a param1a, Fragment param1Fragment, e param1e) {
      this.a = param1b;
      this.b = param1a;
      this.c = param1Fragment;
      this.d = new ArrayList<>();
      this.e = new LinkedHashSet<>();
      param1e.c((e.a)new I(this));
    }
    
    public static final void b(c param1c) {
      s.h(param1c, "this$0");
      param1c.d();
    }
    
    public final void c(Runnable param1Runnable) {
      s.h(param1Runnable, "listener");
      this.d.add(param1Runnable);
    }
    
    public final void d() {
      if (this.f)
        return; 
      this.f = true;
      if (this.e.isEmpty()) {
        e();
      } else {
        Iterator<e> iterator = A.p1(this.e).iterator();
        while (iterator.hasNext())
          ((e)iterator.next()).a(); 
      } 
    }
    
    public void e() {
      if (this.g)
        return; 
      if (FragmentManager.Q0(2)) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("SpecialEffectsController: ");
        stringBuilder.append(this);
        stringBuilder.append(" has called complete.");
        Log.v("FragmentManager", stringBuilder.toString());
      } 
      this.g = true;
      Iterator<Runnable> iterator = this.d.iterator();
      while (iterator.hasNext())
        ((Runnable)iterator.next()).run(); 
    }
    
    public final void f(e param1e) {
      s.h(param1e, "signal");
      if (this.e.remove(param1e) && this.e.isEmpty())
        e(); 
    }
    
    public final b g() {
      return this.a;
    }
    
    public final Fragment h() {
      return this.c;
    }
    
    public final a i() {
      return this.b;
    }
    
    public final boolean j() {
      return this.f;
    }
    
    public final boolean k() {
      return this.g;
    }
    
    public final void l(e param1e) {
      s.h(param1e, "signal");
      n();
      this.e.add(param1e);
    }
    
    public final void m(b param1b, a param1a) {
      s.h(param1b, "finalState");
      s.h(param1a, "lifecycleImpact");
      int i = c.a[param1a.ordinal()];
      if (i != 1) {
        if (i != 2) {
          if (i == 3 && this.a != b.REMOVED) {
            if (FragmentManager.Q0(2)) {
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("SpecialEffectsController: For fragment ");
              stringBuilder.append(this.c);
              stringBuilder.append(" mFinalState = ");
              stringBuilder.append(this.a);
              stringBuilder.append(" -> ");
              stringBuilder.append(param1b);
              stringBuilder.append('.');
              Log.v("FragmentManager", stringBuilder.toString());
            } 
            this.a = param1b;
          } 
        } else {
          if (FragmentManager.Q0(2)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("SpecialEffectsController: For fragment ");
            stringBuilder.append(this.c);
            stringBuilder.append(" mFinalState = ");
            stringBuilder.append(this.a);
            stringBuilder.append(" -> REMOVED. mLifecycleImpact  = ");
            stringBuilder.append(this.b);
            stringBuilder.append(" to REMOVING.");
            Log.v("FragmentManager", stringBuilder.toString());
          } 
          this.a = b.REMOVED;
          this.b = a.REMOVING;
        } 
      } else if (this.a == b.REMOVED) {
        if (FragmentManager.Q0(2)) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("SpecialEffectsController: For fragment ");
          stringBuilder.append(this.c);
          stringBuilder.append(" mFinalState = REMOVED -> VISIBLE. mLifecycleImpact = ");
          stringBuilder.append(this.b);
          stringBuilder.append(" to ADDING.");
          Log.v("FragmentManager", stringBuilder.toString());
        } 
        this.a = b.VISIBLE;
        this.b = a.ADDING;
      } 
    }
    
    public void n() {}
    
    public String toString() {
      String str = Integer.toHexString(System.identityHashCode(this));
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Operation {");
      stringBuilder.append(str);
      stringBuilder.append("} {finalState = ");
      stringBuilder.append(this.a);
      stringBuilder.append(" lifecycleImpact = ");
      stringBuilder.append(this.b);
      stringBuilder.append(" fragment = ");
      stringBuilder.append(this.c);
      stringBuilder.append('}');
      return stringBuilder.toString();
    }
    
    @Metadata(d1 = {"\000\f\n\002\030\002\n\002\020\020\n\002\b\006\b\001\030\0002\b\022\004\022\0020\0000\001B\t\b\002¢\006\004\b\002\020\003j\002\b\004j\002\b\005j\002\b\006¨\006\007"}, d2 = {"Landroidx/fragment/app/q$c$a;", "", "<init>", "(Ljava/lang/String;I)V", "NONE", "ADDING", "REMOVING", "fragment_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
    public enum a {
      ADDING, NONE, REMOVING;
      
      private static final a[] $VALUES = a();
      
      static {
      
      }
    }
    
    @Metadata(d1 = {"\000\032\n\002\030\002\n\002\020\020\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\t\b\001\030\000 \t2\b\022\004\022\0020\0000\001:\001\nB\t\b\002¢\006\004\b\002\020\003J\025\020\007\032\0020\0062\006\020\005\032\0020\004¢\006\004\b\007\020\bj\002\b\013j\002\b\fj\002\b\rj\002\b\016¨\006\017"}, d2 = {"Landroidx/fragment/app/q$c$b;", "", "<init>", "(Ljava/lang/String;I)V", "Landroid/view/View;", "view", "Ldbxyzptlk/pI/D;", "applyState", "(Landroid/view/View;)V", "Companion", "a", "REMOVED", "VISIBLE", "GONE", "INVISIBLE", "fragment_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
    public enum b {
      GONE, INVISIBLE, REMOVED, VISIBLE;
      
      private static final b[] $VALUES = a();
      
      public static final a Companion = new a(null);
      
      static {
      
      }
      
      public static final b from(int param2Int) {
        return Companion.b(param2Int);
      }
      
      public final void applyState(View param2View) {
        s.h(param2View, "view");
        int i = b.a[ordinal()];
        if (i != 1) {
          if (i != 2) {
            if (i != 3) {
              if (i == 4) {
                if (FragmentManager.Q0(2)) {
                  StringBuilder stringBuilder = new StringBuilder();
                  stringBuilder.append("SpecialEffectsController: Setting view ");
                  stringBuilder.append(param2View);
                  stringBuilder.append(" to INVISIBLE");
                  Log.v("FragmentManager", stringBuilder.toString());
                } 
                param2View.setVisibility(4);
              } 
            } else {
              if (FragmentManager.Q0(2)) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("SpecialEffectsController: Setting view ");
                stringBuilder.append(param2View);
                stringBuilder.append(" to GONE");
                Log.v("FragmentManager", stringBuilder.toString());
              } 
              param2View.setVisibility(8);
            } 
          } else {
            if (FragmentManager.Q0(2)) {
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("SpecialEffectsController: Setting view ");
              stringBuilder.append(param2View);
              stringBuilder.append(" to VISIBLE");
              Log.v("FragmentManager", stringBuilder.toString());
            } 
            param2View.setVisibility(0);
          } 
        } else {
          ViewParent viewParent = param2View.getParent();
          if (viewParent instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup)viewParent;
          } else {
            viewParent = null;
          } 
          if (viewParent != null) {
            if (FragmentManager.Q0(2)) {
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("SpecialEffectsController: Removing view ");
              stringBuilder.append(param2View);
              stringBuilder.append(" from container ");
              stringBuilder.append(viewParent);
              Log.v("FragmentManager", stringBuilder.toString());
            } 
            viewParent.removeView(param2View);
          } 
        } 
      }
      
      @Metadata(d1 = {"\000 \n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\b\n\002\b\004\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\021\020\006\032\0020\005*\0020\004¢\006\004\b\006\020\007J\027\020\n\032\0020\0052\006\020\t\032\0020\bH\007¢\006\004\b\n\020\013¨\006\f"}, d2 = {"Landroidx/fragment/app/q$c$b$a;", "", "<init>", "()V", "Landroid/view/View;", "Landroidx/fragment/app/q$c$b;", "a", "(Landroid/view/View;)Landroidx/fragment/app/q$c$b;", "", "visibility", "b", "(I)Landroidx/fragment/app/q$c$b;", "fragment_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
      public static final class a {
        public a() {}
        
        public final q.c.b a(View param3View) {
          q.c.b b;
          s.h(param3View, "<this>");
          if (param3View.getAlpha() == 0.0F && param3View.getVisibility() == 0) {
            b = q.c.b.INVISIBLE;
          } else {
            b = b(b.getVisibility());
          } 
          return b;
        }
        
        public final q.c.b b(int param3Int) {
          q.c.b b;
          if (param3Int != 0) {
            if (param3Int != 4) {
              if (param3Int == 8) {
                b = q.c.b.GONE;
              } else {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Unknown visibility ");
                stringBuilder.append(param3Int);
                throw new IllegalArgumentException(stringBuilder.toString());
              } 
            } else {
              b = q.c.b.INVISIBLE;
            } 
          } else {
            b = q.c.b.VISIBLE;
          } 
          return b;
        }
      }
    }
    
    @Metadata(d1 = {"\000 \n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\b\n\002\b\004\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\021\020\006\032\0020\005*\0020\004¢\006\004\b\006\020\007J\027\020\n\032\0020\0052\006\020\t\032\0020\bH\007¢\006\004\b\n\020\013¨\006\f"}, d2 = {"Landroidx/fragment/app/q$c$b$a;", "", "<init>", "()V", "Landroid/view/View;", "Landroidx/fragment/app/q$c$b;", "a", "(Landroid/view/View;)Landroidx/fragment/app/q$c$b;", "", "visibility", "b", "(I)Landroidx/fragment/app/q$c$b;", "fragment_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
    public static final class a {
      public a() {}
      
      public final q.c.b a(View param2View) {
        q.c.b b;
        s.h(param2View, "<this>");
        if (param2View.getAlpha() == 0.0F && param2View.getVisibility() == 0) {
          b = q.c.b.INVISIBLE;
        } else {
          b = b(b.getVisibility());
        } 
        return b;
      }
      
      public final q.c.b b(int param2Int) {
        q.c.b b;
        if (param2Int != 0) {
          if (param2Int != 4) {
            if (param2Int == 8) {
              b = q.c.b.GONE;
            } else {
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("Unknown visibility ");
              stringBuilder.append(param2Int);
              throw new IllegalArgumentException(stringBuilder.toString());
            } 
          } else {
            b = q.c.b.INVISIBLE;
          } 
        } else {
          b = q.c.b.VISIBLE;
        } 
        return b;
      }
    }
  }
  
  @Metadata(d1 = {"\000\f\n\002\030\002\n\002\020\020\n\002\b\006\b\001\030\0002\b\022\004\022\0020\0000\001B\t\b\002¢\006\004\b\002\020\003j\002\b\004j\002\b\005j\002\b\006¨\006\007"}, d2 = {"Landroidx/fragment/app/q$c$a;", "", "<init>", "(Ljava/lang/String;I)V", "NONE", "ADDING", "REMOVING", "fragment_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public enum a {
    NONE, REMOVING, ADDING;
    
    private static final a[] $VALUES;
    
    static {
      $VALUES = a();
    }
  }
  
  @Metadata(d1 = {"\000\032\n\002\030\002\n\002\020\020\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\t\b\001\030\000 \t2\b\022\004\022\0020\0000\001:\001\nB\t\b\002¢\006\004\b\002\020\003J\025\020\007\032\0020\0062\006\020\005\032\0020\004¢\006\004\b\007\020\bj\002\b\013j\002\b\fj\002\b\rj\002\b\016¨\006\017"}, d2 = {"Landroidx/fragment/app/q$c$b;", "", "<init>", "(Ljava/lang/String;I)V", "Landroid/view/View;", "view", "Ldbxyzptlk/pI/D;", "applyState", "(Landroid/view/View;)V", "Companion", "a", "REMOVED", "VISIBLE", "GONE", "INVISIBLE", "fragment_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public enum b {
    GONE, INVISIBLE, REMOVED, VISIBLE;
    
    private static final b[] $VALUES;
    
    public static final a Companion;
    
    static {
      $VALUES = a();
      Companion = new a(null);
    }
    
    public static final b from(int param1Int) {
      return Companion.b(param1Int);
    }
    
    public final void applyState(View param1View) {
      s.h(param1View, "view");
      int i = b.a[ordinal()];
      if (i != 1) {
        if (i != 2) {
          if (i != 3) {
            if (i == 4) {
              if (FragmentManager.Q0(2)) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("SpecialEffectsController: Setting view ");
                stringBuilder.append(param1View);
                stringBuilder.append(" to INVISIBLE");
                Log.v("FragmentManager", stringBuilder.toString());
              } 
              param1View.setVisibility(4);
            } 
          } else {
            if (FragmentManager.Q0(2)) {
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("SpecialEffectsController: Setting view ");
              stringBuilder.append(param1View);
              stringBuilder.append(" to GONE");
              Log.v("FragmentManager", stringBuilder.toString());
            } 
            param1View.setVisibility(8);
          } 
        } else {
          if (FragmentManager.Q0(2)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("SpecialEffectsController: Setting view ");
            stringBuilder.append(param1View);
            stringBuilder.append(" to VISIBLE");
            Log.v("FragmentManager", stringBuilder.toString());
          } 
          param1View.setVisibility(0);
        } 
      } else {
        ViewParent viewParent = param1View.getParent();
        if (viewParent instanceof ViewGroup) {
          ViewGroup viewGroup = (ViewGroup)viewParent;
        } else {
          viewParent = null;
        } 
        if (viewParent != null) {
          if (FragmentManager.Q0(2)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("SpecialEffectsController: Removing view ");
            stringBuilder.append(param1View);
            stringBuilder.append(" from container ");
            stringBuilder.append(viewParent);
            Log.v("FragmentManager", stringBuilder.toString());
          } 
          viewParent.removeView(param1View);
        } 
      } 
    }
    
    @Metadata(d1 = {"\000 \n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\b\n\002\b\004\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\021\020\006\032\0020\005*\0020\004¢\006\004\b\006\020\007J\027\020\n\032\0020\0052\006\020\t\032\0020\bH\007¢\006\004\b\n\020\013¨\006\f"}, d2 = {"Landroidx/fragment/app/q$c$b$a;", "", "<init>", "()V", "Landroid/view/View;", "Landroidx/fragment/app/q$c$b;", "a", "(Landroid/view/View;)Landroidx/fragment/app/q$c$b;", "", "visibility", "b", "(I)Landroidx/fragment/app/q$c$b;", "fragment_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
    public static final class a {
      public a() {}
      
      public final q.c.b a(View param3View) {
        q.c.b b;
        s.h(param3View, "<this>");
        if (param3View.getAlpha() == 0.0F && param3View.getVisibility() == 0) {
          b = q.c.b.INVISIBLE;
        } else {
          b = b(b.getVisibility());
        } 
        return b;
      }
      
      public final q.c.b b(int param3Int) {
        q.c.b b;
        if (param3Int != 0) {
          if (param3Int != 4) {
            if (param3Int == 8) {
              b = q.c.b.GONE;
            } else {
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("Unknown visibility ");
              stringBuilder.append(param3Int);
              throw new IllegalArgumentException(stringBuilder.toString());
            } 
          } else {
            b = q.c.b.INVISIBLE;
          } 
        } else {
          b = q.c.b.VISIBLE;
        } 
        return b;
      }
    }
  }
  
  @Metadata(d1 = {"\000 \n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\b\n\002\b\004\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\021\020\006\032\0020\005*\0020\004¢\006\004\b\006\020\007J\027\020\n\032\0020\0052\006\020\t\032\0020\bH\007¢\006\004\b\n\020\013¨\006\f"}, d2 = {"Landroidx/fragment/app/q$c$b$a;", "", "<init>", "()V", "Landroid/view/View;", "Landroidx/fragment/app/q$c$b;", "a", "(Landroid/view/View;)Landroidx/fragment/app/q$c$b;", "", "visibility", "b", "(I)Landroidx/fragment/app/q$c$b;", "fragment_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class a {
    public a() {}
    
    public final q.c.b a(View param1View) {
      q.c.b b;
      s.h(param1View, "<this>");
      if (param1View.getAlpha() == 0.0F && param1View.getVisibility() == 0) {
        b = q.c.b.INVISIBLE;
      } else {
        b = b(b.getVisibility());
      } 
      return b;
    }
    
    public final q.c.b b(int param1Int) {
      q.c.b b;
      if (param1Int != 0) {
        if (param1Int != 4) {
          if (param1Int == 8) {
            b = q.c.b.GONE;
          } else {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Unknown visibility ");
            stringBuilder.append(param1Int);
            throw new IllegalArgumentException(stringBuilder.toString());
          } 
        } else {
          b = q.c.b.INVISIBLE;
        } 
      } else {
        b = q.c.b.VISIBLE;
      } 
      return b;
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\fragment\app\q.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */