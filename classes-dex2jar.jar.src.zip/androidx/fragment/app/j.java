package androidx.fragment.app;

import android.util.Log;
import androidx.lifecycle.t;
import dbxyzptlk.U2.v;
import dbxyzptlk.U2.y;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;

public final class j extends v {
  public static final t.b j = new a();
  
  public final HashMap<String, Fragment> c = new HashMap<>();
  
  public final HashMap<String, j> d = new HashMap<>();
  
  public final HashMap<String, y> e = new HashMap<>();
  
  public final boolean f;
  
  public boolean g = false;
  
  public boolean h = false;
  
  public boolean i = false;
  
  public j(boolean paramBoolean) {
    this.f = paramBoolean;
  }
  
  public static j L(y paramy) {
    return (j)(new t(paramy, j)).a(j.class);
  }
  
  public void F(Fragment paramFragment) {
    if (this.i) {
      if (FragmentManager.Q0(2))
        Log.v("FragmentManager", "Ignoring addRetainedFragment as the state is already saved"); 
      return;
    } 
    if (this.c.containsKey(paramFragment.mWho))
      return; 
    this.c.put(paramFragment.mWho, paramFragment);
    if (FragmentManager.Q0(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Updating retained Fragments: Added ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
  }
  
  public void G(Fragment paramFragment, boolean paramBoolean) {
    if (FragmentManager.Q0(3)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Clearing non-config state for ");
      stringBuilder.append(paramFragment);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    I(paramFragment.mWho, paramBoolean);
  }
  
  public void H(String paramString, boolean paramBoolean) {
    if (FragmentManager.Q0(3)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Clearing non-config state for saved state of Fragment ");
      stringBuilder.append(paramString);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    I(paramString, paramBoolean);
  }
  
  public final void I(String paramString, boolean paramBoolean) {
    j j1 = this.d.get(paramString);
    if (j1 != null) {
      if (paramBoolean) {
        ArrayList arrayList = new ArrayList();
        arrayList.addAll(j1.d.keySet());
        Iterator<String> iterator = arrayList.iterator();
        while (iterator.hasNext())
          j1.H(iterator.next(), true); 
      } 
      j1.onCleared();
      this.d.remove(paramString);
    } 
    y y = this.e.get(paramString);
    if (y != null) {
      y.a();
      this.e.remove(paramString);
    } 
  }
  
  public Fragment J(String paramString) {
    return this.c.get(paramString);
  }
  
  public j K(Fragment paramFragment) {
    j j2 = this.d.get(paramFragment.mWho);
    j j1 = j2;
    if (j2 == null) {
      j1 = new j(this.f);
      this.d.put(paramFragment.mWho, j1);
    } 
    return j1;
  }
  
  public Collection<Fragment> M() {
    return new ArrayList<>(this.c.values());
  }
  
  public y N(Fragment paramFragment) {
    y y2 = this.e.get(paramFragment.mWho);
    y y1 = y2;
    if (y2 == null) {
      y1 = new y();
      this.e.put(paramFragment.mWho, y1);
    } 
    return y1;
  }
  
  public boolean O() {
    return this.g;
  }
  
  public void P(Fragment paramFragment) {
    if (this.i) {
      if (FragmentManager.Q0(2))
        Log.v("FragmentManager", "Ignoring removeRetainedFragment as the state is already saved"); 
      return;
    } 
    if (this.c.remove(paramFragment.mWho) != null && FragmentManager.Q0(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Updating retained Fragments: Removed ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
  }
  
  public void Q(boolean paramBoolean) {
    this.i = paramBoolean;
  }
  
  public boolean R(Fragment paramFragment) {
    return !this.c.containsKey(paramFragment.mWho) ? true : (this.f ? this.g : (this.h ^ true));
  }
  
  public boolean equals(Object paramObject) {
    boolean bool = true;
    if (this == paramObject)
      return true; 
    if (paramObject == null || j.class != paramObject.getClass())
      return false; 
    paramObject = paramObject;
    if (!this.c.equals(((j)paramObject).c) || !this.d.equals(((j)paramObject).d) || !this.e.equals(((j)paramObject).e))
      bool = false; 
    return bool;
  }
  
  public int hashCode() {
    return (this.c.hashCode() * 31 + this.d.hashCode()) * 31 + this.e.hashCode();
  }
  
  public void onCleared() {
    if (FragmentManager.Q0(3)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("onCleared called for ");
      stringBuilder.append(this);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    this.g = true;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder("FragmentManagerViewModel{");
    stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
    stringBuilder.append("} Fragments (");
    Iterator<String> iterator = this.c.values().iterator();
    while (iterator.hasNext()) {
      stringBuilder.append(iterator.next());
      if (iterator.hasNext())
        stringBuilder.append(", "); 
    } 
    stringBuilder.append(") Child Non Config (");
    iterator = this.d.keySet().iterator();
    while (iterator.hasNext()) {
      stringBuilder.append(iterator.next());
      if (iterator.hasNext())
        stringBuilder.append(", "); 
    } 
    stringBuilder.append(") ViewModelStores (");
    iterator = this.e.keySet().iterator();
    while (iterator.hasNext()) {
      stringBuilder.append(iterator.next());
      if (iterator.hasNext())
        stringBuilder.append(", "); 
    } 
    stringBuilder.append(')');
    return stringBuilder.toString();
  }
  
  public class a implements t.b {
    public <T extends v> T b(Class<T> param1Class) {
      return (T)new j(true);
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\fragment\app\j.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */