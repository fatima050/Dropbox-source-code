package androidx.fragment.app;

import android.animation.Animator;
import android.content.Context;
import android.graphics.Rect;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import dbxyzptlk.CI.l;
import dbxyzptlk.DI.s;
import dbxyzptlk.K2.B;
import dbxyzptlk.K2.D;
import dbxyzptlk.K2.a;
import dbxyzptlk.K2.b;
import dbxyzptlk.K2.c;
import dbxyzptlk.K2.e;
import dbxyzptlk.K2.f;
import dbxyzptlk.K2.g;
import dbxyzptlk.T1.y;
import dbxyzptlk.V.a;
import dbxyzptlk.d2.e;
import dbxyzptlk.h2.S;
import dbxyzptlk.h2.h0;
import dbxyzptlk.h2.m0;
import dbxyzptlk.pI.n;
import dbxyzptlk.pI.t;
import dbxyzptlk.qI.A;
import dbxyzptlk.qI.x;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Set;
import kotlin.Metadata;

@Metadata(d1 = {"\000n\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\003\n\002\020 \n\002\030\002\n\000\n\002\020\013\n\000\n\002\030\002\n\002\b\004\n\002\030\002\n\000\n\002\020!\n\002\b\002\n\002\020$\n\002\b\003\n\002\030\002\n\002\b\005\n\002\030\002\n\002\020\016\n\002\030\002\n\002\020\036\n\002\b\003\n\002\030\002\n\002\030\002\n\002\b\004\n\002\020%\n\002\b\n\b\000\030\0002\0020\001:\003345B\017\022\006\020\003\032\0020\002¢\006\004\b\004\020\005J%\020\f\032\0020\0132\f\020\b\032\b\022\004\022\0020\0070\0062\006\020\n\032\0020\tH\026¢\006\004\b\f\020\rJ\035\020\016\032\0020\0132\f\020\b\032\b\022\004\022\0020\0070\006H\002¢\006\004\b\016\020\017JG\020\027\032\0020\0132\f\020\021\032\b\022\004\022\0020\0200\0062\f\020\023\032\b\022\004\022\0020\0070\0222\006\020\024\032\0020\t2\022\020\026\032\016\022\004\022\0020\007\022\004\022\0020\t0\025H\002¢\006\004\b\027\020\030JS\020\035\032\016\022\004\022\0020\007\022\004\022\0020\t0\0252\f\020\032\032\b\022\004\022\0020\0310\0062\f\020\023\032\b\022\004\022\0020\0070\0222\006\020\n\032\0020\t2\b\020\033\032\004\030\0010\0072\b\020\034\032\004\030\0010\007H\002¢\006\004\b\035\020\036J-\020$\032\0020\013*\016\022\004\022\0020 \022\004\022\0020!0\0372\f\020#\032\b\022\004\022\0020 0\"H\002¢\006\004\b$\020%J/\020*\032\0020\0132\026\020(\032\022\022\004\022\0020!0&j\b\022\004\022\0020!`'2\006\020)\032\0020!H\002¢\006\004\b*\020+J+\020.\032\0020\0132\022\020-\032\016\022\004\022\0020 \022\004\022\0020!0,2\006\020)\032\0020!H\002¢\006\004\b.\020/J\027\0201\032\0020\0132\006\0200\032\0020\007H\002¢\006\004\b1\0202¨\0066"}, d2 = {"Landroidx/fragment/app/d;", "Landroidx/fragment/app/q;", "Landroid/view/ViewGroup;", "container", "<init>", "(Landroid/view/ViewGroup;)V", "", "Landroidx/fragment/app/q$c;", "operations", "", "isPop", "Ldbxyzptlk/pI/D;", "j", "(Ljava/util/List;Z)V", "Q", "(Ljava/util/List;)V", "Landroidx/fragment/app/d$a;", "animationInfos", "", "awaitingContainerChanges", "startedAnyTransition", "", "startedTransitions", "I", "(Ljava/util/List;Ljava/util/List;ZLjava/util/Map;)V", "Landroidx/fragment/app/d$c;", "transitionInfos", "firstOut", "lastIn", "L", "(Ljava/util/List;Ljava/util/List;ZLandroidx/fragment/app/q$c;Landroidx/fragment/app/q$c;)Ljava/util/Map;", "Ldbxyzptlk/V/a;", "", "Landroid/view/View;", "", "names", "H", "(Ldbxyzptlk/V/a;Ljava/util/Collection;)V", "Ljava/util/ArrayList;", "Lkotlin/collections/ArrayList;", "transitioningViews", "view", "E", "(Ljava/util/ArrayList;Landroid/view/View;)V", "", "namedViews", "G", "(Ljava/util/Map;Landroid/view/View;)V", "operation", "D", "(Landroidx/fragment/app/q$c;)V", "a", "b", "c", "fragment_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class d extends q {
  public d(ViewGroup paramViewGroup) {
    super(paramViewGroup);
  }
  
  public static final void F(List paramList, q.c paramc, d paramd) {
    s.h(paramList, "$awaitingContainerChanges");
    s.h(paramc, "$operation");
    s.h(paramd, "this$0");
    if (paramList.contains(paramc)) {
      paramList.remove(paramc);
      paramd.D(paramc);
    } 
  }
  
  public static final void J(Animator paramAnimator, q.c paramc) {
    s.h(paramc, "$operation");
    paramAnimator.end();
    if (FragmentManager.Q0(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Animator from operation ");
      stringBuilder.append(paramc);
      stringBuilder.append(" has been canceled.");
      Log.v("FragmentManager", stringBuilder.toString());
    } 
  }
  
  public static final void K(View paramView, d paramd, a parama, q.c paramc) {
    s.h(paramd, "this$0");
    s.h(parama, "$animationInfo");
    s.h(paramc, "$operation");
    paramView.clearAnimation();
    paramd.q().endViewTransition(paramView);
    parama.a();
    if (FragmentManager.Q0(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Animation from operation ");
      stringBuilder.append(paramc);
      stringBuilder.append(" has been cancelled.");
      Log.v("FragmentManager", stringBuilder.toString());
    } 
  }
  
  public static final void M(D paramD, View paramView, Rect paramRect) {
    s.h(paramD, "$impl");
    s.h(paramRect, "$lastInEpicenterRect");
    paramD.h(paramView, paramRect);
  }
  
  public static final void N(ArrayList paramArrayList) {
    s.h(paramArrayList, "$transitioningViews");
    B.e(paramArrayList, 4);
  }
  
  public static final void O(c paramc, q.c paramc1) {
    s.h(paramc, "$transitionInfo");
    s.h(paramc1, "$operation");
    paramc.a();
    if (FragmentManager.Q0(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Transition for operation ");
      stringBuilder.append(paramc1);
      stringBuilder.append(" has completed");
      Log.v("FragmentManager", stringBuilder.toString());
    } 
  }
  
  public static final void P(q.c paramc1, q.c paramc2, boolean paramBoolean, a parama) {
    s.h(parama, "$lastInViews");
    B.a(paramc1.h(), paramc2.h(), paramBoolean, parama, false);
  }
  
  public final void D(q.c paramc) {
    View view = (paramc.h()).mView;
    q.c.b b = paramc.g();
    s.g(view, "view");
    b.applyState(view);
  }
  
  public final void E(ArrayList<View> paramArrayList, View paramView) {
    if (paramView instanceof ViewGroup) {
      ViewGroup viewGroup = (ViewGroup)paramView;
      if (m0.b(viewGroup)) {
        if (!paramArrayList.contains(paramView))
          paramArrayList.add(paramView); 
      } else {
        int i = viewGroup.getChildCount();
        for (byte b = 0; b < i; b++) {
          paramView = viewGroup.getChildAt(b);
          if (paramView.getVisibility() == 0) {
            s.g(paramView, "child");
            E(paramArrayList, paramView);
          } 
        } 
      } 
    } else if (!paramArrayList.contains(paramView)) {
      paramArrayList.add(paramView);
    } 
  }
  
  public final void G(Map<String, View> paramMap, View paramView) {
    String str = h0.J(paramView);
    if (str != null)
      paramMap.put(str, paramView); 
    if (paramView instanceof ViewGroup) {
      ViewGroup viewGroup = (ViewGroup)paramView;
      int i = viewGroup.getChildCount();
      for (byte b = 0; b < i; b++) {
        View view = viewGroup.getChildAt(b);
        if (view.getVisibility() == 0) {
          s.g(view, "child");
          G(paramMap, view);
        } 
      } 
    } 
  }
  
  public final void H(a<String, View> parama, Collection<String> paramCollection) {
    Set set = parama.entrySet();
    s.g(set, "entries");
    x.P(set, (l)new d(paramCollection));
  }
  
  public final void I(List<a> paramList, List<q.c> paramList1, boolean paramBoolean, Map<q.c, Boolean> paramMap) {
    Context context = q().getContext();
    ArrayList<a> arrayList = new ArrayList();
    null = paramList.iterator();
    boolean bool;
    for (bool = false; null.hasNext(); bool = true) {
      boolean bool1;
      StringBuilder stringBuilder;
      a a = null.next();
      if (a.d()) {
        a.a();
        continue;
      } 
      s.g(context, "context");
      e.a a1 = a.e(context);
      if (a1 == null) {
        a.a();
        continue;
      } 
      Animator animator = a1.b;
      if (animator == null) {
        arrayList.add(a);
        continue;
      } 
      q.c c = a.b();
      Fragment fragment = c.h();
      if (s.c(paramMap.get(c), Boolean.TRUE)) {
        if (FragmentManager.Q0(2)) {
          stringBuilder = new StringBuilder();
          stringBuilder.append("Ignoring Animator set on ");
          stringBuilder.append(fragment);
          stringBuilder.append(" as this Fragment was involved in a Transition.");
          Log.v("FragmentManager", stringBuilder.toString());
        } 
        a.a();
        continue;
      } 
      if (stringBuilder.g() == q.c.b.GONE) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      if (bool1)
        paramList1.remove(stringBuilder); 
      View view = fragment.mView;
      q().startViewTransition(view);
      animator.addListener((Animator.AnimatorListener)new e(this, view, bool1, (q.c)stringBuilder, a));
      animator.setTarget(view);
      animator.start();
      if (FragmentManager.Q0(2)) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("Animator from operation ");
        stringBuilder1.append(stringBuilder);
        stringBuilder1.append(" has started.");
        Log.v("FragmentManager", stringBuilder1.toString());
      } 
      a.c().c((e.a)new b(animator, (q.c)stringBuilder));
    } 
    for (a a : arrayList) {
      StringBuilder stringBuilder;
      q.c c = a.b();
      Fragment fragment = c.h();
      if (paramBoolean) {
        if (FragmentManager.Q0(2)) {
          stringBuilder = new StringBuilder();
          stringBuilder.append("Ignoring Animation set on ");
          stringBuilder.append(fragment);
          stringBuilder.append(" as Animations cannot run alongside Transitions.");
          Log.v("FragmentManager", stringBuilder.toString());
        } 
        a.a();
        continue;
      } 
      if (bool) {
        if (FragmentManager.Q0(2)) {
          stringBuilder = new StringBuilder();
          stringBuilder.append("Ignoring Animation set on ");
          stringBuilder.append(fragment);
          stringBuilder.append(" as Animations cannot run alongside Animators.");
          Log.v("FragmentManager", stringBuilder.toString());
        } 
        a.a();
        continue;
      } 
      View view = fragment.mView;
      s.g(context, "context");
      e.a a1 = a.e(context);
      if (a1 != null) {
        Animation animation = a1.a;
        if (animation != null) {
          if (stringBuilder.g() != q.c.b.REMOVED) {
            view.startAnimation(animation);
            a.a();
          } else {
            q().startViewTransition(view);
            e.b b = new e.b(animation, q(), view);
            b.setAnimationListener((Animation.AnimationListener)new f((q.c)stringBuilder, this, view, a));
            view.startAnimation((Animation)b);
            if (FragmentManager.Q0(2)) {
              StringBuilder stringBuilder1 = new StringBuilder();
              stringBuilder1.append("Animation from operation ");
              stringBuilder1.append(stringBuilder);
              stringBuilder1.append(" has started.");
              Log.v("FragmentManager", stringBuilder1.toString());
            } 
          } 
          a.c().c((e.a)new c(view, this, a, (q.c)stringBuilder));
          continue;
        } 
        throw new IllegalStateException("Required value was null.");
      } 
      throw new IllegalStateException("Required value was null.");
    } 
  }
  
  public final Map<q.c, Boolean> L(List<c> paramList, List<q.c> paramList1, boolean paramBoolean, q.c paramc1, q.c paramc2) {
    StringBuilder stringBuilder;
    D d1;
    LinkedHashMap<Object, Object> linkedHashMap = new LinkedHashMap<>();
    list = paramList;
    arrayList = new ArrayList();
    for (List<c> list : list) {
      if (!((c)list).d())
        arrayList.add(list); 
    } 
    list = new ArrayList<>();
    for (ArrayList<List<c>> arrayList : arrayList) {
      if (((c)arrayList).e() != null)
        list.add(arrayList); 
    } 
    Iterator<c> iterator1 = list.iterator();
    arrayList = null;
    while (iterator1.hasNext()) {
      c c2 = iterator1.next();
      D d2 = c2.e();
      if (arrayList == null || d2 == arrayList) {
        d1 = d2;
        continue;
      } 
      stringBuilder = new StringBuilder();
      stringBuilder.append("Mixing framework transitions and AndroidX transitions is not allowed. Fragment ");
      stringBuilder.append(c2.b().h());
      stringBuilder.append(" returned Transition ");
      stringBuilder.append(c2.h());
      stringBuilder.append(" which uses a different Transition type than other Fragments.");
      throw new IllegalArgumentException(stringBuilder.toString().toString());
    } 
    if (d1 == null) {
      for (c c1 : stringBuilder) {
        linkedHashMap.put(c1.b(), Boolean.FALSE);
        c1.a();
      } 
      return (Map)linkedHashMap;
    } 
    View view = new View(q().getContext());
    Rect rect = new Rect();
    ArrayList arrayList2 = new ArrayList();
    ArrayList arrayList3 = new ArrayList();
    a<String, String> a = new a();
    Iterator<c> iterator2 = c1.iterator();
    iterator1 = null;
    ArrayList<String> arrayList1 = null;
    boolean bool = false;
    while (true) {
      D d2;
      View view1;
      Object object3;
      Object<String> object;
      Collection<String> collection3;
      boolean bool1 = iterator2.hasNext();
      String str = "FragmentManager";
      if (bool1) {
        c c2 = iterator2.next();
        if (c2.i() && paramc1 != null && paramc2 != null) {
          n n;
          Object<String> object4 = (Object<String>)d1.u(d1.f(c2.g()));
          ArrayList<String> arrayList8 = paramc2.h().getSharedElementSourceNames();
          s.g(arrayList8, "lastIn.fragment.sharedElementSourceNames");
          ArrayList<String> arrayList7 = paramc1.h().getSharedElementSourceNames();
          s.g(arrayList7, "firstOut.fragment.sharedElementSourceNames");
          arrayList1 = paramc1.h().getSharedElementTargetNames();
          s.g(arrayList1, "firstOut.fragment.sharedElementTargetNames");
          int i = arrayList1.size();
          int j;
          for (j = 0; j < i; j++) {
            int k = arrayList8.indexOf(arrayList1.get(j));
            if (k != -1)
              arrayList8.set(k, arrayList7.get(j)); 
          } 
          arrayList7 = paramc2.h().getSharedElementTargetNames();
          s.g(arrayList7, "lastIn.fragment.sharedElementTargetNames");
          if (!paramBoolean) {
            n = t.a(paramc1.h().getExitTransitionCallback(), paramc2.h().getEnterTransitionCallback());
          } else {
            n = t.a(paramc1.h().getEnterTransitionCallback(), paramc2.h().getExitTransitionCallback());
          } 
          y y2 = (y)n.a();
          y y1 = (y)n.b();
          j = arrayList8.size();
          i = 0;
          object = object4;
          while (i < j) {
            a.put(arrayList8.get(i), arrayList7.get(i));
            i++;
          } 
          if (FragmentManager.Q0(2)) {
            Log.v("FragmentManager", ">>> entering view names <<<");
            for (String str1 : arrayList7) {
              StringBuilder stringBuilder1 = new StringBuilder();
              stringBuilder1.append("Name: ");
              stringBuilder1.append(str1);
              Log.v("FragmentManager", stringBuilder1.toString());
            } 
            Log.v("FragmentManager", ">>> exiting view names <<<");
            for (String str1 : arrayList8) {
              StringBuilder stringBuilder1 = new StringBuilder();
              stringBuilder1.append("Name: ");
              stringBuilder1.append(str1);
              Log.v("FragmentManager", stringBuilder1.toString());
            } 
          } 
          a<String, View> a1 = new a();
          View view4 = (paramc1.h()).mView;
          s.g(view4, "firstOut.fragment.mView");
          G((Map<String, View>)a1, view4);
          a1.o(arrayList8);
          if (y2 != null) {
            if (FragmentManager.Q0(2)) {
              StringBuilder stringBuilder1 = new StringBuilder();
              stringBuilder1.append("Executing exit callback for operation ");
              stringBuilder1.append(paramc1);
              Log.v("FragmentManager", stringBuilder1.toString());
            } 
            y2.d(arrayList8, (Map)a1);
            i = arrayList8.size() - 1;
            if (i >= 0)
              while (true) {
                j = i - 1;
                String str1 = arrayList8.get(i);
                View view5 = (View)a1.get(str1);
                if (view5 == null) {
                  a.remove(str1);
                } else if (!s.c(str1, h0.J(view5))) {
                  str1 = (String)a.remove(str1);
                  a.put(h0.J(view5), str1);
                } 
                if (j < 0)
                  break; 
                i = j;
              }  
          } else {
            a.o(a1.keySet());
          } 
          a<String, View> a2 = new a();
          view4 = (paramc2.h()).mView;
          s.g(view4, "lastIn.fragment.mView");
          G((Map<String, View>)a2, view4);
          a2.o(arrayList7);
          a2.o(a.values());
          if (y1 != null) {
            if (FragmentManager.Q0(2)) {
              StringBuilder stringBuilder1 = new StringBuilder();
              stringBuilder1.append("Executing enter callback for operation ");
              stringBuilder1.append(paramc2);
              Log.v("FragmentManager", stringBuilder1.toString());
            } 
            y1.d(arrayList7, (Map)a2);
            i = arrayList7.size() - 1;
            if (i >= 0)
              while (true) {
                String str1;
                j = i - 1;
                String str2 = arrayList7.get(i);
                View view5 = (View)a2.get(str2);
                if (view5 == null) {
                  s.g(str2, "name");
                  str1 = B.b(a, str2);
                  if (str1 != null)
                    a.remove(str1); 
                } else if (!s.c(str2, h0.J((View)str1))) {
                  s.g(str2, "name");
                  str2 = B.b(a, str2);
                  if (str2 != null)
                    a.put(str2, h0.J((View)str1)); 
                } 
                if (j < 0)
                  break; 
                i = j;
              }  
          } else {
            B.d(a, a2);
          } 
          Set<String> set = a.keySet();
          s.g(set, "sharedElementNameMapping.keys");
          H(a1, set);
          collection3 = a.values();
          s.g(collection3, "sharedElementNameMapping.values");
          H(a2, collection3);
          if (a.isEmpty()) {
            arrayList2.clear();
            arrayList3.clear();
            object = null;
            continue;
          } 
          B.a(paramc2.h(), paramc1.h(), paramBoolean, a1, true);
          S.a((View)q(), (Runnable)new dbxyzptlk.K2.d(paramc2, paramc1, paramBoolean, a2));
          arrayList2.addAll(a1.values());
          if (!arrayList8.isEmpty()) {
            view1 = (View)a1.get(arrayList8.get(0));
            d1.p(object, view1);
          } 
          arrayList3.addAll(a2.values());
          if (!arrayList7.isEmpty()) {
            View view5 = (View)a2.get(arrayList7.get(0));
            if (view5 != null) {
              S.a((View)q(), (Runnable)new e(d1, view5, rect));
              bool = true;
            } 
          } 
          d1.s(object, view, arrayList2);
          D d3 = d1;
          Rect rect2 = rect;
          d1.n(object, null, null, null, null, object, arrayList3);
          Boolean bool2 = Boolean.TRUE;
          linkedHashMap.put(paramc1, bool2);
          linkedHashMap.put(paramc2, bool2);
          d2 = d3;
          continue;
        } 
        Rect rect1 = rect;
        continue;
      } 
      View view3 = view;
      ArrayList<View> arrayList6 = new ArrayList();
      Iterator<c> iterator4 = c1.iterator();
      view = null;
      LinkedHashMap linkedHashMap2 = null;
      View view2 = view1;
      LinkedHashMap<Object, Object> linkedHashMap1 = linkedHashMap;
      linkedHashMap = linkedHashMap2;
      Collection<String> collection2 = collection3;
      while (iterator4.hasNext()) {
        boolean bool2;
        c c2 = iterator4.next();
        if (c2.d()) {
          linkedHashMap1.put(c2.b(), Boolean.FALSE);
          c2.a();
          continue;
        } 
        Object object4 = d2.f(c2.h());
        q.c c3 = c2.b();
        if (object != null && (c3 == paramc1 || c3 == paramc2)) {
          bool2 = true;
        } else {
          bool2 = false;
        } 
        if (object4 == null) {
          if (!bool2) {
            linkedHashMap1.put(c3, Boolean.FALSE);
            c2.a();
          } 
          continue;
        } 
        ArrayList<View> arrayList7 = new ArrayList();
        View view4 = (c3.h()).mView;
        s.g(view4, "operation.fragment.mView");
        E(arrayList7, view4);
        if (bool2)
          if (c3 == paramc1) {
            arrayList7.removeAll(A.q1(arrayList2));
          } else {
            arrayList7.removeAll(A.q1(arrayList3));
          }  
        if (arrayList7.isEmpty()) {
          d2.a(object4, view3);
        } else {
          d2.b(object4, arrayList7);
          d2.n(object4, object4, arrayList7, null, null, null, null);
          if (c3.g() == q.c.b.GONE) {
            paramList1.remove(c3);
            ArrayList<View> arrayList8 = new ArrayList<>(arrayList7);
            arrayList8.remove((c3.h()).mView);
            d2.m(object4, (c3.h()).mView, arrayList8);
            S.a((View)q(), (Runnable)new f(arrayList7));
          } 
        } 
        if (c3.g() == q.c.b.VISIBLE) {
          arrayList6.addAll(arrayList7);
          if (bool)
            d2.o(object4, rect); 
        } else {
          d2.p(object4, view2);
        } 
        linkedHashMap1.put(c3, Boolean.TRUE);
        if (c2.j()) {
          object3 = d2.k(linkedHashMap, object4, null);
          continue;
        } 
        object2 = d2.k(view, object4, null);
      } 
      Object object1 = d2.j(object3, object2, object);
      if (object1 == null)
        return (Map)linkedHashMap1; 
      Iterable iterable = (Iterable)c1;
      ArrayList<Object> arrayList4 = new ArrayList();
      for (Object object2 : iterable) {
        if (!((c)object2).d())
          arrayList4.add(object2); 
      } 
      iterator3 = arrayList4.iterator();
      Collection<String> collection1 = collection2;
      while (iterator3.hasNext()) {
        c c2 = iterator3.next();
        object3 = c2.h();
        object2 = c2.b();
        if (object != null && (object2 == paramc1 || object2 == paramc2)) {
          bool = true;
        } else {
          bool = false;
        } 
        if (object3 != null || bool) {
          if (!h0.U((View)q())) {
            if (FragmentManager.Q0(2)) {
              object3 = new StringBuilder();
              object3.append("SpecialEffectsController: Container ");
              object3.append(q());
              object3.append(" has not been laid out. Completing operation ");
              object3.append(object2);
              Log.v((String)collection1, object3.toString());
            } 
            c2.a();
            continue;
          } 
          d2.q(c2.b().h(), object1, c2.c(), (Runnable)new g(c2, (q.c)object2));
        } 
      } 
      if (!h0.U((View)q()))
        return (Map)linkedHashMap1; 
      B.e(arrayList6, 4);
      ArrayList arrayList5 = d2.l(arrayList3);
      if (FragmentManager.Q0(2)) {
        Log.v((String)collection1, ">>>>> Beginning transition <<<<<");
        Log.v((String)collection1, ">>>>> SharedElementFirstOutViews <<<<<");
        for (Iterator<c> iterator3 : (Iterable<Iterator<c>>)arrayList2) {
          s.g(iterator3, "sharedElementFirstOutViews");
          View view4 = (View)iterator3;
          StringBuilder stringBuilder1 = new StringBuilder();
          stringBuilder1.append("View: ");
          stringBuilder1.append(view4);
          stringBuilder1.append(" Name: ");
          stringBuilder1.append(h0.J(view4));
          Log.v((String)collection1, stringBuilder1.toString());
        } 
        Log.v((String)collection1, ">>>>> SharedElementLastInViews <<<<<");
        for (Iterator<c> iterator3 : (Iterable<Iterator<c>>)arrayList3) {
          s.g(iterator3, "sharedElementLastInViews");
          View view4 = (View)iterator3;
          StringBuilder stringBuilder1 = new StringBuilder();
          stringBuilder1.append("View: ");
          stringBuilder1.append(view4);
          stringBuilder1.append(" Name: ");
          stringBuilder1.append(h0.J(view4));
          Log.v((String)collection1, stringBuilder1.toString());
        } 
      } 
      d2.c(q(), object1);
      d2.r((View)q(), arrayList2, arrayList3, arrayList5, (Map)a);
      B.e(arrayList6, 0);
      d2.t(object, arrayList2, arrayList3);
      return (Map)linkedHashMap1;
    } 
  }
  
  public final void Q(List<? extends q.c> paramList) {
    Fragment fragment = ((q.c)A.B0(paramList)).h();
    for (q.c c : paramList) {
      (c.h()).mAnimationInfo.c = fragment.mAnimationInfo.c;
      (c.h()).mAnimationInfo.d = fragment.mAnimationInfo.d;
      (c.h()).mAnimationInfo.e = fragment.mAnimationInfo.e;
      (c.h()).mAnimationInfo.f = fragment.mAnimationInfo.f;
    } 
  }
  
  public void j(List<? extends q.c> paramList, boolean paramBoolean) {
    q.c c2;
    s.h(paramList, "operations");
    Iterator<? extends q.c> iterator1 = paramList.iterator();
    while (true) {
      boolean bool = iterator1.hasNext();
      c2 = null;
      if (bool) {
        q.c c4 = (q.c)iterator1.next();
        q.c c5 = c4;
        q.c.b.a a = q.c.b.Companion;
        View view = (c5.h()).mView;
        s.g(view, "operation.fragment.mView");
        q.c.b b2 = a.a(view);
        q.c.b b1 = q.c.b.VISIBLE;
        if (b2 == b1 && c5.g() != b1)
          break; 
        continue;
      } 
      c1 = null;
      break;
    } 
    q.c c3 = c1;
    ListIterator<? extends q.c> listIterator = paramList.listIterator(paramList.size());
    while (true) {
      c1 = c2;
      if (listIterator.hasPrevious()) {
        c1 = listIterator.previous();
        q.c c = c1;
        q.c.b.a a = q.c.b.Companion;
        View view = (c.h()).mView;
        s.g(view, "operation.fragment.mView");
        q.c.b b1 = a.a(view);
        q.c.b b2 = q.c.b.VISIBLE;
        if (b1 != b2 && c.g() == b2)
          break; 
        continue;
      } 
      break;
    } 
    q.c c1 = c1;
    if (FragmentManager.Q0(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Executing operations from ");
      stringBuilder.append(c3);
      stringBuilder.append(" to ");
      stringBuilder.append(c1);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    ArrayList<a> arrayList = new ArrayList();
    ArrayList<c> arrayList1 = new ArrayList();
    List<q.c> list = A.o1(paramList);
    Q(paramList);
    for (q.c c : paramList) {
      e e = new e();
      c.l(e);
      arrayList.add(new a(c, e, paramBoolean));
      e = new e();
      c.l(e);
      boolean bool = false;
      if (paramBoolean ? (c == c3) : (c == c1))
        bool = true; 
      arrayList1.add(new c(c, e, paramBoolean, bool));
      c.c((Runnable)new a(list, c, this));
    } 
    Map<q.c, Boolean> map = L(arrayList1, list, paramBoolean, c3, c1);
    I(arrayList, list, map.containsValue(Boolean.TRUE), map);
    Iterator<q.c> iterator = list.iterator();
    while (iterator.hasNext())
      D(iterator.next()); 
    list.clear();
    if (FragmentManager.Q0(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Completed executing operations from ");
      stringBuilder.append(c3);
      stringBuilder.append(" to ");
      stringBuilder.append(c1);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
  }
  
  class d {}
  
  class d {}
  
  class d {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\fragment\app\d.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */