package androidx.fragment.app;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import java.util.concurrent.CopyOnWriteArrayList;

public class h {
  public final CopyOnWriteArrayList<a> a = new CopyOnWriteArrayList<>();
  
  public final FragmentManager b;
  
  public h(FragmentManager paramFragmentManager) {
    this.b = paramFragmentManager;
  }
  
  public void a(Fragment paramFragment, Bundle paramBundle, boolean paramBoolean) {
    Fragment fragment = this.b.G0();
    if (fragment != null)
      fragment.getParentFragmentManager().F0().a(paramFragment, paramBundle, true); 
    for (a a : this.a) {
      if (!paramBoolean || a.b)
        a.a.d(this.b, paramFragment, paramBundle); 
    } 
  }
  
  public void b(Fragment paramFragment, boolean paramBoolean) {
    Context context = this.b.D0().f();
    Fragment fragment = this.b.G0();
    if (fragment != null)
      fragment.getParentFragmentManager().F0().b(paramFragment, true); 
    for (a a : this.a) {
      if (!paramBoolean || a.b)
        a.a.e(this.b, paramFragment, context); 
    } 
  }
  
  public void c(Fragment paramFragment, Bundle paramBundle, boolean paramBoolean) {
    Fragment fragment = this.b.G0();
    if (fragment != null)
      fragment.getParentFragmentManager().F0().c(paramFragment, paramBundle, true); 
    for (a a : this.a) {
      if (!paramBoolean || a.b)
        a.a.f(this.b, paramFragment, paramBundle); 
    } 
  }
  
  public void d(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.b.G0();
    if (fragment != null)
      fragment.getParentFragmentManager().F0().d(paramFragment, true); 
    for (a a : this.a) {
      if (!paramBoolean || a.b)
        a.a.g(this.b, paramFragment); 
    } 
  }
  
  public void e(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.b.G0();
    if (fragment != null)
      fragment.getParentFragmentManager().F0().e(paramFragment, true); 
    for (a a : this.a) {
      if (!paramBoolean || a.b)
        a.a.h(this.b, paramFragment); 
    } 
  }
  
  public void f(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.b.G0();
    if (fragment != null)
      fragment.getParentFragmentManager().F0().f(paramFragment, true); 
    for (a a : this.a) {
      if (!paramBoolean || a.b)
        a.a.i(this.b, paramFragment); 
    } 
  }
  
  public void g(Fragment paramFragment, boolean paramBoolean) {
    Context context = this.b.D0().f();
    Fragment fragment = this.b.G0();
    if (fragment != null)
      fragment.getParentFragmentManager().F0().g(paramFragment, true); 
    for (a a : this.a) {
      if (!paramBoolean || a.b)
        a.a.j(this.b, paramFragment, context); 
    } 
  }
  
  public void h(Fragment paramFragment, Bundle paramBundle, boolean paramBoolean) {
    Fragment fragment = this.b.G0();
    if (fragment != null)
      fragment.getParentFragmentManager().F0().h(paramFragment, paramBundle, true); 
    for (a a : this.a) {
      if (!paramBoolean || a.b)
        a.a.k(this.b, paramFragment, paramBundle); 
    } 
  }
  
  public void i(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.b.G0();
    if (fragment != null)
      fragment.getParentFragmentManager().F0().i(paramFragment, true); 
    for (a a : this.a) {
      if (!paramBoolean || a.b)
        a.a.l(this.b, paramFragment); 
    } 
  }
  
  public void j(Fragment paramFragment, Bundle paramBundle, boolean paramBoolean) {
    Fragment fragment = this.b.G0();
    if (fragment != null)
      fragment.getParentFragmentManager().F0().j(paramFragment, paramBundle, true); 
    for (a a : this.a) {
      if (!paramBoolean || a.b)
        a.a.m(this.b, paramFragment, paramBundle); 
    } 
  }
  
  public void k(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.b.G0();
    if (fragment != null)
      fragment.getParentFragmentManager().F0().k(paramFragment, true); 
    for (a a : this.a) {
      if (!paramBoolean || a.b)
        a.a.n(this.b, paramFragment); 
    } 
  }
  
  public void l(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.b.G0();
    if (fragment != null)
      fragment.getParentFragmentManager().F0().l(paramFragment, true); 
    for (a a : this.a) {
      if (!paramBoolean || a.b)
        a.a.o(this.b, paramFragment); 
    } 
  }
  
  public void m(Fragment paramFragment, View paramView, Bundle paramBundle, boolean paramBoolean) {
    Fragment fragment = this.b.G0();
    if (fragment != null)
      fragment.getParentFragmentManager().F0().m(paramFragment, paramView, paramBundle, true); 
    for (a a : this.a) {
      if (!paramBoolean || a.b)
        a.a.p(this.b, paramFragment, paramView, paramBundle); 
    } 
  }
  
  public void n(Fragment paramFragment, boolean paramBoolean) {
    Fragment fragment = this.b.G0();
    if (fragment != null)
      fragment.getParentFragmentManager().F0().n(paramFragment, true); 
    for (a a : this.a) {
      if (!paramBoolean || a.b)
        a.a.q(this.b, paramFragment); 
    } 
  }
  
  public void o(FragmentManager.FragmentLifecycleCallbacks paramFragmentLifecycleCallbacks, boolean paramBoolean) {
    this.a.add(new a(paramFragmentLifecycleCallbacks, paramBoolean));
  }
  
  public void p(FragmentManager.FragmentLifecycleCallbacks paramFragmentLifecycleCallbacks) {
    CopyOnWriteArrayList<a> copyOnWriteArrayList = this.a;
    /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{java/util/concurrent/CopyOnWriteArrayList<InnerObjectType{ObjectType{androidx/fragment/app/h}.Landroidx/fragment/app/h$a;}>}, name=null} */
    try {
      int i = this.a.size();
      for (byte b = 0; b < i; b++) {
        if (((a)this.a.get(b)).a == paramFragmentLifecycleCallbacks) {
          this.a.remove(b);
          break;
        } 
      } 
    } finally {}
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/util/concurrent/CopyOnWriteArrayList<InnerObjectType{ObjectType{androidx/fragment/app/h}.Landroidx/fragment/app/h$a;}>}, name=null} */
  }
  
  public static final class a {
    public final FragmentManager.FragmentLifecycleCallbacks a;
    
    public final boolean b;
    
    public a(FragmentManager.FragmentLifecycleCallbacks param1FragmentLifecycleCallbacks, boolean param1Boolean) {
      this.a = param1FragmentLifecycleCallbacks;
      this.b = param1Boolean;
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\fragment\app\h.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */