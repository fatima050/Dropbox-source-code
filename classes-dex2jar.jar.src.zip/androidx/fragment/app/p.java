package androidx.fragment.app;

import android.app.Application;
import android.content.Context;
import android.content.ContextWrapper;
import android.os.Bundle;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.e;
import androidx.lifecycle.f;
import androidx.lifecycle.j;
import androidx.lifecycle.q;
import androidx.lifecycle.t;
import androidx.savedstate.a;
import dbxyzptlk.J4.c;
import dbxyzptlk.J4.d;
import dbxyzptlk.U2.y;
import dbxyzptlk.U2.z;
import dbxyzptlk.X2.a;
import dbxyzptlk.X2.b;

public class p implements e, d, z {
  public final Fragment a;
  
  public final y b;
  
  public final Runnable c;
  
  public t.b d;
  
  public j e = null;
  
  public c f = null;
  
  public p(Fragment paramFragment, y paramy, Runnable paramRunnable) {
    this.a = paramFragment;
    this.b = paramy;
    this.c = paramRunnable;
  }
  
  public void a(f.a parama) {
    this.e.i(parama);
  }
  
  public void b() {
    if (this.e == null) {
      this.e = new j((LifecycleOwner)this);
      c c1 = c.a(this);
      this.f = c1;
      c1.c();
      this.c.run();
    } 
  }
  
  public boolean c() {
    boolean bool;
    if (this.e != null) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public void d(Bundle paramBundle) {
    this.f.d(paramBundle);
  }
  
  public void e(Bundle paramBundle) {
    this.f.e(paramBundle);
  }
  
  public void f(f.b paramb) {
    this.e.n(paramb);
  }
  
  public a getDefaultViewModelCreationExtras() {
    Context context = this.a.requireContext().getApplicationContext();
    while (true) {
      if (context instanceof ContextWrapper) {
        Application application;
        if (context instanceof Application) {
          application = (Application)context;
          break;
        } 
        Context context1 = ((ContextWrapper)application).getBaseContext();
        continue;
      } 
      context = null;
      break;
    } 
    b b1 = new b();
    if (context != null)
      b1.c(t.a.h, context); 
    b1.c(androidx.lifecycle.p.a, this.a);
    b1.c(androidx.lifecycle.p.b, this);
    if (this.a.getArguments() != null)
      b1.c(androidx.lifecycle.p.c, this.a.getArguments()); 
    return (a)b1;
  }
  
  public t.b getDefaultViewModelProviderFactory() {
    t.b b1 = this.a.getDefaultViewModelProviderFactory();
    if (!b1.equals(this.a.mDefaultFactory)) {
      this.d = b1;
      return b1;
    } 
    if (this.d == null) {
      Context context = this.a.requireContext().getApplicationContext();
      while (true) {
        if (context instanceof ContextWrapper) {
          Application application;
          if (context instanceof Application) {
            application = (Application)context;
            break;
          } 
          Context context1 = ((ContextWrapper)application).getBaseContext();
          continue;
        } 
        context = null;
        break;
      } 
      Fragment fragment = this.a;
      this.d = (t.b)new q((Application)context, fragment, fragment.getArguments());
    } 
    return this.d;
  }
  
  public f getLifecycle() {
    b();
    return (f)this.e;
  }
  
  public a getSavedStateRegistry() {
    b();
    return this.f.b();
  }
  
  public y getViewModelStore() {
    b();
    return this.b;
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\fragment\app\p.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */