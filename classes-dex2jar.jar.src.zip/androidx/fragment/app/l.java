package androidx.fragment.app;

import android.app.Activity;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import androidx.lifecycle.f;
import dbxyzptlk.K2.p;
import dbxyzptlk.h2.h0;

public class l {
  public final h a;
  
  public final n b;
  
  public final Fragment c;
  
  public boolean d = false;
  
  public int e = -1;
  
  public l(h paramh, n paramn, Fragment paramFragment) {
    this.a = paramh;
    this.b = paramn;
    this.c = paramFragment;
  }
  
  public l(h paramh, n paramn, Fragment paramFragment, Bundle paramBundle) {
    this.a = paramh;
    this.b = paramn;
    this.c = paramFragment;
    paramFragment.mSavedViewState = null;
    paramFragment.mSavedViewRegistryState = null;
    paramFragment.mBackStackNesting = 0;
    paramFragment.mInLayout = false;
    paramFragment.mAdded = false;
    Fragment fragment = paramFragment.mTarget;
    if (fragment != null) {
      String str = fragment.mWho;
    } else {
      fragment = null;
    } 
    paramFragment.mTargetWho = (String)fragment;
    paramFragment.mTarget = null;
    paramFragment.mSavedFragmentState = paramBundle;
    paramFragment.mArguments = paramBundle.getBundle("arguments");
  }
  
  public l(h paramh, n paramn, ClassLoader paramClassLoader, f paramf, Bundle paramBundle) {
    this.a = paramh;
    this.b = paramn;
    Fragment fragment = ((k)paramBundle.getParcelable("state")).a(paramf, paramClassLoader);
    this.c = fragment;
    fragment.mSavedFragmentState = paramBundle;
    Bundle bundle = paramBundle.getBundle("arguments");
    if (bundle != null)
      bundle.setClassLoader(paramClassLoader); 
    fragment.setArguments(bundle);
    if (FragmentManager.Q0(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Instantiated fragment ");
      stringBuilder.append(fragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
  }
  
  public void a() {
    if (FragmentManager.Q0(3)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("moveto ACTIVITY_CREATED: ");
      stringBuilder.append(this.c);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    Bundle bundle = this.c.mSavedFragmentState;
    if (bundle != null) {
      bundle = bundle.getBundle("savedInstanceState");
    } else {
      bundle = null;
    } 
    this.c.performActivityCreated(bundle);
    this.a.a(this.c, bundle, false);
  }
  
  public void b() {
    Fragment fragment1 = FragmentManager.p0((View)this.c.mContainer);
    Fragment fragment2 = this.c.getParentFragment();
    if (fragment1 != null && !fragment1.equals(fragment2)) {
      fragment2 = this.c;
      dbxyzptlk.L2.b.o(fragment2, fragment1, fragment2.mContainerId);
    } 
    int i = this.b.j(this.c);
    fragment1 = this.c;
    fragment1.mContainer.addView(fragment1.mView, i);
  }
  
  public void c() {
    StringBuilder stringBuilder;
    if (FragmentManager.Q0(3)) {
      stringBuilder = new StringBuilder();
      stringBuilder.append("moveto ATTACHED: ");
      stringBuilder.append(this.c);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    Fragment fragment2 = this.c;
    Fragment fragment3 = fragment2.mTarget;
    l l1 = null;
    if (fragment3 != null) {
      l1 = this.b.n(fragment3.mWho);
      if (l1 != null) {
        fragment2 = this.c;
        fragment2.mTargetWho = fragment2.mTarget.mWho;
        fragment2.mTarget = null;
      } else {
        stringBuilder = new StringBuilder();
        stringBuilder.append("Fragment ");
        stringBuilder.append(this.c);
        stringBuilder.append(" declared target fragment ");
        stringBuilder.append(this.c.mTarget);
        stringBuilder.append(" that does not belong to this FragmentManager!");
        throw new IllegalStateException(stringBuilder.toString());
      } 
    } else {
      String str = fragment2.mTargetWho;
      if (str != null) {
        l1 = this.b.n(str);
        if (l1 == null) {
          stringBuilder = new StringBuilder();
          stringBuilder.append("Fragment ");
          stringBuilder.append(this.c);
          stringBuilder.append(" declared target fragment ");
          stringBuilder.append(this.c.mTargetWho);
          stringBuilder.append(" that does not belong to this FragmentManager!");
          throw new IllegalStateException(stringBuilder.toString());
        } 
      } 
    } 
    if (stringBuilder != null)
      stringBuilder.m(); 
    Fragment fragment1 = this.c;
    fragment1.mHost = fragment1.mFragmentManager.D0();
    fragment1 = this.c;
    fragment1.mParentFragment = fragment1.mFragmentManager.G0();
    this.a.g(this.c, false);
    this.c.performAttach();
    this.a.b(this.c, false);
  }
  
  public int d() {
    Fragment fragment = this.c;
    if (fragment.mFragmentManager == null)
      return fragment.mState; 
    int i = this.e;
    int k = b.a[fragment.mMaxState.ordinal()];
    int j = i;
    if (k != 1)
      if (k != 2) {
        if (k != 3) {
          if (k != 4) {
            j = Math.min(i, -1);
          } else {
            j = Math.min(i, 0);
          } 
        } else {
          j = Math.min(i, 1);
        } 
      } else {
        j = Math.min(i, 5);
      }  
    fragment = this.c;
    i = j;
    if (fragment.mFromLayout) {
      View view;
      if (fragment.mInLayout) {
        j = Math.max(this.e, 2);
        view = this.c.mView;
        i = j;
        if (view != null) {
          i = j;
          if (view.getParent() == null)
            i = Math.min(j, 2); 
        } 
      } else if (this.e < 4) {
        i = Math.min(j, ((Fragment)view).mState);
      } else {
        i = Math.min(j, 1);
      } 
    } 
    j = i;
    if (!this.c.mAdded)
      j = Math.min(i, 1); 
    fragment = this.c;
    ViewGroup viewGroup = fragment.mContainer;
    if (viewGroup != null) {
      q.c.a a = q.r(viewGroup, fragment.getParentFragmentManager()).p(this);
    } else {
      fragment = null;
    } 
    if (fragment == q.c.a.ADDING) {
      i = Math.min(j, 6);
    } else if (fragment == q.c.a.REMOVING) {
      i = Math.max(j, 3);
    } else {
      fragment = this.c;
      i = j;
      if (fragment.mRemoving)
        if (fragment.isInBackStack()) {
          i = Math.min(j, 1);
        } else {
          i = Math.min(j, -1);
        }  
    } 
    fragment = this.c;
    j = i;
    if (fragment.mDeferStart) {
      j = i;
      if (fragment.mState < 5)
        j = Math.min(i, 4); 
    } 
    if (FragmentManager.Q0(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("computeExpectedState() of ");
      stringBuilder.append(j);
      stringBuilder.append(" for ");
      stringBuilder.append(this.c);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    return j;
  }
  
  public void e() {
    if (FragmentManager.Q0(3)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("moveto CREATED: ");
      stringBuilder.append(this.c);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    Bundle bundle = this.c.mSavedFragmentState;
    if (bundle != null) {
      bundle = bundle.getBundle("savedInstanceState");
    } else {
      bundle = null;
    } 
    Fragment fragment = this.c;
    if (!fragment.mIsCreated) {
      this.a.h(fragment, bundle, false);
      this.c.performCreate(bundle);
      this.a.c(this.c, bundle, false);
    } else {
      fragment.mState = 1;
      fragment.restoreChildFragmentState();
    } 
  }
  
  public void f() {
    StringBuilder stringBuilder1;
    StringBuilder stringBuilder2;
    if (this.c.mFromLayout)
      return; 
    if (FragmentManager.Q0(3)) {
      stringBuilder1 = new StringBuilder();
      stringBuilder1.append("moveto CREATE_VIEW: ");
      stringBuilder1.append(this.c);
      Log.d("FragmentManager", stringBuilder1.toString());
    } 
    Bundle bundle = this.c.mSavedFragmentState;
    ViewGroup viewGroup1 = null;
    if (bundle != null) {
      bundle = bundle.getBundle("savedInstanceState");
    } else {
      bundle = null;
    } 
    LayoutInflater layoutInflater = this.c.performGetLayoutInflater(bundle);
    Fragment fragment2 = this.c;
    ViewGroup viewGroup2 = fragment2.mContainer;
    if (viewGroup2 != null) {
      viewGroup1 = viewGroup2;
    } else {
      int i = fragment2.mContainerId;
      if (i != 0)
        if (i != -1) {
          viewGroup2 = (ViewGroup)fragment2.mFragmentManager.x0().c(this.c.mContainerId);
          if (viewGroup2 == null) {
            ViewGroup viewGroup;
            Fragment fragment = this.c;
            if (fragment.mRestored) {
              viewGroup = viewGroup2;
            } else {
              String str;
              try {
                str = viewGroup.getResources().getResourceName(this.c.mContainerId);
              } catch (android.content.res.Resources.NotFoundException notFoundException) {
                str = "unknown";
              } 
              stringBuilder2 = new StringBuilder();
              stringBuilder2.append("No view found for id 0x");
              stringBuilder2.append(Integer.toHexString(this.c.mContainerId));
              stringBuilder2.append(" (");
              stringBuilder2.append(str);
              stringBuilder2.append(") for fragment ");
              stringBuilder2.append(this.c);
              throw new IllegalArgumentException(stringBuilder2.toString());
            } 
          } else {
            viewGroup1 = viewGroup2;
            if (!(viewGroup2 instanceof FragmentContainerView)) {
              dbxyzptlk.L2.b.n(this.c, viewGroup2);
              viewGroup1 = viewGroup2;
            } 
          } 
        } else {
          stringBuilder1 = new StringBuilder();
          stringBuilder1.append("Cannot create fragment ");
          stringBuilder1.append(this.c);
          stringBuilder1.append(" for a container view with no id");
          throw new IllegalArgumentException(stringBuilder1.toString());
        }  
    } 
    Fragment fragment1 = this.c;
    fragment1.mContainer = (ViewGroup)stringBuilder1;
    fragment1.performCreateView(layoutInflater, (ViewGroup)stringBuilder1, (Bundle)stringBuilder2);
    if (this.c.mView != null) {
      if (FragmentManager.Q0(3)) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("moveto VIEW_CREATED: ");
        stringBuilder.append(this.c);
        Log.d("FragmentManager", stringBuilder.toString());
      } 
      this.c.mView.setSaveFromParentEnabled(false);
      fragment1 = this.c;
      fragment1.mView.setTag(dbxyzptlk.J2.b.fragment_container_view_tag, fragment1);
      if (stringBuilder1 != null)
        b(); 
      Fragment fragment = this.c;
      if (fragment.mHidden)
        fragment.mView.setVisibility(8); 
      if (h0.T(this.c.mView)) {
        h0.n0(this.c.mView);
      } else {
        View view = this.c.mView;
        view.addOnAttachStateChangeListener(new a(this, view));
      } 
      this.c.performViewCreated();
      h h1 = this.a;
      fragment = this.c;
      h1.m(fragment, fragment.mView, (Bundle)stringBuilder2, false);
      int i = this.c.mView.getVisibility();
      float f = this.c.mView.getAlpha();
      this.c.setPostOnViewCreatedAlpha(f);
      fragment = this.c;
      if (fragment.mContainer != null && i == 0) {
        View view = fragment.mView.findFocus();
        if (view != null) {
          this.c.setFocusedView(view);
          if (FragmentManager.Q0(2)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("requestFocus: Saved focused view ");
            stringBuilder.append(view);
            stringBuilder.append(" for Fragment ");
            stringBuilder.append(this.c);
            Log.v("FragmentManager", stringBuilder.toString());
          } 
        } 
        this.c.mView.setAlpha(0.0F);
      } 
    } 
    this.c.mState = 2;
  }
  
  public void g() {
    boolean bool;
    if (FragmentManager.Q0(3)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("movefrom CREATED: ");
      stringBuilder.append(this.c);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    Fragment fragment = this.c;
    boolean bool2 = fragment.mRemoving;
    boolean bool1 = true;
    if (bool2 && !fragment.isInBackStack()) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      fragment = this.c;
      if (!fragment.mBeingSaved)
        this.b.B(fragment.mWho, null); 
    } 
    if (bool || this.b.p().R(this.c)) {
      int i;
      p<?> p = this.c.mHost;
      if (p instanceof dbxyzptlk.U2.z) {
        bool1 = this.b.p().O();
      } else if (p.f() instanceof Activity) {
        i = true ^ ((Activity)p.f()).isChangingConfigurations();
      } 
      if ((bool && !this.c.mBeingSaved) || i != 0)
        this.b.p().G(this.c, false); 
      this.c.performDestroy();
      this.a.d(this.c, false);
      for (l l1 : this.b.k()) {
        if (l1 != null) {
          Fragment fragment2 = l1.k();
          if (this.c.mWho.equals(fragment2.mTargetWho)) {
            fragment2.mTarget = this.c;
            fragment2.mTargetWho = null;
          } 
        } 
      } 
      Fragment fragment1 = this.c;
      String str1 = fragment1.mTargetWho;
      if (str1 != null)
        fragment1.mTarget = this.b.f(str1); 
      this.b.s(this);
      return;
    } 
    String str = this.c.mTargetWho;
    if (str != null) {
      Fragment fragment1 = this.b.f(str);
      if (fragment1 != null && fragment1.mRetainInstance)
        this.c.mTarget = fragment1; 
    } 
    this.c.mState = 0;
  }
  
  public void h() {
    if (FragmentManager.Q0(3)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("movefrom CREATE_VIEW: ");
      stringBuilder.append(this.c);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    Fragment fragment2 = this.c;
    ViewGroup viewGroup = fragment2.mContainer;
    if (viewGroup != null) {
      View view = fragment2.mView;
      if (view != null)
        viewGroup.removeView(view); 
    } 
    this.c.performDestroyView();
    this.a.n(this.c, false);
    Fragment fragment1 = this.c;
    fragment1.mContainer = null;
    fragment1.mView = null;
    fragment1.mViewLifecycleOwner = null;
    fragment1.mViewLifecycleOwnerLiveData.p(null);
    this.c.mInLayout = false;
  }
  
  public void i() {
    if (FragmentManager.Q0(3)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("movefrom ATTACHED: ");
      stringBuilder.append(this.c);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    this.c.performDetach();
    this.a.e(this.c, false);
    Fragment fragment = this.c;
    fragment.mState = -1;
    fragment.mHost = null;
    fragment.mParentFragment = null;
    fragment.mFragmentManager = null;
    if ((fragment.mRemoving && !fragment.isInBackStack()) || this.b.p().R(this.c)) {
      if (FragmentManager.Q0(3)) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("initState called for fragment: ");
        stringBuilder.append(this.c);
        Log.d("FragmentManager", stringBuilder.toString());
      } 
      this.c.initState();
    } 
  }
  
  public void j() {
    Fragment fragment = this.c;
    if (fragment.mFromLayout && fragment.mInLayout && !fragment.mPerformedCreateView) {
      if (FragmentManager.Q0(3)) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("moveto CREATE_VIEW: ");
        stringBuilder.append(this.c);
        Log.d("FragmentManager", stringBuilder.toString());
      } 
      Bundle bundle = this.c.mSavedFragmentState;
      if (bundle != null) {
        bundle = bundle.getBundle("savedInstanceState");
      } else {
        bundle = null;
      } 
      Fragment fragment1 = this.c;
      fragment1.performCreateView(fragment1.performGetLayoutInflater(bundle), null, bundle);
      View view = this.c.mView;
      if (view != null) {
        view.setSaveFromParentEnabled(false);
        Fragment fragment2 = this.c;
        fragment2.mView.setTag(dbxyzptlk.J2.b.fragment_container_view_tag, fragment2);
        fragment2 = this.c;
        if (fragment2.mHidden)
          fragment2.mView.setVisibility(8); 
        this.c.performViewCreated();
        h h1 = this.a;
        fragment2 = this.c;
        h1.m(fragment2, fragment2.mView, bundle, false);
        this.c.mState = 2;
      } 
    } 
  }
  
  public Fragment k() {
    return this.c;
  }
  
  public final boolean l(View paramView) {
    if (paramView == this.c.mView)
      return true; 
    for (ViewParent viewParent = paramView.getParent(); viewParent != null; viewParent = viewParent.getParent()) {
      if (viewParent == this.c.mView)
        return true; 
    } 
    return false;
  }
  
  public void m() {
    if (this.d) {
      if (FragmentManager.Q0(2)) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Ignoring re-entrant call to moveToExpectedState() for ");
        stringBuilder.append(k());
        Log.v("FragmentManager", stringBuilder.toString());
      } 
      return;
    } 
    try {
      this.d = true;
      boolean bool = false;
      while (true) {
        ViewGroup viewGroup;
        int i = d();
        Fragment fragment2 = this.c;
        int j = fragment2.mState;
        if (i != j) {
          if (i > j) {
            switch (j + 1) {
              case 7:
                p();
                break;
              case 6:
                fragment2.mState = 6;
                break;
              case 5:
                u();
                break;
              case 4:
                if (fragment2.mView != null) {
                  ViewGroup viewGroup1 = fragment2.mContainer;
                  if (viewGroup1 != null)
                    q.r(viewGroup1, fragment2.getParentFragmentManager()).f(q.c.b.from(this.c.mView.getVisibility()), this); 
                } 
                this.c.mState = 4;
                break;
              case 3:
                a();
                break;
              case 2:
                j();
                f();
                break;
              case 1:
                e();
                break;
              case 0:
                c();
                break;
            } 
          } else {
            Fragment fragment;
            switch (j - 1) {
              case 6:
                n();
                break;
              case 5:
                fragment2.mState = 5;
                break;
              case 4:
                v();
                break;
              case 3:
                if (FragmentManager.Q0(3)) {
                  StringBuilder stringBuilder = new StringBuilder();
                  this();
                  stringBuilder.append("movefrom ACTIVITY_CREATED: ");
                  stringBuilder.append(this.c);
                  Log.d("FragmentManager", stringBuilder.toString());
                } 
                fragment = this.c;
                if (fragment.mBeingSaved) {
                  this.b.B(fragment.mWho, r());
                } else if (fragment.mView != null && fragment.mSavedViewState == null) {
                  s();
                } 
                fragment = this.c;
                if (fragment.mView != null) {
                  viewGroup = fragment.mContainer;
                  if (viewGroup != null)
                    q.r(viewGroup, fragment.getParentFragmentManager()).h(this); 
                } 
                this.c.mState = 3;
                break;
              case 2:
                ((Fragment)viewGroup).mInLayout = false;
                ((Fragment)viewGroup).mState = 2;
                break;
              case 1:
                h();
                this.c.mState = 1;
                break;
              case 0:
                if (((Fragment)viewGroup).mBeingSaved && this.b.q(((Fragment)viewGroup).mWho) == null)
                  this.b.B(this.c.mWho, r()); 
                g();
                break;
              case -1:
                i();
                break;
            } 
          } 
          bool = true;
          continue;
        } 
        if (!bool && j == -1 && ((Fragment)viewGroup).mRemoving && !viewGroup.isInBackStack() && !this.c.mBeingSaved) {
          if (FragmentManager.Q0(3)) {
            StringBuilder stringBuilder = new StringBuilder();
            this();
            stringBuilder.append("Cleaning up state of never attached fragment: ");
            stringBuilder.append(this.c);
            Log.d("FragmentManager", stringBuilder.toString());
          } 
          this.b.p().G(this.c, true);
          this.b.s(this);
          if (FragmentManager.Q0(3)) {
            StringBuilder stringBuilder = new StringBuilder();
            this();
            stringBuilder.append("initState called for fragment: ");
            stringBuilder.append(this.c);
            Log.d("FragmentManager", stringBuilder.toString());
          } 
          this.c.initState();
        } 
        Fragment fragment1 = this.c;
        if (fragment1.mHiddenChanged) {
          if (fragment1.mView != null) {
            viewGroup = fragment1.mContainer;
            if (viewGroup != null) {
              q q = q.r(viewGroup, fragment1.getParentFragmentManager());
              if (this.c.mHidden) {
                q.g(this);
              } else {
                q.i(this);
              } 
            } 
          } 
          Fragment fragment4 = this.c;
          FragmentManager fragmentManager = fragment4.mFragmentManager;
          if (fragmentManager != null)
            fragmentManager.O0(fragment4); 
          Fragment fragment3 = this.c;
          fragment3.mHiddenChanged = false;
          fragment3.onHiddenChanged(fragment3.mHidden);
          this.c.mChildFragmentManager.L();
        } 
        return;
      } 
    } finally {
      this.d = false;
    } 
  }
  
  public void n() {
    if (FragmentManager.Q0(3)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("movefrom RESUMED: ");
      stringBuilder.append(this.c);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    this.c.performPause();
    this.a.f(this.c, false);
  }
  
  public void o(ClassLoader paramClassLoader) {
    Bundle bundle = this.c.mSavedFragmentState;
    if (bundle == null)
      return; 
    bundle.setClassLoader(paramClassLoader);
    if (this.c.mSavedFragmentState.getBundle("savedInstanceState") == null)
      this.c.mSavedFragmentState.putBundle("savedInstanceState", new Bundle()); 
    Fragment fragment = this.c;
    fragment.mSavedViewState = fragment.mSavedFragmentState.getSparseParcelableArray("viewState");
    fragment = this.c;
    fragment.mSavedViewRegistryState = fragment.mSavedFragmentState.getBundle("viewRegistryState");
    k k = (k)this.c.mSavedFragmentState.getParcelable("state");
    if (k != null) {
      fragment = this.c;
      fragment.mTargetWho = k.l;
      fragment.mTargetRequestCode = k.m;
      Boolean bool = fragment.mSavedUserVisibleHint;
      if (bool != null) {
        fragment.mUserVisibleHint = bool.booleanValue();
        this.c.mSavedUserVisibleHint = null;
      } else {
        fragment.mUserVisibleHint = k.n;
      } 
    } 
    fragment = this.c;
    if (!fragment.mUserVisibleHint)
      fragment.mDeferStart = true; 
  }
  
  public void p() {
    if (FragmentManager.Q0(3)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("moveto RESUMED: ");
      stringBuilder.append(this.c);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    View view = this.c.getFocusedView();
    if (view != null && l(view)) {
      boolean bool = view.requestFocus();
      if (FragmentManager.Q0(2)) {
        String str;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("requestFocus: Restoring focused view ");
        stringBuilder.append(view);
        stringBuilder.append(" ");
        if (bool) {
          str = "succeeded";
        } else {
          str = "failed";
        } 
        stringBuilder.append(str);
        stringBuilder.append(" on Fragment ");
        stringBuilder.append(this.c);
        stringBuilder.append(" resulting in focused view ");
        stringBuilder.append(this.c.mView.findFocus());
        Log.v("FragmentManager", stringBuilder.toString());
      } 
    } 
    this.c.setFocusedView(null);
    this.c.performResume();
    this.a.i(this.c, false);
    this.b.B(this.c.mWho, null);
    Fragment fragment = this.c;
    fragment.mSavedFragmentState = null;
    fragment.mSavedViewState = null;
    fragment.mSavedViewRegistryState = null;
  }
  
  public Fragment.SavedState q() {
    return (this.c.mState > -1) ? new Fragment.SavedState(r()) : null;
  }
  
  public Bundle r() {
    Bundle bundle1 = new Bundle();
    Fragment fragment = this.c;
    if (fragment.mState == -1) {
      Bundle bundle = fragment.mSavedFragmentState;
      if (bundle != null)
        bundle1.putAll(bundle); 
    } 
    bundle1.putParcelable("state", (Parcelable)new k(this.c));
    if (this.c.mState > -1) {
      Bundle bundle4 = new Bundle();
      this.c.performSaveInstanceState(bundle4);
      if (!bundle4.isEmpty())
        bundle1.putBundle("savedInstanceState", bundle4); 
      this.a.j(this.c, bundle4, false);
      bundle4 = new Bundle();
      this.c.mSavedStateRegistryController.e(bundle4);
      if (!bundle4.isEmpty())
        bundle1.putBundle("registryState", bundle4); 
      bundle4 = this.c.mChildFragmentManager.D1();
      if (!bundle4.isEmpty())
        bundle1.putBundle("childFragmentManager", bundle4); 
      if (this.c.mView != null)
        s(); 
      SparseArray<Parcelable> sparseArray = this.c.mSavedViewState;
      if (sparseArray != null)
        bundle1.putSparseParcelableArray("viewState", sparseArray); 
      Bundle bundle3 = this.c.mSavedViewRegistryState;
      if (bundle3 != null)
        bundle1.putBundle("viewRegistryState", bundle3); 
    } 
    Bundle bundle2 = this.c.mArguments;
    if (bundle2 != null)
      bundle1.putBundle("arguments", bundle2); 
    return bundle1;
  }
  
  public void s() {
    if (this.c.mView == null)
      return; 
    if (FragmentManager.Q0(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Saving view state for fragment ");
      stringBuilder.append(this.c);
      stringBuilder.append(" with view ");
      stringBuilder.append(this.c.mView);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    SparseArray<Parcelable> sparseArray = new SparseArray();
    this.c.mView.saveHierarchyState(sparseArray);
    if (sparseArray.size() > 0)
      this.c.mSavedViewState = sparseArray; 
    Bundle bundle = new Bundle();
    this.c.mViewLifecycleOwner.e(bundle);
    if (!bundle.isEmpty())
      this.c.mSavedViewRegistryState = bundle; 
  }
  
  public void t(int paramInt) {
    this.e = paramInt;
  }
  
  public void u() {
    if (FragmentManager.Q0(3)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("moveto STARTED: ");
      stringBuilder.append(this.c);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    this.c.performStart();
    this.a.k(this.c, false);
  }
  
  public void v() {
    if (FragmentManager.Q0(3)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("movefrom STARTED: ");
      stringBuilder.append(this.c);
      Log.d("FragmentManager", stringBuilder.toString());
    } 
    this.c.performStop();
    this.a.l(this.c, false);
  }
  
  public class a implements View.OnAttachStateChangeListener {
    public final View a;
    
    public final l b;
    
    public a(l this$0, View param1View) {}
    
    public void onViewAttachedToWindow(View param1View) {
      this.a.removeOnAttachStateChangeListener(this);
      h0.n0(this.a);
    }
    
    public void onViewDetachedFromWindow(View param1View) {}
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\fragment\app\l.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */