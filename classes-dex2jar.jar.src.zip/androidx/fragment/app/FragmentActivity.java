package androidx.fragment.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.res.Configuration;
import android.os.Bundle;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import androidx.activity.ComponentActivity;
import androidx.activity.OnBackPressedDispatcher;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.f;
import androidx.lifecycle.j;
import dbxyzptlk.J4.d;
import dbxyzptlk.K2.j;
import dbxyzptlk.K2.k;
import dbxyzptlk.K2.l;
import dbxyzptlk.K2.m;
import dbxyzptlk.K2.o;
import dbxyzptlk.K2.p;
import dbxyzptlk.K2.y;
import dbxyzptlk.T1.b;
import dbxyzptlk.T1.k;
import dbxyzptlk.T1.s;
import dbxyzptlk.T1.t;
import dbxyzptlk.T1.v;
import dbxyzptlk.T1.y;
import dbxyzptlk.U2.y;
import dbxyzptlk.U2.z;
import dbxyzptlk.V1.e;
import dbxyzptlk.V1.f;
import dbxyzptlk.e.H;
import dbxyzptlk.g.b;
import dbxyzptlk.h.d;
import dbxyzptlk.h.e;
import dbxyzptlk.h2.B;
import dbxyzptlk.h2.G;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.Iterator;

public class FragmentActivity extends ComponentActivity implements b.f {
  static final String LIFECYCLE_TAG = "android:support:lifecycle";
  
  boolean mCreated;
  
  final j mFragmentLifecycleRegistry = new j((LifecycleOwner)this);
  
  final o mFragments = o.b(new a(this));
  
  boolean mResumed;
  
  boolean mStopped = true;
  
  public FragmentActivity() {
    init();
  }
  
  public FragmentActivity(int paramInt) {
    super(paramInt);
    init();
  }
  
  private void init() {
    getSavedStateRegistry().i("android:support:lifecycle", (androidx.savedstate.a.c)new j(this));
    addOnConfigurationChangedListener((dbxyzptlk.g2.a)new k(this));
    addOnNewIntentListener((dbxyzptlk.g2.a)new l(this));
    addOnContextAvailableListener((b)new m(this));
  }
  
  private static boolean markState(FragmentManager paramFragmentManager, f.b paramb) {
    Iterator<Fragment> iterator = paramFragmentManager.C0().iterator();
    boolean bool = false;
    while (iterator.hasNext()) {
      Fragment fragment = iterator.next();
      if (fragment == null)
        continue; 
      boolean bool1 = bool;
      if (fragment.getHost() != null)
        bool1 = bool | markState(fragment.getChildFragmentManager(), paramb); 
      p p = fragment.mViewLifecycleOwner;
      bool = bool1;
      if (p != null) {
        bool = bool1;
        if (p.getLifecycle().b().isAtLeast(f.b.STARTED)) {
          fragment.mViewLifecycleOwner.f(paramb);
          bool = true;
        } 
      } 
      if (fragment.mLifecycleRegistry.b().isAtLeast(f.b.STARTED)) {
        fragment.mLifecycleRegistry.n(paramb);
        bool = true;
      } 
    } 
    return bool;
  }
  
  public final View dispatchFragmentsOnCreateView(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    return this.mFragments.n(paramView, paramString, paramContext, paramAttributeSet);
  }
  
  public void dump(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString) {
    super.dump(paramString, paramFileDescriptor, paramPrintWriter, paramArrayOfString);
    if (!shouldDumpInternalState(paramArrayOfString))
      return; 
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("Local FragmentActivity ");
    paramPrintWriter.print(Integer.toHexString(System.identityHashCode(this)));
    paramPrintWriter.println(" State:");
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramString);
    stringBuilder.append("  ");
    String str = stringBuilder.toString();
    paramPrintWriter.print(str);
    paramPrintWriter.print("mCreated=");
    paramPrintWriter.print(this.mCreated);
    paramPrintWriter.print(" mResumed=");
    paramPrintWriter.print(this.mResumed);
    paramPrintWriter.print(" mStopped=");
    paramPrintWriter.print(this.mStopped);
    if (getApplication() != null)
      dbxyzptlk.Z2.a.c((LifecycleOwner)this).b(str, paramFileDescriptor, paramPrintWriter, paramArrayOfString); 
    this.mFragments.l().Z(paramString, paramFileDescriptor, paramPrintWriter, paramArrayOfString);
  }
  
  public FragmentManager getSupportFragmentManager() {
    return this.mFragments.l();
  }
  
  @Deprecated
  public dbxyzptlk.Z2.a getSupportLoaderManager() {
    return dbxyzptlk.Z2.a.c((LifecycleOwner)this);
  }
  
  public void markFragmentsCreated() {
    do {
    
    } while (markState(getSupportFragmentManager(), f.b.CREATED));
  }
  
  public void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent) {
    this.mFragments.m();
    super.onActivityResult(paramInt1, paramInt2, paramIntent);
  }
  
  @Deprecated
  public void onAttachFragment(Fragment paramFragment) {}
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    this.mFragmentLifecycleRegistry.i(f.a.ON_CREATE);
    this.mFragments.e();
  }
  
  public View onCreateView(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    View view = dispatchFragmentsOnCreateView(paramView, paramString, paramContext, paramAttributeSet);
    return (view == null) ? super.onCreateView(paramView, paramString, paramContext, paramAttributeSet) : view;
  }
  
  public View onCreateView(String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    View view = dispatchFragmentsOnCreateView(null, paramString, paramContext, paramAttributeSet);
    return (view == null) ? super.onCreateView(paramString, paramContext, paramAttributeSet) : view;
  }
  
  public void onDestroy() {
    super.onDestroy();
    this.mFragments.f();
    this.mFragmentLifecycleRegistry.i(f.a.ON_DESTROY);
  }
  
  public boolean onMenuItemSelected(int paramInt, MenuItem paramMenuItem) {
    return super.onMenuItemSelected(paramInt, paramMenuItem) ? true : ((paramInt == 6) ? this.mFragments.d(paramMenuItem) : false);
  }
  
  public void onPause() {
    super.onPause();
    this.mResumed = false;
    this.mFragments.g();
    this.mFragmentLifecycleRegistry.i(f.a.ON_PAUSE);
  }
  
  public void onPostResume() {
    super.onPostResume();
    onResumeFragments();
  }
  
  public void onRequestPermissionsResult(int paramInt, String[] paramArrayOfString, int[] paramArrayOfint) {
    this.mFragments.m();
    super.onRequestPermissionsResult(paramInt, paramArrayOfString, paramArrayOfint);
  }
  
  public void onResume() {
    this.mFragments.m();
    super.onResume();
    this.mResumed = true;
    this.mFragments.k();
  }
  
  public void onResumeFragments() {
    this.mFragmentLifecycleRegistry.i(f.a.ON_RESUME);
    this.mFragments.h();
  }
  
  public void onStart() {
    this.mFragments.m();
    super.onStart();
    this.mStopped = false;
    if (!this.mCreated) {
      this.mCreated = true;
      this.mFragments.c();
    } 
    this.mFragments.k();
    this.mFragmentLifecycleRegistry.i(f.a.ON_START);
    this.mFragments.i();
  }
  
  public void onStateNotSaved() {
    this.mFragments.m();
  }
  
  public void onStop() {
    super.onStop();
    this.mStopped = true;
    markFragmentsCreated();
    this.mFragments.j();
    this.mFragmentLifecycleRegistry.i(f.a.ON_STOP);
  }
  
  public void setEnterSharedElementCallback(y paramy) {
    b.y((Activity)this, paramy);
  }
  
  public void setExitSharedElementCallback(y paramy) {
    b.z((Activity)this, paramy);
  }
  
  public void startActivityFromFragment(Fragment paramFragment, Intent paramIntent, int paramInt) {
    startActivityFromFragment(paramFragment, paramIntent, paramInt, null);
  }
  
  public void startActivityFromFragment(Fragment paramFragment, Intent paramIntent, int paramInt, Bundle paramBundle) {
    if (paramInt == -1) {
      b.B((Activity)this, paramIntent, -1, paramBundle);
      return;
    } 
    paramFragment.startActivityForResult(paramIntent, paramInt, paramBundle);
  }
  
  @Deprecated
  public void startIntentSenderFromFragment(Fragment paramFragment, IntentSender paramIntentSender, int paramInt1, Intent paramIntent, int paramInt2, int paramInt3, int paramInt4, Bundle paramBundle) throws IntentSender.SendIntentException {
    if (paramInt1 == -1) {
      b.C((Activity)this, paramIntentSender, paramInt1, paramIntent, paramInt2, paramInt3, paramInt4, paramBundle);
      return;
    } 
    paramFragment.startIntentSenderForResult(paramIntentSender, paramInt1, paramIntent, paramInt2, paramInt3, paramInt4, paramBundle);
  }
  
  public void supportFinishAfterTransition() {
    b.s((Activity)this);
  }
  
  @Deprecated
  public void supportInvalidateOptionsMenu() {
    invalidateMenu();
  }
  
  public void supportPostponeEnterTransition() {
    b.u((Activity)this);
  }
  
  public void supportStartPostponedEnterTransition() {
    b.D((Activity)this);
  }
  
  @Deprecated
  public final void validateRequestPermissionsRequestCode(int paramInt) {}
  
  public class a extends p<FragmentActivity> implements e, f, s, t, z, H, e, d, y, B {
    public final FragmentActivity f;
    
    public a(FragmentActivity this$0) {
      super(this$0);
    }
    
    public void a(FragmentManager param1FragmentManager, Fragment param1Fragment) {
      this.f.onAttachFragment(param1Fragment);
    }
    
    public void addMenuProvider(G param1G) {
      this.f.addMenuProvider(param1G);
    }
    
    public void addMenuProvider(G param1G, LifecycleOwner param1LifecycleOwner, f.b param1b) {
      this.f.addMenuProvider(param1G, param1LifecycleOwner, param1b);
    }
    
    public void addOnConfigurationChangedListener(dbxyzptlk.g2.a<Configuration> param1a) {
      this.f.addOnConfigurationChangedListener(param1a);
    }
    
    public void addOnMultiWindowModeChangedListener(dbxyzptlk.g2.a<k> param1a) {
      this.f.addOnMultiWindowModeChangedListener(param1a);
    }
    
    public void addOnPictureInPictureModeChangedListener(dbxyzptlk.g2.a<v> param1a) {
      this.f.addOnPictureInPictureModeChangedListener(param1a);
    }
    
    public void addOnTrimMemoryListener(dbxyzptlk.g2.a<Integer> param1a) {
      this.f.addOnTrimMemoryListener(param1a);
    }
    
    public View c(int param1Int) {
      return this.f.findViewById(param1Int);
    }
    
    public boolean d() {
      boolean bool;
      Window window = this.f.getWindow();
      if (window != null && window.peekDecorView() != null) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    public d getActivityResultRegistry() {
      return this.f.getActivityResultRegistry();
    }
    
    public f getLifecycle() {
      return (f)this.f.mFragmentLifecycleRegistry;
    }
    
    public OnBackPressedDispatcher getOnBackPressedDispatcher() {
      return this.f.getOnBackPressedDispatcher();
    }
    
    public androidx.savedstate.a getSavedStateRegistry() {
      return this.f.getSavedStateRegistry();
    }
    
    public y getViewModelStore() {
      return this.f.getViewModelStore();
    }
    
    public void h(String param1String, FileDescriptor param1FileDescriptor, PrintWriter param1PrintWriter, String[] param1ArrayOfString) {
      this.f.dump(param1String, param1FileDescriptor, param1PrintWriter, param1ArrayOfString);
    }
    
    public void invalidateMenu() {
      this.f.invalidateMenu();
    }
    
    public LayoutInflater j() {
      return this.f.getLayoutInflater().cloneInContext((Context)this.f);
    }
    
    public boolean l(String param1String) {
      return b.A((Activity)this.f, param1String);
    }
    
    public void o() {
      invalidateMenu();
    }
    
    public FragmentActivity p() {
      return this.f;
    }
    
    public void removeMenuProvider(G param1G) {
      this.f.removeMenuProvider(param1G);
    }
    
    public void removeOnConfigurationChangedListener(dbxyzptlk.g2.a<Configuration> param1a) {
      this.f.removeOnConfigurationChangedListener(param1a);
    }
    
    public void removeOnMultiWindowModeChangedListener(dbxyzptlk.g2.a<k> param1a) {
      this.f.removeOnMultiWindowModeChangedListener(param1a);
    }
    
    public void removeOnPictureInPictureModeChangedListener(dbxyzptlk.g2.a<v> param1a) {
      this.f.removeOnPictureInPictureModeChangedListener(param1a);
    }
    
    public void removeOnTrimMemoryListener(dbxyzptlk.g2.a<Integer> param1a) {
      this.f.removeOnTrimMemoryListener(param1a);
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\fragment\app\FragmentActivity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */