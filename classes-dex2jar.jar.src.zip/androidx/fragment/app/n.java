package androidx.fragment.app;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

public class n {
  public final ArrayList<Fragment> a = new ArrayList<>();
  
  public final HashMap<String, l> b = new HashMap<>();
  
  public final HashMap<String, Bundle> c = new HashMap<>();
  
  public j d;
  
  public void A(j paramj) {
    this.d = paramj;
  }
  
  public Bundle B(String paramString, Bundle paramBundle) {
    return (paramBundle != null) ? this.c.put(paramString, paramBundle) : this.c.remove(paramString);
  }
  
  public void a(Fragment paramFragment) {
    if (!this.a.contains(paramFragment))
      synchronized (this.a) {
        this.a.add(paramFragment);
        paramFragment.mAdded = true;
        return;
      }  
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment already added: ");
    stringBuilder.append(paramFragment);
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public void b() {
    this.b.values().removeAll(Collections.singleton(null));
  }
  
  public boolean c(String paramString) {
    boolean bool;
    if (this.b.get(paramString) != null) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public void d(int paramInt) {
    for (l l : this.b.values()) {
      if (l != null)
        l.t(paramInt); 
    } 
  }
  
  public void e(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramString);
    stringBuilder.append("    ");
    String str = stringBuilder.toString();
    if (!this.b.isEmpty()) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.println("Active Fragments:");
      for (l l : this.b.values()) {
        paramPrintWriter.print(paramString);
        if (l != null) {
          Fragment fragment = l.k();
          paramPrintWriter.println(fragment);
          fragment.dump(str, paramFileDescriptor, paramPrintWriter, paramArrayOfString);
          continue;
        } 
        paramPrintWriter.println("null");
      } 
    } 
    int i = this.a.size();
    if (i > 0) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.println("Added Fragments:");
      for (byte b = 0; b < i; b++) {
        Fragment fragment = this.a.get(b);
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("  #");
        paramPrintWriter.print(b);
        paramPrintWriter.print(": ");
        paramPrintWriter.println(fragment.toString());
      } 
    } 
  }
  
  public Fragment f(String paramString) {
    l l = this.b.get(paramString);
    return (l != null) ? l.k() : null;
  }
  
  public Fragment g(int paramInt) {
    for (int i = this.a.size() - 1; i >= 0; i--) {
      Fragment fragment = this.a.get(i);
      if (fragment != null && fragment.mFragmentId == paramInt)
        return fragment; 
    } 
    for (l l : this.b.values()) {
      if (l != null) {
        Fragment fragment = l.k();
        if (fragment.mFragmentId == paramInt)
          return fragment; 
      } 
    } 
    return null;
  }
  
  public Fragment h(String paramString) {
    if (paramString != null)
      for (int i = this.a.size() - 1; i >= 0; i--) {
        Fragment fragment = this.a.get(i);
        if (fragment != null && paramString.equals(fragment.mTag))
          return fragment; 
      }  
    if (paramString != null)
      for (l l : this.b.values()) {
        if (l != null) {
          Fragment fragment = l.k();
          if (paramString.equals(fragment.mTag))
            return fragment; 
        } 
      }  
    return null;
  }
  
  public Fragment i(String paramString) {
    for (l l : this.b.values()) {
      if (l != null) {
        Fragment fragment = l.k().findFragmentByWho(paramString);
        if (fragment != null)
          return fragment; 
      } 
    } 
    return null;
  }
  
  public int j(Fragment paramFragment) {
    int k;
    ViewGroup viewGroup = paramFragment.mContainer;
    if (viewGroup == null)
      return -1; 
    int m = this.a.indexOf(paramFragment);
    int i = m - 1;
    while (true) {
      k = m;
      if (i >= 0) {
        paramFragment = this.a.get(i);
        if (paramFragment.mContainer == viewGroup) {
          View view = paramFragment.mView;
          if (view != null)
            return viewGroup.indexOfChild(view) + 1; 
        } 
        i--;
        continue;
      } 
      break;
    } 
    while (++k < this.a.size()) {
      paramFragment = this.a.get(k);
      if (paramFragment.mContainer == viewGroup) {
        View view = paramFragment.mView;
        if (view != null)
          return viewGroup.indexOfChild(view); 
      } 
    } 
    return -1;
  }
  
  public List<l> k() {
    ArrayList<l> arrayList = new ArrayList();
    for (l l : this.b.values()) {
      if (l != null)
        arrayList.add(l); 
    } 
    return arrayList;
  }
  
  public List<Fragment> l() {
    ArrayList<Fragment> arrayList = new ArrayList();
    for (l l : this.b.values()) {
      if (l != null) {
        arrayList.add(l.k());
        continue;
      } 
      arrayList.add(null);
    } 
    return arrayList;
  }
  
  public HashMap<String, Bundle> m() {
    return this.c;
  }
  
  public l n(String paramString) {
    return this.b.get(paramString);
  }
  
  public List<Fragment> o() {
    if (this.a.isEmpty())
      return Collections.emptyList(); 
    synchronized (this.a) {
      ArrayList<Fragment> arrayList = new ArrayList();
      this((Collection)this.a);
      return arrayList;
    } 
  }
  
  public j p() {
    return this.d;
  }
  
  public Bundle q(String paramString) {
    return this.c.get(paramString);
  }
  
  public void r(l paraml) {
    Fragment fragment = paraml.k();
    if (c(fragment.mWho))
      return; 
    this.b.put(fragment.mWho, paraml);
    if (fragment.mRetainInstanceChangedWhileDetached) {
      if (fragment.mRetainInstance) {
        this.d.F(fragment);
      } else {
        this.d.P(fragment);
      } 
      fragment.mRetainInstanceChangedWhileDetached = false;
    } 
    if (FragmentManager.Q0(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Added fragment to active set ");
      stringBuilder.append(fragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
  }
  
  public void s(l paraml) {
    Fragment fragment = paraml.k();
    if (fragment.mRetainInstance)
      this.d.P(fragment); 
    if (this.b.get(fragment.mWho) != paraml)
      return; 
    if ((l)this.b.put(fragment.mWho, null) == null)
      return; 
    if (FragmentManager.Q0(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Removed fragment from active set ");
      stringBuilder.append(fragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
  }
  
  public void t() {
    for (Fragment fragment : this.a) {
      l l = this.b.get(fragment.mWho);
      if (l != null)
        l.m(); 
    } 
    for (l l : this.b.values()) {
      if (l != null) {
        l.m();
        Fragment fragment = l.k();
        if (fragment.mRemoving && !fragment.isInBackStack()) {
          if (fragment.mBeingSaved && !this.c.containsKey(fragment.mWho))
            B(fragment.mWho, l.r()); 
          s(l);
        } 
      } 
    } 
  }
  
  public void u(Fragment paramFragment) {
    synchronized (this.a) {
      this.a.remove(paramFragment);
      paramFragment.mAdded = false;
      return;
    } 
  }
  
  public void v() {
    this.b.clear();
  }
  
  public void w(List<String> paramList) {
    this.a.clear();
    if (paramList != null)
      for (String str : paramList) {
        Fragment fragment = f(str);
        if (fragment != null) {
          if (FragmentManager.Q0(2)) {
            StringBuilder stringBuilder1 = new StringBuilder();
            stringBuilder1.append("restoreSaveState: added (");
            stringBuilder1.append(str);
            stringBuilder1.append("): ");
            stringBuilder1.append(fragment);
            Log.v("FragmentManager", stringBuilder1.toString());
          } 
          a(fragment);
          continue;
        } 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("No instantiated fragment for (");
        stringBuilder.append(str);
        stringBuilder.append(")");
        throw new IllegalStateException(stringBuilder.toString());
      }  
  }
  
  public void x(HashMap<String, Bundle> paramHashMap) {
    this.c.clear();
    this.c.putAll(paramHashMap);
  }
  
  public ArrayList<String> y() {
    ArrayList<String> arrayList = new ArrayList(this.b.size());
    for (l l : this.b.values()) {
      if (l != null) {
        Fragment fragment = l.k();
        B(fragment.mWho, l.r());
        arrayList.add(fragment.mWho);
        if (FragmentManager.Q0(2)) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Saved state of ");
          stringBuilder.append(fragment);
          stringBuilder.append(": ");
          stringBuilder.append(fragment.mSavedFragmentState);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
      } 
    } 
    return arrayList;
  }
  
  public ArrayList<String> z() {
    ArrayList<Fragment> arrayList = this.a;
    /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{java/util/ArrayList<ObjectType{androidx/fragment/app/Fragment}>}, name=null} */
    try {
      if (this.a.isEmpty()) {
        /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/util/ArrayList<ObjectType{androidx/fragment/app/Fragment}>}, name=null} */
        return null;
      } 
    } finally {
      Exception exception;
    } 
    ArrayList<String> arrayList1 = new ArrayList();
    this(this.a.size());
    for (Fragment fragment : this.a) {
      arrayList1.add(fragment.mWho);
      if (FragmentManager.Q0(2)) {
        StringBuilder stringBuilder = new StringBuilder();
        this();
        stringBuilder.append("saveAllState: adding fragment (");
        stringBuilder.append(fragment.mWho);
        stringBuilder.append("): ");
        stringBuilder.append(fragment);
        Log.v("FragmentManager", stringBuilder.toString());
      } 
    } 
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/util/ArrayList<ObjectType{androidx/fragment/app/Fragment}>}, name=null} */
    return arrayList1;
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\fragment\app\n.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */