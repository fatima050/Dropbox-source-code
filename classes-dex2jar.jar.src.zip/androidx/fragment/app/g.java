package androidx.fragment.app;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import dbxyzptlk.J2.c;
import dbxyzptlk.L2.b;

public class g implements LayoutInflater.Factory2 {
  public final FragmentManager a;
  
  public g(FragmentManager paramFragmentManager) {
    this.a = paramFragmentManager;
  }
  
  public View onCreateView(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    Fragment fragment;
    boolean bool;
    if (FragmentContainerView.class.getName().equals(paramString))
      return (View)new FragmentContainerView(paramContext, paramAttributeSet, this.a); 
    boolean bool1 = "fragment".equals(paramString);
    paramString = null;
    if (!bool1)
      return null; 
    String str1 = paramAttributeSet.getAttributeValue(null, "class");
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, c.Fragment);
    String str2 = str1;
    if (str1 == null)
      str2 = typedArray.getString(c.Fragment_android_name); 
    int i = typedArray.getResourceId(c.Fragment_android_id, -1);
    String str3 = typedArray.getString(c.Fragment_android_tag);
    typedArray.recycle();
    if (str2 == null || !f.b(paramContext.getClassLoader(), str2))
      return null; 
    if (paramView != null) {
      bool = paramView.getId();
    } else {
      bool = false;
    } 
    if (bool != -1 || i != -1 || str3 != null) {
      StringBuilder stringBuilder2;
      l l;
      if (i != -1)
        fragment1 = this.a.l0(i); 
      Fragment fragment2 = fragment1;
      if (fragment1 == null) {
        fragment2 = fragment1;
        if (str3 != null)
          fragment2 = this.a.m0(str3); 
      } 
      Fragment fragment1 = fragment2;
      if (fragment2 == null) {
        fragment1 = fragment2;
        if (bool != -1)
          fragment1 = this.a.l0(bool); 
      } 
      if (fragment1 == null) {
        boolean bool2;
        fragment1 = this.a.A0().a(paramContext.getClassLoader(), str2);
        fragment1.mFromLayout = true;
        if (i != 0) {
          bool2 = i;
        } else {
          bool2 = bool;
        } 
        fragment1.mFragmentId = bool2;
        fragment1.mContainerId = bool;
        fragment1.mTag = str3;
        fragment1.mInLayout = true;
        FragmentManager fragmentManager = this.a;
        fragment1.mFragmentManager = fragmentManager;
        fragment1.mHost = fragmentManager.D0();
        fragment1.onInflate(this.a.D0().f(), paramAttributeSet, fragment1.mSavedFragmentState);
        l l1 = this.a.j(fragment1);
        fragment = fragment1;
        l = l1;
        if (FragmentManager.Q0(2)) {
          StringBuilder stringBuilder3 = new StringBuilder();
          stringBuilder3.append("Fragment ");
          stringBuilder3.append(fragment1);
          stringBuilder3.append(" has been inflated via the <fragment> tag: id=0x");
          stringBuilder3.append(Integer.toHexString(i));
          Log.v("FragmentManager", stringBuilder3.toString());
          fragment = fragment1;
          l l2 = l1;
        } 
      } else if (!fragment1.mInLayout) {
        fragment1.mInLayout = true;
        FragmentManager fragmentManager = this.a;
        fragment1.mFragmentManager = fragmentManager;
        fragment1.mHost = fragmentManager.D0();
        fragment1.onInflate(this.a.D0().f(), (AttributeSet)fragment, fragment1.mSavedFragmentState);
        l l1 = this.a.y(fragment1);
        fragment = fragment1;
        l = l1;
        if (FragmentManager.Q0(2)) {
          StringBuilder stringBuilder3 = new StringBuilder();
          stringBuilder3.append("Retained Fragment ");
          stringBuilder3.append(fragment1);
          stringBuilder3.append(" has been re-attached via the <fragment> tag: id=0x");
          stringBuilder3.append(Integer.toHexString(i));
          Log.v("FragmentManager", stringBuilder3.toString());
          l = l1;
          fragment = fragment1;
        } 
      } else {
        stringBuilder2 = new StringBuilder();
        stringBuilder2.append(fragment.getPositionDescription());
        stringBuilder2.append(": Duplicate id 0x");
        stringBuilder2.append(Integer.toHexString(i));
        stringBuilder2.append(", tag ");
        stringBuilder2.append(str3);
        stringBuilder2.append(", or parent id 0x");
        stringBuilder2.append(Integer.toHexString(bool));
        stringBuilder2.append(" with another fragment for ");
        stringBuilder2.append(str2);
        throw new IllegalArgumentException(stringBuilder2.toString());
      } 
      ViewGroup viewGroup = (ViewGroup)stringBuilder2;
      b.g(fragment, viewGroup);
      fragment.mContainer = viewGroup;
      l.m();
      l.j();
      View view = fragment.mView;
      if (view != null) {
        if (i != 0)
          view.setId(i); 
        if (fragment.mView.getTag() == null)
          fragment.mView.setTag(str3); 
        fragment.mView.addOnAttachStateChangeListener((View.OnAttachStateChangeListener)new a(this, l));
        return fragment.mView;
      } 
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("Fragment ");
      stringBuilder1.append(str2);
      stringBuilder1.append(" did not create a view.");
      throw new IllegalStateException(stringBuilder1.toString());
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(fragment.getPositionDescription());
    stringBuilder.append(": Must specify unique android:id, android:tag, or have a parent with an id for ");
    stringBuilder.append(str2);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public View onCreateView(String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    return onCreateView(null, paramString, paramContext, paramAttributeSet);
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\fragment\app\g.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */