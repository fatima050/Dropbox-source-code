package androidx.fragment.app;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import androidx.lifecycle.f;
import dbxyzptlk.K2.B;
import dbxyzptlk.L2.b;
import dbxyzptlk.h2.h0;
import java.lang.reflect.Modifier;
import java.util.ArrayList;

public abstract class o {
  public final f a;
  
  public final ClassLoader b;
  
  public ArrayList<a> c = new ArrayList<>();
  
  public int d;
  
  public int e;
  
  public int f;
  
  public int g;
  
  public int h;
  
  public boolean i;
  
  public boolean j = true;
  
  public String k;
  
  public int l;
  
  public CharSequence m;
  
  public int n;
  
  public CharSequence o;
  
  public ArrayList<String> p;
  
  public ArrayList<String> q;
  
  public boolean r = false;
  
  public ArrayList<Runnable> s;
  
  public o(f paramf, ClassLoader paramClassLoader) {
    this.a = paramf;
    this.b = paramClassLoader;
  }
  
  public o(f paramf, ClassLoader paramClassLoader, o paramo) {
    this(paramf, paramClassLoader);
    for (a a : paramo.c)
      this.c.add(new a(a)); 
    this.d = paramo.d;
    this.e = paramo.e;
    this.f = paramo.f;
    this.g = paramo.g;
    this.h = paramo.h;
    this.i = paramo.i;
    this.j = paramo.j;
    this.k = paramo.k;
    this.n = paramo.n;
    this.o = paramo.o;
    this.l = paramo.l;
    this.m = paramo.m;
    if (paramo.p != null) {
      ArrayList<String> arrayList = new ArrayList();
      this.p = arrayList;
      arrayList.addAll(paramo.p);
    } 
    if (paramo.q != null) {
      ArrayList<String> arrayList = new ArrayList();
      this.q = arrayList;
      arrayList.addAll(paramo.q);
    } 
    this.r = paramo.r;
  }
  
  public o A(Fragment paramFragment) {
    g(new a(8, paramFragment));
    return this;
  }
  
  public o B(boolean paramBoolean) {
    this.r = paramBoolean;
    return this;
  }
  
  public o C(int paramInt) {
    this.h = paramInt;
    return this;
  }
  
  public o b(int paramInt, Fragment paramFragment) {
    r(paramInt, paramFragment, null, 1);
    return this;
  }
  
  public o c(int paramInt, Fragment paramFragment, String paramString) {
    r(paramInt, paramFragment, paramString, 1);
    return this;
  }
  
  public final o d(int paramInt, Class<? extends Fragment> paramClass, Bundle paramBundle) {
    return b(paramInt, o(paramClass, paramBundle));
  }
  
  public o e(ViewGroup paramViewGroup, Fragment paramFragment, String paramString) {
    paramFragment.mContainer = paramViewGroup;
    return c(paramViewGroup.getId(), paramFragment, paramString);
  }
  
  public o f(Fragment paramFragment, String paramString) {
    r(0, paramFragment, paramString, 1);
    return this;
  }
  
  public void g(a parama) {
    this.c.add(parama);
    parama.d = this.d;
    parama.e = this.e;
    parama.f = this.f;
    parama.g = this.g;
  }
  
  public o h(View paramView, String paramString) {
    if (B.f()) {
      String str = h0.J(paramView);
      if (str != null) {
        StringBuilder stringBuilder1;
        StringBuilder stringBuilder2;
        if (this.p == null) {
          this.p = new ArrayList<>();
          this.q = new ArrayList<>();
        } else if (!this.q.contains(paramString)) {
          if (this.p.contains(str)) {
            stringBuilder2 = new StringBuilder();
            stringBuilder2.append("A shared element with the source name '");
            stringBuilder2.append(str);
            stringBuilder2.append("' has already been added to the transaction.");
            throw new IllegalArgumentException(stringBuilder2.toString());
          } 
        } else {
          stringBuilder1 = new StringBuilder();
          stringBuilder1.append("A shared element with the target name '");
          stringBuilder1.append((String)stringBuilder2);
          stringBuilder1.append("' has already been added to the transaction.");
          throw new IllegalArgumentException(stringBuilder1.toString());
        } 
        this.p.add(stringBuilder1);
        this.q.add(stringBuilder2);
      } else {
        throw new IllegalArgumentException("Unique transitionNames are required for all sharedElements");
      } 
    } 
    return this;
  }
  
  public o i(String paramString) {
    if (this.j) {
      this.i = true;
      this.k = paramString;
      return this;
    } 
    throw new IllegalStateException("This FragmentTransaction is not allowed to be added to the back stack.");
  }
  
  public o j(Fragment paramFragment) {
    g(new a(7, paramFragment));
    return this;
  }
  
  public abstract int k();
  
  public abstract int l();
  
  public abstract void m();
  
  public abstract void n();
  
  public final Fragment o(Class<? extends Fragment> paramClass, Bundle paramBundle) {
    f f1 = this.a;
    if (f1 != null) {
      ClassLoader classLoader = this.b;
      if (classLoader != null) {
        Fragment fragment = f1.a(classLoader, paramClass.getName());
        if (paramBundle != null)
          fragment.setArguments(paramBundle); 
        return fragment;
      } 
      throw new IllegalStateException("The FragmentManager must be attached to itshost to create a Fragment");
    } 
    throw new IllegalStateException("Creating a Fragment requires that this FragmentTransaction was built with FragmentManager.beginTransaction()");
  }
  
  public o p(Fragment paramFragment) {
    g(new a(6, paramFragment));
    return this;
  }
  
  public o q() {
    if (!this.i) {
      this.j = false;
      return this;
    } 
    throw new IllegalStateException("This transaction is already being added to the back stack");
  }
  
  public void r(int paramInt1, Fragment paramFragment, String paramString, int paramInt2) {
    StringBuilder stringBuilder2;
    String str = paramFragment.mPreviousWho;
    if (str != null)
      b.f(paramFragment, str); 
    Class<?> clazz = paramFragment.getClass();
    int i = clazz.getModifiers();
    if (!clazz.isAnonymousClass() && Modifier.isPublic(i) && (!clazz.isMemberClass() || Modifier.isStatic(i))) {
      if (paramString != null) {
        String str1 = paramFragment.mTag;
        if (str1 == null || paramString.equals(str1)) {
          paramFragment.mTag = paramString;
        } else {
          stringBuilder2 = new StringBuilder();
          stringBuilder2.append("Can't change tag of fragment ");
          stringBuilder2.append(paramFragment);
          stringBuilder2.append(": was ");
          stringBuilder2.append(paramFragment.mTag);
          stringBuilder2.append(" now ");
          stringBuilder2.append(paramString);
          throw new IllegalStateException(stringBuilder2.toString());
        } 
      } 
      if (paramInt1 != 0) {
        StringBuilder stringBuilder;
        if (paramInt1 != -1) {
          i = paramFragment.mFragmentId;
          if (i == 0 || i == paramInt1) {
            paramFragment.mFragmentId = paramInt1;
            paramFragment.mContainerId = paramInt1;
          } else {
            stringBuilder = new StringBuilder();
            stringBuilder.append("Can't change container ID of fragment ");
            stringBuilder.append(paramFragment);
            stringBuilder.append(": was ");
            stringBuilder.append(paramFragment.mFragmentId);
            stringBuilder.append(" now ");
            stringBuilder.append(paramInt1);
            throw new IllegalStateException(stringBuilder.toString());
          } 
        } else {
          stringBuilder2 = new StringBuilder();
          stringBuilder2.append("Can't add fragment ");
          stringBuilder2.append(paramFragment);
          stringBuilder2.append(" with tag ");
          stringBuilder2.append((String)stringBuilder);
          stringBuilder2.append(" to container view with no id");
          throw new IllegalArgumentException(stringBuilder2.toString());
        } 
      } 
      g(new a(paramInt2, paramFragment));
      return;
    } 
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append("Fragment ");
    stringBuilder1.append(stringBuilder2.getCanonicalName());
    stringBuilder1.append(" must be a public static class to be  properly recreated from instance state.");
    throw new IllegalStateException(stringBuilder1.toString());
  }
  
  public abstract boolean s();
  
  public o t(Fragment paramFragment) {
    g(new a(3, paramFragment));
    return this;
  }
  
  public o u(int paramInt, Fragment paramFragment) {
    return v(paramInt, paramFragment, null);
  }
  
  public o v(int paramInt, Fragment paramFragment, String paramString) {
    if (paramInt != 0) {
      r(paramInt, paramFragment, paramString, 2);
      return this;
    } 
    throw new IllegalArgumentException("Must use non-zero containerViewId");
  }
  
  public o w(Runnable paramRunnable) {
    q();
    if (this.s == null)
      this.s = new ArrayList<>(); 
    this.s.add(paramRunnable);
    return this;
  }
  
  public o x(int paramInt1, int paramInt2) {
    return y(paramInt1, paramInt2, 0, 0);
  }
  
  public o y(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this.d = paramInt1;
    this.e = paramInt2;
    this.f = paramInt3;
    this.g = paramInt4;
    return this;
  }
  
  public o z(Fragment paramFragment, f.b paramb) {
    g(new a(10, paramFragment, paramb));
    return this;
  }
  
  public static final class a {
    public int a;
    
    public Fragment b;
    
    public boolean c;
    
    public int d;
    
    public int e;
    
    public int f;
    
    public int g;
    
    public f.b h;
    
    public f.b i;
    
    public a() {}
    
    public a(int param1Int, Fragment param1Fragment) {
      this.a = param1Int;
      this.b = param1Fragment;
      this.c = false;
      f.b b1 = f.b.RESUMED;
      this.h = b1;
      this.i = b1;
    }
    
    public a(int param1Int, Fragment param1Fragment, f.b param1b) {
      this.a = param1Int;
      this.b = param1Fragment;
      this.c = false;
      this.h = param1Fragment.mMaxState;
      this.i = param1b;
    }
    
    public a(int param1Int, Fragment param1Fragment, boolean param1Boolean) {
      this.a = param1Int;
      this.b = param1Fragment;
      this.c = param1Boolean;
      f.b b1 = f.b.RESUMED;
      this.h = b1;
      this.i = b1;
    }
    
    public a(a param1a) {
      this.a = param1a.a;
      this.b = param1a.b;
      this.c = param1a.c;
      this.d = param1a.d;
      this.e = param1a.e;
      this.f = param1a.f;
      this.g = param1a.g;
      this.h = param1a.h;
      this.i = param1a.i;
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\fragment\app\o.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */