package androidx.fragment.app;

import android.animation.LayoutTransition;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.os.Bundle;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.widget.FrameLayout;
import dbxyzptlk.DI.s;
import dbxyzptlk.J2.c;
import dbxyzptlk.h2.J0;
import dbxyzptlk.h2.h0;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

@Metadata(d1 = {"\000x\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\003\n\002\030\002\n\000\n\002\020\b\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\003\n\002\030\002\n\000\n\002\020\t\n\000\n\002\020\013\n\002\b\n\n\002\030\002\n\002\b\016\n\002\030\002\n\002\b\005\n\002\020!\n\002\b\n\030\0002\0020\001:\001CB\021\b\026\022\006\020\003\032\0020\002¢\006\004\b\004\020\005B%\b\027\022\006\020\003\032\0020\002\022\b\020\007\032\004\030\0010\006\022\b\b\002\020\t\032\0020\b¢\006\004\b\004\020\nB!\b\020\022\006\020\003\032\0020\002\022\006\020\007\032\0020\006\022\006\020\f\032\0020\013¢\006\004\b\004\020\rJ\031\020\021\032\0020\0202\b\020\017\032\004\030\0010\016H\026¢\006\004\b\021\020\022J\027\020\025\032\0020\0202\006\020\024\032\0020\023H\026¢\006\004\b\025\020\026J\027\020\031\032\0020\0272\006\020\030\032\0020\027H\027¢\006\004\b\031\020\032J\027\020\033\032\0020\0272\006\020\030\032\0020\027H\027¢\006\004\b\033\020\032J\027\020\036\032\0020\0202\006\020\035\032\0020\034H\024¢\006\004\b\036\020\037J'\020%\032\0020$2\006\020\035\032\0020\0342\006\020!\032\0020 2\006\020#\032\0020\"H\024¢\006\004\b%\020&J\027\020(\032\0020\0202\006\020'\032\0020 H\026¢\006\004\b(\020)J\027\020*\032\0020\0202\006\020'\032\0020 H\026¢\006\004\b*\020)J\027\020,\032\0020\0202\006\020+\032\0020$H\001¢\006\004\b,\020-J)\0201\032\0020\0202\006\020!\032\0020 2\006\020.\032\0020\b2\b\0200\032\004\030\0010/H\026¢\006\004\b1\0202J\027\0203\032\0020\0202\006\020.\032\0020\bH\026¢\006\004\b3\0204J\027\0205\032\0020\0202\006\020'\032\0020 H\026¢\006\004\b5\020)J\027\0206\032\0020\0202\006\020'\032\0020 H\026¢\006\004\b6\020)J\037\0209\032\0020\0202\006\0207\032\0020\b2\006\0208\032\0020\bH\026¢\006\004\b9\020:J\037\020;\032\0020\0202\006\0207\032\0020\b2\006\0208\032\0020\bH\026¢\006\004\b;\020:J\017\020<\032\0020\020H\026¢\006\004\b<\020=J\031\020@\032\0028\000\"\n\b\000\020?*\004\030\0010>¢\006\004\b@\020AJ\027\020C\032\0020\0202\006\020B\032\0020 H\002¢\006\004\bC\020)R\032\020F\032\b\022\004\022\0020 0D8\002X\004¢\006\006\n\004\bC\020ER\032\020H\032\b\022\004\022\0020 0D8\002X\004¢\006\006\n\004\bG\020ER\030\020K\032\004\030\0010\0238\002@\002X\016¢\006\006\n\004\bI\020JR\026\020+\032\0020$8\002@\002X\016¢\006\006\n\004\bL\020M¨\006N"}, d2 = {"Landroidx/fragment/app/FragmentContainerView;", "Landroid/widget/FrameLayout;", "Landroid/content/Context;", "context", "<init>", "(Landroid/content/Context;)V", "Landroid/util/AttributeSet;", "attrs", "", "defStyleAttr", "(Landroid/content/Context;Landroid/util/AttributeSet;I)V", "Landroidx/fragment/app/FragmentManager;", "fm", "(Landroid/content/Context;Landroid/util/AttributeSet;Landroidx/fragment/app/FragmentManager;)V", "Landroid/animation/LayoutTransition;", "transition", "Ldbxyzptlk/pI/D;", "setLayoutTransition", "(Landroid/animation/LayoutTransition;)V", "Landroid/view/View$OnApplyWindowInsetsListener;", "listener", "setOnApplyWindowInsetsListener", "(Landroid/view/View$OnApplyWindowInsetsListener;)V", "Landroid/view/WindowInsets;", "insets", "onApplyWindowInsets", "(Landroid/view/WindowInsets;)Landroid/view/WindowInsets;", "dispatchApplyWindowInsets", "Landroid/graphics/Canvas;", "canvas", "dispatchDraw", "(Landroid/graphics/Canvas;)V", "Landroid/view/View;", "child", "", "drawingTime", "", "drawChild", "(Landroid/graphics/Canvas;Landroid/view/View;J)Z", "view", "startViewTransition", "(Landroid/view/View;)V", "endViewTransition", "drawDisappearingViewsFirst", "setDrawDisappearingViewsLast", "(Z)V", "index", "Landroid/view/ViewGroup$LayoutParams;", "params", "addView", "(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)V", "removeViewAt", "(I)V", "removeViewInLayout", "removeView", "start", "count", "removeViews", "(II)V", "removeViewsInLayout", "removeAllViewsInLayout", "()V", "Landroidx/fragment/app/Fragment;", "F", "getFragment", "()Landroidx/fragment/app/Fragment;", "v", "a", "", "Ljava/util/List;", "disappearingFragmentChildren", "b", "transitioningFragmentViews", "c", "Landroid/view/View$OnApplyWindowInsetsListener;", "applyWindowInsetsListener", "d", "Z", "fragment_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class FragmentContainerView extends FrameLayout {
  public final List<View> a = new ArrayList<>();
  
  public final List<View> b = new ArrayList<>();
  
  public View.OnApplyWindowInsetsListener c;
  
  public boolean d = true;
  
  public FragmentContainerView(Context paramContext) {
    super(paramContext);
  }
  
  public FragmentContainerView(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 0, 4, null);
  }
  
  public FragmentContainerView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    if (paramAttributeSet != null) {
      String str1;
      String str2;
      String str3 = paramAttributeSet.getClassAttribute();
      int[] arrayOfInt = c.FragmentContainerView;
      s.g(arrayOfInt, "FragmentContainerView");
      TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, arrayOfInt, 0, 0);
      if (str3 == null) {
        str2 = typedArray.getString(c.FragmentContainerView_android_name);
        str1 = "android:name";
      } else {
        str1 = "class";
        str2 = str3;
      } 
      typedArray.recycle();
      if (str2 != null && !isInEditMode()) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("FragmentContainerView must be within a FragmentActivity to use ");
        stringBuilder.append(str1);
        stringBuilder.append("=\"");
        stringBuilder.append(str2);
        stringBuilder.append('"');
        throw new UnsupportedOperationException(stringBuilder.toString());
      } 
    } 
  }
  
  public FragmentContainerView(Context paramContext, AttributeSet paramAttributeSet, FragmentManager paramFragmentManager) {
    super(paramContext, paramAttributeSet);
    String str2 = paramAttributeSet.getClassAttribute();
    int[] arrayOfInt = c.FragmentContainerView;
    s.g(arrayOfInt, "FragmentContainerView");
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, arrayOfInt, 0, 0);
    String str1 = str2;
    if (str2 == null)
      str1 = typedArray.getString(c.FragmentContainerView_android_name); 
    str2 = typedArray.getString(c.FragmentContainerView_android_tag);
    typedArray.recycle();
    int i = getId();
    Fragment fragment = paramFragmentManager.l0(i);
    if (str1 != null && fragment == null) {
      String str;
      StringBuilder stringBuilder;
      if (i == -1) {
        if (str2 != null) {
          StringBuilder stringBuilder1 = new StringBuilder();
          stringBuilder1.append(" with tag ");
          stringBuilder1.append(str2);
          str = stringBuilder1.toString();
        } else {
          str = "";
        } 
        stringBuilder = new StringBuilder();
        stringBuilder.append("FragmentContainerView must have an android:id to add Fragment ");
        stringBuilder.append(str1);
        stringBuilder.append(str);
        throw new IllegalStateException(stringBuilder.toString());
      } 
      Fragment fragment1 = paramFragmentManager.A0().a(str.getClassLoader(), str1);
      s.g(fragment1, "fm.fragmentFactory.insta…ontext.classLoader, name)");
      fragment1.mFragmentId = i;
      fragment1.mContainerId = i;
      fragment1.mTag = str2;
      fragment1.mFragmentManager = paramFragmentManager;
      fragment1.mHost = paramFragmentManager.D0();
      fragment1.onInflate((Context)str, (AttributeSet)stringBuilder, (Bundle)null);
      paramFragmentManager.q().B(true).e((ViewGroup)this, fragment1, str2).n();
    } 
    paramFragmentManager.i1(this);
  }
  
  public final void a(View paramView) {
    if (this.b.contains(paramView))
      this.a.add(paramView); 
  }
  
  public void addView(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams) {
    s.h(paramView, "child");
    if (FragmentManager.K0(paramView) != null) {
      super.addView(paramView, paramInt, paramLayoutParams);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Views added to a FragmentContainerView must be associated with a Fragment. View ");
    stringBuilder.append(paramView);
    stringBuilder.append(" is not associated with a Fragment.");
    throw new IllegalStateException(stringBuilder.toString().toString());
  }
  
  public WindowInsets dispatchApplyWindowInsets(WindowInsets paramWindowInsets) {
    J0 j01;
    a a;
    s.h(paramWindowInsets, "insets");
    J0 j02 = J0.z(paramWindowInsets);
    s.g(j02, "toWindowInsetsCompat(insets)");
    View.OnApplyWindowInsetsListener onApplyWindowInsetsListener = this.c;
    if (onApplyWindowInsetsListener != null) {
      a = a.a;
      s.e(onApplyWindowInsetsListener);
      j01 = J0.z(a.a(onApplyWindowInsetsListener, (View)this, paramWindowInsets));
    } else {
      j01 = h0.c0((View)this, (J0)a);
    } 
    s.g(j01, "if (applyWindowInsetsLis…, insetsCompat)\n        }");
    if (!j01.r()) {
      int i = getChildCount();
      for (byte b = 0; b < i; b++)
        h0.h(getChildAt(b), j01); 
    } 
    return paramWindowInsets;
  }
  
  public void dispatchDraw(Canvas paramCanvas) {
    s.h(paramCanvas, "canvas");
    if (this.d) {
      Iterator<View> iterator = this.a.iterator();
      while (iterator.hasNext())
        super.drawChild(paramCanvas, iterator.next(), getDrawingTime()); 
    } 
    super.dispatchDraw(paramCanvas);
  }
  
  public boolean drawChild(Canvas paramCanvas, View paramView, long paramLong) {
    s.h(paramCanvas, "canvas");
    s.h(paramView, "child");
    return (this.d && !this.a.isEmpty() && this.a.contains(paramView)) ? false : super.drawChild(paramCanvas, paramView, paramLong);
  }
  
  public void endViewTransition(View paramView) {
    s.h(paramView, "view");
    this.b.remove(paramView);
    if (this.a.remove(paramView))
      this.d = true; 
    super.endViewTransition(paramView);
  }
  
  public final <F extends Fragment> F getFragment() {
    return (F)FragmentManager.o0((View)this).l0(getId());
  }
  
  public WindowInsets onApplyWindowInsets(WindowInsets paramWindowInsets) {
    s.h(paramWindowInsets, "insets");
    return paramWindowInsets;
  }
  
  public void removeAllViewsInLayout() {
    for (int i = getChildCount() - 1; -1 < i; i--) {
      View view = getChildAt(i);
      s.g(view, "view");
      a(view);
    } 
    super.removeAllViewsInLayout();
  }
  
  public void removeView(View paramView) {
    s.h(paramView, "view");
    a(paramView);
    super.removeView(paramView);
  }
  
  public void removeViewAt(int paramInt) {
    View view = getChildAt(paramInt);
    s.g(view, "view");
    a(view);
    super.removeViewAt(paramInt);
  }
  
  public void removeViewInLayout(View paramView) {
    s.h(paramView, "view");
    a(paramView);
    super.removeViewInLayout(paramView);
  }
  
  public void removeViews(int paramInt1, int paramInt2) {
    for (int i = paramInt1; i < paramInt1 + paramInt2; i++) {
      View view = getChildAt(i);
      s.g(view, "view");
      a(view);
    } 
    super.removeViews(paramInt1, paramInt2);
  }
  
  public void removeViewsInLayout(int paramInt1, int paramInt2) {
    for (int i = paramInt1; i < paramInt1 + paramInt2; i++) {
      View view = getChildAt(i);
      s.g(view, "view");
      a(view);
    } 
    super.removeViewsInLayout(paramInt1, paramInt2);
  }
  
  public final void setDrawDisappearingViewsLast(boolean paramBoolean) {
    this.d = paramBoolean;
  }
  
  public void setLayoutTransition(LayoutTransition paramLayoutTransition) {
    throw new UnsupportedOperationException("FragmentContainerView does not support Layout Transitions or animateLayoutChanges=\"true\".");
  }
  
  public void setOnApplyWindowInsetsListener(View.OnApplyWindowInsetsListener paramOnApplyWindowInsetsListener) {
    s.h(paramOnApplyWindowInsetsListener, "listener");
    this.c = paramOnApplyWindowInsetsListener;
  }
  
  public void startViewTransition(View paramView) {
    s.h(paramView, "view");
    if (paramView.getParent() == this)
      this.b.add(paramView); 
    super.startViewTransition(paramView);
  }
  
  class FragmentContainerView {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\fragment\app\FragmentContainerView.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */