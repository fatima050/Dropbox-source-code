package androidx.fragment.app;

import android.util.Log;
import androidx.lifecycle.f;
import dbxyzptlk.K2.F;
import java.io.PrintWriter;
import java.io.Writer;
import java.util.ArrayList;

public final class a extends o implements FragmentManager.j, FragmentManager.o {
  public final FragmentManager t;
  
  public boolean u;
  
  public int v;
  
  public boolean w;
  
  public a(FragmentManager paramFragmentManager) {
    super(f, classLoader);
    ClassLoader classLoader;
    this.v = -1;
    this.w = false;
    this.t = paramFragmentManager;
  }
  
  public a(a parama) {
    super(f, classLoader, parama);
    ClassLoader classLoader;
    this.v = -1;
    this.w = false;
    this.t = parama.t;
    this.u = parama.u;
    this.v = parama.v;
    this.w = parama.w;
  }
  
  public o A(Fragment paramFragment) {
    if (paramFragment != null) {
      FragmentManager fragmentManager = paramFragment.mFragmentManager;
      if (fragmentManager != null && fragmentManager != this.t) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Cannot setPrimaryNavigation for Fragment attached to a different FragmentManager. Fragment ");
        stringBuilder.append(paramFragment.toString());
        stringBuilder.append(" is already attached to a FragmentManager.");
        throw new IllegalStateException(stringBuilder.toString());
      } 
    } 
    return super.A(paramFragment);
  }
  
  public void D(int paramInt) {
    if (!this.i)
      return; 
    if (FragmentManager.Q0(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Bump nesting in ");
      stringBuilder.append(this);
      stringBuilder.append(" by ");
      stringBuilder.append(paramInt);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    int i = this.c.size();
    for (byte b = 0; b < i; b++) {
      o.a a1 = this.c.get(b);
      Fragment fragment = a1.b;
      if (fragment != null) {
        fragment.mBackStackNesting += paramInt;
        if (FragmentManager.Q0(2)) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Bump nesting of ");
          stringBuilder.append(a1.b);
          stringBuilder.append(" to ");
          stringBuilder.append(a1.b.mBackStackNesting);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
      } 
    } 
  }
  
  public void E() {
    for (int i = this.c.size() - 1; i >= 0; i = k - 1) {
      int k;
      o.a a1 = this.c.get(i);
      if (!a1.c) {
        k = i;
      } else if (a1.a == 8) {
        a1.c = false;
        this.c.remove(i - 1);
        k = i - 1;
      } else {
        int n = a1.b.mContainerId;
        a1.a = 2;
        a1.c = false;
        int m = i - 1;
        while (true) {
          k = i;
          if (m >= 0) {
            a1 = this.c.get(m);
            k = i;
            if (a1.c) {
              k = i;
              if (a1.b.mContainerId == n) {
                this.c.remove(m);
                k = i - 1;
              } 
            } 
            m--;
            i = k;
            continue;
          } 
          break;
        } 
      } 
    } 
  }
  
  public int F(boolean paramBoolean) {
    if (!this.u) {
      if (FragmentManager.Q0(2)) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Commit: ");
        stringBuilder.append(this);
        Log.v("FragmentManager", stringBuilder.toString());
        PrintWriter printWriter = new PrintWriter((Writer)new F("FragmentManager"));
        G("  ", printWriter);
        printWriter.close();
      } 
      this.u = true;
      if (this.i) {
        this.v = this.t.n();
      } else {
        this.v = -1;
      } 
      this.t.b0(this, paramBoolean);
      return this.v;
    } 
    throw new IllegalStateException("commit already called");
  }
  
  public void G(String paramString, PrintWriter paramPrintWriter) {
    H(paramString, paramPrintWriter, true);
  }
  
  public void H(String paramString, PrintWriter paramPrintWriter, boolean paramBoolean) {
    if (paramBoolean) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mName=");
      paramPrintWriter.print(this.k);
      paramPrintWriter.print(" mIndex=");
      paramPrintWriter.print(this.v);
      paramPrintWriter.print(" mCommitted=");
      paramPrintWriter.println(this.u);
      if (this.h != 0) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mTransition=#");
        paramPrintWriter.print(Integer.toHexString(this.h));
      } 
      if (this.d != 0 || this.e != 0) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mEnterAnim=#");
        paramPrintWriter.print(Integer.toHexString(this.d));
        paramPrintWriter.print(" mExitAnim=#");
        paramPrintWriter.println(Integer.toHexString(this.e));
      } 
      if (this.f != 0 || this.g != 0) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mPopEnterAnim=#");
        paramPrintWriter.print(Integer.toHexString(this.f));
        paramPrintWriter.print(" mPopExitAnim=#");
        paramPrintWriter.println(Integer.toHexString(this.g));
      } 
      if (this.l != 0 || this.m != null) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mBreadCrumbTitleRes=#");
        paramPrintWriter.print(Integer.toHexString(this.l));
        paramPrintWriter.print(" mBreadCrumbTitleText=");
        paramPrintWriter.println(this.m);
      } 
      if (this.n != 0 || this.o != null) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mBreadCrumbShortTitleRes=#");
        paramPrintWriter.print(Integer.toHexString(this.n));
        paramPrintWriter.print(" mBreadCrumbShortTitleText=");
        paramPrintWriter.println(this.o);
      } 
    } 
    if (!this.c.isEmpty()) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.println("Operations:");
      int i = this.c.size();
      for (byte b = 0; b < i; b++) {
        StringBuilder stringBuilder;
        String str;
        o.a a1 = this.c.get(b);
        switch (a1.a) {
          default:
            stringBuilder = new StringBuilder();
            stringBuilder.append("cmd=");
            stringBuilder.append(a1.a);
            str = stringBuilder.toString();
            break;
          case 10:
            str = "OP_SET_MAX_LIFECYCLE";
            break;
          case 9:
            str = "UNSET_PRIMARY_NAV";
            break;
          case 8:
            str = "SET_PRIMARY_NAV";
            break;
          case 7:
            str = "ATTACH";
            break;
          case 6:
            str = "DETACH";
            break;
          case 5:
            str = "SHOW";
            break;
          case 4:
            str = "HIDE";
            break;
          case 3:
            str = "REMOVE";
            break;
          case 2:
            str = "REPLACE";
            break;
          case 1:
            str = "ADD";
            break;
          case 0:
            str = "NULL";
            break;
        } 
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("  Op #");
        paramPrintWriter.print(b);
        paramPrintWriter.print(": ");
        paramPrintWriter.print(str);
        paramPrintWriter.print(" ");
        paramPrintWriter.println(a1.b);
        if (paramBoolean) {
          if (a1.d != 0 || a1.e != 0) {
            paramPrintWriter.print(paramString);
            paramPrintWriter.print("enterAnim=#");
            paramPrintWriter.print(Integer.toHexString(a1.d));
            paramPrintWriter.print(" exitAnim=#");
            paramPrintWriter.println(Integer.toHexString(a1.e));
          } 
          if (a1.f != 0 || a1.g != 0) {
            paramPrintWriter.print(paramString);
            paramPrintWriter.print("popEnterAnim=#");
            paramPrintWriter.print(Integer.toHexString(a1.f));
            paramPrintWriter.print(" popExitAnim=#");
            paramPrintWriter.println(Integer.toHexString(a1.g));
          } 
        } 
      } 
    } 
  }
  
  public void I() {
    int i = this.c.size();
    for (byte b = 0; b < i; b++) {
      StringBuilder stringBuilder;
      o.a a1 = this.c.get(b);
      Fragment fragment = a1.b;
      if (fragment != null) {
        fragment.mBeingSaved = this.w;
        fragment.setPopDirection(false);
        fragment.setNextTransition(this.h);
        fragment.setSharedElementNames(this.p, this.q);
      } 
      switch (a1.a) {
        default:
          stringBuilder = new StringBuilder();
          stringBuilder.append("Unknown cmd: ");
          stringBuilder.append(a1.a);
          throw new IllegalArgumentException(stringBuilder.toString());
        case 10:
          this.t.L1((Fragment)stringBuilder, a1.i);
          break;
        case 9:
          this.t.M1(null);
          break;
        case 8:
          this.t.M1((Fragment)stringBuilder);
          break;
        case 7:
          stringBuilder.setAnimations(a1.d, a1.e, a1.f, a1.g);
          this.t.I1((Fragment)stringBuilder, false);
          this.t.p((Fragment)stringBuilder);
          break;
        case 6:
          stringBuilder.setAnimations(a1.d, a1.e, a1.f, a1.g);
          this.t.z((Fragment)stringBuilder);
          break;
        case 5:
          stringBuilder.setAnimations(a1.d, a1.e, a1.f, a1.g);
          this.t.I1((Fragment)stringBuilder, false);
          this.t.O1((Fragment)stringBuilder);
          break;
        case 4:
          stringBuilder.setAnimations(a1.d, a1.e, a1.f, a1.g);
          this.t.N0((Fragment)stringBuilder);
          break;
        case 3:
          stringBuilder.setAnimations(a1.d, a1.e, a1.f, a1.g);
          this.t.v1((Fragment)stringBuilder);
          break;
        case 1:
          stringBuilder.setAnimations(a1.d, a1.e, a1.f, a1.g);
          this.t.I1((Fragment)stringBuilder, false);
          this.t.j((Fragment)stringBuilder);
          break;
      } 
    } 
  }
  
  public void J() {
    for (int i = this.c.size() - 1; i >= 0; i--) {
      StringBuilder stringBuilder;
      o.a a1 = this.c.get(i);
      Fragment fragment = a1.b;
      if (fragment != null) {
        fragment.mBeingSaved = this.w;
        fragment.setPopDirection(true);
        fragment.setNextTransition(FragmentManager.C1(this.h));
        fragment.setSharedElementNames(this.q, this.p);
      } 
      switch (a1.a) {
        default:
          stringBuilder = new StringBuilder();
          stringBuilder.append("Unknown cmd: ");
          stringBuilder.append(a1.a);
          throw new IllegalArgumentException(stringBuilder.toString());
        case 10:
          this.t.L1((Fragment)stringBuilder, a1.h);
          break;
        case 9:
          this.t.M1((Fragment)stringBuilder);
          break;
        case 8:
          this.t.M1(null);
          break;
        case 7:
          stringBuilder.setAnimations(a1.d, a1.e, a1.f, a1.g);
          this.t.I1((Fragment)stringBuilder, true);
          this.t.z((Fragment)stringBuilder);
          break;
        case 6:
          stringBuilder.setAnimations(a1.d, a1.e, a1.f, a1.g);
          this.t.p((Fragment)stringBuilder);
          break;
        case 5:
          stringBuilder.setAnimations(a1.d, a1.e, a1.f, a1.g);
          this.t.I1((Fragment)stringBuilder, true);
          this.t.N0((Fragment)stringBuilder);
          break;
        case 4:
          stringBuilder.setAnimations(a1.d, a1.e, a1.f, a1.g);
          this.t.O1((Fragment)stringBuilder);
          break;
        case 3:
          stringBuilder.setAnimations(a1.d, a1.e, a1.f, a1.g);
          this.t.j((Fragment)stringBuilder);
          break;
        case 1:
          stringBuilder.setAnimations(a1.d, a1.e, a1.f, a1.g);
          this.t.I1((Fragment)stringBuilder, true);
          this.t.v1((Fragment)stringBuilder);
          break;
      } 
    } 
  }
  
  public Fragment K(ArrayList<Fragment> paramArrayList, Fragment paramFragment) {
    int i = 0;
    Fragment fragment;
    for (fragment = paramFragment; i < this.c.size(); fragment = paramFragment) {
      o.a a1 = this.c.get(i);
      int k = a1.a;
      if (k != 1)
        if (k != 2) {
          if (k != 3 && k != 6) {
            if (k != 7) {
              if (k != 8) {
                paramFragment = fragment;
                k = i;
              } else {
                this.c.add(i, new o.a(9, fragment, true));
                a1.c = true;
                k = i + 1;
                paramFragment = a1.b;
              } 
              continue;
            } 
          } else {
            paramArrayList.remove(a1.b);
            Fragment fragment1 = a1.b;
            paramFragment = fragment;
            k = i;
            if (fragment1 == fragment) {
              this.c.add(i, new o.a(9, fragment1));
              k = i + 1;
              paramFragment = null;
            } 
            continue;
          } 
        } else {
          Fragment fragment1 = a1.b;
          int n = fragment1.mContainerId;
          int m = paramArrayList.size() - 1;
          boolean bool = false;
          k = i;
          paramFragment = fragment;
          while (m >= 0) {
            Fragment fragment2 = paramArrayList.get(m);
            fragment = paramFragment;
            i = k;
            boolean bool1 = bool;
            if (fragment2.mContainerId == n)
              if (fragment2 == fragment1) {
                bool1 = true;
                fragment = paramFragment;
                i = k;
              } else {
                fragment = paramFragment;
                i = k;
                if (fragment2 == paramFragment) {
                  this.c.add(k, new o.a(9, fragment2, true));
                  i = k + 1;
                  fragment = null;
                } 
                o.a a2 = new o.a(3, fragment2, true);
                a2.d = a1.d;
                a2.f = a1.f;
                a2.e = a1.e;
                a2.g = a1.g;
                this.c.add(i, a2);
                paramArrayList.remove(fragment2);
                i++;
                bool1 = bool;
              }  
            m--;
            paramFragment = fragment;
            k = i;
            bool = bool1;
          } 
          if (bool) {
            this.c.remove(k);
            k--;
          } else {
            a1.a = 1;
            a1.c = true;
            paramArrayList.add(fragment1);
          } 
          continue;
        }  
      paramArrayList.add(a1.b);
      k = i;
      paramFragment = fragment;
      continue;
      i = SYNTHETIC_LOCAL_VARIABLE_3 + 1;
    } 
    return fragment;
  }
  
  public void L() {
    if (this.s != null) {
      for (byte b = 0; b < this.s.size(); b++)
        ((Runnable)this.s.get(b)).run(); 
      this.s = null;
    } 
  }
  
  public Fragment M(ArrayList<Fragment> paramArrayList, Fragment paramFragment) {
    int i = this.c.size() - 1;
    while (i >= 0) {
      o.a a1 = this.c.get(i);
      int k = a1.a;
      if (k != 1)
        if (k != 3) {
          switch (k) {
            case 10:
              a1.i = a1.h;
              break;
            case 9:
              paramFragment = a1.b;
              break;
            case 8:
              paramFragment = null;
              break;
            case 6:
              paramArrayList.add(a1.b);
              break;
            case 7:
              paramArrayList.remove(a1.b);
              break;
          } 
          i--;
        }  
    } 
    return paramFragment;
  }
  
  public boolean a(ArrayList<a> paramArrayList, ArrayList<Boolean> paramArrayList1) {
    if (FragmentManager.Q0(2)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Run: ");
      stringBuilder.append(this);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    paramArrayList.add(this);
    paramArrayList1.add(Boolean.FALSE);
    if (this.i)
      this.t.i(this); 
    return true;
  }
  
  public int getId() {
    return this.v;
  }
  
  public String getName() {
    return this.k;
  }
  
  public int k() {
    return F(false);
  }
  
  public int l() {
    return F(true);
  }
  
  public void m() {
    q();
    this.t.e0(this, false);
  }
  
  public void n() {
    q();
    this.t.e0(this, true);
  }
  
  public o p(Fragment paramFragment) {
    FragmentManager fragmentManager = paramFragment.mFragmentManager;
    if (fragmentManager == null || fragmentManager == this.t)
      return super.p(paramFragment); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Cannot detach Fragment attached to a different FragmentManager. Fragment ");
    stringBuilder.append(paramFragment.toString());
    stringBuilder.append(" is already attached to a FragmentManager.");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public void r(int paramInt1, Fragment paramFragment, String paramString, int paramInt2) {
    super.r(paramInt1, paramFragment, paramString, paramInt2);
    paramFragment.mFragmentManager = this.t;
  }
  
  public boolean s() {
    return this.c.isEmpty();
  }
  
  public o t(Fragment paramFragment) {
    FragmentManager fragmentManager = paramFragment.mFragmentManager;
    if (fragmentManager == null || fragmentManager == this.t)
      return super.t(paramFragment); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Cannot remove Fragment attached to a different FragmentManager. Fragment ");
    stringBuilder.append(paramFragment.toString());
    stringBuilder.append(" is already attached to a FragmentManager.");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder(128);
    stringBuilder.append("BackStackEntry{");
    stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
    if (this.v >= 0) {
      stringBuilder.append(" #");
      stringBuilder.append(this.v);
    } 
    if (this.k != null) {
      stringBuilder.append(" ");
      stringBuilder.append(this.k);
    } 
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
  
  public o z(Fragment paramFragment, f.b paramb) {
    if (paramFragment.mFragmentManager == this.t) {
      if (paramb != f.b.INITIALIZED || paramFragment.mState <= -1) {
        if (paramb != f.b.DESTROYED)
          return super.z(paramFragment, paramb); 
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append("Cannot set maximum Lifecycle to ");
        stringBuilder2.append(paramb);
        stringBuilder2.append(". Use remove() to remove the fragment from the FragmentManager and trigger its destruction.");
        throw new IllegalArgumentException(stringBuilder2.toString());
      } 
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("Cannot set maximum Lifecycle to ");
      stringBuilder1.append(paramb);
      stringBuilder1.append(" after the Fragment has been created");
      throw new IllegalArgumentException(stringBuilder1.toString());
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Cannot setMaxLifecycle for Fragment not attached to FragmentManager ");
    stringBuilder.append(this.t);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\fragment\app\a.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */