package androidx.activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.Window;
import androidx.activity.result.IntentSenderRequest;
import androidx.core.app.ComponentActivity;
import androidx.lifecycle.LifecycleEventObserver;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.e;
import androidx.lifecycle.j;
import androidx.lifecycle.n;
import androidx.lifecycle.p;
import androidx.lifecycle.q;
import androidx.lifecycle.t;
import androidx.savedstate.a;
import dbxyzptlk.CI.a;
import dbxyzptlk.DI.s;
import dbxyzptlk.DI.u;
import dbxyzptlk.J4.d;
import dbxyzptlk.R4.a;
import dbxyzptlk.T1.k;
import dbxyzptlk.T1.s;
import dbxyzptlk.T1.t;
import dbxyzptlk.T1.v;
import dbxyzptlk.U2.A;
import dbxyzptlk.U2.B;
import dbxyzptlk.U2.y;
import dbxyzptlk.U2.z;
import dbxyzptlk.V1.e;
import dbxyzptlk.V1.f;
import dbxyzptlk.X2.a;
import dbxyzptlk.e.C;
import dbxyzptlk.e.D;
import dbxyzptlk.e.H;
import dbxyzptlk.e.K;
import dbxyzptlk.e.L;
import dbxyzptlk.e.j;
import dbxyzptlk.e.k;
import dbxyzptlk.e.l;
import dbxyzptlk.e.m;
import dbxyzptlk.e.n;
import dbxyzptlk.g.a;
import dbxyzptlk.g2.a;
import dbxyzptlk.h.a;
import dbxyzptlk.h.e;
import dbxyzptlk.h2.B;
import dbxyzptlk.h2.E;
import dbxyzptlk.h2.G;
import dbxyzptlk.i.a;
import dbxyzptlk.pI.j;
import dbxyzptlk.pI.k;
import java.io.Serializable;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicInteger;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

@Metadata(d1 = {"\000è\002\n\002\030\002\n\002\030\002\n\002\020\000\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\b\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\n\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\005\n\002\030\002\n\000\n\002\020\013\n\002\b\004\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\006\n\002\030\002\n\002\b\013\n\002\020\021\n\002\020\016\n\000\n\002\020\025\n\002\b\005\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\017\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\006\n\002\030\002\n\002\b\n\n\002\030\002\n\002\b\013\n\002\030\002\n\002\b\006\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\n\b\026\030\000 Ü\0012\0020\0012\0020\0022\0020\0032\0020\0042\0020\0052\0020\0062\0020\0072\0020\b2\0020\0022\0020\t2\0020\n2\0020\0022\0020\0132\0020\f2\0020\0022\0020\r2\0020\016:\nÝ\001Þ\001ß\001à\001á\001B\007¢\006\004\b\017\020\020B\023\b\027\022\b\b\001\020\022\032\0020\021¢\006\004\b\017\020\023J\017\020\025\032\0020\024H\002¢\006\004\b\025\020\020J\027\020\030\032\0020\0242\006\020\027\032\0020\026H\003¢\006\004\b\030\020\031J\017\020\033\032\0020\032H\002¢\006\004\b\033\020\034J\031\020\037\032\0020\0242\b\020\036\032\004\030\0010\035H\024¢\006\004\b\037\020 J\027\020\"\032\0020\0242\006\020!\032\0020\035H\025¢\006\004\b\"\020 J\017\020#\032\004\030\0010\002¢\006\004\b#\020$J\021\020%\032\004\030\0010\002H\027¢\006\004\b%\020$J\031\020'\032\0020\0242\b\b\001\020&\032\0020\021H\026¢\006\004\b'\020\023J\031\020'\032\0020\0242\b\020)\032\004\030\0010(H\026¢\006\004\b'\020*J#\020'\032\0020\0242\b\020)\032\004\030\0010(2\b\020,\032\004\030\0010+H\026¢\006\004\b'\020-J#\020.\032\0020\0242\b\020)\032\004\030\0010(2\b\020,\032\004\030\0010+H\026¢\006\004\b.\020-J\017\020/\032\0020\024H\027¢\006\004\b/\020\020J\021\0201\032\004\030\00100H\026¢\006\004\b1\0202J\025\0205\032\0020\0242\006\0204\032\00203¢\006\004\b5\0206J\025\0207\032\0020\0242\006\0204\032\00203¢\006\004\b7\0206J)\020<\032\0020;2\006\0208\032\0020\0212\b\020)\032\004\030\0010(2\006\020:\032\00209H\026¢\006\004\b<\020=J\037\020>\032\0020;2\006\0208\032\0020\0212\006\020:\032\00209H\026¢\006\004\b>\020?J\037\020B\032\0020;2\006\0208\032\0020\0212\006\020A\032\0020@H\026¢\006\004\bB\020CJ\037\020D\032\0020\0242\006\0208\032\0020\0212\006\020:\032\00209H\026¢\006\004\bD\020EJ\027\020H\032\0020\0242\006\020G\032\0020FH\026¢\006\004\bH\020IJ\037\020H\032\0020\0242\006\020G\032\0020F2\006\020J\032\0020\003H\026¢\006\004\bH\020KJ'\020H\032\0020\0242\006\020G\032\0020F2\006\020J\032\0020\0032\006\020M\032\0020LH\027¢\006\004\bH\020NJ\027\020O\032\0020\0242\006\020G\032\0020FH\026¢\006\004\bO\020IJ\017\020P\032\0020\024H\026¢\006\004\bP\020\020J\017\020Q\032\0020\024H\027¢\006\004\bQ\020\020J\037\020U\032\0020\0242\006\020S\032\0020R2\006\020T\032\0020\021H\027¢\006\004\bU\020VJ)\020U\032\0020\0242\006\020S\032\0020R2\006\020T\032\0020\0212\b\020W\032\004\030\0010\035H\027¢\006\004\bU\020XJA\020^\032\0020\0242\006\020S\032\0020Y2\006\020T\032\0020\0212\b\020Z\032\004\030\0010R2\006\020[\032\0020\0212\006\020\\\032\0020\0212\006\020]\032\0020\021H\027¢\006\004\b^\020_JK\020^\032\0020\0242\006\020S\032\0020Y2\006\020T\032\0020\0212\b\020Z\032\004\030\0010R2\006\020[\032\0020\0212\006\020\\\032\0020\0212\006\020]\032\0020\0212\b\020W\032\004\030\0010\035H\027¢\006\004\b^\020`J)\020c\032\0020\0242\006\020T\032\0020\0212\006\020a\032\0020\0212\b\020b\032\004\030\0010RH\025¢\006\004\bc\020dJ-\020j\032\0020\0242\006\020T\032\0020\0212\f\020g\032\b\022\004\022\0020f0e2\006\020i\032\0020hH\027¢\006\004\bj\020kJI\020u\032\b\022\004\022\0028\0000t\"\004\b\000\020l\"\004\b\001\020m2\022\020o\032\016\022\004\022\0028\000\022\004\022\0028\0010n2\006\020q\032\0020p2\f\020s\032\b\022\004\022\0028\0010r¢\006\004\bu\020vJA\020u\032\b\022\004\022\0028\0000t\"\004\b\000\020l\"\004\b\001\020m2\022\020o\032\016\022\004\022\0028\000\022\004\022\0028\0010n2\f\020s\032\b\022\004\022\0028\0010r¢\006\004\bu\020wJ\027\020z\032\0020\0242\006\020y\032\0020xH\027¢\006\004\bz\020{J\033\020}\032\0020\0242\f\0204\032\b\022\004\022\0020x0|¢\006\004\b}\020~J\033\020\032\0020\0242\f\0204\032\b\022\004\022\0020x0|¢\006\004\b\020~J\032\020\001\032\0020\0242\007\020\001\032\0020\021H\027¢\006\005\b\001\020\023J\035\020\001\032\0020\0242\f\0204\032\b\022\004\022\0020\0210|¢\006\005\b\001\020~J\035\020\001\032\0020\0242\f\0204\032\b\022\004\022\0020\0210|¢\006\005\b\001\020~J\032\020\001\032\0020\0242\006\020S\032\0020RH\025¢\006\006\b\001\020\001J\035\020\001\032\0020\0242\f\0204\032\b\022\004\022\0020R0|¢\006\005\b\001\020~J\035\020\001\032\0020\0242\f\0204\032\b\022\004\022\0020R0|¢\006\005\b\001\020~J\033\020\001\032\0020\0242\007\020\001\032\0020;H\027¢\006\006\b\001\020\001J#\020\001\032\0020\0242\007\020\001\032\0020;2\006\020y\032\0020xH\027¢\006\006\b\001\020\001J\036\020\001\032\0020\0242\r\0204\032\t\022\005\022\0030\0010|¢\006\005\b\001\020~J\036\020\001\032\0020\0242\r\0204\032\t\022\005\022\0030\0010|¢\006\005\b\001\020~J\033\020\001\032\0020\0242\007\020\001\032\0020;H\027¢\006\006\b\001\020\001J#\020\001\032\0020\0242\007\020\001\032\0020;2\006\020y\032\0020xH\027¢\006\006\b\001\020\001J\036\020\001\032\0020\0242\r\0204\032\t\022\005\022\0030\0010|¢\006\005\b\001\020~J\036\020\001\032\0020\0242\r\0204\032\t\022\005\022\0030\0010|¢\006\005\b\001\020~J\021\020\001\032\0020\024H\025¢\006\005\b\001\020\020J\031\020\001\032\0020\0242\007\0204\032\0030\001¢\006\006\b\001\020\001J\031\020\001\032\0020\0242\007\0204\032\0030\001¢\006\006\b\001\020\001J\021\020\001\032\0020\024H\026¢\006\005\b\001\020\020R\030\020\001\032\0030\0018\002X\004¢\006\b\n\006\b\001\020\001R\030\020\001\032\0030\0018\002X\004¢\006\b\n\006\b\001\020\001R\037\020¡\001\032\0030 \0018\002X\004¢\006\017\n\006\b¡\001\020¢\001\022\005\b£\001\020\020R\034\020¥\001\032\005\030\0010¤\0018\002@\002X\016¢\006\b\n\006\b¥\001\020¦\001R\027\020§\001\032\0020\0328\002X\004¢\006\b\n\006\b§\001\020¨\001R!\020®\001\032\0030©\0018VX\002¢\006\020\n\006\bª\001\020«\001\032\006\b¬\001\020­\001R\026\020\022\032\0020\0218\002@\002X\016¢\006\006\n\004\b\022\020lR\030\020°\001\032\0030¯\0018\002X\004¢\006\b\n\006\b°\001\020±\001R\034\020²\001\032\0020p8\006¢\006\020\n\006\b²\001\020³\001\032\006\b´\001\020µ\001R$\020·\001\032\017\022\n\022\b\022\004\022\0020x0|0¶\0018\002X\004¢\006\b\n\006\b·\001\020¸\001R$\020¹\001\032\017\022\n\022\b\022\004\022\0020\0210|0¶\0018\002X\004¢\006\b\n\006\b¹\001\020¸\001R$\020º\001\032\017\022\n\022\b\022\004\022\0020R0|0¶\0018\002X\004¢\006\b\n\006\bº\001\020¸\001R%\020»\001\032\020\022\013\022\t\022\005\022\0030\0010|0¶\0018\002X\004¢\006\b\n\006\b»\001\020¸\001R%\020¼\001\032\020\022\013\022\t\022\005\022\0030\0010|0¶\0018\002X\004¢\006\b\n\006\b¼\001\020¸\001R\037\020½\001\032\n\022\005\022\0030\0010¶\0018\002X\004¢\006\b\n\006\b½\001\020¸\001R\031\020¾\001\032\0020;8\002@\002X\016¢\006\b\n\006\b¾\001\020¿\001R\031\020À\001\032\0020;8\002@\002X\016¢\006\b\n\006\bÀ\001\020¿\001R!\020Å\001\032\0030Á\0018VX\002¢\006\020\n\006\bÂ\001\020«\001\032\006\bÃ\001\020Ä\001R'\020Ê\001\032\0020\0268FX\002¢\006\027\n\006\bÆ\001\020«\001\022\005\bÉ\001\020\020\032\006\bÇ\001\020È\001R\030\020Ì\001\032\004\030\0010\0028WX\004¢\006\007\032\005\bË\001\020$R\030\020Ð\001\032\0030Í\0018VX\004¢\006\b\032\006\bÎ\001\020Ï\001R\030\020Ó\001\032\0030¤\0018VX\004¢\006\b\032\006\bÑ\001\020Ò\001R\030\020×\001\032\0030Ô\0018WX\004¢\006\b\032\006\bÕ\001\020Ö\001R\025\020Û\001\032\0030Ø\0018F¢\006\b\032\006\bÙ\001\020Ú\001¨\006â\001"}, d2 = {"Landroidx/activity/ComponentActivity;", "Landroidx/core/app/ComponentActivity;", "", "Landroidx/lifecycle/LifecycleOwner;", "Ldbxyzptlk/U2/z;", "Landroidx/lifecycle/e;", "Ldbxyzptlk/J4/d;", "Ldbxyzptlk/e/H;", "Ldbxyzptlk/h/e;", "Ldbxyzptlk/V1/e;", "Ldbxyzptlk/V1/f;", "Ldbxyzptlk/T1/s;", "Ldbxyzptlk/T1/t;", "Ldbxyzptlk/h2/B;", "Ldbxyzptlk/e/D;", "<init>", "()V", "", "contentLayoutId", "(I)V", "Ldbxyzptlk/pI/D;", "ensureViewModelStore", "Landroidx/activity/OnBackPressedDispatcher;", "dispatcher", "addObserverForBackInvoker", "(Landroidx/activity/OnBackPressedDispatcher;)V", "Landroidx/activity/ComponentActivity$d;", "createFullyDrawnExecutor", "()Landroidx/activity/ComponentActivity$d;", "Landroid/os/Bundle;", "savedInstanceState", "onCreate", "(Landroid/os/Bundle;)V", "outState", "onSaveInstanceState", "onRetainNonConfigurationInstance", "()Ljava/lang/Object;", "onRetainCustomNonConfigurationInstance", "layoutResID", "setContentView", "Landroid/view/View;", "view", "(Landroid/view/View;)V", "Landroid/view/ViewGroup$LayoutParams;", "params", "(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V", "addContentView", "initializeViewTreeOwners", "Landroid/content/Context;", "peekAvailableContext", "()Landroid/content/Context;", "Ldbxyzptlk/g/b;", "listener", "addOnContextAvailableListener", "(Ldbxyzptlk/g/b;)V", "removeOnContextAvailableListener", "featureId", "Landroid/view/Menu;", "menu", "", "onPreparePanel", "(ILandroid/view/View;Landroid/view/Menu;)Z", "onCreatePanelMenu", "(ILandroid/view/Menu;)Z", "Landroid/view/MenuItem;", "item", "onMenuItemSelected", "(ILandroid/view/MenuItem;)Z", "onPanelClosed", "(ILandroid/view/Menu;)V", "Ldbxyzptlk/h2/G;", "provider", "addMenuProvider", "(Ldbxyzptlk/h2/G;)V", "owner", "(Ldbxyzptlk/h2/G;Landroidx/lifecycle/LifecycleOwner;)V", "Landroidx/lifecycle/f$b;", "state", "(Ldbxyzptlk/h2/G;Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/f$b;)V", "removeMenuProvider", "invalidateMenu", "onBackPressed", "Landroid/content/Intent;", "intent", "requestCode", "startActivityForResult", "(Landroid/content/Intent;I)V", "options", "(Landroid/content/Intent;ILandroid/os/Bundle;)V", "Landroid/content/IntentSender;", "fillInIntent", "flagsMask", "flagsValues", "extraFlags", "startIntentSenderForResult", "(Landroid/content/IntentSender;ILandroid/content/Intent;III)V", "(Landroid/content/IntentSender;ILandroid/content/Intent;IIILandroid/os/Bundle;)V", "resultCode", "data", "onActivityResult", "(IILandroid/content/Intent;)V", "", "", "permissions", "", "grantResults", "onRequestPermissionsResult", "(I[Ljava/lang/String;[I)V", "I", "O", "Ldbxyzptlk/i/a;", "contract", "Ldbxyzptlk/h/d;", "registry", "Ldbxyzptlk/h/a;", "callback", "Ldbxyzptlk/h/b;", "registerForActivityResult", "(Ldbxyzptlk/i/a;Ldbxyzptlk/h/d;Ldbxyzptlk/h/a;)Ldbxyzptlk/h/b;", "(Ldbxyzptlk/i/a;Ldbxyzptlk/h/a;)Ldbxyzptlk/h/b;", "Landroid/content/res/Configuration;", "newConfig", "onConfigurationChanged", "(Landroid/content/res/Configuration;)V", "Ldbxyzptlk/g2/a;", "addOnConfigurationChangedListener", "(Ldbxyzptlk/g2/a;)V", "removeOnConfigurationChangedListener", "level", "onTrimMemory", "addOnTrimMemoryListener", "removeOnTrimMemoryListener", "onNewIntent", "(Landroid/content/Intent;)V", "addOnNewIntentListener", "removeOnNewIntentListener", "isInMultiWindowMode", "onMultiWindowModeChanged", "(Z)V", "(ZLandroid/content/res/Configuration;)V", "Ldbxyzptlk/T1/k;", "addOnMultiWindowModeChangedListener", "removeOnMultiWindowModeChangedListener", "isInPictureInPictureMode", "onPictureInPictureModeChanged", "Ldbxyzptlk/T1/v;", "addOnPictureInPictureModeChangedListener", "removeOnPictureInPictureModeChangedListener", "onUserLeaveHint", "Ljava/lang/Runnable;", "addOnUserLeaveHintListener", "(Ljava/lang/Runnable;)V", "removeOnUserLeaveHintListener", "reportFullyDrawn", "Ldbxyzptlk/g/a;", "contextAwareHelper", "Ldbxyzptlk/g/a;", "Ldbxyzptlk/h2/E;", "menuHostHelper", "Ldbxyzptlk/h2/E;", "Ldbxyzptlk/J4/c;", "savedStateRegistryController", "Ldbxyzptlk/J4/c;", "getSavedStateRegistryController$annotations", "Ldbxyzptlk/U2/y;", "_viewModelStore", "Ldbxyzptlk/U2/y;", "reportFullyDrawnExecutor", "Landroidx/activity/ComponentActivity$d;", "Ldbxyzptlk/e/C;", "fullyDrawnReporter$delegate", "Ldbxyzptlk/pI/j;", "getFullyDrawnReporter", "()Ldbxyzptlk/e/C;", "fullyDrawnReporter", "Ljava/util/concurrent/atomic/AtomicInteger;", "nextLocalRequestCode", "Ljava/util/concurrent/atomic/AtomicInteger;", "activityResultRegistry", "Ldbxyzptlk/h/d;", "getActivityResultRegistry", "()Ldbxyzptlk/h/d;", "Ljava/util/concurrent/CopyOnWriteArrayList;", "onConfigurationChangedListeners", "Ljava/util/concurrent/CopyOnWriteArrayList;", "onTrimMemoryListeners", "onNewIntentListeners", "onMultiWindowModeChangedListeners", "onPictureInPictureModeChangedListeners", "onUserLeaveHintListeners", "dispatchingOnMultiWindowModeChanged", "Z", "dispatchingOnPictureInPictureModeChanged", "Landroidx/lifecycle/t$b;", "defaultViewModelProviderFactory$delegate", "getDefaultViewModelProviderFactory", "()Landroidx/lifecycle/t$b;", "defaultViewModelProviderFactory", "onBackPressedDispatcher$delegate", "getOnBackPressedDispatcher", "()Landroidx/activity/OnBackPressedDispatcher;", "getOnBackPressedDispatcher$annotations", "onBackPressedDispatcher", "getLastCustomNonConfigurationInstance", "lastCustomNonConfigurationInstance", "Landroidx/lifecycle/f;", "getLifecycle", "()Landroidx/lifecycle/f;", "lifecycle", "getViewModelStore", "()Ldbxyzptlk/U2/y;", "viewModelStore", "Ldbxyzptlk/X2/a;", "getDefaultViewModelCreationExtras", "()Ldbxyzptlk/X2/a;", "defaultViewModelCreationExtras", "Landroidx/savedstate/a;", "getSavedStateRegistry", "()Landroidx/savedstate/a;", "savedStateRegistry", "Companion", "a", "b", "c", "d", "e", "activity_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public class ComponentActivity extends ComponentActivity implements LifecycleOwner, z, e, d, H, e, e, f, s, t, B, D {
  private static final String ACTIVITY_RESULT_TAG = "android:support:activity-result";
  
  private static final b Companion = new b(null);
  
  private y _viewModelStore;
  
  private final dbxyzptlk.h.d activityResultRegistry;
  
  private int contentLayoutId;
  
  private final a contextAwareHelper = new a();
  
  private final j defaultViewModelProviderFactory$delegate;
  
  private boolean dispatchingOnMultiWindowModeChanged;
  
  private boolean dispatchingOnPictureInPictureModeChanged;
  
  private final j fullyDrawnReporter$delegate;
  
  private final E menuHostHelper = new E((Runnable)new dbxyzptlk.e.d(this));
  
  private final AtomicInteger nextLocalRequestCode;
  
  private final j onBackPressedDispatcher$delegate;
  
  private final CopyOnWriteArrayList<a<Configuration>> onConfigurationChangedListeners;
  
  private final CopyOnWriteArrayList<a<k>> onMultiWindowModeChangedListeners;
  
  private final CopyOnWriteArrayList<a<Intent>> onNewIntentListeners;
  
  private final CopyOnWriteArrayList<a<v>> onPictureInPictureModeChangedListeners;
  
  private final CopyOnWriteArrayList<a<Integer>> onTrimMemoryListeners;
  
  private final CopyOnWriteArrayList<Runnable> onUserLeaveHintListeners;
  
  private final d reportFullyDrawnExecutor;
  
  private final dbxyzptlk.J4.c savedStateRegistryController;
  
  public ComponentActivity() {
    dbxyzptlk.J4.c c1 = dbxyzptlk.J4.c.d.a((d)this);
    this.savedStateRegistryController = c1;
    this.reportFullyDrawnExecutor = createFullyDrawnExecutor();
    this.fullyDrawnReporter$delegate = k.a(new h(this));
    this.nextLocalRequestCode = new AtomicInteger();
    this.activityResultRegistry = new f(this);
    this.onConfigurationChangedListeners = new CopyOnWriteArrayList<>();
    this.onTrimMemoryListeners = new CopyOnWriteArrayList<>();
    this.onNewIntentListeners = new CopyOnWriteArrayList<>();
    this.onMultiWindowModeChangedListeners = new CopyOnWriteArrayList<>();
    this.onPictureInPictureModeChangedListeners = new CopyOnWriteArrayList<>();
    this.onUserLeaveHintListeners = new CopyOnWriteArrayList<>();
    if (getLifecycle() != null) {
      getLifecycle().a((dbxyzptlk.U2.h)new dbxyzptlk.e.e(this));
      getLifecycle().a((dbxyzptlk.U2.h)new dbxyzptlk.e.f(this));
      getLifecycle().a((dbxyzptlk.U2.h)new LifecycleEventObserver(this) {
            public final ComponentActivity a;
            
            public void f(LifecycleOwner param1LifecycleOwner, androidx.lifecycle.f.a param1a) {
              s.h(param1LifecycleOwner, "source");
              s.h(param1a, "event");
              this.a.ensureViewModelStore();
              this.a.getLifecycle().d((dbxyzptlk.U2.h)this);
            }
          });
      c1.c();
      p.c((d)this);
      getSavedStateRegistry().i("android:support:activity-result", (a.c)new dbxyzptlk.e.g(this));
      addOnContextAvailableListener((dbxyzptlk.g.b)new dbxyzptlk.e.h(this));
      this.defaultViewModelProviderFactory$delegate = k.a(new g(this));
      this.onBackPressedDispatcher$delegate = k.a(new i(this));
      return;
    } 
    throw new IllegalStateException("getLifecycle() returned null in ComponentActivity's constructor. Please make sure you are lazily constructing your Lifecycle in the first call to getLifecycle() rather than relying on field initialization.");
  }
  
  public ComponentActivity(int paramInt) {
    this();
    this.contentLayoutId = paramInt;
  }
  
  private static final void _init_$lambda$2(ComponentActivity paramComponentActivity, LifecycleOwner paramLifecycleOwner, androidx.lifecycle.f.a parama) {
    s.h(paramComponentActivity, "this$0");
    s.h(paramLifecycleOwner, "<anonymous parameter 0>");
    s.h(parama, "event");
    if (parama == androidx.lifecycle.f.a.ON_STOP) {
      Window window = paramComponentActivity.getWindow();
      if (window != null) {
        View view = window.peekDecorView();
        if (view != null)
          view.cancelPendingInputEvents(); 
      } 
    } 
  }
  
  private static final void _init_$lambda$3(ComponentActivity paramComponentActivity, LifecycleOwner paramLifecycleOwner, androidx.lifecycle.f.a parama) {
    s.h(paramComponentActivity, "this$0");
    s.h(paramLifecycleOwner, "<anonymous parameter 0>");
    s.h(parama, "event");
    if (parama == androidx.lifecycle.f.a.ON_DESTROY) {
      paramComponentActivity.contextAwareHelper.b();
      if (!paramComponentActivity.isChangingConfigurations())
        paramComponentActivity.getViewModelStore().a(); 
      paramComponentActivity.reportFullyDrawnExecutor.A();
    } 
  }
  
  private static final Bundle _init_$lambda$4(ComponentActivity paramComponentActivity) {
    s.h(paramComponentActivity, "this$0");
    Bundle bundle = new Bundle();
    paramComponentActivity.activityResultRegistry.k(bundle);
    return bundle;
  }
  
  private static final void _init_$lambda$5(ComponentActivity paramComponentActivity, Context paramContext) {
    s.h(paramComponentActivity, "this$0");
    s.h(paramContext, "it");
    Bundle bundle = paramComponentActivity.getSavedStateRegistry().b("android:support:activity-result");
    if (bundle != null)
      paramComponentActivity.activityResultRegistry.j(bundle); 
  }
  
  private final void addObserverForBackInvoker(OnBackPressedDispatcher paramOnBackPressedDispatcher) {
    getLifecycle().a((dbxyzptlk.U2.h)new dbxyzptlk.e.i(paramOnBackPressedDispatcher, this));
  }
  
  private static final void addObserverForBackInvoker$lambda$7(OnBackPressedDispatcher paramOnBackPressedDispatcher, ComponentActivity paramComponentActivity, LifecycleOwner paramLifecycleOwner, androidx.lifecycle.f.a parama) {
    s.h(paramOnBackPressedDispatcher, "$dispatcher");
    s.h(paramComponentActivity, "this$0");
    s.h(paramLifecycleOwner, "<anonymous parameter 0>");
    s.h(parama, "event");
    if (parama == androidx.lifecycle.f.a.ON_CREATE)
      paramOnBackPressedDispatcher.o(a.a.a((Activity)paramComponentActivity)); 
  }
  
  private final d createFullyDrawnExecutor() {
    return new e(this);
  }
  
  private final void ensureViewModelStore() {
    if (this._viewModelStore == null) {
      c c1 = (c)getLastNonConfigurationInstance();
      if (c1 != null)
        this._viewModelStore = c1.b(); 
      if (this._viewModelStore == null)
        this._viewModelStore = new y(); 
    } 
  }
  
  private static final void menuHostHelper$lambda$0(ComponentActivity paramComponentActivity) {
    s.h(paramComponentActivity, "this$0");
    paramComponentActivity.invalidateMenu();
  }
  
  public void addContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    initializeViewTreeOwners();
    d d1 = this.reportFullyDrawnExecutor;
    View view = getWindow().getDecorView();
    s.g(view, "window.decorView");
    d1.q(view);
    super.addContentView(paramView, paramLayoutParams);
  }
  
  public void addMenuProvider(G paramG) {
    s.h(paramG, "provider");
    this.menuHostHelper.c(paramG);
  }
  
  public void addMenuProvider(G paramG, LifecycleOwner paramLifecycleOwner) {
    s.h(paramG, "provider");
    s.h(paramLifecycleOwner, "owner");
    this.menuHostHelper.d(paramG, paramLifecycleOwner);
  }
  
  @SuppressLint({"LambdaLast"})
  public void addMenuProvider(G paramG, LifecycleOwner paramLifecycleOwner, androidx.lifecycle.f.b paramb) {
    s.h(paramG, "provider");
    s.h(paramLifecycleOwner, "owner");
    s.h(paramb, "state");
    this.menuHostHelper.e(paramG, paramLifecycleOwner, paramb);
  }
  
  public final void addOnConfigurationChangedListener(a<Configuration> parama) {
    s.h(parama, "listener");
    this.onConfigurationChangedListeners.add(parama);
  }
  
  public final void addOnContextAvailableListener(dbxyzptlk.g.b paramb) {
    s.h(paramb, "listener");
    this.contextAwareHelper.a(paramb);
  }
  
  public final void addOnMultiWindowModeChangedListener(a<k> parama) {
    s.h(parama, "listener");
    this.onMultiWindowModeChangedListeners.add(parama);
  }
  
  public final void addOnNewIntentListener(a<Intent> parama) {
    s.h(parama, "listener");
    this.onNewIntentListeners.add(parama);
  }
  
  public final void addOnPictureInPictureModeChangedListener(a<v> parama) {
    s.h(parama, "listener");
    this.onPictureInPictureModeChangedListeners.add(parama);
  }
  
  public final void addOnTrimMemoryListener(a<Integer> parama) {
    s.h(parama, "listener");
    this.onTrimMemoryListeners.add(parama);
  }
  
  public final void addOnUserLeaveHintListener(Runnable paramRunnable) {
    s.h(paramRunnable, "listener");
    this.onUserLeaveHintListeners.add(paramRunnable);
  }
  
  public final dbxyzptlk.h.d getActivityResultRegistry() {
    return this.activityResultRegistry;
  }
  
  public a getDefaultViewModelCreationExtras() {
    Bundle bundle = null;
    dbxyzptlk.X2.b b1 = new dbxyzptlk.X2.b(null, 1, null);
    if (getApplication() != null) {
      a.b b2 = t.a.h;
      Application application = getApplication();
      s.g(application, "application");
      b1.c(b2, application);
    } 
    b1.c(p.a, this);
    b1.c(p.b, this);
    Intent intent = getIntent();
    if (intent != null)
      bundle = intent.getExtras(); 
    if (bundle != null)
      b1.c(p.c, bundle); 
    return (a)b1;
  }
  
  public t.b getDefaultViewModelProviderFactory() {
    return (t.b)this.defaultViewModelProviderFactory$delegate.getValue();
  }
  
  public C getFullyDrawnReporter() {
    return (C)this.fullyDrawnReporter$delegate.getValue();
  }
  
  public Object getLastCustomNonConfigurationInstance() {
    c c1 = (c)getLastNonConfigurationInstance();
    if (c1 != null) {
      Object object = c1.a();
    } else {
      c1 = null;
    } 
    return c1;
  }
  
  public androidx.lifecycle.f getLifecycle() {
    return super.getLifecycle();
  }
  
  public final OnBackPressedDispatcher getOnBackPressedDispatcher() {
    return (OnBackPressedDispatcher)this.onBackPressedDispatcher$delegate.getValue();
  }
  
  public final a getSavedStateRegistry() {
    return this.savedStateRegistryController.b();
  }
  
  public y getViewModelStore() {
    if (getApplication() != null) {
      ensureViewModelStore();
      y y1 = this._viewModelStore;
      s.e(y1);
      return y1;
    } 
    throw new IllegalStateException("Your activity is not yet attached to the Application instance. You can't request ViewModel before onCreate call.");
  }
  
  public void initializeViewTreeOwners() {
    View view = getWindow().getDecorView();
    s.g(view, "window.decorView");
    A.b(view, (LifecycleOwner)this);
    view = getWindow().getDecorView();
    s.g(view, "window.decorView");
    B.b(view, (z)this);
    view = getWindow().getDecorView();
    s.g(view, "window.decorView");
    dbxyzptlk.J4.e.b(view, (d)this);
    view = getWindow().getDecorView();
    s.g(view, "window.decorView");
    L.b(view, (H)this);
    view = getWindow().getDecorView();
    s.g(view, "window.decorView");
    K.a(view, (D)this);
  }
  
  public void invalidateMenu() {
    invalidateOptionsMenu();
  }
  
  public void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent) {
    if (!this.activityResultRegistry.e(paramInt1, paramInt2, paramIntent))
      super.onActivityResult(paramInt1, paramInt2, paramIntent); 
  }
  
  public void onBackPressed() {
    getOnBackPressedDispatcher().l();
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    s.h(paramConfiguration, "newConfig");
    super.onConfigurationChanged(paramConfiguration);
    Iterator<a<Configuration>> iterator = this.onConfigurationChangedListeners.iterator();
    while (iterator.hasNext())
      ((a)iterator.next()).accept(paramConfiguration); 
  }
  
  public void onCreate(Bundle paramBundle) {
    this.savedStateRegistryController.d(paramBundle);
    this.contextAwareHelper.c((Context)this);
    super.onCreate(paramBundle);
    n.b.c((Activity)this);
    int i = this.contentLayoutId;
    if (i != 0)
      setContentView(i); 
  }
  
  public boolean onCreatePanelMenu(int paramInt, Menu paramMenu) {
    s.h(paramMenu, "menu");
    if (paramInt == 0) {
      super.onCreatePanelMenu(paramInt, paramMenu);
      this.menuHostHelper.h(paramMenu, getMenuInflater());
    } 
    return true;
  }
  
  public boolean onMenuItemSelected(int paramInt, MenuItem paramMenuItem) {
    boolean bool;
    s.h(paramMenuItem, "item");
    if (super.onMenuItemSelected(paramInt, paramMenuItem))
      return true; 
    if (paramInt == 0) {
      bool = this.menuHostHelper.j(paramMenuItem);
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public void onMultiWindowModeChanged(boolean paramBoolean) {
    if (this.dispatchingOnMultiWindowModeChanged)
      return; 
    Iterator<a<k>> iterator = this.onMultiWindowModeChangedListeners.iterator();
    while (iterator.hasNext())
      ((a)iterator.next()).accept(new k(paramBoolean)); 
  }
  
  public void onMultiWindowModeChanged(boolean paramBoolean, Configuration paramConfiguration) {
    s.h(paramConfiguration, "newConfig");
    this.dispatchingOnMultiWindowModeChanged = true;
    try {
      super.onMultiWindowModeChanged(paramBoolean, paramConfiguration);
      this.dispatchingOnMultiWindowModeChanged = false;
      Iterator<a<k>> iterator = this.onMultiWindowModeChangedListeners.iterator();
      return;
    } finally {
      this.dispatchingOnMultiWindowModeChanged = false;
    } 
  }
  
  public void onNewIntent(Intent paramIntent) {
    s.h(paramIntent, "intent");
    super.onNewIntent(paramIntent);
    Iterator<a<Intent>> iterator = this.onNewIntentListeners.iterator();
    while (iterator.hasNext())
      ((a)iterator.next()).accept(paramIntent); 
  }
  
  public void onPanelClosed(int paramInt, Menu paramMenu) {
    s.h(paramMenu, "menu");
    this.menuHostHelper.i(paramMenu);
    super.onPanelClosed(paramInt, paramMenu);
  }
  
  public void onPictureInPictureModeChanged(boolean paramBoolean) {
    if (this.dispatchingOnPictureInPictureModeChanged)
      return; 
    Iterator<a<v>> iterator = this.onPictureInPictureModeChangedListeners.iterator();
    while (iterator.hasNext())
      ((a)iterator.next()).accept(new v(paramBoolean)); 
  }
  
  public void onPictureInPictureModeChanged(boolean paramBoolean, Configuration paramConfiguration) {
    s.h(paramConfiguration, "newConfig");
    this.dispatchingOnPictureInPictureModeChanged = true;
    try {
      super.onPictureInPictureModeChanged(paramBoolean, paramConfiguration);
      this.dispatchingOnPictureInPictureModeChanged = false;
      Iterator<a<v>> iterator = this.onPictureInPictureModeChangedListeners.iterator();
      return;
    } finally {
      this.dispatchingOnPictureInPictureModeChanged = false;
    } 
  }
  
  public boolean onPreparePanel(int paramInt, View paramView, Menu paramMenu) {
    s.h(paramMenu, "menu");
    if (paramInt == 0) {
      super.onPreparePanel(paramInt, paramView, paramMenu);
      this.menuHostHelper.k(paramMenu);
    } 
    return true;
  }
  
  public void onRequestPermissionsResult(int paramInt, String[] paramArrayOfString, int[] paramArrayOfint) {
    s.h(paramArrayOfString, "permissions");
    s.h(paramArrayOfint, "grantResults");
    if (!this.activityResultRegistry.e(paramInt, -1, (new Intent()).putExtra("androidx.activity.result.contract.extra.PERMISSIONS", paramArrayOfString).putExtra("androidx.activity.result.contract.extra.PERMISSION_GRANT_RESULTS", paramArrayOfint)))
      super.onRequestPermissionsResult(paramInt, paramArrayOfString, paramArrayOfint); 
  }
  
  public Object onRetainCustomNonConfigurationInstance() {
    return null;
  }
  
  public final Object onRetainNonConfigurationInstance() {
    Object object = onRetainCustomNonConfigurationInstance();
    y y2 = this._viewModelStore;
    y y1 = y2;
    if (y2 == null) {
      c c2 = (c)getLastNonConfigurationInstance();
      y1 = y2;
      if (c2 != null)
        y1 = c2.b(); 
    } 
    if (y1 == null && object == null)
      return null; 
    c c1 = new c();
    c1.c(object);
    c1.d(y1);
    return c1;
  }
  
  public void onSaveInstanceState(Bundle paramBundle) {
    s.h(paramBundle, "outState");
    if (getLifecycle() instanceof j) {
      androidx.lifecycle.f f1 = getLifecycle();
      s.f(f1, "null cannot be cast to non-null type androidx.lifecycle.LifecycleRegistry");
      ((j)f1).n(androidx.lifecycle.f.b.CREATED);
    } 
    super.onSaveInstanceState(paramBundle);
    this.savedStateRegistryController.e(paramBundle);
  }
  
  public void onTrimMemory(int paramInt) {
    super.onTrimMemory(paramInt);
    Iterator<a<Integer>> iterator = this.onTrimMemoryListeners.iterator();
    while (iterator.hasNext())
      ((a)iterator.next()).accept(Integer.valueOf(paramInt)); 
  }
  
  public void onUserLeaveHint() {
    super.onUserLeaveHint();
    Iterator<Runnable> iterator = this.onUserLeaveHintListeners.iterator();
    while (iterator.hasNext())
      ((Runnable)iterator.next()).run(); 
  }
  
  public Context peekAvailableContext() {
    return this.contextAwareHelper.d();
  }
  
  public final <I, O> dbxyzptlk.h.b<I> registerForActivityResult(a<I, O> parama, a<O> parama1) {
    s.h(parama, "contract");
    s.h(parama1, "callback");
    return registerForActivityResult(parama, this.activityResultRegistry, parama1);
  }
  
  public final <I, O> dbxyzptlk.h.b<I> registerForActivityResult(a<I, O> parama, dbxyzptlk.h.d paramd, a<O> parama1) {
    s.h(parama, "contract");
    s.h(paramd, "registry");
    s.h(parama1, "callback");
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("activity_rq#");
    stringBuilder.append(this.nextLocalRequestCode.getAndIncrement());
    return paramd.l(stringBuilder.toString(), (LifecycleOwner)this, parama, parama1);
  }
  
  public void removeMenuProvider(G paramG) {
    s.h(paramG, "provider");
    this.menuHostHelper.l(paramG);
  }
  
  public final void removeOnConfigurationChangedListener(a<Configuration> parama) {
    s.h(parama, "listener");
    this.onConfigurationChangedListeners.remove(parama);
  }
  
  public final void removeOnContextAvailableListener(dbxyzptlk.g.b paramb) {
    s.h(paramb, "listener");
    this.contextAwareHelper.e(paramb);
  }
  
  public final void removeOnMultiWindowModeChangedListener(a<k> parama) {
    s.h(parama, "listener");
    this.onMultiWindowModeChangedListeners.remove(parama);
  }
  
  public final void removeOnNewIntentListener(a<Intent> parama) {
    s.h(parama, "listener");
    this.onNewIntentListeners.remove(parama);
  }
  
  public final void removeOnPictureInPictureModeChangedListener(a<v> parama) {
    s.h(parama, "listener");
    this.onPictureInPictureModeChangedListeners.remove(parama);
  }
  
  public final void removeOnTrimMemoryListener(a<Integer> parama) {
    s.h(parama, "listener");
    this.onTrimMemoryListeners.remove(parama);
  }
  
  public final void removeOnUserLeaveHintListener(Runnable paramRunnable) {
    s.h(paramRunnable, "listener");
    this.onUserLeaveHintListeners.remove(paramRunnable);
  }
  
  public void reportFullyDrawn() {
    try {
      if (a.h())
        a.c("reportFullyDrawn() for ComponentActivity"); 
    } finally {
      Exception exception;
    } 
    super.reportFullyDrawn();
    getFullyDrawnReporter().b();
    a.f();
  }
  
  public void setContentView(int paramInt) {
    initializeViewTreeOwners();
    d d1 = this.reportFullyDrawnExecutor;
    View view = getWindow().getDecorView();
    s.g(view, "window.decorView");
    d1.q(view);
    super.setContentView(paramInt);
  }
  
  public void setContentView(View paramView) {
    initializeViewTreeOwners();
    d d1 = this.reportFullyDrawnExecutor;
    View view = getWindow().getDecorView();
    s.g(view, "window.decorView");
    d1.q(view);
    super.setContentView(paramView);
  }
  
  public void setContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    initializeViewTreeOwners();
    d d1 = this.reportFullyDrawnExecutor;
    View view = getWindow().getDecorView();
    s.g(view, "window.decorView");
    d1.q(view);
    super.setContentView(paramView, paramLayoutParams);
  }
  
  public void startActivityForResult(Intent paramIntent, int paramInt) {
    s.h(paramIntent, "intent");
    super.startActivityForResult(paramIntent, paramInt);
  }
  
  public void startActivityForResult(Intent paramIntent, int paramInt, Bundle paramBundle) {
    s.h(paramIntent, "intent");
    super.startActivityForResult(paramIntent, paramInt, paramBundle);
  }
  
  public void startIntentSenderForResult(IntentSender paramIntentSender, int paramInt1, Intent paramIntent, int paramInt2, int paramInt3, int paramInt4) throws IntentSender.SendIntentException {
    s.h(paramIntentSender, "intent");
    super.startIntentSenderForResult(paramIntentSender, paramInt1, paramIntent, paramInt2, paramInt3, paramInt4);
  }
  
  public void startIntentSenderForResult(IntentSender paramIntentSender, int paramInt1, Intent paramIntent, int paramInt2, int paramInt3, int paramInt4, Bundle paramBundle) throws IntentSender.SendIntentException {
    s.h(paramIntentSender, "intent");
    super.startIntentSenderForResult(paramIntentSender, paramInt1, paramIntent, paramInt2, paramInt3, paramInt4, paramBundle);
  }
  
  class ComponentActivity {}
  
  @Metadata(d1 = {"\000\024\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\016\n\002\b\003\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003R\024\020\005\032\0020\0048\002XT¢\006\006\n\004\b\005\020\006¨\006\007"}, d2 = {"Landroidx/activity/ComponentActivity$b;", "", "<init>", "()V", "", "ACTIVITY_RESULT_TAG", "Ljava/lang/String;", "activity_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class b {
    public b() {}
  }
  
  @Metadata(d1 = {"\000\024\n\002\030\002\n\002\020\000\n\002\b\b\n\002\030\002\n\002\b\007\b\000\030\0002\0020\001B\007¢\006\004\b\002\020\003R$\020\t\032\004\030\0010\0018\006@\006X\016¢\006\022\n\004\b\004\020\005\032\004\b\004\020\006\"\004\b\007\020\bR$\020\020\032\004\030\0010\n8\006@\006X\016¢\006\022\n\004\b\013\020\f\032\004\b\013\020\r\"\004\b\016\020\017¨\006\021"}, d2 = {"Landroidx/activity/ComponentActivity$c;", "", "<init>", "()V", "a", "Ljava/lang/Object;", "()Ljava/lang/Object;", "c", "(Ljava/lang/Object;)V", "custom", "Ldbxyzptlk/U2/y;", "b", "Ldbxyzptlk/U2/y;", "()Ldbxyzptlk/U2/y;", "d", "(Ldbxyzptlk/U2/y;)V", "viewModelStore", "activity_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class c {
    public Object a;
    
    public y b;
    
    public final Object a() {
      return this.a;
    }
    
    public final y b() {
      return this.b;
    }
    
    public final void c(Object param1Object) {
      this.a = param1Object;
    }
    
    public final void d(y param1y) {
      this.b = param1y;
    }
  }
  
  @Metadata(d1 = {"\000\026\n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\005\bb\030\0002\0020\001J\027\020\005\032\0020\0042\006\020\003\032\0020\002H&¢\006\004\b\005\020\006J\017\020\007\032\0020\004H&¢\006\004\b\007\020\bø\001\000\002\006\n\004\b!0\001¨\006\tÀ\006\001"}, d2 = {"Landroidx/activity/ComponentActivity$d;", "Ljava/util/concurrent/Executor;", "Landroid/view/View;", "view", "Ldbxyzptlk/pI/D;", "q", "(Landroid/view/View;)V", "A", "()V", "activity_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static interface d extends Executor {
    void A();
    
    void q(View param1View);
  }
  
  @Metadata(d1 = {"\0002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\t\n\002\020\t\n\002\b\013\n\002\020\013\n\002\b\b\b\004\030\0002\0020\0012\0020\0022\0020\003B\007¢\006\004\b\004\020\005J\027\020\t\032\0020\b2\006\020\007\032\0020\006H\026¢\006\004\b\t\020\nJ\017\020\013\032\0020\bH\026¢\006\004\b\013\020\fJ\027\020\016\032\0020\b2\006\020\r\032\0020\003H\026¢\006\004\b\016\020\017J\017\020\020\032\0020\bH\026¢\006\004\b\020\020\fJ\017\020\021\032\0020\bH\026¢\006\004\b\021\020\fR\027\020\027\032\0020\0228\006¢\006\f\n\004\b\023\020\024\032\004\b\025\020\026R$\020\035\032\004\030\0010\0038\006@\006X\016¢\006\022\n\004\b\030\020\031\032\004\b\032\020\033\"\004\b\034\020\017R\"\020%\032\0020\0368\006@\006X\016¢\006\022\n\004\b\037\020 \032\004\b!\020\"\"\004\b#\020$¨\006&"}, d2 = {"Landroidx/activity/ComponentActivity$e;", "Landroidx/activity/ComponentActivity$d;", "Landroid/view/ViewTreeObserver$OnDrawListener;", "Ljava/lang/Runnable;", "<init>", "(Landroidx/activity/ComponentActivity;)V", "Landroid/view/View;", "view", "Ldbxyzptlk/pI/D;", "q", "(Landroid/view/View;)V", "A", "()V", "runnable", "execute", "(Ljava/lang/Runnable;)V", "onDraw", "run", "", "a", "J", "getEndWatchTimeMillis", "()J", "endWatchTimeMillis", "b", "Ljava/lang/Runnable;", "getCurrentRunnable", "()Ljava/lang/Runnable;", "setCurrentRunnable", "currentRunnable", "", "c", "Z", "getOnDrawScheduled", "()Z", "setOnDrawScheduled", "(Z)V", "onDrawScheduled", "activity_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public final class e implements d, ViewTreeObserver.OnDrawListener, Runnable {
    public final long a = SystemClock.uptimeMillis() + 10000L;
    
    public Runnable b;
    
    public boolean c;
    
    public final ComponentActivity d;
    
    public e(ComponentActivity this$0) {}
    
    public static final void b(e param1e) {
      s.h(param1e, "this$0");
      Runnable runnable = param1e.b;
      if (runnable != null) {
        s.e(runnable);
        runnable.run();
        param1e.b = null;
      } 
    }
    
    public void A() {
      this.d.getWindow().getDecorView().removeCallbacks(this);
      this.d.getWindow().getDecorView().getViewTreeObserver().removeOnDrawListener(this);
    }
    
    public void execute(Runnable param1Runnable) {
      s.h(param1Runnable, "runnable");
      this.b = param1Runnable;
      View view = this.d.getWindow().getDecorView();
      s.g(view, "window.decorView");
      if (this.c) {
        if (s.c(Looper.myLooper(), Looper.getMainLooper())) {
          view.invalidate();
        } else {
          view.postInvalidate();
        } 
      } else {
        view.postOnAnimation((Runnable)new j(this));
      } 
    }
    
    public void onDraw() {
      Runnable runnable = this.b;
      if (runnable != null) {
        runnable.run();
        this.b = null;
        if (this.d.getFullyDrawnReporter().c()) {
          this.c = false;
          this.d.getWindow().getDecorView().post(this);
        } 
      } else if (SystemClock.uptimeMillis() > this.a) {
        this.c = false;
        this.d.getWindow().getDecorView().post(this);
      } 
    }
    
    public void q(View param1View) {
      s.h(param1View, "view");
      if (!this.c) {
        this.c = true;
        param1View.getViewTreeObserver().addOnDrawListener(this);
      } 
    }
    
    public void run() {
      this.d.getWindow().getDecorView().getViewTreeObserver().removeOnDrawListener(this);
    }
  }
  
  @Metadata(d1 = {"\000)\n\000\n\002\030\002\n\002\b\002\n\002\020\b\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\003*\001\000\b\n\030\0002\0020\001JI\020\f\032\0020\013\"\004\b\000\020\002\"\004\b\001\020\0032\006\020\005\032\0020\0042\022\020\007\032\016\022\004\022\0028\000\022\004\022\0028\0010\0062\006\020\b\032\0028\0002\b\020\n\032\004\030\0010\tH\026¢\006\004\b\f\020\r¨\006\016"}, d2 = {"androidx/activity/ComponentActivity$f", "Ldbxyzptlk/h/d;", "I", "O", "", "requestCode", "Ldbxyzptlk/i/a;", "contract", "input", "Ldbxyzptlk/T1/e;", "options", "Ldbxyzptlk/pI/D;", "i", "(ILdbxyzptlk/i/a;Ljava/lang/Object;Ldbxyzptlk/T1/e;)V", "activity_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class f extends dbxyzptlk.h.d {
    public final ComponentActivity i;
    
    public f(ComponentActivity param1ComponentActivity) {}
    
    public static final void s(f param1f, int param1Int, a.a param1a) {
      s.h(param1f, "this$0");
      param1f.f(param1Int, param1a.a());
    }
    
    public static final void t(f param1f, int param1Int, IntentSender.SendIntentException param1SendIntentException) {
      s.h(param1f, "this$0");
      s.h(param1SendIntentException, "$e");
      param1f.e(param1Int, 0, (new Intent()).setAction("androidx.activity.result.contract.action.INTENT_SENDER_REQUEST").putExtra("androidx.activity.result.contract.extra.SEND_INTENT_EXCEPTION", (Serializable)param1SendIntentException));
    }
    
    public <I, O> void i(int param1Int, a<I, O> param1a, I param1I, dbxyzptlk.T1.e param1e) {
      String[] arrayOfString1;
      String[] arrayOfString2;
      s.h(param1a, "contract");
      ComponentActivity componentActivity = this.i;
      a.a a1 = param1a.getSynchronousResult((Context)componentActivity, param1I);
      if (a1 != null) {
        (new Handler(Looper.getMainLooper())).post((Runnable)new k(this, param1Int, a1));
        return;
      } 
      Intent intent = param1a.createIntent((Context)componentActivity, param1I);
      if (intent.getExtras() != null) {
        Bundle bundle = intent.getExtras();
        s.e(bundle);
        if (bundle.getClassLoader() == null)
          intent.setExtrasClassLoader(componentActivity.getClassLoader()); 
      } 
      if (intent.hasExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE")) {
        Bundle bundle = intent.getBundleExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE");
        intent.removeExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE");
      } else {
        param1a = null;
      } 
      if (s.c("androidx.activity.result.contract.action.REQUEST_PERMISSIONS", intent.getAction())) {
        arrayOfString2 = intent.getStringArrayExtra("androidx.activity.result.contract.extra.PERMISSIONS");
        arrayOfString1 = arrayOfString2;
        if (arrayOfString2 == null)
          arrayOfString1 = new String[0]; 
        dbxyzptlk.T1.b.w((Activity)componentActivity, arrayOfString1, param1Int);
      } else {
        IntentSenderRequest intentSenderRequest;
        if (s.c("androidx.activity.result.contract.action.INTENT_SENDER_REQUEST", arrayOfString2.getAction())) {
          intentSenderRequest = (IntentSenderRequest)arrayOfString2.getParcelableExtra("androidx.activity.result.contract.extra.INTENT_SENDER_REQUEST");
          try {
            s.e(intentSenderRequest);
            dbxyzptlk.T1.b.C((Activity)componentActivity, intentSenderRequest.d(), param1Int, intentSenderRequest.a(), intentSenderRequest.b(), intentSenderRequest.c(), 0, (Bundle)arrayOfString1);
          } catch (android.content.IntentSender.SendIntentException sendIntentException) {
            (new Handler(Looper.getMainLooper())).post((Runnable)new l(this, param1Int, sendIntentException));
          } 
        } else {
          dbxyzptlk.T1.b.B((Activity)componentActivity, (Intent)intentSenderRequest, param1Int, (Bundle)sendIntentException);
        } 
      } 
    }
  }
  
  @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"Landroidx/lifecycle/q;", "b", "()Landroidx/lifecycle/q;"}, k = 3, mv = {1, 8, 0})
  public static final class g extends u implements a<q> {
    public final ComponentActivity f;
    
    public g(ComponentActivity param1ComponentActivity) {
      super(0);
    }
    
    public final q b() {
      Bundle bundle;
      Application application = this.f.getApplication();
      ComponentActivity componentActivity = this.f;
      if (componentActivity.getIntent() != null) {
        bundle = this.f.getIntent().getExtras();
      } else {
        bundle = null;
      } 
      return new q(application, (d)componentActivity, bundle);
    }
  }
  
  @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"Ldbxyzptlk/e/C;", "b", "()Ldbxyzptlk/e/C;"}, k = 3, mv = {1, 8, 0})
  public static final class h extends u implements a<C> {
    public final ComponentActivity f;
    
    public h(ComponentActivity param1ComponentActivity) {
      super(0);
    }
    
    public final C b() {
      return new C(this.f.reportFullyDrawnExecutor, (a)new a(this.f));
    }
  }
  
  @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"Landroidx/activity/OnBackPressedDispatcher;", "c", "()Landroidx/activity/OnBackPressedDispatcher;"}, k = 3, mv = {1, 8, 0})
  public static final class i extends u implements a<OnBackPressedDispatcher> {
    public final ComponentActivity f;
    
    public i(ComponentActivity param1ComponentActivity) {
      super(0);
    }
    
    public static final void d(ComponentActivity param1ComponentActivity) {
      s.h(param1ComponentActivity, "this$0");
      try {
        param1ComponentActivity.onBackPressed();
      } catch (IllegalStateException illegalStateException) {
        if (!s.c(illegalStateException.getMessage(), "Can not perform this action after onSaveInstanceState"))
          throw illegalStateException; 
      } catch (NullPointerException nullPointerException) {
        if (!s.c(nullPointerException.getMessage(), "Attempt to invoke virtual method 'android.os.Handler android.app.FragmentHostCallback.getHandler()' on a null object reference"))
          throw nullPointerException; 
      } 
    }
    
    public static final void f(ComponentActivity param1ComponentActivity, OnBackPressedDispatcher param1OnBackPressedDispatcher) {
      s.h(param1ComponentActivity, "this$0");
      s.h(param1OnBackPressedDispatcher, "$dispatcher");
      param1ComponentActivity.addObserverForBackInvoker(param1OnBackPressedDispatcher);
    }
    
    public final OnBackPressedDispatcher c() {
      OnBackPressedDispatcher onBackPressedDispatcher = new OnBackPressedDispatcher((Runnable)new m(this.f));
      ComponentActivity componentActivity = this.f;
      if (Build.VERSION.SDK_INT >= 33)
        if (!s.c(Looper.myLooper(), Looper.getMainLooper())) {
          (new Handler(Looper.getMainLooper())).post((Runnable)new n(componentActivity, onBackPressedDispatcher));
        } else {
          componentActivity.addObserverForBackInvoker(onBackPressedDispatcher);
        }  
      return onBackPressedDispatcher;
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\activity\ComponentActivity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */