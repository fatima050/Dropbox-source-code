package androidx.activity.result;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Parcel;
import android.os.Parcelable;
import dbxyzptlk.DI.s;
import kotlin.Metadata;

@Metadata(d1 = {"\000.\n\002\030\002\n\002\030\002\n\002\020\b\n\000\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\002\n\002\020\016\n\002\b\004\n\002\030\002\n\002\b\013\b\007\030\000 \0322\0020\001:\001\027B\031\022\006\020\003\032\0020\002\022\b\020\005\032\004\030\0010\004¢\006\004\b\006\020\007B\021\b\020\022\006\020\t\032\0020\b¢\006\004\b\006\020\nJ\017\020\f\032\0020\013H\026¢\006\004\b\f\020\rJ\037\020\021\032\0020\0202\006\020\016\032\0020\b2\006\020\017\032\0020\002H\026¢\006\004\b\021\020\022J\017\020\023\032\0020\002H\026¢\006\004\b\023\020\024R\027\020\003\032\0020\0028\006¢\006\f\n\004\b\025\020\026\032\004\b\027\020\024R\031\020\005\032\004\030\0010\0048\006¢\006\f\n\004\b\027\020\030\032\004\b\025\020\031¨\006\033"}, d2 = {"Landroidx/activity/result/ActivityResult;", "Landroid/os/Parcelable;", "", "resultCode", "Landroid/content/Intent;", "data", "<init>", "(ILandroid/content/Intent;)V", "Landroid/os/Parcel;", "parcel", "(Landroid/os/Parcel;)V", "", "toString", "()Ljava/lang/String;", "dest", "flags", "Ldbxyzptlk/pI/D;", "writeToParcel", "(Landroid/os/Parcel;I)V", "describeContents", "()I", "a", "I", "b", "Landroid/content/Intent;", "()Landroid/content/Intent;", "c", "activity_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
@SuppressLint({"BanParcelableUsage"})
public final class ActivityResult implements Parcelable {
  public static final Parcelable.Creator<ActivityResult> CREATOR;
  
  public static final b c = new b(null);
  
  public final int a;
  
  public final Intent b;
  
  static {
    CREATOR = (Parcelable.Creator<ActivityResult>)new a();
  }
  
  public ActivityResult(int paramInt, Intent paramIntent) {
    this.a = paramInt;
    this.b = paramIntent;
  }
  
  public ActivityResult(Parcel paramParcel) {
    this(i, intent);
  }
  
  public final Intent a() {
    return this.b;
  }
  
  public final int b() {
    return this.a;
  }
  
  public int describeContents() {
    return 0;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("ActivityResult{resultCode=");
    stringBuilder.append(c.a(this.a));
    stringBuilder.append(", data=");
    stringBuilder.append(this.b);
    stringBuilder.append('}');
    return stringBuilder.toString();
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    boolean bool;
    s.h(paramParcel, "dest");
    paramParcel.writeInt(this.a);
    if (this.b == null) {
      bool = false;
    } else {
      bool = true;
    } 
    paramParcel.writeInt(bool);
    Intent intent = this.b;
    if (intent != null)
      intent.writeToParcel(paramParcel, paramInt); 
  }
  
  class ActivityResult {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\activity\result\ActivityResult.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */