package androidx.activity;

import android.os.Build;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import androidx.lifecycle.LifecycleEventObserver;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.f;
import dbxyzptlk.CI.a;
import dbxyzptlk.CI.l;
import dbxyzptlk.DI.f;
import dbxyzptlk.DI.p;
import dbxyzptlk.DI.s;
import dbxyzptlk.e.E;
import dbxyzptlk.e.b;
import dbxyzptlk.e.c;
import dbxyzptlk.g2.a;
import dbxyzptlk.pI.D;
import dbxyzptlk.qI.k;
import java.util.Iterator;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

@Metadata(d1 = {"\000X\n\002\030\002\n\002\020\000\n\002\030\002\n\000\n\002\030\002\n\002\020\013\n\002\b\004\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\t\n\002\030\002\n\002\b\t\n\002\030\002\n\002\b\006\n\002\030\002\n\002\b\f\030\0002\0020\001:\00458<\030B!\022\b\020\003\032\004\030\0010\002\022\016\020\006\032\n\022\004\022\0020\005\030\0010\004¢\006\004\b\007\020\bB\025\b\027\022\n\b\002\020\003\032\004\030\0010\002¢\006\004\b\007\020\tJ\027\020\r\032\0020\f2\006\020\013\032\0020\nH\007¢\006\004\b\r\020\016J\027\020\021\032\0020\f2\006\020\020\032\0020\017H\007¢\006\004\b\021\020\022J\027\020\024\032\0020\0232\006\020\020\032\0020\017H\001¢\006\004\b\024\020\025J\037\020\030\032\0020\f2\006\020\027\032\0020\0262\006\020\020\032\0020\017H\007¢\006\004\b\030\020\031J\017\020\032\032\0020\fH\007¢\006\004\b\032\020\033J\027\020\035\032\0020\f2\006\020\034\032\0020\005H\003¢\006\004\b\035\020\036J\017\020\037\032\0020\fH\002¢\006\004\b\037\020\033J\027\020\"\032\0020\f2\006\020!\032\0020 H\003¢\006\004\b\"\020#J\027\020$\032\0020\f2\006\020!\032\0020 H\003¢\006\004\b$\020#J\017\020%\032\0020\fH\003¢\006\004\b%\020\033R\026\020\003\032\004\030\0010\0028\002X\004¢\006\006\n\004\b&\020'R\034\020\006\032\n\022\004\022\0020\005\030\0010\0048\002X\004¢\006\006\n\004\b(\020)R\032\020-\032\b\022\004\022\0020\0170*8\002X\004¢\006\006\n\004\b+\020,R\030\0200\032\004\030\0010\0178\002@\002X\016¢\006\006\n\004\b.\020/R\030\0204\032\004\030\001018\002@\002X\016¢\006\006\n\004\b2\0203R\030\0207\032\004\030\0010\n8\002@\002X\016¢\006\006\n\004\b5\0206R\026\020:\032\0020\0058\002@\002X\016¢\006\006\n\004\b8\0209R\026\020;\032\0020\0058\002@\002X\016¢\006\006\n\004\b\030\0209¨\006="}, d2 = {"Landroidx/activity/OnBackPressedDispatcher;", "", "Ljava/lang/Runnable;", "fallbackOnBackPressed", "Ldbxyzptlk/g2/a;", "", "onHasEnabledCallbacksChanged", "<init>", "(Ljava/lang/Runnable;Ldbxyzptlk/g2/a;)V", "(Ljava/lang/Runnable;)V", "Landroid/window/OnBackInvokedDispatcher;", "invoker", "Ldbxyzptlk/pI/D;", "o", "(Landroid/window/OnBackInvokedDispatcher;)V", "Ldbxyzptlk/e/E;", "onBackPressedCallback", "i", "(Ldbxyzptlk/e/E;)V", "Ldbxyzptlk/e/c;", "j", "(Ldbxyzptlk/e/E;)Ldbxyzptlk/e/c;", "Landroidx/lifecycle/LifecycleOwner;", "owner", "h", "(Landroidx/lifecycle/LifecycleOwner;Ldbxyzptlk/e/E;)V", "l", "()V", "shouldBeRegistered", "p", "(Z)V", "q", "Ldbxyzptlk/e/b;", "backEvent", "n", "(Ldbxyzptlk/e/b;)V", "m", "k", "a", "Ljava/lang/Runnable;", "b", "Ldbxyzptlk/g2/a;", "Ldbxyzptlk/qI/k;", "c", "Ldbxyzptlk/qI/k;", "onBackPressedCallbacks", "d", "Ldbxyzptlk/e/E;", "inProgressCallback", "Landroid/window/OnBackInvokedCallback;", "e", "Landroid/window/OnBackInvokedCallback;", "onBackInvokedCallback", "f", "Landroid/window/OnBackInvokedDispatcher;", "invokedDispatcher", "g", "Z", "backInvokedCallbackRegistered", "hasEnabledCallbacks", "LifecycleOnBackPressedCancellable", "activity_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class OnBackPressedDispatcher {
  public final Runnable a;
  
  public final a<Boolean> b;
  
  public final k<E> c;
  
  public E d;
  
  public OnBackInvokedCallback e;
  
  public OnBackInvokedDispatcher f;
  
  public boolean g;
  
  public boolean h;
  
  public OnBackPressedDispatcher() {
    this(null, 1, null);
  }
  
  public OnBackPressedDispatcher(Runnable paramRunnable) {
    this(paramRunnable, null);
  }
  
  public OnBackPressedDispatcher(Runnable paramRunnable, a<Boolean> parama) {
    this.a = paramRunnable;
    this.b = parama;
    this.c = new k();
    int i = Build.VERSION.SDK_INT;
    if (i >= 33) {
      OnBackInvokedCallback onBackInvokedCallback;
      if (i >= 34) {
        onBackInvokedCallback = g.a.a((l)new a(this), (l)new b(this), (a)new c(this), (a)new d(this));
      } else {
        onBackInvokedCallback = f.a.b((a)new e(this));
      } 
      this.e = onBackInvokedCallback;
    } 
  }
  
  public final void h(LifecycleOwner paramLifecycleOwner, E paramE) {
    s.h(paramLifecycleOwner, "owner");
    s.h(paramE, "onBackPressedCallback");
    f f = paramLifecycleOwner.getLifecycle();
    if (f.b() == f.b.DESTROYED)
      return; 
    paramE.d(new LifecycleOnBackPressedCancellable(this, f, paramE));
    q();
    paramE.n(new i(this));
  }
  
  public final void i(E paramE) {
    s.h(paramE, "onBackPressedCallback");
    j(paramE);
  }
  
  public final c j(E paramE) {
    s.h(paramE, "onBackPressedCallback");
    this.c.add(paramE);
    h h = new h(this, paramE);
    paramE.d(h);
    q();
    paramE.n(new j(this));
    return h;
  }
  
  public final void k() {
    // Byte code:
    //   0: aload_0
    //   1: getfield d : Ldbxyzptlk/e/E;
    //   4: astore_2
    //   5: aload_2
    //   6: astore_1
    //   7: aload_2
    //   8: ifnonnull -> 65
    //   11: aload_0
    //   12: getfield c : Ldbxyzptlk/qI/k;
    //   15: astore_1
    //   16: aload_1
    //   17: aload_1
    //   18: invokeinterface size : ()I
    //   23: invokeinterface listIterator : (I)Ljava/util/ListIterator;
    //   28: astore_2
    //   29: aload_2
    //   30: invokeinterface hasPrevious : ()Z
    //   35: ifeq -> 58
    //   38: aload_2
    //   39: invokeinterface previous : ()Ljava/lang/Object;
    //   44: astore_1
    //   45: aload_1
    //   46: checkcast dbxyzptlk/e/E
    //   49: invokevirtual j : ()Z
    //   52: ifeq -> 29
    //   55: goto -> 60
    //   58: aconst_null
    //   59: astore_1
    //   60: aload_1
    //   61: checkcast dbxyzptlk/e/E
    //   64: astore_1
    //   65: aload_0
    //   66: aconst_null
    //   67: putfield d : Ldbxyzptlk/e/E;
    //   70: aload_1
    //   71: ifnull -> 78
    //   74: aload_1
    //   75: invokevirtual f : ()V
    //   78: return
  }
  
  public final void l() {
    // Byte code:
    //   0: aload_0
    //   1: getfield d : Ldbxyzptlk/e/E;
    //   4: astore_2
    //   5: aload_2
    //   6: astore_1
    //   7: aload_2
    //   8: ifnonnull -> 65
    //   11: aload_0
    //   12: getfield c : Ldbxyzptlk/qI/k;
    //   15: astore_1
    //   16: aload_1
    //   17: aload_1
    //   18: invokeinterface size : ()I
    //   23: invokeinterface listIterator : (I)Ljava/util/ListIterator;
    //   28: astore_2
    //   29: aload_2
    //   30: invokeinterface hasPrevious : ()Z
    //   35: ifeq -> 58
    //   38: aload_2
    //   39: invokeinterface previous : ()Ljava/lang/Object;
    //   44: astore_1
    //   45: aload_1
    //   46: checkcast dbxyzptlk/e/E
    //   49: invokevirtual j : ()Z
    //   52: ifeq -> 29
    //   55: goto -> 60
    //   58: aconst_null
    //   59: astore_1
    //   60: aload_1
    //   61: checkcast dbxyzptlk/e/E
    //   64: astore_1
    //   65: aload_0
    //   66: aconst_null
    //   67: putfield d : Ldbxyzptlk/e/E;
    //   70: aload_1
    //   71: ifnull -> 79
    //   74: aload_1
    //   75: invokevirtual g : ()V
    //   78: return
    //   79: aload_0
    //   80: getfield a : Ljava/lang/Runnable;
    //   83: astore_1
    //   84: aload_1
    //   85: ifnull -> 94
    //   88: aload_1
    //   89: invokeinterface run : ()V
    //   94: return
  }
  
  public final void m(b paramb) {
    // Byte code:
    //   0: aload_0
    //   1: getfield d : Ldbxyzptlk/e/E;
    //   4: astore_3
    //   5: aload_3
    //   6: astore_2
    //   7: aload_3
    //   8: ifnonnull -> 65
    //   11: aload_0
    //   12: getfield c : Ldbxyzptlk/qI/k;
    //   15: astore_2
    //   16: aload_2
    //   17: aload_2
    //   18: invokeinterface size : ()I
    //   23: invokeinterface listIterator : (I)Ljava/util/ListIterator;
    //   28: astore_3
    //   29: aload_3
    //   30: invokeinterface hasPrevious : ()Z
    //   35: ifeq -> 58
    //   38: aload_3
    //   39: invokeinterface previous : ()Ljava/lang/Object;
    //   44: astore_2
    //   45: aload_2
    //   46: checkcast dbxyzptlk/e/E
    //   49: invokevirtual j : ()Z
    //   52: ifeq -> 29
    //   55: goto -> 60
    //   58: aconst_null
    //   59: astore_2
    //   60: aload_2
    //   61: checkcast dbxyzptlk/e/E
    //   64: astore_2
    //   65: aload_2
    //   66: ifnull -> 74
    //   69: aload_2
    //   70: aload_1
    //   71: invokevirtual h : (Ldbxyzptlk/e/b;)V
    //   74: return
  }
  
  public final void n(b paramb) {
    // Byte code:
    //   0: aload_0
    //   1: getfield c : Ldbxyzptlk/qI/k;
    //   4: astore_2
    //   5: aload_2
    //   6: aload_2
    //   7: invokeinterface size : ()I
    //   12: invokeinterface listIterator : (I)Ljava/util/ListIterator;
    //   17: astore_3
    //   18: aload_3
    //   19: invokeinterface hasPrevious : ()Z
    //   24: ifeq -> 47
    //   27: aload_3
    //   28: invokeinterface previous : ()Ljava/lang/Object;
    //   33: astore_2
    //   34: aload_2
    //   35: checkcast dbxyzptlk/e/E
    //   38: invokevirtual j : ()Z
    //   41: ifeq -> 18
    //   44: goto -> 49
    //   47: aconst_null
    //   48: astore_2
    //   49: aload_2
    //   50: checkcast dbxyzptlk/e/E
    //   53: astore_2
    //   54: aload_0
    //   55: getfield d : Ldbxyzptlk/e/E;
    //   58: ifnull -> 65
    //   61: aload_0
    //   62: invokevirtual k : ()V
    //   65: aload_0
    //   66: aload_2
    //   67: putfield d : Ldbxyzptlk/e/E;
    //   70: aload_2
    //   71: ifnull -> 79
    //   74: aload_2
    //   75: aload_1
    //   76: invokevirtual i : (Ldbxyzptlk/e/b;)V
    //   79: return
  }
  
  public final void o(OnBackInvokedDispatcher paramOnBackInvokedDispatcher) {
    s.h(paramOnBackInvokedDispatcher, "invoker");
    this.f = paramOnBackInvokedDispatcher;
    p(this.h);
  }
  
  public final void p(boolean paramBoolean) {
    OnBackInvokedDispatcher onBackInvokedDispatcher = this.f;
    OnBackInvokedCallback onBackInvokedCallback = this.e;
    if (onBackInvokedDispatcher != null && onBackInvokedCallback != null)
      if (paramBoolean && !this.g) {
        f.a.d(onBackInvokedDispatcher, 0, onBackInvokedCallback);
        this.g = true;
      } else if (!paramBoolean && this.g) {
        f.a.e(onBackInvokedDispatcher, onBackInvokedCallback);
        this.g = false;
      }  
  }
  
  public final void q() {
    boolean bool1;
    boolean bool3 = this.h;
    k<E> k1 = this.c;
    boolean bool2 = false;
    if (k1 != null && k1.isEmpty()) {
      bool1 = bool2;
    } else {
      Iterator<E> iterator = k1.iterator();
      while (true) {
        bool1 = bool2;
        if (iterator.hasNext()) {
          if (((E)iterator.next()).j()) {
            bool1 = true;
            break;
          } 
          continue;
        } 
        break;
      } 
    } 
    this.h = bool1;
    if (bool1 != bool3) {
      a<Boolean> a1 = this.b;
      if (a1 != null)
        a1.accept(Boolean.valueOf(bool1)); 
      if (Build.VERSION.SDK_INT >= 33)
        p(bool1); 
    } 
  }
  
  @Metadata(d1 = {"\000.\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\f\b\004\030\0002\0020\0012\0020\002B\027\022\006\020\004\032\0020\003\022\006\020\006\032\0020\005¢\006\004\b\007\020\bJ\037\020\016\032\0020\r2\006\020\n\032\0020\t2\006\020\f\032\0020\013H\026¢\006\004\b\016\020\017J\017\020\020\032\0020\rH\026¢\006\004\b\020\020\021R\024\020\004\032\0020\0038\002X\004¢\006\006\n\004\b\022\020\023R\024\020\006\032\0020\0058\002X\004¢\006\006\n\004\b\024\020\025R\030\020\030\032\004\030\0010\0028\002@\002X\016¢\006\006\n\004\b\026\020\027¨\006\031"}, d2 = {"Landroidx/activity/OnBackPressedDispatcher$LifecycleOnBackPressedCancellable;", "Landroidx/lifecycle/LifecycleEventObserver;", "Ldbxyzptlk/e/c;", "Landroidx/lifecycle/f;", "lifecycle", "Ldbxyzptlk/e/E;", "onBackPressedCallback", "<init>", "(Landroidx/activity/OnBackPressedDispatcher;Landroidx/lifecycle/f;Ldbxyzptlk/e/E;)V", "Landroidx/lifecycle/LifecycleOwner;", "source", "Landroidx/lifecycle/f$a;", "event", "Ldbxyzptlk/pI/D;", "f", "(Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/f$a;)V", "cancel", "()V", "a", "Landroidx/lifecycle/f;", "b", "Ldbxyzptlk/e/E;", "c", "Ldbxyzptlk/e/c;", "currentCancellable", "activity_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public final class LifecycleOnBackPressedCancellable implements LifecycleEventObserver, c {
    public final f a;
    
    public final E b;
    
    public c c;
    
    public final OnBackPressedDispatcher d;
    
    public LifecycleOnBackPressedCancellable(OnBackPressedDispatcher this$0, f param1f, E param1E) {
      this.a = param1f;
      this.b = param1E;
      param1f.a((dbxyzptlk.U2.h)this);
    }
    
    public void cancel() {
      this.a.d((dbxyzptlk.U2.h)this);
      this.b.l(this);
      c c1 = this.c;
      if (c1 != null)
        c1.cancel(); 
      this.c = null;
    }
    
    public void f(LifecycleOwner param1LifecycleOwner, f.a param1a) {
      s.h(param1LifecycleOwner, "source");
      s.h(param1a, "event");
      if (param1a == f.a.ON_START) {
        this.c = this.d.j(this.b);
      } else if (param1a == f.a.ON_STOP) {
        c c1 = this.c;
        if (c1 != null)
          c1.cancel(); 
      } else if (param1a == f.a.ON_DESTROY) {
        cancel();
      } 
    }
  }
  
  class OnBackPressedDispatcher {}
  
  class OnBackPressedDispatcher {}
  
  @Metadata(d1 = {"\000\030\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\005\b\004\030\0002\0020\001B\017\022\006\020\003\032\0020\002¢\006\004\b\004\020\005J\017\020\007\032\0020\006H\026¢\006\004\b\007\020\bR\024\020\003\032\0020\0028\002X\004¢\006\006\n\004\b\t\020\n¨\006\013"}, d2 = {"Landroidx/activity/OnBackPressedDispatcher$h;", "Ldbxyzptlk/e/c;", "Ldbxyzptlk/e/E;", "onBackPressedCallback", "<init>", "(Landroidx/activity/OnBackPressedDispatcher;Ldbxyzptlk/e/E;)V", "Ldbxyzptlk/pI/D;", "cancel", "()V", "a", "Ldbxyzptlk/e/E;", "activity_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public final class h implements c {
    public final E a;
    
    public final OnBackPressedDispatcher b;
    
    public h(OnBackPressedDispatcher this$0, E param1E) {
      this.a = param1E;
    }
    
    public void cancel() {
      OnBackPressedDispatcher.b(this.b).remove(this.a);
      if (s.c(OnBackPressedDispatcher.a(this.b), this.a)) {
        this.a.f();
        OnBackPressedDispatcher.f(this.b, null);
      } 
      this.a.l(this);
      a a = this.a.e();
      if (a != null)
        a.invoke(); 
      this.a.n(null);
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\activity\OnBackPressedDispatcher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */