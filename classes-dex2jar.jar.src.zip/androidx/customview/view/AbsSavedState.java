package androidx.customview.view;

import android.annotation.SuppressLint;
import android.os.Parcel;
import android.os.Parcelable;

@SuppressLint({"BanParcelableUsage"})
public abstract class AbsSavedState implements Parcelable {
  public static final Parcelable.Creator<AbsSavedState> CREATOR;
  
  public static final AbsSavedState EMPTY_STATE = new a();
  
  private final Parcelable mSuperState;
  
  static {
    CREATOR = (Parcelable.Creator<AbsSavedState>)new b();
  }
  
  private AbsSavedState() {
    this.mSuperState = null;
  }
  
  public AbsSavedState(Parcel paramParcel) {
    this(paramParcel, null);
  }
  
  public AbsSavedState(Parcel paramParcel, ClassLoader paramClassLoader) {
    Parcelable parcelable = paramParcel.readParcelable(paramClassLoader);
    if (parcelable == null)
      parcelable = EMPTY_STATE; 
    this.mSuperState = parcelable;
  }
  
  public AbsSavedState(Parcelable paramParcelable) {
    if (paramParcelable != null) {
      if (paramParcelable == EMPTY_STATE)
        paramParcelable = null; 
      this.mSuperState = paramParcelable;
      return;
    } 
    throw new IllegalArgumentException("superState must not be null");
  }
  
  public int describeContents() {
    return 0;
  }
  
  public final Parcelable getSuperState() {
    return this.mSuperState;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    paramParcel.writeParcelable(this.mSuperState, paramInt);
  }
  
  public class a extends AbsSavedState {
    public a() {
      super((a)null);
    }
  }
  
  public class b implements Parcelable.ClassLoaderCreator<AbsSavedState> {
    public AbsSavedState a(Parcel param1Parcel) {
      return b(param1Parcel, null);
    }
    
    public AbsSavedState b(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      if (param1Parcel.readParcelable(param1ClassLoader) == null)
        return AbsSavedState.EMPTY_STATE; 
      throw new IllegalStateException("superState must be null");
    }
    
    public AbsSavedState[] c(int param1Int) {
      return new AbsSavedState[param1Int];
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\customview\view\AbsSavedState.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */