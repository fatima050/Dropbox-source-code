package androidx.savedstate;

import android.annotation.SuppressLint;
import android.os.Bundle;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.f;
import dbxyzptlk.DI.s;
import dbxyzptlk.U2.h;
import java.util.Map;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

@Metadata(d1 = {"\000T\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\016\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\006\n\002\030\002\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\b\n\002\030\002\n\002\b\003\n\002\020\013\n\002\b\b\n\002\030\002\n\002\b\b\b\007\030\000 \0342\0020\001:\003!\007\016B\t\b\000¢\006\004\b\002\020\003J\031\020\007\032\004\030\0010\0062\006\020\005\032\0020\004H\007¢\006\004\b\007\020\bJ\037\020\f\032\0020\0132\006\020\005\032\0020\0042\006\020\n\032\0020\tH\007¢\006\004\b\f\020\rJ\027\020\016\032\004\030\0010\t2\006\020\005\032\0020\004¢\006\004\b\016\020\017J\027\020\020\032\0020\0132\006\020\005\032\0020\004H\007¢\006\004\b\020\020\021J\037\020\025\032\0020\0132\016\020\024\032\n\022\006\b\001\022\0020\0230\022H\007¢\006\004\b\025\020\026J\027\020\031\032\0020\0132\006\020\030\032\0020\027H\001¢\006\004\b\031\020\032J\031\020\034\032\0020\0132\b\020\033\032\004\030\0010\006H\001¢\006\004\b\034\020\035J\027\020\037\032\0020\0132\006\020\036\032\0020\006H\007¢\006\004\b\037\020\035R \020#\032\016\022\004\022\0020\004\022\004\022\0020\t0 8\002X\004¢\006\006\n\004\b!\020\"R\026\020&\032\0020$8\002@\002X\016¢\006\006\n\004\b\007\020%R\030\020(\032\004\030\0010\0068\002@\002X\016¢\006\006\n\004\b\016\020'R$\020,\032\0020$2\006\020)\032\0020$8G@BX\016¢\006\f\n\004\b*\020%\032\004\b*\020+R\030\0200\032\004\030\0010-8\002@\002X\016¢\006\006\n\004\b.\020/R\"\0204\032\0020$8\000@\000X\016¢\006\022\n\004\b\031\020%\032\004\b1\020+\"\004\b2\0203¨\0065"}, d2 = {"Landroidx/savedstate/a;", "", "<init>", "()V", "", "key", "Landroid/os/Bundle;", "b", "(Ljava/lang/String;)Landroid/os/Bundle;", "Landroidx/savedstate/a$c;", "provider", "Ldbxyzptlk/pI/D;", "i", "(Ljava/lang/String;Landroidx/savedstate/a$c;)V", "c", "(Ljava/lang/String;)Landroidx/savedstate/a$c;", "k", "(Ljava/lang/String;)V", "Ljava/lang/Class;", "Landroidx/savedstate/a$a;", "clazz", "j", "(Ljava/lang/Class;)V", "Landroidx/lifecycle/f;", "lifecycle", "f", "(Landroidx/lifecycle/f;)V", "savedState", "g", "(Landroid/os/Bundle;)V", "outBundle", "h", "Ldbxyzptlk/t/b;", "a", "Ldbxyzptlk/t/b;", "components", "", "Z", "attached", "Landroid/os/Bundle;", "restoredState", "<set-?>", "d", "()Z", "isRestored", "Landroidx/savedstate/Recreator$b;", "e", "Landroidx/savedstate/Recreator$b;", "recreatorProvider", "isAllowingSavingState$savedstate_release", "setAllowingSavingState$savedstate_release", "(Z)V", "isAllowingSavingState", "savedstate_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
@SuppressLint({"RestrictedApi"})
public final class a {
  public static final b g = new b(null);
  
  public final dbxyzptlk.t.b<String, c> a = new dbxyzptlk.t.b();
  
  public boolean b;
  
  public Bundle c;
  
  public boolean d;
  
  public Recreator.b e;
  
  public boolean f = true;
  
  public static final void e(a parama, LifecycleOwner paramLifecycleOwner, f.a parama1) {
    s.h(parama, "this$0");
    s.h(paramLifecycleOwner, "<anonymous parameter 0>");
    s.h(parama1, "event");
    if (parama1 == f.a.ON_START) {
      parama.f = true;
    } else if (parama1 == f.a.ON_STOP) {
      parama.f = false;
    } 
  }
  
  public final Bundle b(String paramString) {
    s.h(paramString, "key");
    if (this.d) {
      Bundle bundle = this.c;
      if (bundle != null) {
        if (bundle != null) {
          bundle = bundle.getBundle(paramString);
        } else {
          bundle = null;
        } 
        Bundle bundle2 = this.c;
        if (bundle2 != null)
          bundle2.remove(paramString); 
        Bundle bundle1 = this.c;
        if (bundle1 == null || bundle1.isEmpty())
          this.c = null; 
        return bundle;
      } 
      return null;
    } 
    throw new IllegalStateException("You can consumeRestoredStateForKey only after super.onCreate of corresponding component");
  }
  
  public final c c(String paramString) {
    // Byte code:
    //   0: aload_1
    //   1: ldc 'key'
    //   3: invokestatic h : (Ljava/lang/Object;Ljava/lang/String;)V
    //   6: aload_0
    //   7: getfield a : Ldbxyzptlk/t/b;
    //   10: invokevirtual iterator : ()Ljava/util/Iterator;
    //   13: astore #4
    //   15: aload #4
    //   17: invokeinterface hasNext : ()Z
    //   22: ifeq -> 75
    //   25: aload #4
    //   27: invokeinterface next : ()Ljava/lang/Object;
    //   32: checkcast java/util/Map$Entry
    //   35: astore_2
    //   36: aload_2
    //   37: ldc 'components'
    //   39: invokestatic g : (Ljava/lang/Object;Ljava/lang/String;)V
    //   42: aload_2
    //   43: invokeinterface getKey : ()Ljava/lang/Object;
    //   48: checkcast java/lang/String
    //   51: astore_3
    //   52: aload_2
    //   53: invokeinterface getValue : ()Ljava/lang/Object;
    //   58: checkcast androidx/savedstate/a$c
    //   61: astore_2
    //   62: aload_3
    //   63: aload_1
    //   64: invokestatic c : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   67: ifeq -> 15
    //   70: aload_2
    //   71: astore_1
    //   72: goto -> 77
    //   75: aconst_null
    //   76: astore_1
    //   77: aload_1
    //   78: areturn
  }
  
  public final boolean d() {
    return this.d;
  }
  
  public final void f(f paramf) {
    s.h(paramf, "lifecycle");
    if (!this.b) {
      paramf.a((h)new dbxyzptlk.J4.b(this));
      this.b = true;
      return;
    } 
    throw new IllegalStateException("SavedStateRegistry was already attached.");
  }
  
  public final void g(Bundle paramBundle) {
    if (this.b) {
      if (!this.d) {
        if (paramBundle != null) {
          paramBundle = paramBundle.getBundle("androidx.lifecycle.BundlableSavedStateRegistry.key");
        } else {
          paramBundle = null;
        } 
        this.c = paramBundle;
        this.d = true;
        return;
      } 
      throw new IllegalStateException("SavedStateRegistry was already restored.");
    } 
    throw new IllegalStateException("You must call performAttach() before calling performRestore(Bundle).");
  }
  
  public final void h(Bundle paramBundle) {
    s.h(paramBundle, "outBundle");
    Bundle bundle1 = new Bundle();
    Bundle bundle2 = this.c;
    if (bundle2 != null)
      bundle1.putAll(bundle2); 
    dbxyzptlk.t.b.d<Map.Entry> d = this.a.j();
    s.g(d, "this.components.iteratorWithAdditions()");
    while (d.hasNext()) {
      Map.Entry entry = d.next();
      bundle1.putBundle((String)entry.getKey(), ((c)entry.getValue()).e());
    } 
    if (!bundle1.isEmpty())
      paramBundle.putBundle("androidx.lifecycle.BundlableSavedStateRegistry.key", bundle1); 
  }
  
  public final void i(String paramString, c paramc) {
    s.h(paramString, "key");
    s.h(paramc, "provider");
    if ((c)this.a.m(paramString, paramc) == null)
      return; 
    throw new IllegalArgumentException("SavedStateProvider with the given key is already registered");
  }
  
  public final void j(Class<? extends a> paramClass) {
    s.h(paramClass, "clazz");
    if (this.f) {
      String str;
      Recreator.b b2 = this.e;
      Recreator.b b1 = b2;
      if (b2 == null)
        b1 = new Recreator.b(this); 
      this.e = b1;
      try {
        paramClass.getDeclaredConstructor(null);
        b1 = this.e;
        if (b1 != null) {
          str = paramClass.getName();
          s.g(str, "clazz.name");
          b1.a(str);
        } 
        return;
      } catch (NoSuchMethodException noSuchMethodException) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Class ");
        stringBuilder.append(str.getSimpleName());
        stringBuilder.append(" must have default constructor in order to be automatically recreated");
        throw new IllegalArgumentException(stringBuilder.toString(), noSuchMethodException);
      } 
    } 
    throw new IllegalStateException("Can not perform this action after onSaveInstanceState");
  }
  
  public final void k(String paramString) {
    s.h(paramString, "key");
    this.a.p(paramString);
  }
  
  class a {}
  
  @Metadata(d1 = {"\000\024\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\016\n\002\b\003\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003R\024\020\005\032\0020\0048\002XT¢\006\006\n\004\b\005\020\006¨\006\007"}, d2 = {"Landroidx/savedstate/a$b;", "", "<init>", "()V", "", "SAVED_COMPONENTS_KEY", "Ljava/lang/String;", "savedstate_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class b {
    public b() {}
  }
  
  @Metadata(d1 = {"\000\020\n\002\030\002\n\002\020\000\n\002\030\002\n\002\b\003\bæ\001\030\0002\0020\001J\017\020\003\032\0020\002H&¢\006\004\b\003\020\004ø\001\000\002\006\n\004\b!0\001¨\006\005À\006\001"}, d2 = {"Landroidx/savedstate/a$c;", "", "Landroid/os/Bundle;", "e", "()Landroid/os/Bundle;", "savedstate_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static interface c {
    Bundle e();
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\savedstate\a.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */