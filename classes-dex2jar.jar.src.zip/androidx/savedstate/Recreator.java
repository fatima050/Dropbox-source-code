package androidx.savedstate;

import android.os.Bundle;
import androidx.lifecycle.LifecycleEventObserver;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.f;
import dbxyzptlk.DI.s;
import dbxyzptlk.J4.d;
import dbxyzptlk.U2.h;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.Iterator;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

@Metadata(d1 = {"\000,\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\003\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\020\016\n\002\b\006\b\000\030\000 \0222\0020\001:\002\017\022B\017\022\006\020\003\032\0020\002¢\006\004\b\004\020\005J\037\020\013\032\0020\n2\006\020\007\032\0020\0062\006\020\t\032\0020\bH\026¢\006\004\b\013\020\fJ\027\020\017\032\0020\n2\006\020\016\032\0020\rH\002¢\006\004\b\017\020\020R\024\020\003\032\0020\0028\002X\004¢\006\006\n\004\b\017\020\021¨\006\023"}, d2 = {"Landroidx/savedstate/Recreator;", "Landroidx/lifecycle/LifecycleEventObserver;", "Ldbxyzptlk/J4/d;", "owner", "<init>", "(Ldbxyzptlk/J4/d;)V", "Landroidx/lifecycle/LifecycleOwner;", "source", "Landroidx/lifecycle/f$a;", "event", "Ldbxyzptlk/pI/D;", "f", "(Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/f$a;)V", "", "className", "a", "(Ljava/lang/String;)V", "Ldbxyzptlk/J4/d;", "b", "savedstate_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class Recreator implements LifecycleEventObserver {
  public static final a b = new a(null);
  
  public final d a;
  
  public Recreator(d paramd) {
    this.a = paramd;
  }
  
  public final void a(String paramString) {
    try {
      Class<? extends a.a> clazz = Class.forName(paramString, false, Recreator.class.getClassLoader()).asSubclass(a.a.class);
      s.g(clazz, "{\n                Class.…class.java)\n            }");
      try {
        Constructor<? extends a.a> constructor = clazz.getDeclaredConstructor(null);
        constructor.setAccessible(true);
        try {
          clazz = (Class<? extends a.a>)constructor.newInstance(null);
          s.g(clazz, "{\n                constr…wInstance()\n            }");
          a.a a1 = (a.a)clazz;
          a1.a(this.a);
          return;
        } catch (Exception exception) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Failed to instantiate ");
          stringBuilder.append(paramString);
          throw new RuntimeException(stringBuilder.toString(), exception);
        } 
      } catch (NoSuchMethodException noSuchMethodException) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Class ");
        stringBuilder.append(exception.getSimpleName());
        stringBuilder.append(" must have default constructor in order to be automatically recreated");
        throw new IllegalStateException(stringBuilder.toString(), noSuchMethodException);
      } 
    } catch (ClassNotFoundException classNotFoundException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Class ");
      stringBuilder.append((String)noSuchMethodException);
      stringBuilder.append(" wasn't found");
      throw new RuntimeException(stringBuilder.toString(), classNotFoundException);
    } 
  }
  
  public void f(LifecycleOwner paramLifecycleOwner, f.a parama) {
    s.h(paramLifecycleOwner, "source");
    s.h(parama, "event");
    if (parama == f.a.ON_CREATE) {
      paramLifecycleOwner.getLifecycle().d((h)this);
      Bundle bundle = this.a.getSavedStateRegistry().b("androidx.savedstate.Restarter");
      if (bundle == null)
        return; 
      ArrayList arrayList = bundle.getStringArrayList("classes_to_restore");
      if (arrayList != null) {
        Iterator<String> iterator = arrayList.iterator();
        while (iterator.hasNext())
          a(iterator.next()); 
        return;
      } 
      throw new IllegalStateException("Bundle with restored state for the component \"androidx.savedstate.Restarter\" must contain list of strings by the key \"classes_to_restore\"");
    } 
    throw new AssertionError("Next event must be ON_CREATE");
  }
  
  @Metadata(d1 = {"\000\024\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\016\n\002\b\004\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003R\024\020\005\032\0020\0048\006XT¢\006\006\n\004\b\005\020\006R\024\020\007\032\0020\0048\006XT¢\006\006\n\004\b\007\020\006¨\006\b"}, d2 = {"Landroidx/savedstate/Recreator$a;", "", "<init>", "()V", "", "CLASSES_KEY", "Ljava/lang/String;", "COMPONENT_KEY", "savedstate_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class a {
    public a() {}
  }
  
  class Recreator {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\savedstate\Recreator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */