package androidx.compose.ui;

import dbxyzptlk.CI.l;
import dbxyzptlk.CI.q;
import dbxyzptlk.g1.r0;
import dbxyzptlk.g1.s0;
import dbxyzptlk.pI.D;
import dbxyzptlk.x0.k;
import kotlin.Metadata;

@Metadata(d1 = {"\000\"\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\b\b\022\030\0002\0020\0012\0020\002B/\022\022\020\006\032\016\022\004\022\0020\004\022\004\022\0020\0050\003\022\022\020\b\032\016\022\004\022\0020\007\022\004\022\0020\0070\003¢\006\004\b\t\020\nR#\020\b\032\016\022\004\022\0020\007\022\004\022\0020\0070\0038\006¢\006\f\n\004\b\013\020\f\032\004\b\r\020\016¨\006\017"}, d2 = {"Landroidx/compose/ui/b;", "Landroidx/compose/ui/d$b;", "Ldbxyzptlk/g1/s0;", "Lkotlin/Function1;", "Ldbxyzptlk/g1/r0;", "Ldbxyzptlk/pI/D;", "inspectorInfo", "Landroidx/compose/ui/d;", "factory", "<init>", "(Ldbxyzptlk/CI/l;Ldbxyzptlk/CI/q;)V", "c", "Ldbxyzptlk/CI/q;", "b", "()Ldbxyzptlk/CI/q;", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public class b extends s0 implements d.b {
  public final q<d, k, Integer, d> c;
  
  public b(l<? super r0, D> paraml, q<? super d, ? super k, ? super Integer, ? extends d> paramq) {
    super(paraml);
    this.c = (q)paramq;
  }
  
  public final q<d, k, Integer, d> b() {
    return this.c;
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compos\\ui\b.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */