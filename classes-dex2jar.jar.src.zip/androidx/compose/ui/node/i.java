package androidx.compose.ui.node;

import dbxyzptlk.CI.l;
import dbxyzptlk.DI.s;
import dbxyzptlk.d1.H;
import dbxyzptlk.d1.I;
import dbxyzptlk.d1.Y;
import dbxyzptlk.d1.Z;
import dbxyzptlk.f1.b;
import dbxyzptlk.pI.D;
import dbxyzptlk.z1.n;
import java.util.Map;
import kotlin.Metadata;

@Metadata(d1 = {"\000T\n\002\030\002\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\000\n\002\020\b\n\002\b\003\n\002\030\002\n\000\n\002\030\002\n\002\b\004\n\002\020$\n\000\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\020\013\n\002\b\020\n\002\030\002\n\002\b\017\b \030\0002\0020\0012\0020\002B\007¢\006\004\b\003\020\004J\030\020\b\032\0020\0072\006\020\006\032\0020\005H\002¢\006\004\b\b\020\tJ\027\020\n\032\0020\0072\006\020\006\032\0020\005H&¢\006\004\b\n\020\tJ\017\020\f\032\0020\013H ¢\006\004\b\f\020\004J\023\020\016\032\0020\013*\0020\rH\004¢\006\004\b\016\020\017JG\020\030\032\0020\0272\006\020\020\032\0020\0072\006\020\021\032\0020\0072\022\020\023\032\016\022\004\022\0020\005\022\004\022\0020\0070\0222\022\020\026\032\016\022\004\022\0020\025\022\004\022\0020\0130\024H\026¢\006\004\b\030\020\031R\"\020!\032\0020\0328\000@\000X\016¢\006\022\n\004\b\033\020\034\032\004\b\035\020\036\"\004\b\037\020 R\"\020%\032\0020\0328\000@\000X\016¢\006\022\n\004\b\"\020\034\032\004\b#\020\036\"\004\b$\020 R\027\020*\032\0020\0258\006¢\006\f\n\004\b&\020'\032\004\b(\020)R\032\020.\032\0020+8&X¦\004ø\001\000ø\001\001¢\006\006\032\004\b,\020-R\026\0201\032\004\030\0010\0008&X¦\004¢\006\006\032\004\b/\0200R\024\0203\032\0020\0328&X¦\004¢\006\006\032\004\b2\020\036R\024\0206\032\0020\0278 X \004¢\006\006\032\004\b4\0205R\032\0209\032\0020\0328VX\004¢\006\f\022\004\b8\020\004\032\004\b7\020\036\002\013\n\005\b¡\0360\001\n\002\b!¨\006:"}, d2 = {"Landroidx/compose/ui/node/i;", "Ldbxyzptlk/d1/Y;", "", "<init>", "()V", "Ldbxyzptlk/d1/a;", "alignmentLine", "", "E", "(Ldbxyzptlk/d1/a;)I", "e1", "Ldbxyzptlk/pI/D;", "u1", "Landroidx/compose/ui/node/n;", "l1", "(Landroidx/compose/ui/node/n;)V", "width", "height", "", "alignmentLines", "Lkotlin/Function1;", "Ldbxyzptlk/d1/Y$a;", "placementBlock", "Ldbxyzptlk/d1/H;", "Y0", "(IILjava/util/Map;Ldbxyzptlk/CI/l;)Ldbxyzptlk/d1/H;", "", "f", "Z", "t1", "()Z", "B1", "(Z)V", "isShallowPlacing", "g", "n1", "w1", "isPlacingForAlignment", "h", "Ldbxyzptlk/d1/Y$a;", "j1", "()Ldbxyzptlk/d1/Y$a;", "placementScope", "Ldbxyzptlk/z1/n;", "k1", "()J", "position", "f1", "()Landroidx/compose/ui/node/i;", "child", "g1", "hasMeasureResult", "h1", "()Ldbxyzptlk/d1/H;", "measureResult", "O0", "isLookingAhead$annotations", "isLookingAhead", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public abstract class i extends Y implements I {
  public boolean f;
  
  public boolean g;
  
  public final Y.a h = Z.a(this);
  
  public final void B1(boolean paramBoolean) {
    this.f = paramBoolean;
  }
  
  public final int E(dbxyzptlk.d1.a parama) {
    if (!g1())
      return Integer.MIN_VALUE; 
    int j = e1(parama);
    return (j == Integer.MIN_VALUE) ? Integer.MIN_VALUE : (j + n.k(y0()));
  }
  
  public boolean O0() {
    return false;
  }
  
  public H Y0(int paramInt1, int paramInt2, Map<dbxyzptlk.d1.a, Integer> paramMap, l<? super Y.a, D> paraml) {
    if ((paramInt1 & 0xFF000000) == 0 && (0xFF000000 & paramInt2) == 0)
      return new a(paramInt1, paramInt2, paramMap, paraml, this); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Size(");
    stringBuilder.append(paramInt1);
    stringBuilder.append(" x ");
    stringBuilder.append(paramInt2);
    stringBuilder.append(") is out of range. Each dimension must be between 0 and 16777215.");
    throw new IllegalStateException(stringBuilder.toString().toString());
  }
  
  public abstract int e1(dbxyzptlk.d1.a parama);
  
  public abstract i f1();
  
  public abstract boolean g1();
  
  public abstract H h1();
  
  public final Y.a j1() {
    return this.h;
  }
  
  public abstract long k1();
  
  public final void l1(n paramn) {
    n n1 = paramn.p2();
    if (n1 != null) {
      f f = n1.j2();
    } else {
      n1 = null;
    } 
    if (!s.c(n1, paramn.j2())) {
      paramn.e2().d().m();
    } else {
      b b = paramn.e2().F();
      if (b != null) {
        dbxyzptlk.f1.a a1 = b.d();
        if (a1 != null)
          a1.m(); 
      } 
    } 
  }
  
  public final boolean n1() {
    return this.g;
  }
  
  public final boolean t1() {
    return this.f;
  }
  
  public abstract void u1();
  
  public final void w1(boolean paramBoolean) {
    this.g = paramBoolean;
  }
  
  @Metadata(d1 = {"\000%\n\000\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\b\n\002\b\005\n\002\020$\n\002\030\002\n\002\b\004*\001\000\b\n\030\0002\0020\001J\017\020\003\032\0020\002H\026¢\006\004\b\003\020\004R\024\020\b\032\0020\0058VX\004¢\006\006\032\004\b\006\020\007R\024\020\n\032\0020\0058VX\004¢\006\006\032\004\b\t\020\007R \020\017\032\016\022\004\022\0020\f\022\004\022\0020\0050\0138VX\004¢\006\006\032\004\b\r\020\016¨\006\020"}, d2 = {"androidx/compose/ui/node/i$a", "Ldbxyzptlk/d1/H;", "Ldbxyzptlk/pI/D;", "f", "()V", "", "getWidth", "()I", "width", "getHeight", "height", "", "Ldbxyzptlk/d1/a;", "d", "()Ljava/util/Map;", "alignmentLines", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class a implements H {
    public final int a;
    
    public final int b;
    
    public final Map<dbxyzptlk.d1.a, Integer> c;
    
    public final l<Y.a, D> d;
    
    public final i e;
    
    public a(int param1Int1, int param1Int2, Map<dbxyzptlk.d1.a, Integer> param1Map, l<? super Y.a, D> param1l, i param1i) {}
    
    public Map<dbxyzptlk.d1.a, Integer> d() {
      return this.c;
    }
    
    public void f() {
      this.d.invoke(this.e.j1());
    }
    
    public int getHeight() {
      return this.b;
    }
    
    public int getWidth() {
      return this.a;
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compos\\ui\node\i.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */