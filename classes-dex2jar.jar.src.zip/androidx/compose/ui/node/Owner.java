package androidx.compose.ui.node;

import dbxyzptlk.CI.l;
import dbxyzptlk.L0.d;
import dbxyzptlk.L0.i;
import dbxyzptlk.M0.c;
import dbxyzptlk.O0.j;
import dbxyzptlk.Q0.j0;
import dbxyzptlk.a1.x;
import dbxyzptlk.d1.Y;
import dbxyzptlk.d1.Z;
import dbxyzptlk.e1.f;
import dbxyzptlk.f1.B;
import dbxyzptlk.f1.S;
import dbxyzptlk.f1.U;
import dbxyzptlk.g1.B1;
import dbxyzptlk.g1.K1;
import dbxyzptlk.g1.T1;
import dbxyzptlk.g1.b0;
import dbxyzptlk.g1.z1;
import dbxyzptlk.pI.D;
import dbxyzptlk.s1.k;
import dbxyzptlk.s1.l;
import dbxyzptlk.t1.S;
import dbxyzptlk.tI.g;
import dbxyzptlk.z1.d;
import dbxyzptlk.z1.t;
import kotlin.Metadata;

@Metadata(d1 = {"\000\002\n\002\030\002\n\002\020\000\n\002\030\002\n\000\n\002\020\013\n\002\b\003\n\002\030\002\n\002\b\t\n\002\030\002\n\002\b\n\n\002\030\002\n\002\b\005\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\t\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\007\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\006\b`\030\000 \0012\0020\001:\003\033\001J5\020\t\032\0020\b2\006\020\003\032\0020\0022\b\b\002\020\005\032\0020\0042\b\b\002\020\006\032\0020\0042\b\b\002\020\007\032\0020\004H&¢\006\004\b\t\020\nJ+\020\013\032\0020\b2\006\020\003\032\0020\0022\b\b\002\020\005\032\0020\0042\b\b\002\020\006\032\0020\004H&¢\006\004\b\013\020\fJ\027\020\r\032\0020\b2\006\020\003\032\0020\002H&¢\006\004\b\r\020\016J\027\020\020\032\0020\b2\006\020\017\032\0020\002H&¢\006\004\b\020\020\016J\027\020\021\032\0020\b2\006\020\017\032\0020\002H&¢\006\004\b\021\020\016J\032\020\024\032\0020\0222\006\020\023\032\0020\022H&ø\001\000¢\006\004\b\024\020\025J\032\020\027\032\0020\0222\006\020\026\032\0020\022H&ø\001\000¢\006\004\b\027\020\025J\017\020\030\032\0020\004H&¢\006\004\b\030\020\031J\031\020\033\032\0020\b2\b\b\002\020\032\032\0020\004H&¢\006\004\b\033\020\034J\"\020\037\032\0020\b2\006\020\003\032\0020\0022\006\020\036\032\0020\035H&ø\001\000¢\006\004\b\037\020 J!\020!\032\0020\b2\006\020\003\032\0020\0022\b\b\002\020\005\032\0020\004H&¢\006\004\b!\020\"J1\020)\032\0020(2\022\020%\032\016\022\004\022\0020$\022\004\022\0020\b0#2\f\020'\032\b\022\004\022\0020\b0&H&¢\006\004\b)\020*J\017\020+\032\0020\bH&¢\006\004\b+\020,J\027\020-\032\0020\b2\006\020\003\032\0020\002H&¢\006\004\b-\020\016J\035\020/\032\0020\b2\f\020.\032\b\022\004\022\0020\b0&H&¢\006\004\b/\0200J\017\0201\032\0020\bH&¢\006\004\b1\020,J\027\0203\032\0020\b2\006\020.\032\00202H&¢\006\004\b3\0204R\024\0207\032\0020\0028&X¦\004¢\006\006\032\004\b5\0206R\024\020;\032\002088&X¦\004¢\006\006\032\004\b9\020:R\024\020?\032\0020<8&X¦\004¢\006\006\032\004\b=\020>R\024\020C\032\0020@8&X¦\004¢\006\006\032\004\bA\020BR\024\020G\032\0020D8&X¦\004¢\006\006\032\004\bE\020FR\024\020K\032\0020H8&X¦\004¢\006\006\032\004\bI\020JR\024\020O\032\0020L8&X¦\004¢\006\006\032\004\bM\020NR\032\020T\032\0020P8gX§\004¢\006\f\022\004\bS\020,\032\004\bQ\020RR\034\020Y\032\004\030\0010U8gX§\004¢\006\f\022\004\bX\020,\032\004\bV\020WR\024\020]\032\0020Z8&X¦\004¢\006\006\032\004\b[\020\\R\024\020a\032\0020^8&X¦\004¢\006\006\032\004\b_\020`R\024\020e\032\0020b8&X¦\004¢\006\006\032\004\bc\020dR\024\020i\032\0020f8&X¦\004¢\006\006\032\004\bg\020hR\024\020m\032\0020j8&X¦\004¢\006\006\032\004\bk\020lR\024\020q\032\0020n8&X¦\004¢\006\006\032\004\bo\020pR\032\020v\032\0020r8&X§\004¢\006\f\022\004\bu\020,\032\004\bs\020tR\024\020z\032\0020w8&X¦\004¢\006\006\032\004\bx\020yR\024\020~\032\0020{8&X¦\004¢\006\006\032\004\b|\020}R'\020\001\032\0020\0042\006\020\032\0020\0048&@gX¦\016¢\006\016\032\005\b\001\020\031\"\005\b\001\020\034R\030\020\001\032\0030\0018&X¦\004¢\006\b\032\006\b\001\020\001R\030\020\001\032\0030\0018&X¦\004¢\006\b\032\006\b\001\020\001R\030\020\001\032\0030\0018&X¦\004¢\006\b\032\006\b\001\020\001R\030\020\001\032\0030\0018&X¦\004¢\006\b\032\006\b\001\020\001R\030\020\001\032\0030\0018VX\004¢\006\b\032\006\b\001\020\001R\030\020\001\032\0030\0018&X¦\004¢\006\b\032\006\b\001\020\001ø\001\001\002\r\n\005\b¡\0360\001\n\004\b!0\001¨\006\001À\006\001"}, d2 = {"Landroidx/compose/ui/node/Owner;", "", "Landroidx/compose/ui/node/f;", "layoutNode", "", "affectsLookahead", "forceRequest", "scheduleMeasureAndLayout", "Ldbxyzptlk/pI/D;", "o", "(Landroidx/compose/ui/node/f;ZZZ)V", "q", "(Landroidx/compose/ui/node/f;ZZ)V", "c", "(Landroidx/compose/ui/node/f;)V", "node", "w", "z", "Ldbxyzptlk/P0/f;", "localPosition", "t", "(J)J", "positionInWindow", "m", "requestFocus", "()Z", "sendPointerUpdate", "a", "(Z)V", "Ldbxyzptlk/z1/b;", "constraints", "k", "(Landroidx/compose/ui/node/f;J)V", "v", "(Landroidx/compose/ui/node/f;Z)V", "Lkotlin/Function1;", "Ldbxyzptlk/Q0/j0;", "drawBlock", "Lkotlin/Function0;", "invalidateParentLayer", "Ldbxyzptlk/f1/S;", "i", "(Ldbxyzptlk/CI/l;Ldbxyzptlk/CI/a;)Ldbxyzptlk/f1/S;", "B", "()V", "u", "listener", "h", "(Ldbxyzptlk/CI/a;)V", "p", "Landroidx/compose/ui/node/Owner$b;", "g", "(Landroidx/compose/ui/node/Owner$b;)V", "getRoot", "()Landroidx/compose/ui/node/f;", "root", "Ldbxyzptlk/f1/B;", "getSharedDrawScope", "()Ldbxyzptlk/f1/B;", "sharedDrawScope", "Ldbxyzptlk/W0/a;", "getHapticFeedBack", "()Ldbxyzptlk/W0/a;", "hapticFeedBack", "Ldbxyzptlk/X0/b;", "getInputModeManager", "()Ldbxyzptlk/X0/b;", "inputModeManager", "Ldbxyzptlk/g1/b0;", "getClipboardManager", "()Ldbxyzptlk/g1/b0;", "clipboardManager", "Ldbxyzptlk/g1/b;", "getAccessibilityManager", "()Ldbxyzptlk/g1/b;", "accessibilityManager", "Ldbxyzptlk/g1/B1;", "getTextToolbar", "()Ldbxyzptlk/g1/B1;", "textToolbar", "Ldbxyzptlk/L0/i;", "getAutofillTree", "()Ldbxyzptlk/L0/i;", "getAutofillTree$annotations", "autofillTree", "Ldbxyzptlk/L0/d;", "getAutofill", "()Ldbxyzptlk/L0/d;", "getAutofill$annotations", "autofill", "Ldbxyzptlk/z1/d;", "getDensity", "()Ldbxyzptlk/z1/d;", "density", "Ldbxyzptlk/t1/S;", "getTextInputService", "()Ldbxyzptlk/t1/S;", "textInputService", "Ldbxyzptlk/g1/z1;", "getSoftwareKeyboardController", "()Ldbxyzptlk/g1/z1;", "softwareKeyboardController", "Ldbxyzptlk/a1/x;", "getPointerIconService", "()Ldbxyzptlk/a1/x;", "pointerIconService", "Ldbxyzptlk/O0/j;", "getFocusOwner", "()Ldbxyzptlk/O0/j;", "focusOwner", "Ldbxyzptlk/g1/T1;", "getWindowInfo", "()Ldbxyzptlk/g1/T1;", "windowInfo", "Ldbxyzptlk/s1/k$b;", "getFontLoader", "()Ldbxyzptlk/s1/k$b;", "getFontLoader$annotations", "fontLoader", "Ldbxyzptlk/s1/l$b;", "getFontFamilyResolver", "()Ldbxyzptlk/s1/l$b;", "fontFamilyResolver", "Ldbxyzptlk/z1/t;", "getLayoutDirection", "()Ldbxyzptlk/z1/t;", "layoutDirection", "<set-?>", "getShowLayoutBounds", "setShowLayoutBounds", "showLayoutBounds", "Ldbxyzptlk/g1/K1;", "getViewConfiguration", "()Ldbxyzptlk/g1/K1;", "viewConfiguration", "Ldbxyzptlk/f1/U;", "getSnapshotObserver", "()Ldbxyzptlk/f1/U;", "snapshotObserver", "Ldbxyzptlk/e1/f;", "getModifierLocalManager", "()Ldbxyzptlk/e1/f;", "modifierLocalManager", "Ldbxyzptlk/tI/g;", "getCoroutineContext", "()Ldbxyzptlk/tI/g;", "coroutineContext", "Ldbxyzptlk/d1/Y$a;", "getPlacementScope", "()Ldbxyzptlk/d1/Y$a;", "placementScope", "Ldbxyzptlk/M0/c;", "getDragAndDropManager", "()Ldbxyzptlk/M0/c;", "dragAndDropManager", "r0", "b", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public interface Owner {
  public static final a r0 = a.a;
  
  void B();
  
  void a(boolean paramBoolean);
  
  void c(f paramf);
  
  void g(b paramb);
  
  dbxyzptlk.g1.b getAccessibilityManager();
  
  d getAutofill();
  
  i getAutofillTree();
  
  b0 getClipboardManager();
  
  g getCoroutineContext();
  
  d getDensity();
  
  c getDragAndDropManager();
  
  j getFocusOwner();
  
  l.b getFontFamilyResolver();
  
  k.b getFontLoader();
  
  dbxyzptlk.W0.a getHapticFeedBack();
  
  dbxyzptlk.X0.b getInputModeManager();
  
  t getLayoutDirection();
  
  f getModifierLocalManager();
  
  default Y.a getPlacementScope() {
    return Z.b(this);
  }
  
  x getPointerIconService();
  
  f getRoot();
  
  B getSharedDrawScope();
  
  boolean getShowLayoutBounds();
  
  U getSnapshotObserver();
  
  z1 getSoftwareKeyboardController();
  
  S getTextInputService();
  
  B1 getTextToolbar();
  
  K1 getViewConfiguration();
  
  T1 getWindowInfo();
  
  void h(dbxyzptlk.CI.a<D> parama);
  
  S i(l<? super j0, D> paraml, dbxyzptlk.CI.a<D> parama);
  
  void k(f paramf, long paramLong);
  
  long m(long paramLong);
  
  void o(f paramf, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3);
  
  void p();
  
  void q(f paramf, boolean paramBoolean1, boolean paramBoolean2);
  
  boolean requestFocus();
  
  void setShowLayoutBounds(boolean paramBoolean);
  
  long t(long paramLong);
  
  void u(f paramf);
  
  void v(f paramf, boolean paramBoolean);
  
  void w(f paramf);
  
  void z(f paramf);
  
  @Metadata(d1 = {"\000\024\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\013\n\002\b\b\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003R\"\020\013\032\0020\0048\006@\006X\016¢\006\022\n\004\b\005\020\006\032\004\b\007\020\b\"\004\b\t\020\n¨\006\f"}, d2 = {"Landroidx/compose/ui/node/Owner$a;", "", "<init>", "()V", "", "b", "Z", "a", "()Z", "setEnableExtraAssertions", "(Z)V", "enableExtraAssertions", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class a {
    public static final a a = new a();
    
    public static boolean b;
    
    public final boolean a() {
      return b;
    }
  }
  
  @Metadata(d1 = {"\000\020\n\002\030\002\n\002\020\000\n\002\030\002\n\002\b\003\bf\030\0002\0020\001J\017\020\003\032\0020\002H&¢\006\004\b\003\020\004ø\001\000\002\006\n\004\b!0\001¨\006\005À\006\001"}, d2 = {"Landroidx/compose/ui/node/Owner$b;", "", "Ldbxyzptlk/pI/D;", "l", "()V", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static interface b {
    void l();
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compos\\ui\node\Owner.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */