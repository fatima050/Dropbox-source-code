package androidx.compose.ui.node;

import androidx.compose.ui.focus.FocusTargetNode;
import androidx.compose.ui.viewinterop.AndroidViewHolder;
import dbxyzptlk.CI.l;
import dbxyzptlk.DI.K;
import dbxyzptlk.DI.s;
import dbxyzptlk.DI.u;
import dbxyzptlk.Q0.j0;
import dbxyzptlk.d1.F;
import dbxyzptlk.d1.G;
import dbxyzptlk.d1.H;
import dbxyzptlk.d1.I;
import dbxyzptlk.d1.L;
import dbxyzptlk.d1.a0;
import dbxyzptlk.d1.m;
import dbxyzptlk.d1.n;
import dbxyzptlk.d1.r;
import dbxyzptlk.d1.v;
import dbxyzptlk.d1.z;
import dbxyzptlk.f1.B;
import dbxyzptlk.f1.D;
import dbxyzptlk.f1.H;
import dbxyzptlk.f1.K;
import dbxyzptlk.f1.L;
import dbxyzptlk.f1.S;
import dbxyzptlk.f1.T;
import dbxyzptlk.f1.X;
import dbxyzptlk.f1.h;
import dbxyzptlk.f1.p;
import dbxyzptlk.f1.q;
import dbxyzptlk.f1.t;
import dbxyzptlk.f1.v;
import dbxyzptlk.f1.z;
import dbxyzptlk.g1.K1;
import dbxyzptlk.g1.d0;
import dbxyzptlk.g1.u0;
import dbxyzptlk.l1.l;
import dbxyzptlk.l1.o;
import dbxyzptlk.pI.D;
import dbxyzptlk.x0.j;
import dbxyzptlk.x0.t;
import dbxyzptlk.x0.v;
import dbxyzptlk.z1.k;
import dbxyzptlk.z1.t;
import java.util.Comparator;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

@Metadata(d1 = {"\000´\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\000\n\002\030\002\n\002\020\013\n\000\n\002\020\b\n\002\b\003\n\002\030\002\n\002\b\007\n\002\020\016\n\002\b\026\n\002\030\002\n\002\b\f\n\002\030\002\n\002\b\003\n\002\030\002\n\000\n\002\030\002\n\002\b\023\n\002\020 \n\002\030\002\n\002\b\003\n\002\030\002\n\002\b'\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\n\n\002\030\002\n\002\030\002\n\002\b\013\n\002\030\002\n\002\b\007\n\002\030\002\n\002\b\007\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\013\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\007\n\002\030\002\n\002\b\006\n\002\030\002\n\002\b\006\n\002\030\002\n\002\b\020\n\002\020\007\n\002\b\013\n\002\030\002\n\002\b\n\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\021\n\002\030\002\n\002\b\017\n\002\030\002\n\002\b\013\b\000\030\000 \0012\0020\0012\0020\0022\0020\0032\0020\0042\0020\0052\0020\0062\0020\007:\005gzb\001B\033\022\b\b\002\020\t\032\0020\b\022\b\b\002\020\013\032\0020\n¢\006\004\b\f\020\rJ\017\020\017\032\0020\016H\002¢\006\004\b\017\020\020J\017\020\021\032\0020\016H\002¢\006\004\b\021\020\020J\027\020\023\032\0020\0162\006\020\022\032\0020\000H\002¢\006\004\b\023\020\024J\031\020\027\032\0020\0262\b\b\002\020\025\032\0020\nH\002¢\006\004\b\027\020\030J\017\020\031\032\0020\016H\002¢\006\004\b\031\020\020J\017\020\032\032\0020\016H\002¢\006\004\b\032\020\020J\017\020\033\032\0020\016H\002¢\006\004\b\033\020\020J\017\020\034\032\0020\016H\002¢\006\004\b\034\020\020J\017\020\035\032\0020\016H\002¢\006\004\b\035\020\020J\017\020\036\032\0020\016H\000¢\006\004\b\036\020\020J\037\020!\032\0020\0162\006\020\037\032\0020\n2\006\020 \032\0020\000H\000¢\006\004\b!\020\"J\017\020#\032\0020\016H\000¢\006\004\b#\020\020J\037\020%\032\0020\0162\006\020\037\032\0020\n2\006\020$\032\0020\nH\000¢\006\004\b%\020&J\017\020'\032\0020\016H\000¢\006\004\b'\020\020J'\020*\032\0020\0162\006\020(\032\0020\n2\006\020)\032\0020\n2\006\020$\032\0020\nH\000¢\006\004\b*\020+J\017\020,\032\0020\016H\000¢\006\004\b,\020\020J\027\020/\032\0020\0162\006\020.\032\0020-H\000¢\006\004\b/\0200J\017\0201\032\0020\016H\000¢\006\004\b1\020\020J\017\0202\032\0020\026H\026¢\006\004\b2\0203J\017\0204\032\0020\016H\000¢\006\004\b4\020\020J\017\0205\032\0020\016H\000¢\006\004\b5\020\020J\037\0207\032\0020\0162\006\0206\032\0020\n2\006\0201\032\0020\nH\000¢\006\004\b7\020&J\017\0208\032\0020\016H\000¢\006\004\b8\020\020J\017\0209\032\0020\016H\000¢\006\004\b9\020\020J\027\020<\032\0020\0162\006\020;\032\0020:H\000¢\006\004\b<\020=J6\020D\032\0020\0162\006\020?\032\0020>2\006\020A\032\0020@2\b\b\002\020B\032\0020\b2\b\b\002\020C\032\0020\bH\000ø\001\000¢\006\004\bD\020EJ6\020G\032\0020\0162\006\020?\032\0020>2\006\020F\032\0020@2\b\b\002\020B\032\0020\b2\b\b\002\020C\032\0020\bH\000ø\001\000¢\006\004\bG\020EJ\027\020I\032\0020\0162\006\020H\032\0020\000H\000¢\006\004\bI\020\024J#\020L\032\0020\0162\b\b\002\020J\032\0020\b2\b\b\002\020K\032\0020\bH\000¢\006\004\bL\020MJ#\020N\032\0020\0162\b\b\002\020J\032\0020\b2\b\b\002\020K\032\0020\bH\000¢\006\004\bN\020MJ\017\020O\032\0020\016H\000¢\006\004\bO\020\020J\031\020P\032\0020\0162\b\b\002\020J\032\0020\bH\000¢\006\004\bP\020QJ\031\020R\032\0020\0162\b\b\002\020J\032\0020\bH\000¢\006\004\bR\020QJ\017\020S\032\0020\016H\000¢\006\004\bS\020\020J\025\020V\032\b\022\004\022\0020U0TH\026¢\006\004\bV\020WJ\017\020X\032\0020\016H\000¢\006\004\bX\020\020J\036\020[\032\0020\b2\n\b\002\020Z\032\004\030\0010YH\000ø\001\000¢\006\004\b[\020\\J\036\020]\032\0020\b2\n\b\002\020Z\032\004\030\0010YH\000ø\001\000¢\006\004\b]\020\\J\017\020^\032\0020\016H\000¢\006\004\b^\020\020J\017\020_\032\0020\016H\000¢\006\004\b_\020\020J\017\020`\032\0020\016H\000¢\006\004\b`\020\020J\017\020a\032\0020\016H\000¢\006\004\ba\020\020J\017\020b\032\0020\016H\026¢\006\004\bb\020\020J\017\020c\032\0020\016H\026¢\006\004\bc\020\020J\017\020d\032\0020\016H\000¢\006\004\bd\020\020J\017\020e\032\0020\016H\000¢\006\004\be\020\020J\017\020f\032\0020\016H\026¢\006\004\bf\020\020J\017\020g\032\0020\016H\026¢\006\004\bg\020\020J\017\020h\032\0020\016H\026¢\006\004\bh\020\020R\024\020\t\032\0020\b8\002X\004¢\006\006\n\004\bi\020jR\"\020\013\032\0020\n8\026@\026X\016¢\006\022\n\004\bh\020k\032\004\bl\020m\"\004\bn\020oR0\020t\032\0020\n2\006\020p\032\0020\n8W@WX\016¢\006\030\n\004\bq\020k\022\004\bs\020\020\032\004\br\020m\"\004\bq\020oR\"\020x\032\0020\b8\000@\000X\016¢\006\022\n\004\bg\020j\032\004\bu\020v\"\004\bw\020QR.\020\032\004\030\0010\0002\b\020y\032\004\030\0010\0008\000@BX\016¢\006\022\n\004\bz\020{\032\004\b|\020}\"\004\b~\020\024R\027\020\001\032\0020\n8\002@\002X\016¢\006\006\n\004\bb\020kR\036\020\001\032\t\022\004\022\0020\0000\0018\002X\004¢\006\b\n\006\b\001\020\001R\"\020\001\032\013\022\004\022\0020\000\030\0010\0018\002@\002X\016¢\006\b\n\006\b\001\020\001R\030\020\001\032\0020\b8\002@\002X\016¢\006\007\n\005\b\001\020jR\032\020\001\032\004\030\0010\0008\002@\002X\016¢\006\007\n\005\b\001\020{R+\020.\032\004\030\0010-2\b\020p\032\004\030\0010-8\000@BX\016¢\006\017\n\005\bf\020\001\032\006\b\001\020\001R2\020\001\032\f\030\0010\001j\005\030\001`\0018\000@\000X\016¢\006\027\n\005\bc\020\001\032\006\b\001\020\001\"\006\b\001\020\001R%\020\025\032\0020\n8\000@\000X\016¢\006\025\n\005\b\001\020k\032\005\b\001\020m\"\005\b\001\020oR\030\020\001\032\0020\b8\002@\002X\016¢\006\007\n\005\b\001\020jR\034\020 \001\032\005\030\0010\0018\002@\002X\016¢\006\b\n\006\b\001\020\001R\036\020¢\001\032\t\022\004\022\0020\0000\0018\002X\004¢\006\b\n\006\b¡\001\020\001R\030\020¤\001\032\0020\b8\002@\002X\016¢\006\007\n\005\b£\001\020jR4\020¬\001\032\0030¥\0012\b\020¦\001\032\0030¥\0018\026@VX\016¢\006\030\n\006\b§\001\020¨\001\032\006\b©\001\020ª\001\"\006\b\001\020«\001R \020²\001\032\0030­\0018\000X\004¢\006\020\n\006\b®\001\020¯\001\032\006\b°\001\020±\001R1\020·\001\032\0030³\0012\b\020¦\001\032\0030³\0018\026@VX\016¢\006\025\n\005\b/\020´\001\032\005\bk\020µ\001\"\005\bz\020¶\001R2\020½\001\032\0030¸\0012\b\020¦\001\032\0030¸\0018\026@VX\016¢\006\026\n\005\bd\020¹\001\032\006\bº\001\020»\001\"\005\bi\020¼\001R3\020Ã\001\032\0030¾\0012\b\020¦\001\032\0030¾\0018\026@VX\016¢\006\027\n\005\b\035\020¿\001\032\006\bÀ\001\020Á\001\"\006\b\001\020Â\001R3\020É\001\032\0030Ä\0012\b\020¦\001\032\0030Ä\0018\026@VX\016¢\006\027\n\005\b\027\020Å\001\032\006\bÆ\001\020Ç\001\"\006\b\001\020È\001R)\020Ð\001\032\0030Ê\0018\000@\000X\016¢\006\027\n\005\b6\020Ë\001\032\006\bÌ\001\020Í\001\"\006\bÎ\001\020Ï\001R\031\020Ñ\001\032\0030Ê\0018\002@\002X\016¢\006\007\n\005\b1\020Ë\001R,\020Õ\001\032\0020\b8\000@\000X\016¢\006\033\n\004\bS\020j\022\005\bÔ\001\020\020\032\005\bÒ\001\020v\"\005\bÓ\001\020QR\037\020Ú\001\032\0030Ö\0018\000X\004¢\006\017\n\005\b<\020×\001\032\006\bØ\001\020Ù\001R \020Ü\001\032\0030Û\0018\000X\004¢\006\020\n\006\bÜ\001\020Ý\001\032\006\bÞ\001\020ß\001R,\020ç\001\032\005\030\0010à\0018\000@\000X\016¢\006\030\n\006\bá\001\020â\001\032\006\bã\001\020ä\001\"\006\bå\001\020æ\001R\034\020ê\001\032\005\030\0010è\0018\002@\002X\016¢\006\b\n\006\bÒ\001\020é\001R&\020î\001\032\0020\b8\000@\000X\016¢\006\025\n\005\bë\001\020j\032\005\bì\001\020v\"\005\bí\001\020QR4\020õ\001\032\0030ï\0012\b\020¦\001\032\0030ï\0018\026@VX\016¢\006\030\n\006\bð\001\020ñ\001\032\006\bò\001\020ó\001\"\006\b\001\020ô\001R8\020ý\001\032\021\022\004\022\0020-\022\004\022\0020\016\030\0010ö\0018\000@\000X\016¢\006\030\n\006\b÷\001\020ø\001\032\006\bù\001\020ú\001\"\006\bû\001\020ü\001R8\020\002\032\021\022\004\022\0020-\022\004\022\0020\016\030\0010ö\0018\000@\000X\016¢\006\030\n\006\bþ\001\020ø\001\032\006\bÿ\001\020ú\001\"\006\b\002\020ü\001R&\020\002\032\0020\b8\000@\000X\016¢\006\025\n\005\bÆ\001\020j\032\005\b\002\020v\"\005\b\002\020QR&\020\002\032\0020\b2\006\020p\032\0020\b8\026@RX\016¢\006\r\n\004\bk\020j\032\005\b\002\020vR\030\020\002\032\0030\0028BX\004¢\006\b\032\006\b\002\020\002R\032\020\002\032\005\030\0010è\0018BX\004¢\006\b\032\006\b\002\020\002R\026\020\002\032\004\030\0010\b8F¢\006\b\032\006\b\002\020\002R\034\020\002\032\b\022\004\022\0020\0000T8@X\004¢\006\007\032\005\b\002\020WR\035\020\002\032\t\022\005\022\0030\0020T8@X\004¢\006\007\032\005\bð\001\020WR\035\020\002\032\t\022\005\022\0030\0020T8@X\004¢\006\007\032\005\bë\001\020WR\036\020\002\032\t\022\004\022\0020\0000\0018@X\004¢\006\b\032\006\b\002\020\002R\034\020\002\032\b\022\004\022\0020\0000T8@X\004¢\006\007\032\005\b÷\001\020WR\030\020\002\032\004\030\0010\0008@X\004¢\006\007\032\005\b\002\020}R\026\020\002\032\0020\b8VX\004¢\006\007\032\005\b\002\020vR\030\020¡\002\032\0030\0028@X\004¢\006\b\032\006\b\002\020 \002R\037\020¥\002\032\n\030\0010¢\002R\0030Û\0018@X\004¢\006\b\032\006\b£\002\020¤\002R\035\020©\002\032\b0¦\002R\0030Û\0018@X\004¢\006\b\032\006\b§\002\020¨\002R\032\020«\002\032\005\030\0010\0018@X\004¢\006\b\032\006\bþ\001\020ª\002R%\020®\002\032\t\022\004\022\0020\0000\0018@X\004¢\006\017\022\005\b­\002\020\020\032\006\b¬\002\020\002R\026\020°\002\032\0020\b8VX\004¢\006\007\032\005\b¯\002\020vR\026\020²\002\032\0020\b8@X\004¢\006\007\032\005\b±\002\020vR\026\020´\002\032\0020\n8VX\004¢\006\007\032\005\b³\002\020mR\026\020¶\002\032\0020\n8VX\004¢\006\007\032\005\bµ\002\020mR\026\020·\002\032\0020\b8@X\004¢\006\007\032\005\bá\001\020vR\027\020º\002\032\0030¸\0028@X\004¢\006\007\032\005\bj\020¹\002R\026\020»\002\032\0020\b8VX\004¢\006\007\032\005\b\001\020vR\023\020½\002\032\0020\b8F¢\006\007\032\005\b¼\002\020vR\026\020¿\002\032\0020\n8@X\004¢\006\007\032\005\b¾\002\020mR\030\020Á\002\032\0030Ê\0018@X\004¢\006\b\032\006\bÀ\002\020Í\001R\030\020Ã\002\032\0030Ê\0018@X\004¢\006\b\032\006\bÂ\002\020Í\001R\030\020Å\002\032\0030è\0018@X\004¢\006\b\032\006\bÄ\002\020\002R\030\020Ç\002\032\0030è\0018@X\004¢\006\b\032\006\bÆ\002\020\002R\030\020Ê\002\032\0030È\0028VX\004¢\006\b\032\006\b\001\020É\002R\026\020Ì\002\032\0020\b8@X\004¢\006\007\032\005\bË\002\020vR\026\020Î\002\032\0020\b8@X\004¢\006\007\032\005\bÍ\002\020vR\026\020Ð\002\032\0020\b8@X\004¢\006\007\032\005\bÏ\002\020vR\026\020Ò\002\032\0020\b8@X\004¢\006\007\032\005\bÑ\002\020v\002\007\n\005\b¡\0360\001¨\006Ó\002"}, d2 = {"Landroidx/compose/ui/node/f;", "Ldbxyzptlk/x0/j;", "Ldbxyzptlk/d1/a0;", "Ldbxyzptlk/f1/T;", "Ldbxyzptlk/d1/v;", "Landroidx/compose/ui/node/c;", "", "Landroidx/compose/ui/node/Owner$b;", "", "isVirtual", "", "semanticsId", "<init>", "(ZI)V", "Ldbxyzptlk/pI/D;", "Z0", "()V", "H0", "child", "V0", "(Landroidx/compose/ui/node/f;)V", "depth", "", "w", "(I)Ljava/lang/String;", "W0", "o1", "A0", "B0", "v", "A1", "index", "instance", "z0", "(ILandroidx/compose/ui/node/f;)V", "X0", "count", "d1", "(II)V", "c1", "from", "to", "U0", "(III)V", "G0", "Landroidx/compose/ui/node/Owner;", "owner", "t", "(Landroidx/compose/ui/node/Owner;)V", "y", "toString", "()Ljava/lang/String;", "C0", "F0", "x", "Y0", "e1", "P0", "Ldbxyzptlk/Q0/j0;", "canvas", "A", "(Ldbxyzptlk/Q0/j0;)V", "Ldbxyzptlk/P0/f;", "pointerPosition", "Ldbxyzptlk/f1/q;", "hitTestResult", "isTouchEvent", "isInLayer", "v0", "(JLdbxyzptlk/f1/q;ZZ)V", "hitSemanticsEntities", "x0", "it", "n1", "forceRequest", "scheduleMeasureAndLayout", "l1", "(ZZ)V", "h1", "E0", "j1", "(Z)V", "f1", "z", "", "Ldbxyzptlk/d1/L;", "g0", "()Ljava/util/List;", "D0", "Ldbxyzptlk/z1/b;", "constraints", "N0", "(Ldbxyzptlk/z1/b;)Z", "a1", "Q0", "T0", "R0", "S0", "f", "l", "u", "p1", "k", "d", "b", "a", "Z", "I", "o0", "()I", "y1", "(I)V", "<set-?>", "c", "getCompositeKeyHash", "getCompositeKeyHash$annotations", "compositeKeyHash", "M0", "()Z", "setVirtualLookaheadRoot$ui_release", "isVirtualLookaheadRoot", "newRoot", "e", "Landroidx/compose/ui/node/f;", "Y", "()Landroidx/compose/ui/node/f;", "u1", "lookaheadRoot", "virtualChildrenCount", "Ldbxyzptlk/f1/H;", "g", "Ldbxyzptlk/f1/H;", "_foldedChildren", "Ldbxyzptlk/z0/d;", "h", "Ldbxyzptlk/z0/d;", "_unfoldedChildren", "i", "unfoldedVirtualChildrenListDirty", "j", "_foldedParent", "Landroidx/compose/ui/node/Owner;", "l0", "()Landroidx/compose/ui/node/Owner;", "Landroidx/compose/ui/viewinterop/AndroidViewHolder;", "Landroidx/compose/ui/viewinterop/InteropViewFactoryHolder;", "Landroidx/compose/ui/viewinterop/AndroidViewHolder;", "P", "()Landroidx/compose/ui/viewinterop/AndroidViewHolder;", "s1", "(Landroidx/compose/ui/viewinterop/AndroidViewHolder;)V", "interopViewFactoryHolder", "m", "J", "setDepth$ui_release", "n", "ignoreRemeasureRequests", "Ldbxyzptlk/l1/l;", "o", "Ldbxyzptlk/l1/l;", "_collapsedSemantics", "p", "_zSortedChildren", "q", "zSortedChildrenInvalidated", "Ldbxyzptlk/d1/G;", "value", "r", "Ldbxyzptlk/d1/G;", "c0", "()Ldbxyzptlk/d1/G;", "(Ldbxyzptlk/d1/G;)V", "measurePolicy", "Ldbxyzptlk/f1/t;", "s", "Ldbxyzptlk/f1/t;", "Q", "()Ldbxyzptlk/f1/t;", "intrinsicsPolicy", "Ldbxyzptlk/z1/d;", "Ldbxyzptlk/z1/d;", "()Ldbxyzptlk/z1/d;", "(Ldbxyzptlk/z1/d;)V", "density", "Ldbxyzptlk/z1/t;", "Ldbxyzptlk/z1/t;", "getLayoutDirection", "()Ldbxyzptlk/z1/t;", "(Ldbxyzptlk/z1/t;)V", "layoutDirection", "Ldbxyzptlk/g1/K1;", "Ldbxyzptlk/g1/K1;", "q0", "()Ldbxyzptlk/g1/K1;", "(Ldbxyzptlk/g1/K1;)V", "viewConfiguration", "Ldbxyzptlk/x0/v;", "Ldbxyzptlk/x0/v;", "H", "()Ldbxyzptlk/x0/v;", "(Ldbxyzptlk/x0/v;)V", "compositionLocalMap", "Landroidx/compose/ui/node/f$g;", "Landroidx/compose/ui/node/f$g;", "R", "()Landroidx/compose/ui/node/f$g;", "t1", "(Landroidx/compose/ui/node/f$g;)V", "intrinsicsUsageByParent", "previousIntrinsicsUsageByParent", "C", "q1", "getCanMultiMeasure$ui_release$annotations", "canMultiMeasure", "Landroidx/compose/ui/node/l;", "Landroidx/compose/ui/node/l;", "i0", "()Landroidx/compose/ui/node/l;", "nodes", "Landroidx/compose/ui/node/g;", "layoutDelegate", "Landroidx/compose/ui/node/g;", "S", "()Landroidx/compose/ui/node/g;", "Ldbxyzptlk/d1/z;", "B", "Ldbxyzptlk/d1/z;", "p0", "()Ldbxyzptlk/d1/z;", "z1", "(Ldbxyzptlk/d1/z;)V", "subcompositionsState", "Landroidx/compose/ui/node/n;", "Landroidx/compose/ui/node/n;", "_innerLayerCoordinator", "D", "getInnerLayerCoordinatorIsDirty$ui_release", "r1", "innerLayerCoordinatorIsDirty", "Landroidx/compose/ui/d;", "E", "Landroidx/compose/ui/d;", "f0", "()Landroidx/compose/ui/d;", "(Landroidx/compose/ui/d;)V", "modifier", "Lkotlin/Function1;", "F", "Ldbxyzptlk/CI/l;", "getOnAttach$ui_release", "()Ldbxyzptlk/CI/l;", "w1", "(Ldbxyzptlk/CI/l;)V", "onAttach", "G", "getOnDetach$ui_release", "x1", "onDetach", "h0", "v1", "needsOnPositionedDispatch", "J0", "isDeactivated", "", "s0", "()F", "zIndex", "O", "()Landroidx/compose/ui/node/n;", "innerLayerCoordinator", "L0", "()Ljava/lang/Boolean;", "isPlacedInLookahead", "K", "foldedChildren", "Ldbxyzptlk/d1/F;", "childMeasurables", "childLookaheadMeasurables", "u0", "()Ldbxyzptlk/z0/d;", "_children", "children", "m0", "parent", "I0", "isAttached", "Landroidx/compose/ui/node/f$e;", "U", "()Landroidx/compose/ui/node/f$e;", "layoutState", "Landroidx/compose/ui/node/g$a;", "X", "()Landroidx/compose/ui/node/g$a;", "lookaheadPassDelegate", "Landroidx/compose/ui/node/g$b;", "a0", "()Landroidx/compose/ui/node/g$b;", "measurePassDelegate", "()Ldbxyzptlk/l1/l;", "collapsedSemantics", "t0", "getZSortedChildren$annotations", "zSortedChildren", "k0", "isValidOwnerScope", "L", "hasFixedInnerContentConstraints", "r0", "width", "M", "height", "alignmentLinesRequired", "Ldbxyzptlk/f1/B;", "()Ldbxyzptlk/f1/B;", "mDrawScope", "isPlaced", "K0", "isPlacedByParent", "n0", "placeOrder", "d0", "measuredByParent", "e0", "measuredByParentInLookahead", "N", "innerCoordinator", "j0", "outerCoordinator", "Ldbxyzptlk/d1/r;", "()Ldbxyzptlk/d1/r;", "coordinates", "b0", "measurePending", "T", "layoutPending", "W", "lookaheadMeasurePending", "V", "lookaheadLayoutPending", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class f implements j, a0, T, v, c, Owner.b {
  public static final d J = new d(null);
  
  public static final int K = 8;
  
  public static final f L = new c();
  
  public static final dbxyzptlk.CI.a<f> M = a.f;
  
  public static final K1 N = new b();
  
  public static final Comparator<f> O = (Comparator<f>)new z();
  
  public final l A;
  
  public z B;
  
  public n C;
  
  public boolean D;
  
  public androidx.compose.ui.d E;
  
  public l<? super Owner, D> F;
  
  public l<? super Owner, D> G;
  
  public boolean H;
  
  public boolean I;
  
  public final boolean a;
  
  public int b;
  
  public int c;
  
  public boolean d;
  
  public f e;
  
  public int f;
  
  public final H<f> g;
  
  public dbxyzptlk.z0.d<f> h;
  
  public boolean i;
  
  public f j;
  
  public Owner k;
  
  public AndroidViewHolder l;
  
  private final g layoutDelegate;
  
  public int m;
  
  public boolean n;
  
  public l o;
  
  public final dbxyzptlk.z0.d<f> p;
  
  public boolean q;
  
  public G r;
  
  public final t s;
  
  public dbxyzptlk.z1.d t;
  
  public t u;
  
  public K1 v;
  
  public v w;
  
  public g x;
  
  public g y;
  
  public boolean z;
  
  public f() {
    this(false, 0, 3, null);
  }
  
  public f(boolean paramBoolean, int paramInt) {
    this.a = paramBoolean;
    this.b = paramInt;
    this.g = new H(new dbxyzptlk.z0.d((Object[])new f[16], 0), new i(this));
    this.p = new dbxyzptlk.z0.d((Object[])new f[16], 0);
    this.q = true;
    this.r = L;
    this.s = new t(this);
    this.t = D.a();
    this.u = t.Ltr;
    this.v = N;
    this.w = v.Pa.a();
    g g1 = g.NotUsed;
    this.x = g1;
    this.y = g1;
    this.A = new l(this);
    this.layoutDelegate = new g(this);
    this.D = true;
    this.E = (androidx.compose.ui.d)androidx.compose.ui.d.a;
  }
  
  public static final int p(f paramf1, f paramf2) {
    int i;
    if (paramf1.s0() == paramf2.s0()) {
      i = s.j(paramf1.n0(), paramf2.n0());
    } else {
      i = Float.compare(paramf1.s0(), paramf2.s0());
    } 
    return i;
  }
  
  private final float s0() {
    return a0().C1();
  }
  
  public final void A(j0 paramj0) {
    j0().X1(paramj0);
  }
  
  public final void A0() {
    if (this.A.q(K.a(1024) | K.a(2048) | K.a(4096)))
      for (androidx.compose.ui.d.c c1 = this.A.k(); c1 != null; c1 = c1.I1()) {
        int k = K.a(1024);
        int i = c1.M1();
        boolean bool = false;
        if ((k & i) != 0) {
          i = 1;
        } else {
          i = 0;
        } 
        if ((K.a(2048) & c1.M1()) != 0) {
          k = 1;
        } else {
          k = 0;
        } 
        if ((K.a(4096) & c1.M1()) != 0)
          bool = true; 
        if ((i | k | bool) != 0)
          L.a(c1); 
      }  
  }
  
  public final void A1() {
    if (this.f > 0)
      Z0(); 
  }
  
  public final boolean B() {
    g g1 = this.layoutDelegate;
    boolean bool = g1.r().d().k();
    boolean bool2 = true;
    boolean bool1 = bool2;
    if (!bool) {
      dbxyzptlk.f1.b b1 = g1.B();
      if (b1 != null) {
        dbxyzptlk.f1.a a1 = b1.d();
        if (a1 != null && a1.k() == true)
          return bool2; 
      } 
      bool1 = false;
    } 
    return bool1;
  }
  
  public final void B0() {
    l l1 = this.A;
    int i = K.a(1024);
    if ((l.c(l1) & i) != 0)
      for (androidx.compose.ui.d.c c1 = l1.p(); c1 != null; c1 = c1.O1()) {
        if ((c1.M1() & i) != 0) {
          androidx.compose.ui.d.c c2 = c1;
          l1 = null;
          while (c2 != null) {
            dbxyzptlk.z0.d d2;
            FocusTargetNode focusTargetNode;
            if (c2 instanceof FocusTargetNode) {
              focusTargetNode = (FocusTargetNode)c2;
              l l2 = l1;
              if (focusTargetNode.r2().isFocused()) {
                D.b(this).getFocusOwner().i(true, false);
                focusTargetNode.t2();
                l2 = l1;
              } 
            } else {
              l l2 = l1;
              if ((focusTargetNode.M1() & i) != 0) {
                l2 = l1;
                if (focusTargetNode instanceof dbxyzptlk.f1.i) {
                  dbxyzptlk.z0.d d3;
                  androidx.compose.ui.d.c c4 = ((dbxyzptlk.f1.i)focusTargetNode).l2();
                  int k;
                  for (k = 0; c4 != null; k = m) {
                    dbxyzptlk.z0.d d4;
                    FocusTargetNode focusTargetNode1 = focusTargetNode;
                    l l3 = l1;
                    int m = k;
                    if ((c4.M1() & i) != 0) {
                      m = k + 1;
                      if (m == 1) {
                        androidx.compose.ui.d.c c5 = c4;
                        l3 = l1;
                      } else {
                        dbxyzptlk.z0.d d5;
                        l l4 = l1;
                        if (l1 == null)
                          d5 = new dbxyzptlk.z0.d((Object[])new androidx.compose.ui.d.c[16], 0); 
                        FocusTargetNode focusTargetNode2 = focusTargetNode;
                        if (focusTargetNode != null) {
                          d5.c(focusTargetNode);
                          focusTargetNode2 = null;
                        } 
                        d5.c(c4);
                        d4 = d5;
                        focusTargetNode1 = focusTargetNode2;
                      } 
                    } 
                    c4 = c4.I1();
                    focusTargetNode = focusTargetNode1;
                    d3 = d4;
                  } 
                  d2 = d3;
                  if (k == 1)
                    continue; 
                } 
              } 
            } 
            androidx.compose.ui.d.c c3 = h.b(d2);
            dbxyzptlk.z0.d d1 = d2;
          } 
        } 
      }  
  }
  
  public final boolean C() {
    return this.z;
  }
  
  public final void C0() {
    n n1 = O();
    if (n1 != null) {
      n1.z2();
    } else {
      f f1 = m0();
      if (f1 != null)
        f1.C0(); 
    } 
  }
  
  public final List<F> D() {
    g.a a1 = X();
    s.e(a1);
    return a1.j1();
  }
  
  public final void D0() {
    n n1 = j0();
    n n2 = N();
    while (n1 != n2) {
      s.f(n1, "null cannot be cast to non-null type androidx.compose.ui.node.LayoutModifierNodeCoordinator");
      n1 = n1;
      S s1 = n1.i2();
      if (s1 != null)
        s1.invalidate(); 
      n1 = n1.p2();
    } 
    S s = N().i2();
    if (s != null)
      s.invalidate(); 
  }
  
  public final List<F> E() {
    return (List)a0().n1();
  }
  
  public final void E0() {
    if (this.e != null) {
      i1(this, false, false, 3, null);
    } else {
      m1(this, false, false, 3, null);
    } 
  }
  
  public final List<f> F() {
    return u0().h();
  }
  
  public final void F0() {
    this.layoutDelegate.J();
  }
  
  public final l G() {
    if (!this.A.r(K.a(8)) || this.o != null)
      return this.o; 
    K k = new K();
    k.a = new l();
    D.b(this).getSnapshotObserver().j(this, (dbxyzptlk.CI.a)new j(this, k));
    Object object = k.a;
    this.o = (l)object;
    return (l)object;
  }
  
  public final void G0() {
    this.o = null;
    D.b(this).B();
  }
  
  public v H() {
    return this.w;
  }
  
  public final void H0() {
    if (this.f > 0)
      this.i = true; 
    if (this.a) {
      f f1 = this.j;
      if (f1 != null)
        f1.H0(); 
    } 
  }
  
  public dbxyzptlk.z1.d I() {
    return this.t;
  }
  
  public boolean I0() {
    boolean bool;
    if (this.k != null) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public final int J() {
    return this.m;
  }
  
  public boolean J0() {
    return this.I;
  }
  
  public final List<f> K() {
    return this.g.b();
  }
  
  public final boolean K0() {
    return a0().I1();
  }
  
  public final boolean L() {
    boolean bool;
    long l1 = N().h2();
    if (dbxyzptlk.z1.b.l(l1) && dbxyzptlk.z1.b.k(l1)) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public final Boolean L0() {
    g.a a1 = X();
    if (a1 != null) {
      Boolean bool = Boolean.valueOf(a1.h());
    } else {
      a1 = null;
    } 
    return (Boolean)a1;
  }
  
  public int M() {
    return this.layoutDelegate.w();
  }
  
  public final boolean M0() {
    return this.d;
  }
  
  public final n N() {
    return this.A.l();
  }
  
  public final boolean N0(dbxyzptlk.z1.b paramb) {
    boolean bool;
    if (paramb != null && this.e != null) {
      g.a a1 = X();
      s.e(a1);
      bool = a1.M1(paramb.t());
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public final n O() {
    if (this.D) {
      n n2 = N();
      n n3 = j0().q2();
      this.C = null;
      while (!s.c(n2, n3)) {
        Object object;
        if (n2 != null) {
          object = n2.i2();
        } else {
          object = null;
        } 
        if (object != null) {
          this.C = n2;
          break;
        } 
        if (n2 != null) {
          n2 = n2.q2();
          continue;
        } 
        n2 = null;
      } 
    } 
    n n1 = this.C;
    if (n1 == null || n1.i2() != null)
      return n1; 
    throw new IllegalStateException("layer was not set");
  }
  
  public final AndroidViewHolder P() {
    return this.l;
  }
  
  public final void P0() {
    if (this.x == g.NotUsed)
      v(); 
    g.a a1 = X();
    s.e(a1);
    a1.N1();
  }
  
  public final t Q() {
    return this.s;
  }
  
  public final void Q0() {
    this.layoutDelegate.L();
  }
  
  public final g R() {
    return this.x;
  }
  
  public final void R0() {
    this.layoutDelegate.M();
  }
  
  public final g S() {
    return this.layoutDelegate;
  }
  
  public final void S0() {
    this.layoutDelegate.N();
  }
  
  public final boolean T() {
    return this.layoutDelegate.z();
  }
  
  public final void T0() {
    this.layoutDelegate.O();
  }
  
  public final e U() {
    return this.layoutDelegate.A();
  }
  
  public final void U0(int paramInt1, int paramInt2, int paramInt3) {
    if (paramInt1 == paramInt2)
      return; 
    for (byte b1 = 0; b1 < paramInt3; b1++) {
      int i;
      int k;
      if (paramInt1 > paramInt2) {
        i = paramInt1 + b1;
      } else {
        i = paramInt1;
      } 
      if (paramInt1 > paramInt2) {
        k = paramInt2 + b1;
      } else {
        k = paramInt2 + paramInt3 - 2;
      } 
      f f1 = (f)this.g.g(i);
      this.g.a(k, f1);
    } 
    X0();
    H0();
    E0();
  }
  
  public final boolean V() {
    return this.layoutDelegate.C();
  }
  
  public final void V0(f paramf) {
    if (paramf.layoutDelegate.s() > 0) {
      g g1 = this.layoutDelegate;
      g1.T(g1.s() - 1);
    } 
    if (this.k != null)
      paramf.y(); 
    paramf.j = null;
    paramf.j0().S2(null);
    if (paramf.a) {
      this.f--;
      dbxyzptlk.z0.d d1 = paramf.g.f();
      int i = d1.p();
      if (i > 0) {
        int m;
        Object[] arrayOfObject = d1.o();
        int k = 0;
        do {
          ((f)arrayOfObject[k]).j0().S2(null);
          m = k + 1;
          k = m;
        } while (m < i);
      } 
    } 
    H0();
    X0();
  }
  
  public final boolean W() {
    return this.layoutDelegate.D();
  }
  
  public final void W0() {
    E0();
    f f1 = m0();
    if (f1 != null)
      f1.C0(); 
    D0();
  }
  
  public final g.a X() {
    return this.layoutDelegate.E();
  }
  
  public final void X0() {
    if (this.a) {
      f f1 = m0();
      if (f1 != null)
        f1.X0(); 
    } else {
      this.q = true;
    } 
  }
  
  public final f Y() {
    return this.e;
  }
  
  public final void Y0(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: getfield x : Landroidx/compose/ui/node/f$g;
    //   4: getstatic androidx/compose/ui/node/f$g.NotUsed : Landroidx/compose/ui/node/f$g;
    //   7: if_acmpne -> 14
    //   10: aload_0
    //   11: invokevirtual v : ()V
    //   14: aload_0
    //   15: invokevirtual m0 : ()Landroidx/compose/ui/node/f;
    //   18: astore_3
    //   19: aload_3
    //   20: ifnull -> 52
    //   23: aload_3
    //   24: invokevirtual N : ()Landroidx/compose/ui/node/n;
    //   27: astore_3
    //   28: aload_3
    //   29: ifnull -> 52
    //   32: aload_3
    //   33: invokevirtual j1 : ()Ldbxyzptlk/d1/Y$a;
    //   36: astore #4
    //   38: aload #4
    //   40: astore_3
    //   41: aload #4
    //   43: ifnonnull -> 49
    //   46: goto -> 52
    //   49: goto -> 65
    //   52: aload_0
    //   53: invokestatic b : (Landroidx/compose/ui/node/f;)Landroidx/compose/ui/node/Owner;
    //   56: invokeinterface getPlacementScope : ()Ldbxyzptlk/d1/Y$a;
    //   61: astore_3
    //   62: goto -> 49
    //   65: aload_3
    //   66: aload_0
    //   67: invokevirtual a0 : ()Landroidx/compose/ui/node/g$b;
    //   70: iload_1
    //   71: iload_2
    //   72: fconst_0
    //   73: iconst_4
    //   74: aconst_null
    //   75: invokestatic j : (Ldbxyzptlk/d1/Y$a;Ldbxyzptlk/d1/Y;IIFILjava/lang/Object;)V
    //   78: return
  }
  
  public final B Z() {
    return D.b(this).getSharedDrawScope();
  }
  
  public final void Z0() {
    if (this.i) {
      int i = 0;
      this.i = false;
      dbxyzptlk.z0.d<f> d2 = this.h;
      dbxyzptlk.z0.d<f> d1 = d2;
      if (d2 == null) {
        d1 = new dbxyzptlk.z0.d((Object[])new f[16], 0);
        this.h = d1;
      } 
      d1.i();
      d2 = this.g.f();
      int k = d2.p();
      if (k > 0) {
        int m;
        Object[] arrayOfObject = d2.o();
        do {
          dbxyzptlk.z0.d<f> d3;
          f f1 = (f)arrayOfObject[i];
          if (f1.a) {
            d3 = f1.u0();
            d1.d(d1.p(), d3);
          } else {
            d1.c(d3);
          } 
          m = i + 1;
          i = m;
        } while (m < k);
      } 
      this.layoutDelegate.K();
    } 
  }
  
  public void a(t paramt) {
    if (this.u != paramt) {
      this.u = paramt;
      W0();
    } 
  }
  
  public final g.b a0() {
    return this.layoutDelegate.F();
  }
  
  public final boolean a1(dbxyzptlk.z1.b paramb) {
    boolean bool;
    if (paramb != null) {
      if (this.x == g.NotUsed)
        u(); 
      bool = a0().S1(paramb.t());
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public void b() {
    AndroidViewHolder androidViewHolder = this.l;
    if (androidViewHolder != null)
      androidViewHolder.b(); 
    z z1 = this.B;
    if (z1 != null)
      z1.b(); 
    n n1 = j0();
    n n2 = N().p2();
    while (!s.c(n1, n2) && n1 != null) {
      n1.J2();
      n1 = n1.p2();
    } 
  }
  
  public final boolean b0() {
    return this.layoutDelegate.G();
  }
  
  public void c(int paramInt) {
    this.c = paramInt;
  }
  
  public G c0() {
    return this.r;
  }
  
  public final void c1() {
    for (int i = this.g.e() - 1; -1 < i; i--)
      V0((f)this.g.d(i)); 
    this.g.c();
  }
  
  public void d() {
    AndroidViewHolder androidViewHolder = this.l;
    if (androidViewHolder != null)
      androidViewHolder.d(); 
    z z1 = this.B;
    if (z1 != null)
      z1.d(); 
    this.I = true;
    o1();
    if (I0())
      G0(); 
  }
  
  public final g d0() {
    return a0().w1();
  }
  
  public final void d1(int paramInt1, int paramInt2) {
    if (paramInt2 >= 0) {
      paramInt2 = paramInt2 + paramInt1 - 1;
      if (paramInt1 <= paramInt2)
        while (true) {
          V0((f)this.g.g(paramInt2));
          if (paramInt2 != paramInt1) {
            paramInt2--;
            continue;
          } 
          break;
        }  
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("count (");
    stringBuilder.append(paramInt2);
    stringBuilder.append(") must be greater than 0");
    throw new IllegalArgumentException(stringBuilder.toString().toString());
  }
  
  public void e(dbxyzptlk.z1.d paramd) {
    if (!s.c(this.t, paramd)) {
      this.t = paramd;
      W0();
      l l1 = this.A;
      int i = K.a(16);
      if ((l.c(l1) & i) != 0) {
        androidx.compose.ui.d.c c1 = l1.k();
        while (c1 != null) {
          if ((c1.M1() & i) != 0) {
            androidx.compose.ui.d.c c2 = c1;
            l1 = null;
            while (c2 != null) {
              dbxyzptlk.z0.d d2;
              if (c2 instanceof X) {
                ((X)c2).t1();
                l l2 = l1;
              } else {
                l l2 = l1;
                if ((c2.M1() & i) != 0) {
                  l2 = l1;
                  if (c2 instanceof dbxyzptlk.f1.i) {
                    dbxyzptlk.z0.d d3;
                    androidx.compose.ui.d.c c3 = ((dbxyzptlk.f1.i)c2).l2();
                    int k;
                    for (k = 0; c3 != null; k = m) {
                      dbxyzptlk.z0.d d4;
                      androidx.compose.ui.d.c c4 = c2;
                      l l3 = l1;
                      int m = k;
                      if ((c3.M1() & i) != 0) {
                        m = k + 1;
                        if (m == 1) {
                          c4 = c3;
                          l3 = l1;
                        } else {
                          dbxyzptlk.z0.d d5;
                          l l4 = l1;
                          if (l1 == null)
                            d5 = new dbxyzptlk.z0.d((Object[])new androidx.compose.ui.d.c[16], 0); 
                          androidx.compose.ui.d.c c5 = c2;
                          if (c2 != null) {
                            d5.c(c2);
                            c5 = null;
                          } 
                          d5.c(c3);
                          d4 = d5;
                          c4 = c5;
                        } 
                      } 
                      c3 = c3.I1();
                      c2 = c4;
                      d3 = d4;
                    } 
                    d2 = d3;
                    if (k == 1)
                      continue; 
                  } 
                } 
              } 
              c2 = h.b(d2);
              dbxyzptlk.z0.d d1 = d2;
            } 
          } 
          if ((c1.H1() & i) != 0)
            c1 = c1.I1(); 
        } 
      } 
    } 
  }
  
  public final g e0() {
    g.a a1 = X();
    if (a1 != null) {
      g g2 = a1.t1();
      g g1 = g2;
      return (g2 == null) ? g.NotUsed : g1;
    } 
    return g.NotUsed;
  }
  
  public final void e1() {
    if (this.x == g.NotUsed)
      v(); 
    a0().T1();
  }
  
  public void f() {
    if (this.e != null) {
      i1(this, false, false, 1, null);
    } else {
      m1(this, false, false, 1, null);
    } 
    dbxyzptlk.z1.b b1 = this.layoutDelegate.x();
    if (b1 != null) {
      Owner owner = this.k;
      if (owner != null)
        owner.k(this, b1.t()); 
    } else {
      Owner owner = this.k;
      if (owner != null)
        Owner.b(owner, false, 1, null); 
    } 
  }
  
  public androidx.compose.ui.d f0() {
    return this.E;
  }
  
  public final void f1(boolean paramBoolean) {
    if (!this.a) {
      Owner owner = this.k;
      if (owner != null)
        owner.q(this, true, paramBoolean); 
    } 
  }
  
  public void g(androidx.compose.ui.d paramd) {
    if (!this.a || f0() == androidx.compose.ui.d.a) {
      if (!J0()) {
        this.E = paramd;
        this.A.F(paramd);
        this.layoutDelegate.W();
        if (this.A.r(K.a(512)) && this.e == null)
          u1(this); 
        return;
      } 
      throw new IllegalArgumentException("modifier is updated when deactivated");
    } 
    throw new IllegalArgumentException("Modifiers are not supported on virtual LayoutNodes");
  }
  
  public List<L> g0() {
    return this.A.n();
  }
  
  public t getLayoutDirection() {
    return this.u;
  }
  
  public boolean h() {
    return a0().h();
  }
  
  public final boolean h0() {
    return this.H;
  }
  
  public final void h1(boolean paramBoolean1, boolean paramBoolean2) {
    if (this.e != null) {
      Owner owner = this.k;
      if (owner == null)
        return; 
      if (!this.n && !this.a) {
        owner.o(this, true, paramBoolean1, paramBoolean2);
        g.a a1 = X();
        s.e(a1);
        a1.w1(paramBoolean1);
      } 
      return;
    } 
    throw new IllegalStateException("Lookahead measure cannot be requested on a node that is not a part of theLookaheadScope");
  }
  
  public r i() {
    return N();
  }
  
  public final l i0() {
    return this.A;
  }
  
  public void j(G paramG) {
    if (!s.c(this.r, paramG)) {
      this.r = paramG;
      this.s.l(c0());
      E0();
    } 
  }
  
  public final n j0() {
    return this.A.o();
  }
  
  public final void j1(boolean paramBoolean) {
    if (!this.a) {
      Owner owner = this.k;
      if (owner != null)
        Owner.s(owner, this, false, paramBoolean, 2, null); 
    } 
  }
  
  public void k() {
    if (I0()) {
      AndroidViewHolder androidViewHolder = this.l;
      if (androidViewHolder != null)
        androidViewHolder.k(); 
      z z1 = this.B;
      if (z1 != null)
        z1.k(); 
      if (J0()) {
        this.I = false;
        G0();
      } else {
        o1();
      } 
      y1(o.b());
      this.A.t();
      this.A.z();
      n1(this);
      return;
    } 
    throw new IllegalArgumentException("onReuse is only expected on attached node");
  }
  
  public boolean k0() {
    return I0();
  }
  
  public void l() {
    n n1 = N();
    int i = K.a(128);
    boolean bool = L.i(i);
    androidx.compose.ui.d.c c2 = n1.o2();
    if (!bool) {
      androidx.compose.ui.d.c c3 = c2.O1();
      c2 = c3;
      if (c3 == null)
        return; 
    } 
    androidx.compose.ui.d.c c1 = n.N1(n1, bool);
    while (c1 != null && (c1.H1() & i) != 0) {
      if ((c1.M1() & i) != 0) {
        androidx.compose.ui.d.c c4 = c1;
        androidx.compose.ui.d.c c3 = null;
        while (c4 != null) {
          dbxyzptlk.z0.d d2;
          if (c4 instanceof v) {
            ((v)c4).D(N());
            androidx.compose.ui.d.c c5 = c3;
          } else {
            androidx.compose.ui.d.c c5 = c3;
            if ((c4.M1() & i) != 0) {
              c5 = c3;
              if (c4 instanceof dbxyzptlk.f1.i) {
                dbxyzptlk.z0.d d3;
                c5 = ((dbxyzptlk.f1.i)c4).l2();
                int k;
                for (k = 0; c5 != null; k = m) {
                  dbxyzptlk.z0.d d4;
                  androidx.compose.ui.d.c c6 = c4;
                  androidx.compose.ui.d.c c7 = c3;
                  int m = k;
                  if ((c5.M1() & i) != 0) {
                    m = k + 1;
                    if (m == 1) {
                      c6 = c5;
                      c7 = c3;
                    } else {
                      dbxyzptlk.z0.d d5;
                      c6 = c3;
                      if (c3 == null)
                        d5 = new dbxyzptlk.z0.d((Object[])new androidx.compose.ui.d.c[16], 0); 
                      c3 = c4;
                      if (c4 != null) {
                        d5.c(c4);
                        c3 = null;
                      } 
                      d5.c(c5);
                      d4 = d5;
                      c6 = c3;
                    } 
                  } 
                  c5 = c5.I1();
                  c4 = c6;
                  d3 = d4;
                } 
                d2 = d3;
                if (k == 1)
                  continue; 
              } 
            } 
          } 
          c4 = h.b(d2);
          dbxyzptlk.z0.d d1 = d2;
        } 
      } 
      if (c1 != c2)
        c1 = c1.I1(); 
    } 
  }
  
  public final Owner l0() {
    return this.k;
  }
  
  public final void l1(boolean paramBoolean1, boolean paramBoolean2) {
    if (!this.n && !this.a) {
      Owner owner = this.k;
      if (owner == null)
        return; 
      Owner.C(owner, this, false, paramBoolean1, paramBoolean2, 2, null);
      a0().G1(paramBoolean1);
    } 
  }
  
  public void m(K1 paramK1) {
    if (!s.c(this.v, paramK1)) {
      this.v = paramK1;
      l l1 = this.A;
      int i = K.a(16);
      if ((l.c(l1) & i) != 0) {
        androidx.compose.ui.d.c c1 = l1.k();
        while (c1 != null) {
          if ((c1.M1() & i) != 0) {
            androidx.compose.ui.d.c c2 = c1;
            l1 = null;
            while (c2 != null) {
              dbxyzptlk.z0.d d2;
              if (c2 instanceof X) {
                ((X)c2).C1();
                l l2 = l1;
              } else {
                l l2 = l1;
                if ((c2.M1() & i) != 0) {
                  l2 = l1;
                  if (c2 instanceof dbxyzptlk.f1.i) {
                    dbxyzptlk.z0.d d3;
                    androidx.compose.ui.d.c c3 = ((dbxyzptlk.f1.i)c2).l2();
                    int k;
                    for (k = 0; c3 != null; k = m) {
                      dbxyzptlk.z0.d d4;
                      androidx.compose.ui.d.c c4 = c2;
                      l l3 = l1;
                      int m = k;
                      if ((c3.M1() & i) != 0) {
                        m = k + 1;
                        if (m == 1) {
                          c4 = c3;
                          l3 = l1;
                        } else {
                          dbxyzptlk.z0.d d5;
                          l l4 = l1;
                          if (l1 == null)
                            d5 = new dbxyzptlk.z0.d((Object[])new androidx.compose.ui.d.c[16], 0); 
                          androidx.compose.ui.d.c c5 = c2;
                          if (c2 != null) {
                            d5.c(c2);
                            c5 = null;
                          } 
                          d5.c(c3);
                          d4 = d5;
                          c4 = c5;
                        } 
                      } 
                      c3 = c3.I1();
                      c2 = c4;
                      d3 = d4;
                    } 
                    d2 = d3;
                    if (k == 1)
                      continue; 
                  } 
                } 
              } 
              c2 = h.b(d2);
              dbxyzptlk.z0.d d1 = d2;
            } 
          } 
          if ((c1.H1() & i) != 0)
            c1 = c1.I1(); 
        } 
      } 
    } 
  }
  
  public final f m0() {
    f f1;
    for (f1 = this.j; f1 != null && f1.a == true; f1 = f1.j);
    return f1;
  }
  
  public void n(v paramv) {
    this.w = paramv;
    e((dbxyzptlk.z1.d)paramv.a((t)d0.e()));
    a((t)paramv.a((t)d0.j()));
    m((K1)paramv.a((t)d0.p()));
    l l1 = this.A;
    int i = K.a(32768);
    if ((l.c(l1) & i) != 0) {
      androidx.compose.ui.d.c c1 = l1.k();
      while (c1 != null) {
        if ((c1.M1() & i) != 0) {
          androidx.compose.ui.d.c c2 = c1;
          l1 = null;
          while (c2 != null) {
            dbxyzptlk.z0.d d2;
            if (c2 instanceof dbxyzptlk.f1.e) {
              l l2;
              androidx.compose.ui.d.c c3 = ((dbxyzptlk.f1.e)c2).Q0();
              if (c3.R1()) {
                L.e(c3);
                l2 = l1;
              } else {
                l2.h2(true);
                l2 = l1;
              } 
            } else {
              l l2 = l1;
              if ((c2.M1() & i) != 0) {
                l2 = l1;
                if (c2 instanceof dbxyzptlk.f1.i) {
                  dbxyzptlk.z0.d d3;
                  androidx.compose.ui.d.c c3 = ((dbxyzptlk.f1.i)c2).l2();
                  int k;
                  for (k = 0; c3 != null; k = m) {
                    dbxyzptlk.z0.d d4;
                    androidx.compose.ui.d.c c4 = c2;
                    l l3 = l1;
                    int m = k;
                    if ((c3.M1() & i) != 0) {
                      m = k + 1;
                      if (m == 1) {
                        c4 = c3;
                        l3 = l1;
                      } else {
                        dbxyzptlk.z0.d d5;
                        l l4 = l1;
                        if (l1 == null)
                          d5 = new dbxyzptlk.z0.d((Object[])new androidx.compose.ui.d.c[16], 0); 
                        androidx.compose.ui.d.c c5 = c2;
                        if (c2 != null) {
                          d5.c(c2);
                          c5 = null;
                        } 
                        d5.c(c3);
                        d4 = d5;
                        c4 = c5;
                      } 
                    } 
                    c3 = c3.I1();
                    c2 = c4;
                    d3 = d4;
                  } 
                  d2 = d3;
                  if (k == 1)
                    continue; 
                } 
              } 
            } 
            c2 = h.b(d2);
            dbxyzptlk.z0.d d1 = d2;
          } 
        } 
        if ((c1.H1() & i) != 0)
          c1 = c1.I1(); 
      } 
    } 
  }
  
  public final int n0() {
    return a0().B1();
  }
  
  public final void n1(f paramf) {
    e e = paramf.U();
    if (h.a[e.ordinal()] == 1) {
      if (paramf.W()) {
        i1(paramf, true, false, 2, null);
      } else {
        if (paramf.V())
          paramf.f1(true); 
        if (paramf.b0()) {
          m1(paramf, true, false, 2, null);
        } else if (paramf.T()) {
          paramf.j1(true);
        } 
      } 
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Unexpected state ");
    stringBuilder.append(paramf.U());
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public int o0() {
    return this.b;
  }
  
  public final void o1() {
    this.A.y();
  }
  
  public final z p0() {
    return this.B;
  }
  
  public final void p1() {
    dbxyzptlk.z0.d<f> d1 = u0();
    int i = d1.p();
    if (i > 0) {
      int m;
      Object[] arrayOfObject = d1.o();
      int k = 0;
      do {
        f f1 = (f)arrayOfObject[k];
        g g1 = f1.y;
        f1.x = g1;
        if (g1 != g.NotUsed)
          f1.p1(); 
        m = k + 1;
        k = m;
      } while (m < i);
    } 
  }
  
  public K1 q0() {
    return this.v;
  }
  
  public final void q1(boolean paramBoolean) {
    this.z = paramBoolean;
  }
  
  public int r0() {
    return this.layoutDelegate.I();
  }
  
  public final void r1(boolean paramBoolean) {
    this.D = paramBoolean;
  }
  
  public final void s1(AndroidViewHolder paramAndroidViewHolder) {
    this.l = paramAndroidViewHolder;
  }
  
  public final void t(Owner paramOwner) {
    // Byte code:
    //   0: aload_0
    //   1: getfield k : Landroidx/compose/ui/node/Owner;
    //   4: astore #5
    //   6: iconst_0
    //   7: istore_3
    //   8: aconst_null
    //   9: astore #7
    //   11: aconst_null
    //   12: astore #6
    //   14: aload #5
    //   16: ifnonnull -> 549
    //   19: aload_0
    //   20: getfield j : Landroidx/compose/ui/node/f;
    //   23: astore #5
    //   25: aload #5
    //   27: ifnull -> 197
    //   30: aload #5
    //   32: ifnull -> 45
    //   35: aload #5
    //   37: getfield k : Landroidx/compose/ui/node/Owner;
    //   40: astore #5
    //   42: goto -> 48
    //   45: aconst_null
    //   46: astore #5
    //   48: aload #5
    //   50: aload_1
    //   51: invokestatic c : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   54: ifeq -> 60
    //   57: goto -> 197
    //   60: new java/lang/StringBuilder
    //   63: dup
    //   64: invokespecial <init> : ()V
    //   67: astore #5
    //   69: aload #5
    //   71: ldc_w 'Attaching to a different owner('
    //   74: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   77: pop
    //   78: aload #5
    //   80: aload_1
    //   81: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   84: pop
    //   85: aload #5
    //   87: ldc_w ') than the parent's owner('
    //   90: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   93: pop
    //   94: aload_0
    //   95: invokevirtual m0 : ()Landroidx/compose/ui/node/f;
    //   98: astore_1
    //   99: aload_1
    //   100: ifnull -> 111
    //   103: aload_1
    //   104: getfield k : Landroidx/compose/ui/node/Owner;
    //   107: astore_1
    //   108: goto -> 113
    //   111: aconst_null
    //   112: astore_1
    //   113: aload #5
    //   115: aload_1
    //   116: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   119: pop
    //   120: aload #5
    //   122: ldc_w '). This tree: '
    //   125: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   128: pop
    //   129: aload #5
    //   131: aload_0
    //   132: iconst_0
    //   133: iconst_1
    //   134: aconst_null
    //   135: invokestatic x : (Landroidx/compose/ui/node/f;IILjava/lang/Object;)Ljava/lang/String;
    //   138: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   141: pop
    //   142: aload #5
    //   144: ldc_w ' Parent tree: '
    //   147: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   150: pop
    //   151: aload_0
    //   152: getfield j : Landroidx/compose/ui/node/f;
    //   155: astore #7
    //   157: aload #6
    //   159: astore_1
    //   160: aload #7
    //   162: ifnull -> 174
    //   165: aload #7
    //   167: iconst_0
    //   168: iconst_1
    //   169: aconst_null
    //   170: invokestatic x : (Landroidx/compose/ui/node/f;IILjava/lang/Object;)Ljava/lang/String;
    //   173: astore_1
    //   174: aload #5
    //   176: aload_1
    //   177: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   180: pop
    //   181: new java/lang/IllegalStateException
    //   184: dup
    //   185: aload #5
    //   187: invokevirtual toString : ()Ljava/lang/String;
    //   190: invokevirtual toString : ()Ljava/lang/String;
    //   193: invokespecial <init> : (Ljava/lang/String;)V
    //   196: athrow
    //   197: aload_0
    //   198: invokevirtual m0 : ()Landroidx/compose/ui/node/f;
    //   201: astore #8
    //   203: aload #8
    //   205: ifnonnull -> 233
    //   208: aload_0
    //   209: invokevirtual a0 : ()Landroidx/compose/ui/node/g$b;
    //   212: iconst_1
    //   213: invokevirtual W1 : (Z)V
    //   216: aload_0
    //   217: invokevirtual X : ()Landroidx/compose/ui/node/g$a;
    //   220: astore #5
    //   222: aload #5
    //   224: ifnull -> 233
    //   227: aload #5
    //   229: iconst_1
    //   230: invokevirtual R1 : (Z)V
    //   233: aload_0
    //   234: invokevirtual j0 : ()Landroidx/compose/ui/node/n;
    //   237: astore #6
    //   239: aload #7
    //   241: astore #5
    //   243: aload #8
    //   245: ifnull -> 255
    //   248: aload #8
    //   250: invokevirtual N : ()Landroidx/compose/ui/node/n;
    //   253: astore #5
    //   255: aload #6
    //   257: aload #5
    //   259: invokevirtual S2 : (Landroidx/compose/ui/node/n;)V
    //   262: aload_0
    //   263: aload_1
    //   264: putfield k : Landroidx/compose/ui/node/Owner;
    //   267: aload #8
    //   269: ifnull -> 281
    //   272: aload #8
    //   274: getfield m : I
    //   277: istore_2
    //   278: goto -> 283
    //   281: iconst_m1
    //   282: istore_2
    //   283: aload_0
    //   284: iload_2
    //   285: iconst_1
    //   286: iadd
    //   287: putfield m : I
    //   290: aload_0
    //   291: getfield A : Landroidx/compose/ui/node/l;
    //   294: bipush #8
    //   296: invokestatic a : (I)I
    //   299: invokevirtual r : (I)Z
    //   302: ifeq -> 309
    //   305: aload_0
    //   306: invokevirtual G0 : ()V
    //   309: aload_1
    //   310: aload_0
    //   311: invokeinterface w : (Landroidx/compose/ui/node/f;)V
    //   316: aload_0
    //   317: getfield d : Z
    //   320: ifeq -> 331
    //   323: aload_0
    //   324: aload_0
    //   325: invokevirtual u1 : (Landroidx/compose/ui/node/f;)V
    //   328: goto -> 370
    //   331: aload_0
    //   332: getfield j : Landroidx/compose/ui/node/f;
    //   335: astore #5
    //   337: aload #5
    //   339: ifnull -> 358
    //   342: aload #5
    //   344: getfield e : Landroidx/compose/ui/node/f;
    //   347: astore #6
    //   349: aload #6
    //   351: astore #5
    //   353: aload #6
    //   355: ifnonnull -> 364
    //   358: aload_0
    //   359: getfield e : Landroidx/compose/ui/node/f;
    //   362: astore #5
    //   364: aload_0
    //   365: aload #5
    //   367: invokevirtual u1 : (Landroidx/compose/ui/node/f;)V
    //   370: aload_0
    //   371: invokevirtual J0 : ()Z
    //   374: ifne -> 384
    //   377: aload_0
    //   378: getfield A : Landroidx/compose/ui/node/l;
    //   381: invokevirtual t : ()V
    //   384: aload_0
    //   385: getfield g : Ldbxyzptlk/f1/H;
    //   388: invokevirtual f : ()Ldbxyzptlk/z0/d;
    //   391: astore #5
    //   393: aload #5
    //   395: invokevirtual p : ()I
    //   398: istore #4
    //   400: iload #4
    //   402: ifle -> 437
    //   405: aload #5
    //   407: invokevirtual o : ()[Ljava/lang/Object;
    //   410: astore #5
    //   412: iload_3
    //   413: istore_2
    //   414: aload #5
    //   416: iload_2
    //   417: aaload
    //   418: checkcast androidx/compose/ui/node/f
    //   421: aload_1
    //   422: invokevirtual t : (Landroidx/compose/ui/node/Owner;)V
    //   425: iload_2
    //   426: iconst_1
    //   427: iadd
    //   428: istore_3
    //   429: iload_3
    //   430: istore_2
    //   431: iload_3
    //   432: iload #4
    //   434: if_icmplt -> 414
    //   437: aload_0
    //   438: invokevirtual J0 : ()Z
    //   441: ifne -> 451
    //   444: aload_0
    //   445: getfield A : Landroidx/compose/ui/node/l;
    //   448: invokevirtual z : ()V
    //   451: aload_0
    //   452: invokevirtual E0 : ()V
    //   455: aload #8
    //   457: ifnull -> 465
    //   460: aload #8
    //   462: invokevirtual E0 : ()V
    //   465: aload_0
    //   466: invokevirtual j0 : ()Landroidx/compose/ui/node/n;
    //   469: astore #5
    //   471: aload_0
    //   472: invokevirtual N : ()Landroidx/compose/ui/node/n;
    //   475: invokevirtual p2 : ()Landroidx/compose/ui/node/n;
    //   478: astore #6
    //   480: aload #5
    //   482: aload #6
    //   484: invokestatic c : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   487: ifne -> 510
    //   490: aload #5
    //   492: ifnull -> 510
    //   495: aload #5
    //   497: invokevirtual F2 : ()V
    //   500: aload #5
    //   502: invokevirtual p2 : ()Landroidx/compose/ui/node/n;
    //   505: astore #5
    //   507: goto -> 480
    //   510: aload_0
    //   511: getfield F : Ldbxyzptlk/CI/l;
    //   514: astore #5
    //   516: aload #5
    //   518: ifnull -> 530
    //   521: aload #5
    //   523: aload_1
    //   524: invokeinterface invoke : (Ljava/lang/Object;)Ljava/lang/Object;
    //   529: pop
    //   530: aload_0
    //   531: getfield layoutDelegate : Landroidx/compose/ui/node/g;
    //   534: invokevirtual W : ()V
    //   537: aload_0
    //   538: invokevirtual J0 : ()Z
    //   541: ifne -> 548
    //   544: aload_0
    //   545: invokevirtual A0 : ()V
    //   548: return
    //   549: new java/lang/StringBuilder
    //   552: dup
    //   553: invokespecial <init> : ()V
    //   556: astore_1
    //   557: aload_1
    //   558: ldc_w 'Cannot attach '
    //   561: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   564: pop
    //   565: aload_1
    //   566: aload_0
    //   567: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   570: pop
    //   571: aload_1
    //   572: ldc_w ' as it already is attached.  Tree: '
    //   575: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   578: pop
    //   579: aload_1
    //   580: aload_0
    //   581: iconst_0
    //   582: iconst_1
    //   583: aconst_null
    //   584: invokestatic x : (Landroidx/compose/ui/node/f;IILjava/lang/Object;)Ljava/lang/String;
    //   587: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   590: pop
    //   591: new java/lang/IllegalStateException
    //   594: dup
    //   595: aload_1
    //   596: invokevirtual toString : ()Ljava/lang/String;
    //   599: invokevirtual toString : ()Ljava/lang/String;
    //   602: invokespecial <init> : (Ljava/lang/String;)V
    //   605: athrow
  }
  
  public final dbxyzptlk.z0.d<f> t0() {
    if (this.q) {
      this.p.i();
      dbxyzptlk.z0.d<f> d1 = this.p;
      dbxyzptlk.z0.d<f> d2 = u0();
      d1.d(d1.p(), d2);
      this.p.I(O);
      this.q = false;
    } 
    return this.p;
  }
  
  public final void t1(g paramg) {
    this.x = paramg;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(u0.a(this, null));
    stringBuilder.append(" children: ");
    stringBuilder.append(F().size());
    stringBuilder.append(" measurePolicy: ");
    stringBuilder.append(c0());
    return stringBuilder.toString();
  }
  
  public final void u() {
    this.y = this.x;
    this.x = g.NotUsed;
    dbxyzptlk.z0.d<f> d1 = u0();
    int i = d1.p();
    if (i > 0) {
      int m;
      Object[] arrayOfObject = d1.o();
      int k = 0;
      do {
        f f1 = (f)arrayOfObject[k];
        if (f1.x != g.NotUsed)
          f1.u(); 
        m = k + 1;
        k = m;
      } while (m < i);
    } 
  }
  
  public final dbxyzptlk.z0.d<f> u0() {
    dbxyzptlk.z0.d<f> d1;
    A1();
    if (this.f == 0) {
      d1 = this.g.f();
    } else {
      d1 = this.h;
      s.e(d1);
    } 
    return d1;
  }
  
  public final void u1(f paramf) {
    if (!s.c(paramf, this.e)) {
      this.e = paramf;
      if (paramf != null) {
        this.layoutDelegate.q();
        n n1 = j0();
        n n2 = N().p2();
        while (!s.c(n1, n2) && n1 != null) {
          n1.a2();
          n1 = n1.p2();
        } 
      } 
      E0();
    } 
  }
  
  public final void v() {
    this.y = this.x;
    this.x = g.NotUsed;
    dbxyzptlk.z0.d<f> d1 = u0();
    int i = d1.p();
    if (i > 0) {
      int m;
      Object[] arrayOfObject = d1.o();
      int k = 0;
      do {
        f f1 = (f)arrayOfObject[k];
        if (f1.x == g.InLayoutBlock)
          f1.v(); 
        m = k + 1;
        k = m;
      } while (m < i);
    } 
  }
  
  public final void v0(long paramLong, q paramq, boolean paramBoolean1, boolean paramBoolean2) {
    paramLong = j0().c2(paramLong);
    j0().x2(n.B.a(), paramLong, paramq, paramBoolean1, paramBoolean2);
  }
  
  public final void v1(boolean paramBoolean) {
    this.H = paramBoolean;
  }
  
  public final String w(int paramInt) {
    StringBuilder stringBuilder = new StringBuilder();
    int i;
    for (i = 0; i < paramInt; i++)
      stringBuilder.append("  "); 
    stringBuilder.append("|-");
    stringBuilder.append(toString());
    stringBuilder.append('\n');
    dbxyzptlk.z0.d<f> d1 = u0();
    int k = d1.p();
    if (k > 0) {
      int m;
      Object[] arrayOfObject = d1.o();
      i = 0;
      do {
        stringBuilder.append(((f)arrayOfObject[i]).w(paramInt + 1));
        m = i + 1;
        i = m;
      } while (m < k);
    } 
    String str2 = stringBuilder.toString();
    String str1 = str2;
    if (paramInt == 0) {
      str1 = str2.substring(0, str2.length() - 1);
      s.g(str1, "this as java.lang.String…ing(startIndex, endIndex)");
    } 
    return str1;
  }
  
  public final void w1(l<? super Owner, D> paraml) {
    this.F = paraml;
  }
  
  public final void x0(long paramLong, q paramq, boolean paramBoolean1, boolean paramBoolean2) {
    paramLong = j0().c2(paramLong);
    j0().x2(n.B.b(), paramLong, paramq, true, paramBoolean2);
  }
  
  public final void x1(l<? super Owner, D> paraml) {
    this.G = paraml;
  }
  
  public final void y() {
    StringBuilder stringBuilder;
    Owner owner = this.k;
    String str = null;
    if (owner == null) {
      stringBuilder = new StringBuilder();
      stringBuilder.append("Cannot detach node that is already detached!  Tree: ");
      f f2 = m0();
      if (f2 != null)
        str = x(f2, 0, 1, null); 
      stringBuilder.append(str);
      throw new IllegalStateException(stringBuilder.toString().toString());
    } 
    B0();
    f f1 = m0();
    if (f1 != null) {
      f1.C0();
      f1.E0();
      g.b b1 = a0();
      g g1 = g.NotUsed;
      b1.V1(g1);
      g.a a2 = X();
      if (a2 != null)
        a2.P1(g1); 
    } 
    this.layoutDelegate.S();
    l<? super Owner, D> l1 = this.G;
    if (l1 != null)
      l1.invoke(stringBuilder); 
    if (this.A.r(K.a(8)))
      G0(); 
    this.A.A();
    s(this, true);
    dbxyzptlk.z0.d d1 = this.g.f();
    int i = d1.p();
    if (i > 0) {
      int m;
      Object[] arrayOfObject = d1.o();
      int k = 0;
      do {
        ((f)arrayOfObject[k]).y();
        m = k + 1;
        k = m;
      } while (m < i);
    } 
    s(this, false);
    this.A.u();
    stringBuilder.z(this);
    this.k = null;
    u1(null);
    this.m = 0;
    a0().P1();
    g.a a1 = X();
    if (a1 != null)
      a1.K1(); 
  }
  
  public void y1(int paramInt) {
    this.b = paramInt;
  }
  
  public final void z() {
    if (U() == e.Idle && !T() && !b0() && !J0()) {
      if (!h())
        return; 
      l l1 = this.A;
      int i = K.a(256);
      if ((l.c(l1) & i) != 0) {
        androidx.compose.ui.d.c c1 = l1.k();
        while (c1 != null) {
          if ((c1.M1() & i) != 0) {
            androidx.compose.ui.d.c c2 = c1;
            l1 = null;
            while (c2 != null) {
              dbxyzptlk.z0.d d2;
              if (c2 instanceof p) {
                p p = (p)c2;
                p.x(h.h((dbxyzptlk.f1.g)p, K.a(256)));
                l l2 = l1;
              } else {
                l l2 = l1;
                if ((c2.M1() & i) != 0) {
                  l2 = l1;
                  if (c2 instanceof dbxyzptlk.f1.i) {
                    dbxyzptlk.z0.d d3;
                    androidx.compose.ui.d.c c3 = ((dbxyzptlk.f1.i)c2).l2();
                    int k;
                    for (k = 0; c3 != null; k = m) {
                      dbxyzptlk.z0.d d4;
                      androidx.compose.ui.d.c c4 = c2;
                      l l3 = l1;
                      int m = k;
                      if ((c3.M1() & i) != 0) {
                        m = k + 1;
                        if (m == 1) {
                          c4 = c3;
                          l3 = l1;
                        } else {
                          dbxyzptlk.z0.d d5;
                          l l4 = l1;
                          if (l1 == null)
                            d5 = new dbxyzptlk.z0.d((Object[])new androidx.compose.ui.d.c[16], 0); 
                          androidx.compose.ui.d.c c5 = c2;
                          if (c2 != null) {
                            d5.c(c2);
                            c5 = null;
                          } 
                          d5.c(c3);
                          d4 = d5;
                          c4 = c5;
                        } 
                      } 
                      c3 = c3.I1();
                      c2 = c4;
                      d3 = d4;
                    } 
                    d2 = d3;
                    if (k == 1)
                      continue; 
                  } 
                } 
              } 
              c2 = h.b(d2);
              dbxyzptlk.z0.d d1 = d2;
            } 
          } 
          if ((c1.H1() & i) != 0)
            c1 = c1.I1(); 
        } 
      } 
    } 
  }
  
  public final void z0(int paramInt, f paramf) {
    g g1;
    String str;
    StringBuilder stringBuilder2;
    f f1 = paramf.j;
    Owner owner = null;
    if (f1 == null) {
      if (paramf.k == null) {
        paramf.j = this;
        this.g.a(paramInt, paramf);
        X0();
        if (paramf.a)
          this.f++; 
        H0();
        owner = this.k;
        if (owner != null)
          paramf.t(owner); 
        if (paramf.layoutDelegate.s() > 0) {
          g1 = this.layoutDelegate;
          g1.T(g1.s() + 1);
        } 
        return;
      } 
      stringBuilder2 = new StringBuilder();
      stringBuilder2.append("Cannot insert ");
      stringBuilder2.append(g1);
      stringBuilder2.append(" because it already has an owner. This tree: ");
      stringBuilder2.append(x(this, 0, 1, null));
      stringBuilder2.append(" Other tree: ");
      stringBuilder2.append(x((f)g1, 0, 1, null));
      throw new IllegalStateException(stringBuilder2.toString().toString());
    } 
    StringBuilder stringBuilder3 = new StringBuilder();
    stringBuilder3.append("Cannot insert ");
    stringBuilder3.append(g1);
    stringBuilder3.append(" because it already has a parent. This tree: ");
    stringBuilder3.append(x(this, 0, 1, null));
    stringBuilder3.append(" Other tree: ");
    f f2 = ((f)g1).j;
    StringBuilder stringBuilder1 = stringBuilder2;
    if (f2 != null)
      str = x(f2, 0, 1, null); 
    stringBuilder3.append(str);
    throw new IllegalStateException(stringBuilder3.toString().toString());
  }
  
  public final void z1(z paramz) {
    this.B = paramz;
  }
  
  @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"Landroidx/compose/ui/node/f;", "b", "()Landroidx/compose/ui/node/f;"}, k = 3, mv = {1, 8, 0})
  public static final class a extends u implements dbxyzptlk.CI.a<f> {
    public static final a f = new a();
    
    public a() {
      super(0);
    }
    
    public final f b() {
      return new f(false, 0, 3, null);
    }
  }
  
  @Metadata(d1 = {"\000!\n\000\n\002\030\002\n\002\020\t\n\002\b\007\n\002\020\007\n\002\b\003\n\002\030\002\n\002\b\003*\001\000\b\n\030\0002\0020\001R\024\020\005\032\0020\0028VX\004¢\006\006\032\004\b\003\020\004R\024\020\007\032\0020\0028VX\004¢\006\006\032\004\b\006\020\004R\024\020\t\032\0020\0028VX\004¢\006\006\032\004\b\b\020\004R\024\020\r\032\0020\n8VX\004¢\006\006\032\004\b\013\020\fR\032\020\020\032\0020\0168VX\004ø\001\000ø\001\001¢\006\006\032\004\b\017\020\004\002\013\n\005\b¡\0360\001\n\002\b!¨\006\021"}, d2 = {"androidx/compose/ui/node/f$b", "Ldbxyzptlk/g1/K1;", "", "d", "()J", "longPressTimeoutMillis", "c", "doubleTapTimeoutMillis", "a", "doubleTapMinTimeMillis", "", "b", "()F", "touchSlop", "Ldbxyzptlk/z1/k;", "e", "minimumTouchTargetSize", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class b implements K1 {
    public long a() {
      return 40L;
    }
    
    public float b() {
      return 16.0F;
    }
    
    public long c() {
      return 300L;
    }
    
    public long d() {
      return 400L;
    }
    
    public long e() {
      return k.b.b();
    }
  }
  
  @Metadata(d1 = {"\000%\n\000\n\002\030\002\n\002\030\002\n\002\020 \n\002\030\002\n\000\n\002\030\002\n\000\n\002\020\001\n\002\b\003*\001\000\b\n\030\0002\0020\001J,\020\t\032\0020\b*\0020\0022\f\020\005\032\b\022\004\022\0020\0040\0032\006\020\007\032\0020\006H\026ø\001\000¢\006\004\b\t\020\n\002\007\n\005\b¡\0360\001¨\006\013"}, d2 = {"androidx/compose/ui/node/f$c", "Landroidx/compose/ui/node/f$f;", "Ldbxyzptlk/d1/I;", "", "Ldbxyzptlk/d1/F;", "measurables", "Ldbxyzptlk/z1/b;", "constraints", "", "n", "(Ldbxyzptlk/d1/I;Ljava/util/List;J)Ljava/lang/Void;", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class c extends f {
    public c() {
      super("Undefined intrinsics block and it is required");
    }
    
    public Void n(I param1I, List<? extends F> param1List, long param1Long) {
      throw new IllegalStateException("Undefined measure and it is required");
    }
  }
  
  @Metadata(d1 = {"\0000\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\002\n\002\020\b\n\002\b\003\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003R \020\006\032\b\022\004\022\0020\0050\0048\000X\004¢\006\f\n\004\b\006\020\007\032\004\b\b\020\tR \020\013\032\b\022\004\022\0020\0050\n8\000X\004¢\006\f\n\004\b\013\020\f\032\004\b\r\020\016R\024\020\020\032\0020\0178\002X\004¢\006\006\n\004\b\020\020\021R\024\020\023\032\0020\0228\000XT¢\006\006\n\004\b\023\020\024¨\006\025"}, d2 = {"Landroidx/compose/ui/node/f$d;", "", "<init>", "()V", "Lkotlin/Function0;", "Landroidx/compose/ui/node/f;", "Constructor", "Ldbxyzptlk/CI/a;", "a", "()Ldbxyzptlk/CI/a;", "Ljava/util/Comparator;", "ZComparator", "Ljava/util/Comparator;", "b", "()Ljava/util/Comparator;", "Landroidx/compose/ui/node/f$f;", "ErrorMeasurePolicy", "Landroidx/compose/ui/node/f$f;", "", "NotPlacedPlaceOrder", "I", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class d {
    public d() {}
    
    public final dbxyzptlk.CI.a<f> a() {
      return f.q();
    }
    
    public final Comparator<f> b() {
      return f.r();
    }
  }
  
  @Metadata(d1 = {"\000\f\n\002\030\002\n\002\020\020\n\002\b\b\b\001\030\0002\b\022\004\022\0020\0000\001B\t\b\002¢\006\004\b\002\020\003j\002\b\004j\002\b\005j\002\b\006j\002\b\007j\002\b\b¨\006\t"}, d2 = {"Landroidx/compose/ui/node/f$e;", "", "<init>", "(Ljava/lang/String;I)V", "Measuring", "LookaheadMeasuring", "LayingOut", "LookaheadLayingOut", "Idle", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public enum e {
    Idle, LayingOut, LookaheadLayingOut, LookaheadMeasuring, Measuring;
    
    private static final e[] $VALUES;
    
    static {
      LayingOut = new e("LayingOut", 2);
      LookaheadLayingOut = new e("LookaheadLayingOut", 3);
      Idle = new e("Idle", 4);
      $VALUES = a();
    }
  }
  
  @Metadata(d1 = {"\000,\n\002\030\002\n\002\030\002\n\002\020\016\n\002\b\003\n\002\030\002\n\002\020 \n\002\030\002\n\000\n\002\020\b\n\000\n\002\020\001\n\002\b\t\b \030\0002\0020\001B\017\022\006\020\003\032\0020\002¢\006\004\b\004\020\005J)\020\r\032\0020\f*\0020\0062\f\020\t\032\b\022\004\022\0020\b0\0072\006\020\013\032\0020\nH\026¢\006\004\b\r\020\016J)\020\020\032\0020\f*\0020\0062\f\020\t\032\b\022\004\022\0020\b0\0072\006\020\017\032\0020\nH\026¢\006\004\b\020\020\016J)\020\021\032\0020\f*\0020\0062\f\020\t\032\b\022\004\022\0020\b0\0072\006\020\013\032\0020\nH\026¢\006\004\b\021\020\016J)\020\022\032\0020\f*\0020\0062\f\020\t\032\b\022\004\022\0020\b0\0072\006\020\017\032\0020\nH\026¢\006\004\b\022\020\016R\024\020\003\032\0020\0028\002X\004¢\006\006\n\004\b\023\020\024¨\006\025"}, d2 = {"Landroidx/compose/ui/node/f$f;", "Ldbxyzptlk/d1/G;", "", "error", "<init>", "(Ljava/lang/String;)V", "Ldbxyzptlk/d1/n;", "", "Ldbxyzptlk/d1/m;", "measurables", "", "height", "", "m", "(Ldbxyzptlk/d1/n;Ljava/util/List;I)Ljava/lang/Void;", "width", "l", "k", "j", "a", "Ljava/lang/String;", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static abstract class f implements G {
    public final String a;
    
    public f(String param1String) {
      this.a = param1String;
    }
    
    public Void j(n param1n, List<? extends m> param1List, int param1Int) {
      throw new IllegalStateException(this.a.toString());
    }
    
    public Void k(n param1n, List<? extends m> param1List, int param1Int) {
      throw new IllegalStateException(this.a.toString());
    }
    
    public Void l(n param1n, List<? extends m> param1List, int param1Int) {
      throw new IllegalStateException(this.a.toString());
    }
    
    public Void m(n param1n, List<? extends m> param1List, int param1Int) {
      throw new IllegalStateException(this.a.toString());
    }
  }
  
  @Metadata(d1 = {"\000\f\n\002\030\002\n\002\020\020\n\002\b\006\b\001\030\0002\b\022\004\022\0020\0000\001B\t\b\002¢\006\004\b\002\020\003j\002\b\004j\002\b\005j\002\b\006¨\006\007"}, d2 = {"Landroidx/compose/ui/node/f$g;", "", "<init>", "(Ljava/lang/String;I)V", "InMeasureBlock", "InLayoutBlock", "NotUsed", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public enum g {
    InLayoutBlock, InMeasureBlock, NotUsed;
    
    private static final g[] $VALUES;
    
    static {
      $VALUES = a();
    }
  }
  
  class f {}
  
  @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"Ldbxyzptlk/pI/D;", "b", "()V"}, k = 3, mv = {1, 8, 0})
  public static final class i extends u implements dbxyzptlk.CI.a<D> {
    public final f f;
    
    public i(f param1f) {
      super(0);
    }
    
    public final void b() {
      this.f.S().K();
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compos\\ui\node\f.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */