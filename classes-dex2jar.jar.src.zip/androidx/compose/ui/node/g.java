package androidx.compose.ui.node;

import dbxyzptlk.CI.l;
import dbxyzptlk.DI.s;
import dbxyzptlk.DI.u;
import dbxyzptlk.d1.F;
import dbxyzptlk.d1.Y;
import dbxyzptlk.f1.A;
import dbxyzptlk.f1.D;
import dbxyzptlk.f1.E;
import dbxyzptlk.f1.U;
import dbxyzptlk.pI.D;
import dbxyzptlk.z1.n;
import dbxyzptlk.z1.r;
import dbxyzptlk.z1.s;
import java.util.List;
import java.util.Map;
import kotlin.Metadata;

@Metadata(d1 = {"\000^\n\002\030\002\n\002\020\000\n\002\030\002\n\002\b\003\n\002\030\002\n\000\n\002\030\002\n\002\b\020\n\002\020\013\n\002\b\006\n\002\030\002\n\002\b\025\n\002\020\b\n\002\b\025\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\006\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\013\n\002\030\002\n\002\b\005\b\000\030\0002\0020\001:\002\027\033B\017\022\006\020\003\032\0020\002¢\006\004\b\004\020\005J\032\020\t\032\0020\b2\006\020\007\032\0020\006H\002ø\001\000¢\006\004\b\t\020\nJ\032\020\013\032\0020\b2\006\020\007\032\0020\006H\002ø\001\000¢\006\004\b\013\020\nJ\017\020\f\032\0020\bH\000¢\006\004\b\f\020\rJ\017\020\016\032\0020\bH\000¢\006\004\b\016\020\rJ\017\020\017\032\0020\bH\000¢\006\004\b\017\020\rJ\017\020\020\032\0020\bH\000¢\006\004\b\020\020\rJ\r\020\021\032\0020\b¢\006\004\b\021\020\rJ\017\020\022\032\0020\bH\000¢\006\004\b\022\020\rJ\r\020\023\032\0020\b¢\006\004\b\023\020\rJ\r\020\024\032\0020\b¢\006\004\b\024\020\rJ\r\020\025\032\0020\b¢\006\004\b\025\020\rJ\r\020\026\032\0020\b¢\006\004\b\026\020\rR\024\020\003\032\0020\0028\002X\004¢\006\006\n\004\b\027\020\030R$\020\037\032\0020\0312\006\020\032\032\0020\0318\000@BX\016¢\006\f\n\004\b\033\020\034\032\004\b\035\020\036R$\020%\032\0020 2\006\020\032\032\0020 8\000@BX\016¢\006\f\n\004\b!\020\"\032\004\b#\020$R$\020(\032\0020\0312\006\020\032\032\0020\0318\000@BX\016¢\006\f\n\004\b&\020\034\032\004\b'\020\036R$\020+\032\0020\0312\006\020\032\032\0020\0318\000@BX\016¢\006\f\n\004\b)\020\034\032\004\b*\020\036R\026\020-\032\0020\0318\002@\002X\016¢\006\006\n\004\b,\020\034R$\0200\032\0020\0312\006\020\032\032\0020\0318\000@BX\016¢\006\f\n\004\b.\020\034\032\004\b/\020\036R$\0203\032\0020\0312\006\020\032\032\0020\0318\000@BX\016¢\006\f\n\004\b1\020\034\032\004\b2\020\036R\026\0205\032\0020\0318\002@\002X\016¢\006\006\n\004\b4\020\034R\026\0209\032\002068\002@\002X\016¢\006\006\n\004\b7\0208R\026\020;\032\002068\002@\002X\016¢\006\006\n\004\b:\0208R*\020A\032\0020\0312\006\020<\032\0020\0318\006@FX\016¢\006\022\n\004\b=\020\034\032\004\b>\020\036\"\004\b?\020@R*\020E\032\0020\0312\006\020<\032\0020\0318\006@FX\016¢\006\022\n\004\bB\020\034\032\004\bC\020\036\"\004\bD\020@R*\020K\032\002062\006\020<\032\002068\006@FX\016¢\006\022\n\004\bF\0208\032\004\bG\020H\"\004\bI\020JR\036\020Q\032\0060LR\0020\0008\000X\004¢\006\f\n\004\bM\020N\032\004\bO\020PR0\020W\032\b\030\0010RR\0020\0002\f\020\032\032\b\030\0010RR\0020\0008\000@BX\016¢\006\f\n\004\bS\020T\032\004\bU\020VR\034\020X\032\0020\0068\002@\002X\016ø\001\000ø\001\001¢\006\006\n\004\b\022\020\024R\032\020\\\032\b\022\004\022\0020\b0Y8\002X\004¢\006\006\n\004\bZ\020[R\021\020`\032\0020]8F¢\006\006\032\004\b^\020_R\031\020c\032\004\030\0010\0068Fø\001\000ø\001\001¢\006\006\032\004\ba\020bR\031\020e\032\004\030\0010\0068Fø\001\000ø\001\001¢\006\006\032\004\bd\020bR\024\020g\032\002068@X\004¢\006\006\032\004\bf\020HR\024\020h\032\002068@X\004¢\006\006\032\004\b8\020HR\024\020k\032\0020i8@X\004¢\006\006\032\004\bZ\020jR\026\020m\032\004\030\0010i8@X\004¢\006\006\032\004\bl\020j\002\013\n\005\b¡\0360\001\n\002\b!¨\006n"}, d2 = {"Landroidx/compose/ui/node/g;", "", "Landroidx/compose/ui/node/f;", "layoutNode", "<init>", "(Landroidx/compose/ui/node/f;)V", "Ldbxyzptlk/z1/b;", "constraints", "Ldbxyzptlk/pI/D;", "R", "(J)V", "Q", "L", "()V", "O", "M", "N", "P", "q", "W", "J", "S", "K", "a", "Landroidx/compose/ui/node/f;", "", "<set-?>", "b", "Z", "v", "()Z", "detachedFromParentLookaheadPass", "Landroidx/compose/ui/node/f$e;", "c", "Landroidx/compose/ui/node/f$e;", "A", "()Landroidx/compose/ui/node/f$e;", "layoutState", "d", "G", "measurePending", "e", "z", "layoutPending", "f", "layoutPendingForAlignment", "g", "D", "lookaheadMeasurePending", "h", "C", "lookaheadLayoutPending", "i", "lookaheadLayoutPendingForAlignment", "", "j", "I", "nextChildLookaheadPlaceOrder", "k", "nextChildPlaceOrder", "value", "l", "u", "V", "(Z)V", "coordinatesAccessedDuringPlacement", "m", "t", "U", "coordinatesAccessedDuringModifierPlacement", "n", "s", "()I", "T", "(I)V", "childrenAccessingCoordinatesDuringPlacement", "Landroidx/compose/ui/node/g$b;", "o", "Landroidx/compose/ui/node/g$b;", "F", "()Landroidx/compose/ui/node/g$b;", "measurePassDelegate", "Landroidx/compose/ui/node/g$a;", "p", "Landroidx/compose/ui/node/g$a;", "E", "()Landroidx/compose/ui/node/g$a;", "lookaheadPassDelegate", "performMeasureConstraints", "Lkotlin/Function0;", "r", "Ldbxyzptlk/CI/a;", "performMeasureBlock", "Landroidx/compose/ui/node/n;", "H", "()Landroidx/compose/ui/node/n;", "outerCoordinator", "x", "()Ldbxyzptlk/z1/b;", "lastConstraints", "y", "lastLookaheadConstraints", "w", "height", "width", "Ldbxyzptlk/f1/b;", "()Ldbxyzptlk/f1/b;", "alignmentLinesOwner", "B", "lookaheadAlignmentLinesOwner", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class g {
  public final f a;
  
  public boolean b;
  
  public f.e c;
  
  public boolean d;
  
  public boolean e;
  
  public boolean f;
  
  public boolean g;
  
  public boolean h;
  
  public boolean i;
  
  public int j;
  
  public int k;
  
  public boolean l;
  
  public boolean m;
  
  public int n;
  
  public final b o;
  
  public a p;
  
  public long q;
  
  public final dbxyzptlk.CI.a<D> r;
  
  public g(f paramf) {
    this.a = paramf;
    this.c = f.e.Idle;
    this.o = new b(this);
    this.q = dbxyzptlk.z1.c.b(0, 0, 0, 0, 15, null);
    this.r = new d(this);
  }
  
  public final f.e A() {
    return this.c;
  }
  
  public final dbxyzptlk.f1.b B() {
    return (dbxyzptlk.f1.b)this.p;
  }
  
  public final boolean C() {
    return this.h;
  }
  
  public final boolean D() {
    return this.g;
  }
  
  public final a E() {
    return this.p;
  }
  
  public final b F() {
    return this.o;
  }
  
  public final boolean G() {
    return this.d;
  }
  
  public final n H() {
    return this.a.i0().o();
  }
  
  public final int I() {
    return this.o.Q0();
  }
  
  public final void J() {
    this.o.H1();
    a a1 = this.p;
    if (a1 != null)
      a1.B1(); 
  }
  
  public final void K() {
    this.o.U1(true);
    a a1 = this.p;
    if (a1 != null)
      a1.O1(true); 
  }
  
  public final void L() {
    this.e = true;
    this.f = true;
  }
  
  public final void M() {
    this.h = true;
    this.i = true;
  }
  
  public final void N() {
    this.g = true;
  }
  
  public final void O() {
    this.d = true;
  }
  
  public final void P() {
    f.e e1 = this.a.U();
    if (e1 == f.e.LayingOut || e1 == f.e.LookaheadLayingOut)
      if (this.o.u1()) {
        V(true);
      } else {
        U(true);
      }  
    if (e1 == f.e.LookaheadLayingOut) {
      a a1 = this.p;
      if (a1 != null && a1.l1() == true) {
        V(true);
      } else {
        U(true);
      } 
    } 
  }
  
  public final void Q(long paramLong) {
    this.c = f.e.LookaheadMeasuring;
    this.g = false;
    U.h(D.b(this.a).getSnapshotObserver(), this.a, false, (dbxyzptlk.CI.a)new c(this, paramLong), 2, null);
    M();
    if (E.a(this.a)) {
      L();
    } else {
      O();
    } 
    this.c = f.e.Idle;
  }
  
  public final void R(long paramLong) {
    f.e e2 = this.c;
    f.e e1 = f.e.Idle;
    if (e2 == e1) {
      e2 = f.e.Measuring;
      this.c = e2;
      this.d = false;
      this.q = paramLong;
      D.b(this.a).getSnapshotObserver().g(this.a, false, this.r);
      if (this.c == e2) {
        L();
        this.c = e1;
      } 
      return;
    } 
    throw new IllegalStateException("layout state is not idle before measure starts");
  }
  
  public final void S() {
    this.o.d().p();
    a a1 = this.p;
    if (a1 != null) {
      dbxyzptlk.f1.a a2 = a1.d();
      if (a2 != null)
        a2.p(); 
    } 
  }
  
  public final void T(int paramInt) {
    int i = this.n;
    this.n = paramInt;
    byte b1 = 0;
    if (i == 0) {
      i = 1;
    } else {
      i = 0;
    } 
    if (paramInt == 0)
      b1 = 1; 
    if (i != b1) {
      f f1 = this.a.m0();
      if (f1 != null) {
        g g1 = f1.S();
      } else {
        f1 = null;
      } 
      if (f1 != null)
        if (paramInt == 0) {
          f1.T(((g)f1).n - 1);
        } else {
          f1.T(((g)f1).n + 1);
        }  
    } 
  }
  
  public final void U(boolean paramBoolean) {
    if (this.m != paramBoolean) {
      this.m = paramBoolean;
      if (paramBoolean && !this.l) {
        T(this.n + 1);
      } else if (!paramBoolean && !this.l) {
        T(this.n - 1);
      } 
    } 
  }
  
  public final void V(boolean paramBoolean) {
    if (this.l != paramBoolean) {
      this.l = paramBoolean;
      if (paramBoolean && !this.m) {
        T(this.n + 1);
      } else if (!paramBoolean && !this.m) {
        T(this.n - 1);
      } 
    } 
  }
  
  public final void W() {
    if (this.o.Y1()) {
      f f1 = this.a.m0();
      if (f1 != null)
        f.m1(f1, false, false, 3, null); 
    } 
    a a1 = this.p;
    if (a1 != null && a1.T1() == true)
      if (E.a(this.a)) {
        f f1 = this.a.m0();
        if (f1 != null)
          f.m1(f1, false, false, 3, null); 
      } else {
        f f1 = this.a.m0();
        if (f1 != null)
          f.i1(f1, false, false, 3, null); 
      }  
  }
  
  public final void q() {
    if (this.p == null)
      this.p = new a(this); 
  }
  
  public final dbxyzptlk.f1.b r() {
    return this.o;
  }
  
  public final int s() {
    return this.n;
  }
  
  public final boolean t() {
    return this.m;
  }
  
  public final boolean u() {
    return this.l;
  }
  
  public final boolean v() {
    return this.b;
  }
  
  public final int w() {
    return this.o.B0();
  }
  
  public final dbxyzptlk.z1.b x() {
    return this.o.t1();
  }
  
  public final dbxyzptlk.z1.b y() {
    a a1 = this.p;
    if (a1 != null) {
      dbxyzptlk.z1.b b1 = a1.k1();
    } else {
      a1 = null;
    } 
    return (dbxyzptlk.z1.b)a1;
  }
  
  public final boolean z() {
    return this.e;
  }
  
  class g {}
  
  @Metadata(d1 = {"\000\001\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\003\n\002\030\002\n\000\n\002\020\007\n\000\n\002\030\002\n\002\030\002\n\002\b\b\n\002\030\002\n\002\b\003\n\002\020\013\n\002\b\002\n\002\030\002\n\000\n\002\020\b\n\002\b\016\n\002\020$\n\002\b\033\n\002\030\002\n\002\b\025\n\002\020\000\n\002\b\f\n\002\030\002\n\002\b\005\n\002\030\002\n\002\030\002\n\002\b\t\n\002\030\002\n\002\b\022\n\002\030\002\n\002\b\003\n\002\020 \n\002\b\n\b\004\030\0002\0020\0012\0020\0022\0020\003B\007¢\006\004\b\004\020\005J\017\020\007\032\0020\006H\002¢\006\004\b\007\020\bJ\017\020\t\032\0020\006H\002¢\006\004\b\t\020\bJ\017\020\n\032\0020\006H\002¢\006\004\b\n\020\bJ\017\020\013\032\0020\006H\002¢\006\004\b\013\020\bJ\027\020\016\032\0020\0062\006\020\r\032\0020\fH\002¢\006\004\b\016\020\017J8\020\027\032\0020\0062\006\020\021\032\0020\0202\006\020\023\032\0020\0222\024\020\026\032\020\022\004\022\0020\025\022\004\022\0020\006\030\0010\024H\002ø\001\000¢\006\004\b\027\020\030J\017\020\031\032\0020\006H\002¢\006\004\b\031\020\bJ\017\020\032\032\0020\006H\002¢\006\004\b\032\020\bJ\017\020\033\032\0020\006H\000¢\006\004\b\033\020\bJ\017\020\034\032\0020\006H\026¢\006\004\b\034\020\bJ\017\020\035\032\0020\006H\000¢\006\004\b\035\020\bJ\032\020 \032\0020\0022\006\020\037\032\0020\036H\026ø\001\000¢\006\004\b \020!J\030\020#\032\0020\"2\006\020\037\032\0020\036ø\001\000¢\006\004\b#\020$J\030\020(\032\0020'2\006\020&\032\0020%H\002¢\006\004\b(\020)J8\020*\032\0020\0062\006\020\021\032\0020\0202\006\020\023\032\0020\0222\024\020\026\032\020\022\004\022\0020\025\022\004\022\0020\006\030\0010\024H\024ø\001\000¢\006\004\b*\020\030J\r\020+\032\0020\006¢\006\004\b+\020\bJ\027\020-\032\0020'2\006\020,\032\0020'H\026¢\006\004\b-\020.J\027\020/\032\0020'2\006\020,\032\0020'H\026¢\006\004\b/\020.J\027\0201\032\0020'2\006\0200\032\0020'H\026¢\006\004\b1\020.J\027\0202\032\0020'2\006\0200\032\0020'H\026¢\006\004\b2\020.J\r\0203\032\0020\006¢\006\004\b3\020\bJ\r\0204\032\0020\"¢\006\004\b4\0205J\033\0207\032\016\022\004\022\0020%\022\004\022\0020'06H\026¢\006\004\b7\0208J#\020:\032\0020\0062\022\0209\032\016\022\004\022\0020\003\022\004\022\0020\0060\024H\026¢\006\004\b:\020;J\017\020<\032\0020\006H\026¢\006\004\b<\020\bJ\017\020=\032\0020\006H\026¢\006\004\b=\020\bJ\r\020>\032\0020\006¢\006\004\b>\020\bJ\025\020@\032\0020\0062\006\020?\032\0020\"¢\006\004\b@\020AJ\r\020B\032\0020\006¢\006\004\bB\020\bR\026\020E\032\0020\"8\002@\002X\016¢\006\006\n\004\bC\020DR$\020K\032\0020'2\006\020F\032\0020'8\000@BX\016¢\006\f\n\004\bG\020H\032\004\bI\020JR$\020N\032\0020'2\006\020F\032\0020'8\000@BX\016¢\006\f\n\004\bL\020H\032\004\bM\020JR\026\020P\032\0020\"8\002@\002X\016¢\006\006\n\004\bO\020DR\026\020Q\032\0020\"8\002@\002X\016¢\006\006\n\004\b7\020DR\"\020Y\032\0020R8\000@\000X\016¢\006\022\n\004\bS\020T\032\004\bU\020V\"\004\bW\020XR\"\020\\\032\0020\"8\000@\000X\016¢\006\022\n\004\b:\020D\032\004\bZ\0205\"\004\b[\020AR\034\020_\032\0020\0208\002@\002X\016ø\001\000ø\001\001¢\006\006\n\004\b]\020^R$\020b\032\020\022\004\022\0020\025\022\004\022\0020\006\030\0010\0248\002@\002X\016¢\006\006\n\004\b`\020aR\026\020e\032\0020\0228\002@\002X\016¢\006\006\n\004\bc\020dR\026\020g\032\0020\"8\002@\002X\016¢\006\006\n\004\bf\020DR(\020m\032\004\030\0010h2\b\020F\032\004\030\0010h8\026@RX\016¢\006\f\n\004\bi\020j\032\004\bk\020lR*\020p\032\0020\"2\006\020F\032\0020\"8\026@PX\016¢\006\022\n\004\bn\020D\032\004\bL\0205\"\004\bo\020AR*\020t\032\0020\"2\006\020F\032\0020\"8\006@@X\016¢\006\022\n\004\bq\020D\032\004\br\0205\"\004\bs\020AR\032\020z\032\0020u8\026X\004¢\006\f\n\004\bv\020w\032\004\bx\020yR\036\020\032\f\022\b\022\0060\000R\0020|0{8\002X\004¢\006\006\n\004\b}\020~R%\020\001\032\0020\"8\000@\000X\016¢\006\024\n\004\b=\020D\032\005\b\001\0205\"\005\b\001\020AR'\020\001\032\0020\"2\006\020F\032\0020\"8\006@BX\016¢\006\016\n\005\b\001\020D\032\005\b\001\0205R\035\020\001\032\t\022\004\022\0020\0060\0018\002X\004¢\006\007\n\005\b2\020\001R'\020\023\032\0020\0222\006\020F\032\0020\0228\000@BX\016¢\006\017\n\005\b\001\020d\032\006\b\001\020\001R\030\020\001\032\0020\"8\002@\002X\016¢\006\007\n\005\b\001\020DR&\020\001\032\020\022\004\022\0020\025\022\004\022\0020\006\030\0010\0248\002@\002X\016¢\006\007\n\005\b\001\020aR\036\020\001\032\0020\0208\002@\002X\016ø\001\000ø\001\001¢\006\007\n\005\b\001\020^R\030\020\001\032\0020\0228\002@\002X\016¢\006\007\n\005\b\001\020dR\036\020\001\032\t\022\004\022\0020\0060\0018\002X\004¢\006\b\n\006\b\001\020\001R\034\020\001\032\004\030\0010\0368Fø\001\000ø\001\001¢\006\b\032\006\b\001\020\001R\030\020\001\032\0030\0018VX\004¢\006\b\032\006\b\001\020\001R\"\020 \001\032\r\022\b\022\0060\000R\0020|0\0018@X\004¢\006\b\032\006\b\001\020\001R\026\020¢\001\032\0020'8VX\004¢\006\007\032\005\b¡\001\020JR\026\020¤\001\032\0020'8VX\004¢\006\007\032\005\b£\001\020JR\030\020¦\001\032\004\030\0010\0038VX\004¢\006\007\032\005\bd\020¥\001\002\013\n\005\b¡\0360\001\n\002\b!¨\006§\001"}, d2 = {"Landroidx/compose/ui/node/g$b;", "Ldbxyzptlk/d1/F;", "Ldbxyzptlk/d1/Y;", "Ldbxyzptlk/f1/b;", "<init>", "(Landroidx/compose/ui/node/g;)V", "Ldbxyzptlk/pI/D;", "k1", "()V", "L1", "K1", "l1", "Landroidx/compose/ui/node/f;", "node", "X1", "(Landroidx/compose/ui/node/f;)V", "Ldbxyzptlk/z1/n;", "position", "", "zIndex", "Lkotlin/Function1;", "Landroidx/compose/ui/graphics/c;", "layerBlock", "R1", "(JFLdbxyzptlk/CI/l;)V", "O1", "N1", "J1", "M", "Q1", "Ldbxyzptlk/z1/b;", "constraints", "d0", "(J)Ldbxyzptlk/d1/Y;", "", "S1", "(J)Z", "Ldbxyzptlk/d1/a;", "alignmentLine", "", "E", "(Ldbxyzptlk/d1/a;)I", "T0", "T1", "height", "S", "(I)I", "U", "width", "N", "x", "H1", "Y1", "()Z", "", "j", "()Ljava/util/Map;", "block", "l", "(Ldbxyzptlk/CI/l;)V", "requestLayout", "v", "M1", "forceRequest", "G1", "(Z)V", "P1", "f", "Z", "relayoutWithoutParentInProgress", "<set-?>", "g", "I", "getPreviousPlaceOrder$ui_release", "()I", "previousPlaceOrder", "h", "B1", "placeOrder", "i", "measuredOnce", "placedOnce", "Landroidx/compose/ui/node/f$g;", "k", "Landroidx/compose/ui/node/f$g;", "w1", "()Landroidx/compose/ui/node/f$g;", "V1", "(Landroidx/compose/ui/node/f$g;)V", "measuredByParent", "getDuringAlignmentLinesQuery$ui_release", "setDuringAlignmentLinesQuery$ui_release", "duringAlignmentLinesQuery", "m", "J", "lastPosition", "n", "Ldbxyzptlk/CI/l;", "lastLayerBlock", "o", "F", "lastZIndex", "p", "parentDataDirty", "", "q", "Ljava/lang/Object;", "b", "()Ljava/lang/Object;", "parentData", "r", "W1", "isPlaced", "s", "I1", "setPlacedByParent$ui_release", "isPlacedByParent", "Ldbxyzptlk/f1/a;", "t", "Ldbxyzptlk/f1/a;", "d", "()Ldbxyzptlk/f1/a;", "alignmentLines", "Ldbxyzptlk/z0/d;", "Landroidx/compose/ui/node/g;", "u", "Ldbxyzptlk/z0/d;", "_childDelegates", "getChildDelegatesDirty$ui_release", "U1", "childDelegatesDirty", "w", "u1", "layingOutChildren", "Lkotlin/Function0;", "Ldbxyzptlk/CI/a;", "layoutChildrenBlock", "y", "C1", "()F", "z", "onNodePlacedCalled", "A", "placeOuterCoordinatorLayerBlock", "B", "placeOuterCoordinatorPosition", "C", "placeOuterCoordinatorZIndex", "D", "placeOuterCoordinatorBlock", "t1", "()Ldbxyzptlk/z1/b;", "lastConstraints", "Landroidx/compose/ui/node/n;", "P", "()Landroidx/compose/ui/node/n;", "innerCoordinator", "", "n1", "()Ljava/util/List;", "childDelegates", "K0", "measuredWidth", "F0", "measuredHeight", "()Ldbxyzptlk/f1/b;", "parentAlignmentLinesOwner", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public final class b extends Y implements F, dbxyzptlk.f1.b {
    public l<? super androidx.compose.ui.graphics.c, D> A;
    
    public long B;
    
    public float C;
    
    public final dbxyzptlk.CI.a<D> D;
    
    public final g E;
    
    public boolean f;
    
    public int g = Integer.MAX_VALUE;
    
    public int h = Integer.MAX_VALUE;
    
    public boolean i;
    
    public boolean j;
    
    public f.g k = f.g.NotUsed;
    
    public boolean l;
    
    public long m;
    
    public l<? super androidx.compose.ui.graphics.c, D> n;
    
    public float o;
    
    public boolean p;
    
    public Object q;
    
    public boolean r;
    
    public boolean s;
    
    public final dbxyzptlk.f1.a t;
    
    public final dbxyzptlk.z0.d<b> u;
    
    public boolean v;
    
    public boolean w;
    
    public final dbxyzptlk.CI.a<D> x;
    
    public float y;
    
    public boolean z;
    
    public b(g this$0) {
      n.a a1 = n.b;
      this.m = a1.a();
      this.p = true;
      this.t = (dbxyzptlk.f1.a)new A(this);
      this.u = new dbxyzptlk.z0.d((Object[])new b[16], 0);
      this.v = true;
      this.x = new b(this);
      this.B = a1.a();
      this.D = new c(this$0, this);
    }
    
    private final void K1() {
      boolean bool = h();
      W1(true);
      f f = g.a(this.E);
      int i = 0;
      if (!bool)
        if (f.b0()) {
          f.m1(f, true, false, 2, null);
        } else if (f.W()) {
          f.i1(f, true, false, 2, null);
        }  
      n n1 = f.j0();
      n n2 = f.N().p2();
      while (!s.c(n1, n2) && n1 != null) {
        if (n1.g2())
          n1.z2(); 
        n1 = n1.p2();
      } 
      dbxyzptlk.z0.d<f> d1 = f.u0();
      int j = d1.p();
      if (j > 0) {
        int k;
        Object[] arrayOfObject = d1.o();
        do {
          f f1 = (f)arrayOfObject[i];
          if (f1.n0() != Integer.MAX_VALUE) {
            f1.a0().K1();
            f.n1(f1);
          } 
          k = i + 1;
          i = k;
        } while (k < j);
      } 
    }
    
    private final void L1() {
      if (h()) {
        int i = 0;
        W1(false);
        dbxyzptlk.z0.d<f> d1 = g.a(this.E).u0();
        int j = d1.p();
        if (j > 0) {
          int k;
          Object[] arrayOfObject = d1.o();
          do {
            ((f)arrayOfObject[i]).a0().L1();
            k = i + 1;
            i = k;
          } while (k < j);
        } 
      } 
    }
    
    private final void N1() {
      f f = g.a(this.E);
      g g1 = this.E;
      dbxyzptlk.z0.d<f> d1 = f.u0();
      int i = d1.p();
      if (i > 0) {
        int k;
        Object[] arrayOfObject = d1.o();
        int j = 0;
        do {
          f f1 = (f)arrayOfObject[j];
          if (f1.b0() && f1.d0() == f.g.InMeasureBlock && f.b1(f1, null, 1, null))
            f.m1(g.a(g1), false, false, 3, null); 
          k = j + 1;
          j = k;
        } while (k < i);
      } 
    }
    
    private final void O1() {
      f.m1(g.a(this.E), false, false, 3, null);
      f f = g.a(this.E).m0();
      if (f != null && g.a(this.E).R() == f.g.NotUsed) {
        f.g g1;
        f f1 = g.a(this.E);
        f.e e = f.U();
        int i = a.a[e.ordinal()];
        if (i != 1) {
          if (i != 2) {
            g1 = f.R();
          } else {
            g1 = f.g.InLayoutBlock;
          } 
        } else {
          g1 = f.g.InMeasureBlock;
        } 
        f1.t1(g1);
      } 
    }
    
    private final void k1() {
      f f = g.a(this.E);
      dbxyzptlk.z0.d<f> d1 = f.u0();
      int i = d1.p();
      if (i > 0) {
        int k;
        Object[] arrayOfObject = d1.o();
        int j = 0;
        do {
          f f1 = (f)arrayOfObject[j];
          if ((f1.a0()).g != f1.n0()) {
            f.X0();
            f.C0();
            if (f1.n0() == Integer.MAX_VALUE)
              f1.a0().L1(); 
          } 
          k = j + 1;
          j = k;
        } while (k < i);
      } 
    }
    
    private final void l1() {
      g.p(this.E, 0);
      dbxyzptlk.z0.d<f> d1 = g.a(this.E).u0();
      int i = d1.p();
      if (i > 0) {
        int k;
        Object[] arrayOfObject = d1.o();
        int j = 0;
        do {
          b b1 = ((f)arrayOfObject[j]).a0();
          b1.g = b1.h;
          b1.h = Integer.MAX_VALUE;
          b1.s = false;
          if (b1.k == f.g.InLayoutBlock)
            b1.k = f.g.NotUsed; 
          k = j + 1;
          j = k;
        } while (k < i);
      } 
    }
    
    public final int B1() {
      return this.h;
    }
    
    public final float C1() {
      return this.y;
    }
    
    public int E(dbxyzptlk.d1.a param1a) {
      f f1 = g.a(this.E).m0();
      f f2 = null;
      if (f1 != null) {
        f.e e = f1.U();
      } else {
        f1 = null;
      } 
      if (f1 == f.e.Measuring) {
        d().u(true);
      } else {
        f.e e;
        f f = g.a(this.E).m0();
        f1 = f2;
        if (f != null)
          e = f.U(); 
        if (e == f.e.LayingOut)
          d().t(true); 
      } 
      this.l = true;
      int i = this.E.H().E(param1a);
      this.l = false;
      return i;
    }
    
    public dbxyzptlk.f1.b F() {
      null = g.a(this.E).m0();
      if (null != null) {
        g g1 = null.S();
        if (g1 != null)
          return g1.r(); 
      } 
      return null;
    }
    
    public int F0() {
      return this.E.H().F0();
    }
    
    public final void G1(boolean param1Boolean) {
      f f = g.a(this.E).m0();
      f.g g1 = g.a(this.E).R();
      if (f != null && g1 != f.g.NotUsed) {
        while (f.R() == g1) {
          f f1 = f.m0();
          if (f1 == null)
            break; 
          f = f1;
        } 
        int i = a.b[g1.ordinal()];
        if (i != 1) {
          if (i == 2) {
            f.j1(param1Boolean);
          } else {
            throw new IllegalStateException("Intrinsics isn't used by the parent");
          } 
        } else {
          f.m1(f, param1Boolean, false, 2, null);
        } 
      } 
    }
    
    public final void H1() {
      this.p = true;
    }
    
    public final boolean I1() {
      return this.s;
    }
    
    public final void J1() {
      g.i(this.E, true);
    }
    
    public int K0() {
      return this.E.H().K0();
    }
    
    public void M() {
      this.w = true;
      d().o();
      if (this.E.z())
        N1(); 
      if (g.b(this.E) || (!this.l && !P().n1() && this.E.z())) {
        g.j(this.E, false);
        f.e e = this.E.A();
        g.l(this.E, f.e.LayingOut);
        this.E.V(false);
        f f = g.a(this.E);
        D.b(f).getSnapshotObserver().e(f, false, this.x);
        g.l(this.E, e);
        if (P().n1() && this.E.u())
          requestLayout(); 
        g.k(this.E, false);
      } 
      if (d().l())
        d().q(true); 
      if (d().g() && d().k())
        d().n(); 
      this.w = false;
    }
    
    public final void M1() {
      if (this.E.s() > 0) {
        dbxyzptlk.z0.d<f> d1 = g.a(this.E).u0();
        int i = d1.p();
        if (i > 0) {
          int k;
          Object[] arrayOfObject = d1.o();
          int j = 0;
          do {
            f f = (f)arrayOfObject[j];
            g g1 = f.S();
            if ((g1.u() || g1.t()) && !g1.z())
              f.k1(f, false, 1, null); 
            g1.F().M1();
            k = j + 1;
            j = k;
          } while (k < i);
        } 
      } 
    }
    
    public int N(int param1Int) {
      O1();
      return this.E.H().N(param1Int);
    }
    
    public n P() {
      return g.a(this.E).N();
    }
    
    public final void P1() {
      this.h = Integer.MAX_VALUE;
      this.g = Integer.MAX_VALUE;
      W1(false);
    }
    
    public final void Q1() {
      this.z = true;
      f f1 = g.a(this.E).m0();
      float f = P().r2();
      f f2 = g.a(this.E);
      n n1 = f2.j0();
      n n2 = f2.N();
      while (n1 != n2) {
        s.f(n1, "null cannot be cast to non-null type androidx.compose.ui.node.LayoutModifierNodeCoordinator");
        n1 = n1;
        f += n1.r2();
        n1 = n1.p2();
      } 
      if (f != this.y) {
        this.y = f;
        if (f1 != null)
          f1.X0(); 
        if (f1 != null)
          f1.C0(); 
      } 
      if (!h()) {
        if (f1 != null)
          f1.C0(); 
        K1();
        if (this.f && f1 != null)
          f.k1(f1, false, 1, null); 
      } 
      if (f1 != null) {
        if (!this.f && f1.U() == f.e.LayingOut)
          if (this.h == Integer.MAX_VALUE) {
            this.h = g.e(f1.S());
            g g1 = f1.S();
            g.p(g1, g.e(g1) + 1);
          } else {
            throw new IllegalStateException("Place was called on a node which was placed already");
          }  
      } else {
        this.h = 0;
      } 
      M();
    }
    
    public final void R1(long param1Long, float param1Float, l<? super androidx.compose.ui.graphics.c, D> param1l) {
      if (!g.a(this.E).J0()) {
        g.l(this.E, f.e.LayingOut);
        this.m = param1Long;
        this.o = param1Float;
        this.n = param1l;
        this.j = true;
        this.z = false;
        Owner owner = D.b(g.a(this.E));
        if (!this.E.z() && h()) {
          this.E.H().M2(param1Long, param1Float, param1l);
          Q1();
        } else {
          d().r(false);
          this.E.U(false);
          this.A = param1l;
          this.B = param1Long;
          this.C = param1Float;
          owner.getSnapshotObserver().c(g.a(this.E), false, this.D);
          this.A = null;
        } 
        g.l(this.E, f.e.Idle);
        return;
      } 
      throw new IllegalArgumentException("place is called on a deactivated node");
    }
    
    public int S(int param1Int) {
      O1();
      return this.E.H().S(param1Int);
    }
    
    public final boolean S1(long param1Long) {
      if (!g.a(this.E).J0()) {
        Owner owner = D.b(g.a(this.E));
        f f2 = g.a(this.E).m0();
        f f1 = g.a(this.E);
        boolean bool = g.a(this.E).C();
        boolean bool1 = true;
        if (bool || (f2 != null && f2.C())) {
          bool = true;
        } else {
          bool = false;
        } 
        f1.q1(bool);
        if (g.a(this.E).b0() || !dbxyzptlk.z1.b.g(N0(), param1Long)) {
          d().s(false);
          l(d.f);
          this.i = true;
          long l1 = this.E.H().a();
          b1(param1Long);
          g.h(this.E, param1Long);
          bool = bool1;
          if (r.f(this.E.H().a(), l1)) {
            bool = bool1;
            if (this.E.H().Q0() == Q0())
              if (this.E.H().B0() != B0()) {
                bool = bool1;
              } else {
                bool = false;
              }  
          } 
          U0(s.a(this.E.H().Q0(), this.E.H().B0()));
          return bool;
        } 
        Owner.d(owner, g.a(this.E), false, 2, null);
        g.a(this.E).p1();
        return false;
      } 
      throw new IllegalArgumentException("measure is called on a deactivated node");
    }
    
    public void T0(long param1Long, float param1Float, l<? super androidx.compose.ui.graphics.c, D> param1l) {
      // Byte code:
      //   0: iconst_1
      //   1: istore #5
      //   3: aload_0
      //   4: iconst_1
      //   5: putfield s : Z
      //   8: lload_1
      //   9: aload_0
      //   10: getfield m : J
      //   13: invokestatic i : (JJ)Z
      //   16: ifne -> 51
      //   19: aload_0
      //   20: getfield E : Landroidx/compose/ui/node/g;
      //   23: invokevirtual t : ()Z
      //   26: ifne -> 39
      //   29: aload_0
      //   30: getfield E : Landroidx/compose/ui/node/g;
      //   33: invokevirtual u : ()Z
      //   36: ifeq -> 47
      //   39: aload_0
      //   40: getfield E : Landroidx/compose/ui/node/g;
      //   43: iconst_1
      //   44: invokestatic j : (Landroidx/compose/ui/node/g;Z)V
      //   47: aload_0
      //   48: invokevirtual M1 : ()V
      //   51: aload_0
      //   52: getfield E : Landroidx/compose/ui/node/g;
      //   55: invokestatic a : (Landroidx/compose/ui/node/g;)Landroidx/compose/ui/node/f;
      //   58: invokestatic a : (Landroidx/compose/ui/node/f;)Z
      //   61: ifeq -> 190
      //   64: aload_0
      //   65: getfield E : Landroidx/compose/ui/node/g;
      //   68: invokevirtual H : ()Landroidx/compose/ui/node/n;
      //   71: invokevirtual q2 : ()Landroidx/compose/ui/node/n;
      //   74: astore #6
      //   76: aload #6
      //   78: ifnull -> 103
      //   81: aload #6
      //   83: invokevirtual j1 : ()Ldbxyzptlk/d1/Y$a;
      //   86: astore #7
      //   88: aload #7
      //   90: astore #6
      //   92: aload #7
      //   94: ifnonnull -> 100
      //   97: goto -> 103
      //   100: goto -> 123
      //   103: aload_0
      //   104: getfield E : Landroidx/compose/ui/node/g;
      //   107: invokestatic a : (Landroidx/compose/ui/node/g;)Landroidx/compose/ui/node/f;
      //   110: invokestatic b : (Landroidx/compose/ui/node/f;)Landroidx/compose/ui/node/Owner;
      //   113: invokeinterface getPlacementScope : ()Ldbxyzptlk/d1/Y$a;
      //   118: astore #6
      //   120: goto -> 100
      //   123: aload_0
      //   124: getfield E : Landroidx/compose/ui/node/g;
      //   127: astore #8
      //   129: aload #8
      //   131: invokevirtual E : ()Landroidx/compose/ui/node/g$a;
      //   134: astore #7
      //   136: aload #7
      //   138: invokestatic e : (Ljava/lang/Object;)V
      //   141: aload #8
      //   143: invokestatic a : (Landroidx/compose/ui/node/g;)Landroidx/compose/ui/node/f;
      //   146: invokevirtual m0 : ()Landroidx/compose/ui/node/f;
      //   149: astore #8
      //   151: aload #8
      //   153: ifnull -> 165
      //   156: aload #8
      //   158: invokevirtual S : ()Landroidx/compose/ui/node/g;
      //   161: iconst_0
      //   162: invokestatic o : (Landroidx/compose/ui/node/g;I)V
      //   165: aload #7
      //   167: ldc 2147483647
      //   169: invokevirtual Q1 : (I)V
      //   172: aload #6
      //   174: aload #7
      //   176: lload_1
      //   177: invokestatic j : (J)I
      //   180: lload_1
      //   181: invokestatic k : (J)I
      //   184: fconst_0
      //   185: iconst_4
      //   186: aconst_null
      //   187: invokestatic f : (Ldbxyzptlk/d1/Y$a;Ldbxyzptlk/d1/Y;IIFILjava/lang/Object;)V
      //   190: aload_0
      //   191: getfield E : Landroidx/compose/ui/node/g;
      //   194: invokevirtual E : ()Landroidx/compose/ui/node/g$a;
      //   197: astore #6
      //   199: aload #6
      //   201: ifnull -> 215
      //   204: aload #6
      //   206: invokevirtual u1 : ()Z
      //   209: ifne -> 215
      //   212: goto -> 218
      //   215: iconst_0
      //   216: istore #5
      //   218: iload #5
      //   220: ifne -> 232
      //   223: aload_0
      //   224: lload_1
      //   225: fload_3
      //   226: aload #4
      //   228: invokevirtual R1 : (JFLdbxyzptlk/CI/l;)V
      //   231: return
      //   232: new java/lang/IllegalArgumentException
      //   235: dup
      //   236: ldc_w 'Error: Placement happened before lookahead.'
      //   239: invokespecial <init> : (Ljava/lang/String;)V
      //   242: athrow
    }
    
    public final void T1() {
      try {
        this.f = true;
        if (this.j) {
          boolean bool = h();
          R1(this.m, this.o, this.n);
          if (bool && !this.z) {
            f f = g.a(this.E).m0();
            if (f != null)
              f.k1(f, false, 1, null); 
          } 
          this.f = false;
          return;
        } 
      } finally {
        Exception exception;
      } 
      IllegalStateException illegalStateException = new IllegalStateException();
      this("replace called on unplaced item");
      throw illegalStateException;
    }
    
    public int U(int param1Int) {
      O1();
      return this.E.H().U(param1Int);
    }
    
    public final void U1(boolean param1Boolean) {
      this.v = param1Boolean;
    }
    
    public final void V1(f.g param1g) {
      this.k = param1g;
    }
    
    public void W1(boolean param1Boolean) {
      this.r = param1Boolean;
    }
    
    public final void X1(f param1f) {
      f f1 = param1f.m0();
      if (f1 != null) {
        if (this.k == f.g.NotUsed || param1f.C()) {
          f.g g1;
          f.e e = f1.U();
          int i = a.a[e.ordinal()];
          if (i != 1) {
            if (i == 2) {
              g1 = f.g.InLayoutBlock;
            } else {
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("Measurable could be only measured from the parent's measure or layout block. Parents state is ");
              stringBuilder.append(f1.U());
              throw new IllegalStateException(stringBuilder.toString());
            } 
          } else {
            g1 = f.g.InMeasureBlock;
          } 
          this.k = g1;
          return;
        } 
        throw new IllegalStateException("measure() may not be called multiple times on the same Measurable. If you want to get the content size of the Measurable before calculating the final constraints, please use methods like minIntrinsicWidth()/maxIntrinsicWidth() and minIntrinsicHeight()/maxIntrinsicHeight()");
      } 
      this.k = f.g.NotUsed;
    }
    
    public final boolean Y1() {
      if (b() == null && this.E.H().b() == null)
        return false; 
      if (!this.p)
        return false; 
      this.p = false;
      this.q = this.E.H().b();
      return true;
    }
    
    public Object b() {
      return this.q;
    }
    
    public dbxyzptlk.f1.a d() {
      return this.t;
    }
    
    public Y d0(long param1Long) {
      f.g g2 = g.a(this.E).R();
      f.g g1 = f.g.NotUsed;
      if (g2 == g1)
        g.a(this.E).u(); 
      if (E.a(g.a(this.E))) {
        g.a a1 = this.E.E();
        s.e(a1);
        a1.P1(g1);
        a1.d0(param1Long);
      } 
      X1(g.a(this.E));
      S1(param1Long);
      return this;
    }
    
    public boolean h() {
      return this.r;
    }
    
    public Map<dbxyzptlk.d1.a, Integer> j() {
      if (!this.l)
        if (this.E.A() == f.e.Measuring) {
          d().s(true);
          if (d().g())
            this.E.L(); 
        } else {
          d().r(true);
        }  
      P().w1(true);
      M();
      P().w1(false);
      return d().h();
    }
    
    public void l(l<? super dbxyzptlk.f1.b, D> param1l) {
      dbxyzptlk.z0.d<f> d1 = g.a(this.E).u0();
      int i = d1.p();
      if (i > 0) {
        int k;
        Object[] arrayOfObject = d1.o();
        int j = 0;
        do {
          param1l.invoke(((f)arrayOfObject[j]).S().r());
          k = j + 1;
          j = k;
        } while (k < i);
      } 
    }
    
    public final List<b> n1() {
      g.a(this.E).A1();
      if (!this.v)
        return this.u.h(); 
      f f = g.a(this.E);
      dbxyzptlk.z0.d<b> d1 = this.u;
      dbxyzptlk.z0.d<f> d2 = f.u0();
      int i = d2.p();
      if (i > 0) {
        int k;
        Object[] arrayOfObject = d2.o();
        int j = 0;
        do {
          f f1 = (f)arrayOfObject[j];
          if (d1.p() <= j) {
            d1.c(f1.S().F());
          } else {
            d1.G(j, f1.S().F());
          } 
          k = j + 1;
          j = k;
        } while (k < i);
      } 
      d1.E(f.F().size(), d1.p());
      this.v = false;
      return this.u.h();
    }
    
    public void requestLayout() {
      f.k1(g.a(this.E), false, 1, null);
    }
    
    public final dbxyzptlk.z1.b t1() {
      dbxyzptlk.z1.b b1;
      if (this.i) {
        b1 = dbxyzptlk.z1.b.b(N0());
      } else {
        b1 = null;
      } 
      return b1;
    }
    
    public final boolean u1() {
      return this.w;
    }
    
    public void v() {
      f.m1(g.a(this.E), false, false, 3, null);
    }
    
    public final f.g w1() {
      return this.k;
    }
    
    public int x(int param1Int) {
      O1();
      return this.E.H().x(param1Int);
    }
    
    @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"Ldbxyzptlk/pI/D;", "b", "()V"}, k = 3, mv = {1, 8, 0})
    public static final class b extends u implements dbxyzptlk.CI.a<D> {
      public final g.b f;
      
      public b(g.b param2b) {
        super(0);
      }
      
      public final void b() {
        g.b.f1(this.f);
        this.f.l(a.f);
        this.f.P().h1().f();
        g.b.e1(this.f);
        this.f.l(b.f);
      }
      
      @Metadata(d1 = {"\000\016\n\002\030\002\n\000\n\002\030\002\n\002\b\002\020\003\032\0020\0022\006\020\001\032\0020\000H\n¢\006\004\b\003\020\004"}, d2 = {"Ldbxyzptlk/f1/b;", "it", "Ldbxyzptlk/pI/D;", "a", "(Ldbxyzptlk/f1/b;)V"}, k = 3, mv = {1, 8, 0})
      public static final class a extends u implements l<dbxyzptlk.f1.b, D> {
        public static final a f = new a();
        
        public a() {
          super(1);
        }
        
        public final void a(dbxyzptlk.f1.b param3b) {
          param3b.d().t(false);
        }
      }
      
      @Metadata(d1 = {"\000\016\n\002\030\002\n\000\n\002\030\002\n\002\b\002\020\003\032\0020\0022\006\020\001\032\0020\000H\n¢\006\004\b\003\020\004"}, d2 = {"Ldbxyzptlk/f1/b;", "it", "Ldbxyzptlk/pI/D;", "a", "(Ldbxyzptlk/f1/b;)V"}, k = 3, mv = {1, 8, 0})
      public static final class b extends u implements l<dbxyzptlk.f1.b, D> {
        public static final b f = new b();
        
        public b() {
          super(1);
        }
        
        public final void a(dbxyzptlk.f1.b param3b) {
          param3b.d().q(param3b.d().l());
        }
      }
    }
    
    @Metadata(d1 = {"\000\016\n\002\030\002\n\000\n\002\030\002\n\002\b\002\020\003\032\0020\0022\006\020\001\032\0020\000H\n¢\006\004\b\003\020\004"}, d2 = {"Ldbxyzptlk/f1/b;", "it", "Ldbxyzptlk/pI/D;", "a", "(Ldbxyzptlk/f1/b;)V"}, k = 3, mv = {1, 8, 0})
    public static final class a extends u implements l<dbxyzptlk.f1.b, D> {
      public static final a f = new a();
      
      public a() {
        super(1);
      }
      
      public final void a(dbxyzptlk.f1.b param2b) {
        param2b.d().t(false);
      }
    }
    
    @Metadata(d1 = {"\000\016\n\002\030\002\n\000\n\002\030\002\n\002\b\002\020\003\032\0020\0022\006\020\001\032\0020\000H\n¢\006\004\b\003\020\004"}, d2 = {"Ldbxyzptlk/f1/b;", "it", "Ldbxyzptlk/pI/D;", "a", "(Ldbxyzptlk/f1/b;)V"}, k = 3, mv = {1, 8, 0})
    public static final class b extends u implements l<dbxyzptlk.f1.b, D> {
      public static final b f = new b();
      
      public b() {
        super(1);
      }
      
      public final void a(dbxyzptlk.f1.b param2b) {
        param2b.d().q(param2b.d().l());
      }
    }
    
    @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"Ldbxyzptlk/pI/D;", "b", "()V"}, k = 3, mv = {1, 8, 0})
    public static final class c extends u implements dbxyzptlk.CI.a<D> {
      public final g f;
      
      public final g.b g;
      
      public c(g param2g, g.b param2b) {
        super(0);
      }
      
      public final void b() {
        // Byte code:
        //   0: aload_0
        //   1: getfield f : Landroidx/compose/ui/node/g;
        //   4: invokevirtual H : ()Landroidx/compose/ui/node/n;
        //   7: invokevirtual q2 : ()Landroidx/compose/ui/node/n;
        //   10: astore_1
        //   11: aload_1
        //   12: ifnull -> 32
        //   15: aload_1
        //   16: invokevirtual j1 : ()Ldbxyzptlk/d1/Y$a;
        //   19: astore_2
        //   20: aload_2
        //   21: astore_1
        //   22: aload_2
        //   23: ifnonnull -> 29
        //   26: goto -> 32
        //   29: goto -> 51
        //   32: aload_0
        //   33: getfield f : Landroidx/compose/ui/node/g;
        //   36: invokestatic a : (Landroidx/compose/ui/node/g;)Landroidx/compose/ui/node/f;
        //   39: invokestatic b : (Landroidx/compose/ui/node/f;)Landroidx/compose/ui/node/Owner;
        //   42: invokeinterface getPlacementScope : ()Ldbxyzptlk/d1/Y$a;
        //   47: astore_1
        //   48: goto -> 29
        //   51: aload_0
        //   52: getfield g : Landroidx/compose/ui/node/g$b;
        //   55: astore_2
        //   56: aload_0
        //   57: getfield f : Landroidx/compose/ui/node/g;
        //   60: astore_3
        //   61: aload_2
        //   62: invokestatic g1 : (Landroidx/compose/ui/node/g$b;)Ldbxyzptlk/CI/l;
        //   65: astore #4
        //   67: aload #4
        //   69: ifnonnull -> 91
        //   72: aload_1
        //   73: aload_3
        //   74: invokevirtual H : ()Landroidx/compose/ui/node/n;
        //   77: aload_2
        //   78: invokestatic h1 : (Landroidx/compose/ui/node/g$b;)J
        //   81: aload_2
        //   82: invokestatic j1 : (Landroidx/compose/ui/node/g$b;)F
        //   85: invokevirtual g : (Ldbxyzptlk/d1/Y;JF)V
        //   88: goto -> 109
        //   91: aload_1
        //   92: aload_3
        //   93: invokevirtual H : ()Landroidx/compose/ui/node/n;
        //   96: aload_2
        //   97: invokestatic h1 : (Landroidx/compose/ui/node/g$b;)J
        //   100: aload_2
        //   101: invokestatic j1 : (Landroidx/compose/ui/node/g$b;)F
        //   104: aload #4
        //   106: invokevirtual s : (Ldbxyzptlk/d1/Y;JFLdbxyzptlk/CI/l;)V
        //   109: return
      }
    }
    
    @Metadata(d1 = {"\000\016\n\002\030\002\n\000\n\002\030\002\n\002\b\002\020\003\032\0020\0022\006\020\001\032\0020\000H\n¢\006\004\b\003\020\004"}, d2 = {"Ldbxyzptlk/f1/b;", "it", "Ldbxyzptlk/pI/D;", "a", "(Ldbxyzptlk/f1/b;)V"}, k = 3, mv = {1, 8, 0})
    public static final class d extends u implements l<dbxyzptlk.f1.b, D> {
      public static final d f = new d();
      
      public d() {
        super(1);
      }
      
      public final void a(dbxyzptlk.f1.b param2b) {
        param2b.d().u(false);
      }
    }
  }
  
  @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"Ldbxyzptlk/pI/D;", "b", "()V"}, k = 3, mv = {1, 8, 0})
  public static final class b extends u implements dbxyzptlk.CI.a<D> {
    public final g.b f;
    
    public b(g.b param1b) {
      super(0);
    }
    
    public final void b() {
      g.b.f1(this.f);
      this.f.l(a.f);
      this.f.P().h1().f();
      g.b.e1(this.f);
      this.f.l(b.f);
    }
    
    @Metadata(d1 = {"\000\016\n\002\030\002\n\000\n\002\030\002\n\002\b\002\020\003\032\0020\0022\006\020\001\032\0020\000H\n¢\006\004\b\003\020\004"}, d2 = {"Ldbxyzptlk/f1/b;", "it", "Ldbxyzptlk/pI/D;", "a", "(Ldbxyzptlk/f1/b;)V"}, k = 3, mv = {1, 8, 0})
    public static final class a extends u implements l<dbxyzptlk.f1.b, D> {
      public static final a f = new a();
      
      public a() {
        super(1);
      }
      
      public final void a(dbxyzptlk.f1.b param3b) {
        param3b.d().t(false);
      }
    }
    
    @Metadata(d1 = {"\000\016\n\002\030\002\n\000\n\002\030\002\n\002\b\002\020\003\032\0020\0022\006\020\001\032\0020\000H\n¢\006\004\b\003\020\004"}, d2 = {"Ldbxyzptlk/f1/b;", "it", "Ldbxyzptlk/pI/D;", "a", "(Ldbxyzptlk/f1/b;)V"}, k = 3, mv = {1, 8, 0})
    public static final class b extends u implements l<dbxyzptlk.f1.b, D> {
      public static final b f = new b();
      
      public b() {
        super(1);
      }
      
      public final void a(dbxyzptlk.f1.b param3b) {
        param3b.d().q(param3b.d().l());
      }
    }
  }
  
  @Metadata(d1 = {"\000\016\n\002\030\002\n\000\n\002\030\002\n\002\b\002\020\003\032\0020\0022\006\020\001\032\0020\000H\n¢\006\004\b\003\020\004"}, d2 = {"Ldbxyzptlk/f1/b;", "it", "Ldbxyzptlk/pI/D;", "a", "(Ldbxyzptlk/f1/b;)V"}, k = 3, mv = {1, 8, 0})
  public static final class a extends u implements l<dbxyzptlk.f1.b, D> {
    public static final a f = new a();
    
    public a() {
      super(1);
    }
    
    public final void a(dbxyzptlk.f1.b param1b) {
      param1b.d().t(false);
    }
  }
  
  @Metadata(d1 = {"\000\016\n\002\030\002\n\000\n\002\030\002\n\002\b\002\020\003\032\0020\0022\006\020\001\032\0020\000H\n¢\006\004\b\003\020\004"}, d2 = {"Ldbxyzptlk/f1/b;", "it", "Ldbxyzptlk/pI/D;", "a", "(Ldbxyzptlk/f1/b;)V"}, k = 3, mv = {1, 8, 0})
  public static final class b extends u implements l<dbxyzptlk.f1.b, D> {
    public static final b f = new b();
    
    public b() {
      super(1);
    }
    
    public final void a(dbxyzptlk.f1.b param1b) {
      param1b.d().q(param1b.d().l());
    }
  }
  
  @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"Ldbxyzptlk/pI/D;", "b", "()V"}, k = 3, mv = {1, 8, 0})
  public static final class c extends u implements dbxyzptlk.CI.a<D> {
    public final g f;
    
    public final g.b g;
    
    public c(g param1g, g.b param1b) {
      super(0);
    }
    
    public final void b() {
      // Byte code:
      //   0: aload_0
      //   1: getfield f : Landroidx/compose/ui/node/g;
      //   4: invokevirtual H : ()Landroidx/compose/ui/node/n;
      //   7: invokevirtual q2 : ()Landroidx/compose/ui/node/n;
      //   10: astore_1
      //   11: aload_1
      //   12: ifnull -> 32
      //   15: aload_1
      //   16: invokevirtual j1 : ()Ldbxyzptlk/d1/Y$a;
      //   19: astore_2
      //   20: aload_2
      //   21: astore_1
      //   22: aload_2
      //   23: ifnonnull -> 29
      //   26: goto -> 32
      //   29: goto -> 51
      //   32: aload_0
      //   33: getfield f : Landroidx/compose/ui/node/g;
      //   36: invokestatic a : (Landroidx/compose/ui/node/g;)Landroidx/compose/ui/node/f;
      //   39: invokestatic b : (Landroidx/compose/ui/node/f;)Landroidx/compose/ui/node/Owner;
      //   42: invokeinterface getPlacementScope : ()Ldbxyzptlk/d1/Y$a;
      //   47: astore_1
      //   48: goto -> 29
      //   51: aload_0
      //   52: getfield g : Landroidx/compose/ui/node/g$b;
      //   55: astore_2
      //   56: aload_0
      //   57: getfield f : Landroidx/compose/ui/node/g;
      //   60: astore_3
      //   61: aload_2
      //   62: invokestatic g1 : (Landroidx/compose/ui/node/g$b;)Ldbxyzptlk/CI/l;
      //   65: astore #4
      //   67: aload #4
      //   69: ifnonnull -> 91
      //   72: aload_1
      //   73: aload_3
      //   74: invokevirtual H : ()Landroidx/compose/ui/node/n;
      //   77: aload_2
      //   78: invokestatic h1 : (Landroidx/compose/ui/node/g$b;)J
      //   81: aload_2
      //   82: invokestatic j1 : (Landroidx/compose/ui/node/g$b;)F
      //   85: invokevirtual g : (Ldbxyzptlk/d1/Y;JF)V
      //   88: goto -> 109
      //   91: aload_1
      //   92: aload_3
      //   93: invokevirtual H : ()Landroidx/compose/ui/node/n;
      //   96: aload_2
      //   97: invokestatic h1 : (Landroidx/compose/ui/node/g$b;)J
      //   100: aload_2
      //   101: invokestatic j1 : (Landroidx/compose/ui/node/g$b;)F
      //   104: aload #4
      //   106: invokevirtual s : (Ldbxyzptlk/d1/Y;JFLdbxyzptlk/CI/l;)V
      //   109: return
    }
  }
  
  @Metadata(d1 = {"\000\016\n\002\030\002\n\000\n\002\030\002\n\002\b\002\020\003\032\0020\0022\006\020\001\032\0020\000H\n¢\006\004\b\003\020\004"}, d2 = {"Ldbxyzptlk/f1/b;", "it", "Ldbxyzptlk/pI/D;", "a", "(Ldbxyzptlk/f1/b;)V"}, k = 3, mv = {1, 8, 0})
  public static final class d extends u implements l<dbxyzptlk.f1.b, D> {
    public static final d f = new d();
    
    public d() {
      super(1);
    }
    
    public final void a(dbxyzptlk.f1.b param1b) {
      param1b.d().u(false);
    }
  }
  
  @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"Ldbxyzptlk/pI/D;", "b", "()V"}, k = 3, mv = {1, 8, 0})
  public static final class d extends u implements dbxyzptlk.CI.a<D> {
    public final g f;
    
    public d(g param1g) {
      super(0);
    }
    
    public final void b() {
      this.f.H().d0(g.f(this.f));
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compos\\ui\node\g.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */