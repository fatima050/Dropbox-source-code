package androidx.compose.ui.node;

import androidx.compose.ui.graphics.c;
import dbxyzptlk.CI.l;
import dbxyzptlk.Q0.L0;
import dbxyzptlk.Q0.M0;
import dbxyzptlk.Q0.O;
import dbxyzptlk.Q0.j0;
import dbxyzptlk.Q0.r0;
import dbxyzptlk.d1.I;
import dbxyzptlk.d1.Y;
import dbxyzptlk.f1.D;
import dbxyzptlk.f1.d0;
import dbxyzptlk.f1.q;
import dbxyzptlk.pI.D;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

@Metadata(d1 = {"\000\001\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\020\b\n\002\b\007\n\002\030\002\n\000\n\002\020\007\n\000\n\002\030\002\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020\013\n\002\b\004\n\002\030\002\n\002\b\006\n\002\030\002\n\002\b\f\b\000\030\000 B2\0020\001:\002CDB\017\022\006\020\003\032\0020\002¢\006\004\b\004\020\005J\017\020\007\032\0020\006H\026¢\006\004\b\007\020\bJ\032\020\f\032\0020\0132\006\020\n\032\0020\tH\026ø\001\000¢\006\004\b\f\020\rJ\027\020\020\032\0020\0162\006\020\017\032\0020\016H\026¢\006\004\b\020\020\021J\027\020\023\032\0020\0162\006\020\022\032\0020\016H\026¢\006\004\b\023\020\021J\027\020\024\032\0020\0162\006\020\017\032\0020\016H\026¢\006\004\b\024\020\021J\027\020\025\032\0020\0162\006\020\022\032\0020\016H\026¢\006\004\b\025\020\021J8\020\035\032\0020\0062\006\020\027\032\0020\0262\006\020\031\032\0020\0302\024\020\034\032\020\022\004\022\0020\033\022\004\022\0020\006\030\0010\032H\024ø\001\000¢\006\004\b\035\020\036J\027\020!\032\0020\0162\006\020 \032\0020\037H\026¢\006\004\b!\020\"J\027\020%\032\0020\0062\006\020$\032\0020#H\026¢\006\004\b%\020&J:\0200\032\0020\0062\006\020(\032\0020'2\006\020*\032\0020)2\006\020,\032\0020+2\006\020.\032\0020-2\006\020/\032\0020-H\026ø\001\000¢\006\004\b0\0201R \0208\032\002028\026X\004¢\006\022\n\004\b3\0204\022\004\b7\020\b\032\004\b5\0206R.\020A\032\004\030\001092\b\020:\032\004\030\001098\026@TX\016¢\006\022\n\004\b;\020<\032\004\b=\020>\"\004\b?\020@\002\007\n\005\b¡\0360\001¨\006E"}, d2 = {"Landroidx/compose/ui/node/d;", "Landroidx/compose/ui/node/n;", "Landroidx/compose/ui/node/f;", "layoutNode", "<init>", "(Landroidx/compose/ui/node/f;)V", "Ldbxyzptlk/pI/D;", "a2", "()V", "Ldbxyzptlk/z1/b;", "constraints", "Ldbxyzptlk/d1/Y;", "d0", "(J)Ldbxyzptlk/d1/Y;", "", "height", "S", "(I)I", "width", "N", "U", "x", "Ldbxyzptlk/z1/n;", "position", "", "zIndex", "Lkotlin/Function1;", "Landroidx/compose/ui/graphics/c;", "layerBlock", "T0", "(JFLdbxyzptlk/CI/l;)V", "Ldbxyzptlk/d1/a;", "alignmentLine", "e1", "(Ldbxyzptlk/d1/a;)I", "Ldbxyzptlk/Q0/j0;", "canvas", "K2", "(Ldbxyzptlk/Q0/j0;)V", "Landroidx/compose/ui/node/n$f;", "hitTestSource", "Ldbxyzptlk/P0/f;", "pointerPosition", "Ldbxyzptlk/f1/q;", "hitTestResult", "", "isTouchEvent", "isInLayer", "y2", "(Landroidx/compose/ui/node/n$f;JLdbxyzptlk/f1/q;ZZ)V", "Ldbxyzptlk/f1/d0;", "J", "Ldbxyzptlk/f1/d0;", "f3", "()Ldbxyzptlk/f1/d0;", "getTail$annotations", "tail", "Landroidx/compose/ui/node/j;", "<set-?>", "K", "Landroidx/compose/ui/node/j;", "k2", "()Landroidx/compose/ui/node/j;", "g3", "(Landroidx/compose/ui/node/j;)V", "lookaheadDelegate", "L", "a", "b", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class d extends n {
  public static final a L = new a(null);
  
  public static final L0 M;
  
  public final d0 J = new d0();
  
  public j K;
  
  static {
    L0 l0 = O.a();
    l0.g(r0.b.d());
    l0.o(1.0F);
    l0.m(M0.a.b());
    M = l0;
  }
  
  public d(f paramf) {
    super(paramf);
    f3().j2((n)this);
    if (paramf.Y() != null) {
      b b = new b(this);
    } else {
      paramf = null;
    } 
    this.K = (j)paramf;
  }
  
  public void K2(j0 paramj0) {
    Owner owner = D.b(j2());
    dbxyzptlk.z0.d<f> d1 = j2().t0();
    int i = d1.p();
    if (i > 0) {
      int m;
      Object[] arrayOfObject = d1.o();
      int k = 0;
      do {
        f f = (f)arrayOfObject[k];
        if (f.h())
          f.A(paramj0); 
        m = k + 1;
        k = m;
      } while (m < i);
    } 
    if (owner.getShowLayoutBounds())
      Y1(paramj0, M); 
  }
  
  public int N(int paramInt) {
    return j2().Q().g(paramInt);
  }
  
  public int S(int paramInt) {
    return j2().Q().h(paramInt);
  }
  
  public void T0(long paramLong, float paramFloat, l<? super c, D> paraml) {
    super.T0(paramLong, paramFloat, paraml);
    if (t1())
      return; 
    I2();
    j2().a0().Q1();
  }
  
  public int U(int paramInt) {
    return j2().Q().c(paramInt);
  }
  
  public void a2() {
    if (k2() == null)
      g3((j)new b(this)); 
  }
  
  public Y d0(long paramLong) {
    n.R1((n)this, paramLong);
    dbxyzptlk.z0.d<f> d1 = j2().u0();
    int i = d1.p();
    if (i > 0) {
      int m;
      Object[] arrayOfObject = d1.o();
      int k = 0;
      do {
        ((f)arrayOfObject[k]).a0().V1(f.g.NotUsed);
        m = k + 1;
        k = m;
      } while (m < i);
    } 
    P2(j2().c0().h((I)this, j2().E(), paramLong));
    H2();
    return (Y)this;
  }
  
  public int e1(dbxyzptlk.d1.a parama) {
    int i;
    j j1 = k2();
    if (j1 != null) {
      i = j1.e1(parama);
    } else {
      Integer integer = (Integer)e2().j().get(parama);
      if (integer != null) {
        i = integer.intValue();
      } else {
        i = Integer.MIN_VALUE;
      } 
    } 
    return i;
  }
  
  public d0 f3() {
    return this.J;
  }
  
  public void g3(j paramj) {
    this.K = paramj;
  }
  
  public j k2() {
    return this.K;
  }
  
  public int x(int paramInt) {
    return j2().Q().b(paramInt);
  }
  
  public void y2(n.f paramf, long paramLong, q paramq, boolean paramBoolean1, boolean paramBoolean2) {
    // Byte code:
    //   0: aload_1
    //   1: aload_0
    //   2: invokevirtual j2 : ()Landroidx/compose/ui/node/f;
    //   5: invokeinterface d : (Landroidx/compose/ui/node/f;)Z
    //   10: istore #11
    //   12: iconst_0
    //   13: istore #8
    //   15: iload #11
    //   17: ifeq -> 72
    //   20: aload_0
    //   21: lload_2
    //   22: invokevirtual e3 : (J)Z
    //   25: ifeq -> 34
    //   28: iconst_1
    //   29: istore #8
    //   31: goto -> 72
    //   34: iload #5
    //   36: ifeq -> 72
    //   39: aload_0
    //   40: lload_2
    //   41: aload_0
    //   42: invokevirtual l2 : ()J
    //   45: invokevirtual W1 : (JJ)F
    //   48: fstore #7
    //   50: fload #7
    //   52: invokestatic isInfinite : (F)Z
    //   55: ifne -> 72
    //   58: fload #7
    //   60: invokestatic isNaN : (F)Z
    //   63: ifne -> 72
    //   66: iconst_0
    //   67: istore #6
    //   69: goto -> 28
    //   72: iload #8
    //   74: ifeq -> 206
    //   77: aload #4
    //   79: invokestatic e : (Ldbxyzptlk/f1/q;)I
    //   82: istore #10
    //   84: aload_0
    //   85: invokevirtual j2 : ()Landroidx/compose/ui/node/f;
    //   88: invokevirtual t0 : ()Ldbxyzptlk/z0/d;
    //   91: astore #12
    //   93: aload #12
    //   95: invokevirtual p : ()I
    //   98: istore #8
    //   100: iload #8
    //   102: ifle -> 178
    //   105: aload #12
    //   107: invokevirtual o : ()[Ljava/lang/Object;
    //   110: astore #12
    //   112: iinc #8, -1
    //   115: aload #12
    //   117: iload #8
    //   119: aaload
    //   120: checkcast androidx/compose/ui/node/f
    //   123: astore #13
    //   125: aload #13
    //   127: invokevirtual h : ()Z
    //   130: ifeq -> 181
    //   133: aload_1
    //   134: aload #13
    //   136: lload_2
    //   137: aload #4
    //   139: iload #5
    //   141: iload #6
    //   143: invokeinterface c : (Landroidx/compose/ui/node/f;JLdbxyzptlk/f1/q;ZZ)V
    //   148: aload #4
    //   150: invokevirtual x : ()Z
    //   153: ifne -> 159
    //   156: goto -> 181
    //   159: aload #13
    //   161: invokevirtual j0 : ()Landroidx/compose/ui/node/n;
    //   164: invokevirtual T2 : ()Z
    //   167: ifeq -> 178
    //   170: aload #4
    //   172: invokevirtual b : ()V
    //   175: goto -> 181
    //   178: goto -> 199
    //   181: iload #8
    //   183: iconst_1
    //   184: isub
    //   185: istore #9
    //   187: iload #9
    //   189: istore #8
    //   191: iload #9
    //   193: ifge -> 115
    //   196: goto -> 178
    //   199: aload #4
    //   201: iload #10
    //   203: invokestatic k : (Ldbxyzptlk/f1/q;I)V
    //   206: return
  }
  
  @Metadata(d1 = {"\000\f\n\002\030\002\n\002\020\000\n\002\b\003\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003¨\006\004"}, d2 = {"Landroidx/compose/ui/node/d$a;", "", "<init>", "()V", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class a {
    public a() {}
  }
  
  class d {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compos\\ui\node\d.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */