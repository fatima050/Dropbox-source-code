package androidx.compose.ui.node;

import androidx.compose.ui.d;
import dbxyzptlk.CI.l;
import dbxyzptlk.DI.s;
import dbxyzptlk.DI.u;
import dbxyzptlk.e1.k;
import dbxyzptlk.f1.d0;
import dbxyzptlk.f1.g;
import dbxyzptlk.f1.h;
import dbxyzptlk.pI.D;
import kotlin.Metadata;

@Metadata(d1 = {"\000\037\n\002\030\002\n\002\020\013\n\002\b\002\n\002\b\004\n\002\030\002\n\002\030\002\n\002\b\006*\001\004\032\023\020\002\032\0020\001*\0020\000H\002¢\006\004\b\002\020\003\"\024\020\007\032\0020\0048\002X\004¢\006\006\n\004\b\005\020\006\" \020\f\032\016\022\004\022\0020\000\022\004\022\0020\t0\b8\002X\004¢\006\006\n\004\b\n\020\013\" \020\016\032\016\022\004\022\0020\000\022\004\022\0020\t0\b8\002X\004¢\006\006\n\004\b\r\020\013¨\006\017"}, d2 = {"Landroidx/compose/ui/node/a;", "", "e", "(Landroidx/compose/ui/node/a;)Z", "androidx/compose/ui/node/b$a", "a", "Landroidx/compose/ui/node/b$a;", "DetachedModifierLocalReadScope", "Lkotlin/Function1;", "Ldbxyzptlk/pI/D;", "b", "Ldbxyzptlk/CI/l;", "onDrawCacheReadsChanged", "c", "updateModifierLocalConsumer", "ui_release"}, k = 2, mv = {1, 8, 0}, xi = 48)
public final class b {
  public static final a a = new a();
  
  public static final l<a, D> b = b.f;
  
  public static final l<a, D> c = c.f;
  
  public static final boolean e(a parama) {
    d.c c = h.k((g)parama).i0().p();
    s.f(c, "null cannot be cast to non-null type androidx.compose.ui.node.TailModifierNode");
    return ((d0)c).k2();
  }
  
  @Metadata(d1 = {"\000\023\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\004*\001\000\b\n\030\0002\0020\001R$\020\006\032\0028\000\"\004\b\000\020\002*\b\022\004\022\0028\0000\0038VX\004¢\006\006\032\004\b\004\020\005¨\006\007"}, d2 = {"androidx/compose/ui/node/b$a", "Ldbxyzptlk/e1/k;", "T", "Ldbxyzptlk/e1/c;", "b", "(Ldbxyzptlk/e1/c;)Ljava/lang/Object;", "current", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class a implements k {
    public <T> T b(dbxyzptlk.e1.c<T> param1c) {
      return (T)param1c.a().invoke();
    }
  }
  
  @Metadata(d1 = {"\000\016\n\002\030\002\n\000\n\002\030\002\n\002\b\002\020\003\032\0020\0022\006\020\001\032\0020\000H\n¢\006\004\b\003\020\004"}, d2 = {"Landroidx/compose/ui/node/a;", "it", "Ldbxyzptlk/pI/D;", "a", "(Landroidx/compose/ui/node/a;)V"}, k = 3, mv = {1, 8, 0})
  public static final class b extends u implements l<a, D> {
    public static final b f = new b();
    
    public b() {
      super(1);
    }
    
    public final void a(a param1a) {
      param1a.o2();
    }
  }
  
  @Metadata(d1 = {"\000\016\n\002\030\002\n\000\n\002\030\002\n\002\b\002\020\003\032\0020\0022\006\020\001\032\0020\000H\n¢\006\004\b\003\020\004"}, d2 = {"Landroidx/compose/ui/node/a;", "it", "Ldbxyzptlk/pI/D;", "a", "(Landroidx/compose/ui/node/a;)V"}, k = 3, mv = {1, 8, 0})
  public static final class c extends u implements l<a, D> {
    public static final c f = new c();
    
    public c() {
      super(1);
    }
    
    public final void a(a param1a) {
      param1a.s2();
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compos\\ui\node\b.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */