package androidx.compose.ui.node;

import dbxyzptlk.DI.K;
import dbxyzptlk.DI.s;
import dbxyzptlk.DI.u;
import dbxyzptlk.P0.h;
import dbxyzptlk.P0.m;
import dbxyzptlk.Q0.H0;
import dbxyzptlk.Q0.L0;
import dbxyzptlk.Q0.j0;
import dbxyzptlk.d1.B;
import dbxyzptlk.d1.F;
import dbxyzptlk.d1.H;
import dbxyzptlk.d1.r;
import dbxyzptlk.d1.s;
import dbxyzptlk.f1.D;
import dbxyzptlk.f1.J;
import dbxyzptlk.f1.K;
import dbxyzptlk.f1.L;
import dbxyzptlk.f1.S;
import dbxyzptlk.f1.T;
import dbxyzptlk.f1.U;
import dbxyzptlk.f1.V;
import dbxyzptlk.f1.X;
import dbxyzptlk.f1.h;
import dbxyzptlk.f1.i;
import dbxyzptlk.f1.q;
import dbxyzptlk.f1.u;
import dbxyzptlk.f1.v;
import dbxyzptlk.pI.D;
import dbxyzptlk.z1.o;
import dbxyzptlk.z1.r;
import dbxyzptlk.z1.s;
import dbxyzptlk.z1.t;
import java.util.LinkedHashMap;
import java.util.Map;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

@Metadata(d1 = {"\000\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\003\n\002\020\013\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\003\n\002\030\002\n\000\n\002\020\007\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\006\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\f\n\002\030\002\n\002\b\007\n\002\030\002\n\002\b\020\n\002\020\b\n\002\b\021\n\002\030\002\n\002\b\021\n\002\030\002\n\002\b\021\n\002\030\002\n\002\b\034\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\006\n\002\030\002\n\002\b\003\n\002\020%\n\002\030\002\n\002\b\017\n\002\030\002\n\002\b\006\n\002\030\002\n\002\b\006\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\020\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\020\n\002\030\002\n\002\b\005\n\002\020\000\n\002\b\007\n\002\030\002\n\002\b\t\b \030\000 \0022\0020\0012\0020\0022\0020\0032\0020\004:\004\002\002B\017\022\006\020\006\032\0020\005¢\006\004\b\007\020\bJ\031\020\f\032\004\030\0010\0132\006\020\n\032\0020\tH\002¢\006\004\b\f\020\rJ\036\020\020\032\0020\t2\n\020\017\032\006\022\002\b\0030\016H\002ø\001\000¢\006\004\b\020\020\021J8\020\032\032\0020\0302\006\020\023\032\0020\0222\006\020\025\032\0020\0242\024\020\031\032\020\022\004\022\0020\027\022\004\022\0020\030\030\0010\026H\002ø\001\000¢\006\004\b\032\020\033J\027\020\036\032\0020\0302\006\020\035\032\0020\034H\002¢\006\004\b\036\020\037J\031\020!\032\0020\0302\b\b\002\020 \032\0020\tH\002¢\006\004\b!\020\"J@\020+\032\0020\030*\004\030\0010\0132\006\020$\032\0020#2\006\020&\032\0020%2\006\020(\032\0020'2\006\020)\032\0020\t2\006\020*\032\0020\tH\002ø\001\000¢\006\004\b+\020,JH\020.\032\0020\030*\004\030\0010\0132\006\020$\032\0020#2\006\020&\032\0020%2\006\020(\032\0020'2\006\020)\032\0020\t2\006\020*\032\0020\t2\006\020-\032\0020\024H\002ø\001\000¢\006\004\b.\020/JH\0200\032\0020\030*\004\030\0010\0132\006\020$\032\0020#2\006\020&\032\0020%2\006\020(\032\0020'2\006\020)\032\0020\t2\006\020*\032\0020\t2\006\020-\032\0020\024H\002ø\001\000¢\006\004\b0\020/J\023\0201\032\0020\000*\0020\003H\002¢\006\004\b1\0202J\"\0206\032\0020\0302\006\0203\032\0020\0002\006\0205\032\00204H\002ø\001\000¢\006\004\b6\0207J\"\0208\032\0020\0302\006\0203\032\0020\0002\006\0205\032\00204H\002ø\001\000¢\006\004\b8\0207J\"\020:\032\0020%2\006\0203\032\0020\0002\006\0209\032\0020%H\002ø\001\000¢\006\004\b:\020;J'\020?\032\0020\0302\006\0203\032\0020\0002\006\020=\032\0020<2\006\020>\032\0020\tH\002¢\006\004\b?\020@J\037\020B\032\0020\0302\006\020A\032\0020<2\006\020>\032\0020\tH\002¢\006\004\bB\020CJ\032\020D\032\0020%2\006\020&\032\0020%H\002ø\001\000¢\006\004\bD\020EJ\036\020F\032\004\030\0010\0132\n\020\017\032\006\022\002\b\0030\016ø\001\000¢\006\004\bF\020GJ\r\020H\032\0020\t¢\006\004\bH\020IJ\017\020J\032\0020\030H\020¢\006\004\bJ\020KJ\017\020L\032\0020\030H&¢\006\004\bL\020KJ\037\020P\032\0020\0302\006\020N\032\0020M2\006\020O\032\0020MH\024¢\006\004\bP\020QJ\017\020R\032\0020\030H\000¢\006\004\bR\020KJ\r\020S\032\0020\030¢\006\004\bS\020KJ8\020T\032\0020\0302\006\020\023\032\0020\0222\006\020\025\032\0020\0242\024\020\031\032\020\022\004\022\0020\027\022\004\022\0020\030\030\0010\026H\024ø\001\000¢\006\004\bT\020\033J6\020U\032\0020\0302\006\020\023\032\0020\0222\006\020\025\032\0020\0242\024\020\031\032\020\022\004\022\0020\027\022\004\022\0020\030\030\0010\026ø\001\000¢\006\004\bU\020\033J\025\020V\032\0020\0302\006\020\035\032\0020\034¢\006\004\bV\020\037J\027\020W\032\0020\0302\006\020\035\032\0020\034H\026¢\006\004\bW\020\037J\r\020X\032\0020\030¢\006\004\bX\020KJ-\020Z\032\0020\0302\024\020\031\032\020\022\004\022\0020\027\022\004\022\0020\030\030\0010\0262\b\b\002\020Y\032\0020\t¢\006\004\bZ\020[J8\020\\\032\0020\0302\006\020$\032\0020#2\006\020&\032\0020%2\006\020(\032\0020'2\006\020)\032\0020\t2\006\020*\032\0020\tø\001\000¢\006\004\b\\\020]J:\020^\032\0020\0302\006\020$\032\0020#2\006\020&\032\0020%2\006\020(\032\0020'2\006\020)\032\0020\t2\006\020*\032\0020\tH\026ø\001\000¢\006\004\b^\020]J\r\020`\032\0020_¢\006\004\b`\020aJ\032\020c\032\0020%2\006\020b\032\0020%H\026ø\001\000¢\006\004\bc\020EJ\032\020e\032\0020%2\006\020d\032\0020%H\026ø\001\000¢\006\004\be\020EJ\"\020h\032\0020%2\006\020f\032\0020\0032\006\020g\032\0020%H\026ø\001\000¢\006\004\bh\020iJ\"\020j\032\0020\0302\006\020f\032\0020\0032\006\0205\032\00204H\026ø\001\000¢\006\004\bj\020kJ\037\020l\032\0020_2\006\020f\032\0020\0032\006\020>\032\0020\tH\026¢\006\004\bl\020mJ\032\020n\032\0020%2\006\020d\032\0020%H\026ø\001\000¢\006\004\bn\020EJ\032\020o\032\0020%2\006\020\023\032\0020%H\026ø\001\000¢\006\004\bo\020EJ\032\020p\032\0020%2\006\020\023\032\0020%H\026ø\001\000¢\006\004\bp\020EJ\037\020s\032\0020\0302\006\020\035\032\0020\0342\006\020r\032\0020qH\004¢\006\004\bs\020tJ\r\020u\032\0020\030¢\006\004\bu\020KJ\r\020v\032\0020\030¢\006\004\bv\020KJ)\020x\032\0020\0302\006\020A\032\0020<2\006\020>\032\0020\t2\b\b\002\020w\032\0020\tH\000¢\006\004\bx\020yJ\032\020z\032\0020\t2\006\020&\032\0020%H\004ø\001\000¢\006\004\bz\020{J\032\020|\032\0020\t2\006\020&\032\0020%H\004ø\001\000¢\006\004\b|\020{J\017\020}\032\0020\030H\026¢\006\004\b}\020KJ\017\020~\032\0020\030H\026¢\006\004\b~\020KJ\032\020\001\032\0020\0002\006\020\032\0020\000H\000¢\006\006\b\001\020\001J\017\020\001\032\0020\t¢\006\005\b\001\020IJ\037\020\001\032\0030\0012\b\020\001\032\0030\001H\004ø\001\000¢\006\005\b\001\020EJ'\020\001\032\0020\0242\006\020&\032\0020%2\b\020\001\032\0030\001H\004ø\001\000¢\006\006\b\001\020\001R\036\020\006\032\0020\0058\026X\004¢\006\020\n\006\b\001\020\001\032\006\b\001\020\001R+\020\001\032\004\030\0010\0008\000@\000X\016¢\006\030\n\006\b\001\020\001\032\006\b\001\020\001\"\006\b\001\020\001R+\020\001\032\004\030\0010\0008\000@\000X\016¢\006\030\n\006\b\001\020\001\032\006\b\001\020\001\"\006\b\001\020\001R\031\020\001\032\0020\t8\002@\002X\016¢\006\b\n\006\b\001\020\001R\030\020\001\032\0020\t8\002@\002X\016¢\006\007\n\005\be\020\001RE\020\031\032\020\022\004\022\0020\027\022\004\022\0020\030\030\0010\0262\025\020\001\032\020\022\004\022\0020\027\022\004\022\0020\030\030\0010\0268\004@BX\016¢\006\020\n\006\b\001\020\001\032\006\b\001\020\001R\032\020£\001\032\0030 \0018\002@\002X\016¢\006\b\n\006\b¡\001\020¢\001R\032\020§\001\032\0030¤\0018\002@\002X\016¢\006\b\n\006\b¥\001\020¦\001R\031\020ª\001\032\0020\0248\002@\002X\016¢\006\b\n\006\b¨\001\020©\001R\034\020®\001\032\005\030\0010«\0018\002@\002X\016¢\006\b\n\006\b¬\001\020­\001R)\020³\001\032\022\022\005\022\0030°\001\022\004\022\0020M\030\0010¯\0018\002@\002X\016¢\006\b\n\006\b±\001\020²\001R6\020\023\032\0020\0222\007\020\001\032\0020\0228\026@TX\016ø\001\000ø\001\001¢\006\027\n\005\b´\001\020c\032\006\bµ\001\020¶\001\"\006\b·\001\020¸\001R0\020\025\032\0020\0242\007\020\001\032\0020\0248\006@DX\016¢\006\027\n\005\bn\020©\001\032\006\b¹\001\020º\001\"\006\b»\001\020¼\001R\033\020¿\001\032\004\030\0010<8\002@\002X\016¢\006\b\n\006\b½\001\020¾\001R\034\020Ã\001\032\005\030\0010À\0018\002@\002X\016¢\006\b\n\006\bÁ\001\020Â\001R*\020Æ\001\032\016\022\004\022\0020\034\022\004\022\0020\0300\0268\002X\004¢\006\017\n\006\bÄ\001\020\001\022\005\bÅ\001\020KR\036\020Ê\001\032\t\022\004\022\0020\0300Ç\0018\002X\004¢\006\b\n\006\bÈ\001\020É\001R)\020Í\001\032\0020\t2\007\020\001\032\0020\t8\000@BX\016¢\006\017\n\006\bË\001\020\001\032\005\bÌ\001\020IR0\020Ó\001\032\005\030\0010Î\0012\n\020\001\032\005\030\0010Î\0018\006@BX\016¢\006\020\n\006\bÏ\001\020Ð\001\032\006\bÑ\001\020Ò\001R\030\020×\001\032\0030Ô\0018BX\004¢\006\b\032\006\bÕ\001\020Ö\001R\027\020Ú\001\032\0020\0138&X¦\004¢\006\b\032\006\bØ\001\020Ù\001R\030\020Ý\001\032\0030¤\0018VX\004¢\006\b\032\006\bÛ\001\020Ü\001R\027\020ß\001\032\0020\0248VX\004¢\006\b\032\006\bÞ\001\020º\001R\027\020á\001\032\0020\0248VX\004¢\006\b\032\006\bà\001\020º\001R\027\020ä\001\032\0020\0038VX\004¢\006\b\032\006\bâ\001\020ã\001R\033\020ç\001\032\0030å\0018Fø\001\000ø\001\001¢\006\b\032\006\bæ\001\020¶\001R\030\020ë\001\032\0030è\0018VX\004¢\006\b\032\006\bé\001\020ê\001R\031\020î\001\032\004\030\0010\0018VX\004¢\006\b\032\006\bì\001\020í\001R\026\020ð\001\032\0020\t8VX\004¢\006\007\032\005\bï\001\020IR\026\020ò\001\032\0020\t8VX\004¢\006\007\032\005\bñ\001\020IR,\020ø\001\032\0030«\0012\b\020ó\001\032\0030«\0018P@PX\016¢\006\020\032\006\bô\001\020õ\001\"\006\bö\001\020÷\001R0\020þ\001\032\005\030\0010ù\0012\n\020\001\032\005\030\0010ù\0018&@dX¦\016¢\006\020\032\006\bú\001\020û\001\"\006\bü\001\020ý\001R\032\020\002\032\005\030\0010ÿ\0018VX\004¢\006\b\032\006\b\002\020\002R\026\020\002\032\004\030\0010\0038F¢\006\b\032\006\b¬\001\020ã\001R\027\020\002\032\0020<8DX\004¢\006\b\032\006\b\002\020\002R\036\020\002\032\0030\0028@X\004ø\001\000ø\001\001¢\006\b\032\006\b\002\020¶\001R\026\020\002\032\0020\t8VX\004¢\006\007\032\005\b\002\020IR\033\020\001\032\0030\0018Fø\001\000ø\001\001¢\006\b\032\006\b\002\020¶\001\002\013\n\005\b¡\0360\001\n\002\b!¨\006\002"}, d2 = {"Landroidx/compose/ui/node/n;", "Landroidx/compose/ui/node/i;", "Ldbxyzptlk/d1/F;", "Ldbxyzptlk/d1/r;", "Ldbxyzptlk/f1/T;", "Landroidx/compose/ui/node/f;", "layoutNode", "<init>", "(Landroidx/compose/ui/node/f;)V", "", "includeTail", "Landroidx/compose/ui/d$c;", "u2", "(Z)Landroidx/compose/ui/d$c;", "Ldbxyzptlk/f1/K;", "type", "s2", "(I)Z", "Ldbxyzptlk/z1/n;", "position", "", "zIndex", "Lkotlin/Function1;", "Landroidx/compose/ui/graphics/c;", "Ldbxyzptlk/pI/D;", "layerBlock", "L2", "(JFLdbxyzptlk/CI/l;)V", "Ldbxyzptlk/Q0/j0;", "canvas", "Z1", "(Ldbxyzptlk/Q0/j0;)V", "invokeOnLayoutChange", "c3", "(Z)V", "Landroidx/compose/ui/node/n$f;", "hitTestSource", "Ldbxyzptlk/P0/f;", "pointerPosition", "Ldbxyzptlk/f1/q;", "hitTestResult", "isTouchEvent", "isInLayer", "v2", "(Landroidx/compose/ui/d$c;Landroidx/compose/ui/node/n$f;JLdbxyzptlk/f1/q;ZZ)V", "distanceFromEdge", "w2", "(Landroidx/compose/ui/d$c;Landroidx/compose/ui/node/n$f;JLdbxyzptlk/f1/q;ZZF)V", "U2", "V2", "(Ldbxyzptlk/d1/r;)Landroidx/compose/ui/node/n;", "ancestor", "Ldbxyzptlk/Q0/H0;", "matrix", "Z2", "(Landroidx/compose/ui/node/n;[F)V", "Y2", "offset", "U1", "(Landroidx/compose/ui/node/n;J)J", "Ldbxyzptlk/P0/d;", "rect", "clipBounds", "T1", "(Landroidx/compose/ui/node/n;Ldbxyzptlk/P0/d;Z)V", "bounds", "d2", "(Ldbxyzptlk/P0/d;Z)V", "C2", "(J)J", "t2", "(I)Landroidx/compose/ui/d$c;", "B2", "()Z", "u1", "()V", "a2", "", "width", "height", "G2", "(II)V", "D2", "H2", "T0", "M2", "X1", "K2", "I2", "forceUpdateLayerParameters", "a3", "(Ldbxyzptlk/CI/l;Z)V", "x2", "(Landroidx/compose/ui/node/n$f;JLdbxyzptlk/f1/q;ZZ)V", "y2", "Ldbxyzptlk/P0/h;", "X2", "()Ldbxyzptlk/P0/h;", "relativeToWindow", "J", "relativeToLocal", "m", "sourceCoordinates", "relativeToSource", "D", "(Ldbxyzptlk/d1/r;J)J", "I", "(Ldbxyzptlk/d1/r;[F)V", "Q", "(Ldbxyzptlk/d1/r;Z)Ldbxyzptlk/P0/h;", "u", "W2", "c2", "Ldbxyzptlk/Q0/L0;", "paint", "Y1", "(Ldbxyzptlk/Q0/j0;Ldbxyzptlk/Q0/L0;)V", "F2", "J2", "clipToMinimumTouchTargetSize", "N2", "(Ldbxyzptlk/P0/d;ZZ)V", "e3", "(J)Z", "A2", "z2", "E2", "other", "b2", "(Landroidx/compose/ui/node/n;)Landroidx/compose/ui/node/n;", "T2", "Ldbxyzptlk/P0/l;", "minimumTouchTargetSize", "V1", "W1", "(JJ)F", "i", "Landroidx/compose/ui/node/f;", "j2", "()Landroidx/compose/ui/node/f;", "j", "Landroidx/compose/ui/node/n;", "p2", "()Landroidx/compose/ui/node/n;", "R2", "(Landroidx/compose/ui/node/n;)V", "wrapped", "k", "q2", "S2", "wrappedBy", "l", "Z", "released", "isClipping", "<set-?>", "n", "Ldbxyzptlk/CI/l;", "getLayerBlock", "()Ldbxyzptlk/CI/l;", "Ldbxyzptlk/z1/d;", "o", "Ldbxyzptlk/z1/d;", "layerDensity", "Ldbxyzptlk/z1/t;", "p", "Ldbxyzptlk/z1/t;", "layerLayoutDirection", "q", "F", "lastLayerAlpha", "Ldbxyzptlk/d1/H;", "r", "Ldbxyzptlk/d1/H;", "_measureResult", "", "Ldbxyzptlk/d1/a;", "s", "Ljava/util/Map;", "oldAlignmentLines", "t", "k1", "()J", "Q2", "(J)V", "r2", "()F", "setZIndex", "(F)V", "v", "Ldbxyzptlk/P0/d;", "_rectCache", "Ldbxyzptlk/f1/u;", "w", "Ldbxyzptlk/f1/u;", "layerPositionalProperties", "x", "getDrawBlock$annotations", "drawBlock", "Lkotlin/Function0;", "y", "Ldbxyzptlk/CI/a;", "invalidateParentLayer", "z", "g2", "lastLayerDrawingWasSkipped", "Ldbxyzptlk/f1/S;", "A", "Ldbxyzptlk/f1/S;", "i2", "()Ldbxyzptlk/f1/S;", "layer", "Ldbxyzptlk/f1/U;", "n2", "()Ldbxyzptlk/f1/U;", "snapshotObserver", "o2", "()Landroidx/compose/ui/d$c;", "tail", "getLayoutDirection", "()Ldbxyzptlk/z1/t;", "layoutDirection", "getDensity", "density", "v1", "fontScale", "f2", "()Ldbxyzptlk/d1/r;", "coordinates", "Ldbxyzptlk/z1/r;", "a", "size", "Ldbxyzptlk/f1/b;", "e2", "()Ldbxyzptlk/f1/b;", "alignmentLinesOwner", "f1", "()Landroidx/compose/ui/node/i;", "child", "g1", "hasMeasureResult", "G", "isAttached", "value", "h1", "()Ldbxyzptlk/d1/H;", "P2", "(Ldbxyzptlk/d1/H;)V", "measureResult", "Landroidx/compose/ui/node/j;", "k2", "()Landroidx/compose/ui/node/j;", "setLookaheadDelegate", "(Landroidx/compose/ui/node/j;)V", "lookaheadDelegate", "", "b", "()Ljava/lang/Object;", "parentData", "parentLayoutCoordinates", "m2", "()Ldbxyzptlk/P0/d;", "rectCache", "Ldbxyzptlk/z1/b;", "h2", "lastMeasurementConstraints", "k0", "isValidOwnerScope", "l2", "B", "e", "f", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public abstract class n extends i implements F, r, T {
  public static final e B = new e(null);
  
  public static final dbxyzptlk.CI.l<n, D> C = d.f;
  
  public static final dbxyzptlk.CI.l<n, D> D = c.f;
  
  public static final androidx.compose.ui.graphics.d E = new androidx.compose.ui.graphics.d();
  
  public static final u F = new u();
  
  public static final float[] G = H0.c(null, 1, null);
  
  public static final f H = new a();
  
  public static final f I = new b();
  
  public S A;
  
  public final f i;
  
  public n j;
  
  public n k;
  
  public boolean l;
  
  public boolean m;
  
  public dbxyzptlk.CI.l<? super androidx.compose.ui.graphics.c, D> n;
  
  public dbxyzptlk.z1.d o;
  
  public t p;
  
  public float q;
  
  public H r;
  
  public Map<dbxyzptlk.d1.a, Integer> s;
  
  public long t;
  
  public float u;
  
  public dbxyzptlk.P0.d v;
  
  public u w;
  
  public final dbxyzptlk.CI.l<j0, D> x;
  
  public final dbxyzptlk.CI.a<D> y;
  
  public boolean z;
  
  public n(f paramf) {
    this.i = paramf;
    this.o = j2().I();
    this.p = j2().getLayoutDirection();
    this.q = 0.8F;
    this.t = dbxyzptlk.z1.n.b.a();
    this.x = new g(this);
    this.y = new j(this);
  }
  
  private final U n2() {
    return D.b(j2()).getSnapshotObserver();
  }
  
  public final boolean A2(long paramLong) {
    boolean bool;
    float f2 = dbxyzptlk.P0.f.o(paramLong);
    float f1 = dbxyzptlk.P0.f.p(paramLong);
    if (f2 >= 0.0F && f1 >= 0.0F && f2 < K0() && f1 < F0()) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public final boolean B2() {
    if (this.A != null && this.q <= 0.0F)
      return true; 
    n n1 = this.k;
    return (n1 != null) ? n1.B2() : false;
  }
  
  public final long C2(long paramLong) {
    float f1 = dbxyzptlk.P0.f.o(paramLong);
    if (f1 < 0.0F) {
      f1 = -f1;
    } else {
      f1 -= K0();
    } 
    float f2 = Math.max(0.0F, f1);
    f1 = dbxyzptlk.P0.f.p(paramLong);
    if (f1 < 0.0F) {
      f1 = -f1;
    } else {
      f1 -= F0();
    } 
    return dbxyzptlk.P0.g.a(f2, Math.max(0.0F, f1));
  }
  
  public long D(r paramr, long paramLong) {
    if (paramr instanceof B)
      return dbxyzptlk.P0.f.w(paramr.D(this, dbxyzptlk.P0.f.w(paramLong))); 
    paramr = V2(paramr);
    paramr.D2();
    n n1 = b2((n)paramr);
    while (paramr != n1) {
      paramLong = paramr.W2(paramLong);
      paramr = ((n)paramr).k;
      s.e(paramr);
    } 
    return U1(n1, paramLong);
  }
  
  public final void D2() {
    j2().S().P();
  }
  
  public void E2() {
    S s = this.A;
    if (s != null)
      s.invalidate(); 
  }
  
  public final void F2() {
    a3(this.n, true);
    S s = this.A;
    if (s != null)
      s.invalidate(); 
  }
  
  public boolean G() {
    return o2().R1();
  }
  
  public void G2(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: getfield A : Ldbxyzptlk/f1/S;
    //   4: astore #5
    //   6: aload #5
    //   8: ifnull -> 26
    //   11: aload #5
    //   13: iload_1
    //   14: iload_2
    //   15: invokestatic a : (II)J
    //   18: invokeinterface d : (J)V
    //   23: goto -> 42
    //   26: aload_0
    //   27: getfield k : Landroidx/compose/ui/node/n;
    //   30: astore #5
    //   32: aload #5
    //   34: ifnull -> 42
    //   37: aload #5
    //   39: invokevirtual z2 : ()V
    //   42: aload_0
    //   43: iload_1
    //   44: iload_2
    //   45: invokestatic a : (II)J
    //   48: invokevirtual U0 : (J)V
    //   51: aload_0
    //   52: iconst_0
    //   53: invokevirtual c3 : (Z)V
    //   56: iconst_4
    //   57: invokestatic a : (I)I
    //   60: istore_3
    //   61: iload_3
    //   62: invokestatic i : (I)Z
    //   65: istore #4
    //   67: aload_0
    //   68: invokevirtual o2 : ()Landroidx/compose/ui/d$c;
    //   71: astore #10
    //   73: iload #4
    //   75: ifeq -> 81
    //   78: goto -> 100
    //   81: aload #10
    //   83: invokevirtual O1 : ()Landroidx/compose/ui/d$c;
    //   86: astore #5
    //   88: aload #5
    //   90: astore #10
    //   92: aload #5
    //   94: ifnonnull -> 100
    //   97: goto -> 376
    //   100: aload_0
    //   101: iload #4
    //   103: invokestatic N1 : (Landroidx/compose/ui/node/n;Z)Landroidx/compose/ui/d$c;
    //   106: astore #6
    //   108: aload #6
    //   110: ifnull -> 376
    //   113: aload #6
    //   115: invokevirtual H1 : ()I
    //   118: iload_3
    //   119: iand
    //   120: ifeq -> 376
    //   123: aload #6
    //   125: invokevirtual M1 : ()I
    //   128: iload_3
    //   129: iand
    //   130: ifeq -> 359
    //   133: aload #6
    //   135: astore #8
    //   137: aconst_null
    //   138: astore #5
    //   140: aload #8
    //   142: ifnull -> 359
    //   145: aload #8
    //   147: instanceof dbxyzptlk/f1/n
    //   150: ifeq -> 170
    //   153: aload #8
    //   155: checkcast dbxyzptlk/f1/n
    //   158: invokeinterface q0 : ()V
    //   163: aload #5
    //   165: astore #7
    //   167: goto -> 345
    //   170: aload #5
    //   172: astore #7
    //   174: aload #8
    //   176: invokevirtual M1 : ()I
    //   179: iload_3
    //   180: iand
    //   181: ifeq -> 345
    //   184: aload #5
    //   186: astore #7
    //   188: aload #8
    //   190: instanceof dbxyzptlk/f1/i
    //   193: ifeq -> 345
    //   196: aload #8
    //   198: checkcast dbxyzptlk/f1/i
    //   201: invokevirtual l2 : ()Landroidx/compose/ui/d$c;
    //   204: astore #7
    //   206: iconst_0
    //   207: istore_2
    //   208: aload #7
    //   210: ifnull -> 333
    //   213: aload #8
    //   215: astore #9
    //   217: aload #5
    //   219: astore #11
    //   221: iload_2
    //   222: istore_1
    //   223: aload #7
    //   225: invokevirtual M1 : ()I
    //   228: iload_3
    //   229: iand
    //   230: ifeq -> 313
    //   233: iload_2
    //   234: iconst_1
    //   235: iadd
    //   236: istore_1
    //   237: iload_1
    //   238: iconst_1
    //   239: if_icmpne -> 253
    //   242: aload #7
    //   244: astore #9
    //   246: aload #5
    //   248: astore #11
    //   250: goto -> 313
    //   253: aload #5
    //   255: astore #9
    //   257: aload #5
    //   259: ifnonnull -> 277
    //   262: new dbxyzptlk/z0/d
    //   265: dup
    //   266: bipush #16
    //   268: anewarray androidx/compose/ui/d$c
    //   271: iconst_0
    //   272: invokespecial <init> : ([Ljava/lang/Object;I)V
    //   275: astore #9
    //   277: aload #8
    //   279: astore #5
    //   281: aload #8
    //   283: ifnull -> 297
    //   286: aload #9
    //   288: aload #8
    //   290: invokevirtual c : (Ljava/lang/Object;)Z
    //   293: pop
    //   294: aconst_null
    //   295: astore #5
    //   297: aload #9
    //   299: aload #7
    //   301: invokevirtual c : (Ljava/lang/Object;)Z
    //   304: pop
    //   305: aload #9
    //   307: astore #11
    //   309: aload #5
    //   311: astore #9
    //   313: aload #7
    //   315: invokevirtual I1 : ()Landroidx/compose/ui/d$c;
    //   318: astore #7
    //   320: aload #9
    //   322: astore #8
    //   324: aload #11
    //   326: astore #5
    //   328: iload_1
    //   329: istore_2
    //   330: goto -> 208
    //   333: aload #5
    //   335: astore #7
    //   337: iload_2
    //   338: iconst_1
    //   339: if_icmpne -> 345
    //   342: goto -> 140
    //   345: aload #7
    //   347: invokestatic b : (Ldbxyzptlk/z0/d;)Landroidx/compose/ui/d$c;
    //   350: astore #8
    //   352: aload #7
    //   354: astore #5
    //   356: goto -> 140
    //   359: aload #6
    //   361: aload #10
    //   363: if_acmpeq -> 376
    //   366: aload #6
    //   368: invokevirtual I1 : ()Landroidx/compose/ui/d$c;
    //   371: astore #6
    //   373: goto -> 108
    //   376: aload_0
    //   377: invokevirtual j2 : ()Landroidx/compose/ui/node/f;
    //   380: invokevirtual l0 : ()Landroidx/compose/ui/node/Owner;
    //   383: astore #5
    //   385: aload #5
    //   387: ifnull -> 401
    //   390: aload #5
    //   392: aload_0
    //   393: invokevirtual j2 : ()Landroidx/compose/ui/node/f;
    //   396: invokeinterface u : (Landroidx/compose/ui/node/f;)V
    //   401: return
  }
  
  public final void H2() {
    // Byte code:
    //   0: aload_0
    //   1: sipush #128
    //   4: invokestatic a : (I)I
    //   7: invokevirtual s2 : (I)Z
    //   10: ifeq -> 405
    //   13: getstatic dbxyzptlk/I0/k.e : Ldbxyzptlk/I0/k$a;
    //   16: invokevirtual c : ()Ldbxyzptlk/I0/k;
    //   19: astore #12
    //   21: aload #12
    //   23: invokevirtual l : ()Ldbxyzptlk/I0/k;
    //   26: astore #13
    //   28: sipush #128
    //   31: invokestatic a : (I)I
    //   34: istore_3
    //   35: iload_3
    //   36: invokestatic i : (I)Z
    //   39: istore #4
    //   41: iload #4
    //   43: ifeq -> 60
    //   46: aload_0
    //   47: invokevirtual o2 : ()Landroidx/compose/ui/d$c;
    //   50: astore #10
    //   52: goto -> 81
    //   55: astore #5
    //   57: goto -> 387
    //   60: aload_0
    //   61: invokevirtual o2 : ()Landroidx/compose/ui/d$c;
    //   64: invokevirtual O1 : ()Landroidx/compose/ui/d$c;
    //   67: astore #5
    //   69: aload #5
    //   71: astore #10
    //   73: aload #5
    //   75: ifnonnull -> 81
    //   78: goto -> 362
    //   81: aload_0
    //   82: iload #4
    //   84: invokestatic N1 : (Landroidx/compose/ui/node/n;Z)Landroidx/compose/ui/d$c;
    //   87: astore #6
    //   89: aload #6
    //   91: ifnull -> 362
    //   94: aload #6
    //   96: invokevirtual H1 : ()I
    //   99: iload_3
    //   100: iand
    //   101: ifeq -> 362
    //   104: aload #6
    //   106: invokevirtual M1 : ()I
    //   109: iload_3
    //   110: iand
    //   111: ifeq -> 345
    //   114: aload #6
    //   116: astore #8
    //   118: aconst_null
    //   119: astore #5
    //   121: aload #8
    //   123: ifnull -> 345
    //   126: aload #8
    //   128: instanceof dbxyzptlk/f1/v
    //   131: ifeq -> 155
    //   134: aload #8
    //   136: checkcast dbxyzptlk/f1/v
    //   139: aload_0
    //   140: invokevirtual G0 : ()J
    //   143: invokeinterface v : (J)V
    //   148: aload #5
    //   150: astore #7
    //   152: goto -> 331
    //   155: aload #5
    //   157: astore #7
    //   159: aload #8
    //   161: invokevirtual M1 : ()I
    //   164: iload_3
    //   165: iand
    //   166: ifeq -> 331
    //   169: aload #5
    //   171: astore #7
    //   173: aload #8
    //   175: instanceof dbxyzptlk/f1/i
    //   178: ifeq -> 331
    //   181: aload #8
    //   183: checkcast dbxyzptlk/f1/i
    //   186: invokevirtual l2 : ()Landroidx/compose/ui/d$c;
    //   189: astore #7
    //   191: iconst_0
    //   192: istore_2
    //   193: aload #7
    //   195: ifnull -> 319
    //   198: aload #8
    //   200: astore #9
    //   202: aload #5
    //   204: astore #11
    //   206: iload_2
    //   207: istore_1
    //   208: aload #7
    //   210: invokevirtual M1 : ()I
    //   213: iload_3
    //   214: iand
    //   215: ifeq -> 299
    //   218: iload_2
    //   219: iconst_1
    //   220: iadd
    //   221: istore_1
    //   222: iload_1
    //   223: iconst_1
    //   224: if_icmpne -> 238
    //   227: aload #7
    //   229: astore #9
    //   231: aload #5
    //   233: astore #11
    //   235: goto -> 299
    //   238: aload #5
    //   240: astore #9
    //   242: aload #5
    //   244: ifnonnull -> 263
    //   247: new dbxyzptlk/z0/d
    //   250: astore #9
    //   252: aload #9
    //   254: bipush #16
    //   256: anewarray androidx/compose/ui/d$c
    //   259: iconst_0
    //   260: invokespecial <init> : ([Ljava/lang/Object;I)V
    //   263: aload #8
    //   265: astore #5
    //   267: aload #8
    //   269: ifnull -> 283
    //   272: aload #9
    //   274: aload #8
    //   276: invokevirtual c : (Ljava/lang/Object;)Z
    //   279: pop
    //   280: aconst_null
    //   281: astore #5
    //   283: aload #9
    //   285: aload #7
    //   287: invokevirtual c : (Ljava/lang/Object;)Z
    //   290: pop
    //   291: aload #9
    //   293: astore #11
    //   295: aload #5
    //   297: astore #9
    //   299: aload #7
    //   301: invokevirtual I1 : ()Landroidx/compose/ui/d$c;
    //   304: astore #7
    //   306: aload #9
    //   308: astore #8
    //   310: aload #11
    //   312: astore #5
    //   314: iload_1
    //   315: istore_2
    //   316: goto -> 193
    //   319: aload #5
    //   321: astore #7
    //   323: iload_2
    //   324: iconst_1
    //   325: if_icmpne -> 331
    //   328: goto -> 121
    //   331: aload #7
    //   333: invokestatic b : (Ldbxyzptlk/z0/d;)Landroidx/compose/ui/d$c;
    //   336: astore #8
    //   338: aload #7
    //   340: astore #5
    //   342: goto -> 121
    //   345: aload #6
    //   347: aload #10
    //   349: if_acmpeq -> 362
    //   352: aload #6
    //   354: invokevirtual I1 : ()Landroidx/compose/ui/d$c;
    //   357: astore #6
    //   359: goto -> 89
    //   362: getstatic dbxyzptlk/pI/D.a : Ldbxyzptlk/pI/D;
    //   365: astore #5
    //   367: aload #12
    //   369: aload #13
    //   371: invokevirtual s : (Ldbxyzptlk/I0/k;)V
    //   374: aload #12
    //   376: invokevirtual d : ()V
    //   379: goto -> 405
    //   382: astore #5
    //   384: goto -> 397
    //   387: aload #12
    //   389: aload #13
    //   391: invokevirtual s : (Ldbxyzptlk/I0/k;)V
    //   394: aload #5
    //   396: athrow
    //   397: aload #12
    //   399: invokevirtual d : ()V
    //   402: aload #5
    //   404: athrow
    //   405: return
    // Exception table:
    //   from	to	target	type
    //   21	28	382	finally
    //   28	41	55	finally
    //   46	52	55	finally
    //   60	69	55	finally
    //   81	89	55	finally
    //   94	114	55	finally
    //   126	148	55	finally
    //   159	169	55	finally
    //   173	191	55	finally
    //   208	218	55	finally
    //   247	263	55	finally
    //   272	280	55	finally
    //   283	291	55	finally
    //   299	306	55	finally
    //   331	338	55	finally
    //   352	359	55	finally
    //   362	367	55	finally
    //   367	374	382	finally
    //   387	397	382	finally
  }
  
  public void I(r paramr, float[] paramArrayOffloat) {
    n n1 = V2(paramr);
    n1.D2();
    paramr = b2(n1);
    H0.h(paramArrayOffloat);
    n1.Z2((n)paramr, paramArrayOffloat);
    Y2((n)paramr, paramArrayOffloat);
  }
  
  public final void I2() {
    int j = K.a(128);
    boolean bool = L.i(j);
    androidx.compose.ui.d.c c2 = o2();
    if (!bool) {
      androidx.compose.ui.d.c c = c2.O1();
      c2 = c;
      if (c == null)
        return; 
    } 
    androidx.compose.ui.d.c c1 = N1(this, bool);
    while (c1 != null && (c1.H1() & j) != 0) {
      if ((c1.M1() & j) != 0) {
        androidx.compose.ui.d.c c4 = c1;
        androidx.compose.ui.d.c c3 = null;
        while (c4 != null) {
          dbxyzptlk.z0.d d2;
          if (c4 instanceof v) {
            ((v)c4).D(this);
            androidx.compose.ui.d.c c = c3;
          } else {
            androidx.compose.ui.d.c c = c3;
            if ((c4.M1() & j) != 0) {
              c = c3;
              if (c4 instanceof i) {
                dbxyzptlk.z0.d d3;
                c = ((i)c4).l2();
                int k;
                for (k = 0; c != null; k = m) {
                  dbxyzptlk.z0.d d4;
                  androidx.compose.ui.d.c c5 = c4;
                  androidx.compose.ui.d.c c6 = c3;
                  int m = k;
                  if ((c.M1() & j) != 0) {
                    m = k + 1;
                    if (m == 1) {
                      c5 = c;
                      c6 = c3;
                    } else {
                      dbxyzptlk.z0.d d5;
                      c5 = c3;
                      if (c3 == null)
                        d5 = new dbxyzptlk.z0.d((Object[])new androidx.compose.ui.d.c[16], 0); 
                      c3 = c4;
                      if (c4 != null) {
                        d5.c(c4);
                        c3 = null;
                      } 
                      d5.c(c);
                      d4 = d5;
                      c5 = c3;
                    } 
                  } 
                  c = c.I1();
                  c4 = c5;
                  d3 = d4;
                } 
                d2 = d3;
                if (k == 1)
                  continue; 
              } 
            } 
          } 
          c4 = h.b(d2);
          dbxyzptlk.z0.d d1 = d2;
        } 
      } 
      if (c1 != c2)
        c1 = c1.I1(); 
    } 
  }
  
  public long J(long paramLong) {
    if (G()) {
      r r1 = s.d(this);
      return D(r1, dbxyzptlk.P0.f.s(D.b(j2()).m(paramLong), s.e(r1)));
    } 
    throw new IllegalStateException("LayoutCoordinate operations are only valid when isAttached is true");
  }
  
  public final void J2() {
    this.l = true;
    this.y.invoke();
    if (this.A != null)
      b3(this, null, false, 2, null); 
  }
  
  public void K2(j0 paramj0) {
    n n1 = this.j;
    if (n1 != null)
      n1.X1(paramj0); 
  }
  
  public final void L2(long paramLong, float paramFloat, dbxyzptlk.CI.l<? super androidx.compose.ui.graphics.c, D> paraml) {
    b3(this, paraml, false, 2, null);
    if (!dbxyzptlk.z1.n.i(k1(), paramLong)) {
      Q2(paramLong);
      j2().S().F().M1();
      S s = this.A;
      if (s != null) {
        s.k(paramLong);
      } else {
        n n1 = this.k;
        if (n1 != null)
          n1.z2(); 
      } 
      l1(this);
      Owner owner = j2().l0();
      if (owner != null)
        owner.u(j2()); 
    } 
    this.u = paramFloat;
  }
  
  public final void M2(long paramLong, float paramFloat, dbxyzptlk.CI.l<? super androidx.compose.ui.graphics.c, D> paraml) {
    long l1 = y0();
    L2(o.a(dbxyzptlk.z1.n.j(paramLong) + dbxyzptlk.z1.n.j(l1), dbxyzptlk.z1.n.k(paramLong) + dbxyzptlk.z1.n.k(l1)), paramFloat, paraml);
  }
  
  public final void N2(dbxyzptlk.P0.d paramd, boolean paramBoolean1, boolean paramBoolean2) {
    S s = this.A;
    if (s != null) {
      if (this.m) {
        if (paramBoolean2) {
          long l1 = l2();
          float f3 = dbxyzptlk.P0.l.i(l1) / 2.0F;
          float f4 = dbxyzptlk.P0.l.g(l1) / 2.0F;
          paramd.e(-f3, -f4, r.h(a()) + f3, r.g(a()) + f4);
        } else if (paramBoolean1) {
          paramd.e(0.0F, 0.0F, r.h(a()), r.g(a()));
        } 
        if (paramd.f())
          return; 
      } 
      s.a(paramd, false);
    } 
    int j = dbxyzptlk.z1.n.j(k1());
    float f1 = paramd.b();
    float f2 = j;
    paramd.i(f1 + f2);
    paramd.j(paramd.c() + f2);
    j = dbxyzptlk.z1.n.k(k1());
    f1 = paramd.d();
    f2 = j;
    paramd.k(f1 + f2);
    paramd.h(paramd.a() + f2);
  }
  
  public void P2(H paramH) {
    H h = this.r;
    if (paramH != h) {
      this.r = paramH;
      if (h == null || paramH.getWidth() != h.getWidth() || paramH.getHeight() != h.getHeight())
        G2(paramH.getWidth(), paramH.getHeight()); 
      Map<dbxyzptlk.d1.a, Integer> map = this.s;
      if (((map != null && !map.isEmpty()) || !paramH.d().isEmpty()) && !s.c(paramH.d(), this.s)) {
        e2().d().m();
        Map<dbxyzptlk.d1.a, Integer> map1 = this.s;
        map = map1;
        if (map1 == null) {
          map = new LinkedHashMap<>();
          this.s = map;
        } 
        map.clear();
        map.putAll(paramH.d());
      } 
    } 
  }
  
  public h Q(r paramr, boolean paramBoolean) {
    if (G()) {
      if (paramr.G()) {
        n n1 = V2(paramr);
        n1.D2();
        n n2 = b2(n1);
        dbxyzptlk.P0.d d1 = m2();
        d1.i(0.0F);
        d1.k(0.0F);
        d1.j(r.h(paramr.a()));
        d1.h(r.g(paramr.a()));
        paramr = n1;
        while (paramr != n2) {
          O2((n)paramr, d1, paramBoolean, false, 4, null);
          if (d1.f())
            return h.e.a(); 
          paramr = ((n)paramr).k;
          s.e(paramr);
        } 
        T1(n2, d1, paramBoolean);
        return dbxyzptlk.P0.e.a(d1);
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("LayoutCoordinates ");
      stringBuilder.append(paramr);
      stringBuilder.append(" is not attached!");
      throw new IllegalStateException(stringBuilder.toString().toString());
    } 
    throw new IllegalStateException("LayoutCoordinate operations are only valid when isAttached is true");
  }
  
  public void Q2(long paramLong) {
    this.t = paramLong;
  }
  
  public final void R2(n paramn) {
    this.j = paramn;
  }
  
  public final void S2(n paramn) {
    this.k = paramn;
  }
  
  public void T0(long paramLong, float paramFloat, dbxyzptlk.CI.l<? super androidx.compose.ui.graphics.c, D> paraml) {
    L2(paramLong, paramFloat, paraml);
  }
  
  public final void T1(n paramn, dbxyzptlk.P0.d paramd, boolean paramBoolean) {
    if (paramn == this)
      return; 
    n n1 = this.k;
    if (n1 != null)
      n1.T1(paramn, paramd, paramBoolean); 
    d2(paramd, paramBoolean);
  }
  
  public final boolean T2() {
    androidx.compose.ui.d.c c = u2(L.i(K.a(16)));
    if (c == null)
      return false; 
    if (c.R1()) {
      int j = K.a(16);
      if (c.Q0().R1()) {
        c = c.Q0();
        if ((c.H1() & j) != 0)
          for (androidx.compose.ui.d.c c1 = c.I1(); c1 != null; c1 = c1.I1()) {
            if ((c1.M1() & j) != 0) {
              androidx.compose.ui.d.c c2 = c1;
              c = null;
              while (c2 != null) {
                dbxyzptlk.z0.d d2;
                if (c2 instanceof X) {
                  androidx.compose.ui.d.c c3 = c;
                  if (((X)c2).B1())
                    return true; 
                } else {
                  androidx.compose.ui.d.c c3 = c;
                  if ((c2.M1() & j) != 0) {
                    c3 = c;
                    if (c2 instanceof i) {
                      dbxyzptlk.z0.d d3;
                      c3 = ((i)c2).l2();
                      int k;
                      for (k = 0; c3 != null; k = m) {
                        dbxyzptlk.z0.d d4;
                        androidx.compose.ui.d.c c4 = c2;
                        androidx.compose.ui.d.c c5 = c;
                        int m = k;
                        if ((c3.M1() & j) != 0) {
                          m = k + 1;
                          if (m == 1) {
                            c4 = c3;
                            c5 = c;
                          } else {
                            dbxyzptlk.z0.d d5;
                            c4 = c;
                            if (c == null)
                              d5 = new dbxyzptlk.z0.d((Object[])new androidx.compose.ui.d.c[16], 0); 
                            c = c2;
                            if (c2 != null) {
                              d5.c(c2);
                              c = null;
                            } 
                            d5.c(c3);
                            d4 = d5;
                            c4 = c;
                          } 
                        } 
                        c3 = c3.I1();
                        c2 = c4;
                        d3 = d4;
                      } 
                      d2 = d3;
                      if (k == 1)
                        continue; 
                    } 
                  } 
                } 
                c2 = h.b(d2);
                dbxyzptlk.z0.d d1 = d2;
              } 
            } 
          }  
      } else {
        throw new IllegalStateException("visitLocalDescendants called on an unattached node");
      } 
    } 
    return false;
  }
  
  public final long U1(n paramn, long paramLong) {
    if (paramn == this)
      return paramLong; 
    n n1 = this.k;
    return (n1 == null || s.c(paramn, n1)) ? c2(paramLong) : c2(n1.U1(paramn, paramLong));
  }
  
  public final void U2(androidx.compose.ui.d.c paramc, f paramf, long paramLong, q paramq, boolean paramBoolean1, boolean paramBoolean2, float paramFloat) {
    if (paramc == null) {
      y2(paramf, paramLong, paramq, paramBoolean1, paramBoolean2);
    } else if (paramf.b(paramc)) {
      paramq.H(paramc, paramFloat, paramBoolean2, (dbxyzptlk.CI.a)new k(this, paramc, paramf, paramLong, paramq, paramBoolean1, paramBoolean2, paramFloat));
    } else {
      U2(J.a((dbxyzptlk.f1.g)paramc, paramf.a(), K.a(2)), paramf, paramLong, paramq, paramBoolean1, paramBoolean2, paramFloat);
    } 
  }
  
  public final long V1(long paramLong) {
    float f2 = dbxyzptlk.P0.l.i(paramLong);
    float f3 = K0();
    float f4 = dbxyzptlk.P0.l.g(paramLong);
    float f1 = F0();
    return m.a(Math.max(0.0F, (f2 - f3) / 2.0F), Math.max(0.0F, (f4 - f1) / 2.0F));
  }
  
  public final n V2(r paramr) {
    B b;
    if (paramr instanceof B) {
      b = (B)paramr;
    } else {
      b = null;
    } 
    if (b != null) {
      n n2 = b.b();
      n n1 = n2;
      if (n2 == null) {
        s.f(paramr, "null cannot be cast to non-null type androidx.compose.ui.node.NodeCoordinator");
        return (n)paramr;
      } 
      return n1;
    } 
    s.f(paramr, "null cannot be cast to non-null type androidx.compose.ui.node.NodeCoordinator");
    return (n)paramr;
  }
  
  public final float W1(long paramLong1, long paramLong2) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual K0 : ()I
    //   4: i2f
    //   5: fstore #7
    //   7: lload_3
    //   8: invokestatic i : (J)F
    //   11: fstore #5
    //   13: ldc_w Infinity
    //   16: fstore #6
    //   18: fload #7
    //   20: fload #5
    //   22: fcmpl
    //   23: iflt -> 43
    //   26: aload_0
    //   27: invokevirtual F0 : ()I
    //   30: i2f
    //   31: lload_3
    //   32: invokestatic g : (J)F
    //   35: fcmpl
    //   36: iflt -> 43
    //   39: ldc_w Infinity
    //   42: freturn
    //   43: aload_0
    //   44: lload_3
    //   45: invokevirtual V1 : (J)J
    //   48: lstore_3
    //   49: lload_3
    //   50: invokestatic i : (J)F
    //   53: fstore #8
    //   55: lload_3
    //   56: invokestatic g : (J)F
    //   59: fstore #7
    //   61: aload_0
    //   62: lload_1
    //   63: invokevirtual C2 : (J)J
    //   66: lstore_1
    //   67: fload #8
    //   69: fconst_0
    //   70: fcmpl
    //   71: ifgt -> 85
    //   74: fload #6
    //   76: fstore #5
    //   78: fload #7
    //   80: fconst_0
    //   81: fcmpl
    //   82: ifle -> 119
    //   85: fload #6
    //   87: fstore #5
    //   89: lload_1
    //   90: invokestatic o : (J)F
    //   93: fload #8
    //   95: fcmpg
    //   96: ifgt -> 119
    //   99: fload #6
    //   101: fstore #5
    //   103: lload_1
    //   104: invokestatic p : (J)F
    //   107: fload #7
    //   109: fcmpg
    //   110: ifgt -> 119
    //   113: lload_1
    //   114: invokestatic n : (J)F
    //   117: fstore #5
    //   119: fload #5
    //   121: freturn
  }
  
  public long W2(long paramLong) {
    S s = this.A;
    long l1 = paramLong;
    if (s != null)
      l1 = s.b(paramLong, false); 
    return o.c(l1, k1());
  }
  
  public final void X1(j0 paramj0) {
    S s = this.A;
    if (s != null) {
      s.f(paramj0);
    } else {
      float f1 = dbxyzptlk.z1.n.j(k1());
      float f2 = dbxyzptlk.z1.n.k(k1());
      paramj0.b(f1, f2);
      Z1(paramj0);
      paramj0.b(-f1, -f2);
    } 
  }
  
  public final h X2() {
    if (!G())
      return h.e.a(); 
    r r1 = s.d(this);
    dbxyzptlk.P0.d d1 = m2();
    long l1 = V1(l2());
    d1.i(-dbxyzptlk.P0.l.i(l1));
    d1.k(-dbxyzptlk.P0.l.g(l1));
    d1.j(K0() + dbxyzptlk.P0.l.i(l1));
    d1.h(F0() + dbxyzptlk.P0.l.g(l1));
    n n1 = this;
    while (n1 != r1) {
      n1.N2(d1, false, true);
      if (d1.f())
        return h.e.a(); 
      n1 = n1.k;
      s.e(n1);
    } 
    return dbxyzptlk.P0.e.a(d1);
  }
  
  public final void Y1(j0 paramj0, L0 paramL0) {
    paramj0.y(new h(0.5F, 0.5F, r.h(G0()) - 0.5F, r.g(G0()) - 0.5F), paramL0);
  }
  
  public final void Y2(n paramn, float[] paramArrayOffloat) {
    if (!s.c(paramn, this)) {
      n n1 = this.k;
      s.e(n1);
      n1.Y2(paramn, paramArrayOffloat);
      if (!dbxyzptlk.z1.n.i(k1(), dbxyzptlk.z1.n.b.a())) {
        float[] arrayOfFloat = G;
        H0.h(arrayOfFloat);
        H0.n(arrayOfFloat, -(dbxyzptlk.z1.n.j(k1())), -(dbxyzptlk.z1.n.k(k1())), 0.0F, 4, null);
        H0.k(paramArrayOffloat, arrayOfFloat);
      } 
      S s = this.A;
      if (s != null)
        s.j(paramArrayOffloat); 
    } 
  }
  
  public final void Z1(j0 paramj0) {
    androidx.compose.ui.d.c c = t2(K.a(4));
    if (c == null) {
      K2(paramj0);
    } else {
      j2().Z().b(paramj0, s.c(a()), this, c);
    } 
  }
  
  public final void Z2(n paramn, float[] paramArrayOffloat) {
    n n1 = this;
    while (!s.c(n1, paramn)) {
      S s = n1.A;
      if (s != null)
        s.c(paramArrayOffloat); 
      long l1 = n1.k1();
      if (!dbxyzptlk.z1.n.i(l1, dbxyzptlk.z1.n.b.a())) {
        float[] arrayOfFloat = G;
        H0.h(arrayOfFloat);
        H0.n(arrayOfFloat, dbxyzptlk.z1.n.j(l1), dbxyzptlk.z1.n.k(l1), 0.0F, 4, null);
        H0.k(paramArrayOffloat, arrayOfFloat);
      } 
      n1 = n1.k;
      s.e(n1);
    } 
  }
  
  public final long a() {
    return G0();
  }
  
  public abstract void a2();
  
  public final void a3(dbxyzptlk.CI.l<? super androidx.compose.ui.graphics.c, D> paraml, boolean paramBoolean) {
    boolean bool;
    f f1 = j2();
    if (paramBoolean || this.n != paraml || !s.c(this.o, f1.I()) || this.p != f1.getLayoutDirection()) {
      bool = true;
    } else {
      bool = false;
    } 
    this.n = paraml;
    this.o = f1.I();
    this.p = f1.getLayoutDirection();
    if (f1.I0() && paraml != null) {
      if (this.A == null) {
        S s = D.b(f1).i(this.x, this.y);
        s.d(G0());
        s.k(k1());
        this.A = s;
        d3(this, false, 1, null);
        f1.r1(true);
        this.y.invoke();
      } else if (bool) {
        d3(this, false, 1, null);
      } 
    } else {
      S s = this.A;
      if (s != null) {
        s.e();
        f1.r1(true);
        this.y.invoke();
        if (G()) {
          Owner owner = f1.l0();
          if (owner != null)
            owner.u(f1); 
        } 
      } 
      this.A = null;
      this.z = false;
    } 
  }
  
  public Object b() {
    if (j2().i0().r(K.a(64))) {
      o2();
      K k = new K();
      for (androidx.compose.ui.d.c c = j2().i0().p(); c != null; c = c.O1()) {
        if ((K.a(64) & c.M1()) != 0) {
          int j = K.a(64);
          androidx.compose.ui.d.c c1 = null;
          androidx.compose.ui.d.c c2 = c;
          while (c2 != null) {
            dbxyzptlk.z0.d d2;
            if (c2 instanceof V) {
              k.a = ((V)c2).E(j2().I(), k.a);
              androidx.compose.ui.d.c c3 = c1;
            } else {
              androidx.compose.ui.d.c c3 = c1;
              if ((c2.M1() & j) != 0) {
                c3 = c1;
                if (c2 instanceof i) {
                  dbxyzptlk.z0.d d3;
                  c3 = ((i)c2).l2();
                  int m;
                  for (m = 0; c3 != null; m = i1) {
                    dbxyzptlk.z0.d d4;
                    androidx.compose.ui.d.c c4 = c2;
                    androidx.compose.ui.d.c c5 = c1;
                    int i1 = m;
                    if ((c3.M1() & j) != 0) {
                      i1 = m + 1;
                      if (i1 == 1) {
                        c4 = c3;
                        c5 = c1;
                      } else {
                        dbxyzptlk.z0.d d5;
                        c4 = c1;
                        if (c1 == null)
                          d5 = new dbxyzptlk.z0.d((Object[])new androidx.compose.ui.d.c[16], 0); 
                        c1 = c2;
                        if (c2 != null) {
                          d5.c(c2);
                          c1 = null;
                        } 
                        d5.c(c3);
                        d4 = d5;
                        c4 = c1;
                      } 
                    } 
                    c3 = c3.I1();
                    c2 = c4;
                    d3 = d4;
                  } 
                  d2 = d3;
                  if (m == 1)
                    continue; 
                } 
              } 
            } 
            c2 = h.b(d2);
            dbxyzptlk.z0.d d1 = d2;
          } 
        } 
      } 
      return k.a;
    } 
    return null;
  }
  
  public final n b2(n paramn) {
    androidx.compose.ui.d.c c;
    f f1;
    f f5;
    f f3 = paramn.j2();
    f f4 = j2();
    f f2 = f3;
    if (f3 == f4) {
      androidx.compose.ui.d.c c1 = paramn.o2();
      c = o2();
      int j = K.a(2);
      if (c.Q0().R1()) {
        for (c = c.Q0().O1(); c != null; c = c.O1()) {
          if ((c.M1() & j) != 0 && c == c1)
            return paramn; 
        } 
        return this;
      } 
      throw new IllegalStateException("visitLocalAncestors called on an unattached node");
    } 
    while (true) {
      f3 = f4;
      if (c.J() > f4.J()) {
        f1 = c.m0();
        s.e(f1);
        continue;
      } 
      break;
    } 
    while (true) {
      f5 = f1;
      f4 = f3;
      if (f3.J() > f1.J()) {
        f3 = f3.m0();
        s.e(f3);
        continue;
      } 
      break;
    } 
    while (f5 != f4) {
      f5 = f5.m0();
      f4 = f4.m0();
      if (f5 != null && f4 != null)
        continue; 
      throw new IllegalArgumentException("layouts are not part of the same hierarchy");
    } 
    if (f4 == j2()) {
      paramn = this;
    } else if (f5 != paramn.j2()) {
      paramn = f5.N();
    } 
    return paramn;
  }
  
  public long c2(long paramLong) {
    long l1 = o.b(paramLong, k1());
    S s = this.A;
    paramLong = l1;
    if (s != null)
      paramLong = s.b(l1, true); 
    return paramLong;
  }
  
  public final void c3(boolean paramBoolean) {
    S s = this.A;
    if (s != null) {
      dbxyzptlk.CI.l<? super androidx.compose.ui.graphics.c, D> l1 = this.n;
      if (l1 != null) {
        androidx.compose.ui.graphics.d d1 = E;
        d1.x();
        d1.D(j2().I());
        d1.E(s.c(a()));
        n2().i(this, C, new l(l1));
        u u2 = this.w;
        u u1 = u2;
        if (u2 == null) {
          u1 = new u();
          this.w = u1;
        } 
        u1.a((androidx.compose.ui.graphics.c)d1);
        s.g(d1, j2().getLayoutDirection(), j2().I());
        this.m = d1.h();
        this.q = d1.b();
        if (paramBoolean) {
          Owner owner = j2().l0();
          if (owner != null)
            owner.u(j2()); 
        } 
      } else {
        throw new IllegalStateException("updateLayerParameters requires a non-null layerBlock");
      } 
    } else if (this.n != null) {
      throw new IllegalStateException("null layer with a non-null layerBlock");
    } 
  }
  
  public final void d2(dbxyzptlk.P0.d paramd, boolean paramBoolean) {
    int j = dbxyzptlk.z1.n.j(k1());
    float f1 = paramd.b();
    float f2 = j;
    paramd.i(f1 - f2);
    paramd.j(paramd.c() - f2);
    j = dbxyzptlk.z1.n.k(k1());
    f2 = paramd.d();
    f1 = j;
    paramd.k(f2 - f1);
    paramd.h(paramd.a() - f1);
    S s = this.A;
    if (s != null) {
      s.a(paramd, true);
      if (this.m && paramBoolean) {
        paramd.e(0.0F, 0.0F, r.h(a()), r.g(a()));
        paramd.f();
      } 
    } 
  }
  
  public dbxyzptlk.f1.b e2() {
    return j2().S().r();
  }
  
  public final boolean e3(long paramLong) {
    boolean bool1 = dbxyzptlk.P0.g.b(paramLong);
    boolean bool = false;
    if (!bool1)
      return false; 
    S s = this.A;
    if (s == null || !this.m || s.i(paramLong))
      bool = true; 
    return bool;
  }
  
  public i f1() {
    return this.j;
  }
  
  public r f2() {
    return this;
  }
  
  public boolean g1() {
    boolean bool;
    if (this.r != null) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public final boolean g2() {
    return this.z;
  }
  
  public float getDensity() {
    return j2().I().getDensity();
  }
  
  public t getLayoutDirection() {
    return j2().getLayoutDirection();
  }
  
  public H h1() {
    H h = this.r;
    if (h != null)
      return h; 
    throw new IllegalStateException("Asking for measurement result of unmeasured layout modifier");
  }
  
  public final long h2() {
    return N0();
  }
  
  public final S i2() {
    return this.A;
  }
  
  public f j2() {
    return this.i;
  }
  
  public boolean k0() {
    boolean bool;
    if (this.A != null && !this.l && j2().I0()) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public long k1() {
    return this.t;
  }
  
  public abstract j k2();
  
  public final long l2() {
    return this.o.A0(j2().q0().e());
  }
  
  public long m(long paramLong) {
    paramLong = u(paramLong);
    return D.b(j2()).t(paramLong);
  }
  
  public final dbxyzptlk.P0.d m2() {
    dbxyzptlk.P0.d d2 = this.v;
    dbxyzptlk.P0.d d1 = d2;
    if (d2 == null) {
      d1 = new dbxyzptlk.P0.d(0.0F, 0.0F, 0.0F, 0.0F);
      this.v = d1;
    } 
    return d1;
  }
  
  public abstract androidx.compose.ui.d.c o2();
  
  public final n p2() {
    return this.j;
  }
  
  public final n q2() {
    return this.k;
  }
  
  public final r r() {
    if (G()) {
      D2();
      return (j2().j0()).k;
    } 
    throw new IllegalStateException("LayoutCoordinate operations are only valid when isAttached is true");
  }
  
  public final float r2() {
    return this.u;
  }
  
  public final boolean s2(int paramInt) {
    androidx.compose.ui.d.c c = u2(L.i(paramInt));
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (c != null) {
      bool1 = bool2;
      if (h.e((dbxyzptlk.f1.g)c, paramInt) == true)
        bool1 = true; 
    } 
    return bool1;
  }
  
  public final androidx.compose.ui.d.c t2(int paramInt) {
    boolean bool = L.i(paramInt);
    androidx.compose.ui.d.c c1 = o2();
    if (!bool) {
      androidx.compose.ui.d.c c = c1.O1();
      c1 = c;
      if (c == null)
        return null; 
    } 
    androidx.compose.ui.d.c c2 = N1(this, bool);
    while (c2 != null && (c2.H1() & paramInt) != 0) {
      if ((c2.M1() & paramInt) != 0)
        return c2; 
      if (c2 != c1)
        c2 = c2.I1(); 
    } 
    return null;
  }
  
  public long u(long paramLong) {
    if (G()) {
      D2();
      for (n n1 = this; n1 != null; n1 = n1.k)
        paramLong = n1.W2(paramLong); 
      return paramLong;
    } 
    throw new IllegalStateException("LayoutCoordinate operations are only valid when isAttached is true");
  }
  
  public void u1() {
    T0(k1(), this.u, this.n);
  }
  
  public final androidx.compose.ui.d.c u2(boolean paramBoolean) {
    androidx.compose.ui.d.c c;
    if (j2().j0() == this) {
      c = j2().i0().k();
    } else {
      if (paramBoolean) {
        n n1 = this.k;
        if (n1 != null) {
          androidx.compose.ui.d.c c1 = n1.o2();
          if (c1 != null)
            return c1.I1(); 
        } 
      } else {
        n n1 = this.k;
        if (n1 != null)
          return n1.o2(); 
      } 
      c = null;
    } 
    return c;
  }
  
  public float v1() {
    return j2().I().v1();
  }
  
  public final void v2(androidx.compose.ui.d.c paramc, f paramf, long paramLong, q paramq, boolean paramBoolean1, boolean paramBoolean2) {
    if (paramc == null) {
      y2(paramf, paramLong, paramq, paramBoolean1, paramBoolean2);
    } else {
      paramq.z(paramc, paramBoolean2, (dbxyzptlk.CI.a)new h(this, paramc, paramf, paramLong, paramq, paramBoolean1, paramBoolean2));
    } 
  }
  
  public final void w2(androidx.compose.ui.d.c paramc, f paramf, long paramLong, q paramq, boolean paramBoolean1, boolean paramBoolean2, float paramFloat) {
    if (paramc == null) {
      y2(paramf, paramLong, paramq, paramBoolean1, paramBoolean2);
    } else {
      paramq.A(paramc, paramFloat, paramBoolean2, (dbxyzptlk.CI.a)new i(this, paramc, paramf, paramLong, paramq, paramBoolean1, paramBoolean2, paramFloat));
    } 
  }
  
  public final void x2(f paramf, long paramLong, q paramq, boolean paramBoolean1, boolean paramBoolean2) {
    androidx.compose.ui.d.c c = t2(paramf.a());
    if (!e3(paramLong)) {
      if (paramBoolean1) {
        float f1 = W1(paramLong, l2());
        if (!Float.isInfinite(f1) && !Float.isNaN(f1) && paramq.E(f1, false))
          w2(c, paramf, paramLong, paramq, paramBoolean1, false, f1); 
      } 
    } else if (c == null) {
      y2(paramf, paramLong, paramq, paramBoolean1, paramBoolean2);
    } else if (A2(paramLong)) {
      v2(c, paramf, paramLong, paramq, paramBoolean1, paramBoolean2);
    } else {
      float f1;
      if (!paramBoolean1) {
        f1 = Float.POSITIVE_INFINITY;
      } else {
        f1 = W1(paramLong, l2());
      } 
      if (!Float.isInfinite(f1) && !Float.isNaN(f1) && paramq.E(f1, paramBoolean2)) {
        w2(c, paramf, paramLong, paramq, paramBoolean1, paramBoolean2, f1);
      } else {
        U2(c, paramf, paramLong, paramq, paramBoolean1, paramBoolean2, f1);
      } 
    } 
  }
  
  public void y2(f paramf, long paramLong, q paramq, boolean paramBoolean1, boolean paramBoolean2) {
    n n1 = this.j;
    if (n1 != null)
      n1.x2(paramf, n1.c2(paramLong), paramq, paramBoolean1, paramBoolean2); 
  }
  
  public void z2() {
    S s = this.A;
    if (s != null) {
      s.invalidate();
    } else {
      n n1 = this.k;
      if (n1 != null)
        n1.z2(); 
    } 
  }
  
  @Metadata(d1 = {"\000A\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\020\013\n\002\b\002\n\002\030\002\n\002\b\004\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003*\001\000\b\n\030\0002\0020\001J\033\020\004\032\b\022\004\022\0020\0030\002H\026ø\001\000ø\001\001¢\006\004\b\004\020\005J\027\020\t\032\0020\b2\006\020\007\032\0020\006H\026¢\006\004\b\t\020\nJ\027\020\r\032\0020\b2\006\020\f\032\0020\013H\026¢\006\004\b\r\020\016J:\020\027\032\0020\0262\006\020\017\032\0020\0132\006\020\021\032\0020\0202\006\020\023\032\0020\0222\006\020\024\032\0020\b2\006\020\025\032\0020\bH\026ø\001\001¢\006\004\b\027\020\030\002\013\n\002\b!\n\005\b¡\0360\001¨\006\031"}, d2 = {"androidx/compose/ui/node/n$a", "Landroidx/compose/ui/node/n$f;", "Ldbxyzptlk/f1/K;", "Ldbxyzptlk/f1/X;", "a", "()I", "Landroidx/compose/ui/d$c;", "node", "", "b", "(Landroidx/compose/ui/d$c;)Z", "Landroidx/compose/ui/node/f;", "parentLayoutNode", "d", "(Landroidx/compose/ui/node/f;)Z", "layoutNode", "Ldbxyzptlk/P0/f;", "pointerPosition", "Ldbxyzptlk/f1/q;", "hitTestResult", "isTouchEvent", "isInLayer", "Ldbxyzptlk/pI/D;", "c", "(Landroidx/compose/ui/node/f;JLdbxyzptlk/f1/q;ZZ)V", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class a implements f {
    public int a() {
      return K.a(16);
    }
    
    public boolean b(androidx.compose.ui.d.c param1c) {
      int i = K.a(16);
      androidx.compose.ui.d.c c2 = null;
      androidx.compose.ui.d.c c1 = param1c;
      param1c = c2;
      while (c1 != null) {
        dbxyzptlk.z0.d d2;
        if (c1 instanceof X) {
          c2 = param1c;
          if (((X)c1).P())
            return true; 
        } else {
          c2 = param1c;
          if ((c1.M1() & i) != 0) {
            c2 = param1c;
            if (c1 instanceof i) {
              dbxyzptlk.z0.d d;
              c2 = ((i)c1).l2();
              int j = 0;
              while (c2 != null) {
                dbxyzptlk.z0.d d3;
                androidx.compose.ui.d.c c4 = param1c;
                int k = j;
                androidx.compose.ui.d.c c3 = c1;
                if ((c2.M1() & i) != 0) {
                  k = j + 1;
                  if (k == 1) {
                    c3 = c2;
                    c4 = param1c;
                  } else {
                    c4 = param1c;
                    if (param1c == null)
                      d3 = new dbxyzptlk.z0.d((Object[])new androidx.compose.ui.d.c[16], 0); 
                    c3 = c1;
                    if (c1 != null) {
                      d3.c(c1);
                      c3 = null;
                    } 
                    d3.c(c2);
                  } 
                } 
                c2 = c2.I1();
                d = d3;
                j = k;
                c1 = c3;
              } 
              d2 = d;
              if (j == 1)
                continue; 
            } 
          } 
        } 
        c1 = h.b(d2);
        dbxyzptlk.z0.d d1 = d2;
      } 
      return false;
    }
    
    public void c(f param1f, long param1Long, q param1q, boolean param1Boolean1, boolean param1Boolean2) {
      param1f.v0(param1Long, param1q, param1Boolean1, param1Boolean2);
    }
    
    public boolean d(f param1f) {
      return true;
    }
  }
  
  @Metadata(d1 = {"\000A\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\020\013\n\002\b\002\n\002\030\002\n\002\b\004\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003*\001\000\b\n\030\0002\0020\001J\033\020\004\032\b\022\004\022\0020\0030\002H\026ø\001\000ø\001\001¢\006\004\b\004\020\005J\027\020\t\032\0020\b2\006\020\007\032\0020\006H\026¢\006\004\b\t\020\nJ\027\020\r\032\0020\b2\006\020\f\032\0020\013H\026¢\006\004\b\r\020\016J:\020\027\032\0020\0262\006\020\017\032\0020\0132\006\020\021\032\0020\0202\006\020\023\032\0020\0222\006\020\024\032\0020\b2\006\020\025\032\0020\bH\026ø\001\001¢\006\004\b\027\020\030\002\013\n\002\b!\n\005\b¡\0360\001¨\006\031"}, d2 = {"androidx/compose/ui/node/n$b", "Landroidx/compose/ui/node/n$f;", "Ldbxyzptlk/f1/K;", "Ldbxyzptlk/f1/a0;", "a", "()I", "Landroidx/compose/ui/d$c;", "node", "", "b", "(Landroidx/compose/ui/d$c;)Z", "Landroidx/compose/ui/node/f;", "parentLayoutNode", "d", "(Landroidx/compose/ui/node/f;)Z", "layoutNode", "Ldbxyzptlk/P0/f;", "pointerPosition", "Ldbxyzptlk/f1/q;", "hitTestResult", "isTouchEvent", "isInLayer", "Ldbxyzptlk/pI/D;", "c", "(Landroidx/compose/ui/node/f;JLdbxyzptlk/f1/q;ZZ)V", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class b implements f {
    public int a() {
      return K.a(8);
    }
    
    public boolean b(androidx.compose.ui.d.c param1c) {
      return false;
    }
    
    public void c(f param1f, long param1Long, q param1q, boolean param1Boolean1, boolean param1Boolean2) {
      param1f.x0(param1Long, param1q, param1Boolean1, param1Boolean2);
    }
    
    public boolean d(f param1f) {
      dbxyzptlk.l1.l l = param1f.G();
      boolean bool2 = false;
      boolean bool1 = bool2;
      if (l != null) {
        bool1 = bool2;
        if (l.w() == true)
          bool1 = true; 
      } 
      return bool1 ^ true;
    }
  }
  
  @Metadata(d1 = {"\000\016\n\002\030\002\n\000\n\002\030\002\n\002\b\002\020\003\032\0020\0022\006\020\001\032\0020\000H\n¢\006\004\b\003\020\004"}, d2 = {"Landroidx/compose/ui/node/n;", "coordinator", "Ldbxyzptlk/pI/D;", "a", "(Landroidx/compose/ui/node/n;)V"}, k = 3, mv = {1, 8, 0})
  public static final class c extends u implements dbxyzptlk.CI.l<n, D> {
    public static final c f = new c();
    
    public c() {
      super(1);
    }
    
    public final void a(n param1n) {
      S s = param1n.i2();
      if (s != null)
        s.invalidate(); 
    }
  }
  
  @Metadata(d1 = {"\000\016\n\002\030\002\n\000\n\002\030\002\n\002\b\002\020\003\032\0020\0022\006\020\001\032\0020\000H\n¢\006\004\b\003\020\004"}, d2 = {"Landroidx/compose/ui/node/n;", "coordinator", "Ldbxyzptlk/pI/D;", "a", "(Landroidx/compose/ui/node/n;)V"}, k = 3, mv = {1, 8, 0})
  public static final class d extends u implements dbxyzptlk.CI.l<n, D> {
    public static final d f = new d();
    
    public d() {
      super(1);
    }
    
    public final void a(n param1n) {
      if (param1n.k0()) {
        u u1 = n.H1(param1n);
        if (u1 == null) {
          n.d3(param1n, false, 1, null);
        } else {
          n.M1().b(u1);
          n.d3(param1n, false, 1, null);
          if (!n.M1().c(u1)) {
            f f = param1n.j2();
            g g = f.S();
            if (g.s() > 0) {
              if (g.t() || g.u())
                f.k1(f, false, 1, null); 
              g.F().M1();
            } 
            Owner owner = f.l0();
            if (owner != null)
              owner.c(f); 
          } 
        } 
      } 
    }
  }
  
  @Metadata(d1 = {"\000D\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\b\006\n\002\020\016\n\002\b\003\n\002\030\002\n\002\b\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\003\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003R\027\020\005\032\0020\0048\006¢\006\f\n\004\b\005\020\006\032\004\b\007\020\bR\027\020\t\032\0020\0048\006¢\006\f\n\004\b\t\020\006\032\004\b\n\020\bR\024\020\f\032\0020\0138\006XT¢\006\006\n\004\b\f\020\rR\024\020\016\032\0020\0138\006XT¢\006\006\n\004\b\016\020\rR\024\020\020\032\0020\0178\002X\004¢\006\006\n\004\b\020\020\021R \020\025\032\016\022\004\022\0020\023\022\004\022\0020\0240\0228\002X\004¢\006\006\n\004\b\025\020\026R \020\027\032\016\022\004\022\0020\023\022\004\022\0020\0240\0228\002X\004¢\006\006\n\004\b\027\020\026R\024\020\031\032\0020\0308\002X\004¢\006\006\n\004\b\031\020\032R\032\020\034\032\0020\0338\002X\004ø\001\000ø\001\001¢\006\006\n\004\b\034\020\035\002\013\n\005\b¡\0360\001\n\002\b!¨\006\036"}, d2 = {"Landroidx/compose/ui/node/n$e;", "", "<init>", "()V", "Landroidx/compose/ui/node/n$f;", "PointerInputSource", "Landroidx/compose/ui/node/n$f;", "a", "()Landroidx/compose/ui/node/n$f;", "SemanticsSource", "b", "", "ExpectAttachedLayoutCoordinates", "Ljava/lang/String;", "UnmeasuredError", "Landroidx/compose/ui/graphics/d;", "graphicsLayerScope", "Landroidx/compose/ui/graphics/d;", "Lkotlin/Function1;", "Landroidx/compose/ui/node/n;", "Ldbxyzptlk/pI/D;", "onCommitAffectingLayer", "Ldbxyzptlk/CI/l;", "onCommitAffectingLayerParams", "Ldbxyzptlk/f1/u;", "tmpLayerPositionalProperties", "Ldbxyzptlk/f1/u;", "Ldbxyzptlk/Q0/H0;", "tmpMatrix", "[F", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class e {
    public e() {}
    
    public final n.f a() {
      return n.J1();
    }
    
    public final n.f b() {
      return n.K1();
    }
  }
  
  @Metadata(d1 = {"\000<\n\002\030\002\n\002\020\000\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\020\013\n\002\b\002\n\002\030\002\n\002\b\004\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\b`\030\0002\0020\001J\031\020\003\032\006\022\002\b\0030\002H&ø\001\000ø\001\001¢\006\004\b\003\020\004J\027\020\b\032\0020\0072\006\020\006\032\0020\005H&¢\006\004\b\b\020\tJ\027\020\f\032\0020\0072\006\020\013\032\0020\nH&¢\006\004\b\f\020\rJ:\020\026\032\0020\0252\006\020\016\032\0020\n2\006\020\020\032\0020\0172\006\020\022\032\0020\0212\006\020\023\032\0020\0072\006\020\024\032\0020\007H&ø\001\001¢\006\004\b\026\020\027ø\001\002\002\021\n\002\b!\n\005\b¡\0360\001\n\004\b!0\001¨\006\030À\006\001"}, d2 = {"Landroidx/compose/ui/node/n$f;", "", "Ldbxyzptlk/f1/K;", "a", "()I", "Landroidx/compose/ui/d$c;", "node", "", "b", "(Landroidx/compose/ui/d$c;)Z", "Landroidx/compose/ui/node/f;", "parentLayoutNode", "d", "(Landroidx/compose/ui/node/f;)Z", "layoutNode", "Ldbxyzptlk/P0/f;", "pointerPosition", "Ldbxyzptlk/f1/q;", "hitTestResult", "isTouchEvent", "isInLayer", "Ldbxyzptlk/pI/D;", "c", "(Landroidx/compose/ui/node/f;JLdbxyzptlk/f1/q;ZZ)V", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static interface f {
    int a();
    
    boolean b(androidx.compose.ui.d.c param1c);
    
    void c(f param1f, long param1Long, q param1q, boolean param1Boolean1, boolean param1Boolean2);
    
    boolean d(f param1f);
  }
  
  @Metadata(d1 = {"\000\016\n\002\030\002\n\000\n\002\030\002\n\002\b\002\020\003\032\0020\0022\006\020\001\032\0020\000H\n¢\006\004\b\003\020\004"}, d2 = {"Ldbxyzptlk/Q0/j0;", "canvas", "Ldbxyzptlk/pI/D;", "a", "(Ldbxyzptlk/Q0/j0;)V"}, k = 3, mv = {1, 8, 0})
  public static final class g extends u implements dbxyzptlk.CI.l<j0, D> {
    public final n f;
    
    public g(n param1n) {
      super(1);
    }
    
    public final void a(j0 param1j0) {
      if (this.f.j2().h()) {
        n.L1(this.f).i(this.f, n.I1(), new a(this.f, param1j0));
        n.Q1(this.f, false);
      } else {
        n.Q1(this.f, true);
      } 
    }
    
    @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"Ldbxyzptlk/pI/D;", "b", "()V"}, k = 3, mv = {1, 8, 0})
    public static final class a extends u implements dbxyzptlk.CI.a<D> {
      public final n f;
      
      public final j0 g;
      
      public a(n param2n, j0 param2j0) {
        super(0);
      }
      
      public final void b() {
        n.C1(this.f, this.g);
      }
    }
  }
  
  @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"Ldbxyzptlk/pI/D;", "b", "()V"}, k = 3, mv = {1, 8, 0})
  public static final class a extends u implements dbxyzptlk.CI.a<D> {
    public final n f;
    
    public final j0 g;
    
    public a(n param1n, j0 param1j0) {
      super(0);
    }
    
    public final void b() {
      n.C1(this.f, this.g);
    }
  }
  
  @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"Ldbxyzptlk/pI/D;", "b", "()V"}, k = 3, mv = {1, 8, 0})
  public static final class j extends u implements dbxyzptlk.CI.a<D> {
    public final n f;
    
    public j(n param1n) {
      super(0);
    }
    
    public final void b() {
      n n1 = this.f.q2();
      if (n1 != null)
        n1.z2(); 
    }
  }
  
  @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"Ldbxyzptlk/pI/D;", "b", "()V"}, k = 3, mv = {1, 8, 0})
  public static final class l extends u implements dbxyzptlk.CI.a<D> {
    public final dbxyzptlk.CI.l<androidx.compose.ui.graphics.c, D> f;
    
    public l(dbxyzptlk.CI.l<? super androidx.compose.ui.graphics.c, D> param1l) {
      super(0);
    }
    
    public final void b() {
      this.f.invoke(n.G1());
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compos\\ui\node\n.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */