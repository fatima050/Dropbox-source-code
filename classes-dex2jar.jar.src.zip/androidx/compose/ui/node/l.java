package androidx.compose.ui.node;

import androidx.compose.ui.d;
import dbxyzptlk.DI.s;
import dbxyzptlk.d1.L;
import dbxyzptlk.f1.G;
import dbxyzptlk.f1.I;
import dbxyzptlk.f1.K;
import dbxyzptlk.f1.L;
import dbxyzptlk.f1.S;
import dbxyzptlk.f1.d0;
import dbxyzptlk.f1.h;
import dbxyzptlk.f1.w;
import dbxyzptlk.qI.s;
import dbxyzptlk.z0.d;
import java.util.List;
import kotlin.Metadata;

@Metadata(d1 = {"\000t\n\002\030\002\n\002\020\000\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\003\n\002\020\b\n\000\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\013\n\000\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\023\n\002\030\002\n\002\b\007\n\002\020 \n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\005\n\002\020\016\n\002\b\005\n\002\030\002\n\002\b\032\b\000\030\0002\0020\001:\002GKB\017\022\006\020\003\032\0020\002¢\006\004\b\004\020\005J\017\020\007\032\0020\006H\002¢\006\004\b\007\020\bJ\027\020\n\032\0020\0062\006\020\t\032\0020\006H\002¢\006\004\b\n\020\013J\017\020\r\032\0020\fH\002¢\006\004\b\r\020\016JG\020\031\032\0060\030R\0020\0002\006\020\017\032\0020\0062\006\020\021\032\0020\0202\f\020\024\032\b\022\004\022\0020\0230\0222\f\020\025\032\b\022\004\022\0020\0230\0222\006\020\027\032\0020\026H\002¢\006\004\b\031\020\032J\037\020\036\032\0020\f2\006\020\033\032\0020\0062\006\020\035\032\0020\034H\002¢\006\004\b\036\020\037JC\020!\032\0020\f2\006\020\021\032\0020\0202\f\020\024\032\b\022\004\022\0020\0230\0222\f\020\025\032\b\022\004\022\0020\0230\0222\006\020 \032\0020\0062\006\020\027\032\0020\026H\002¢\006\004\b!\020\"J\027\020$\032\0020\0062\006\020#\032\0020\006H\002¢\006\004\b$\020\013J\027\020%\032\0020\0062\006\020#\032\0020\006H\002¢\006\004\b%\020\013J\037\020(\032\0020\0062\006\020&\032\0020\0232\006\020'\032\0020\006H\002¢\006\004\b(\020)J\037\020*\032\0020\0062\006\020#\032\0020\0062\006\020'\032\0020\006H\002¢\006\004\b*\020+J'\020.\032\0020\f2\006\020,\032\0020\0232\006\020-\032\0020\0232\006\020#\032\0020\006H\002¢\006\004\b.\020/J\027\0202\032\0020\f2\006\0201\032\00200H\000¢\006\004\b2\0203J\017\0204\032\0020\fH\000¢\006\004\b4\020\016J\r\0205\032\0020\f¢\006\004\b5\020\016J\r\0206\032\0020\f¢\006\004\b6\020\016J\r\0207\032\0020\f¢\006\004\b7\020\016J\023\020:\032\b\022\004\022\0020908¢\006\004\b:\020;J\017\020<\032\0020\fH\000¢\006\004\b<\020\016J\017\020=\032\0020\fH\000¢\006\004\b=\020\016J\036\020@\032\0020\0262\n\020?\032\006\022\002\b\0030>H\000ø\001\000¢\006\004\b@\020AJ\027\020C\032\0020\0262\006\020B\032\0020\020H\000¢\006\004\bC\020AJ\017\020E\032\0020DH\026¢\006\004\bE\020FR\027\020\003\032\0020\0028\006¢\006\f\n\004\bG\020H\032\004\b1\020IR\032\020O\032\0020J8\000X\004¢\006\f\n\004\bK\020L\032\004\bM\020NR$\020U\032\0020\0342\006\020P\032\0020\0348\000@BX\016¢\006\f\n\004\bQ\020R\032\004\bS\020TR\032\020 \032\0020\0068\000X\004¢\006\f\n\004\bV\020W\032\004\bX\020\bR$\020\017\032\0020\0062\006\020P\032\0020\0068\000@BX\016¢\006\f\n\004\bY\020W\032\004\bZ\020\bR\036\020]\032\n\022\004\022\0020\023\030\0010\0228\002@\002X\016¢\006\006\n\004\b[\020\\R\036\020^\032\n\022\004\022\0020\023\030\0010\0228\002@\002X\016¢\006\006\n\004\b(\020\\R\034\020`\032\b\030\0010\030R\0020\0008\002@\002X\016¢\006\006\n\004\b$\020_R\024\020c\032\0020\0208BX\004¢\006\006\032\004\ba\020b\002\007\n\005\b¡\0360\001¨\006d"}, d2 = {"Landroidx/compose/ui/node/l;", "", "Landroidx/compose/ui/node/f;", "layoutNode", "<init>", "(Landroidx/compose/ui/node/f;)V", "Landroidx/compose/ui/d$c;", "v", "()Landroidx/compose/ui/d$c;", "paddedHead", "E", "(Landroidx/compose/ui/d$c;)Landroidx/compose/ui/d$c;", "Ldbxyzptlk/pI/D;", "C", "()V", "head", "", "offset", "Ldbxyzptlk/z0/d;", "Landroidx/compose/ui/d$b;", "before", "after", "", "shouldAttachOnInsert", "Landroidx/compose/ui/node/l$a;", "j", "(Landroidx/compose/ui/d$c;ILdbxyzptlk/z0/d;Ldbxyzptlk/z0/d;Z)Landroidx/compose/ui/node/l$a;", "start", "Landroidx/compose/ui/node/n;", "coordinator", "w", "(Landroidx/compose/ui/d$c;Landroidx/compose/ui/node/n;)V", "tail", "B", "(ILdbxyzptlk/z0/d;Ldbxyzptlk/z0/d;Landroidx/compose/ui/d$c;Z)V", "node", "h", "x", "element", "parent", "g", "(Landroidx/compose/ui/d$b;Landroidx/compose/ui/d$c;)Landroidx/compose/ui/d$c;", "s", "(Landroidx/compose/ui/d$c;Landroidx/compose/ui/d$c;)Landroidx/compose/ui/d$c;", "prev", "next", "G", "(Landroidx/compose/ui/d$b;Landroidx/compose/ui/d$b;Landroidx/compose/ui/d$c;)V", "Landroidx/compose/ui/d;", "m", "F", "(Landroidx/compose/ui/d;)V", "y", "D", "t", "z", "", "Ldbxyzptlk/d1/L;", "n", "()Ljava/util/List;", "u", "A", "Ldbxyzptlk/f1/K;", "type", "r", "(I)Z", "mask", "q", "", "toString", "()Ljava/lang/String;", "a", "Landroidx/compose/ui/node/f;", "()Landroidx/compose/ui/node/f;", "Landroidx/compose/ui/node/d;", "b", "Landroidx/compose/ui/node/d;", "l", "()Landroidx/compose/ui/node/d;", "innerCoordinator", "<set-?>", "c", "Landroidx/compose/ui/node/n;", "o", "()Landroidx/compose/ui/node/n;", "outerCoordinator", "d", "Landroidx/compose/ui/d$c;", "p", "e", "k", "f", "Ldbxyzptlk/z0/d;", "current", "buffer", "Landroidx/compose/ui/node/l$a;", "cachedDiffer", "i", "()I", "aggregateChildKindSet", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class l {
  public final f a;
  
  public final d b;
  
  public n c;
  
  public final d.c d;
  
  public d.c e;
  
  public d<d.b> f;
  
  public d<d.b> g;
  
  public a h;
  
  public l(f paramf) {
    this.a = paramf;
    d d1 = new d(paramf);
    this.b = d1;
    this.c = d1;
    d0 d0 = d1.f3();
    this.d = (d.c)d0;
    this.e = (d.c)d0;
  }
  
  public final void A() {
    for (d.c c1 = p(); c1 != null; c1 = c1.O1()) {
      if (c1.R1())
        c1.Z1(); 
    } 
  }
  
  public final void B(int paramInt, d<d.b> paramd1, d<d.b> paramd2, d.c paramc, boolean paramBoolean) {
    a a1 = j(paramc, paramInt, paramd1, paramd2, paramBoolean);
    I.e(paramd1.p() - paramInt, paramd2.p() - paramInt, (dbxyzptlk.f1.l)a1);
    C();
  }
  
  public final void C() {
    d.c c1 = this.d.O1();
    int i = 0;
    while (c1 != null && c1 != m.b()) {
      i |= c1.M1();
      c1.a2(i);
      c1 = c1.O1();
    } 
  }
  
  public final void D() {
    n n1 = this.b;
    for (d.c c1 = this.d.O1(); c1 != null; c1 = c1.O1()) {
      w w = h.d(c1);
      if (w != null) {
        n n2;
        if (c1.J1() != null) {
          n n3 = c1.J1();
          s.f(n3, "null cannot be cast to non-null type androidx.compose.ui.node.LayoutModifierNodeCoordinator");
          n3 = n3;
          w w1 = n3.h3();
          n3.j3(w);
          n2 = n3;
          if (w1 != c1) {
            n3.E2();
            n2 = n3;
          } 
        } else {
          n2 = new e(this.a, (w)n2);
          c1.j2(n2);
        } 
        n1.S2(n2);
        n2.R2(n1);
        n1 = n2;
      } else {
        c1.j2(n1);
      } 
    } 
    f f1 = this.a.m0();
    if (f1 != null) {
      n n2 = f1.N();
    } else {
      f1 = null;
    } 
    n1.S2((n)f1);
    this.c = n1;
  }
  
  public final d.c E(d.c paramc) {
    if (paramc == m.b()) {
      d.c c1 = m.b().I1();
      paramc = c1;
      if (c1 == null)
        paramc = this.d; 
      paramc.g2(null);
      m.b().c2(null);
      m.b().a2(-1);
      m.b().j2(null);
      if (paramc != m.b())
        return paramc; 
      throw new IllegalStateException("trimChain did not update the head");
    } 
    throw new IllegalStateException("trimChain called on already trimmed chain");
  }
  
  public final void F(d paramd) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual v : ()Landroidx/compose/ui/d$c;
    //   4: astore #8
    //   6: aload_0
    //   7: getfield f : Ldbxyzptlk/z0/d;
    //   10: astore #6
    //   12: iconst_0
    //   13: istore #4
    //   15: iconst_0
    //   16: istore_3
    //   17: aload #6
    //   19: ifnull -> 31
    //   22: aload #6
    //   24: invokevirtual p : ()I
    //   27: istore_2
    //   28: goto -> 33
    //   31: iconst_0
    //   32: istore_2
    //   33: aload_0
    //   34: getfield g : Ldbxyzptlk/z0/d;
    //   37: astore #9
    //   39: aload #9
    //   41: astore #7
    //   43: aload #9
    //   45: ifnonnull -> 63
    //   48: new dbxyzptlk/z0/d
    //   51: dup
    //   52: bipush #16
    //   54: anewarray androidx/compose/ui/d$b
    //   57: iconst_0
    //   58: invokespecial <init> : ([Ljava/lang/Object;I)V
    //   61: astore #7
    //   63: aload_1
    //   64: aload #7
    //   66: invokestatic a : (Landroidx/compose/ui/d;Ldbxyzptlk/z0/d;)Ldbxyzptlk/z0/d;
    //   69: astore #10
    //   71: aload #10
    //   73: invokevirtual p : ()I
    //   76: istore #5
    //   78: aconst_null
    //   79: astore #9
    //   81: iload #5
    //   83: iload_2
    //   84: if_icmpne -> 269
    //   87: aload #8
    //   89: invokevirtual I1 : ()Landroidx/compose/ui/d$c;
    //   92: astore_1
    //   93: iconst_0
    //   94: istore_3
    //   95: aload_1
    //   96: astore #7
    //   98: aload_1
    //   99: ifnull -> 188
    //   102: aload_1
    //   103: astore #7
    //   105: iload_3
    //   106: iload_2
    //   107: if_icmpge -> 188
    //   110: aload #6
    //   112: ifnull -> 191
    //   115: aload #6
    //   117: invokevirtual o : ()[Ljava/lang/Object;
    //   120: iload_3
    //   121: aaload
    //   122: checkcast androidx/compose/ui/d$b
    //   125: astore #7
    //   127: aload #10
    //   129: invokevirtual o : ()[Ljava/lang/Object;
    //   132: iload_3
    //   133: aaload
    //   134: checkcast androidx/compose/ui/d$b
    //   137: astore #11
    //   139: aload #7
    //   141: aload #11
    //   143: invokestatic d : (Landroidx/compose/ui/d$b;Landroidx/compose/ui/d$b;)I
    //   146: istore #5
    //   148: iload #5
    //   150: ifeq -> 182
    //   153: iload #5
    //   155: iconst_1
    //   156: if_icmpeq -> 162
    //   159: goto -> 171
    //   162: aload_0
    //   163: aload #7
    //   165: aload #11
    //   167: aload_1
    //   168: invokevirtual G : (Landroidx/compose/ui/d$b;Landroidx/compose/ui/d$b;Landroidx/compose/ui/d$c;)V
    //   171: aload_1
    //   172: invokevirtual I1 : ()Landroidx/compose/ui/d$c;
    //   175: astore_1
    //   176: iinc #3, 1
    //   179: goto -> 95
    //   182: aload_1
    //   183: invokevirtual O1 : ()Landroidx/compose/ui/d$c;
    //   186: astore #7
    //   188: goto -> 202
    //   191: new java/lang/IllegalStateException
    //   194: dup
    //   195: ldc_w 'expected prior modifier list to be non-empty'
    //   198: invokespecial <init> : (Ljava/lang/String;)V
    //   201: athrow
    //   202: aload #6
    //   204: astore_1
    //   205: iload_3
    //   206: iload_2
    //   207: if_icmpge -> 479
    //   210: aload #6
    //   212: ifnull -> 258
    //   215: aload #7
    //   217: ifnull -> 247
    //   220: aload_0
    //   221: iload_3
    //   222: aload #6
    //   224: aload #10
    //   226: aload #7
    //   228: aload_0
    //   229: getfield a : Landroidx/compose/ui/node/f;
    //   232: invokevirtual I0 : ()Z
    //   235: invokevirtual B : (ILdbxyzptlk/z0/d;Ldbxyzptlk/z0/d;Landroidx/compose/ui/d$c;Z)V
    //   238: aload #6
    //   240: astore_1
    //   241: iconst_1
    //   242: istore #4
    //   244: goto -> 479
    //   247: new java/lang/IllegalStateException
    //   250: dup
    //   251: ldc_w 'structuralUpdate requires a non-null tail'
    //   254: invokespecial <init> : (Ljava/lang/String;)V
    //   257: athrow
    //   258: new java/lang/IllegalStateException
    //   261: dup
    //   262: ldc_w 'expected prior modifier list to be non-empty'
    //   265: invokespecial <init> : (Ljava/lang/String;)V
    //   268: athrow
    //   269: aload_0
    //   270: getfield a : Landroidx/compose/ui/node/f;
    //   273: invokevirtual I0 : ()Z
    //   276: ifne -> 329
    //   279: iload_2
    //   280: ifne -> 329
    //   283: aload #8
    //   285: astore_1
    //   286: iload_3
    //   287: istore_2
    //   288: iload_2
    //   289: aload #10
    //   291: invokevirtual p : ()I
    //   294: if_icmpge -> 319
    //   297: aload_0
    //   298: aload #10
    //   300: invokevirtual o : ()[Ljava/lang/Object;
    //   303: iload_2
    //   304: aaload
    //   305: checkcast androidx/compose/ui/d$b
    //   308: aload_1
    //   309: invokevirtual g : (Landroidx/compose/ui/d$b;Landroidx/compose/ui/d$c;)Landroidx/compose/ui/d$c;
    //   312: astore_1
    //   313: iinc #2, 1
    //   316: goto -> 288
    //   319: aload_0
    //   320: invokevirtual C : ()V
    //   323: aload #6
    //   325: astore_1
    //   326: goto -> 241
    //   329: aload #10
    //   331: invokevirtual p : ()I
    //   334: ifne -> 437
    //   337: aload #6
    //   339: ifnull -> 426
    //   342: aload #8
    //   344: invokevirtual I1 : ()Landroidx/compose/ui/d$c;
    //   347: astore_1
    //   348: iconst_0
    //   349: istore_2
    //   350: aload_1
    //   351: ifnull -> 378
    //   354: iload_2
    //   355: aload #6
    //   357: invokevirtual p : ()I
    //   360: if_icmpge -> 378
    //   363: aload_0
    //   364: aload_1
    //   365: invokevirtual h : (Landroidx/compose/ui/d$c;)Landroidx/compose/ui/d$c;
    //   368: invokevirtual I1 : ()Landroidx/compose/ui/d$c;
    //   371: astore_1
    //   372: iinc #2, 1
    //   375: goto -> 350
    //   378: aload_0
    //   379: getfield b : Landroidx/compose/ui/node/d;
    //   382: astore #7
    //   384: aload_0
    //   385: getfield a : Landroidx/compose/ui/node/f;
    //   388: invokevirtual m0 : ()Landroidx/compose/ui/node/f;
    //   391: astore_1
    //   392: aload_1
    //   393: ifnull -> 404
    //   396: aload_1
    //   397: invokevirtual N : ()Landroidx/compose/ui/node/n;
    //   400: astore_1
    //   401: goto -> 406
    //   404: aconst_null
    //   405: astore_1
    //   406: aload #7
    //   408: aload_1
    //   409: invokevirtual S2 : (Landroidx/compose/ui/node/n;)V
    //   412: aload_0
    //   413: aload_0
    //   414: getfield b : Landroidx/compose/ui/node/d;
    //   417: putfield c : Landroidx/compose/ui/node/n;
    //   420: aload #6
    //   422: astore_1
    //   423: goto -> 479
    //   426: new java/lang/IllegalStateException
    //   429: dup
    //   430: ldc_w 'expected prior modifier list to be non-empty'
    //   433: invokespecial <init> : (Ljava/lang/String;)V
    //   436: athrow
    //   437: aload #6
    //   439: astore_1
    //   440: aload #6
    //   442: ifnonnull -> 459
    //   445: new dbxyzptlk/z0/d
    //   448: dup
    //   449: bipush #16
    //   451: anewarray androidx/compose/ui/d$b
    //   454: iconst_0
    //   455: invokespecial <init> : ([Ljava/lang/Object;I)V
    //   458: astore_1
    //   459: aload_0
    //   460: iconst_0
    //   461: aload_1
    //   462: aload #10
    //   464: aload #8
    //   466: aload_0
    //   467: getfield a : Landroidx/compose/ui/node/f;
    //   470: invokevirtual I0 : ()Z
    //   473: invokevirtual B : (ILdbxyzptlk/z0/d;Ldbxyzptlk/z0/d;Landroidx/compose/ui/d$c;Z)V
    //   476: goto -> 241
    //   479: aload_0
    //   480: aload #10
    //   482: putfield f : Ldbxyzptlk/z0/d;
    //   485: aload #9
    //   487: astore #6
    //   489: aload_1
    //   490: ifnull -> 500
    //   493: aload_1
    //   494: invokevirtual i : ()V
    //   497: aload_1
    //   498: astore #6
    //   500: aload_0
    //   501: aload #6
    //   503: putfield g : Ldbxyzptlk/z0/d;
    //   506: aload_0
    //   507: aload_0
    //   508: aload #8
    //   510: invokevirtual E : (Landroidx/compose/ui/d$c;)Landroidx/compose/ui/d$c;
    //   513: putfield e : Landroidx/compose/ui/d$c;
    //   516: iload #4
    //   518: ifeq -> 525
    //   521: aload_0
    //   522: invokevirtual D : ()V
    //   525: return
  }
  
  public final void G(d.b paramb1, d.b paramb2, d.c paramc) {
    if (paramb1 instanceof G && paramb2 instanceof G) {
      m.c((G)paramb2, paramc);
      if (paramc.R1()) {
        L.e(paramc);
      } else {
        paramc.h2(true);
      } 
    } else {
      if (paramc instanceof a) {
        ((a)paramc).p2(paramb2);
        if (paramc.R1()) {
          L.e(paramc);
        } else {
          paramc.h2(true);
        } 
        return;
      } 
      throw new IllegalStateException("Unknown Modifier.Node type");
    } 
  }
  
  public final d.c g(d.b paramb, d.c paramc) {
    d.c c1;
    if (paramb instanceof G) {
      c1 = ((G)paramb).b();
      c1.e2(L.h(c1));
    } else {
      c1 = new a((d.b)c1);
    } 
    if (!c1.R1()) {
      c1.d2(true);
      return s(c1, paramc);
    } 
    throw new IllegalStateException("A ModifierNodeElement cannot return an already attached node from create() ");
  }
  
  public final d.c h(d.c paramc) {
    if (paramc.R1()) {
      L.d(paramc);
      paramc.Z1();
      paramc.T1();
    } 
    return x(paramc);
  }
  
  public final int i() {
    return this.e.H1();
  }
  
  public final a j(d.c paramc, int paramInt, d<d.b> paramd1, d<d.b> paramd2, boolean paramBoolean) {
    a a1;
    a a2 = this.h;
    if (a2 == null) {
      a1 = new a(this, paramc, paramInt, paramd1, paramd2, paramBoolean);
      this.h = a1;
    } else {
      a2.g((d.c)a1);
      a2.h(paramInt);
      a2.f(paramd1);
      a2.e(paramd2);
      a2.i(paramBoolean);
      a1 = a2;
    } 
    return a1;
  }
  
  public final d.c k() {
    return this.e;
  }
  
  public final d l() {
    return this.b;
  }
  
  public final f m() {
    return this.a;
  }
  
  public final List<L> n() {
    d<d.b> d1 = this.f;
    if (d1 == null)
      return s.m(); 
    L[] arrayOfL = new L[d1.p()];
    byte b = 0;
    d d2 = new d((Object[])arrayOfL, 0);
    d.c c1 = k();
    while (c1 != null && c1 != p()) {
      n n1 = c1.J1();
      if (n1 != null) {
        S s3 = n1.i2();
        S s1 = this.b.i2();
        d.c c2 = c1.I1();
        if (c2 != this.d || c1.J1() == c2.J1())
          s1 = null; 
        S s2 = s3;
        if (s3 == null)
          s2 = s1; 
        d2.c(new L((d)d1.o()[b], n1, s2));
        c1 = c1.I1();
        b++;
        continue;
      } 
      throw new IllegalArgumentException("getModifierInfo called on node with no coordinator");
    } 
    return d2.h();
  }
  
  public final n o() {
    return this.c;
  }
  
  public final d.c p() {
    return this.d;
  }
  
  public final boolean q(int paramInt) {
    boolean bool;
    if ((paramInt & i()) != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public final boolean r(int paramInt) {
    boolean bool;
    if ((paramInt & i()) != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public final d.c s(d.c paramc1, d.c paramc2) {
    d.c c1 = paramc2.I1();
    if (c1 != null) {
      c1.g2(paramc1);
      paramc1.c2(c1);
    } 
    paramc2.c2(paramc1);
    paramc1.g2(paramc2);
    return paramc1;
  }
  
  public final void t() {
    for (d.c c1 = k(); c1 != null; c1 = c1.I1())
      c1.S1(); 
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("[");
    if (this.e == this.d) {
      stringBuilder.append("]");
    } else {
      for (d.c c1 = k(); c1 != null && c1 != p(); c1 = c1.I1()) {
        stringBuilder.append(String.valueOf(c1));
        if (c1.I1() == this.d) {
          stringBuilder.append("]");
          break;
        } 
        stringBuilder.append(",");
      } 
    } 
    String str = stringBuilder.toString();
    s.g(str, "StringBuilder().apply(builderAction).toString()");
    return str;
  }
  
  public final void u() {
    for (d.c c1 = p(); c1 != null; c1 = c1.O1()) {
      if (c1.R1())
        c1.T1(); 
    } 
  }
  
  public final d.c v() {
    if (this.e != m.b()) {
      d.c c1 = this.e;
      c1.g2(m.b());
      m.b().c2(c1);
      return m.b();
    } 
    throw new IllegalStateException("padChain called on already padded chain");
  }
  
  public final void w(d.c paramc, n paramn) {
    paramc = paramc.O1();
    while (paramc != null) {
      f f1;
      if (paramc == m.b()) {
        f1 = this.a.m0();
        if (f1 != null) {
          n n1 = f1.N();
        } else {
          f1 = null;
        } 
        paramn.S2((n)f1);
        this.c = paramn;
        break;
      } 
      if ((K.a(2) & f1.M1()) != 0)
        break; 
      f1.j2(paramn);
      d.c c1 = f1.O1();
    } 
  }
  
  public final d.c x(d.c paramc) {
    d.c c2 = paramc.I1();
    d.c c1 = paramc.O1();
    if (c2 != null) {
      c2.g2(c1);
      paramc.c2(null);
    } 
    if (c1 != null) {
      c1.c2(c2);
      paramc.g2(null);
    } 
    s.e(c1);
    return c1;
  }
  
  public final void y() {
    for (d.c c1 = p(); c1 != null; c1 = c1.O1()) {
      if (c1.R1())
        c1.X1(); 
    } 
    d<d.b> d1 = this.f;
    if (d1 != null) {
      int i = d1.p();
      if (i > 0) {
        int k;
        Object[] arrayOfObject = d1.o();
        int j = 0;
        do {
          d.b b = (d.b)arrayOfObject[j];
          if (b instanceof androidx.compose.ui.input.pointer.SuspendPointerInputElement)
            d1.G(j, new ForceUpdateElement((G)b)); 
          k = j + 1;
          j = k;
        } while (k < i);
      } 
    } 
    A();
    u();
  }
  
  public final void z() {
    for (d.c c1 = k(); c1 != null; c1 = c1.I1()) {
      c1.Y1();
      if (c1.L1())
        L.a(c1); 
      if (c1.Q1())
        L.e(c1); 
      c1.d2(false);
      c1.h2(false);
    } 
  }
  
  class l {}
  
  class l {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compos\\ui\node\l.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */