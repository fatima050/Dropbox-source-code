package androidx.compose.ui.node;

import androidx.compose.ui.d;
import androidx.compose.ui.focus.e;
import dbxyzptlk.DI.s;
import dbxyzptlk.DI.u;
import dbxyzptlk.N0.b;
import dbxyzptlk.N0.i;
import dbxyzptlk.O0.c;
import dbxyzptlk.O0.d;
import dbxyzptlk.O0.h;
import dbxyzptlk.O0.i;
import dbxyzptlk.O0.k;
import dbxyzptlk.O0.m;
import dbxyzptlk.O0.n;
import dbxyzptlk.O0.p;
import dbxyzptlk.S0.c;
import dbxyzptlk.a1.H;
import dbxyzptlk.a1.p;
import dbxyzptlk.a1.r;
import dbxyzptlk.d1.F;
import dbxyzptlk.d1.H;
import dbxyzptlk.d1.I;
import dbxyzptlk.d1.N;
import dbxyzptlk.d1.P;
import dbxyzptlk.d1.Q;
import dbxyzptlk.d1.V;
import dbxyzptlk.d1.b0;
import dbxyzptlk.d1.m;
import dbxyzptlk.d1.n;
import dbxyzptlk.d1.r;
import dbxyzptlk.d1.x;
import dbxyzptlk.e1.c;
import dbxyzptlk.e1.g;
import dbxyzptlk.e1.h;
import dbxyzptlk.e1.i;
import dbxyzptlk.e1.j;
import dbxyzptlk.e1.k;
import dbxyzptlk.f1.K;
import dbxyzptlk.f1.L;
import dbxyzptlk.f1.T;
import dbxyzptlk.f1.V;
import dbxyzptlk.f1.X;
import dbxyzptlk.f1.a0;
import dbxyzptlk.f1.g;
import dbxyzptlk.f1.h;
import dbxyzptlk.f1.i;
import dbxyzptlk.f1.n;
import dbxyzptlk.f1.o;
import dbxyzptlk.f1.p;
import dbxyzptlk.f1.v;
import dbxyzptlk.f1.w;
import dbxyzptlk.f1.y;
import dbxyzptlk.l1.l;
import dbxyzptlk.l1.n;
import dbxyzptlk.l1.x;
import dbxyzptlk.pI.D;
import dbxyzptlk.z1.s;
import dbxyzptlk.z1.t;
import java.util.HashSet;
import kotlin.Metadata;

@Metadata(d1 = {"\000\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\002\n\002\020\013\n\002\b\004\n\002\030\002\n\002\b\007\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\030\002\n\002\020\b\n\002\b\007\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\007\n\002\030\002\n\002\020\000\n\002\b\003\n\002\030\002\n\002\b\007\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\020\016\n\002\b\013\n\002\030\002\n\002\b\003\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\f\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\n\b\000\030\0002\0020\0012\0020\0022\0020\0032\0020\0042\0020\0052\0020\0062\0020\0072\0020\b2\0020\t2\0020\n2\0020\0132\0020\f2\0020\r2\0020\0162\0020\017B\017\022\006\020\021\032\0020\020¢\006\004\b\022\020\023J\017\020\025\032\0020\024H\002¢\006\004\b\025\020\026J\027\020\031\032\0020\0242\006\020\030\032\0020\027H\002¢\006\004\b\031\020\032J\017\020\033\032\0020\024H\002¢\006\004\b\033\020\026J\033\020\035\032\0020\0242\n\020\021\032\006\022\002\b\0030\034H\002¢\006\004\b\035\020\036J\017\020\037\032\0020\024H\026¢\006\004\b\037\020\026J\017\020 \032\0020\024H\026¢\006\004\b \020\026J\017\020!\032\0020\024H\026¢\006\004\b!\020\026J\017\020\"\032\0020\024H\000¢\006\004\b\"\020\026J\r\020#\032\0020\024¢\006\004\b#\020\026J&\020*\032\0020)*\0020$2\006\020&\032\0020%2\006\020(\032\0020'H\026ø\001\000¢\006\004\b*\020+J#\0200\032\0020.*\0020,2\006\020&\032\0020-2\006\020/\032\0020.H\026¢\006\004\b0\0201J#\0203\032\0020.*\0020,2\006\020&\032\0020-2\006\0202\032\0020.H\026¢\006\004\b3\0201J#\0204\032\0020.*\0020,2\006\020&\032\0020-2\006\020/\032\0020.H\026¢\006\004\b4\0201J#\0205\032\0020.*\0020,2\006\020&\032\0020-2\006\0202\032\0020.H\026¢\006\004\b5\0201J\023\0207\032\0020\024*\00206H\026¢\006\004\b7\0208J\023\020:\032\0020\024*\00209H\026¢\006\004\b:\020;J*\020B\032\0020\0242\006\020=\032\0020<2\006\020?\032\0020>2\006\020A\032\0020@H\026ø\001\000¢\006\004\bB\020CJ\017\020D\032\0020\024H\026¢\006\004\bD\020\026J\017\020E\032\0020\027H\026¢\006\004\bE\020FJ\017\020G\032\0020\027H\026¢\006\004\bG\020FJ\037\020K\032\004\030\0010I*\0020H2\b\020J\032\004\030\0010IH\026¢\006\004\bK\020LJ\027\020O\032\0020\0242\006\020N\032\0020MH\026¢\006\004\bO\020PJ\032\020R\032\0020\0242\006\020Q\032\0020@H\026ø\001\000¢\006\004\bR\020SJ\027\020T\032\0020\0242\006\020N\032\0020MH\026¢\006\004\bT\020PJ\027\020W\032\0020\0242\006\020V\032\0020UH\026¢\006\004\bW\020XJ\027\020[\032\0020\0242\006\020Z\032\0020YH\026¢\006\004\b[\020\\J\017\020^\032\0020]H\026¢\006\004\b^\020_R*\020\021\032\0020\0202\006\020`\032\0020\0208\006@FX\016¢\006\022\n\004\ba\020b\032\004\bc\020d\"\004\be\020\023R\026\020h\032\0020\0278\002@\002X\016¢\006\006\n\004\bf\020gR\030\020l\032\004\030\0010i8\002@\002X\016¢\006\006\n\004\bj\020kR:\020v\032\032\022\b\022\006\022\002\b\0030n0mj\f\022\b\022\006\022\002\b\0030n`o8\006@\006X\016¢\006\022\n\004\bp\020q\032\004\br\020s\"\004\bt\020uR\030\020x\032\004\030\0010M8\002@\002X\016¢\006\006\n\004\b5\020wR\024\020{\032\0020H8VX\004¢\006\006\032\004\by\020zR\024\020\032\0020|8VX\004¢\006\006\032\004\b}\020~R\035\020Q\032\0030\0018VX\004ø\001\000ø\001\001¢\006\b\032\006\b\001\020\001R\030\020\001\032\0030\0018VX\004¢\006\b\032\006\b\001\020\001R(\020\001\032\0028\000\"\005\b\000\020\001*\b\022\004\022\0028\0000n8VX\004¢\006\b\032\006\b\001\020\001R\026\020\001\032\0020\0278VX\004¢\006\007\032\005\b\001\020F\002\013\n\005\b¡\0360\001\n\002\b!¨\006\001"}, d2 = {"Landroidx/compose/ui/node/a;", "Ldbxyzptlk/f1/w;", "Ldbxyzptlk/f1/n;", "Ldbxyzptlk/f1/a0;", "Ldbxyzptlk/f1/X;", "Ldbxyzptlk/e1/h;", "Ldbxyzptlk/e1/k;", "Ldbxyzptlk/f1/V;", "Ldbxyzptlk/f1/v;", "Ldbxyzptlk/f1/p;", "Ldbxyzptlk/O0/d;", "Ldbxyzptlk/O0/k;", "Ldbxyzptlk/O0/n;", "Ldbxyzptlk/f1/T;", "Ldbxyzptlk/N0/b;", "Landroidx/compose/ui/d$c;", "Landroidx/compose/ui/d$b;", "element", "<init>", "(Landroidx/compose/ui/d$b;)V", "Ldbxyzptlk/pI/D;", "q2", "()V", "", "duringAttach", "n2", "(Z)V", "r2", "Ldbxyzptlk/e1/j;", "t2", "(Ldbxyzptlk/e1/j;)V", "U1", "V1", "q0", "o2", "s2", "Ldbxyzptlk/d1/I;", "Ldbxyzptlk/d1/F;", "measurable", "Ldbxyzptlk/z1/b;", "constraints", "Ldbxyzptlk/d1/H;", "d", "(Ldbxyzptlk/d1/I;Ldbxyzptlk/d1/F;J)Ldbxyzptlk/d1/H;", "Ldbxyzptlk/d1/n;", "Ldbxyzptlk/d1/m;", "", "height", "l", "(Ldbxyzptlk/d1/n;Ldbxyzptlk/d1/m;I)I", "width", "u", "j", "r", "Ldbxyzptlk/S0/c;", "h", "(Ldbxyzptlk/S0/c;)V", "Ldbxyzptlk/l1/x;", "J", "(Ldbxyzptlk/l1/x;)V", "Ldbxyzptlk/a1/p;", "pointerEvent", "Ldbxyzptlk/a1/r;", "pass", "Ldbxyzptlk/z1/r;", "bounds", "f1", "(Ldbxyzptlk/a1/p;Ldbxyzptlk/a1/r;J)V", "p0", "B1", "()Z", "P", "Ldbxyzptlk/z1/d;", "", "parentData", "E", "(Ldbxyzptlk/z1/d;Ljava/lang/Object;)Ljava/lang/Object;", "Ldbxyzptlk/d1/r;", "coordinates", "x", "(Ldbxyzptlk/d1/r;)V", "size", "v", "(J)V", "D", "Ldbxyzptlk/O0/p;", "focusState", "m", "(Ldbxyzptlk/O0/p;)V", "Landroidx/compose/ui/focus/e;", "focusProperties", "j1", "(Landroidx/compose/ui/focus/e;)V", "", "toString", "()Ljava/lang/String;", "value", "n", "Landroidx/compose/ui/d$b;", "l2", "()Landroidx/compose/ui/d$b;", "p2", "o", "Z", "invalidateCache", "Ldbxyzptlk/e1/a;", "p", "Ldbxyzptlk/e1/a;", "_providedValues", "Ljava/util/HashSet;", "Ldbxyzptlk/e1/c;", "Lkotlin/collections/HashSet;", "q", "Ljava/util/HashSet;", "m2", "()Ljava/util/HashSet;", "setReadValues", "(Ljava/util/HashSet;)V", "readValues", "Ldbxyzptlk/d1/r;", "lastOnPlacedCoordinates", "getDensity", "()Ldbxyzptlk/z1/d;", "density", "Ldbxyzptlk/z1/t;", "getLayoutDirection", "()Ldbxyzptlk/z1/t;", "layoutDirection", "Ldbxyzptlk/P0/l;", "c", "()J", "Ldbxyzptlk/e1/g;", "S", "()Ldbxyzptlk/e1/g;", "providedValues", "T", "b", "(Ldbxyzptlk/e1/c;)Ljava/lang/Object;", "current", "k0", "isValidOwnerScope", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class a extends d.c implements w, n, a0, X, h, k, V, v, p, d, k, n, T, b {
  public d.b n;
  
  public boolean o;
  
  public dbxyzptlk.e1.a p;
  
  public HashSet<c<?>> q;
  
  public r r;
  
  public a(d.b paramb) {
    e2(L.f(paramb));
    this.n = paramb;
    this.o = true;
    this.q = new HashSet<>();
  }
  
  public boolean B1() {
    d.b b1 = this.n;
    s.f(b1, "null cannot be cast to non-null type androidx.compose.ui.input.pointer.PointerInputModifier");
    return ((H)b1).y().c();
  }
  
  public void D(r paramr) {
    this.r = paramr;
    d.b b1 = this.n;
    if (b1 instanceof P)
      ((P)b1).D(paramr); 
  }
  
  public Object E(dbxyzptlk.z1.d paramd, Object paramObject) {
    d.b b1 = this.n;
    s.f(b1, "null cannot be cast to non-null type androidx.compose.ui.layout.ParentDataModifier");
    return ((V)b1).E(paramd, paramObject);
  }
  
  public void J(x paramx) {
    d.b b1 = this.n;
    s.f(b1, "null cannot be cast to non-null type androidx.compose.ui.semantics.SemanticsModifier");
    l l = ((n)b1).z();
    s.f(paramx, "null cannot be cast to non-null type androidx.compose.ui.semantics.SemanticsConfiguration");
    ((l)paramx).e(l);
  }
  
  public boolean P() {
    d.b b1 = this.n;
    s.f(b1, "null cannot be cast to non-null type androidx.compose.ui.input.pointer.PointerInputModifier");
    return ((H)b1).y().a();
  }
  
  public g S() {
    g g;
    dbxyzptlk.e1.a a1 = this.p;
    if (a1 == null)
      g = i.a(); 
    return g;
  }
  
  public void U1() {
    n2(true);
  }
  
  public void V1() {
    q2();
  }
  
  public <T> T b(c<T> paramc) {
    this.q.add(paramc);
    int i = K.a(32);
    if (Q0().R1()) {
      d.c c1 = Q0().O1();
      f f = h.k((g)this);
      while (f != null) {
        if ((f.i0().k().H1() & i) != 0)
          for (d.c c2 = c1; c2 != null; c2 = c2.O1()) {
            if ((c2.M1() & i) != 0) {
              d.c c3 = c2;
              c1 = null;
              while (c3 != null) {
                dbxyzptlk.z0.d d2;
                h h1;
                if (c3 instanceof h) {
                  h1 = (h)c3;
                  d.c c5 = c1;
                  if (h1.S().a(paramc))
                    return (T)h1.S().b(paramc); 
                } else {
                  d.c c5 = c1;
                  if ((h1.M1() & i) != 0) {
                    c5 = c1;
                    if (h1 instanceof i) {
                      dbxyzptlk.z0.d d3;
                      c5 = ((i)h1).l2();
                      int j;
                      for (j = 0; c5 != null; j = m) {
                        dbxyzptlk.z0.d d4;
                        h h2 = h1;
                        d.c c6 = c1;
                        int m = j;
                        if ((c5.M1() & i) != 0) {
                          m = j + 1;
                          if (m == 1) {
                            d.c c7 = c5;
                            c6 = c1;
                          } else {
                            dbxyzptlk.z0.d d5;
                            d.c c7 = c1;
                            if (c1 == null)
                              d5 = new dbxyzptlk.z0.d((Object[])new d.c[16], 0); 
                            h h3 = h1;
                            if (h1 != null) {
                              d5.c(h1);
                              h3 = null;
                            } 
                            d5.c(c5);
                            d4 = d5;
                            h2 = h3;
                          } 
                        } 
                        c5 = c5.I1();
                        h1 = h2;
                        d3 = d4;
                      } 
                      d2 = d3;
                      if (j == 1)
                        continue; 
                    } 
                  } 
                } 
                d.c c4 = h.b(d2);
                dbxyzptlk.z0.d d1 = d2;
              } 
            } 
          }  
        f = f.m0();
        if (f != null) {
          l l = f.i0();
          if (l != null) {
            d.c c2 = l.p();
            continue;
          } 
        } 
        c1 = null;
      } 
      return (T)paramc.a().invoke();
    } 
    throw new IllegalStateException("visitAncestors called on an unattached node");
  }
  
  public long c() {
    return s.c(h.h((g)this, K.a(128)).a());
  }
  
  public H d(I paramI, F paramF, long paramLong) {
    d.b b1 = this.n;
    s.f(b1, "null cannot be cast to non-null type androidx.compose.ui.layout.LayoutModifier");
    return ((x)b1).d(paramI, paramF, paramLong);
  }
  
  public void f1(p paramp, r paramr, long paramLong) {
    d.b b1 = this.n;
    s.f(b1, "null cannot be cast to non-null type androidx.compose.ui.input.pointer.PointerInputModifier");
    ((H)b1).y().e(paramp, paramr, paramLong);
  }
  
  public dbxyzptlk.z1.d getDensity() {
    return h.k((g)this).I();
  }
  
  public t getLayoutDirection() {
    return h.k((g)this).getLayoutDirection();
  }
  
  public void h(c paramc) {
    d.b b1 = this.n;
    s.f(b1, "null cannot be cast to non-null type androidx.compose.ui.draw.DrawModifier");
    i i = (i)b1;
    if (this.o && b1 instanceof dbxyzptlk.N0.h)
      r2(); 
    i.h(paramc);
  }
  
  public int j(n paramn, m paramm, int paramInt) {
    d.b b1 = this.n;
    s.f(b1, "null cannot be cast to non-null type androidx.compose.ui.layout.LayoutModifier");
    return ((x)b1).j(paramn, paramm, paramInt);
  }
  
  public void j1(e parame) {
    d.b b1 = this.n;
    if (b1 instanceof i) {
      ((i)b1).w(new h(parame));
      return;
    } 
    throw new IllegalStateException("applyFocusProperties called on wrong node");
  }
  
  public boolean k0() {
    return R1();
  }
  
  public int l(n paramn, m paramm, int paramInt) {
    d.b b1 = this.n;
    s.f(b1, "null cannot be cast to non-null type androidx.compose.ui.layout.LayoutModifier");
    return ((x)b1).l(paramn, paramm, paramInt);
  }
  
  public final d.b l2() {
    return this.n;
  }
  
  public void m(p paramp) {
    d.b b1 = this.n;
    if (b1 instanceof c) {
      ((c)b1).m(paramp);
      return;
    } 
    throw new IllegalStateException("onFocusEvent called on wrong node");
  }
  
  public final HashSet<c<?>> m2() {
    return this.q;
  }
  
  public final void n2(boolean paramBoolean) {
    if (R1()) {
      d.b b1 = this.n;
      if ((K.a(32) & M1()) != 0) {
        if (b1 instanceof dbxyzptlk.e1.d)
          i2(new a(this)); 
        if (b1 instanceof j)
          t2((j)b1); 
      } 
      if ((K.a(4) & M1()) != 0) {
        if (b1 instanceof dbxyzptlk.N0.h)
          this.o = true; 
        if (!paramBoolean)
          y.a(this); 
      } 
      if ((K.a(2) & M1()) != 0) {
        if (b.d(this)) {
          n n1 = J1();
          s.e(n1);
          ((e)n1).j3(this);
          n1.E2();
        } 
        if (!paramBoolean) {
          y.a(this);
          h.k((g)this).E0();
        } 
      } 
      if (b1 instanceof b0)
        ((b0)b1).n(h.k((g)this)); 
      if ((K.a(128) & M1()) != 0) {
        if (b1 instanceof Q && b.d(this))
          h.k((g)this).E0(); 
        if (b1 instanceof P) {
          this.r = null;
          if (b.d(this))
            h.l((g)this).g((Owner.b)new b(this)); 
        } 
      } 
      if ((K.a(256) & M1()) != 0 && b1 instanceof N && b.d(this))
        h.k((g)this).E0(); 
      if (b1 instanceof m)
        ((m)b1).f().d().c(this); 
      if ((K.a(16) & M1()) != 0 && b1 instanceof H)
        ((H)b1).y().f(J1()); 
      if ((K.a(8) & M1()) != 0)
        h.l((g)this).B(); 
      return;
    } 
    throw new IllegalStateException("initializeModifier called on unattached node");
  }
  
  public final void o2() {
    this.o = true;
    o.a(this);
  }
  
  public void p0() {
    d.b b1 = this.n;
    s.f(b1, "null cannot be cast to non-null type androidx.compose.ui.input.pointer.PointerInputModifier");
    ((H)b1).y().d();
  }
  
  public final void p2(d.b paramb) {
    if (R1())
      q2(); 
    this.n = paramb;
    e2(L.f(paramb));
    if (R1())
      n2(false); 
  }
  
  public void q0() {
    this.o = true;
    o.a(this);
  }
  
  public final void q2() {
    if (R1()) {
      d.b b1 = this.n;
      if ((K.a(32) & M1()) != 0) {
        if (b1 instanceof j)
          h.l((g)this).getModifierLocalManager().d(this, (c)((j)b1).getKey()); 
        if (b1 instanceof dbxyzptlk.e1.d)
          ((dbxyzptlk.e1.d)b1).s(b.a()); 
      } 
      if ((K.a(8) & M1()) != 0)
        h.l((g)this).B(); 
      if (b1 instanceof m)
        ((m)b1).f().d().A(this); 
      return;
    } 
    throw new IllegalStateException("unInitializeModifier called on unattached node");
  }
  
  public int r(n paramn, m paramm, int paramInt) {
    d.b b1 = this.n;
    s.f(b1, "null cannot be cast to non-null type androidx.compose.ui.layout.LayoutModifier");
    return ((x)b1).r(paramn, paramm, paramInt);
  }
  
  public final void r2() {
    d.b b1 = this.n;
    if (b1 instanceof dbxyzptlk.N0.h)
      h.l((g)this).getSnapshotObserver().i(this, b.b(), (dbxyzptlk.CI.a)new c(b1, this)); 
    this.o = false;
  }
  
  public final void s2() {
    if (R1()) {
      this.q.clear();
      h.l((g)this).getSnapshotObserver().i(this, b.c(), new d(this));
    } 
  }
  
  public final void t2(j<?> paramj) {
    dbxyzptlk.e1.a a1 = this.p;
    if (a1 != null && a1.a((c)paramj.getKey())) {
      a1.c(paramj);
      h.l((g)this).getModifierLocalManager().f(this, (c)paramj.getKey());
    } else {
      this.p = new dbxyzptlk.e1.a(paramj);
      if (b.d(this))
        h.l((g)this).getModifierLocalManager().a(this, (c)paramj.getKey()); 
    } 
  }
  
  public String toString() {
    return this.n.toString();
  }
  
  public int u(n paramn, m paramm, int paramInt) {
    d.b b1 = this.n;
    s.f(b1, "null cannot be cast to non-null type androidx.compose.ui.layout.LayoutModifier");
    return ((x)b1).u(paramn, paramm, paramInt);
  }
  
  public void v(long paramLong) {
    d.b b1 = this.n;
    if (b1 instanceof Q)
      ((Q)b1).v(paramLong); 
  }
  
  public void x(r paramr) {
    d.b b1 = this.n;
    s.f(b1, "null cannot be cast to non-null type androidx.compose.ui.layout.OnGloballyPositionedModifier");
    ((N)b1).x(paramr);
  }
  
  @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"Ldbxyzptlk/pI/D;", "b", "()V"}, k = 3, mv = {1, 8, 0})
  public static final class a extends u implements dbxyzptlk.CI.a<D> {
    public final a f;
    
    public a(a param1a) {
      super(0);
    }
    
    public final void b() {
      this.f.s2();
    }
  }
  
  @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"Ldbxyzptlk/pI/D;", "b", "()V"}, k = 3, mv = {1, 8, 0})
  public static final class d extends u implements dbxyzptlk.CI.a<D> {
    public final a f;
    
    public d(a param1a) {
      super(0);
    }
    
    public final void b() {
      d.b b = this.f.l2();
      s.f(b, "null cannot be cast to non-null type androidx.compose.ui.modifier.ModifierLocalConsumer");
      ((dbxyzptlk.e1.d)b).s(this.f);
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compos\\ui\node\a.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */