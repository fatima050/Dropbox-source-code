package androidx.compose.ui.node;

import androidx.compose.ui.d;
import dbxyzptlk.CI.l;
import dbxyzptlk.DI.s;
import dbxyzptlk.DI.u;
import dbxyzptlk.KI.n;
import dbxyzptlk.f1.G;
import dbxyzptlk.z0.d;
import kotlin.Metadata;

@Metadata(d1 = {"\0007\n\002\030\002\n\002\b\002\n\002\020\b\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\030\002\n\002\b\003\n\002\b\005*\001\022\032\037\020\004\032\0020\0032\006\020\001\032\0020\0002\006\020\002\032\0020\000H\000¢\006\004\b\004\020\005\032+\020\013\032\0020\n\"\b\b\000\020\007*\0020\006*\b\022\004\022\0028\0000\b2\006\020\t\032\0020\006H\002¢\006\004\b\013\020\f\032'\020\020\032\b\022\004\022\0020\0000\016*\0020\r2\f\020\017\032\b\022\004\022\0020\0000\016H\002¢\006\004\b\020\020\021\"\024\020\025\032\0020\0228\002X\004¢\006\006\n\004\b\023\020\024¨\006\026"}, d2 = {"Landroidx/compose/ui/d$b;", "prev", "next", "", "d", "(Landroidx/compose/ui/d$b;Landroidx/compose/ui/d$b;)I", "Landroidx/compose/ui/d$c;", "T", "Ldbxyzptlk/f1/G;", "node", "Ldbxyzptlk/pI/D;", "f", "(Ldbxyzptlk/f1/G;Landroidx/compose/ui/d$c;)V", "Landroidx/compose/ui/d;", "Ldbxyzptlk/z0/d;", "result", "e", "(Landroidx/compose/ui/d;Ldbxyzptlk/z0/d;)Ldbxyzptlk/z0/d;", "androidx/compose/ui/node/m$a", "a", "Landroidx/compose/ui/node/m$a;", "SentinelHead", "ui_release"}, k = 2, mv = {1, 8, 0}, xi = 48)
public final class m {
  public static final a a;
  
  static {
    a a1 = new a();
    a1.a2(-1);
    a = a1;
  }
  
  public static final int d(d.b paramb1, d.b paramb2) {
    boolean bool;
    if (s.c(paramb1, paramb2)) {
      bool = true;
    } else {
      if (dbxyzptlk.K0.b.a(paramb1, paramb2) || (paramb1 instanceof ForceUpdateElement && dbxyzptlk.K0.b.a(((ForceUpdateElement)paramb1).i(), paramb2)))
        return 1; 
      bool = false;
    } 
    return bool;
  }
  
  public static final d<d.b> e(d paramd, d<d.b> paramd1) {
    d d1 = new d((Object[])new d[n.e(paramd1.p(), 16)], 0);
    d1.c(paramd);
    paramd = null;
    while (d1.w()) {
      b b2;
      d d3 = (d)d1.C(d1.p() - 1);
      if (d3 instanceof androidx.compose.ui.a) {
        androidx.compose.ui.a a1 = (androidx.compose.ui.a)d3;
        d1.c(a1.b());
        d1.c(a1.e());
        continue;
      } 
      if (d3 instanceof d.b) {
        paramd1.c(d3);
        continue;
      } 
      d d2 = paramd;
      if (paramd == null)
        b2 = new b(paramd1); 
      d3.c(b2);
      b b1 = b2;
    } 
    return paramd1;
  }
  
  public static final <T extends d.c> void f(G<T> paramG, d.c paramc) {
    s.f(paramc, "null cannot be cast to non-null type T of androidx.compose.ui.node.NodeChainKt.updateUnsafe");
    paramG.e(paramc);
  }
  
  @Metadata(d1 = {"\000\021\n\000\n\002\030\002\n\002\020\016\n\002\b\003*\001\000\b\n\030\0002\0020\001J\017\020\003\032\0020\002H\026¢\006\004\b\003\020\004¨\006\005"}, d2 = {"androidx/compose/ui/node/m$a", "Landroidx/compose/ui/d$c;", "", "toString", "()Ljava/lang/String;", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class a extends d.c {
    public String toString() {
      return "<Head>";
    }
  }
  
  @Metadata(d1 = {"\000\016\n\002\030\002\n\000\n\002\020\013\n\002\b\002\020\003\032\0020\0022\006\020\001\032\0020\000H\n¢\006\004\b\003\020\004"}, d2 = {"Landroidx/compose/ui/d$b;", "element", "", "a", "(Landroidx/compose/ui/d$b;)Ljava/lang/Boolean;"}, k = 3, mv = {1, 8, 0})
  public static final class b extends u implements l<d.b, Boolean> {
    public final d<d.b> f;
    
    public b(d<d.b> param1d) {
      super(1);
    }
    
    public final Boolean a(d.b param1b) {
      this.f.c(param1b);
      return Boolean.TRUE;
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compos\\ui\node\m.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */