package androidx.compose.ui.node;

import dbxyzptlk.DI.s;
import dbxyzptlk.f1.E;
import dbxyzptlk.f1.Q;
import dbxyzptlk.f1.j;
import dbxyzptlk.pI.D;
import dbxyzptlk.z0.d;
import kotlin.Metadata;
import kotlin.NoWhenBranchMatchedException;

@Metadata(d1 = {"\000f\n\002\030\002\n\002\020\000\n\002\030\002\n\002\b\003\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\020\013\n\002\b\007\n\002\030\002\n\002\b\007\n\002\030\002\n\002\b\031\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\002\n\002\020\t\n\002\b\004\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\021\b\000\030\0002\0020\001:\0014B\017\022\006\020\003\032\0020\002¢\006\004\b\004\020\005J\030\020\t\032\0020\b2\006\020\007\032\0020\006ø\001\000¢\006\004\b\t\020\nJ\037\020\016\032\0020\f2\006\020\013\032\0020\0022\b\b\002\020\r\032\0020\f¢\006\004\b\016\020\017J\037\020\020\032\0020\f2\006\020\013\032\0020\0022\b\b\002\020\r\032\0020\f¢\006\004\b\020\020\017J\037\020\021\032\0020\f2\006\020\013\032\0020\0022\b\b\002\020\r\032\0020\f¢\006\004\b\021\020\017J\037\020\022\032\0020\f2\006\020\013\032\0020\0022\b\b\002\020\r\032\0020\f¢\006\004\b\022\020\017J\025\020\023\032\0020\b2\006\020\013\032\0020\002¢\006\004\b\023\020\005J\037\020\026\032\0020\f2\020\b\002\020\025\032\n\022\004\022\0020\b\030\0010\024¢\006\004\b\026\020\027J\r\020\030\032\0020\b¢\006\004\b\030\020\031J \020\032\032\0020\b2\006\020\013\032\0020\0022\006\020\007\032\0020\006ø\001\000¢\006\004\b\032\020\033J\025\020\036\032\0020\b2\006\020\035\032\0020\034¢\006\004\b\036\020\037J\035\020!\032\0020\b2\006\020\013\032\0020\0022\006\020 \032\0020\f¢\006\004\b!\020\"J\027\020$\032\0020\b2\b\b\002\020#\032\0020\f¢\006\004\b$\020%J\025\020'\032\0020\b2\006\020&\032\0020\002¢\006\004\b'\020\005J$\020(\032\0020\f2\006\020\013\032\0020\0022\b\020\007\032\004\030\0010\006H\002ø\001\000¢\006\004\b(\020)J$\020*\032\0020\f2\006\020\013\032\0020\0022\b\020\007\032\004\030\0010\006H\002ø\001\000¢\006\004\b*\020)J\027\020+\032\0020\b2\006\020\013\032\0020\002H\002¢\006\004\b+\020\005J\017\020,\032\0020\bH\002¢\006\004\b,\020\031J+\020.\032\0020\f2\006\020\013\032\0020\0022\b\b\002\020 \032\0020\f2\b\b\002\020-\032\0020\fH\002¢\006\004\b.\020/J\037\0200\032\0020\b2\006\020\013\032\0020\0022\006\020 \032\0020\fH\002¢\006\004\b0\020\"J\037\0201\032\0020\b2\006\020&\032\0020\0022\006\020 \032\0020\fH\002¢\006\004\b1\020\"J\037\0202\032\0020\b2\006\020\013\032\0020\0022\006\020 \032\0020\fH\002¢\006\004\b2\020\"J\033\0203\032\0020\f*\0020\0022\006\020 \032\0020\fH\002¢\006\004\b3\020\017R\024\020\003\032\0020\0028\002X\004¢\006\006\n\004\b4\0205R\024\0208\032\002068\002X\004¢\006\006\n\004\b,\0207R\026\020:\032\0020\f8\002@\002X\016¢\006\006\n\004\b$\0209R\024\020>\032\0020;8\002X\004¢\006\006\n\004\b<\020=R\032\020A\032\b\022\004\022\0020\0340?8\002X\004¢\006\006\n\004\b(\020@R$\020F\032\0020B2\006\020C\032\0020B8F@BX\016¢\006\f\n\004\b*\020\t\032\004\bD\020ER\032\020H\032\b\022\004\022\0020G0?8\002X\004¢\006\006\n\004\b!\020@R\036\020J\032\004\030\0010\0068\002@\002X\016ø\001\000ø\001\001¢\006\006\n\004\b2\020IR\026\020N\032\004\030\0010K8\002X\004¢\006\006\n\004\bL\020MR\021\020Q\032\0020\f8F¢\006\006\032\004\bO\020PR\021\020S\032\0020\f8F¢\006\006\032\004\bR\020PR\030\020V\032\0020\f*\0020\0028BX\004¢\006\006\032\004\bT\020UR\030\020W\032\0020\f*\0020\0028BX\004¢\006\006\032\004\bL\020UR\030\020Y\032\0020\f*\0020\0028BX\004¢\006\006\032\004\bX\020UR\030\020[\032\0020\f*\0020\0028BX\004¢\006\006\032\004\bZ\020U\002\013\n\005\b¡\0360\001\n\002\b!¨\006\\"}, d2 = {"Landroidx/compose/ui/node/k;", "", "Landroidx/compose/ui/node/f;", "root", "<init>", "(Landroidx/compose/ui/node/f;)V", "Ldbxyzptlk/z1/b;", "constraints", "Ldbxyzptlk/pI/D;", "J", "(J)V", "layoutNode", "", "forced", "C", "(Landroidx/compose/ui/node/f;Z)Z", "H", "A", "F", "E", "Lkotlin/Function0;", "onLayout", "p", "(Ldbxyzptlk/CI/a;)Z", "r", "()V", "q", "(Landroidx/compose/ui/node/f;J)V", "Landroidx/compose/ui/node/Owner$b;", "listener", "v", "(Landroidx/compose/ui/node/Owner$b;)V", "affectsLookahead", "g", "(Landroidx/compose/ui/node/f;Z)V", "forceDispatch", "c", "(Z)V", "node", "t", "e", "(Landroidx/compose/ui/node/f;Ldbxyzptlk/z1/b;)Z", "f", "y", "b", "relayoutNeeded", "w", "(Landroidx/compose/ui/node/f;ZZ)Z", "z", "u", "h", "s", "a", "Landroidx/compose/ui/node/f;", "Ldbxyzptlk/f1/k;", "Ldbxyzptlk/f1/k;", "relayoutNodes", "Z", "duringMeasureLayout", "Ldbxyzptlk/f1/Q;", "d", "Ldbxyzptlk/f1/Q;", "onPositionedDispatcher", "Ldbxyzptlk/z0/d;", "Ldbxyzptlk/z0/d;", "onLayoutCompletedListeners", "", "<set-?>", "o", "()J", "measureIteration", "Landroidx/compose/ui/node/k$a;", "postponedMeasureRequests", "Ldbxyzptlk/z1/b;", "rootConstraints", "Landroidx/compose/ui/node/h;", "i", "Landroidx/compose/ui/node/h;", "consistencyChecker", "k", "()Z", "hasPendingMeasureOrLayout", "l", "hasPendingOnPositionedCallbacks", "m", "(Landroidx/compose/ui/node/f;)Z", "measureAffectsParent", "canAffectParent", "j", "canAffectParentInLookahead", "n", "measureAffectsParentLookahead", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class k {
  public final f a;
  
  public final dbxyzptlk.f1.k b;
  
  public boolean c;
  
  public final Q d;
  
  public final d<Owner.b> e;
  
  public long f;
  
  public final d<a> g;
  
  public dbxyzptlk.z1.b h;
  
  public final h i;
  
  public k(f paramf) {
    this.a = paramf;
    Owner.a a = Owner.r0;
    dbxyzptlk.f1.k k1 = new dbxyzptlk.f1.k(a.a());
    this.b = k1;
    this.d = new Q();
    this.e = new d((Object[])new Owner.b[16], 0);
    this.f = 1L;
    d<a> d1 = new d((Object[])new a[16], 0);
    this.g = d1;
    if (a.a()) {
      h h1 = new h(paramf, k1, d1.h());
    } else {
      paramf = null;
    } 
    this.i = (h)paramf;
  }
  
  public final boolean A(f paramf, boolean paramBoolean) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual U : ()Landroidx/compose/ui/node/f$e;
    //   4: astore #5
    //   6: getstatic androidx/compose/ui/node/k$b.a : [I
    //   9: aload #5
    //   11: invokevirtual ordinal : ()I
    //   14: iaload
    //   15: istore_3
    //   16: iconst_0
    //   17: istore #4
    //   19: iload_3
    //   20: iconst_1
    //   21: if_icmpeq -> 246
    //   24: iload_3
    //   25: iconst_2
    //   26: if_icmpeq -> 55
    //   29: iload_3
    //   30: iconst_3
    //   31: if_icmpeq -> 246
    //   34: iload_3
    //   35: iconst_4
    //   36: if_icmpeq -> 55
    //   39: iload_3
    //   40: iconst_5
    //   41: if_icmpne -> 47
    //   44: goto -> 55
    //   47: new kotlin/NoWhenBranchMatchedException
    //   50: dup
    //   51: invokespecial <init> : ()V
    //   54: athrow
    //   55: aload_1
    //   56: invokevirtual W : ()Z
    //   59: ifne -> 69
    //   62: aload_1
    //   63: invokevirtual V : ()Z
    //   66: ifeq -> 95
    //   69: iload_2
    //   70: ifne -> 95
    //   73: aload_0
    //   74: getfield i : Landroidx/compose/ui/node/h;
    //   77: astore_1
    //   78: iload #4
    //   80: istore_2
    //   81: aload_1
    //   82: ifnull -> 265
    //   85: aload_1
    //   86: invokevirtual a : ()V
    //   89: iload #4
    //   91: istore_2
    //   92: goto -> 265
    //   95: aload_1
    //   96: invokevirtual R0 : ()V
    //   99: aload_1
    //   100: invokevirtual Q0 : ()V
    //   103: aload_1
    //   104: invokevirtual J0 : ()Z
    //   107: ifeq -> 116
    //   110: iload #4
    //   112: istore_2
    //   113: goto -> 265
    //   116: aload_1
    //   117: invokevirtual m0 : ()Landroidx/compose/ui/node/f;
    //   120: astore #5
    //   122: aload_1
    //   123: invokevirtual L0 : ()Ljava/lang/Boolean;
    //   126: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
    //   129: invokestatic c : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   132: ifeq -> 181
    //   135: aload #5
    //   137: ifnull -> 152
    //   140: aload #5
    //   142: invokevirtual W : ()Z
    //   145: iconst_1
    //   146: if_icmpne -> 152
    //   149: goto -> 181
    //   152: aload #5
    //   154: ifnull -> 169
    //   157: aload #5
    //   159: invokevirtual V : ()Z
    //   162: iconst_1
    //   163: if_icmpne -> 169
    //   166: goto -> 181
    //   169: aload_0
    //   170: getfield b : Ldbxyzptlk/f1/k;
    //   173: aload_1
    //   174: iconst_1
    //   175: invokevirtual c : (Landroidx/compose/ui/node/f;Z)V
    //   178: goto -> 231
    //   181: aload_1
    //   182: invokevirtual h : ()Z
    //   185: ifeq -> 231
    //   188: aload #5
    //   190: ifnull -> 205
    //   193: aload #5
    //   195: invokevirtual T : ()Z
    //   198: iconst_1
    //   199: if_icmpne -> 205
    //   202: goto -> 231
    //   205: aload #5
    //   207: ifnull -> 222
    //   210: aload #5
    //   212: invokevirtual b0 : ()Z
    //   215: iconst_1
    //   216: if_icmpne -> 222
    //   219: goto -> 231
    //   222: aload_0
    //   223: getfield b : Ldbxyzptlk/f1/k;
    //   226: aload_1
    //   227: iconst_0
    //   228: invokevirtual c : (Landroidx/compose/ui/node/f;Z)V
    //   231: iload #4
    //   233: istore_2
    //   234: aload_0
    //   235: getfield c : Z
    //   238: ifne -> 265
    //   241: iconst_1
    //   242: istore_2
    //   243: goto -> 265
    //   246: aload_0
    //   247: getfield i : Landroidx/compose/ui/node/h;
    //   250: astore_1
    //   251: iload #4
    //   253: istore_2
    //   254: aload_1
    //   255: ifnull -> 265
    //   258: aload_1
    //   259: invokevirtual a : ()V
    //   262: iload #4
    //   264: istore_2
    //   265: iload_2
    //   266: ireturn
  }
  
  public final boolean C(f paramf, boolean paramBoolean) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual Y : ()Landroidx/compose/ui/node/f;
    //   4: ifnull -> 262
    //   7: aload_1
    //   8: invokevirtual U : ()Landroidx/compose/ui/node/f$e;
    //   11: astore #6
    //   13: getstatic androidx/compose/ui/node/k$b.a : [I
    //   16: aload #6
    //   18: invokevirtual ordinal : ()I
    //   21: iaload
    //   22: istore_3
    //   23: iconst_0
    //   24: istore #5
    //   26: iload #5
    //   28: istore #4
    //   30: iload_3
    //   31: iconst_1
    //   32: if_icmpeq -> 259
    //   35: iload_3
    //   36: iconst_2
    //   37: if_icmpeq -> 220
    //   40: iload_3
    //   41: iconst_3
    //   42: if_icmpeq -> 220
    //   45: iload_3
    //   46: iconst_4
    //   47: if_icmpeq -> 220
    //   50: iload_3
    //   51: iconst_5
    //   52: if_icmpne -> 212
    //   55: aload_1
    //   56: invokevirtual W : ()Z
    //   59: ifeq -> 73
    //   62: iload_2
    //   63: ifne -> 73
    //   66: iload #5
    //   68: istore #4
    //   70: goto -> 259
    //   73: aload_1
    //   74: invokevirtual S0 : ()V
    //   77: aload_1
    //   78: invokevirtual T0 : ()V
    //   81: aload_1
    //   82: invokevirtual J0 : ()Z
    //   85: ifeq -> 95
    //   88: iload #5
    //   90: istore #4
    //   92: goto -> 259
    //   95: aload_1
    //   96: invokevirtual L0 : ()Ljava/lang/Boolean;
    //   99: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
    //   102: invokestatic c : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   105: ifne -> 116
    //   108: aload_0
    //   109: aload_1
    //   110: invokevirtual j : (Landroidx/compose/ui/node/f;)Z
    //   113: ifeq -> 136
    //   116: aload_1
    //   117: invokevirtual m0 : ()Landroidx/compose/ui/node/f;
    //   120: astore #6
    //   122: aload #6
    //   124: ifnull -> 186
    //   127: aload #6
    //   129: invokevirtual W : ()Z
    //   132: iconst_1
    //   133: if_icmpne -> 186
    //   136: aload_1
    //   137: invokevirtual h : ()Z
    //   140: ifne -> 151
    //   143: aload_0
    //   144: aload_1
    //   145: invokevirtual i : (Landroidx/compose/ui/node/f;)Z
    //   148: ifeq -> 195
    //   151: aload_1
    //   152: invokevirtual m0 : ()Landroidx/compose/ui/node/f;
    //   155: astore #6
    //   157: aload #6
    //   159: ifnull -> 174
    //   162: aload #6
    //   164: invokevirtual b0 : ()Z
    //   167: iconst_1
    //   168: if_icmpne -> 174
    //   171: goto -> 195
    //   174: aload_0
    //   175: getfield b : Ldbxyzptlk/f1/k;
    //   178: aload_1
    //   179: iconst_0
    //   180: invokevirtual c : (Landroidx/compose/ui/node/f;Z)V
    //   183: goto -> 195
    //   186: aload_0
    //   187: getfield b : Ldbxyzptlk/f1/k;
    //   190: aload_1
    //   191: iconst_1
    //   192: invokevirtual c : (Landroidx/compose/ui/node/f;Z)V
    //   195: iload #5
    //   197: istore #4
    //   199: aload_0
    //   200: getfield c : Z
    //   203: ifne -> 259
    //   206: iconst_1
    //   207: istore #4
    //   209: goto -> 259
    //   212: new kotlin/NoWhenBranchMatchedException
    //   215: dup
    //   216: invokespecial <init> : ()V
    //   219: athrow
    //   220: aload_0
    //   221: getfield g : Ldbxyzptlk/z0/d;
    //   224: new androidx/compose/ui/node/k$a
    //   227: dup
    //   228: aload_1
    //   229: iconst_1
    //   230: iload_2
    //   231: invokespecial <init> : (Landroidx/compose/ui/node/f;ZZ)V
    //   234: invokevirtual c : (Ljava/lang/Object;)Z
    //   237: pop
    //   238: aload_0
    //   239: getfield i : Landroidx/compose/ui/node/h;
    //   242: astore_1
    //   243: iload #5
    //   245: istore #4
    //   247: aload_1
    //   248: ifnull -> 259
    //   251: aload_1
    //   252: invokevirtual a : ()V
    //   255: iload #5
    //   257: istore #4
    //   259: iload #4
    //   261: ireturn
    //   262: new java/lang/IllegalStateException
    //   265: dup
    //   266: ldc_w 'Error: requestLookaheadRemeasure cannot be called on a node outside LookaheadScope'
    //   269: invokespecial <init> : (Ljava/lang/String;)V
    //   272: athrow
  }
  
  public final void E(f paramf) {
    this.d.d(paramf);
  }
  
  public final boolean F(f paramf, boolean paramBoolean) {
    f.e e = paramf.U();
    int i = b.a[e.ordinal()];
    boolean bool = true;
    if (i != 1 && i != 2 && i != 3 && i != 4) {
      if (i == 5) {
        h h1;
        if (!paramBoolean && paramf.h() == paramf.K0() && (paramf.b0() || paramf.T())) {
          h1 = this.i;
          if (h1 != null)
            h1.a(); 
        } else {
          h1.Q0();
          if (!h1.J0()) {
            if (h1.K0()) {
              f f1 = h1.m0();
              if ((f1 == null || f1.T() != true) && (f1 == null || f1.b0() != true))
                this.b.c((f)h1, false); 
            } 
            if (!this.c)
              return bool; 
          } 
        } 
      } else {
        throw new NoWhenBranchMatchedException();
      } 
    } else {
      h h1 = this.i;
      if (h1 != null)
        h1.a(); 
    } 
    return false;
  }
  
  public final boolean H(f paramf, boolean paramBoolean) {
    f.e e = paramf.U();
    int i = b.a[e.ordinal()];
    boolean bool = true;
    if (i != 1 && i != 2)
      if (i != 3 && i != 4) {
        if (i == 5) {
          if (!paramf.b0() || paramBoolean) {
            paramf.T0();
            if (!paramf.J0()) {
              if (paramf.h() || i(paramf)) {
                f f1 = paramf.m0();
                if (f1 == null || f1.b0() != true)
                  this.b.c(paramf, false); 
              } 
              if (!this.c)
                return bool; 
            } 
          } 
        } else {
          throw new NoWhenBranchMatchedException();
        } 
      } else {
        this.g.c(new a(paramf, false, paramBoolean));
        h h1 = this.i;
        if (h1 != null)
          h1.a(); 
      }  
    return false;
  }
  
  public final void J(long paramLong) {
    boolean bool;
    dbxyzptlk.z1.b b1 = this.h;
    boolean bool1 = false;
    if (b1 == null) {
      bool = false;
    } else {
      bool = dbxyzptlk.z1.b.g(b1.t(), paramLong);
    } 
    if (!bool)
      if (!this.c) {
        this.h = dbxyzptlk.z1.b.b(paramLong);
        if (this.a.Y() != null)
          this.a.S0(); 
        this.a.T0();
        dbxyzptlk.f1.k k1 = this.b;
        f f1 = this.a;
        bool = bool1;
        if (f1.Y() != null)
          bool = true; 
        k1.c(f1, bool);
      } else {
        throw new IllegalArgumentException("updateRootConstraints called while measuring");
      }  
  }
  
  public final void b() {
    d<Owner.b> d1 = this.e;
    int i = d1.p();
    if (i > 0) {
      int m;
      Object[] arrayOfObject = d1.o();
      int j = 0;
      do {
        ((Owner.b)arrayOfObject[j]).l();
        m = j + 1;
        j = m;
      } while (m < i);
    } 
    this.e.i();
  }
  
  public final void c(boolean paramBoolean) {
    if (paramBoolean)
      this.d.e(this.a); 
    this.d.a();
  }
  
  public final boolean e(f paramf, dbxyzptlk.z1.b paramb) {
    boolean bool;
    if (paramf.Y() == null)
      return false; 
    if (paramb != null) {
      bool = paramf.N0(paramb);
    } else {
      bool = f.O0(paramf, null, 1, null);
    } 
    f f1 = paramf.m0();
    if (bool && f1 != null)
      if (f1.Y() == null) {
        I(this, f1, false, 2, null);
      } else if (paramf.e0() == f.g.InMeasureBlock) {
        D(this, f1, false, 2, null);
      } else if (paramf.e0() == f.g.InLayoutBlock) {
        B(this, f1, false, 2, null);
      }  
    return bool;
  }
  
  public final boolean f(f paramf, dbxyzptlk.z1.b paramb) {
    boolean bool;
    if (paramb != null) {
      bool = paramf.a1(paramb);
    } else {
      bool = f.b1(paramf, null, 1, null);
    } 
    f f1 = paramf.m0();
    if (bool && f1 != null)
      if (paramf.d0() == f.g.InMeasureBlock) {
        I(this, f1, false, 2, null);
      } else if (paramf.d0() == f.g.InLayoutBlock) {
        G(this, f1, false, 2, null);
      }  
    return bool;
  }
  
  public final void g(f paramf, boolean paramBoolean) {
    if (this.b.g(paramBoolean))
      return; 
    if (this.c) {
      if (!s(paramf, paramBoolean)) {
        h(paramf, paramBoolean);
        return;
      } 
      throw new IllegalArgumentException("node not yet measured");
    } 
    throw new IllegalStateException("forceMeasureTheSubtree should be executed during the measureAndLayout pass");
  }
  
  public final void h(f paramf, boolean paramBoolean) {
    d<f> d1 = paramf.u0();
    int i = d1.p();
    if (i > 0) {
      int m;
      Object[] arrayOfObject = d1.o();
      int j = 0;
      do {
        f f1 = (f)arrayOfObject[j];
        if ((!paramBoolean && m(f1)) || (paramBoolean && n(f1))) {
          if (E.a(f1) && !paramBoolean)
            if (f1.W() && this.b.e(f1, true)) {
              w(f1, true, false);
            } else {
              g(f1, true);
            }  
          u(f1, paramBoolean);
          if (!s(f1, paramBoolean))
            h(f1, paramBoolean); 
        } 
        m = j + 1;
        j = m;
      } while (m < i);
    } 
    u(paramf, paramBoolean);
  }
  
  public final boolean i(f paramf) {
    boolean bool;
    if (paramf.b0() && m(paramf)) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public final boolean j(f paramf) {
    boolean bool;
    if (paramf.W() && n(paramf)) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public final boolean k() {
    return this.b.h();
  }
  
  public final boolean l() {
    return this.d.c();
  }
  
  public final boolean m(f paramf) {
    return (paramf.d0() == f.g.InMeasureBlock || paramf.S().r().d().k());
  }
  
  public final boolean n(f paramf) {
    f.g g1 = paramf.e0();
    f.g g2 = f.g.InMeasureBlock;
    boolean bool2 = true;
    boolean bool1 = bool2;
    if (g1 != g2) {
      dbxyzptlk.f1.b b1 = paramf.S().B();
      if (b1 != null) {
        dbxyzptlk.f1.a a = b1.d();
        if (a != null && a.k() == true)
          return bool2; 
      } 
      bool1 = false;
    } 
    return bool1;
  }
  
  public final long o() {
    if (this.c)
      return this.f; 
    throw new IllegalArgumentException("measureIteration should be only used during the measure/layout pass");
  }
  
  public final boolean p(dbxyzptlk.CI.a<D> parama) {
    if (this.a.I0()) {
      if (this.a.h()) {
        if (!this.c) {
          dbxyzptlk.z1.b b1 = this.h;
          boolean bool = false;
          if (b1 != null) {
            boolean bool1;
            this.c = true;
            try {
              if (this.b.h()) {
                dbxyzptlk.f1.k k1 = this.b;
                bool = false;
                while (k1.h()) {
                  j j;
                  boolean bool2 = dbxyzptlk.f1.k.a(k1).d();
                  if (!bool2) {
                    j = dbxyzptlk.f1.k.a(k1);
                  } else {
                    j = dbxyzptlk.f1.k.b(k1);
                  } 
                  f f1 = j.e();
                  bool2 = x(this, f1, bool2 ^ true, false, 4, null);
                  if (f1 == a(this) && bool2)
                    bool = true; 
                } 
                bool1 = bool;
                if (parama != null) {
                  parama.invoke();
                  bool1 = bool;
                } 
              } else {
                bool1 = false;
              } 
            } finally {}
            this.c = false;
            h h1 = this.i;
            if (h1 != null)
              h1.a(); 
            bool = bool1;
          } 
          b();
          return bool;
        } 
        throw new IllegalArgumentException("performMeasureAndLayout called during measure layout");
      } 
      throw new IllegalArgumentException("performMeasureAndLayout called with unplaced root");
    } 
    throw new IllegalArgumentException("performMeasureAndLayout called with unattached root");
  }
  
  public final void q(f paramf, long paramLong) {
    if (paramf.J0())
      return; 
    if (!s.c(paramf, this.a)) {
      if (this.a.I0()) {
        if (this.a.h()) {
          if (!this.c) {
            if (this.h != null) {
              this.c = true;
              try {
                this.b.i(paramf);
                boolean bool = e(paramf, dbxyzptlk.z1.b.b(paramLong));
                f(paramf, dbxyzptlk.z1.b.b(paramLong));
                if ((bool || paramf.V()) && s.c(paramf.L0(), Boolean.TRUE))
                  paramf.P0(); 
              } finally {}
              if (paramf.T() && paramf.h()) {
                paramf.e1();
                this.d.d(paramf);
              } 
              this.c = false;
              h h1 = this.i;
              if (h1 != null)
                h1.a(); 
            } 
            b();
            return;
          } 
          throw new IllegalArgumentException("performMeasureAndLayout called during measure layout");
        } 
        throw new IllegalArgumentException("performMeasureAndLayout called with unplaced root");
      } 
      throw new IllegalArgumentException("performMeasureAndLayout called with unattached root");
    } 
    throw new IllegalArgumentException("measureAndLayout called on root");
  }
  
  public final void r() {
    if (this.b.h())
      if (this.a.I0()) {
        if (this.a.h()) {
          if (!this.c) {
            if (this.h != null) {
              this.c = true;
              try {
                if (!this.b.g(true))
                  if (this.a.Y() != null) {
                    z(this.a, true);
                  } else {
                    y(this.a);
                  }  
              } finally {
                Exception exception;
              } 
              z(this.a, false);
              this.c = false;
              h h1 = this.i;
              if (h1 != null)
                h1.a(); 
            } 
          } else {
            throw new IllegalArgumentException("performMeasureAndLayout called during measure layout");
          } 
        } else {
          throw new IllegalArgumentException("performMeasureAndLayout called with unplaced root");
        } 
      } else {
        throw new IllegalArgumentException("performMeasureAndLayout called with unattached root");
      }  
  }
  
  public final boolean s(f paramf, boolean paramBoolean) {
    if (paramBoolean) {
      paramBoolean = paramf.W();
    } else {
      paramBoolean = paramf.b0();
    } 
    return paramBoolean;
  }
  
  public final void t(f paramf) {
    this.b.i(paramf);
  }
  
  public final void u(f paramf, boolean paramBoolean) {
    if (s(paramf, paramBoolean) && this.b.e(paramf, paramBoolean))
      w(paramf, paramBoolean, false); 
  }
  
  public final void v(Owner.b paramb) {
    this.e.c(paramb);
  }
  
  public final boolean w(f paramf, boolean paramBoolean1, boolean paramBoolean2) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual J0 : ()Z
    //   4: istore #8
    //   6: iconst_0
    //   7: istore #7
    //   9: iconst_0
    //   10: istore #4
    //   12: iload #8
    //   14: ifeq -> 19
    //   17: iconst_0
    //   18: ireturn
    //   19: aload_1
    //   20: invokevirtual h : ()Z
    //   23: ifne -> 69
    //   26: aload_1
    //   27: invokevirtual K0 : ()Z
    //   30: ifne -> 69
    //   33: aload_0
    //   34: aload_1
    //   35: invokevirtual i : (Landroidx/compose/ui/node/f;)Z
    //   38: ifne -> 69
    //   41: aload_1
    //   42: invokevirtual L0 : ()Ljava/lang/Boolean;
    //   45: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
    //   48: invokestatic c : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   51: ifne -> 69
    //   54: aload_0
    //   55: aload_1
    //   56: invokevirtual j : (Landroidx/compose/ui/node/f;)Z
    //   59: ifne -> 69
    //   62: aload_1
    //   63: invokevirtual B : ()Z
    //   66: ifeq -> 395
    //   69: aload_1
    //   70: invokevirtual W : ()Z
    //   73: ifne -> 95
    //   76: aload_1
    //   77: invokevirtual b0 : ()Z
    //   80: ifeq -> 86
    //   83: goto -> 95
    //   86: iconst_0
    //   87: istore #7
    //   89: iconst_0
    //   90: istore #8
    //   92: goto -> 163
    //   95: aload_1
    //   96: aload_0
    //   97: getfield a : Landroidx/compose/ui/node/f;
    //   100: if_acmpne -> 117
    //   103: aload_0
    //   104: getfield h : Ldbxyzptlk/z1/b;
    //   107: astore #10
    //   109: aload #10
    //   111: invokestatic e : (Ljava/lang/Object;)V
    //   114: goto -> 120
    //   117: aconst_null
    //   118: astore #10
    //   120: aload_1
    //   121: invokevirtual W : ()Z
    //   124: ifeq -> 143
    //   127: iload_2
    //   128: ifeq -> 143
    //   131: aload_0
    //   132: aload_1
    //   133: aload #10
    //   135: invokevirtual e : (Landroidx/compose/ui/node/f;Ldbxyzptlk/z1/b;)Z
    //   138: istore #7
    //   140: goto -> 146
    //   143: iconst_0
    //   144: istore #7
    //   146: aload_0
    //   147: aload_1
    //   148: aload #10
    //   150: invokevirtual f : (Landroidx/compose/ui/node/f;Ldbxyzptlk/z1/b;)Z
    //   153: istore #9
    //   155: iload #7
    //   157: istore #8
    //   159: iload #9
    //   161: istore #7
    //   163: iload_3
    //   164: ifeq -> 284
    //   167: iload #8
    //   169: ifne -> 179
    //   172: aload_1
    //   173: invokevirtual V : ()Z
    //   176: ifeq -> 200
    //   179: aload_1
    //   180: invokevirtual L0 : ()Ljava/lang/Boolean;
    //   183: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
    //   186: invokestatic c : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   189: ifeq -> 200
    //   192: iload_2
    //   193: ifeq -> 200
    //   196: aload_1
    //   197: invokevirtual P0 : ()V
    //   200: aload_1
    //   201: invokevirtual T : ()Z
    //   204: ifeq -> 284
    //   207: aload_1
    //   208: aload_0
    //   209: getfield a : Landroidx/compose/ui/node/f;
    //   212: if_acmpeq -> 242
    //   215: aload_1
    //   216: invokevirtual m0 : ()Landroidx/compose/ui/node/f;
    //   219: astore #10
    //   221: aload #10
    //   223: ifnull -> 284
    //   226: aload #10
    //   228: invokevirtual h : ()Z
    //   231: iconst_1
    //   232: if_icmpne -> 284
    //   235: aload_1
    //   236: invokevirtual K0 : ()Z
    //   239: ifeq -> 284
    //   242: aload_1
    //   243: aload_0
    //   244: getfield a : Landroidx/compose/ui/node/f;
    //   247: if_acmpne -> 259
    //   250: aload_1
    //   251: iconst_0
    //   252: iconst_0
    //   253: invokevirtual Y0 : (II)V
    //   256: goto -> 263
    //   259: aload_1
    //   260: invokevirtual e1 : ()V
    //   263: aload_0
    //   264: getfield d : Ldbxyzptlk/f1/Q;
    //   267: aload_1
    //   268: invokevirtual d : (Landroidx/compose/ui/node/f;)V
    //   271: aload_0
    //   272: getfield i : Landroidx/compose/ui/node/h;
    //   275: astore_1
    //   276: aload_1
    //   277: ifnull -> 284
    //   280: aload_1
    //   281: invokevirtual a : ()V
    //   284: aload_0
    //   285: getfield g : Ldbxyzptlk/z0/d;
    //   288: invokevirtual w : ()Z
    //   291: ifeq -> 395
    //   294: aload_0
    //   295: getfield g : Ldbxyzptlk/z0/d;
    //   298: astore_1
    //   299: aload_1
    //   300: invokevirtual p : ()I
    //   303: istore #6
    //   305: iload #6
    //   307: ifle -> 388
    //   310: aload_1
    //   311: invokevirtual o : ()[Ljava/lang/Object;
    //   314: astore #10
    //   316: aload #10
    //   318: iload #4
    //   320: aaload
    //   321: checkcast androidx/compose/ui/node/k$a
    //   324: astore_1
    //   325: aload_1
    //   326: invokevirtual a : ()Landroidx/compose/ui/node/f;
    //   329: invokevirtual I0 : ()Z
    //   332: ifeq -> 371
    //   335: aload_1
    //   336: invokevirtual c : ()Z
    //   339: ifne -> 358
    //   342: aload_0
    //   343: aload_1
    //   344: invokevirtual a : ()Landroidx/compose/ui/node/f;
    //   347: aload_1
    //   348: invokevirtual b : ()Z
    //   351: invokevirtual H : (Landroidx/compose/ui/node/f;Z)Z
    //   354: pop
    //   355: goto -> 371
    //   358: aload_0
    //   359: aload_1
    //   360: invokevirtual a : ()Landroidx/compose/ui/node/f;
    //   363: aload_1
    //   364: invokevirtual b : ()Z
    //   367: invokevirtual C : (Landroidx/compose/ui/node/f;Z)Z
    //   370: pop
    //   371: iload #4
    //   373: iconst_1
    //   374: iadd
    //   375: istore #5
    //   377: iload #5
    //   379: istore #4
    //   381: iload #5
    //   383: iload #6
    //   385: if_icmplt -> 316
    //   388: aload_0
    //   389: getfield g : Ldbxyzptlk/z0/d;
    //   392: invokevirtual i : ()V
    //   395: iload #7
    //   397: ireturn
  }
  
  public final void y(f paramf) {
    d<f> d1 = paramf.u0();
    int i = d1.p();
    if (i > 0) {
      int m;
      Object[] arrayOfObject = d1.o();
      int j = 0;
      do {
        f f1 = (f)arrayOfObject[j];
        if (m(f1))
          if (E.a(f1)) {
            z(f1, true);
          } else {
            y(f1);
          }  
        m = j + 1;
        j = m;
      } while (m < i);
    } 
  }
  
  public final void z(f paramf, boolean paramBoolean) {
    dbxyzptlk.z1.b b1;
    if (paramf == this.a) {
      b1 = this.h;
      s.e(b1);
    } else {
      b1 = null;
    } 
    if (paramBoolean) {
      e(paramf, b1);
    } else {
      f(paramf, b1);
    } 
  }
  
  @Metadata(d1 = {"\000\026\n\002\030\002\n\002\020\000\n\002\030\002\n\000\n\002\020\013\n\002\b\f\b\007\030\0002\0020\001B\037\022\006\020\003\032\0020\002\022\006\020\005\032\0020\004\022\006\020\006\032\0020\004¢\006\004\b\007\020\bR\027\020\003\032\0020\0028\006¢\006\f\n\004\b\t\020\n\032\004\b\t\020\013R\027\020\005\032\0020\0048\006¢\006\f\n\004\b\f\020\r\032\004\b\016\020\017R\027\020\006\032\0020\0048\006¢\006\f\n\004\b\016\020\r\032\004\b\f\020\017¨\006\020"}, d2 = {"Landroidx/compose/ui/node/k$a;", "", "Landroidx/compose/ui/node/f;", "node", "", "isLookahead", "isForced", "<init>", "(Landroidx/compose/ui/node/f;ZZ)V", "a", "Landroidx/compose/ui/node/f;", "()Landroidx/compose/ui/node/f;", "b", "Z", "c", "()Z", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class a {
    public final f a;
    
    public final boolean b;
    
    public final boolean c;
    
    public a(f param1f, boolean param1Boolean1, boolean param1Boolean2) {
      this.a = param1f;
      this.b = param1Boolean1;
      this.c = param1Boolean2;
    }
    
    public final f a() {
      return this.a;
    }
    
    public final boolean b() {
      return this.c;
    }
    
    public final boolean c() {
      return this.b;
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compos\\ui\node\k.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */