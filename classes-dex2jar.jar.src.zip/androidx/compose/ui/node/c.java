package androidx.compose.ui.node;

import dbxyzptlk.CI.p;
import dbxyzptlk.DI.u;
import dbxyzptlk.d1.G;
import dbxyzptlk.g1.K1;
import dbxyzptlk.pI.D;
import dbxyzptlk.x0.v;
import dbxyzptlk.z1.t;
import kotlin.Metadata;

@Metadata(d1 = {"\000@\n\002\030\002\n\002\020\000\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\005\n\002\020\b\n\002\b\t\ba\030\000 .2\0020\001:\001\013R\034\020\007\032\0020\0028&@&X¦\016¢\006\f\032\004\b\003\020\004\"\004\b\005\020\006R\034\020\r\032\0020\b8&@&X¦\016¢\006\f\032\004\b\t\020\n\"\004\b\013\020\fR\034\020\023\032\0020\0168&@&X¦\016¢\006\f\032\004\b\017\020\020\"\004\b\021\020\022R\034\020\031\032\0020\0248&@&X¦\016¢\006\f\032\004\b\025\020\026\"\004\b\027\020\030R\034\020\037\032\0020\0328&@&X¦\016¢\006\f\032\004\b\033\020\034\"\004\b\035\020\036R\034\020%\032\0020 8&@&X¦\016¢\006\f\032\004\b!\020\"\"\004\b#\020$R\"\020-\032\0020&8&@&X§\016¢\006\022\022\004\b+\020,\032\004\b'\020(\"\004\b)\020*ø\001\000\002\006\n\004\b!0\001¨\006/À\006\001"}, d2 = {"Landroidx/compose/ui/node/c;", "", "Ldbxyzptlk/d1/G;", "getMeasurePolicy", "()Ldbxyzptlk/d1/G;", "j", "(Ldbxyzptlk/d1/G;)V", "measurePolicy", "Ldbxyzptlk/z1/t;", "getLayoutDirection", "()Ldbxyzptlk/z1/t;", "a", "(Ldbxyzptlk/z1/t;)V", "layoutDirection", "Ldbxyzptlk/z1/d;", "getDensity", "()Ldbxyzptlk/z1/d;", "e", "(Ldbxyzptlk/z1/d;)V", "density", "Landroidx/compose/ui/d;", "getModifier", "()Landroidx/compose/ui/d;", "g", "(Landroidx/compose/ui/d;)V", "modifier", "Ldbxyzptlk/g1/K1;", "getViewConfiguration", "()Ldbxyzptlk/g1/K1;", "m", "(Ldbxyzptlk/g1/K1;)V", "viewConfiguration", "Ldbxyzptlk/x0/v;", "getCompositionLocalMap", "()Ldbxyzptlk/x0/v;", "n", "(Ldbxyzptlk/x0/v;)V", "compositionLocalMap", "", "getCompositeKeyHash", "()I", "c", "(I)V", "getCompositeKeyHash$annotations", "()V", "compositeKeyHash", "q0", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public interface c {
  public static final a q0 = a.a;
  
  void a(t paramt);
  
  void c(int paramInt);
  
  void e(dbxyzptlk.z1.d paramd);
  
  void g(androidx.compose.ui.d paramd);
  
  void j(G paramG);
  
  void m(K1 paramK1);
  
  void n(v paramv);
  
  @Metadata(d1 = {"\000X\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\030\002\n\002\b\b\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\020\b\n\002\b\004\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003R\035\020\n\032\b\022\004\022\0020\0050\0048\006¢\006\f\n\004\b\006\020\007\032\004\b\b\020\tR\035\020\r\032\b\022\004\022\0020\0050\0048\006¢\006\f\n\004\b\013\020\007\032\004\b\f\020\tR)\020\024\032\024\022\004\022\0020\005\022\004\022\0020\017\022\004\022\0020\0200\0168\006¢\006\f\n\004\b\021\020\022\032\004\b\021\020\023R)\020\030\032\024\022\004\022\0020\005\022\004\022\0020\025\022\004\022\0020\0200\0168\006¢\006\f\n\004\b\026\020\022\032\004\b\027\020\023R)\020\033\032\024\022\004\022\0020\005\022\004\022\0020\031\022\004\022\0020\0200\0168\006¢\006\f\n\004\b\032\020\022\032\004\b\026\020\023R)\020\036\032\024\022\004\022\0020\005\022\004\022\0020\034\022\004\022\0020\0200\0168\006¢\006\f\n\004\b\035\020\022\032\004\b\013\020\023R)\020\"\032\024\022\004\022\0020\005\022\004\022\0020\037\022\004\022\0020\0200\0168\006¢\006\f\n\004\b \020\022\032\004\b!\020\023R)\020&\032\024\022\004\022\0020\005\022\004\022\0020#\022\004\022\0020\0200\0168\006¢\006\f\n\004\b$\020\022\032\004\b%\020\023R2\020*\032\024\022\004\022\0020\005\022\004\022\0020'\022\004\022\0020\0200\0168GX\004¢\006\022\n\004\b(\020\022\022\004\b)\020\003\032\004\b\006\020\023¨\006+"}, d2 = {"Landroidx/compose/ui/node/c$a;", "", "<init>", "()V", "Lkotlin/Function0;", "Landroidx/compose/ui/node/c;", "b", "Ldbxyzptlk/CI/a;", "a", "()Ldbxyzptlk/CI/a;", "Constructor", "c", "getVirtualConstructor", "VirtualConstructor", "Lkotlin/Function2;", "Landroidx/compose/ui/d;", "Ldbxyzptlk/pI/D;", "d", "Ldbxyzptlk/CI/p;", "()Ldbxyzptlk/CI/p;", "SetModifier", "Ldbxyzptlk/z1/d;", "e", "getSetDensity", "SetDensity", "Ldbxyzptlk/x0/v;", "f", "SetResolvedCompositionLocals", "Ldbxyzptlk/d1/G;", "g", "SetMeasurePolicy", "Ldbxyzptlk/z1/t;", "h", "getSetLayoutDirection", "SetLayoutDirection", "Ldbxyzptlk/g1/K1;", "i", "getSetViewConfiguration", "SetViewConfiguration", "", "j", "getSetCompositeKeyHash$annotations", "SetCompositeKeyHash", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class a {
    public static final a a = new a();
    
    public static final dbxyzptlk.CI.a<c> b = (dbxyzptlk.CI.a)f.J.a();
    
    public static final dbxyzptlk.CI.a<c> c = h.f;
    
    public static final p<c, androidx.compose.ui.d, D> d = e.f;
    
    public static final p<c, dbxyzptlk.z1.d, D> e = b.f;
    
    public static final p<c, v, D> f = f.f;
    
    public static final p<c, G, D> g = d.f;
    
    public static final p<c, t, D> h = c.f;
    
    public static final p<c, K1, D> i = g.f;
    
    public static final p<c, Integer, D> j = a.f;
    
    public final dbxyzptlk.CI.a<c> a() {
      return b;
    }
    
    public final p<c, Integer, D> b() {
      return j;
    }
    
    public final p<c, G, D> c() {
      return g;
    }
    
    public final p<c, androidx.compose.ui.d, D> d() {
      return d;
    }
    
    public final p<c, v, D> e() {
      return f;
    }
    
    @Metadata(d1 = {"\000\022\n\002\030\002\n\002\020\b\n\000\n\002\030\002\n\002\b\002\020\004\032\0020\003*\0020\0002\006\020\002\032\0020\001H\n¢\006\004\b\004\020\005"}, d2 = {"Landroidx/compose/ui/node/c;", "", "it", "Ldbxyzptlk/pI/D;", "a", "(Landroidx/compose/ui/node/c;I)V"}, k = 3, mv = {1, 8, 0})
    public static final class a extends u implements p<c, Integer, D> {
      public static final a f = new a();
      
      public a() {
        super(2);
      }
      
      public final void a(c param2c, int param2Int) {
        param2c.c(param2Int);
      }
    }
    
    @Metadata(d1 = {"\000\022\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\020\004\032\0020\003*\0020\0002\006\020\002\032\0020\001H\n¢\006\004\b\004\020\005"}, d2 = {"Landroidx/compose/ui/node/c;", "Ldbxyzptlk/z1/d;", "it", "Ldbxyzptlk/pI/D;", "a", "(Landroidx/compose/ui/node/c;Ldbxyzptlk/z1/d;)V"}, k = 3, mv = {1, 8, 0})
    public static final class b extends u implements p<c, dbxyzptlk.z1.d, D> {
      public static final b f = new b();
      
      public b() {
        super(2);
      }
      
      public final void a(c param2c, dbxyzptlk.z1.d param2d) {
        param2c.e(param2d);
      }
    }
    
    @Metadata(d1 = {"\000\022\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\020\004\032\0020\003*\0020\0002\006\020\002\032\0020\001H\n¢\006\004\b\004\020\005"}, d2 = {"Landroidx/compose/ui/node/c;", "Ldbxyzptlk/z1/t;", "it", "Ldbxyzptlk/pI/D;", "a", "(Landroidx/compose/ui/node/c;Ldbxyzptlk/z1/t;)V"}, k = 3, mv = {1, 8, 0})
    public static final class c extends u implements p<c, t, D> {
      public static final c f = new c();
      
      public c() {
        super(2);
      }
      
      public final void a(c param2c, t param2t) {
        param2c.a(param2t);
      }
    }
    
    @Metadata(d1 = {"\000\022\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\020\004\032\0020\003*\0020\0002\006\020\002\032\0020\001H\n¢\006\004\b\004\020\005"}, d2 = {"Landroidx/compose/ui/node/c;", "Ldbxyzptlk/d1/G;", "it", "Ldbxyzptlk/pI/D;", "a", "(Landroidx/compose/ui/node/c;Ldbxyzptlk/d1/G;)V"}, k = 3, mv = {1, 8, 0})
    public static final class d extends u implements p<c, G, D> {
      public static final d f = new d();
      
      public d() {
        super(2);
      }
      
      public final void a(c param2c, G param2G) {
        param2c.j(param2G);
      }
    }
    
    @Metadata(d1 = {"\000\022\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\020\004\032\0020\003*\0020\0002\006\020\002\032\0020\001H\n¢\006\004\b\004\020\005"}, d2 = {"Landroidx/compose/ui/node/c;", "Landroidx/compose/ui/d;", "it", "Ldbxyzptlk/pI/D;", "a", "(Landroidx/compose/ui/node/c;Landroidx/compose/ui/d;)V"}, k = 3, mv = {1, 8, 0})
    public static final class e extends u implements p<c, androidx.compose.ui.d, D> {
      public static final e f = new e();
      
      public e() {
        super(2);
      }
      
      public final void a(c param2c, androidx.compose.ui.d param2d) {
        param2c.g(param2d);
      }
    }
    
    @Metadata(d1 = {"\000\022\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\020\004\032\0020\003*\0020\0002\006\020\002\032\0020\001H\n¢\006\004\b\004\020\005"}, d2 = {"Landroidx/compose/ui/node/c;", "Ldbxyzptlk/x0/v;", "it", "Ldbxyzptlk/pI/D;", "a", "(Landroidx/compose/ui/node/c;Ldbxyzptlk/x0/v;)V"}, k = 3, mv = {1, 8, 0})
    public static final class f extends u implements p<c, v, D> {
      public static final f f = new f();
      
      public f() {
        super(2);
      }
      
      public final void a(c param2c, v param2v) {
        param2c.n(param2v);
      }
    }
    
    @Metadata(d1 = {"\000\022\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\020\004\032\0020\003*\0020\0002\006\020\002\032\0020\001H\n¢\006\004\b\004\020\005"}, d2 = {"Landroidx/compose/ui/node/c;", "Ldbxyzptlk/g1/K1;", "it", "Ldbxyzptlk/pI/D;", "a", "(Landroidx/compose/ui/node/c;Ldbxyzptlk/g1/K1;)V"}, k = 3, mv = {1, 8, 0})
    public static final class g extends u implements p<c, K1, D> {
      public static final g f = new g();
      
      public g() {
        super(2);
      }
      
      public final void a(c param2c, K1 param2K1) {
        param2c.m(param2K1);
      }
    }
    
    @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"Landroidx/compose/ui/node/f;", "b", "()Landroidx/compose/ui/node/f;"}, k = 3, mv = {1, 8, 0})
    public static final class h extends u implements dbxyzptlk.CI.a<f> {
      public static final h f = new h();
      
      public h() {
        super(0);
      }
      
      public final f b() {
        return new f(true, 0, 2, null);
      }
    }
  }
  
  @Metadata(d1 = {"\000\022\n\002\030\002\n\002\020\b\n\000\n\002\030\002\n\002\b\002\020\004\032\0020\003*\0020\0002\006\020\002\032\0020\001H\n¢\006\004\b\004\020\005"}, d2 = {"Landroidx/compose/ui/node/c;", "", "it", "Ldbxyzptlk/pI/D;", "a", "(Landroidx/compose/ui/node/c;I)V"}, k = 3, mv = {1, 8, 0})
  public static final class a extends u implements p<c, Integer, D> {
    public static final a f = new a();
    
    public a() {
      super(2);
    }
    
    public final void a(c param1c, int param1Int) {
      param1c.c(param1Int);
    }
  }
  
  @Metadata(d1 = {"\000\022\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\020\004\032\0020\003*\0020\0002\006\020\002\032\0020\001H\n¢\006\004\b\004\020\005"}, d2 = {"Landroidx/compose/ui/node/c;", "Ldbxyzptlk/z1/d;", "it", "Ldbxyzptlk/pI/D;", "a", "(Landroidx/compose/ui/node/c;Ldbxyzptlk/z1/d;)V"}, k = 3, mv = {1, 8, 0})
  public static final class b extends u implements p<c, dbxyzptlk.z1.d, D> {
    public static final b f = new b();
    
    public b() {
      super(2);
    }
    
    public final void a(c param1c, dbxyzptlk.z1.d param1d) {
      param1c.e(param1d);
    }
  }
  
  @Metadata(d1 = {"\000\022\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\020\004\032\0020\003*\0020\0002\006\020\002\032\0020\001H\n¢\006\004\b\004\020\005"}, d2 = {"Landroidx/compose/ui/node/c;", "Ldbxyzptlk/z1/t;", "it", "Ldbxyzptlk/pI/D;", "a", "(Landroidx/compose/ui/node/c;Ldbxyzptlk/z1/t;)V"}, k = 3, mv = {1, 8, 0})
  public static final class c extends u implements p<c, t, D> {
    public static final c f = new c();
    
    public c() {
      super(2);
    }
    
    public final void a(c param1c, t param1t) {
      param1c.a(param1t);
    }
  }
  
  @Metadata(d1 = {"\000\022\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\020\004\032\0020\003*\0020\0002\006\020\002\032\0020\001H\n¢\006\004\b\004\020\005"}, d2 = {"Landroidx/compose/ui/node/c;", "Ldbxyzptlk/d1/G;", "it", "Ldbxyzptlk/pI/D;", "a", "(Landroidx/compose/ui/node/c;Ldbxyzptlk/d1/G;)V"}, k = 3, mv = {1, 8, 0})
  public static final class d extends u implements p<c, G, D> {
    public static final d f = new d();
    
    public d() {
      super(2);
    }
    
    public final void a(c param1c, G param1G) {
      param1c.j(param1G);
    }
  }
  
  @Metadata(d1 = {"\000\022\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\020\004\032\0020\003*\0020\0002\006\020\002\032\0020\001H\n¢\006\004\b\004\020\005"}, d2 = {"Landroidx/compose/ui/node/c;", "Landroidx/compose/ui/d;", "it", "Ldbxyzptlk/pI/D;", "a", "(Landroidx/compose/ui/node/c;Landroidx/compose/ui/d;)V"}, k = 3, mv = {1, 8, 0})
  public static final class e extends u implements p<c, androidx.compose.ui.d, D> {
    public static final e f = new e();
    
    public e() {
      super(2);
    }
    
    public final void a(c param1c, androidx.compose.ui.d param1d) {
      param1c.g(param1d);
    }
  }
  
  @Metadata(d1 = {"\000\022\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\020\004\032\0020\003*\0020\0002\006\020\002\032\0020\001H\n¢\006\004\b\004\020\005"}, d2 = {"Landroidx/compose/ui/node/c;", "Ldbxyzptlk/x0/v;", "it", "Ldbxyzptlk/pI/D;", "a", "(Landroidx/compose/ui/node/c;Ldbxyzptlk/x0/v;)V"}, k = 3, mv = {1, 8, 0})
  public static final class f extends u implements p<c, v, D> {
    public static final f f = new f();
    
    public f() {
      super(2);
    }
    
    public final void a(c param1c, v param1v) {
      param1c.n(param1v);
    }
  }
  
  @Metadata(d1 = {"\000\022\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\020\004\032\0020\003*\0020\0002\006\020\002\032\0020\001H\n¢\006\004\b\004\020\005"}, d2 = {"Landroidx/compose/ui/node/c;", "Ldbxyzptlk/g1/K1;", "it", "Ldbxyzptlk/pI/D;", "a", "(Landroidx/compose/ui/node/c;Ldbxyzptlk/g1/K1;)V"}, k = 3, mv = {1, 8, 0})
  public static final class g extends u implements p<c, K1, D> {
    public static final g f = new g();
    
    public g() {
      super(2);
    }
    
    public final void a(c param1c, K1 param1K1) {
      param1c.m(param1K1);
    }
  }
  
  @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"Landroidx/compose/ui/node/f;", "b", "()Landroidx/compose/ui/node/f;"}, k = 3, mv = {1, 8, 0})
  public static final class h extends u implements dbxyzptlk.CI.a<f> {
    public static final h f = new h();
    
    public h() {
      super(0);
    }
    
    public final f b() {
      return new f(true, 0, 2, null);
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compos\\ui\node\c.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */