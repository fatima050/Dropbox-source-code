package androidx.compose.ui.node;

import androidx.compose.ui.d;
import androidx.compose.ui.graphics.c;
import dbxyzptlk.CI.l;
import dbxyzptlk.DI.s;
import dbxyzptlk.Q0.L0;
import dbxyzptlk.Q0.M0;
import dbxyzptlk.Q0.O;
import dbxyzptlk.Q0.j0;
import dbxyzptlk.Q0.r0;
import dbxyzptlk.d1.H;
import dbxyzptlk.d1.I;
import dbxyzptlk.d1.Y;
import dbxyzptlk.d1.l;
import dbxyzptlk.d1.m;
import dbxyzptlk.d1.n;
import dbxyzptlk.f1.D;
import dbxyzptlk.f1.w;
import dbxyzptlk.f1.x;
import dbxyzptlk.pI.D;
import dbxyzptlk.z1.b;
import dbxyzptlk.z1.s;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

@Metadata(d1 = {"\000l\n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\020\b\n\002\b\007\n\002\030\002\n\000\n\002\020\007\n\000\n\002\030\002\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\016\n\002\030\002\n\002\b\007\n\002\030\002\n\002\b\n\b\000\030\000 C2\0020\001:\002DEB\027\022\006\020\003\032\0020\002\022\006\020\005\032\0020\004¢\006\004\b\006\020\007J\017\020\t\032\0020\bH\026¢\006\004\b\t\020\nJ\032\020\016\032\0020\r2\006\020\f\032\0020\013H\026ø\001\000¢\006\004\b\016\020\017J\027\020\022\032\0020\0202\006\020\021\032\0020\020H\026¢\006\004\b\022\020\023J\027\020\024\032\0020\0202\006\020\021\032\0020\020H\026¢\006\004\b\024\020\023J\027\020\026\032\0020\0202\006\020\025\032\0020\020H\026¢\006\004\b\026\020\023J\027\020\027\032\0020\0202\006\020\025\032\0020\020H\026¢\006\004\b\027\020\023J8\020\037\032\0020\b2\006\020\031\032\0020\0302\006\020\033\032\0020\0322\024\020\036\032\020\022\004\022\0020\035\022\004\022\0020\b\030\0010\034H\024ø\001\000¢\006\004\b\037\020 J\027\020#\032\0020\0202\006\020\"\032\0020!H\026¢\006\004\b#\020$J\027\020'\032\0020\b2\006\020&\032\0020%H\026¢\006\004\b'\020(R*\0200\032\0020\0042\006\020)\032\0020\0048\006@@X\016¢\006\022\n\004\b*\020+\032\004\b,\020-\"\004\b.\020/R\036\0203\032\004\030\0010\0138\002@\002X\016ø\001\000ø\001\001¢\006\006\n\004\b1\0202R.\020;\032\004\030\001042\b\020)\032\004\030\001048\026@TX\016¢\006\022\n\004\b5\0206\032\004\b7\0208\"\004\b9\020:R\024\020?\032\0020<8VX\004¢\006\006\032\004\b=\020>R\021\020B\032\0020\0018F¢\006\006\032\004\b@\020A\002\013\n\005\b¡\0360\001\n\002\b!¨\006F"}, d2 = {"Landroidx/compose/ui/node/e;", "Landroidx/compose/ui/node/n;", "Landroidx/compose/ui/node/f;", "layoutNode", "Ldbxyzptlk/f1/w;", "measureNode", "<init>", "(Landroidx/compose/ui/node/f;Ldbxyzptlk/f1/w;)V", "Ldbxyzptlk/pI/D;", "a2", "()V", "Ldbxyzptlk/z1/b;", "constraints", "Ldbxyzptlk/d1/Y;", "d0", "(J)Ldbxyzptlk/d1/Y;", "", "height", "S", "(I)I", "U", "width", "N", "x", "Ldbxyzptlk/z1/n;", "position", "", "zIndex", "Lkotlin/Function1;", "Landroidx/compose/ui/graphics/c;", "layerBlock", "T0", "(JFLdbxyzptlk/CI/l;)V", "Ldbxyzptlk/d1/a;", "alignmentLine", "e1", "(Ldbxyzptlk/d1/a;)I", "Ldbxyzptlk/Q0/j0;", "canvas", "K2", "(Ldbxyzptlk/Q0/j0;)V", "<set-?>", "J", "Ldbxyzptlk/f1/w;", "h3", "()Ldbxyzptlk/f1/w;", "j3", "(Ldbxyzptlk/f1/w;)V", "layoutModifierNode", "K", "Ldbxyzptlk/z1/b;", "lookaheadConstraints", "Landroidx/compose/ui/node/j;", "L", "Landroidx/compose/ui/node/j;", "k2", "()Landroidx/compose/ui/node/j;", "k3", "(Landroidx/compose/ui/node/j;)V", "lookaheadDelegate", "Landroidx/compose/ui/d$c;", "o2", "()Landroidx/compose/ui/d$c;", "tail", "i3", "()Landroidx/compose/ui/node/n;", "wrappedNonNull", "M", "a", "b", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class e extends n {
  public static final a M = new a(null);
  
  public static final L0 N;
  
  public w J;
  
  public b K;
  
  public j L;
  
  static {
    L0 l0 = O.a();
    l0.g(r0.b.b());
    l0.o(1.0F);
    l0.m(M0.a.b());
    N = l0;
  }
  
  public e(f paramf, w paramw) {
    super(paramf);
    this.J = paramw;
    if (paramf.Y() != null) {
      b b1 = new b(this);
    } else {
      paramf = null;
    } 
    this.L = (j)paramf;
  }
  
  public void K2(j0 paramj0) {
    i3().X1(paramj0);
    if (D.b(j2()).getShowLayoutBounds())
      Y1(paramj0, N); 
  }
  
  public int N(int paramInt) {
    l l;
    w w1 = this.J;
    if (w1 instanceof l) {
      l = (l)w1;
    } else {
      l = null;
    } 
    if (l != null) {
      paramInt = l.p2((n)this, (m)i3(), paramInt);
    } else {
      paramInt = w1.u((n)this, (m)i3(), paramInt);
    } 
    return paramInt;
  }
  
  public int S(int paramInt) {
    l l;
    w w1 = this.J;
    if (w1 instanceof l) {
      l = (l)w1;
    } else {
      l = null;
    } 
    if (l != null) {
      paramInt = l.q2((n)this, (m)i3(), paramInt);
    } else {
      paramInt = w1.l((n)this, (m)i3(), paramInt);
    } 
    return paramInt;
  }
  
  public void T0(long paramLong, float paramFloat, l<? super c, D> paraml) {
    super.T0(paramLong, paramFloat, paraml);
    if (t1())
      return; 
    I2();
    h1().f();
  }
  
  public int U(int paramInt) {
    l l;
    w w1 = this.J;
    if (w1 instanceof l) {
      l = (l)w1;
    } else {
      l = null;
    } 
    if (l != null) {
      paramInt = l.o2((n)this, (m)i3(), paramInt);
    } else {
      paramInt = w1.j((n)this, (m)i3(), paramInt);
    } 
    return paramInt;
  }
  
  public void a2() {
    if (k2() == null)
      k3((j)new b(this)); 
  }
  
  public Y d0(long paramLong) {
    H h;
    n.R1((n)this, paramLong);
    w w1 = h3();
    if (w1 instanceof l) {
      l l1 = (l)w1;
      n n1 = i3();
      j j1 = k2();
      s.e(j1);
      H h1 = j1.h1();
      long l = s.a(h1.getWidth(), h1.getHeight());
      b b1 = f3(this);
      s.e(b1);
      h = l1.m2((I)this, n1, paramLong, l, b1.t());
    } else {
      h = h.d((I)this, i3(), paramLong);
    } 
    P2(h);
    H2();
    return (Y)this;
  }
  
  public int e1(dbxyzptlk.d1.a parama) {
    int i;
    j j1 = k2();
    if (j1 != null) {
      i = j1.I1(parama);
    } else {
      i = x.a((i)this, parama);
    } 
    return i;
  }
  
  public final w h3() {
    return this.J;
  }
  
  public final n i3() {
    n n1 = p2();
    s.e(n1);
    return n1;
  }
  
  public final void j3(w paramw) {
    this.J = paramw;
  }
  
  public j k2() {
    return this.L;
  }
  
  public void k3(j paramj) {
    this.L = paramj;
  }
  
  public d.c o2() {
    return this.J.Q0();
  }
  
  public int x(int paramInt) {
    l l;
    w w1 = this.J;
    if (w1 instanceof l) {
      l = (l)w1;
    } else {
      l = null;
    } 
    if (l != null) {
      paramInt = l.n2((n)this, (m)i3(), paramInt);
    } else {
      paramInt = w1.r((n)this, (m)i3(), paramInt);
    } 
    return paramInt;
  }
  
  @Metadata(d1 = {"\000\f\n\002\030\002\n\002\020\000\n\002\b\003\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003¨\006\004"}, d2 = {"Landroidx/compose/ui/node/e$a;", "", "<init>", "()V", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class a {
    public a() {}
  }
  
  class e {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compos\\ui\node\e.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */