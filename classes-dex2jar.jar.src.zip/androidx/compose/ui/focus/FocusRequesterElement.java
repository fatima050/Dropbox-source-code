package androidx.compose.ui.focus;

import androidx.compose.ui.d;
import dbxyzptlk.DI.s;
import dbxyzptlk.O0.o;
import dbxyzptlk.f1.G;
import kotlin.Metadata;

@Metadata(d1 = {"\000:\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\006\n\002\030\002\n\002\b\002\n\002\020\016\n\002\b\002\n\002\020\b\n\002\b\002\n\002\020\000\n\000\n\002\020\013\n\002\b\007\b\b\030\0002\b\022\004\022\0020\0020\001B\017\022\006\020\004\032\0020\003¢\006\004\b\005\020\006J\017\020\007\032\0020\002H\026¢\006\004\b\007\020\bJ\027\020\013\032\0020\n2\006\020\t\032\0020\002H\026¢\006\004\b\013\020\fJ\020\020\016\032\0020\rHÖ\001¢\006\004\b\016\020\017J\020\020\021\032\0020\020HÖ\001¢\006\004\b\021\020\022J\032\020\026\032\0020\0252\b\020\024\032\004\030\0010\023HÖ\003¢\006\004\b\026\020\027R\027\020\004\032\0020\0038\006¢\006\f\n\004\b\030\020\031\032\004\b\032\020\033¨\006\034"}, d2 = {"Landroidx/compose/ui/focus/FocusRequesterElement;", "Ldbxyzptlk/f1/G;", "Ldbxyzptlk/O0/o;", "Landroidx/compose/ui/focus/g;", "focusRequester", "<init>", "(Landroidx/compose/ui/focus/g;)V", "i", "()Ldbxyzptlk/O0/o;", "node", "Ldbxyzptlk/pI/D;", "k", "(Ldbxyzptlk/O0/o;)V", "", "toString", "()Ljava/lang/String;", "", "hashCode", "()I", "", "other", "", "equals", "(Ljava/lang/Object;)Z", "b", "Landroidx/compose/ui/focus/g;", "getFocusRequester", "()Landroidx/compose/ui/focus/g;", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
final class FocusRequesterElement extends G<o> {
  public final g b;
  
  public FocusRequesterElement(g paramg) {
    this.b = paramg;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof FocusRequesterElement))
      return false; 
    paramObject = paramObject;
    return !!s.c(this.b, ((FocusRequesterElement)paramObject).b);
  }
  
  public int hashCode() {
    return this.b.hashCode();
  }
  
  public o i() {
    return new o(this.b);
  }
  
  public void k(o paramo) {
    paramo.k2().d().A(paramo);
    paramo.l2(this.b);
    paramo.k2().d().c(paramo);
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("FocusRequesterElement(focusRequester=");
    stringBuilder.append(this.b);
    stringBuilder.append(')');
    return stringBuilder.toString();
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compos\\ui\focus\FocusRequesterElement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */