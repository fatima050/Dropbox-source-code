package androidx.compose.ui.focus;

import android.view.KeyEvent;
import androidx.compose.ui.d;
import dbxyzptlk.CI.l;
import dbxyzptlk.DI.G;
import dbxyzptlk.DI.s;
import dbxyzptlk.O0.d;
import dbxyzptlk.O0.f;
import dbxyzptlk.O0.j;
import dbxyzptlk.O0.k;
import dbxyzptlk.O0.q;
import dbxyzptlk.O0.u;
import dbxyzptlk.P0.h;
import dbxyzptlk.V.u;
import dbxyzptlk.Y0.c;
import dbxyzptlk.Y0.d;
import dbxyzptlk.c1.c;
import dbxyzptlk.f1.G;
import dbxyzptlk.f1.K;
import dbxyzptlk.f1.g;
import dbxyzptlk.pI.D;
import dbxyzptlk.z1.t;
import kotlin.Metadata;
import kotlin.NoWhenBranchMatchedException;

@Metadata(d1 = {"\000\001\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\006\n\002\020\013\n\002\b\006\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\030\002\n\002\b\n\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\003\b\000\030\0002\0020\001B!\022\030\020\005\032\024\022\n\022\b\022\004\022\0020\0040\003\022\004\022\0020\0040\002¢\006\004\b\006\020\007J\017\020\b\032\0020\004H\026¢\006\004\b\b\020\tJ\017\020\n\032\0020\004H\026¢\006\004\b\n\020\tJ\027\020\r\032\0020\0042\006\020\f\032\0020\013H\026¢\006\004\b\r\020\016J\037\020\020\032\0020\0042\006\020\f\032\0020\0132\006\020\017\032\0020\013H\026¢\006\004\b\020\020\021J\032\020\024\032\0020\0132\006\020\023\032\0020\022H\026ø\001\000¢\006\004\b\024\020\025J\032\020\030\032\0020\0132\006\020\027\032\0020\026H\026ø\001\000¢\006\004\b\030\020\031J\032\020\032\032\0020\0132\006\020\027\032\0020\026H\026ø\001\000¢\006\004\b\032\020\031J\027\020\035\032\0020\0132\006\020\034\032\0020\033H\026¢\006\004\b\035\020\036J\027\020!\032\0020\0042\006\020 \032\0020\037H\026¢\006\004\b!\020\"J\027\020$\032\0020\0042\006\020 \032\0020#H\026¢\006\004\b$\020%J\027\020'\032\0020\0042\006\020 \032\0020&H\026¢\006\004\b'\020(J\021\020*\032\004\030\0010)H\026¢\006\004\b*\020+J\025\020.\032\004\030\0010-*\0020,H\002¢\006\004\b.\020/J\032\0200\032\0020\0132\006\020\023\032\0020\022H\002ø\001\000¢\006\004\b0\020\025J\032\0201\032\0020\0132\006\020\027\032\0020\026H\002ø\001\000¢\006\004\b1\020\031R\"\0207\032\0020\0378\000@\000X\016¢\006\022\n\004\b2\0203\032\004\b4\0205\"\004\b6\020\"R\024\020:\032\002088\002X\004¢\006\006\n\004\b\b\0209R\032\020?\032\0020;8\026X\004¢\006\f\n\004\b<\020=\032\004\b<\020>R\032\020D\032\0020@8\026X\004¢\006\f\n\004\b\032\020A\032\004\bB\020CR\"\020J\032\0020E8\026@\026X.¢\006\022\n\004\b$\020F\032\004\bG\020H\"\004\b2\020IR\030\020M\032\004\030\0010K8\002@\002X\016¢\006\006\n\004\bB\020L\002\007\n\005\b¡\0360\001¨\006N"}, d2 = {"Landroidx/compose/ui/focus/FocusOwnerImpl;", "Ldbxyzptlk/O0/j;", "Lkotlin/Function1;", "Lkotlin/Function0;", "Ldbxyzptlk/pI/D;", "onRequestApplyChangesListener", "<init>", "(Ldbxyzptlk/CI/l;)V", "b", "()V", "o", "", "force", "p", "(Z)V", "refreshFocusEvents", "i", "(ZZ)V", "Landroidx/compose/ui/focus/c;", "focusDirection", "l", "(I)Z", "Ldbxyzptlk/Y0/b;", "keyEvent", "h", "(Landroid/view/KeyEvent;)Z", "d", "Ldbxyzptlk/c1/c;", "event", "j", "(Ldbxyzptlk/c1/c;)Z", "Landroidx/compose/ui/focus/FocusTargetNode;", "node", "m", "(Landroidx/compose/ui/focus/FocusTargetNode;)V", "Ldbxyzptlk/O0/d;", "e", "(Ldbxyzptlk/O0/d;)V", "Ldbxyzptlk/O0/k;", "g", "(Ldbxyzptlk/O0/k;)V", "Ldbxyzptlk/P0/h;", "n", "()Ldbxyzptlk/P0/h;", "Ldbxyzptlk/f1/g;", "Landroidx/compose/ui/d$c;", "s", "(Ldbxyzptlk/f1/g;)Landroidx/compose/ui/d$c;", "u", "t", "a", "Landroidx/compose/ui/focus/FocusTargetNode;", "r", "()Landroidx/compose/ui/focus/FocusTargetNode;", "setRootFocusNode$ui_release", "rootFocusNode", "Ldbxyzptlk/O0/f;", "Ldbxyzptlk/O0/f;", "focusInvalidationManager", "Ldbxyzptlk/O0/u;", "c", "Ldbxyzptlk/O0/u;", "()Ldbxyzptlk/O0/u;", "focusTransactionManager", "Landroidx/compose/ui/d;", "Landroidx/compose/ui/d;", "f", "()Landroidx/compose/ui/d;", "modifier", "Ldbxyzptlk/z1/t;", "Ldbxyzptlk/z1/t;", "q", "()Ldbxyzptlk/z1/t;", "(Ldbxyzptlk/z1/t;)V", "layoutDirection", "Ldbxyzptlk/V/u;", "Ldbxyzptlk/V/u;", "keysCurrentlyDown", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class FocusOwnerImpl implements j {
  public FocusTargetNode a = new FocusTargetNode();
  
  public final f b;
  
  public final u c;
  
  public final d d;
  
  public t e;
  
  public u f;
  
  public FocusOwnerImpl(l<? super dbxyzptlk.CI.a<D>, D> paraml) {
    this.b = new f(paraml);
    this.c = new u();
    this.d = (d)new FocusOwnerImpl$modifier$1(this);
  }
  
  public void a(t paramt) {
    this.e = paramt;
  }
  
  public void b() {
    if (this.a.r2() == q.Inactive)
      this.a.u2(q.Active); 
  }
  
  public u c() {
    return this.c;
  }
  
  public boolean d(KeyEvent paramKeyEvent) {
    // Byte code:
    //   0: aload_0
    //   1: getfield a : Landroidx/compose/ui/focus/FocusTargetNode;
    //   4: invokestatic b : (Landroidx/compose/ui/focus/FocusTargetNode;)Landroidx/compose/ui/focus/FocusTargetNode;
    //   7: astore #6
    //   9: aload #6
    //   11: ifnull -> 382
    //   14: ldc 131072
    //   16: invokestatic a : (I)I
    //   19: istore #4
    //   21: aload #6
    //   23: invokeinterface Q0 : ()Landroidx/compose/ui/d$c;
    //   28: invokevirtual R1 : ()Z
    //   31: ifeq -> 372
    //   34: aload #6
    //   36: invokeinterface Q0 : ()Landroidx/compose/ui/d$c;
    //   41: invokevirtual O1 : ()Landroidx/compose/ui/d$c;
    //   44: astore #5
    //   46: aload #6
    //   48: invokestatic k : (Ldbxyzptlk/f1/g;)Landroidx/compose/ui/node/f;
    //   51: astore #10
    //   53: aload #10
    //   55: ifnull -> 359
    //   58: aload #10
    //   60: invokevirtual i0 : ()Landroidx/compose/ui/node/l;
    //   63: invokevirtual k : ()Landroidx/compose/ui/d$c;
    //   66: invokevirtual H1 : ()I
    //   69: iload #4
    //   71: iand
    //   72: ifeq -> 319
    //   75: aload #5
    //   77: astore #7
    //   79: aload #7
    //   81: ifnull -> 319
    //   84: aload #7
    //   86: invokevirtual M1 : ()I
    //   89: iload #4
    //   91: iand
    //   92: ifeq -> 309
    //   95: aconst_null
    //   96: astore #5
    //   98: aload #7
    //   100: astore #6
    //   102: aload #6
    //   104: ifnull -> 309
    //   107: aload #6
    //   109: instanceof dbxyzptlk/Y0/h
    //   112: ifeq -> 118
    //   115: goto -> 362
    //   118: aload #5
    //   120: astore #8
    //   122: aload #6
    //   124: invokevirtual M1 : ()I
    //   127: iload #4
    //   129: iand
    //   130: ifeq -> 295
    //   133: aload #5
    //   135: astore #8
    //   137: aload #6
    //   139: instanceof dbxyzptlk/f1/i
    //   142: ifeq -> 295
    //   145: aload #6
    //   147: checkcast dbxyzptlk/f1/i
    //   150: invokevirtual l2 : ()Landroidx/compose/ui/d$c;
    //   153: astore #8
    //   155: iconst_0
    //   156: istore_3
    //   157: aload #8
    //   159: ifnull -> 283
    //   162: aload #6
    //   164: astore #9
    //   166: aload #5
    //   168: astore #11
    //   170: iload_3
    //   171: istore_2
    //   172: aload #8
    //   174: invokevirtual M1 : ()I
    //   177: iload #4
    //   179: iand
    //   180: ifeq -> 263
    //   183: iload_3
    //   184: iconst_1
    //   185: iadd
    //   186: istore_2
    //   187: iload_2
    //   188: iconst_1
    //   189: if_icmpne -> 203
    //   192: aload #8
    //   194: astore #9
    //   196: aload #5
    //   198: astore #11
    //   200: goto -> 263
    //   203: aload #5
    //   205: astore #9
    //   207: aload #5
    //   209: ifnonnull -> 227
    //   212: new dbxyzptlk/z0/d
    //   215: dup
    //   216: bipush #16
    //   218: anewarray androidx/compose/ui/d$c
    //   221: iconst_0
    //   222: invokespecial <init> : ([Ljava/lang/Object;I)V
    //   225: astore #9
    //   227: aload #6
    //   229: astore #5
    //   231: aload #6
    //   233: ifnull -> 247
    //   236: aload #9
    //   238: aload #6
    //   240: invokevirtual c : (Ljava/lang/Object;)Z
    //   243: pop
    //   244: aconst_null
    //   245: astore #5
    //   247: aload #9
    //   249: aload #8
    //   251: invokevirtual c : (Ljava/lang/Object;)Z
    //   254: pop
    //   255: aload #9
    //   257: astore #11
    //   259: aload #5
    //   261: astore #9
    //   263: aload #8
    //   265: invokevirtual I1 : ()Landroidx/compose/ui/d$c;
    //   268: astore #8
    //   270: aload #9
    //   272: astore #6
    //   274: aload #11
    //   276: astore #5
    //   278: iload_2
    //   279: istore_3
    //   280: goto -> 157
    //   283: aload #5
    //   285: astore #8
    //   287: iload_3
    //   288: iconst_1
    //   289: if_icmpne -> 295
    //   292: goto -> 102
    //   295: aload #8
    //   297: invokestatic b : (Ldbxyzptlk/z0/d;)Landroidx/compose/ui/d$c;
    //   300: astore #6
    //   302: aload #8
    //   304: astore #5
    //   306: goto -> 102
    //   309: aload #7
    //   311: invokevirtual O1 : ()Landroidx/compose/ui/d$c;
    //   314: astore #7
    //   316: goto -> 79
    //   319: aload #10
    //   321: invokevirtual m0 : ()Landroidx/compose/ui/node/f;
    //   324: astore #10
    //   326: aload #10
    //   328: ifnull -> 353
    //   331: aload #10
    //   333: invokevirtual i0 : ()Landroidx/compose/ui/node/l;
    //   336: astore #5
    //   338: aload #5
    //   340: ifnull -> 353
    //   343: aload #5
    //   345: invokevirtual p : ()Landroidx/compose/ui/d$c;
    //   348: astore #5
    //   350: goto -> 53
    //   353: aconst_null
    //   354: astore #5
    //   356: goto -> 53
    //   359: aconst_null
    //   360: astore #6
    //   362: aload #6
    //   364: checkcast dbxyzptlk/Y0/h
    //   367: astore #11
    //   369: goto -> 385
    //   372: new java/lang/IllegalStateException
    //   375: dup
    //   376: ldc 'visitAncestors called on an unattached node'
    //   378: invokespecial <init> : (Ljava/lang/String;)V
    //   381: athrow
    //   382: aconst_null
    //   383: astore #11
    //   385: aload #11
    //   387: ifnull -> 1409
    //   390: ldc 131072
    //   392: invokestatic a : (I)I
    //   395: istore #4
    //   397: aload #11
    //   399: invokeinterface Q0 : ()Landroidx/compose/ui/d$c;
    //   404: invokevirtual R1 : ()Z
    //   407: ifeq -> 1399
    //   410: aload #11
    //   412: invokeinterface Q0 : ()Landroidx/compose/ui/d$c;
    //   417: invokevirtual O1 : ()Landroidx/compose/ui/d$c;
    //   420: astore #6
    //   422: aload #11
    //   424: invokestatic k : (Ldbxyzptlk/f1/g;)Landroidx/compose/ui/node/f;
    //   427: astore #12
    //   429: aconst_null
    //   430: astore #7
    //   432: aload #12
    //   434: ifnull -> 822
    //   437: aload #7
    //   439: astore #8
    //   441: aload #12
    //   443: invokevirtual i0 : ()Landroidx/compose/ui/node/l;
    //   446: invokevirtual k : ()Landroidx/compose/ui/d$c;
    //   449: invokevirtual H1 : ()I
    //   452: iload #4
    //   454: iand
    //   455: ifeq -> 774
    //   458: aload #7
    //   460: astore #5
    //   462: aload #6
    //   464: astore #7
    //   466: aload #5
    //   468: astore #8
    //   470: aload #7
    //   472: ifnull -> 774
    //   475: aload #5
    //   477: astore #8
    //   479: aload #7
    //   481: invokevirtual M1 : ()I
    //   484: iload #4
    //   486: iand
    //   487: ifeq -> 760
    //   490: aload #7
    //   492: astore #9
    //   494: aconst_null
    //   495: astore #6
    //   497: aload #5
    //   499: astore #8
    //   501: aload #9
    //   503: ifnull -> 760
    //   506: aload #9
    //   508: instanceof dbxyzptlk/Y0/h
    //   511: ifeq -> 553
    //   514: aload #5
    //   516: astore #8
    //   518: aload #5
    //   520: ifnonnull -> 532
    //   523: new java/util/ArrayList
    //   526: dup
    //   527: invokespecial <init> : ()V
    //   530: astore #8
    //   532: aload #8
    //   534: aload #9
    //   536: invokeinterface add : (Ljava/lang/Object;)Z
    //   541: pop
    //   542: aload #8
    //   544: astore #10
    //   546: aload #6
    //   548: astore #8
    //   550: goto -> 742
    //   553: aload #5
    //   555: astore #10
    //   557: aload #6
    //   559: astore #8
    //   561: aload #9
    //   563: invokevirtual M1 : ()I
    //   566: iload #4
    //   568: iand
    //   569: ifeq -> 742
    //   572: aload #5
    //   574: astore #10
    //   576: aload #6
    //   578: astore #8
    //   580: aload #9
    //   582: instanceof dbxyzptlk/f1/i
    //   585: ifeq -> 742
    //   588: aload #9
    //   590: checkcast dbxyzptlk/f1/i
    //   593: invokevirtual l2 : ()Landroidx/compose/ui/d$c;
    //   596: astore #8
    //   598: iconst_0
    //   599: istore_3
    //   600: aload #8
    //   602: ifnull -> 726
    //   605: aload #9
    //   607: astore #10
    //   609: aload #6
    //   611: astore #13
    //   613: iload_3
    //   614: istore_2
    //   615: aload #8
    //   617: invokevirtual M1 : ()I
    //   620: iload #4
    //   622: iand
    //   623: ifeq -> 706
    //   626: iload_3
    //   627: iconst_1
    //   628: iadd
    //   629: istore_2
    //   630: iload_2
    //   631: iconst_1
    //   632: if_icmpne -> 646
    //   635: aload #8
    //   637: astore #10
    //   639: aload #6
    //   641: astore #13
    //   643: goto -> 706
    //   646: aload #6
    //   648: astore #10
    //   650: aload #6
    //   652: ifnonnull -> 670
    //   655: new dbxyzptlk/z0/d
    //   658: dup
    //   659: bipush #16
    //   661: anewarray androidx/compose/ui/d$c
    //   664: iconst_0
    //   665: invokespecial <init> : ([Ljava/lang/Object;I)V
    //   668: astore #10
    //   670: aload #9
    //   672: astore #6
    //   674: aload #9
    //   676: ifnull -> 690
    //   679: aload #10
    //   681: aload #9
    //   683: invokevirtual c : (Ljava/lang/Object;)Z
    //   686: pop
    //   687: aconst_null
    //   688: astore #6
    //   690: aload #10
    //   692: aload #8
    //   694: invokevirtual c : (Ljava/lang/Object;)Z
    //   697: pop
    //   698: aload #10
    //   700: astore #13
    //   702: aload #6
    //   704: astore #10
    //   706: aload #8
    //   708: invokevirtual I1 : ()Landroidx/compose/ui/d$c;
    //   711: astore #8
    //   713: aload #10
    //   715: astore #9
    //   717: aload #13
    //   719: astore #6
    //   721: iload_2
    //   722: istore_3
    //   723: goto -> 600
    //   726: aload #5
    //   728: astore #10
    //   730: aload #6
    //   732: astore #8
    //   734: iload_3
    //   735: iconst_1
    //   736: if_icmpne -> 742
    //   739: goto -> 497
    //   742: aload #8
    //   744: invokestatic b : (Ldbxyzptlk/z0/d;)Landroidx/compose/ui/d$c;
    //   747: astore #9
    //   749: aload #10
    //   751: astore #5
    //   753: aload #8
    //   755: astore #6
    //   757: goto -> 497
    //   760: aload #7
    //   762: invokevirtual O1 : ()Landroidx/compose/ui/d$c;
    //   765: astore #7
    //   767: aload #8
    //   769: astore #5
    //   771: goto -> 466
    //   774: aload #12
    //   776: invokevirtual m0 : ()Landroidx/compose/ui/node/f;
    //   779: astore #12
    //   781: aload #12
    //   783: ifnull -> 812
    //   786: aload #12
    //   788: invokevirtual i0 : ()Landroidx/compose/ui/node/l;
    //   791: astore #5
    //   793: aload #5
    //   795: ifnull -> 812
    //   798: aload #5
    //   800: invokevirtual p : ()Landroidx/compose/ui/d$c;
    //   803: astore #6
    //   805: aload #8
    //   807: astore #7
    //   809: goto -> 432
    //   812: aconst_null
    //   813: astore #6
    //   815: aload #8
    //   817: astore #7
    //   819: goto -> 432
    //   822: aload #7
    //   824: ifnull -> 879
    //   827: aload #7
    //   829: invokeinterface size : ()I
    //   834: iconst_1
    //   835: isub
    //   836: istore_2
    //   837: iload_2
    //   838: iflt -> 879
    //   841: iload_2
    //   842: iconst_1
    //   843: isub
    //   844: istore_3
    //   845: aload #7
    //   847: iload_2
    //   848: invokeinterface get : (I)Ljava/lang/Object;
    //   853: checkcast dbxyzptlk/Y0/h
    //   856: aload_1
    //   857: invokeinterface G : (Landroid/view/KeyEvent;)Z
    //   862: ifeq -> 867
    //   865: iconst_1
    //   866: ireturn
    //   867: iload_3
    //   868: ifge -> 874
    //   871: goto -> 879
    //   874: iload_3
    //   875: istore_2
    //   876: goto -> 841
    //   879: aload #11
    //   881: invokeinterface Q0 : ()Landroidx/compose/ui/d$c;
    //   886: astore #8
    //   888: aconst_null
    //   889: astore #5
    //   891: aload #8
    //   893: ifnull -> 1115
    //   896: aload #8
    //   898: instanceof dbxyzptlk/Y0/h
    //   901: ifeq -> 924
    //   904: aload #5
    //   906: astore #6
    //   908: aload #8
    //   910: checkcast dbxyzptlk/Y0/h
    //   913: aload_1
    //   914: invokeinterface G : (Landroid/view/KeyEvent;)Z
    //   919: ifeq -> 1101
    //   922: iconst_1
    //   923: ireturn
    //   924: aload #5
    //   926: astore #6
    //   928: aload #8
    //   930: invokevirtual M1 : ()I
    //   933: iload #4
    //   935: iand
    //   936: ifeq -> 1101
    //   939: aload #5
    //   941: astore #6
    //   943: aload #8
    //   945: instanceof dbxyzptlk/f1/i
    //   948: ifeq -> 1101
    //   951: aload #8
    //   953: checkcast dbxyzptlk/f1/i
    //   956: invokevirtual l2 : ()Landroidx/compose/ui/d$c;
    //   959: astore #6
    //   961: iconst_0
    //   962: istore_3
    //   963: aload #6
    //   965: ifnull -> 1089
    //   968: aload #8
    //   970: astore #9
    //   972: aload #5
    //   974: astore #10
    //   976: iload_3
    //   977: istore_2
    //   978: aload #6
    //   980: invokevirtual M1 : ()I
    //   983: iload #4
    //   985: iand
    //   986: ifeq -> 1069
    //   989: iload_3
    //   990: iconst_1
    //   991: iadd
    //   992: istore_2
    //   993: iload_2
    //   994: iconst_1
    //   995: if_icmpne -> 1009
    //   998: aload #6
    //   1000: astore #9
    //   1002: aload #5
    //   1004: astore #10
    //   1006: goto -> 1069
    //   1009: aload #5
    //   1011: astore #9
    //   1013: aload #5
    //   1015: ifnonnull -> 1033
    //   1018: new dbxyzptlk/z0/d
    //   1021: dup
    //   1022: bipush #16
    //   1024: anewarray androidx/compose/ui/d$c
    //   1027: iconst_0
    //   1028: invokespecial <init> : ([Ljava/lang/Object;I)V
    //   1031: astore #9
    //   1033: aload #8
    //   1035: astore #5
    //   1037: aload #8
    //   1039: ifnull -> 1053
    //   1042: aload #9
    //   1044: aload #8
    //   1046: invokevirtual c : (Ljava/lang/Object;)Z
    //   1049: pop
    //   1050: aconst_null
    //   1051: astore #5
    //   1053: aload #9
    //   1055: aload #6
    //   1057: invokevirtual c : (Ljava/lang/Object;)Z
    //   1060: pop
    //   1061: aload #9
    //   1063: astore #10
    //   1065: aload #5
    //   1067: astore #9
    //   1069: aload #6
    //   1071: invokevirtual I1 : ()Landroidx/compose/ui/d$c;
    //   1074: astore #6
    //   1076: aload #9
    //   1078: astore #8
    //   1080: aload #10
    //   1082: astore #5
    //   1084: iload_2
    //   1085: istore_3
    //   1086: goto -> 963
    //   1089: aload #5
    //   1091: astore #6
    //   1093: iload_3
    //   1094: iconst_1
    //   1095: if_icmpne -> 1101
    //   1098: goto -> 891
    //   1101: aload #6
    //   1103: invokestatic b : (Ldbxyzptlk/z0/d;)Landroidx/compose/ui/d$c;
    //   1106: astore #8
    //   1108: aload #6
    //   1110: astore #5
    //   1112: goto -> 891
    //   1115: aload #11
    //   1117: invokeinterface Q0 : ()Landroidx/compose/ui/d$c;
    //   1122: astore #8
    //   1124: aconst_null
    //   1125: astore #5
    //   1127: aload #8
    //   1129: ifnull -> 1351
    //   1132: aload #8
    //   1134: instanceof dbxyzptlk/Y0/h
    //   1137: ifeq -> 1160
    //   1140: aload #5
    //   1142: astore #6
    //   1144: aload #8
    //   1146: checkcast dbxyzptlk/Y0/h
    //   1149: aload_1
    //   1150: invokeinterface U : (Landroid/view/KeyEvent;)Z
    //   1155: ifeq -> 1337
    //   1158: iconst_1
    //   1159: ireturn
    //   1160: aload #5
    //   1162: astore #6
    //   1164: aload #8
    //   1166: invokevirtual M1 : ()I
    //   1169: iload #4
    //   1171: iand
    //   1172: ifeq -> 1337
    //   1175: aload #5
    //   1177: astore #6
    //   1179: aload #8
    //   1181: instanceof dbxyzptlk/f1/i
    //   1184: ifeq -> 1337
    //   1187: aload #8
    //   1189: checkcast dbxyzptlk/f1/i
    //   1192: invokevirtual l2 : ()Landroidx/compose/ui/d$c;
    //   1195: astore #6
    //   1197: iconst_0
    //   1198: istore_2
    //   1199: aload #6
    //   1201: ifnull -> 1325
    //   1204: aload #8
    //   1206: astore #9
    //   1208: aload #5
    //   1210: astore #10
    //   1212: iload_2
    //   1213: istore_3
    //   1214: aload #6
    //   1216: invokevirtual M1 : ()I
    //   1219: iload #4
    //   1221: iand
    //   1222: ifeq -> 1305
    //   1225: iload_2
    //   1226: iconst_1
    //   1227: iadd
    //   1228: istore_3
    //   1229: iload_3
    //   1230: iconst_1
    //   1231: if_icmpne -> 1245
    //   1234: aload #6
    //   1236: astore #9
    //   1238: aload #5
    //   1240: astore #10
    //   1242: goto -> 1305
    //   1245: aload #5
    //   1247: astore #9
    //   1249: aload #5
    //   1251: ifnonnull -> 1269
    //   1254: new dbxyzptlk/z0/d
    //   1257: dup
    //   1258: bipush #16
    //   1260: anewarray androidx/compose/ui/d$c
    //   1263: iconst_0
    //   1264: invokespecial <init> : ([Ljava/lang/Object;I)V
    //   1267: astore #9
    //   1269: aload #8
    //   1271: astore #5
    //   1273: aload #8
    //   1275: ifnull -> 1289
    //   1278: aload #9
    //   1280: aload #8
    //   1282: invokevirtual c : (Ljava/lang/Object;)Z
    //   1285: pop
    //   1286: aconst_null
    //   1287: astore #5
    //   1289: aload #9
    //   1291: aload #6
    //   1293: invokevirtual c : (Ljava/lang/Object;)Z
    //   1296: pop
    //   1297: aload #9
    //   1299: astore #10
    //   1301: aload #5
    //   1303: astore #9
    //   1305: aload #6
    //   1307: invokevirtual I1 : ()Landroidx/compose/ui/d$c;
    //   1310: astore #6
    //   1312: aload #9
    //   1314: astore #8
    //   1316: aload #10
    //   1318: astore #5
    //   1320: iload_3
    //   1321: istore_2
    //   1322: goto -> 1199
    //   1325: aload #5
    //   1327: astore #6
    //   1329: iload_2
    //   1330: iconst_1
    //   1331: if_icmpne -> 1337
    //   1334: goto -> 1127
    //   1337: aload #6
    //   1339: invokestatic b : (Ldbxyzptlk/z0/d;)Landroidx/compose/ui/d$c;
    //   1342: astore #8
    //   1344: aload #6
    //   1346: astore #5
    //   1348: goto -> 1127
    //   1351: aload #7
    //   1353: ifnull -> 1409
    //   1356: aload #7
    //   1358: invokeinterface size : ()I
    //   1363: istore_3
    //   1364: iconst_0
    //   1365: istore_2
    //   1366: iload_2
    //   1367: iload_3
    //   1368: if_icmpge -> 1409
    //   1371: aload #7
    //   1373: iload_2
    //   1374: invokeinterface get : (I)Ljava/lang/Object;
    //   1379: checkcast dbxyzptlk/Y0/h
    //   1382: aload_1
    //   1383: invokeinterface U : (Landroid/view/KeyEvent;)Z
    //   1388: ifeq -> 1393
    //   1391: iconst_1
    //   1392: ireturn
    //   1393: iinc #2, 1
    //   1396: goto -> 1366
    //   1399: new java/lang/IllegalStateException
    //   1402: dup
    //   1403: ldc 'visitAncestors called on an unattached node'
    //   1405: invokespecial <init> : (Ljava/lang/String;)V
    //   1408: athrow
    //   1409: iconst_0
    //   1410: ireturn
  }
  
  public void e(d paramd) {
    this.b.e(paramd);
  }
  
  public d f() {
    return this.d;
  }
  
  public void g(k paramk) {
    this.b.f(paramk);
  }
  
  public boolean h(KeyEvent paramKeyEvent) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: invokevirtual t : (Landroid/view/KeyEvent;)Z
    //   5: ifne -> 10
    //   8: iconst_0
    //   9: ireturn
    //   10: aload_0
    //   11: getfield a : Landroidx/compose/ui/focus/FocusTargetNode;
    //   14: invokestatic b : (Landroidx/compose/ui/focus/FocusTargetNode;)Landroidx/compose/ui/focus/FocusTargetNode;
    //   17: astore #6
    //   19: aload #6
    //   21: ifnull -> 1457
    //   24: aload_0
    //   25: aload #6
    //   27: invokevirtual s : (Ldbxyzptlk/f1/g;)Landroidx/compose/ui/d$c;
    //   30: astore #5
    //   32: aload #5
    //   34: astore #7
    //   36: aload #5
    //   38: ifnonnull -> 430
    //   41: sipush #8192
    //   44: invokestatic a : (I)I
    //   47: istore #4
    //   49: aload #6
    //   51: invokeinterface Q0 : ()Landroidx/compose/ui/d$c;
    //   56: invokevirtual R1 : ()Z
    //   59: ifeq -> 420
    //   62: aload #6
    //   64: invokeinterface Q0 : ()Landroidx/compose/ui/d$c;
    //   69: invokevirtual O1 : ()Landroidx/compose/ui/d$c;
    //   72: astore #5
    //   74: aload #6
    //   76: invokestatic k : (Ldbxyzptlk/f1/g;)Landroidx/compose/ui/node/f;
    //   79: astore #10
    //   81: aload #10
    //   83: ifnull -> 387
    //   86: aload #10
    //   88: invokevirtual i0 : ()Landroidx/compose/ui/node/l;
    //   91: invokevirtual k : ()Landroidx/compose/ui/d$c;
    //   94: invokevirtual H1 : ()I
    //   97: iload #4
    //   99: iand
    //   100: ifeq -> 347
    //   103: aload #5
    //   105: astore #7
    //   107: aload #7
    //   109: ifnull -> 347
    //   112: aload #7
    //   114: invokevirtual M1 : ()I
    //   117: iload #4
    //   119: iand
    //   120: ifeq -> 337
    //   123: aconst_null
    //   124: astore #5
    //   126: aload #7
    //   128: astore #6
    //   130: aload #6
    //   132: ifnull -> 337
    //   135: aload #6
    //   137: instanceof dbxyzptlk/Y0/e
    //   140: ifeq -> 146
    //   143: goto -> 390
    //   146: aload #5
    //   148: astore #8
    //   150: aload #6
    //   152: invokevirtual M1 : ()I
    //   155: iload #4
    //   157: iand
    //   158: ifeq -> 323
    //   161: aload #5
    //   163: astore #8
    //   165: aload #6
    //   167: instanceof dbxyzptlk/f1/i
    //   170: ifeq -> 323
    //   173: aload #6
    //   175: checkcast dbxyzptlk/f1/i
    //   178: invokevirtual l2 : ()Landroidx/compose/ui/d$c;
    //   181: astore #8
    //   183: iconst_0
    //   184: istore_2
    //   185: aload #8
    //   187: ifnull -> 311
    //   190: aload #6
    //   192: astore #9
    //   194: aload #5
    //   196: astore #11
    //   198: iload_2
    //   199: istore_3
    //   200: aload #8
    //   202: invokevirtual M1 : ()I
    //   205: iload #4
    //   207: iand
    //   208: ifeq -> 291
    //   211: iload_2
    //   212: iconst_1
    //   213: iadd
    //   214: istore_3
    //   215: iload_3
    //   216: iconst_1
    //   217: if_icmpne -> 231
    //   220: aload #8
    //   222: astore #9
    //   224: aload #5
    //   226: astore #11
    //   228: goto -> 291
    //   231: aload #5
    //   233: astore #9
    //   235: aload #5
    //   237: ifnonnull -> 255
    //   240: new dbxyzptlk/z0/d
    //   243: dup
    //   244: bipush #16
    //   246: anewarray androidx/compose/ui/d$c
    //   249: iconst_0
    //   250: invokespecial <init> : ([Ljava/lang/Object;I)V
    //   253: astore #9
    //   255: aload #6
    //   257: astore #5
    //   259: aload #6
    //   261: ifnull -> 275
    //   264: aload #9
    //   266: aload #6
    //   268: invokevirtual c : (Ljava/lang/Object;)Z
    //   271: pop
    //   272: aconst_null
    //   273: astore #5
    //   275: aload #9
    //   277: aload #8
    //   279: invokevirtual c : (Ljava/lang/Object;)Z
    //   282: pop
    //   283: aload #9
    //   285: astore #11
    //   287: aload #5
    //   289: astore #9
    //   291: aload #8
    //   293: invokevirtual I1 : ()Landroidx/compose/ui/d$c;
    //   296: astore #8
    //   298: aload #9
    //   300: astore #6
    //   302: aload #11
    //   304: astore #5
    //   306: iload_3
    //   307: istore_2
    //   308: goto -> 185
    //   311: aload #5
    //   313: astore #8
    //   315: iload_2
    //   316: iconst_1
    //   317: if_icmpne -> 323
    //   320: goto -> 130
    //   323: aload #8
    //   325: invokestatic b : (Ldbxyzptlk/z0/d;)Landroidx/compose/ui/d$c;
    //   328: astore #6
    //   330: aload #8
    //   332: astore #5
    //   334: goto -> 130
    //   337: aload #7
    //   339: invokevirtual O1 : ()Landroidx/compose/ui/d$c;
    //   342: astore #7
    //   344: goto -> 107
    //   347: aload #10
    //   349: invokevirtual m0 : ()Landroidx/compose/ui/node/f;
    //   352: astore #10
    //   354: aload #10
    //   356: ifnull -> 381
    //   359: aload #10
    //   361: invokevirtual i0 : ()Landroidx/compose/ui/node/l;
    //   364: astore #5
    //   366: aload #5
    //   368: ifnull -> 381
    //   371: aload #5
    //   373: invokevirtual p : ()Landroidx/compose/ui/d$c;
    //   376: astore #5
    //   378: goto -> 81
    //   381: aconst_null
    //   382: astore #5
    //   384: goto -> 81
    //   387: aconst_null
    //   388: astore #6
    //   390: aload #6
    //   392: checkcast dbxyzptlk/Y0/e
    //   395: astore #5
    //   397: aload #5
    //   399: ifnull -> 414
    //   402: aload #5
    //   404: invokeinterface Q0 : ()Landroidx/compose/ui/d$c;
    //   409: astore #7
    //   411: goto -> 430
    //   414: aconst_null
    //   415: astore #7
    //   417: goto -> 430
    //   420: new java/lang/IllegalStateException
    //   423: dup
    //   424: ldc 'visitAncestors called on an unattached node'
    //   426: invokespecial <init> : (Ljava/lang/String;)V
    //   429: athrow
    //   430: aload #7
    //   432: ifnull -> 1455
    //   435: sipush #8192
    //   438: invokestatic a : (I)I
    //   441: istore #4
    //   443: aload #7
    //   445: invokeinterface Q0 : ()Landroidx/compose/ui/d$c;
    //   450: invokevirtual R1 : ()Z
    //   453: ifeq -> 1445
    //   456: aload #7
    //   458: invokeinterface Q0 : ()Landroidx/compose/ui/d$c;
    //   463: invokevirtual O1 : ()Landroidx/compose/ui/d$c;
    //   466: astore #6
    //   468: aload #7
    //   470: invokestatic k : (Ldbxyzptlk/f1/g;)Landroidx/compose/ui/node/f;
    //   473: astore #12
    //   475: aconst_null
    //   476: astore #8
    //   478: aload #12
    //   480: ifnull -> 868
    //   483: aload #8
    //   485: astore #9
    //   487: aload #12
    //   489: invokevirtual i0 : ()Landroidx/compose/ui/node/l;
    //   492: invokevirtual k : ()Landroidx/compose/ui/d$c;
    //   495: invokevirtual H1 : ()I
    //   498: iload #4
    //   500: iand
    //   501: ifeq -> 820
    //   504: aload #8
    //   506: astore #5
    //   508: aload #6
    //   510: astore #8
    //   512: aload #5
    //   514: astore #9
    //   516: aload #8
    //   518: ifnull -> 820
    //   521: aload #5
    //   523: astore #9
    //   525: aload #8
    //   527: invokevirtual M1 : ()I
    //   530: iload #4
    //   532: iand
    //   533: ifeq -> 806
    //   536: aload #8
    //   538: astore #10
    //   540: aconst_null
    //   541: astore #6
    //   543: aload #5
    //   545: astore #9
    //   547: aload #10
    //   549: ifnull -> 806
    //   552: aload #10
    //   554: instanceof dbxyzptlk/Y0/e
    //   557: ifeq -> 599
    //   560: aload #5
    //   562: astore #9
    //   564: aload #5
    //   566: ifnonnull -> 578
    //   569: new java/util/ArrayList
    //   572: dup
    //   573: invokespecial <init> : ()V
    //   576: astore #9
    //   578: aload #9
    //   580: aload #10
    //   582: invokeinterface add : (Ljava/lang/Object;)Z
    //   587: pop
    //   588: aload #9
    //   590: astore #11
    //   592: aload #6
    //   594: astore #9
    //   596: goto -> 788
    //   599: aload #5
    //   601: astore #11
    //   603: aload #6
    //   605: astore #9
    //   607: aload #10
    //   609: invokevirtual M1 : ()I
    //   612: iload #4
    //   614: iand
    //   615: ifeq -> 788
    //   618: aload #5
    //   620: astore #11
    //   622: aload #6
    //   624: astore #9
    //   626: aload #10
    //   628: instanceof dbxyzptlk/f1/i
    //   631: ifeq -> 788
    //   634: aload #10
    //   636: checkcast dbxyzptlk/f1/i
    //   639: invokevirtual l2 : ()Landroidx/compose/ui/d$c;
    //   642: astore #9
    //   644: iconst_0
    //   645: istore_2
    //   646: aload #9
    //   648: ifnull -> 772
    //   651: aload #10
    //   653: astore #11
    //   655: aload #6
    //   657: astore #13
    //   659: iload_2
    //   660: istore_3
    //   661: aload #9
    //   663: invokevirtual M1 : ()I
    //   666: iload #4
    //   668: iand
    //   669: ifeq -> 752
    //   672: iload_2
    //   673: iconst_1
    //   674: iadd
    //   675: istore_3
    //   676: iload_3
    //   677: iconst_1
    //   678: if_icmpne -> 692
    //   681: aload #9
    //   683: astore #11
    //   685: aload #6
    //   687: astore #13
    //   689: goto -> 752
    //   692: aload #6
    //   694: astore #11
    //   696: aload #6
    //   698: ifnonnull -> 716
    //   701: new dbxyzptlk/z0/d
    //   704: dup
    //   705: bipush #16
    //   707: anewarray androidx/compose/ui/d$c
    //   710: iconst_0
    //   711: invokespecial <init> : ([Ljava/lang/Object;I)V
    //   714: astore #11
    //   716: aload #10
    //   718: astore #6
    //   720: aload #10
    //   722: ifnull -> 736
    //   725: aload #11
    //   727: aload #10
    //   729: invokevirtual c : (Ljava/lang/Object;)Z
    //   732: pop
    //   733: aconst_null
    //   734: astore #6
    //   736: aload #11
    //   738: aload #9
    //   740: invokevirtual c : (Ljava/lang/Object;)Z
    //   743: pop
    //   744: aload #11
    //   746: astore #13
    //   748: aload #6
    //   750: astore #11
    //   752: aload #9
    //   754: invokevirtual I1 : ()Landroidx/compose/ui/d$c;
    //   757: astore #9
    //   759: aload #11
    //   761: astore #10
    //   763: aload #13
    //   765: astore #6
    //   767: iload_3
    //   768: istore_2
    //   769: goto -> 646
    //   772: aload #5
    //   774: astore #11
    //   776: aload #6
    //   778: astore #9
    //   780: iload_2
    //   781: iconst_1
    //   782: if_icmpne -> 788
    //   785: goto -> 543
    //   788: aload #9
    //   790: invokestatic b : (Ldbxyzptlk/z0/d;)Landroidx/compose/ui/d$c;
    //   793: astore #10
    //   795: aload #11
    //   797: astore #5
    //   799: aload #9
    //   801: astore #6
    //   803: goto -> 543
    //   806: aload #8
    //   808: invokevirtual O1 : ()Landroidx/compose/ui/d$c;
    //   811: astore #8
    //   813: aload #9
    //   815: astore #5
    //   817: goto -> 512
    //   820: aload #12
    //   822: invokevirtual m0 : ()Landroidx/compose/ui/node/f;
    //   825: astore #12
    //   827: aload #12
    //   829: ifnull -> 858
    //   832: aload #12
    //   834: invokevirtual i0 : ()Landroidx/compose/ui/node/l;
    //   837: astore #5
    //   839: aload #5
    //   841: ifnull -> 858
    //   844: aload #5
    //   846: invokevirtual p : ()Landroidx/compose/ui/d$c;
    //   849: astore #6
    //   851: aload #9
    //   853: astore #8
    //   855: goto -> 478
    //   858: aconst_null
    //   859: astore #6
    //   861: aload #9
    //   863: astore #8
    //   865: goto -> 478
    //   868: aload #8
    //   870: ifnull -> 925
    //   873: aload #8
    //   875: invokeinterface size : ()I
    //   880: iconst_1
    //   881: isub
    //   882: istore_2
    //   883: iload_2
    //   884: iflt -> 925
    //   887: iload_2
    //   888: iconst_1
    //   889: isub
    //   890: istore_3
    //   891: aload #8
    //   893: iload_2
    //   894: invokeinterface get : (I)Ljava/lang/Object;
    //   899: checkcast dbxyzptlk/Y0/e
    //   902: aload_1
    //   903: invokeinterface e0 : (Landroid/view/KeyEvent;)Z
    //   908: ifeq -> 913
    //   911: iconst_1
    //   912: ireturn
    //   913: iload_3
    //   914: ifge -> 920
    //   917: goto -> 925
    //   920: iload_3
    //   921: istore_2
    //   922: goto -> 887
    //   925: aload #7
    //   927: invokeinterface Q0 : ()Landroidx/compose/ui/d$c;
    //   932: astore #9
    //   934: aconst_null
    //   935: astore #5
    //   937: aload #9
    //   939: ifnull -> 1161
    //   942: aload #9
    //   944: instanceof dbxyzptlk/Y0/e
    //   947: ifeq -> 970
    //   950: aload #5
    //   952: astore #6
    //   954: aload #9
    //   956: checkcast dbxyzptlk/Y0/e
    //   959: aload_1
    //   960: invokeinterface e0 : (Landroid/view/KeyEvent;)Z
    //   965: ifeq -> 1147
    //   968: iconst_1
    //   969: ireturn
    //   970: aload #5
    //   972: astore #6
    //   974: aload #9
    //   976: invokevirtual M1 : ()I
    //   979: iload #4
    //   981: iand
    //   982: ifeq -> 1147
    //   985: aload #5
    //   987: astore #6
    //   989: aload #9
    //   991: instanceof dbxyzptlk/f1/i
    //   994: ifeq -> 1147
    //   997: aload #9
    //   999: checkcast dbxyzptlk/f1/i
    //   1002: invokevirtual l2 : ()Landroidx/compose/ui/d$c;
    //   1005: astore #6
    //   1007: iconst_0
    //   1008: istore_2
    //   1009: aload #6
    //   1011: ifnull -> 1135
    //   1014: aload #9
    //   1016: astore #10
    //   1018: aload #5
    //   1020: astore #11
    //   1022: iload_2
    //   1023: istore_3
    //   1024: aload #6
    //   1026: invokevirtual M1 : ()I
    //   1029: iload #4
    //   1031: iand
    //   1032: ifeq -> 1115
    //   1035: iload_2
    //   1036: iconst_1
    //   1037: iadd
    //   1038: istore_3
    //   1039: iload_3
    //   1040: iconst_1
    //   1041: if_icmpne -> 1055
    //   1044: aload #6
    //   1046: astore #10
    //   1048: aload #5
    //   1050: astore #11
    //   1052: goto -> 1115
    //   1055: aload #5
    //   1057: astore #10
    //   1059: aload #5
    //   1061: ifnonnull -> 1079
    //   1064: new dbxyzptlk/z0/d
    //   1067: dup
    //   1068: bipush #16
    //   1070: anewarray androidx/compose/ui/d$c
    //   1073: iconst_0
    //   1074: invokespecial <init> : ([Ljava/lang/Object;I)V
    //   1077: astore #10
    //   1079: aload #9
    //   1081: astore #5
    //   1083: aload #9
    //   1085: ifnull -> 1099
    //   1088: aload #10
    //   1090: aload #9
    //   1092: invokevirtual c : (Ljava/lang/Object;)Z
    //   1095: pop
    //   1096: aconst_null
    //   1097: astore #5
    //   1099: aload #10
    //   1101: aload #6
    //   1103: invokevirtual c : (Ljava/lang/Object;)Z
    //   1106: pop
    //   1107: aload #10
    //   1109: astore #11
    //   1111: aload #5
    //   1113: astore #10
    //   1115: aload #6
    //   1117: invokevirtual I1 : ()Landroidx/compose/ui/d$c;
    //   1120: astore #6
    //   1122: aload #10
    //   1124: astore #9
    //   1126: aload #11
    //   1128: astore #5
    //   1130: iload_3
    //   1131: istore_2
    //   1132: goto -> 1009
    //   1135: aload #5
    //   1137: astore #6
    //   1139: iload_2
    //   1140: iconst_1
    //   1141: if_icmpne -> 1147
    //   1144: goto -> 937
    //   1147: aload #6
    //   1149: invokestatic b : (Ldbxyzptlk/z0/d;)Landroidx/compose/ui/d$c;
    //   1152: astore #9
    //   1154: aload #6
    //   1156: astore #5
    //   1158: goto -> 937
    //   1161: aload #7
    //   1163: invokeinterface Q0 : ()Landroidx/compose/ui/d$c;
    //   1168: astore #7
    //   1170: aconst_null
    //   1171: astore #5
    //   1173: aload #7
    //   1175: ifnull -> 1397
    //   1178: aload #7
    //   1180: instanceof dbxyzptlk/Y0/e
    //   1183: ifeq -> 1206
    //   1186: aload #5
    //   1188: astore #6
    //   1190: aload #7
    //   1192: checkcast dbxyzptlk/Y0/e
    //   1195: aload_1
    //   1196: invokeinterface k1 : (Landroid/view/KeyEvent;)Z
    //   1201: ifeq -> 1383
    //   1204: iconst_1
    //   1205: ireturn
    //   1206: aload #5
    //   1208: astore #6
    //   1210: aload #7
    //   1212: invokevirtual M1 : ()I
    //   1215: iload #4
    //   1217: iand
    //   1218: ifeq -> 1383
    //   1221: aload #5
    //   1223: astore #6
    //   1225: aload #7
    //   1227: instanceof dbxyzptlk/f1/i
    //   1230: ifeq -> 1383
    //   1233: aload #7
    //   1235: checkcast dbxyzptlk/f1/i
    //   1238: invokevirtual l2 : ()Landroidx/compose/ui/d$c;
    //   1241: astore #6
    //   1243: iconst_0
    //   1244: istore_2
    //   1245: aload #6
    //   1247: ifnull -> 1371
    //   1250: aload #7
    //   1252: astore #9
    //   1254: aload #5
    //   1256: astore #10
    //   1258: iload_2
    //   1259: istore_3
    //   1260: aload #6
    //   1262: invokevirtual M1 : ()I
    //   1265: iload #4
    //   1267: iand
    //   1268: ifeq -> 1351
    //   1271: iload_2
    //   1272: iconst_1
    //   1273: iadd
    //   1274: istore_3
    //   1275: iload_3
    //   1276: iconst_1
    //   1277: if_icmpne -> 1291
    //   1280: aload #6
    //   1282: astore #9
    //   1284: aload #5
    //   1286: astore #10
    //   1288: goto -> 1351
    //   1291: aload #5
    //   1293: astore #9
    //   1295: aload #5
    //   1297: ifnonnull -> 1315
    //   1300: new dbxyzptlk/z0/d
    //   1303: dup
    //   1304: bipush #16
    //   1306: anewarray androidx/compose/ui/d$c
    //   1309: iconst_0
    //   1310: invokespecial <init> : ([Ljava/lang/Object;I)V
    //   1313: astore #9
    //   1315: aload #7
    //   1317: astore #5
    //   1319: aload #7
    //   1321: ifnull -> 1335
    //   1324: aload #9
    //   1326: aload #7
    //   1328: invokevirtual c : (Ljava/lang/Object;)Z
    //   1331: pop
    //   1332: aconst_null
    //   1333: astore #5
    //   1335: aload #9
    //   1337: aload #6
    //   1339: invokevirtual c : (Ljava/lang/Object;)Z
    //   1342: pop
    //   1343: aload #9
    //   1345: astore #10
    //   1347: aload #5
    //   1349: astore #9
    //   1351: aload #6
    //   1353: invokevirtual I1 : ()Landroidx/compose/ui/d$c;
    //   1356: astore #6
    //   1358: aload #9
    //   1360: astore #7
    //   1362: aload #10
    //   1364: astore #5
    //   1366: iload_3
    //   1367: istore_2
    //   1368: goto -> 1245
    //   1371: aload #5
    //   1373: astore #6
    //   1375: iload_2
    //   1376: iconst_1
    //   1377: if_icmpne -> 1383
    //   1380: goto -> 1173
    //   1383: aload #6
    //   1385: invokestatic b : (Ldbxyzptlk/z0/d;)Landroidx/compose/ui/d$c;
    //   1388: astore #7
    //   1390: aload #6
    //   1392: astore #5
    //   1394: goto -> 1173
    //   1397: aload #8
    //   1399: ifnull -> 1455
    //   1402: aload #8
    //   1404: invokeinterface size : ()I
    //   1409: istore_3
    //   1410: iconst_0
    //   1411: istore_2
    //   1412: iload_2
    //   1413: iload_3
    //   1414: if_icmpge -> 1455
    //   1417: aload #8
    //   1419: iload_2
    //   1420: invokeinterface get : (I)Ljava/lang/Object;
    //   1425: checkcast dbxyzptlk/Y0/e
    //   1428: aload_1
    //   1429: invokeinterface k1 : (Landroid/view/KeyEvent;)Z
    //   1434: ifeq -> 1439
    //   1437: iconst_1
    //   1438: ireturn
    //   1439: iinc #2, 1
    //   1442: goto -> 1412
    //   1445: new java/lang/IllegalStateException
    //   1448: dup
    //   1449: ldc 'visitAncestors called on an unattached node'
    //   1451: invokespecial <init> : (Ljava/lang/String;)V
    //   1454: athrow
    //   1455: iconst_0
    //   1456: ireturn
    //   1457: new java/lang/IllegalStateException
    //   1460: dup
    //   1461: ldc_w 'Event can't be processed because we do not have an active focus target.'
    //   1464: invokespecial <init> : (Ljava/lang/String;)V
    //   1467: athrow
  }
  
  public void i(boolean paramBoolean1, boolean paramBoolean2) {
    u u1 = c();
    try {
      if (u.e(u1))
        u.b(u1); 
    } finally {
      Exception exception;
    } 
    u.a(u1);
    if (!paramBoolean1) {
      dbxyzptlk.O0.a a = j.e(this.a, c.b.c());
      int i = a.a[a.ordinal()];
      if (i == 1 || i == 2 || i == 3) {
        u.c(u1);
        return;
      } 
    } 
    q q = this.a.r2();
    if (j.c(this.a, paramBoolean1, paramBoolean2)) {
      FocusTargetNode focusTargetNode = this.a;
      int i = a.b[q.ordinal()];
      if (i != 1 && i != 2 && i != 3) {
        if (i == 4) {
          q = q.Inactive;
        } else {
          NoWhenBranchMatchedException noWhenBranchMatchedException = new NoWhenBranchMatchedException();
          this();
          throw noWhenBranchMatchedException;
        } 
      } else {
        q = q.Active;
      } 
      focusTargetNode.u2(q);
    } 
    D d1 = D.a;
    u.c(u1);
  }
  
  public boolean j(c paramc) {
    // Byte code:
    //   0: aload_0
    //   1: getfield a : Landroidx/compose/ui/focus/FocusTargetNode;
    //   4: invokestatic b : (Landroidx/compose/ui/focus/FocusTargetNode;)Landroidx/compose/ui/focus/FocusTargetNode;
    //   7: astore #6
    //   9: aload #6
    //   11: ifnull -> 383
    //   14: sipush #16384
    //   17: invokestatic a : (I)I
    //   20: istore #4
    //   22: aload #6
    //   24: invokeinterface Q0 : ()Landroidx/compose/ui/d$c;
    //   29: invokevirtual R1 : ()Z
    //   32: ifeq -> 373
    //   35: aload #6
    //   37: invokeinterface Q0 : ()Landroidx/compose/ui/d$c;
    //   42: invokevirtual O1 : ()Landroidx/compose/ui/d$c;
    //   45: astore #5
    //   47: aload #6
    //   49: invokestatic k : (Ldbxyzptlk/f1/g;)Landroidx/compose/ui/node/f;
    //   52: astore #10
    //   54: aload #10
    //   56: ifnull -> 360
    //   59: aload #10
    //   61: invokevirtual i0 : ()Landroidx/compose/ui/node/l;
    //   64: invokevirtual k : ()Landroidx/compose/ui/d$c;
    //   67: invokevirtual H1 : ()I
    //   70: iload #4
    //   72: iand
    //   73: ifeq -> 320
    //   76: aload #5
    //   78: astore #7
    //   80: aload #7
    //   82: ifnull -> 320
    //   85: aload #7
    //   87: invokevirtual M1 : ()I
    //   90: iload #4
    //   92: iand
    //   93: ifeq -> 310
    //   96: aconst_null
    //   97: astore #5
    //   99: aload #7
    //   101: astore #6
    //   103: aload #6
    //   105: ifnull -> 310
    //   108: aload #6
    //   110: instanceof dbxyzptlk/c1/a
    //   113: ifeq -> 119
    //   116: goto -> 363
    //   119: aload #5
    //   121: astore #8
    //   123: aload #6
    //   125: invokevirtual M1 : ()I
    //   128: iload #4
    //   130: iand
    //   131: ifeq -> 296
    //   134: aload #5
    //   136: astore #8
    //   138: aload #6
    //   140: instanceof dbxyzptlk/f1/i
    //   143: ifeq -> 296
    //   146: aload #6
    //   148: checkcast dbxyzptlk/f1/i
    //   151: invokevirtual l2 : ()Landroidx/compose/ui/d$c;
    //   154: astore #8
    //   156: iconst_0
    //   157: istore_3
    //   158: aload #8
    //   160: ifnull -> 284
    //   163: aload #6
    //   165: astore #9
    //   167: aload #5
    //   169: astore #11
    //   171: iload_3
    //   172: istore_2
    //   173: aload #8
    //   175: invokevirtual M1 : ()I
    //   178: iload #4
    //   180: iand
    //   181: ifeq -> 264
    //   184: iload_3
    //   185: iconst_1
    //   186: iadd
    //   187: istore_2
    //   188: iload_2
    //   189: iconst_1
    //   190: if_icmpne -> 204
    //   193: aload #8
    //   195: astore #9
    //   197: aload #5
    //   199: astore #11
    //   201: goto -> 264
    //   204: aload #5
    //   206: astore #9
    //   208: aload #5
    //   210: ifnonnull -> 228
    //   213: new dbxyzptlk/z0/d
    //   216: dup
    //   217: bipush #16
    //   219: anewarray androidx/compose/ui/d$c
    //   222: iconst_0
    //   223: invokespecial <init> : ([Ljava/lang/Object;I)V
    //   226: astore #9
    //   228: aload #6
    //   230: astore #5
    //   232: aload #6
    //   234: ifnull -> 248
    //   237: aload #9
    //   239: aload #6
    //   241: invokevirtual c : (Ljava/lang/Object;)Z
    //   244: pop
    //   245: aconst_null
    //   246: astore #5
    //   248: aload #9
    //   250: aload #8
    //   252: invokevirtual c : (Ljava/lang/Object;)Z
    //   255: pop
    //   256: aload #9
    //   258: astore #11
    //   260: aload #5
    //   262: astore #9
    //   264: aload #8
    //   266: invokevirtual I1 : ()Landroidx/compose/ui/d$c;
    //   269: astore #8
    //   271: aload #9
    //   273: astore #6
    //   275: aload #11
    //   277: astore #5
    //   279: iload_2
    //   280: istore_3
    //   281: goto -> 158
    //   284: aload #5
    //   286: astore #8
    //   288: iload_3
    //   289: iconst_1
    //   290: if_icmpne -> 296
    //   293: goto -> 103
    //   296: aload #8
    //   298: invokestatic b : (Ldbxyzptlk/z0/d;)Landroidx/compose/ui/d$c;
    //   301: astore #6
    //   303: aload #8
    //   305: astore #5
    //   307: goto -> 103
    //   310: aload #7
    //   312: invokevirtual O1 : ()Landroidx/compose/ui/d$c;
    //   315: astore #7
    //   317: goto -> 80
    //   320: aload #10
    //   322: invokevirtual m0 : ()Landroidx/compose/ui/node/f;
    //   325: astore #10
    //   327: aload #10
    //   329: ifnull -> 354
    //   332: aload #10
    //   334: invokevirtual i0 : ()Landroidx/compose/ui/node/l;
    //   337: astore #5
    //   339: aload #5
    //   341: ifnull -> 354
    //   344: aload #5
    //   346: invokevirtual p : ()Landroidx/compose/ui/d$c;
    //   349: astore #5
    //   351: goto -> 54
    //   354: aconst_null
    //   355: astore #5
    //   357: goto -> 54
    //   360: aconst_null
    //   361: astore #6
    //   363: aload #6
    //   365: checkcast dbxyzptlk/c1/a
    //   368: astore #11
    //   370: goto -> 386
    //   373: new java/lang/IllegalStateException
    //   376: dup
    //   377: ldc 'visitAncestors called on an unattached node'
    //   379: invokespecial <init> : (Ljava/lang/String;)V
    //   382: athrow
    //   383: aconst_null
    //   384: astore #11
    //   386: aload #11
    //   388: ifnull -> 1407
    //   391: sipush #16384
    //   394: invokestatic a : (I)I
    //   397: istore #4
    //   399: aload #11
    //   401: invokeinterface Q0 : ()Landroidx/compose/ui/d$c;
    //   406: invokevirtual R1 : ()Z
    //   409: ifeq -> 1397
    //   412: aload #11
    //   414: invokeinterface Q0 : ()Landroidx/compose/ui/d$c;
    //   419: invokevirtual O1 : ()Landroidx/compose/ui/d$c;
    //   422: astore #6
    //   424: aload #11
    //   426: invokestatic k : (Ldbxyzptlk/f1/g;)Landroidx/compose/ui/node/f;
    //   429: astore #12
    //   431: aconst_null
    //   432: astore #7
    //   434: aload #12
    //   436: ifnull -> 820
    //   439: aload #7
    //   441: astore #8
    //   443: aload #12
    //   445: invokevirtual i0 : ()Landroidx/compose/ui/node/l;
    //   448: invokevirtual k : ()Landroidx/compose/ui/d$c;
    //   451: invokevirtual H1 : ()I
    //   454: iload #4
    //   456: iand
    //   457: ifeq -> 772
    //   460: aload #7
    //   462: astore #5
    //   464: aload #6
    //   466: astore #7
    //   468: aload #5
    //   470: astore #8
    //   472: aload #7
    //   474: ifnull -> 772
    //   477: aload #5
    //   479: astore #8
    //   481: aload #7
    //   483: invokevirtual M1 : ()I
    //   486: iload #4
    //   488: iand
    //   489: ifeq -> 758
    //   492: aload #7
    //   494: astore #9
    //   496: aconst_null
    //   497: astore #6
    //   499: aload #5
    //   501: astore #8
    //   503: aload #9
    //   505: ifnull -> 758
    //   508: aload #9
    //   510: instanceof dbxyzptlk/c1/a
    //   513: ifeq -> 551
    //   516: aload #5
    //   518: astore #8
    //   520: aload #5
    //   522: ifnonnull -> 534
    //   525: new java/util/ArrayList
    //   528: dup
    //   529: invokespecial <init> : ()V
    //   532: astore #8
    //   534: aload #8
    //   536: aload #9
    //   538: invokeinterface add : (Ljava/lang/Object;)Z
    //   543: pop
    //   544: aload #6
    //   546: astore #10
    //   548: goto -> 740
    //   551: aload #5
    //   553: astore #8
    //   555: aload #6
    //   557: astore #10
    //   559: aload #9
    //   561: invokevirtual M1 : ()I
    //   564: iload #4
    //   566: iand
    //   567: ifeq -> 740
    //   570: aload #5
    //   572: astore #8
    //   574: aload #6
    //   576: astore #10
    //   578: aload #9
    //   580: instanceof dbxyzptlk/f1/i
    //   583: ifeq -> 740
    //   586: aload #9
    //   588: checkcast dbxyzptlk/f1/i
    //   591: invokevirtual l2 : ()Landroidx/compose/ui/d$c;
    //   594: astore #8
    //   596: iconst_0
    //   597: istore_2
    //   598: aload #8
    //   600: ifnull -> 724
    //   603: aload #9
    //   605: astore #10
    //   607: aload #6
    //   609: astore #13
    //   611: iload_2
    //   612: istore_3
    //   613: aload #8
    //   615: invokevirtual M1 : ()I
    //   618: iload #4
    //   620: iand
    //   621: ifeq -> 704
    //   624: iload_2
    //   625: iconst_1
    //   626: iadd
    //   627: istore_3
    //   628: iload_3
    //   629: iconst_1
    //   630: if_icmpne -> 644
    //   633: aload #8
    //   635: astore #10
    //   637: aload #6
    //   639: astore #13
    //   641: goto -> 704
    //   644: aload #6
    //   646: astore #10
    //   648: aload #6
    //   650: ifnonnull -> 668
    //   653: new dbxyzptlk/z0/d
    //   656: dup
    //   657: bipush #16
    //   659: anewarray androidx/compose/ui/d$c
    //   662: iconst_0
    //   663: invokespecial <init> : ([Ljava/lang/Object;I)V
    //   666: astore #10
    //   668: aload #9
    //   670: astore #6
    //   672: aload #9
    //   674: ifnull -> 688
    //   677: aload #10
    //   679: aload #9
    //   681: invokevirtual c : (Ljava/lang/Object;)Z
    //   684: pop
    //   685: aconst_null
    //   686: astore #6
    //   688: aload #10
    //   690: aload #8
    //   692: invokevirtual c : (Ljava/lang/Object;)Z
    //   695: pop
    //   696: aload #10
    //   698: astore #13
    //   700: aload #6
    //   702: astore #10
    //   704: aload #8
    //   706: invokevirtual I1 : ()Landroidx/compose/ui/d$c;
    //   709: astore #8
    //   711: aload #10
    //   713: astore #9
    //   715: aload #13
    //   717: astore #6
    //   719: iload_3
    //   720: istore_2
    //   721: goto -> 598
    //   724: aload #5
    //   726: astore #8
    //   728: aload #6
    //   730: astore #10
    //   732: iload_2
    //   733: iconst_1
    //   734: if_icmpne -> 740
    //   737: goto -> 499
    //   740: aload #10
    //   742: invokestatic b : (Ldbxyzptlk/z0/d;)Landroidx/compose/ui/d$c;
    //   745: astore #9
    //   747: aload #8
    //   749: astore #5
    //   751: aload #10
    //   753: astore #6
    //   755: goto -> 499
    //   758: aload #7
    //   760: invokevirtual O1 : ()Landroidx/compose/ui/d$c;
    //   763: astore #7
    //   765: aload #8
    //   767: astore #5
    //   769: goto -> 468
    //   772: aload #12
    //   774: invokevirtual m0 : ()Landroidx/compose/ui/node/f;
    //   777: astore #12
    //   779: aload #12
    //   781: ifnull -> 810
    //   784: aload #12
    //   786: invokevirtual i0 : ()Landroidx/compose/ui/node/l;
    //   789: astore #5
    //   791: aload #5
    //   793: ifnull -> 810
    //   796: aload #5
    //   798: invokevirtual p : ()Landroidx/compose/ui/d$c;
    //   801: astore #6
    //   803: aload #8
    //   805: astore #7
    //   807: goto -> 434
    //   810: aconst_null
    //   811: astore #6
    //   813: aload #8
    //   815: astore #7
    //   817: goto -> 434
    //   820: aload #7
    //   822: ifnull -> 877
    //   825: aload #7
    //   827: invokeinterface size : ()I
    //   832: iconst_1
    //   833: isub
    //   834: istore_2
    //   835: iload_2
    //   836: iflt -> 877
    //   839: iload_2
    //   840: iconst_1
    //   841: isub
    //   842: istore_3
    //   843: aload #7
    //   845: iload_2
    //   846: invokeinterface get : (I)Ljava/lang/Object;
    //   851: checkcast dbxyzptlk/c1/a
    //   854: aload_1
    //   855: invokeinterface K0 : (Ldbxyzptlk/c1/c;)Z
    //   860: ifeq -> 865
    //   863: iconst_1
    //   864: ireturn
    //   865: iload_3
    //   866: ifge -> 872
    //   869: goto -> 877
    //   872: iload_3
    //   873: istore_2
    //   874: goto -> 839
    //   877: aload #11
    //   879: invokeinterface Q0 : ()Landroidx/compose/ui/d$c;
    //   884: astore #8
    //   886: aconst_null
    //   887: astore #5
    //   889: aload #8
    //   891: ifnull -> 1113
    //   894: aload #8
    //   896: instanceof dbxyzptlk/c1/a
    //   899: ifeq -> 922
    //   902: aload #5
    //   904: astore #6
    //   906: aload #8
    //   908: checkcast dbxyzptlk/c1/a
    //   911: aload_1
    //   912: invokeinterface K0 : (Ldbxyzptlk/c1/c;)Z
    //   917: ifeq -> 1099
    //   920: iconst_1
    //   921: ireturn
    //   922: aload #5
    //   924: astore #6
    //   926: aload #8
    //   928: invokevirtual M1 : ()I
    //   931: iload #4
    //   933: iand
    //   934: ifeq -> 1099
    //   937: aload #5
    //   939: astore #6
    //   941: aload #8
    //   943: instanceof dbxyzptlk/f1/i
    //   946: ifeq -> 1099
    //   949: aload #8
    //   951: checkcast dbxyzptlk/f1/i
    //   954: invokevirtual l2 : ()Landroidx/compose/ui/d$c;
    //   957: astore #6
    //   959: iconst_0
    //   960: istore_3
    //   961: aload #6
    //   963: ifnull -> 1087
    //   966: aload #8
    //   968: astore #9
    //   970: aload #5
    //   972: astore #10
    //   974: iload_3
    //   975: istore_2
    //   976: aload #6
    //   978: invokevirtual M1 : ()I
    //   981: iload #4
    //   983: iand
    //   984: ifeq -> 1067
    //   987: iload_3
    //   988: iconst_1
    //   989: iadd
    //   990: istore_2
    //   991: iload_2
    //   992: iconst_1
    //   993: if_icmpne -> 1007
    //   996: aload #6
    //   998: astore #9
    //   1000: aload #5
    //   1002: astore #10
    //   1004: goto -> 1067
    //   1007: aload #5
    //   1009: astore #9
    //   1011: aload #5
    //   1013: ifnonnull -> 1031
    //   1016: new dbxyzptlk/z0/d
    //   1019: dup
    //   1020: bipush #16
    //   1022: anewarray androidx/compose/ui/d$c
    //   1025: iconst_0
    //   1026: invokespecial <init> : ([Ljava/lang/Object;I)V
    //   1029: astore #9
    //   1031: aload #8
    //   1033: astore #5
    //   1035: aload #8
    //   1037: ifnull -> 1051
    //   1040: aload #9
    //   1042: aload #8
    //   1044: invokevirtual c : (Ljava/lang/Object;)Z
    //   1047: pop
    //   1048: aconst_null
    //   1049: astore #5
    //   1051: aload #9
    //   1053: aload #6
    //   1055: invokevirtual c : (Ljava/lang/Object;)Z
    //   1058: pop
    //   1059: aload #9
    //   1061: astore #10
    //   1063: aload #5
    //   1065: astore #9
    //   1067: aload #6
    //   1069: invokevirtual I1 : ()Landroidx/compose/ui/d$c;
    //   1072: astore #6
    //   1074: aload #9
    //   1076: astore #8
    //   1078: aload #10
    //   1080: astore #5
    //   1082: iload_2
    //   1083: istore_3
    //   1084: goto -> 961
    //   1087: aload #5
    //   1089: astore #6
    //   1091: iload_3
    //   1092: iconst_1
    //   1093: if_icmpne -> 1099
    //   1096: goto -> 889
    //   1099: aload #6
    //   1101: invokestatic b : (Ldbxyzptlk/z0/d;)Landroidx/compose/ui/d$c;
    //   1104: astore #8
    //   1106: aload #6
    //   1108: astore #5
    //   1110: goto -> 889
    //   1113: aload #11
    //   1115: invokeinterface Q0 : ()Landroidx/compose/ui/d$c;
    //   1120: astore #8
    //   1122: aconst_null
    //   1123: astore #5
    //   1125: aload #8
    //   1127: ifnull -> 1349
    //   1130: aload #8
    //   1132: instanceof dbxyzptlk/c1/a
    //   1135: ifeq -> 1158
    //   1138: aload #5
    //   1140: astore #6
    //   1142: aload #8
    //   1144: checkcast dbxyzptlk/c1/a
    //   1147: aload_1
    //   1148: invokeinterface w1 : (Ldbxyzptlk/c1/c;)Z
    //   1153: ifeq -> 1335
    //   1156: iconst_1
    //   1157: ireturn
    //   1158: aload #5
    //   1160: astore #6
    //   1162: aload #8
    //   1164: invokevirtual M1 : ()I
    //   1167: iload #4
    //   1169: iand
    //   1170: ifeq -> 1335
    //   1173: aload #5
    //   1175: astore #6
    //   1177: aload #8
    //   1179: instanceof dbxyzptlk/f1/i
    //   1182: ifeq -> 1335
    //   1185: aload #8
    //   1187: checkcast dbxyzptlk/f1/i
    //   1190: invokevirtual l2 : ()Landroidx/compose/ui/d$c;
    //   1193: astore #6
    //   1195: iconst_0
    //   1196: istore_3
    //   1197: aload #6
    //   1199: ifnull -> 1323
    //   1202: aload #8
    //   1204: astore #9
    //   1206: aload #5
    //   1208: astore #10
    //   1210: iload_3
    //   1211: istore_2
    //   1212: aload #6
    //   1214: invokevirtual M1 : ()I
    //   1217: iload #4
    //   1219: iand
    //   1220: ifeq -> 1303
    //   1223: iload_3
    //   1224: iconst_1
    //   1225: iadd
    //   1226: istore_2
    //   1227: iload_2
    //   1228: iconst_1
    //   1229: if_icmpne -> 1243
    //   1232: aload #6
    //   1234: astore #9
    //   1236: aload #5
    //   1238: astore #10
    //   1240: goto -> 1303
    //   1243: aload #5
    //   1245: astore #9
    //   1247: aload #5
    //   1249: ifnonnull -> 1267
    //   1252: new dbxyzptlk/z0/d
    //   1255: dup
    //   1256: bipush #16
    //   1258: anewarray androidx/compose/ui/d$c
    //   1261: iconst_0
    //   1262: invokespecial <init> : ([Ljava/lang/Object;I)V
    //   1265: astore #9
    //   1267: aload #8
    //   1269: astore #5
    //   1271: aload #8
    //   1273: ifnull -> 1287
    //   1276: aload #9
    //   1278: aload #8
    //   1280: invokevirtual c : (Ljava/lang/Object;)Z
    //   1283: pop
    //   1284: aconst_null
    //   1285: astore #5
    //   1287: aload #9
    //   1289: aload #6
    //   1291: invokevirtual c : (Ljava/lang/Object;)Z
    //   1294: pop
    //   1295: aload #9
    //   1297: astore #10
    //   1299: aload #5
    //   1301: astore #9
    //   1303: aload #6
    //   1305: invokevirtual I1 : ()Landroidx/compose/ui/d$c;
    //   1308: astore #6
    //   1310: aload #9
    //   1312: astore #8
    //   1314: aload #10
    //   1316: astore #5
    //   1318: iload_2
    //   1319: istore_3
    //   1320: goto -> 1197
    //   1323: aload #5
    //   1325: astore #6
    //   1327: iload_3
    //   1328: iconst_1
    //   1329: if_icmpne -> 1335
    //   1332: goto -> 1125
    //   1335: aload #6
    //   1337: invokestatic b : (Ldbxyzptlk/z0/d;)Landroidx/compose/ui/d$c;
    //   1340: astore #8
    //   1342: aload #6
    //   1344: astore #5
    //   1346: goto -> 1125
    //   1349: aload #7
    //   1351: ifnull -> 1407
    //   1354: aload #7
    //   1356: invokeinterface size : ()I
    //   1361: istore_3
    //   1362: iconst_0
    //   1363: istore_2
    //   1364: iload_2
    //   1365: iload_3
    //   1366: if_icmpge -> 1407
    //   1369: aload #7
    //   1371: iload_2
    //   1372: invokeinterface get : (I)Ljava/lang/Object;
    //   1377: checkcast dbxyzptlk/c1/a
    //   1380: aload_1
    //   1381: invokeinterface w1 : (Ldbxyzptlk/c1/c;)Z
    //   1386: ifeq -> 1391
    //   1389: iconst_1
    //   1390: ireturn
    //   1391: iinc #2, 1
    //   1394: goto -> 1364
    //   1397: new java/lang/IllegalStateException
    //   1400: dup
    //   1401: ldc 'visitAncestors called on an unattached node'
    //   1403: invokespecial <init> : (Ljava/lang/String;)V
    //   1406: athrow
    //   1407: iconst_0
    //   1408: ireturn
  }
  
  public boolean l(int paramInt) {
    FocusTargetNode focusTargetNode = k.b(this.a);
    boolean bool = false;
    boolean bool1 = false;
    if (focusTargetNode == null)
      return false; 
    g g1 = k.a(focusTargetNode, paramInt, q());
    g.a a = g.b;
    if (g1 != a.b()) {
      boolean bool2 = bool1;
      if (g1 != a.a()) {
        bool2 = bool1;
        if (g1.c())
          bool2 = true; 
      } 
      return bool2;
    } 
    G g = new G();
    bool1 = k.e(this.a, paramInt, q(), (l)new b(focusTargetNode, this, paramInt, g));
    null = bool;
    if (!g.a) {
      if (!bool1) {
        null = bool;
        return u(paramInt) ? true : null;
      } 
    } else {
      return null;
    } 
    return true;
  }
  
  public void m(FocusTargetNode paramFocusTargetNode) {
    this.b.d(paramFocusTargetNode);
  }
  
  public h n() {
    FocusTargetNode focusTargetNode = k.b(this.a);
    if (focusTargetNode != null) {
      h h = k.d(focusTargetNode);
    } else {
      focusTargetNode = null;
    } 
    return (h)focusTargetNode;
  }
  
  public void o() {
    j.c(this.a, true, true);
  }
  
  public void p(boolean paramBoolean) {
    i(paramBoolean, true);
  }
  
  public t q() {
    t t1 = this.e;
    if (t1 != null)
      return t1; 
    s.u("layoutDirection");
    return null;
  }
  
  public final FocusTargetNode r() {
    return this.a;
  }
  
  public final d.c s(g paramg) {
    int i = K.a(1024) | K.a(8192);
    if (paramg.Q0().R1()) {
      d.c c1 = paramg.Q0();
      int k = c1.H1();
      d.c c3 = null;
      d.c c2 = null;
      if ((k & i) != 0) {
        c1 = c1.I1();
        while (true) {
          c3 = c2;
          if (c1 != null) {
            c3 = c2;
            if ((c1.M1() & i) != 0) {
              if ((K.a(1024) & c1.M1()) != 0)
                return c2; 
              c3 = c1;
            } 
            c1 = c1.I1();
            c2 = c3;
            continue;
          } 
          break;
        } 
      } 
      return c3;
    } 
    throw new IllegalStateException("visitLocalDescendants called on an unattached node");
  }
  
  public final boolean t(KeyEvent paramKeyEvent) {
    u u1;
    long l = d.a(paramKeyEvent);
    int i = d.b(paramKeyEvent);
    c.a a = c.a;
    if (c.e(i, a.a())) {
      u u2 = this.f;
      u1 = u2;
      if (u2 == null) {
        u1 = new u(3);
        this.f = u1;
      } 
      u1.k(l);
    } else if (c.e(i, u1.b())) {
      u1 = this.f;
      if (u1 != null && u1.a(l) == true) {
        u1 = this.f;
        if (u1 != null)
          u1.l(l); 
      } else {
        return false;
      } 
    } 
    return true;
  }
  
  public final boolean u(int paramInt) {
    if (this.a.r2().getHasFocus() && !this.a.r2().isFocused()) {
      boolean bool;
      c.a a = c.b;
      if (c.l(paramInt, a.e())) {
        bool = true;
      } else {
        bool = c.l(paramInt, a.f());
      } 
      if (bool) {
        p(false);
        return !this.a.r2().isFocused() ? false : l(paramInt);
      } 
    } 
    return false;
  }
  
  @Metadata(d1 = {"\000/\n\000\n\002\030\002\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\002\n\002\020\b\n\002\b\002\n\002\020\000\n\000\n\002\020\013\n\002\b\003*\001\000\b\n\030\0002\b\022\004\022\0020\0020\001J\017\020\003\032\0020\002H\026¢\006\004\b\003\020\004J\027\020\007\032\0020\0062\006\020\005\032\0020\002H\026¢\006\004\b\007\020\bJ\017\020\n\032\0020\tH\026¢\006\004\b\n\020\013J\032\020\017\032\0020\0162\b\020\r\032\004\030\0010\fH\002¢\006\004\b\017\020\020¨\006\021"}, d2 = {"androidx/compose/ui/focus/FocusOwnerImpl$modifier$1", "Ldbxyzptlk/f1/G;", "Landroidx/compose/ui/focus/FocusTargetNode;", "i", "()Landroidx/compose/ui/focus/FocusTargetNode;", "node", "Ldbxyzptlk/pI/D;", "k", "(Landroidx/compose/ui/focus/FocusTargetNode;)V", "", "hashCode", "()I", "", "other", "", "equals", "(Ljava/lang/Object;)Z", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class FocusOwnerImpl$modifier$1 extends G<FocusTargetNode> {
    public final FocusOwnerImpl b;
    
    public FocusOwnerImpl$modifier$1(FocusOwnerImpl param1FocusOwnerImpl) {}
    
    public boolean equals(Object param1Object) {
      boolean bool;
      if (param1Object == this) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    public int hashCode() {
      return this.b.r().hashCode();
    }
    
    public FocusTargetNode i() {
      return this.b.r();
    }
    
    public void k(FocusTargetNode param1FocusTargetNode) {}
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compos\\ui\focus\FocusOwnerImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */