package androidx.compose.ui.focus;

import androidx.compose.ui.d;
import androidx.compose.ui.node.f;
import androidx.compose.ui.node.l;
import dbxyzptlk.DI.K;
import dbxyzptlk.DI.s;
import dbxyzptlk.O0.d;
import dbxyzptlk.O0.e;
import dbxyzptlk.O0.k;
import dbxyzptlk.O0.q;
import dbxyzptlk.O0.r;
import dbxyzptlk.O0.t;
import dbxyzptlk.O0.u;
import dbxyzptlk.d1.c;
import dbxyzptlk.d1.d;
import dbxyzptlk.e1.c;
import dbxyzptlk.e1.h;
import dbxyzptlk.f1.G;
import dbxyzptlk.f1.K;
import dbxyzptlk.f1.N;
import dbxyzptlk.f1.O;
import dbxyzptlk.f1.e;
import dbxyzptlk.f1.g;
import dbxyzptlk.f1.h;
import dbxyzptlk.f1.i;
import dbxyzptlk.pI.D;
import dbxyzptlk.z0.d;
import kotlin.Metadata;

@Metadata(d1 = {"\000D\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\005\n\002\020\013\n\002\b\005\n\002\030\002\n\002\b\n\n\002\030\002\n\002\b\005\b\000\030\0002\0020\0012\0020\0022\0020\0032\0020\0042\0020\005:\001&B\007¢\006\004\b\006\020\007J\017\020\t\032\0020\bH\026¢\006\004\b\t\020\007J\017\020\n\032\0020\bH\026¢\006\004\b\n\020\007J\017\020\f\032\0020\013H\000¢\006\004\b\f\020\rJ\017\020\016\032\0020\bH\000¢\006\004\b\016\020\007J\017\020\017\032\0020\bH\000¢\006\004\b\017\020\007J\017\020\020\032\0020\bH\000¢\006\004\b\020\020\007R\026\020\024\032\0020\0218\002@\002X\016¢\006\006\n\004\b\022\020\023R\026\020\026\032\0020\0218\002@\002X\016¢\006\006\n\004\b\025\020\023R\026\020\032\032\0020\0278\002@\002X\016¢\006\006\n\004\b\030\020\031R*\020!\032\0020\0272\006\020\033\032\0020\0278V@VX\016¢\006\022\022\004\b \020\007\032\004\b\034\020\035\"\004\b\036\020\037R\023\020%\032\004\030\0010\"8F¢\006\006\032\004\b#\020$¨\006'"}, d2 = {"Landroidx/compose/ui/focus/FocusTargetNode;", "Ldbxyzptlk/f1/e;", "Ldbxyzptlk/O0/r;", "Ldbxyzptlk/f1/N;", "Ldbxyzptlk/e1/h;", "Landroidx/compose/ui/d$c;", "<init>", "()V", "Ldbxyzptlk/pI/D;", "U0", "W1", "Landroidx/compose/ui/focus/e;", "p2", "()Landroidx/compose/ui/focus/e;", "o2", "s2", "t2", "", "n", "Z", "isProcessingCustomExit", "o", "isProcessingCustomEnter", "Ldbxyzptlk/O0/q;", "p", "Ldbxyzptlk/O0/q;", "committedFocusState", "value", "r2", "()Ldbxyzptlk/O0/q;", "u2", "(Ldbxyzptlk/O0/q;)V", "getFocusState$annotations", "focusState", "Ldbxyzptlk/d1/c;", "q2", "()Ldbxyzptlk/d1/c;", "beyondBoundsLayoutParent", "FocusTargetElement", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class FocusTargetNode extends d.c implements e, r, N, h {
  public boolean n;
  
  public boolean o;
  
  public q p = q.Inactive;
  
  public void U0() {
    q q1 = r2();
    s2();
    if (q1 != r2())
      e.c(this); 
  }
  
  public void W1() {
    q q1 = r2();
    int i = a.a[q1.ordinal()];
    if (i != 1 && i != 2) {
      if (i != 3) {
        if (i == 4)
          t2(); 
      } else {
        t2();
        u u = t.d(this);
        try {
          if (u.e(u))
            u.b(u); 
        } finally {
          Exception exception;
        } 
        u.a(u);
        u2(q.Inactive);
        D d = D.a;
        u.c(u);
      } 
    } else {
      h.l((g)this).getFocusOwner().p(true);
    } 
  }
  
  public final void o2() {
    q q1 = t.d(this).i(this);
    if (q1 != null) {
      this.p = q1;
      return;
    } 
    throw new IllegalStateException("committing a node that was not updated in the current transaction");
  }
  
  public final e p2() {
    f f = new f();
    int k = K.a(2048);
    int i = K.a(1024);
    d.c c1 = Q0();
    int j = k | i;
    if (Q0().R1()) {
      d.c c2 = Q0();
      f f1 = h.k((g)this);
      label60: while (f1 != null) {
        if ((f1.i0().k().H1() & j) != 0)
          for (d.c c3 = c2; c3 != null; c3 = c3.O1()) {
            if ((c3.M1() & j) != 0) {
              if (c3 != c1 && (c3.M1() & i) != 0)
                break label60; 
              if ((c3.M1() & k) != 0) {
                d.c c4 = c3;
                c2 = null;
                while (c4 != null) {
                  d d2;
                  if (c4 instanceof k) {
                    ((k)c4).j1((e)f);
                    d.c c5 = c2;
                  } else {
                    d.c c5 = c2;
                    if ((c4.M1() & k) != 0) {
                      c5 = c2;
                      if (c4 instanceof i) {
                        d d;
                        c5 = ((i)c4).l2();
                        int m;
                        for (m = 0; c5 != null; m = n) {
                          d d3;
                          d.c c6 = c4;
                          d.c c7 = c2;
                          int n = m;
                          if ((c5.M1() & k) != 0) {
                            n = m + 1;
                            if (n == 1) {
                              c6 = c5;
                              c7 = c2;
                            } else {
                              d d4;
                              c6 = c2;
                              if (c2 == null)
                                d4 = new d((Object[])new d.c[16], 0); 
                              c2 = c4;
                              if (c4 != null) {
                                d4.c(c4);
                                c2 = null;
                              } 
                              d4.c(c5);
                              d3 = d4;
                              c6 = c2;
                            } 
                          } 
                          c5 = c5.I1();
                          c4 = c6;
                          d = d3;
                        } 
                        d2 = d;
                        if (m == 1)
                          continue; 
                      } 
                    } 
                  } 
                  c4 = h.b(d2);
                  d d1 = d2;
                } 
              } 
            } 
          }  
        f1 = f1.m0();
        if (f1 != null) {
          l l = f1.i0();
          if (l != null) {
            d.c c3 = l.p();
            continue;
          } 
        } 
        c2 = null;
      } 
      return (e)f;
    } 
    throw new IllegalStateException("visitAncestors called on an unattached node");
  }
  
  public final c q2() {
    return (c)b((c)d.a());
  }
  
  public q r2() {
    u u = t.a(this);
    if (u != null) {
      q q2 = u.i(this);
      q q1 = q2;
      return (q2 == null) ? this.p : q1;
    } 
    return this.p;
  }
  
  public final void s2() {
    q q1 = r2();
    int i = a.a[q1.ordinal()];
    if (i == 1 || i == 2) {
      K k = new K();
      O.a(this, (dbxyzptlk.CI.a)new b(k, this));
      Object object = k.a;
      if (object == null) {
        s.u("focusProperties");
        object = null;
      } else {
        object = object;
      } 
      if (!object.m())
        h.l((g)this).getFocusOwner().p(true); 
    } 
  }
  
  public final void t2() {
    d.c c2 = Q0();
    int i = K.a(4096);
    d.c c1 = null;
    while (c2 != null) {
      d d2;
      if (c2 instanceof d) {
        e.b((d)c2);
        d.c c3 = c1;
      } else {
        d.c c3 = c1;
        if ((c2.M1() & i) != 0) {
          c3 = c1;
          if (c2 instanceof i) {
            d d;
            c3 = ((i)c2).l2();
            int k;
            for (k = 0; c3 != null; k = m) {
              d d3;
              d.c c4 = c2;
              d.c c5 = c1;
              int m = k;
              if ((c3.M1() & i) != 0) {
                m = k + 1;
                if (m == 1) {
                  c4 = c3;
                  c5 = c1;
                } else {
                  d d4;
                  c4 = c1;
                  if (c1 == null)
                    d4 = new d((Object[])new d.c[16], 0); 
                  c1 = c2;
                  if (c2 != null) {
                    d4.c(c2);
                    c1 = null;
                  } 
                  d4.c(c3);
                  d3 = d4;
                  c4 = c1;
                } 
              } 
              c3 = c3.I1();
              c2 = c4;
              d = d3;
            } 
            d2 = d;
            if (k == 1)
              continue; 
          } 
        } 
      } 
      c2 = h.b(d2);
      d d1 = d2;
    } 
    int j = K.a(4096) | K.a(1024);
    if (Q0().R1()) {
      c1 = Q0().O1();
      f f = h.k((g)this);
      while (f != null) {
        if ((f.i0().k().H1() & j) != 0)
          for (d.c c3 = c1; c3 != null; c3 = c3.O1()) {
            if ((c3.M1() & j) != 0 && (K.a(1024) & c3.M1()) == 0 && c3.R1()) {
              i = K.a(4096);
              c1 = null;
              d.c c4 = c3;
              while (c4 != null) {
                d d2;
                if (c4 instanceof d) {
                  e.b((d)c4);
                  c2 = c1;
                } else {
                  c2 = c1;
                  if ((c4.M1() & i) != 0) {
                    c2 = c1;
                    if (c4 instanceof i) {
                      d d;
                      c2 = ((i)c4).l2();
                      int k;
                      for (k = 0; c2 != null; k = m) {
                        d d3;
                        d.c c5 = c4;
                        d.c c6 = c1;
                        int m = k;
                        if ((c2.M1() & i) != 0) {
                          m = k + 1;
                          if (m == 1) {
                            c5 = c2;
                            c6 = c1;
                          } else {
                            d d4;
                            c5 = c1;
                            if (c1 == null)
                              d4 = new d((Object[])new d.c[16], 0); 
                            c1 = c4;
                            if (c4 != null) {
                              d4.c(c4);
                              c1 = null;
                            } 
                            d4.c(c2);
                            d3 = d4;
                            c5 = c1;
                          } 
                        } 
                        c2 = c2.I1();
                        c4 = c5;
                        d = d3;
                      } 
                      d2 = d;
                      if (k == 1)
                        continue; 
                    } 
                  } 
                } 
                c4 = h.b(d2);
                d d1 = d2;
              } 
            } 
          }  
        f = f.m0();
        if (f != null) {
          l l = f.i0();
          if (l != null) {
            d.c c3 = l.p();
            continue;
          } 
        } 
        c1 = null;
      } 
      return;
    } 
    throw new IllegalStateException("visitAncestors called on an unattached node");
  }
  
  public void u2(q paramq) {
    t.d(this).j(this, paramq);
  }
  
  @Metadata(d1 = {"\000.\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\002\n\002\020\b\n\002\b\002\n\002\020\000\n\000\n\002\020\013\n\002\b\003\bÀ\002\030\0002\b\022\004\022\0020\0020\001B\t\b\002¢\006\004\b\003\020\004J\017\020\005\032\0020\002H\026¢\006\004\b\005\020\006J\027\020\t\032\0020\b2\006\020\007\032\0020\002H\026¢\006\004\b\t\020\nJ\017\020\f\032\0020\013H\026¢\006\004\b\f\020\rJ\032\020\021\032\0020\0202\b\020\017\032\004\030\0010\016H\002¢\006\004\b\021\020\022¨\006\023"}, d2 = {"Landroidx/compose/ui/focus/FocusTargetNode$FocusTargetElement;", "Ldbxyzptlk/f1/G;", "Landroidx/compose/ui/focus/FocusTargetNode;", "<init>", "()V", "i", "()Landroidx/compose/ui/focus/FocusTargetNode;", "node", "Ldbxyzptlk/pI/D;", "k", "(Landroidx/compose/ui/focus/FocusTargetNode;)V", "", "hashCode", "()I", "", "other", "", "equals", "(Ljava/lang/Object;)Z", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class FocusTargetElement extends G<FocusTargetNode> {
    public static final FocusTargetElement b = new FocusTargetElement();
    
    public boolean equals(Object param1Object) {
      boolean bool;
      if (param1Object == this) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    public int hashCode() {
      return 1739042953;
    }
    
    public FocusTargetNode i() {
      return new FocusTargetNode();
    }
    
    public void k(FocusTargetNode param1FocusTargetNode) {}
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compos\\ui\focus\FocusTargetNode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */