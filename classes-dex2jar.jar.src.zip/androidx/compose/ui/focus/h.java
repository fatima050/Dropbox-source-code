package androidx.compose.ui.focus;

import androidx.compose.ui.d;
import kotlin.Metadata;

@Metadata(d1 = {"\000\f\n\002\030\002\n\002\030\002\n\002\b\004\032\031\020\003\032\0020\000*\0020\0002\006\020\002\032\0020\001¢\006\004\b\003\020\004¨\006\005"}, d2 = {"Landroidx/compose/ui/d;", "Landroidx/compose/ui/focus/g;", "focusRequester", "a", "(Landroidx/compose/ui/d;Landroidx/compose/ui/focus/g;)Landroidx/compose/ui/d;", "ui_release"}, k = 2, mv = {1, 8, 0}, xi = 48)
public final class h {
  public static final d a(d paramd, g paramg) {
    return paramd.g((d)new FocusRequesterElement(paramg));
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compos\\ui\focus\h.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */