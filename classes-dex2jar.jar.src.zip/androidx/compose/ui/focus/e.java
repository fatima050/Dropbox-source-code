package androidx.compose.ui.focus;

import dbxyzptlk.CI.l;
import kotlin.Metadata;

@Metadata(d1 = {"\000$\n\002\030\002\n\002\020\000\n\002\020\013\n\002\b\005\n\002\030\002\n\002\b\033\n\002\030\002\n\002\030\002\n\002\b\f\bf\030\0002\0020\001R\034\020\007\032\0020\0028&@&X¦\016¢\006\f\032\004\b\003\020\004\"\004\b\005\020\006R$\020\016\032\0020\b2\006\020\t\032\0020\b8V@VX\016¢\006\f\032\004\b\n\020\013\"\004\b\f\020\rR$\020\021\032\0020\b2\006\020\t\032\0020\b8V@VX\016¢\006\f\032\004\b\017\020\013\"\004\b\020\020\rR$\020\024\032\0020\b2\006\020\t\032\0020\b8V@VX\016¢\006\f\032\004\b\022\020\013\"\004\b\023\020\rR$\020\027\032\0020\b2\006\020\t\032\0020\b8V@VX\016¢\006\f\032\004\b\025\020\013\"\004\b\026\020\rR$\020\032\032\0020\b2\006\020\t\032\0020\b8V@VX\016¢\006\f\032\004\b\030\020\013\"\004\b\031\020\rR$\020\035\032\0020\b2\006\020\t\032\0020\b8V@VX\016¢\006\f\032\004\b\033\020\013\"\004\b\034\020\rR$\020 \032\0020\b2\006\020\t\032\0020\b8V@VX\016¢\006\f\032\004\b\036\020\013\"\004\b\037\020\rR$\020#\032\0020\b2\006\020\t\032\0020\b8V@VX\016¢\006\f\032\004\b!\020\013\"\004\b\"\020\rRB\020,\032\016\022\004\022\0020%\022\004\022\0020\b0$2\022\020\t\032\016\022\004\022\0020%\022\004\022\0020\b0$8W@WX\016¢\006\022\022\004\b*\020+\032\004\b&\020'\"\004\b(\020)RB\0200\032\016\022\004\022\0020%\022\004\022\0020\b0$2\022\020\t\032\016\022\004\022\0020%\022\004\022\0020\b0$8W@WX\016¢\006\022\022\004\b/\020+\032\004\b-\020'\"\004\b.\020)ø\001\000\002\006\n\004\b!0\001¨\0061À\006\001"}, d2 = {"Landroidx/compose/ui/focus/e;", "", "", "m", "()Z", "i", "(Z)V", "canFocus", "Landroidx/compose/ui/focus/g;", "<anonymous parameter 0>", "getNext", "()Landroidx/compose/ui/focus/g;", "setNext", "(Landroidx/compose/ui/focus/g;)V", "next", "j", "setPrevious", "previous", "f", "setUp", "up", "h", "setDown", "down", "b", "setLeft", "left", "a", "setRight", "right", "e", "setStart", "start", "k", "setEnd", "end", "Lkotlin/Function1;", "Landroidx/compose/ui/focus/c;", "l", "()Ldbxyzptlk/CI/l;", "setEnter", "(Ldbxyzptlk/CI/l;)V", "getEnter$annotations", "()V", "enter", "g", "setExit", "getExit$annotations", "exit", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public interface e {
  default g a() {
    return g.b.b();
  }
  
  default g b() {
    return g.b.b();
  }
  
  default g e() {
    return g.b.b();
  }
  
  default g f() {
    return g.b.b();
  }
  
  default l<c, g> g() {
    return (l<c, g>)b.f;
  }
  
  default g getNext() {
    return g.b.b();
  }
  
  default g h() {
    return g.b.b();
  }
  
  void i(boolean paramBoolean);
  
  default g j() {
    return g.b.b();
  }
  
  default g k() {
    return g.b.b();
  }
  
  default l<c, g> l() {
    return (l<c, g>)a.f;
  }
  
  boolean m();
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compos\\ui\focus\e.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */