package androidx.compose.ui.focus;

import androidx.compose.ui.d;
import dbxyzptlk.CI.l;
import dbxyzptlk.DI.s;
import dbxyzptlk.O0.b;
import dbxyzptlk.O0.p;
import dbxyzptlk.f1.G;
import dbxyzptlk.pI.D;
import kotlin.Metadata;

@Metadata(d1 = {"\000:\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\b\n\002\020\016\n\002\b\002\n\002\020\b\n\002\b\002\n\002\020\000\n\000\n\002\020\013\n\002\b\007\b\b\030\0002\b\022\004\022\0020\0020\001B\033\022\022\020\006\032\016\022\004\022\0020\004\022\004\022\0020\0050\003¢\006\004\b\007\020\bJ\017\020\t\032\0020\002H\026¢\006\004\b\t\020\nJ\027\020\f\032\0020\0052\006\020\013\032\0020\002H\026¢\006\004\b\f\020\rJ\020\020\017\032\0020\016HÖ\001¢\006\004\b\017\020\020J\020\020\022\032\0020\021HÖ\001¢\006\004\b\022\020\023J\032\020\027\032\0020\0262\b\020\025\032\004\030\0010\024HÖ\003¢\006\004\b\027\020\030R#\020\006\032\016\022\004\022\0020\004\022\004\022\0020\0050\0038\006¢\006\f\n\004\b\031\020\032\032\004\b\033\020\034¨\006\035"}, d2 = {"Landroidx/compose/ui/focus/FocusChangedElement;", "Ldbxyzptlk/f1/G;", "Ldbxyzptlk/O0/b;", "Lkotlin/Function1;", "Ldbxyzptlk/O0/p;", "Ldbxyzptlk/pI/D;", "onFocusChanged", "<init>", "(Ldbxyzptlk/CI/l;)V", "i", "()Ldbxyzptlk/O0/b;", "node", "k", "(Ldbxyzptlk/O0/b;)V", "", "toString", "()Ljava/lang/String;", "", "hashCode", "()I", "", "other", "", "equals", "(Ljava/lang/Object;)Z", "b", "Ldbxyzptlk/CI/l;", "getOnFocusChanged", "()Ldbxyzptlk/CI/l;", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
final class FocusChangedElement extends G<b> {
  public final l<p, D> b;
  
  public FocusChangedElement(l<? super p, D> paraml) {
    this.b = (l)paraml;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof FocusChangedElement))
      return false; 
    paramObject = paramObject;
    return !!s.c(this.b, ((FocusChangedElement)paramObject).b);
  }
  
  public int hashCode() {
    return this.b.hashCode();
  }
  
  public b i() {
    return new b(this.b);
  }
  
  public void k(b paramb) {
    paramb.k2(this.b);
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("FocusChangedElement(onFocusChanged=");
    stringBuilder.append(this.b);
    stringBuilder.append(')');
    return stringBuilder.toString();
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compos\\ui\focus\FocusChangedElement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */