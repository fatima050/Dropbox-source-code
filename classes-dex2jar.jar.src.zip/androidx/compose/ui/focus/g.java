package androidx.compose.ui.focus;

import androidx.compose.ui.d;
import dbxyzptlk.CI.l;
import dbxyzptlk.O0.n;
import dbxyzptlk.f1.K;
import dbxyzptlk.f1.h;
import dbxyzptlk.f1.i;
import dbxyzptlk.z0.d;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

@Metadata(d1 = {"\000&\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\000\n\002\020\013\n\002\b\002\n\002\030\002\n\002\030\002\n\002\b\007\b\007\030\000 \0202\0020\001:\001\013B\007¢\006\004\b\002\020\003J\r\020\005\032\0020\004¢\006\004\b\005\020\003J\017\020\007\032\0020\006H\000¢\006\004\b\007\020\bR \020\017\032\b\022\004\022\0020\n0\t8\000X\004¢\006\f\n\004\b\013\020\f\032\004\b\r\020\016¨\006\021"}, d2 = {"Landroidx/compose/ui/focus/g;", "", "<init>", "()V", "Ldbxyzptlk/pI/D;", "e", "", "c", "()Z", "Ldbxyzptlk/z0/d;", "Ldbxyzptlk/O0/n;", "a", "Ldbxyzptlk/z0/d;", "d", "()Ldbxyzptlk/z0/d;", "focusRequesterNodes", "b", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class g {
  public static final a b = new a(null);
  
  public static final g c = new g();
  
  public static final g d = new g();
  
  public final d<n> a = new d((Object[])new n[16], 0);
  
  public final boolean c() {
    a a1 = b;
    if (this != a1.b()) {
      if (this != a1.a()) {
        if (this.a.w()) {
          d<n> d1 = this.a;
          int i = d1.p();
          boolean bool = false;
          if (i > 0) {
            Object[] arrayOfObject = d1.o();
            int j = 0;
            boolean bool1 = false;
            while (true) {
              n n = (n)arrayOfObject[j];
              int k = K.a(1024);
              if (n.Q0().R1()) {
                d d2 = new d((Object[])new d.c[16], 0);
                d.c c = n.Q0().I1();
                if (c == null) {
                  h.a(d2, n.Q0());
                } else {
                  d2.c(c);
                } 
                label83: while (true) {
                  bool = bool1;
                  if (d2.w()) {
                    c = (d.c)d2.C(d2.p() - 1);
                    d.c c1 = c;
                    if ((c.H1() & k) == 0) {
                      h.a(d2, c);
                      continue;
                    } 
                    while (c1 != null) {
                      if ((c1.M1() & k) != 0) {
                        c = null;
                        while (c1 != null) {
                          d d4;
                          if (c1 instanceof FocusTargetNode) {
                            FocusTargetNode focusTargetNode = (FocusTargetNode)c1;
                            if (focusTargetNode.p2().m()) {
                              bool = j.j(focusTargetNode);
                            } else {
                              bool = m.k(focusTargetNode, c.b.b(), (l)b.f);
                            } 
                            d.c c2 = c;
                            if (bool) {
                              bool = true;
                              break label83;
                            } 
                          } else {
                            int i1;
                            if ((c1.M1() & k) != 0) {
                              i1 = 1;
                            } else {
                              i1 = 0;
                            } 
                            d.c c2 = c;
                            if (i1) {
                              c2 = c;
                              if (c1 instanceof i) {
                                d d5;
                                c2 = ((i)c1).l2();
                                for (i1 = 0; c2 != null; i1 = i2) {
                                  boolean bool2;
                                  d d6;
                                  if ((c2.M1() & k) != 0) {
                                    bool2 = true;
                                  } else {
                                    bool2 = false;
                                  } 
                                  d.c c3 = c1;
                                  d.c c4 = c;
                                  int i2 = i1;
                                  if (bool2) {
                                    i2 = i1 + 1;
                                    if (i2 == 1) {
                                      c3 = c2;
                                      c4 = c;
                                    } else {
                                      d d7;
                                      c3 = c;
                                      if (c == null)
                                        d7 = new d((Object[])new d.c[16], 0); 
                                      c = c1;
                                      if (c1 != null) {
                                        d7.c(c1);
                                        c = null;
                                      } 
                                      d7.c(c2);
                                      d6 = d7;
                                      c3 = c;
                                    } 
                                  } 
                                  c2 = c2.I1();
                                  c1 = c3;
                                  d5 = d6;
                                } 
                                d4 = d5;
                                if (i1 == 1)
                                  continue; 
                              } 
                            } 
                          } 
                          c1 = h.b(d4);
                          d d3 = d4;
                        } 
                        break;
                      } 
                      c1 = c1.I1();
                    } 
                    continue;
                  } 
                  break;
                } 
                int m = j + 1;
                j = m;
                bool1 = bool;
                if (m >= i)
                  break; 
                continue;
              } 
              throw new IllegalStateException("visitChildren called on an unattached node");
            } 
          } 
          return bool;
        } 
        throw new IllegalStateException("\n   FocusRequester is not initialized. Here are some possible fixes:\n\n   1. Remember the FocusRequester: val focusRequester = remember { FocusRequester() }\n   2. Did you forget to add a Modifier.focusRequester() ?\n   3. Are you attempting to request focus during composition? Focus requests should be made in\n   response to some event. Eg Modifier.clickable { focusRequester.requestFocus() }\n");
      } 
      throw new IllegalStateException("\n    Please check whether the focusRequester is FocusRequester.Cancel or FocusRequester.Default\n    before invoking any functions on the focusRequester.\n");
    } 
    throw new IllegalStateException("\n    Please check whether the focusRequester is FocusRequester.Cancel or FocusRequester.Default\n    before invoking any functions on the focusRequester.\n");
  }
  
  public final d<n> d() {
    return this.a;
  }
  
  public final void e() {
    c();
  }
  
  @Metadata(d1 = {"\000\024\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\b\b\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003R\027\020\005\032\0020\0048\006¢\006\f\n\004\b\005\020\006\032\004\b\007\020\bR \020\t\032\0020\0048GX\004¢\006\022\n\004\b\t\020\006\022\004\b\013\020\003\032\004\b\n\020\b¨\006\f"}, d2 = {"Landroidx/compose/ui/focus/g$a;", "", "<init>", "()V", "Landroidx/compose/ui/focus/g;", "Default", "Landroidx/compose/ui/focus/g;", "b", "()Landroidx/compose/ui/focus/g;", "Cancel", "a", "getCancel$annotations", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class a {
    public a() {}
    
    public final g a() {
      return g.a();
    }
    
    public final g b() {
      return g.b();
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compos\\ui\focus\g.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */