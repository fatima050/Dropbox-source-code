package androidx.compose.ui.focus;

import kotlin.Metadata;

@Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\003\032\021\020\001\032\0020\000*\0020\000¢\006\004\b\001\020\002¨\006\003"}, d2 = {"Landroidx/compose/ui/d;", "a", "(Landroidx/compose/ui/d;)Landroidx/compose/ui/d;", "ui_release"}, k = 2, mv = {1, 8, 0}, xi = 48)
public final class d {
  public static final androidx.compose.ui.d a(androidx.compose.ui.d paramd) {
    return paramd.g((androidx.compose.ui.d)FocusTargetNode.FocusTargetElement.b);
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compos\\ui\focus\d.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */