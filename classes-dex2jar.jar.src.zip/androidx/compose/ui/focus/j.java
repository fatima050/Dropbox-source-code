package androidx.compose.ui.focus;

import androidx.compose.ui.d;
import androidx.compose.ui.node.Owner;
import androidx.compose.ui.node.f;
import androidx.compose.ui.node.l;
import androidx.compose.ui.node.n;
import dbxyzptlk.DI.s;
import dbxyzptlk.O0.e;
import dbxyzptlk.O0.q;
import dbxyzptlk.O0.t;
import dbxyzptlk.O0.u;
import dbxyzptlk.f1.K;
import dbxyzptlk.f1.O;
import dbxyzptlk.f1.g;
import dbxyzptlk.f1.h;
import dbxyzptlk.f1.i;
import dbxyzptlk.z0.d;
import kotlin.Metadata;
import kotlin.NoWhenBranchMatchedException;

@Metadata(d1 = {"\000\032\n\002\030\002\n\002\020\013\n\002\b\017\n\002\030\002\n\000\n\002\030\002\n\002\b\006\032\023\020\002\032\0020\001*\0020\000H\000¢\006\004\b\002\020\003\032\023\020\004\032\0020\001*\0020\000H\000¢\006\004\b\004\020\003\032%\020\007\032\0020\001*\0020\0002\b\b\002\020\005\032\0020\0012\006\020\006\032\0020\001H\000¢\006\004\b\007\020\b\032\023\020\t\032\0020\001*\0020\000H\002¢\006\004\b\t\020\003\032'\020\n\032\0020\001*\0020\0002\b\b\002\020\005\032\0020\0012\b\b\002\020\006\032\0020\001H\002¢\006\004\b\n\020\b\032\033\020\f\032\0020\001*\0020\0002\006\020\013\032\0020\000H\002¢\006\004\b\f\020\r\032\023\020\016\032\0020\001*\0020\000H\002¢\006\004\b\016\020\003\032\023\020\017\032\0020\000*\0020\000H\002¢\006\004\b\017\020\020\032\036\020\024\032\0020\023*\0020\0002\006\020\022\032\0020\021H\000ø\001\000¢\006\004\b\024\020\025\032\036\020\026\032\0020\023*\0020\0002\006\020\022\032\0020\021H\000ø\001\000¢\006\004\b\026\020\025\032\036\020\027\032\0020\023*\0020\0002\006\020\022\032\0020\021H\002ø\001\000¢\006\004\b\027\020\025\032\036\020\030\032\0020\023*\0020\0002\006\020\022\032\0020\021H\002ø\001\000¢\006\004\b\030\020\025\002\007\n\005\b¡\0360\001¨\006\031"}, d2 = {"Landroidx/compose/ui/focus/FocusTargetNode;", "", "j", "(Landroidx/compose/ui/focus/FocusTargetNode;)Z", "i", "forced", "refreshFocusEvents", "c", "(Landroidx/compose/ui/focus/FocusTargetNode;ZZ)Z", "d", "a", "childNode", "k", "(Landroidx/compose/ui/focus/FocusTargetNode;Landroidx/compose/ui/focus/FocusTargetNode;)Z", "l", "m", "(Landroidx/compose/ui/focus/FocusTargetNode;)Landroidx/compose/ui/focus/FocusTargetNode;", "Landroidx/compose/ui/focus/c;", "focusDirection", "Ldbxyzptlk/O0/a;", "h", "(Landroidx/compose/ui/focus/FocusTargetNode;I)Ldbxyzptlk/O0/a;", "e", "f", "g", "ui_release"}, k = 2, mv = {1, 8, 0}, xi = 48)
public final class j {
  public static final boolean a(FocusTargetNode paramFocusTargetNode, boolean paramBoolean1, boolean paramBoolean2) {
    paramFocusTargetNode = k.f(paramFocusTargetNode);
    if (paramFocusTargetNode != null) {
      paramBoolean1 = c(paramFocusTargetNode, paramBoolean1, paramBoolean2);
    } else {
      paramBoolean1 = true;
    } 
    return paramBoolean1;
  }
  
  public static final boolean c(FocusTargetNode paramFocusTargetNode, boolean paramBoolean1, boolean paramBoolean2) {
    q q = paramFocusTargetNode.r2();
    int i = a.b[q.ordinal()];
    if (i != 1) {
      if (i != 2) {
        if (i != 3) {
          if (i != 4)
            throw new NoWhenBranchMatchedException(); 
        } else if (a(paramFocusTargetNode, paramBoolean1, paramBoolean2)) {
          paramFocusTargetNode.u2(q.Inactive);
          if (paramBoolean2)
            e.c(paramFocusTargetNode); 
        } else {
          return false;
        } 
      } else {
        boolean bool = paramBoolean1;
        if (paramBoolean1) {
          paramFocusTargetNode.u2(q.Inactive);
          bool = paramBoolean1;
          if (paramBoolean2) {
            e.c(paramFocusTargetNode);
            bool = paramBoolean1;
          } 
        } 
        return bool;
      } 
    } else {
      paramFocusTargetNode.u2(q.Inactive);
      if (paramBoolean2)
        e.c(paramFocusTargetNode); 
    } 
    return true;
  }
  
  public static final boolean d(FocusTargetNode paramFocusTargetNode) {
    O.a(paramFocusTargetNode, (dbxyzptlk.CI.a)new b(paramFocusTargetNode));
    q q = paramFocusTargetNode.r2();
    int i = a.b[q.ordinal()];
    if (i == 3 || i == 4)
      paramFocusTargetNode.u2(q.Active); 
    return true;
  }
  
  public static final dbxyzptlk.O0.a e(FocusTargetNode paramFocusTargetNode, int paramInt) {
    q q = paramFocusTargetNode.r2();
    int i = a.b[q.ordinal()];
    if (i != 1)
      if (i != 2) {
        if (i != 3) {
          if (i != 4)
            throw new NoWhenBranchMatchedException(); 
        } else {
          dbxyzptlk.O0.a a1 = e(m(paramFocusTargetNode), paramInt);
          dbxyzptlk.O0.a a2 = a1;
          if (a1 == dbxyzptlk.O0.a.None)
            a2 = null; 
          a1 = a2;
          if (a2 == null)
            a1 = g(paramFocusTargetNode, paramInt); 
          return a1;
        } 
      } else {
        return dbxyzptlk.O0.a.Cancelled;
      }  
    return dbxyzptlk.O0.a.None;
  }
  
  public static final dbxyzptlk.O0.a f(FocusTargetNode paramFocusTargetNode, int paramInt) {
    if (!FocusTargetNode.k2(paramFocusTargetNode)) {
      FocusTargetNode.m2(paramFocusTargetNode, true);
      try {
        g g = (g)paramFocusTargetNode.p2().l().invoke(c.i(paramInt));
        g.a a = g.b;
        if (g != a.b()) {
          dbxyzptlk.O0.a a1;
          if (g == a.a()) {
            a1 = dbxyzptlk.O0.a.Cancelled;
            FocusTargetNode.m2(paramFocusTargetNode, false);
            return a1;
          } 
          if (a1.c()) {
            a1 = dbxyzptlk.O0.a.Redirected;
          } else {
            a1 = dbxyzptlk.O0.a.RedirectCancelled;
          } 
          FocusTargetNode.m2(paramFocusTargetNode, false);
          return a1;
        } 
      } finally {
        Exception exception;
      } 
      FocusTargetNode.m2(paramFocusTargetNode, false);
    } 
    return dbxyzptlk.O0.a.None;
  }
  
  public static final dbxyzptlk.O0.a g(FocusTargetNode paramFocusTargetNode, int paramInt) {
    if (!FocusTargetNode.l2(paramFocusTargetNode)) {
      FocusTargetNode.n2(paramFocusTargetNode, true);
      try {
        g g = (g)paramFocusTargetNode.p2().g().invoke(c.i(paramInt));
        g.a a = g.b;
        if (g != a.b()) {
          dbxyzptlk.O0.a a1;
          if (g == a.a()) {
            a1 = dbxyzptlk.O0.a.Cancelled;
            FocusTargetNode.n2(paramFocusTargetNode, false);
            return a1;
          } 
          if (a1.c()) {
            a1 = dbxyzptlk.O0.a.Redirected;
          } else {
            a1 = dbxyzptlk.O0.a.RedirectCancelled;
          } 
          FocusTargetNode.n2(paramFocusTargetNode, false);
          return a1;
        } 
      } finally {
        Exception exception;
      } 
      FocusTargetNode.n2(paramFocusTargetNode, false);
    } 
    return dbxyzptlk.O0.a.None;
  }
  
  public static final dbxyzptlk.O0.a h(FocusTargetNode paramFocusTargetNode, int paramInt) {
    q q = paramFocusTargetNode.r2();
    int i = a.b[q.ordinal()];
    if (i != 1 && i != 2) {
      dbxyzptlk.O0.a a;
      if (i != 3) {
        if (i == 4) {
          int k = K.a(1024);
          if (paramFocusTargetNode.Q0().R1()) {
            dbxyzptlk.O0.a a1;
            d.c c2 = paramFocusTargetNode.Q0().O1();
            f f = h.k((g)paramFocusTargetNode);
            d.c c1 = c2;
            while (true) {
              a1 = null;
              if (f != null) {
                if ((f.i0().k().H1() & k) != 0)
                  for (d.c c = c1; c != null; c = c.O1()) {
                    if ((c.M1() & k) != 0) {
                      c2 = c;
                      c1 = null;
                      while (c2 != null && !(c2 instanceof FocusTargetNode)) {
                        d d2;
                        d.c c3 = c1;
                        if ((c2.M1() & k) != 0) {
                          c3 = c1;
                          if (c2 instanceof i) {
                            d d;
                            c3 = ((i)c2).l2();
                            int m;
                            for (m = 0; c3 != null; m = i) {
                              d d3;
                              d.c c4 = c2;
                              d.c c5 = c1;
                              i = m;
                              if ((c3.M1() & k) != 0) {
                                i = m + 1;
                                if (i == 1) {
                                  c4 = c3;
                                  c5 = c1;
                                } else {
                                  d d4;
                                  c4 = c1;
                                  if (c1 == null)
                                    d4 = new d((Object[])new d.c[16], 0); 
                                  c1 = c2;
                                  if (c2 != null) {
                                    d4.c(c2);
                                    c1 = null;
                                  } 
                                  d4.c(c3);
                                  d3 = d4;
                                  c4 = c1;
                                } 
                              } 
                              c3 = c3.I1();
                              c2 = c4;
                              d = d3;
                            } 
                            d2 = d;
                            if (m == 1)
                              continue; 
                          } 
                        } 
                        c2 = h.b(d2);
                        d d1 = d2;
                      } 
                    } 
                  }  
                f = f.m0();
                if (f != null) {
                  l l = f.i0();
                  if (l != null) {
                    d.c c = l.p();
                    continue;
                  } 
                } 
                c1 = null;
                continue;
              } 
              c2 = null;
              break;
            } 
            FocusTargetNode focusTargetNode = (FocusTargetNode)c2;
            if (focusTargetNode == null)
              return dbxyzptlk.O0.a.None; 
            q q1 = focusTargetNode.r2();
            i = a.b[q1.ordinal()];
            if (i != 1) {
              if (i != 2) {
                if (i != 3) {
                  if (i == 4) {
                    dbxyzptlk.O0.a a2 = h(focusTargetNode, paramInt);
                    if (a2 == dbxyzptlk.O0.a.None)
                      a2 = a1; 
                    a = a2;
                    if (a2 == null)
                      a = f(focusTargetNode, paramInt); 
                  } else {
                    throw new NoWhenBranchMatchedException();
                  } 
                } else {
                  a = h(focusTargetNode, paramInt);
                } 
              } else {
                a = dbxyzptlk.O0.a.Cancelled;
              } 
            } else {
              a = f(focusTargetNode, paramInt);
            } 
            return a;
          } 
          throw new IllegalStateException("visitAncestors called on an unattached node");
        } 
        throw new NoWhenBranchMatchedException();
      } 
      return e(m((FocusTargetNode)a), paramInt);
    } 
    return dbxyzptlk.O0.a.None;
  }
  
  public static final boolean i(FocusTargetNode paramFocusTargetNode) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual r2 : ()Ldbxyzptlk/O0/q;
    //   4: astore #6
    //   6: getstatic androidx/compose/ui/focus/j$a.b : [I
    //   9: aload #6
    //   11: invokevirtual ordinal : ()I
    //   14: iaload
    //   15: istore_1
    //   16: iconst_1
    //   17: istore #5
    //   19: iload #5
    //   21: istore #4
    //   23: iload_1
    //   24: iconst_1
    //   25: if_icmpeq -> 521
    //   28: iload #5
    //   30: istore #4
    //   32: iload_1
    //   33: iconst_2
    //   34: if_icmpeq -> 521
    //   37: aconst_null
    //   38: astore #13
    //   40: iload_1
    //   41: iconst_3
    //   42: if_icmpeq -> 499
    //   45: iload_1
    //   46: iconst_4
    //   47: if_icmpne -> 491
    //   50: sipush #1024
    //   53: invokestatic a : (I)I
    //   56: istore_3
    //   57: aload_0
    //   58: invokeinterface Q0 : ()Landroidx/compose/ui/d$c;
    //   63: invokevirtual R1 : ()Z
    //   66: ifeq -> 481
    //   69: aload_0
    //   70: invokeinterface Q0 : ()Landroidx/compose/ui/d$c;
    //   75: invokevirtual O1 : ()Landroidx/compose/ui/d$c;
    //   78: astore #6
    //   80: aload_0
    //   81: invokestatic k : (Ldbxyzptlk/f1/g;)Landroidx/compose/ui/node/f;
    //   84: astore #11
    //   86: aload #13
    //   88: astore #7
    //   90: aload #11
    //   92: ifnull -> 392
    //   95: aload #11
    //   97: invokevirtual i0 : ()Landroidx/compose/ui/node/l;
    //   100: invokevirtual k : ()Landroidx/compose/ui/d$c;
    //   103: invokevirtual H1 : ()I
    //   106: iload_3
    //   107: iand
    //   108: ifeq -> 352
    //   111: aload #6
    //   113: astore #8
    //   115: aload #8
    //   117: ifnull -> 352
    //   120: aload #8
    //   122: invokevirtual M1 : ()I
    //   125: iload_3
    //   126: iand
    //   127: ifeq -> 342
    //   130: aload #8
    //   132: astore #7
    //   134: aconst_null
    //   135: astore #6
    //   137: aload #7
    //   139: ifnull -> 342
    //   142: aload #7
    //   144: instanceof androidx/compose/ui/focus/FocusTargetNode
    //   147: ifeq -> 153
    //   150: goto -> 392
    //   153: aload #6
    //   155: astore #9
    //   157: aload #7
    //   159: invokevirtual M1 : ()I
    //   162: iload_3
    //   163: iand
    //   164: ifeq -> 328
    //   167: aload #6
    //   169: astore #9
    //   171: aload #7
    //   173: instanceof dbxyzptlk/f1/i
    //   176: ifeq -> 328
    //   179: aload #7
    //   181: checkcast dbxyzptlk/f1/i
    //   184: invokevirtual l2 : ()Landroidx/compose/ui/d$c;
    //   187: astore #9
    //   189: iconst_0
    //   190: istore_1
    //   191: aload #9
    //   193: ifnull -> 316
    //   196: aload #7
    //   198: astore #10
    //   200: aload #6
    //   202: astore #12
    //   204: iload_1
    //   205: istore_2
    //   206: aload #9
    //   208: invokevirtual M1 : ()I
    //   211: iload_3
    //   212: iand
    //   213: ifeq -> 296
    //   216: iload_1
    //   217: iconst_1
    //   218: iadd
    //   219: istore_2
    //   220: iload_2
    //   221: iconst_1
    //   222: if_icmpne -> 236
    //   225: aload #9
    //   227: astore #10
    //   229: aload #6
    //   231: astore #12
    //   233: goto -> 296
    //   236: aload #6
    //   238: astore #10
    //   240: aload #6
    //   242: ifnonnull -> 260
    //   245: new dbxyzptlk/z0/d
    //   248: dup
    //   249: bipush #16
    //   251: anewarray androidx/compose/ui/d$c
    //   254: iconst_0
    //   255: invokespecial <init> : ([Ljava/lang/Object;I)V
    //   258: astore #10
    //   260: aload #7
    //   262: astore #6
    //   264: aload #7
    //   266: ifnull -> 280
    //   269: aload #10
    //   271: aload #7
    //   273: invokevirtual c : (Ljava/lang/Object;)Z
    //   276: pop
    //   277: aconst_null
    //   278: astore #6
    //   280: aload #10
    //   282: aload #9
    //   284: invokevirtual c : (Ljava/lang/Object;)Z
    //   287: pop
    //   288: aload #10
    //   290: astore #12
    //   292: aload #6
    //   294: astore #10
    //   296: aload #9
    //   298: invokevirtual I1 : ()Landroidx/compose/ui/d$c;
    //   301: astore #9
    //   303: aload #10
    //   305: astore #7
    //   307: aload #12
    //   309: astore #6
    //   311: iload_2
    //   312: istore_1
    //   313: goto -> 191
    //   316: aload #6
    //   318: astore #9
    //   320: iload_1
    //   321: iconst_1
    //   322: if_icmpne -> 328
    //   325: goto -> 137
    //   328: aload #9
    //   330: invokestatic b : (Ldbxyzptlk/z0/d;)Landroidx/compose/ui/d$c;
    //   333: astore #7
    //   335: aload #9
    //   337: astore #6
    //   339: goto -> 137
    //   342: aload #8
    //   344: invokevirtual O1 : ()Landroidx/compose/ui/d$c;
    //   347: astore #8
    //   349: goto -> 115
    //   352: aload #11
    //   354: invokevirtual m0 : ()Landroidx/compose/ui/node/f;
    //   357: astore #11
    //   359: aload #11
    //   361: ifnull -> 386
    //   364: aload #11
    //   366: invokevirtual i0 : ()Landroidx/compose/ui/node/l;
    //   369: astore #6
    //   371: aload #6
    //   373: ifnull -> 386
    //   376: aload #6
    //   378: invokevirtual p : ()Landroidx/compose/ui/d$c;
    //   381: astore #6
    //   383: goto -> 86
    //   386: aconst_null
    //   387: astore #6
    //   389: goto -> 86
    //   392: aload #7
    //   394: checkcast androidx/compose/ui/focus/FocusTargetNode
    //   397: astore #7
    //   399: aload #7
    //   401: ifnull -> 454
    //   404: aload #7
    //   406: invokevirtual r2 : ()Ldbxyzptlk/O0/q;
    //   409: astore #6
    //   411: aload #7
    //   413: aload_0
    //   414: invokestatic k : (Landroidx/compose/ui/focus/FocusTargetNode;Landroidx/compose/ui/focus/FocusTargetNode;)Z
    //   417: istore #5
    //   419: iload #5
    //   421: istore #4
    //   423: iload #5
    //   425: ifeq -> 521
    //   428: iload #5
    //   430: istore #4
    //   432: aload #6
    //   434: aload #7
    //   436: invokevirtual r2 : ()Ldbxyzptlk/O0/q;
    //   439: if_acmpeq -> 521
    //   442: aload #7
    //   444: invokestatic c : (Landroidx/compose/ui/focus/FocusTargetNode;)V
    //   447: iload #5
    //   449: istore #4
    //   451: goto -> 521
    //   454: aload_0
    //   455: invokestatic l : (Landroidx/compose/ui/focus/FocusTargetNode;)Z
    //   458: ifeq -> 475
    //   461: aload_0
    //   462: invokestatic d : (Landroidx/compose/ui/focus/FocusTargetNode;)Z
    //   465: ifeq -> 475
    //   468: iload #5
    //   470: istore #4
    //   472: goto -> 521
    //   475: iconst_0
    //   476: istore #4
    //   478: goto -> 521
    //   481: new java/lang/IllegalStateException
    //   484: dup
    //   485: ldc 'visitAncestors called on an unattached node'
    //   487: invokespecial <init> : (Ljava/lang/String;)V
    //   490: athrow
    //   491: new kotlin/NoWhenBranchMatchedException
    //   494: dup
    //   495: invokespecial <init> : ()V
    //   498: athrow
    //   499: aload_0
    //   500: iconst_0
    //   501: iconst_0
    //   502: iconst_3
    //   503: aconst_null
    //   504: invokestatic b : (Landroidx/compose/ui/focus/FocusTargetNode;ZZILjava/lang/Object;)Z
    //   507: ifeq -> 475
    //   510: aload_0
    //   511: invokestatic d : (Landroidx/compose/ui/focus/FocusTargetNode;)Z
    //   514: ifeq -> 475
    //   517: iload #5
    //   519: istore #4
    //   521: iload #4
    //   523: ifeq -> 530
    //   526: aload_0
    //   527: invokestatic c : (Landroidx/compose/ui/focus/FocusTargetNode;)V
    //   530: iload #4
    //   532: ireturn
  }
  
  public static final boolean j(FocusTargetNode paramFocusTargetNode) {
    NoWhenBranchMatchedException noWhenBranchMatchedException;
    u u = t.d(paramFocusTargetNode);
    try {
      if (u.e(u))
        u.b(u); 
    } finally {}
    u.a(u);
    dbxyzptlk.O0.a a = h(paramFocusTargetNode, c.b.b());
    int i = a.a[a.ordinal()];
    boolean bool = true;
    if (i != 1) {
      if (i != 2) {
        if (i == 3 || i == 4) {
          bool = false;
          u.c(u);
          return bool;
        } 
        noWhenBranchMatchedException = new NoWhenBranchMatchedException();
        this();
        throw noWhenBranchMatchedException;
      } 
    } else {
      bool = i((FocusTargetNode)noWhenBranchMatchedException);
    } 
    u.c(u);
    return bool;
  }
  
  public static final boolean k(FocusTargetNode paramFocusTargetNode1, FocusTargetNode paramFocusTargetNode2) {
    int i = K.a(1024);
    if (paramFocusTargetNode2.Q0().R1()) {
      d.c c2;
      d.c c3;
      d.c c1 = paramFocusTargetNode2.Q0().O1();
      f f = h.k((g)paramFocusTargetNode2);
      while (true) {
        boolean bool1 = true;
        c3 = null;
        if (f != null) {
          if ((f.i0().k().H1() & i) != 0)
            for (d.c c = c1; c != null; c = c.O1()) {
              if ((c.M1() & i) != 0) {
                d.c c4 = c;
                c1 = null;
                while (c4 != null && !(c4 instanceof FocusTargetNode)) {
                  d d2;
                  d.c c5 = c1;
                  if ((c4.M1() & i) != 0) {
                    c5 = c1;
                    if (c4 instanceof i) {
                      d d;
                      c5 = ((i)c4).l2();
                      int k;
                      for (k = 0; c5 != null; k = m) {
                        d d3;
                        d.c c6 = c4;
                        d.c c7 = c1;
                        int m = k;
                        if ((c5.M1() & i) != 0) {
                          m = k + 1;
                          if (m == 1) {
                            c6 = c5;
                            c7 = c1;
                          } else {
                            d d4;
                            c6 = c1;
                            if (c1 == null)
                              d4 = new d((Object[])new d.c[16], 0); 
                            c1 = c4;
                            if (c4 != null) {
                              d4.c(c4);
                              c1 = null;
                            } 
                            d4.c(c5);
                            d3 = d4;
                            c6 = c1;
                          } 
                        } 
                        c5 = c5.I1();
                        c4 = c6;
                        d = d3;
                      } 
                      d2 = d;
                      if (k == 1)
                        continue; 
                    } 
                  } 
                  c4 = h.b(d2);
                  d d1 = d2;
                } 
              } 
            }  
          f = f.m0();
          if (f != null) {
            l l = f.i0();
            if (l != null) {
              d.c c = l.p();
              continue;
            } 
          } 
          c1 = null;
          continue;
        } 
        c2 = null;
        break;
      } 
      if (s.c(c2, paramFocusTargetNode1)) {
        q q = paramFocusTargetNode1.r2();
        int k = a.b[q.ordinal()];
        if (k != 1) {
          if (k != 2) {
            boolean bool1;
            if (k != 3) {
              if (k == 4) {
                i = K.a(1024);
                if (paramFocusTargetNode1.Q0().R1()) {
                  d.c c = paramFocusTargetNode1.Q0().O1();
                  f = h.k((g)paramFocusTargetNode1);
                  label139: while (true) {
                    c2 = c3;
                    if (f != null) {
                      if ((f.i0().k().H1() & i) != 0)
                        for (d.c c4 = c; c4 != null; c4 = c4.O1()) {
                          if ((c4.M1() & i) != 0) {
                            c2 = c4;
                            c = null;
                            while (c2 != null) {
                              d d2;
                              if (c2 instanceof FocusTargetNode)
                                break label139; 
                              d.c c5 = c;
                              if ((c2.M1() & i) != 0) {
                                c5 = c;
                                if (c2 instanceof i) {
                                  d d;
                                  c5 = ((i)c2).l2();
                                  for (k = 0; c5 != null; k = m) {
                                    d d3;
                                    d.c c6 = c2;
                                    d.c c7 = c;
                                    int m = k;
                                    if ((c5.M1() & i) != 0) {
                                      m = k + 1;
                                      if (m == 1) {
                                        c6 = c5;
                                        c7 = c;
                                      } else {
                                        d d4;
                                        c6 = c;
                                        if (c == null)
                                          d4 = new d((Object[])new d.c[16], 0); 
                                        c = c2;
                                        if (c2 != null) {
                                          d4.c(c2);
                                          c = null;
                                        } 
                                        d4.c(c5);
                                        d3 = d4;
                                        c6 = c;
                                      } 
                                    } 
                                    c5 = c5.I1();
                                    c2 = c6;
                                    d = d3;
                                  } 
                                  d2 = d;
                                  if (k == 1)
                                    continue; 
                                } 
                              } 
                              c2 = h.b(d2);
                              d d1 = d2;
                            } 
                          } 
                        }  
                      f = f.m0();
                      if (f != null) {
                        l l = f.i0();
                        if (l != null) {
                          d.c c4 = l.p();
                          continue;
                        } 
                      } 
                      c = null;
                      continue;
                    } 
                    break;
                  } 
                  c = c2;
                  if (c == null && l(paramFocusTargetNode1)) {
                    paramFocusTargetNode1.u2(q.Active);
                    bool1 = k(paramFocusTargetNode1, paramFocusTargetNode2);
                  } else {
                    if (c != null && k((FocusTargetNode)c, paramFocusTargetNode1)) {
                      boolean bool2;
                      boolean bool3 = k(paramFocusTargetNode1, paramFocusTargetNode2);
                      if (paramFocusTargetNode1.r2() == q.ActiveParent) {
                        bool2 = bool3;
                        if (bool3) {
                          e.c((FocusTargetNode)c);
                          bool2 = bool3;
                        } 
                      } else {
                        throw new IllegalStateException("Deactivated node is focused");
                      } 
                      return bool2;
                    } 
                    bool1 = false;
                  } 
                } else {
                  throw new IllegalStateException("visitAncestors called on an unattached node");
                } 
              } else {
                throw new NoWhenBranchMatchedException();
              } 
            } else {
              m(paramFocusTargetNode1);
              if (b(paramFocusTargetNode1, false, false, 3, null) && d(paramFocusTargetNode2))
                return bool1; 
              bool1 = false;
            } 
            return bool1;
          } 
        } else {
          boolean bool2 = d(paramFocusTargetNode2);
          boolean bool1 = bool2;
          if (bool2) {
            paramFocusTargetNode1.u2(q.ActiveParent);
            bool1 = bool2;
          } 
          return bool1;
        } 
      } else {
        throw new IllegalStateException("Non child node cannot request focus.");
      } 
    } else {
      throw new IllegalStateException("visitAncestors called on an unattached node");
    } 
    boolean bool = false;
  }
  
  public static final boolean l(FocusTargetNode paramFocusTargetNode) {
    n n = paramFocusTargetNode.J1();
    if (n != null) {
      f f = n.j2();
      if (f != null) {
        Owner owner = f.l0();
        if (owner != null)
          return owner.requestFocus(); 
      } 
    } 
    throw new IllegalStateException("Owner not initialized.");
  }
  
  public static final FocusTargetNode m(FocusTargetNode paramFocusTargetNode) {
    paramFocusTargetNode = k.f(paramFocusTargetNode);
    if (paramFocusTargetNode != null)
      return paramFocusTargetNode; 
    throw new IllegalArgumentException("ActiveParent with no focused child");
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compos\\ui\focus\j.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */