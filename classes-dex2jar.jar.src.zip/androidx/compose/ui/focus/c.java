package androidx.compose.ui.focus;

import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

@Metadata(d1 = {"\000 \n\002\030\002\n\002\020\000\n\002\020\b\n\002\b\003\n\002\020\016\n\002\b\004\n\002\020\013\n\002\b\006\b@\030\000 \0202\0020\001:\001\016B\021\b\000\022\006\020\003\032\0020\002¢\006\004\b\004\020\005J\017\020\007\032\0020\006H\026¢\006\004\b\007\020\bJ\020\020\t\032\0020\002HÖ\001¢\006\004\b\t\020\005J\032\020\f\032\0020\0132\b\020\n\032\004\030\0010\001HÖ\003¢\006\004\b\f\020\rR\024\020\003\032\0020\0028\002X\004¢\006\006\n\004\b\016\020\017\001\003\001\0020\002¨\006\021"}, d2 = {"Landroidx/compose/ui/focus/c;", "", "", "value", "j", "(I)I", "", "n", "(I)Ljava/lang/String;", "m", "other", "", "k", "(ILjava/lang/Object;)Z", "a", "I", "b", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class c {
  public static final a b = new a(null);
  
  public static final int c = j(1);
  
  public static final int d = j(2);
  
  public static final int e = j(3);
  
  public static final int f = j(4);
  
  public static final int g = j(5);
  
  public static final int h = j(6);
  
  public static final int i = j(7);
  
  public static final int j = j(8);
  
  public final int a;
  
  public static int j(int paramInt) {
    return paramInt;
  }
  
  public static boolean k(int paramInt, Object paramObject) {
    return !(paramObject instanceof c) ? false : (!(paramInt != ((c)paramObject).o()));
  }
  
  public static final boolean l(int paramInt1, int paramInt2) {
    boolean bool;
    if (paramInt1 == paramInt2) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public static int m(int paramInt) {
    return Integer.hashCode(paramInt);
  }
  
  public static String n(int paramInt) {
    String str;
    if (l(paramInt, c)) {
      str = "Next";
    } else if (l(paramInt, d)) {
      str = "Previous";
    } else if (l(paramInt, e)) {
      str = "Left";
    } else if (l(paramInt, f)) {
      str = "Right";
    } else if (l(paramInt, g)) {
      str = "Up";
    } else if (l(paramInt, h)) {
      str = "Down";
    } else if (l(paramInt, i)) {
      str = "Enter";
    } else if (l(paramInt, j)) {
      str = "Exit";
    } else {
      str = "Invalid FocusDirection";
    } 
    return str;
  }
  
  public boolean equals(Object paramObject) {
    return k(this.a, paramObject);
  }
  
  public int hashCode() {
    return m(this.a);
  }
  
  public String toString() {
    return n(this.a);
  }
  
  @Metadata(d1 = {"\000\024\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\b\025\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003R\035\020\005\032\0020\0048\006ø\001\000ø\001\001¢\006\f\n\004\b\005\020\006\032\004\b\007\020\bR\035\020\t\032\0020\0048\006ø\001\000ø\001\001¢\006\f\n\004\b\t\020\006\032\004\b\n\020\bR\035\020\013\032\0020\0048\006ø\001\000ø\001\001¢\006\f\n\004\b\013\020\006\032\004\b\f\020\bR\035\020\r\032\0020\0048\006ø\001\000ø\001\001¢\006\f\n\004\b\r\020\006\032\004\b\016\020\bR\035\020\017\032\0020\0048\006ø\001\000ø\001\001¢\006\f\n\004\b\017\020\006\032\004\b\020\020\bR\035\020\021\032\0020\0048\006ø\001\000ø\001\001¢\006\f\n\004\b\021\020\006\032\004\b\022\020\bR&\020\023\032\0020\0048GX\004ø\001\000ø\001\001¢\006\022\n\004\b\023\020\006\022\004\b\025\020\003\032\004\b\024\020\bR&\020\026\032\0020\0048GX\004ø\001\000ø\001\001¢\006\022\n\004\b\026\020\006\022\004\b\030\020\003\032\004\b\027\020\b\002\013\n\005\b¡\0360\001\n\002\b!¨\006\031"}, d2 = {"Landroidx/compose/ui/focus/c$a;", "", "<init>", "()V", "Landroidx/compose/ui/focus/c;", "Next", "I", "e", "()I", "Previous", "f", "Left", "d", "Right", "g", "Up", "h", "Down", "a", "Enter", "b", "getEnter-dhqQ-8s$annotations", "Exit", "c", "getExit-dhqQ-8s$annotations", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class a {
    public a() {}
    
    public final int a() {
      return c.a();
    }
    
    public final int b() {
      return c.b();
    }
    
    public final int c() {
      return c.c();
    }
    
    public final int d() {
      return c.d();
    }
    
    public final int e() {
      return c.e();
    }
    
    public final int f() {
      return c.f();
    }
    
    public final int g() {
      return c.g();
    }
    
    public final int h() {
      return c.h();
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compos\\ui\focus\c.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */