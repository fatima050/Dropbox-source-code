package androidx.compose.ui;

import dbxyzptlk.CI.l;
import dbxyzptlk.CI.p;
import dbxyzptlk.CI.q;
import dbxyzptlk.DI.S;
import dbxyzptlk.DI.s;
import dbxyzptlk.DI.u;
import dbxyzptlk.g1.p0;
import dbxyzptlk.g1.r0;
import dbxyzptlk.pI.D;
import dbxyzptlk.x0.k;
import kotlin.Metadata;

@Metadata(d1 = {"\000\034\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\004\032;\020\006\032\0020\000*\0020\0002\024\b\002\020\004\032\016\022\004\022\0020\002\022\004\022\0020\0030\0012\022\020\005\032\016\022\004\022\0020\000\022\004\022\0020\0000\001¢\006\004\b\006\020\007\032\033\020\n\032\0020\000*\0020\b2\006\020\t\032\0020\000H\007¢\006\004\b\n\020\013¨\006\f"}, d2 = {"Landroidx/compose/ui/d;", "Lkotlin/Function1;", "Ldbxyzptlk/g1/r0;", "Ldbxyzptlk/pI/D;", "inspectorInfo", "factory", "a", "(Landroidx/compose/ui/d;Ldbxyzptlk/CI/l;Ldbxyzptlk/CI/q;)Landroidx/compose/ui/d;", "Ldbxyzptlk/x0/k;", "modifier", "c", "(Ldbxyzptlk/x0/k;Landroidx/compose/ui/d;)Landroidx/compose/ui/d;", "ui_release"}, k = 2, mv = {1, 8, 0}, xi = 48)
public final class c {
  public static final d a(d paramd, l<? super r0, D> paraml, q<? super d, ? super k, ? super Integer, ? extends d> paramq) {
    return paramd.g(new b(paraml, paramq));
  }
  
  public static final d c(k paramk, d paramd) {
    if (paramd.c(a.f))
      return paramd; 
    paramk.I(1219399079);
    paramd = paramd.<d>a(d.a, new b(paramk));
    paramk.R();
    return paramd;
  }
  
  @Metadata(d1 = {"\000\016\n\002\030\002\n\000\n\002\020\013\n\002\b\002\020\003\032\0020\0022\006\020\001\032\0020\000H\n¢\006\004\b\003\020\004"}, d2 = {"Landroidx/compose/ui/d$b;", "it", "", "a", "(Landroidx/compose/ui/d$b;)Ljava/lang/Boolean;"}, k = 3, mv = {1, 8, 0})
  public static final class a extends u implements l<d.b, Boolean> {
    public static final a f = new a();
    
    public a() {
      super(1);
    }
    
    public final Boolean a(d.b param1b) {
      return Boolean.valueOf(param1b instanceof b ^ true);
    }
  }
  
  @Metadata(d1 = {"\000\016\n\002\030\002\n\000\n\002\030\002\n\002\b\003\020\004\032\0020\0002\006\020\001\032\0020\0002\006\020\003\032\0020\002H\n¢\006\004\b\004\020\005"}, d2 = {"Landroidx/compose/ui/d;", "acc", "Landroidx/compose/ui/d$b;", "element", "a", "(Landroidx/compose/ui/d;Landroidx/compose/ui/d$b;)Landroidx/compose/ui/d;"}, k = 3, mv = {1, 8, 0})
  public static final class b extends u implements p<d, d.b, d> {
    public final k f;
    
    public b(k param1k) {
      super(2);
    }
    
    public final d a(d param1d, d.b param1b) {
      d d1 = param1b;
      if (param1b instanceof b) {
        q<d, k, Integer, d> q = ((b)param1b).b();
        s.f(q, "null cannot be cast to non-null type @[ExtensionFunctionType] kotlin.Function3<androidx.compose.ui.Modifier, androidx.compose.runtime.Composer, kotlin.Int, androidx.compose.ui.Modifier>");
        d d2 = (d)((q)S.g(q, 3)).h(d.a, this.f, Integer.valueOf(0));
        d1 = c.c(this.f, d2);
      } 
      return param1d.g(d1);
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compos\\ui\c.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */