package androidx.compose.ui.layout;

import androidx.compose.ui.d;
import dbxyzptlk.DI.s;
import dbxyzptlk.d1.t;
import dbxyzptlk.f1.G;
import kotlin.Metadata;

@Metadata(d1 = {"\0004\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\000\n\002\b\006\n\002\030\002\n\002\b\002\n\002\020\016\n\002\b\002\n\002\020\b\n\002\b\003\n\002\020\013\n\002\b\005\b\b\030\0002\b\022\004\022\0020\0020\001B\017\022\006\020\004\032\0020\003¢\006\004\b\005\020\006J\017\020\007\032\0020\002H\026¢\006\004\b\007\020\bJ\027\020\013\032\0020\n2\006\020\t\032\0020\002H\026¢\006\004\b\013\020\fJ\020\020\016\032\0020\rHÖ\001¢\006\004\b\016\020\017J\020\020\021\032\0020\020HÖ\001¢\006\004\b\021\020\022J\032\020\025\032\0020\0242\b\020\023\032\004\030\0010\003HÖ\003¢\006\004\b\025\020\026R\024\020\004\032\0020\0038\002X\004¢\006\006\n\004\b\027\020\030¨\006\031"}, d2 = {"Landroidx/compose/ui/layout/LayoutIdElement;", "Ldbxyzptlk/f1/G;", "Ldbxyzptlk/d1/t;", "", "layoutId", "<init>", "(Ljava/lang/Object;)V", "i", "()Ldbxyzptlk/d1/t;", "node", "Ldbxyzptlk/pI/D;", "k", "(Ldbxyzptlk/d1/t;)V", "", "toString", "()Ljava/lang/String;", "", "hashCode", "()I", "other", "", "equals", "(Ljava/lang/Object;)Z", "b", "Ljava/lang/Object;", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
final class LayoutIdElement extends G<t> {
  public final Object b;
  
  public LayoutIdElement(Object paramObject) {
    this.b = paramObject;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof LayoutIdElement))
      return false; 
    paramObject = paramObject;
    return !!s.c(this.b, ((LayoutIdElement)paramObject).b);
  }
  
  public int hashCode() {
    return this.b.hashCode();
  }
  
  public t i() {
    return new t(this.b);
  }
  
  public void k(t paramt) {
    paramt.k2(this.b);
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("LayoutIdElement(layoutId=");
    stringBuilder.append(this.b);
    stringBuilder.append(')');
    return stringBuilder.toString();
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compos\\ui\layout\LayoutIdElement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */