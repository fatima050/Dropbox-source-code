package androidx.compose.ui.layout;

import androidx.compose.ui.d;
import dbxyzptlk.CI.q;
import dbxyzptlk.DI.s;
import dbxyzptlk.d1.F;
import dbxyzptlk.d1.H;
import dbxyzptlk.d1.I;
import dbxyzptlk.d1.y;
import dbxyzptlk.f1.G;
import dbxyzptlk.z1.b;
import kotlin.Metadata;

@Metadata(d1 = {"\000J\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\006\n\002\030\002\n\002\b\002\n\002\020\016\n\002\b\002\n\002\020\b\n\002\b\002\n\002\020\000\n\000\n\002\020\013\n\002\b\007\b\b\030\0002\b\022\004\022\0020\0020\001B'\022\036\020\b\032\032\022\004\022\0020\004\022\004\022\0020\005\022\004\022\0020\006\022\004\022\0020\0070\003¢\006\004\b\t\020\nJ\017\020\013\032\0020\002H\026¢\006\004\b\013\020\fJ\027\020\017\032\0020\0162\006\020\r\032\0020\002H\026¢\006\004\b\017\020\020J\020\020\022\032\0020\021HÖ\001¢\006\004\b\022\020\023J\020\020\025\032\0020\024HÖ\001¢\006\004\b\025\020\026J\032\020\032\032\0020\0312\b\020\030\032\004\030\0010\027HÖ\003¢\006\004\b\032\020\033R/\020\b\032\032\022\004\022\0020\004\022\004\022\0020\005\022\004\022\0020\006\022\004\022\0020\0070\0038\006¢\006\f\n\004\b\034\020\035\032\004\b\036\020\037¨\006 "}, d2 = {"Landroidx/compose/ui/layout/LayoutElement;", "Ldbxyzptlk/f1/G;", "Ldbxyzptlk/d1/y;", "Lkotlin/Function3;", "Ldbxyzptlk/d1/I;", "Ldbxyzptlk/d1/F;", "Ldbxyzptlk/z1/b;", "Ldbxyzptlk/d1/H;", "measure", "<init>", "(Ldbxyzptlk/CI/q;)V", "i", "()Ldbxyzptlk/d1/y;", "node", "Ldbxyzptlk/pI/D;", "k", "(Ldbxyzptlk/d1/y;)V", "", "toString", "()Ljava/lang/String;", "", "hashCode", "()I", "", "other", "", "equals", "(Ljava/lang/Object;)Z", "b", "Ldbxyzptlk/CI/q;", "getMeasure", "()Ldbxyzptlk/CI/q;", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
final class LayoutElement extends G<y> {
  public final q<I, F, b, H> b;
  
  public LayoutElement(q<? super I, ? super F, ? super b, ? extends H> paramq) {
    this.b = (q)paramq;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof LayoutElement))
      return false; 
    paramObject = paramObject;
    return !!s.c(this.b, ((LayoutElement)paramObject).b);
  }
  
  public int hashCode() {
    return this.b.hashCode();
  }
  
  public y i() {
    return new y(this.b);
  }
  
  public void k(y paramy) {
    paramy.k2(this.b);
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("LayoutElement(measure=");
    stringBuilder.append(this.b);
    stringBuilder.append(')');
    return stringBuilder.toString();
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compos\\ui\layout\LayoutElement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */