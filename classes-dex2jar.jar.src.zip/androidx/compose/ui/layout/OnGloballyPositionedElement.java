package androidx.compose.ui.layout;

import androidx.compose.ui.d;
import dbxyzptlk.CI.l;
import dbxyzptlk.DI.s;
import dbxyzptlk.d1.O;
import dbxyzptlk.d1.r;
import dbxyzptlk.f1.G;
import dbxyzptlk.pI.D;
import kotlin.Metadata;

@Metadata(d1 = {"\0002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\005\n\002\020\000\n\000\n\002\020\013\n\002\b\002\n\002\020\b\n\002\b\n\b\002\030\0002\b\022\004\022\0020\0020\001B\033\022\022\020\006\032\016\022\004\022\0020\004\022\004\022\0020\0050\003¢\006\004\b\007\020\bJ\017\020\t\032\0020\002H\026¢\006\004\b\t\020\nJ\032\020\016\032\0020\r2\b\020\f\032\004\030\0010\013H\002¢\006\004\b\016\020\017J\017\020\021\032\0020\020H\026¢\006\004\b\021\020\022J\027\020\024\032\0020\0052\006\020\023\032\0020\002H\026¢\006\004\b\024\020\025R#\020\006\032\016\022\004\022\0020\004\022\004\022\0020\0050\0038\006¢\006\f\n\004\b\026\020\027\032\004\b\030\020\031¨\006\032"}, d2 = {"Landroidx/compose/ui/layout/OnGloballyPositionedElement;", "Ldbxyzptlk/f1/G;", "Ldbxyzptlk/d1/O;", "Lkotlin/Function1;", "Ldbxyzptlk/d1/r;", "Ldbxyzptlk/pI/D;", "onGloballyPositioned", "<init>", "(Ldbxyzptlk/CI/l;)V", "i", "()Ldbxyzptlk/d1/O;", "", "other", "", "equals", "(Ljava/lang/Object;)Z", "", "hashCode", "()I", "node", "k", "(Ldbxyzptlk/d1/O;)V", "b", "Ldbxyzptlk/CI/l;", "getOnGloballyPositioned", "()Ldbxyzptlk/CI/l;", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
final class OnGloballyPositionedElement extends G<O> {
  public final l<r, D> b;
  
  public OnGloballyPositionedElement(l<? super r, D> paraml) {
    this.b = (l)paraml;
  }
  
  public boolean equals(Object paramObject) {
    return (this == paramObject) ? true : (!(paramObject instanceof OnGloballyPositionedElement) ? false : s.c(this.b, ((OnGloballyPositionedElement)paramObject).b));
  }
  
  public int hashCode() {
    return this.b.hashCode();
  }
  
  public O i() {
    return new O(this.b);
  }
  
  public void k(O paramO) {
    paramO.k2(this.b);
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compos\\ui\layout\OnGloballyPositionedElement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */