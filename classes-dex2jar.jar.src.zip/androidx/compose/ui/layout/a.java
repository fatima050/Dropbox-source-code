package androidx.compose.ui.layout;

import androidx.compose.ui.d;
import dbxyzptlk.d1.F;
import kotlin.Metadata;

@Metadata(d1 = {"\000\024\n\002\030\002\n\002\020\000\n\002\b\003\n\002\030\002\n\002\b\003\032\033\020\003\032\0020\000*\0020\0002\006\020\002\032\0020\001H\007¢\006\004\b\003\020\004\"\027\020\002\032\004\030\0010\001*\0020\0058F¢\006\006\032\004\b\006\020\007¨\006\b"}, d2 = {"Landroidx/compose/ui/d;", "", "layoutId", "b", "(Landroidx/compose/ui/d;Ljava/lang/Object;)Landroidx/compose/ui/d;", "Ldbxyzptlk/d1/F;", "a", "(Ldbxyzptlk/d1/F;)Ljava/lang/Object;", "ui_release"}, k = 2, mv = {1, 8, 0}, xi = 48)
public final class a {
  public static final Object a(F paramF) {
    Object object1 = paramF.b();
    boolean bool = object1 instanceof dbxyzptlk.d1.u;
    Object object2 = null;
    if (bool) {
      object1 = object1;
    } else {
      object1 = null;
    } 
    if (object1 != null)
      object2 = object1.g1(); 
    return object2;
  }
  
  public static final d b(d paramd, Object paramObject) {
    return paramd.g((d)new LayoutIdElement(paramObject));
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compos\\ui\layout\a.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */