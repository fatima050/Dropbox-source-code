package androidx.compose.ui.layout;

import androidx.compose.ui.d;
import dbxyzptlk.CI.q;
import dbxyzptlk.d1.F;
import dbxyzptlk.d1.H;
import dbxyzptlk.d1.I;
import kotlin.Metadata;

@Metadata(d1 = {"\000\034\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\004\0321\020\007\032\0020\000*\0020\0002\036\020\006\032\032\022\004\022\0020\002\022\004\022\0020\003\022\004\022\0020\004\022\004\022\0020\0050\001¢\006\004\b\007\020\b¨\006\t"}, d2 = {"Landroidx/compose/ui/d;", "Lkotlin/Function3;", "Ldbxyzptlk/d1/I;", "Ldbxyzptlk/d1/F;", "Ldbxyzptlk/z1/b;", "Ldbxyzptlk/d1/H;", "measure", "a", "(Landroidx/compose/ui/d;Ldbxyzptlk/CI/q;)Landroidx/compose/ui/d;", "ui_release"}, k = 2, mv = {1, 8, 0}, xi = 48)
public final class b {
  public static final d a(d paramd, q<? super I, ? super F, ? super dbxyzptlk.z1.b, ? extends H> paramq) {
    return paramd.g((d)new LayoutElement(paramq));
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compos\\ui\layout\b.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */