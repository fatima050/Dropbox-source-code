package androidx.compose.ui;

import dbxyzptlk.CI.l;
import dbxyzptlk.CI.p;
import dbxyzptlk.DI.s;
import kotlin.Metadata;

@Metadata(d1 = {"\000<\n\002\030\002\n\002\030\002\n\002\b\006\n\002\030\002\n\002\030\002\n\002\b\003\n\002\030\002\n\002\020\013\n\002\b\003\n\002\020\000\n\002\b\003\n\002\020\b\n\002\b\002\n\002\020\016\n\002\b\007\b\007\030\0002\0020\001B\027\022\006\020\002\032\0020\001\022\006\020\003\032\0020\001¢\006\004\b\004\020\005J7\020\013\032\0028\000\"\004\b\000\020\0062\006\020\007\032\0028\0002\030\020\n\032\024\022\004\022\0028\000\022\004\022\0020\t\022\004\022\0028\0000\bH\026¢\006\004\b\013\020\fJ#\020\020\032\0020\0162\022\020\017\032\016\022\004\022\0020\t\022\004\022\0020\0160\rH\026¢\006\004\b\020\020\021J\032\020\024\032\0020\0162\b\020\023\032\004\030\0010\022H\002¢\006\004\b\024\020\025J\017\020\027\032\0020\026H\026¢\006\004\b\027\020\030J\017\020\032\032\0020\031H\026¢\006\004\b\032\020\033R\032\020\002\032\0020\0018\000X\004¢\006\f\n\004\b\034\020\035\032\004\b\036\020\037R\032\020\003\032\0020\0018\000X\004¢\006\f\n\004\b\020\020\035\032\004\b\034\020\037¨\006 "}, d2 = {"Landroidx/compose/ui/a;", "Landroidx/compose/ui/d;", "outer", "inner", "<init>", "(Landroidx/compose/ui/d;Landroidx/compose/ui/d;)V", "R", "initial", "Lkotlin/Function2;", "Landroidx/compose/ui/d$b;", "operation", "a", "(Ljava/lang/Object;Ldbxyzptlk/CI/p;)Ljava/lang/Object;", "Lkotlin/Function1;", "", "predicate", "c", "(Ldbxyzptlk/CI/l;)Z", "", "other", "equals", "(Ljava/lang/Object;)Z", "", "hashCode", "()I", "", "toString", "()Ljava/lang/String;", "b", "Landroidx/compose/ui/d;", "e", "()Landroidx/compose/ui/d;", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class a implements d {
  public final d b;
  
  public final d c;
  
  public a(d paramd1, d paramd2) {
    this.b = paramd1;
    this.c = paramd2;
  }
  
  public <R> R a(R paramR, p<? super R, ? super d.b, ? extends R> paramp) {
    return this.c.a(this.b.a(paramR, paramp), paramp);
  }
  
  public final d b() {
    return this.c;
  }
  
  public boolean c(l<? super d.b, Boolean> paraml) {
    boolean bool;
    if (this.b.c(paraml) && this.c.c(paraml)) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public final d e() {
    return this.b;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject instanceof a) {
      d d1 = this.b;
      paramObject = paramObject;
      if (s.c(d1, ((a)paramObject).b) && s.c(this.c, ((a)paramObject).c))
        return true; 
    } 
    return false;
  }
  
  public int hashCode() {
    return this.b.hashCode() + this.c.hashCode() * 31;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append('[');
    stringBuilder.append(a("", (p<? super String, ? super d.b, ? extends String>)a.f));
    stringBuilder.append(']');
    return stringBuilder.toString();
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compos\\ui\a.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */