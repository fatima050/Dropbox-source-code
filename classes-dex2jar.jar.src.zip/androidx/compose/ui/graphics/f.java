package androidx.compose.ui.graphics;

import dbxyzptlk.DI.l;
import dbxyzptlk.Q0.h1;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

@Metadata(d1 = {"\0000\n\002\030\002\n\002\020\000\n\002\020\t\n\002\b\003\n\002\020\016\n\002\b\002\n\002\020\b\n\002\b\003\n\002\020\013\n\002\b\006\n\002\020\007\n\002\b\007\b@\030\000 \0322\0020\001:\001\020B\021\b\000\022\006\020\003\032\0020\002¢\006\004\b\004\020\005J\020\020\007\032\0020\006HÖ\001¢\006\004\b\007\020\bJ\020\020\n\032\0020\tHÖ\001¢\006\004\b\n\020\013J\032\020\016\032\0020\r2\b\020\f\032\004\030\0010\001HÖ\003¢\006\004\b\016\020\017R\032\020\003\032\0020\0028\000X\004¢\006\f\n\004\b\020\020\021\022\004\b\022\020\023R\021\020\027\032\0020\0248F¢\006\006\032\004\b\025\020\026R\021\020\031\032\0020\0248F¢\006\006\032\004\b\030\020\026\001\003\001\0020\002¨\006\033"}, d2 = {"Landroidx/compose/ui/graphics/f;", "", "", "packedValue", "c", "(J)J", "", "i", "(J)Ljava/lang/String;", "", "h", "(J)I", "other", "", "d", "(JLjava/lang/Object;)Z", "a", "J", "getPackedValue$annotations", "()V", "", "f", "(J)F", "pivotFractionX", "g", "pivotFractionY", "b", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class f {
  public static final a b = new a(null);
  
  public static final long c = h1.a(0.5F, 0.5F);
  
  public final long a;
  
  public static long c(long paramLong) {
    return paramLong;
  }
  
  public static boolean d(long paramLong, Object paramObject) {
    return !(paramObject instanceof f) ? false : (!(paramLong != ((f)paramObject).j()));
  }
  
  public static final boolean e(long paramLong1, long paramLong2) {
    boolean bool;
    if (paramLong1 == paramLong2) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public static final float f(long paramLong) {
    l l = l.a;
    return Float.intBitsToFloat((int)(paramLong >> 32L));
  }
  
  public static final float g(long paramLong) {
    l l = l.a;
    return Float.intBitsToFloat((int)(paramLong & 0xFFFFFFFFL));
  }
  
  public static int h(long paramLong) {
    return Long.hashCode(paramLong);
  }
  
  public static String i(long paramLong) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("TransformOrigin(packedValue=");
    stringBuilder.append(paramLong);
    stringBuilder.append(')');
    return stringBuilder.toString();
  }
  
  public boolean equals(Object paramObject) {
    return d(this.a, paramObject);
  }
  
  public int hashCode() {
    return h(this.a);
  }
  
  public String toString() {
    return i(this.a);
  }
  
  @Metadata(d1 = {"\000\024\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\b\005\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003R\035\020\005\032\0020\0048\006ø\001\000ø\001\001¢\006\f\n\004\b\005\020\006\032\004\b\007\020\b\002\013\n\005\b¡\0360\001\n\002\b!¨\006\t"}, d2 = {"Landroidx/compose/ui/graphics/f$a;", "", "<init>", "()V", "Landroidx/compose/ui/graphics/f;", "Center", "J", "a", "()J", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class a {
    public a() {}
    
    public final long a() {
      return f.a();
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compos\\ui\graphics\f.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */