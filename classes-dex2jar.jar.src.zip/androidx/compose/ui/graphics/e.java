package androidx.compose.ui.graphics;

import androidx.compose.ui.d;
import androidx.compose.ui.node.n;
import dbxyzptlk.CI.l;
import dbxyzptlk.DI.u;
import dbxyzptlk.Q0.V0;
import dbxyzptlk.Q0.a1;
import dbxyzptlk.Q0.r0;
import dbxyzptlk.d1.F;
import dbxyzptlk.d1.H;
import dbxyzptlk.d1.I;
import dbxyzptlk.d1.Y;
import dbxyzptlk.f1.K;
import dbxyzptlk.f1.g;
import dbxyzptlk.f1.h;
import dbxyzptlk.f1.w;
import dbxyzptlk.pI.D;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

@Metadata(d1 = {"\000p\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\007\n\002\b\n\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020\013\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\002\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\020\016\n\002\b8\n\002\030\002\n\002\030\002\n\002\b\013\b\002\030\0002\0020\0012\0020\002B\001\022\006\020\004\032\0020\003\022\006\020\005\032\0020\003\022\006\020\006\032\0020\003\022\006\020\007\032\0020\003\022\006\020\b\032\0020\003\022\006\020\t\032\0020\003\022\006\020\n\032\0020\003\022\006\020\013\032\0020\003\022\006\020\f\032\0020\003\022\006\020\r\032\0020\003\022\006\020\017\032\0020\016\022\006\020\021\032\0020\020\022\006\020\023\032\0020\022\022\b\020\025\032\004\030\0010\024\022\006\020\027\032\0020\026\022\006\020\030\032\0020\026\022\b\b\002\020\032\032\0020\031¢\006\004\b\033\020\034J\r\020\036\032\0020\035¢\006\004\b\036\020\037J&\020&\032\0020%*\0020 2\006\020\"\032\0020!2\006\020$\032\0020#H\026ø\001\000¢\006\004\b&\020'J\017\020)\032\0020(H\026¢\006\004\b)\020*R\"\020\004\032\0020\0038\006@\006X\016¢\006\022\n\004\b+\020,\032\004\b-\020.\"\004\b/\0200R\"\020\005\032\0020\0038\006@\006X\016¢\006\022\n\004\b1\020,\032\004\b2\020.\"\004\b3\0200R\"\020\006\032\0020\0038\006@\006X\016¢\006\022\n\004\b4\020,\032\004\b5\020.\"\004\b6\0200R\"\020\007\032\0020\0038\006@\006X\016¢\006\022\n\004\b7\020,\032\004\b8\020.\"\004\b9\0200R\"\020\b\032\0020\0038\006@\006X\016¢\006\022\n\004\b:\020,\032\004\b;\020.\"\004\b<\0200R\"\020\t\032\0020\0038\006@\006X\016¢\006\022\n\004\b=\020,\032\004\b>\020.\"\004\b?\0200R\"\020\n\032\0020\0038\006@\006X\016¢\006\022\n\004\b@\020,\032\004\bA\020.\"\004\b1\0200R\"\020\013\032\0020\0038\006@\006X\016¢\006\022\n\004\bB\020,\032\004\bC\020.\"\004\b4\0200R\"\020\f\032\0020\0038\006@\006X\016¢\006\022\n\004\bD\020,\032\004\bE\020.\"\004\b7\0200R\"\020\r\032\0020\0038\006@\006X\016¢\006\022\n\004\bF\020,\032\004\bG\020.\"\004\b+\0200R(\020\017\032\0020\0168\006@\006X\016ø\001\000ø\001\001¢\006\022\n\004\bH\020I\032\004\bJ\020K\"\004\bL\020MR\"\020\021\032\0020\0208\006@\006X\016¢\006\022\n\004\bE\020N\032\004\bO\020P\"\004\bQ\020RR\"\020\023\032\0020\0228\006@\006X\016¢\006\022\n\004\b/\020S\032\004\bT\020U\"\004\bV\020WR(\020\027\032\0020\0268\006@\006X\016ø\001\000ø\001\001¢\006\022\n\004\bJ\020I\032\004\bX\020K\"\004\bY\020MR(\020\030\032\0020\0268\006@\006X\016ø\001\000ø\001\001¢\006\022\n\004\b3\020I\032\004\bZ\020K\"\004\b[\020MR(\020\032\032\0020\0318\006@\006X\016ø\001\000ø\001\001¢\006\022\n\004\b9\020\\\032\004\b]\020^\"\004\b_\020`R\"\020e\032\016\022\004\022\0020b\022\004\022\0020\0350a8\002@\002X\016¢\006\006\n\004\bc\020dR$\020\025\032\004\030\0010\0248\006@\006X\016¢\006\022\n\004\b\025\020f\032\004\bg\020h\"\004\bi\020jR\024\020l\032\0020\0228VX\004¢\006\006\032\004\bk\020U\002\013\n\005\b¡\0360\001\n\002\b!¨\006m"}, d2 = {"Landroidx/compose/ui/graphics/e;", "Ldbxyzptlk/f1/w;", "Landroidx/compose/ui/d$c;", "", "scaleX", "scaleY", "alpha", "translationX", "translationY", "shadowElevation", "rotationX", "rotationY", "rotationZ", "cameraDistance", "Landroidx/compose/ui/graphics/f;", "transformOrigin", "Ldbxyzptlk/Q0/a1;", "shape", "", "clip", "Ldbxyzptlk/Q0/V0;", "renderEffect", "Ldbxyzptlk/Q0/r0;", "ambientShadowColor", "spotShadowColor", "Landroidx/compose/ui/graphics/a;", "compositingStrategy", "<init>", "(FFFFFFFFFFJLdbxyzptlk/Q0/a1;ZLdbxyzptlk/Q0/V0;JJILkotlin/jvm/internal/DefaultConstructorMarker;)V", "Ldbxyzptlk/pI/D;", "t2", "()V", "Ldbxyzptlk/d1/I;", "Ldbxyzptlk/d1/F;", "measurable", "Ldbxyzptlk/z1/b;", "constraints", "Ldbxyzptlk/d1/H;", "d", "(Ldbxyzptlk/d1/I;Ldbxyzptlk/d1/F;J)Ldbxyzptlk/d1/H;", "", "toString", "()Ljava/lang/String;", "n", "F", "c1", "()F", "z", "(F)V", "o", "E1", "B", "p", "l2", "setAlpha", "q", "x0", "C", "r", "u0", "f", "s", "q2", "h0", "t", "A1", "u", "M0", "v", "y", "w", "Y", "x", "J", "A", "()J", "c0", "(J)V", "Ldbxyzptlk/Q0/a1;", "r2", "()Ldbxyzptlk/Q0/a1;", "Z0", "(Ldbxyzptlk/Q0/a1;)V", "Z", "n2", "()Z", "b0", "(Z)V", "m2", "P0", "s2", "X0", "I", "o2", "()I", "g", "(I)V", "Lkotlin/Function1;", "Landroidx/compose/ui/graphics/c;", "D", "Ldbxyzptlk/CI/l;", "layerBlock", "Ldbxyzptlk/Q0/V0;", "p2", "()Ldbxyzptlk/Q0/V0;", "k", "(Ldbxyzptlk/Q0/V0;)V", "P1", "shouldAutoInvalidate", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class e extends d.c implements w {
  public long A;
  
  public long B;
  
  public int C;
  
  public l<? super c, D> D;
  
  public float n;
  
  public float o;
  
  public float p;
  
  public float q;
  
  public float r;
  
  public float s;
  
  public float t;
  
  public float u;
  
  public float v;
  
  public float w;
  
  public long x;
  
  public a1 y;
  
  public boolean z;
  
  public e(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, float paramFloat10, long paramLong1, a1 parama1, boolean paramBoolean, V0 paramV0, long paramLong2, long paramLong3, int paramInt) {
    this.n = paramFloat1;
    this.o = paramFloat2;
    this.p = paramFloat3;
    this.q = paramFloat4;
    this.r = paramFloat5;
    this.s = paramFloat6;
    this.t = paramFloat7;
    this.u = paramFloat8;
    this.v = paramFloat9;
    this.w = paramFloat10;
    this.x = paramLong1;
    this.y = parama1;
    this.z = paramBoolean;
    this.A = paramLong2;
    this.B = paramLong3;
    this.C = paramInt;
    this.D = new a(this);
  }
  
  public final long A() {
    return this.x;
  }
  
  public final float A1() {
    return this.t;
  }
  
  public final void B(float paramFloat) {
    this.o = paramFloat;
  }
  
  public final void C(float paramFloat) {
    this.q = paramFloat;
  }
  
  public final float E1() {
    return this.o;
  }
  
  public final float M0() {
    return this.u;
  }
  
  public final void P0(long paramLong) {
    this.A = paramLong;
  }
  
  public boolean P1() {
    return false;
  }
  
  public final void X0(long paramLong) {
    this.B = paramLong;
  }
  
  public final float Y() {
    return this.w;
  }
  
  public final void Z0(a1 parama1) {
    this.y = parama1;
  }
  
  public final void b0(boolean paramBoolean) {
    this.z = paramBoolean;
  }
  
  public final void c0(long paramLong) {
    this.x = paramLong;
  }
  
  public final float c1() {
    return this.n;
  }
  
  public H d(I paramI, F paramF, long paramLong) {
    Y y = paramF.d0(paramLong);
    return I.q1(paramI, y.Q0(), y.B0(), null, new b(y, this), 4, null);
  }
  
  public final void f(float paramFloat) {
    this.r = paramFloat;
  }
  
  public final void g(int paramInt) {
    this.C = paramInt;
  }
  
  public final void h0(float paramFloat) {
    this.s = paramFloat;
  }
  
  public final void k(V0 paramV0) {}
  
  public final float l2() {
    return this.p;
  }
  
  public final long m2() {
    return this.A;
  }
  
  public final void n(float paramFloat) {
    this.w = paramFloat;
  }
  
  public final boolean n2() {
    return this.z;
  }
  
  public final void o(float paramFloat) {
    this.t = paramFloat;
  }
  
  public final int o2() {
    return this.C;
  }
  
  public final void p(float paramFloat) {
    this.u = paramFloat;
  }
  
  public final V0 p2() {
    return null;
  }
  
  public final void q(float paramFloat) {
    this.v = paramFloat;
  }
  
  public final float q2() {
    return this.s;
  }
  
  public final a1 r2() {
    return this.y;
  }
  
  public final long s2() {
    return this.B;
  }
  
  public final void setAlpha(float paramFloat) {
    this.p = paramFloat;
  }
  
  public final void t2() {
    n n = h.h((g)this, K.a(2)).p2();
    if (n != null)
      n.a3(this.D, true); 
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("SimpleGraphicsLayerModifier(scaleX=");
    stringBuilder.append(this.n);
    stringBuilder.append(", scaleY=");
    stringBuilder.append(this.o);
    stringBuilder.append(", alpha = ");
    stringBuilder.append(this.p);
    stringBuilder.append(", translationX=");
    stringBuilder.append(this.q);
    stringBuilder.append(", translationY=");
    stringBuilder.append(this.r);
    stringBuilder.append(", shadowElevation=");
    stringBuilder.append(this.s);
    stringBuilder.append(", rotationX=");
    stringBuilder.append(this.t);
    stringBuilder.append(", rotationY=");
    stringBuilder.append(this.u);
    stringBuilder.append(", rotationZ=");
    stringBuilder.append(this.v);
    stringBuilder.append(", cameraDistance=");
    stringBuilder.append(this.w);
    stringBuilder.append(", transformOrigin=");
    stringBuilder.append(f.i(this.x));
    stringBuilder.append(", shape=");
    stringBuilder.append(this.y);
    stringBuilder.append(", clip=");
    stringBuilder.append(this.z);
    stringBuilder.append(", renderEffect=");
    stringBuilder.append((Object)null);
    stringBuilder.append(", ambientShadowColor=");
    stringBuilder.append(r0.y(this.A));
    stringBuilder.append(", spotShadowColor=");
    stringBuilder.append(r0.y(this.B));
    stringBuilder.append(", compositingStrategy=");
    stringBuilder.append(a.g(this.C));
    stringBuilder.append(')');
    return stringBuilder.toString();
  }
  
  public final float u0() {
    return this.r;
  }
  
  public final float x0() {
    return this.q;
  }
  
  public final float y() {
    return this.v;
  }
  
  public final void z(float paramFloat) {
    this.n = paramFloat;
  }
  
  @Metadata(d1 = {"\000\f\n\002\030\002\n\002\030\002\n\002\b\002\020\002\032\0020\001*\0020\000H\n¢\006\004\b\002\020\003"}, d2 = {"Landroidx/compose/ui/graphics/c;", "Ldbxyzptlk/pI/D;", "a", "(Landroidx/compose/ui/graphics/c;)V"}, k = 3, mv = {1, 8, 0})
  public static final class a extends u implements l<c, D> {
    public final e f;
    
    public a(e param1e) {
      super(1);
    }
    
    public final void a(c param1c) {
      param1c.z(this.f.c1());
      param1c.B(this.f.E1());
      param1c.setAlpha(this.f.l2());
      param1c.C(this.f.x0());
      param1c.f(this.f.u0());
      param1c.h0(this.f.q2());
      param1c.o(this.f.A1());
      param1c.p(this.f.M0());
      param1c.q(this.f.y());
      param1c.n(this.f.Y());
      param1c.c0(this.f.A());
      param1c.Z0(this.f.r2());
      param1c.b0(this.f.n2());
      this.f.p2();
      param1c.k(null);
      param1c.P0(this.f.m2());
      param1c.X0(this.f.s2());
      param1c.g(this.f.o2());
    }
  }
  
  @Metadata(d1 = {"\000\f\n\002\030\002\n\002\030\002\n\002\b\002\020\002\032\0020\001*\0020\000H\n¢\006\004\b\002\020\003"}, d2 = {"Ldbxyzptlk/d1/Y$a;", "Ldbxyzptlk/pI/D;", "a", "(Ldbxyzptlk/d1/Y$a;)V"}, k = 3, mv = {1, 8, 0})
  public static final class b extends u implements l<Y.a, D> {
    public final Y f;
    
    public final e g;
    
    public b(Y param1Y, e param1e) {
      super(1);
    }
    
    public final void a(Y.a param1a) {
      Y.a.r(param1a, this.f, 0, 0, 0.0F, e.k2(this.g), 4, null);
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compos\\ui\graphics\e.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */