package androidx.compose.ui.graphics;

import androidx.compose.ui.d;
import dbxyzptlk.DI.s;
import dbxyzptlk.Q0.V0;
import dbxyzptlk.Q0.a1;
import dbxyzptlk.Q0.r0;
import dbxyzptlk.f1.G;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

@Metadata(d1 = {"\000\\\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\007\n\002\b\n\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020\013\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\006\n\002\030\002\n\002\b\002\n\002\020\016\n\002\b\002\n\002\020\b\n\002\b\002\n\002\020\000\n\002\b+\b\b\030\0002\b\022\004\022\0020\0020\001B\001\022\006\020\004\032\0020\003\022\006\020\005\032\0020\003\022\006\020\006\032\0020\003\022\006\020\007\032\0020\003\022\006\020\b\032\0020\003\022\006\020\t\032\0020\003\022\006\020\n\032\0020\003\022\006\020\013\032\0020\003\022\006\020\f\032\0020\003\022\006\020\r\032\0020\003\022\006\020\017\032\0020\016\022\006\020\021\032\0020\020\022\006\020\023\032\0020\022\022\b\020\025\032\004\030\0010\024\022\006\020\027\032\0020\026\022\006\020\030\032\0020\026\022\006\020\032\032\0020\031¢\006\004\b\033\020\034J\017\020\035\032\0020\002H\026¢\006\004\b\035\020\036J\027\020!\032\0020 2\006\020\037\032\0020\002H\026¢\006\004\b!\020\"J\020\020$\032\0020#HÖ\001¢\006\004\b$\020%J\020\020'\032\0020&HÖ\001¢\006\004\b'\020(J\032\020+\032\0020\0222\b\020*\032\004\030\0010)HÖ\003¢\006\004\b+\020,R\027\020\004\032\0020\0038\006¢\006\f\n\004\b-\020.\032\004\b/\0200R\027\020\005\032\0020\0038\006¢\006\f\n\004\b1\020.\032\004\b2\0200R\027\020\006\032\0020\0038\006¢\006\f\n\004\b3\020.\032\004\b4\0200R\027\020\007\032\0020\0038\006¢\006\f\n\004\b5\020.\032\004\b6\0200R\027\020\b\032\0020\0038\006¢\006\f\n\004\b7\020.\032\004\b8\0200R\027\020\t\032\0020\0038\006¢\006\f\n\004\b9\020.\032\004\b:\0200R\027\020\n\032\0020\0038\006¢\006\f\n\004\b;\020.\032\004\b<\0200R\027\020\013\032\0020\0038\006¢\006\f\n\004\b\035\020.\032\004\b=\0200R\027\020\f\032\0020\0038\006¢\006\f\n\004\b>\020.\032\004\b?\0200R\027\020\r\032\0020\0038\006¢\006\f\n\004\b!\020.\032\004\b@\0200R\035\020\017\032\0020\0168\006ø\001\000ø\001\001¢\006\f\n\004\bA\020B\032\004\bC\020DR\027\020\021\032\0020\0208\006¢\006\f\n\004\bE\020F\032\004\bG\020HR\027\020\023\032\0020\0228\006¢\006\f\n\004\bI\020J\032\004\bK\020LR\035\020\027\032\0020\0268\006ø\001\000ø\001\001¢\006\f\n\004\bM\020B\032\004\bN\020DR\035\020\030\032\0020\0268\006ø\001\000ø\001\001¢\006\f\n\004\bO\020B\032\004\bP\020DR\035\020\032\032\0020\0318\006ø\001\000ø\001\001¢\006\f\n\004\bQ\020R\032\004\bS\020(\002\013\n\005\b¡\0360\001\n\002\b!¨\006T"}, d2 = {"Landroidx/compose/ui/graphics/GraphicsLayerElement;", "Ldbxyzptlk/f1/G;", "Landroidx/compose/ui/graphics/e;", "", "scaleX", "scaleY", "alpha", "translationX", "translationY", "shadowElevation", "rotationX", "rotationY", "rotationZ", "cameraDistance", "Landroidx/compose/ui/graphics/f;", "transformOrigin", "Ldbxyzptlk/Q0/a1;", "shape", "", "clip", "Ldbxyzptlk/Q0/V0;", "renderEffect", "Ldbxyzptlk/Q0/r0;", "ambientShadowColor", "spotShadowColor", "Landroidx/compose/ui/graphics/a;", "compositingStrategy", "<init>", "(FFFFFFFFFFJLdbxyzptlk/Q0/a1;ZLdbxyzptlk/Q0/V0;JJILkotlin/jvm/internal/DefaultConstructorMarker;)V", "i", "()Landroidx/compose/ui/graphics/e;", "node", "Ldbxyzptlk/pI/D;", "k", "(Landroidx/compose/ui/graphics/e;)V", "", "toString", "()Ljava/lang/String;", "", "hashCode", "()I", "", "other", "equals", "(Ljava/lang/Object;)Z", "b", "F", "getScaleX", "()F", "c", "getScaleY", "d", "getAlpha", "e", "getTranslationX", "f", "getTranslationY", "g", "getShadowElevation", "h", "getRotationX", "getRotationY", "j", "getRotationZ", "getCameraDistance", "l", "J", "getTransformOrigin-SzJe1aQ", "()J", "m", "Ldbxyzptlk/Q0/a1;", "getShape", "()Ldbxyzptlk/Q0/a1;", "n", "Z", "getClip", "()Z", "o", "getAmbientShadowColor-0d7_KjU", "p", "getSpotShadowColor-0d7_KjU", "q", "I", "getCompositingStrategy--NrFUSI", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
final class GraphicsLayerElement extends G<e> {
  public final float b;
  
  public final float c;
  
  public final float d;
  
  public final float e;
  
  public final float f;
  
  public final float g;
  
  public final float h;
  
  public final float i;
  
  public final float j;
  
  public final float k;
  
  public final long l;
  
  public final a1 m;
  
  public final boolean n;
  
  public final long o;
  
  public final long p;
  
  public final int q;
  
  public GraphicsLayerElement(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, float paramFloat10, long paramLong1, a1 parama1, boolean paramBoolean, V0 paramV0, long paramLong2, long paramLong3, int paramInt) {
    this.b = paramFloat1;
    this.c = paramFloat2;
    this.d = paramFloat3;
    this.e = paramFloat4;
    this.f = paramFloat5;
    this.g = paramFloat6;
    this.h = paramFloat7;
    this.i = paramFloat8;
    this.j = paramFloat9;
    this.k = paramFloat10;
    this.l = paramLong1;
    this.m = parama1;
    this.n = paramBoolean;
    this.o = paramLong2;
    this.p = paramLong3;
    this.q = paramInt;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof GraphicsLayerElement))
      return false; 
    paramObject = paramObject;
    return (Float.compare(this.b, ((GraphicsLayerElement)paramObject).b) != 0) ? false : ((Float.compare(this.c, ((GraphicsLayerElement)paramObject).c) != 0) ? false : ((Float.compare(this.d, ((GraphicsLayerElement)paramObject).d) != 0) ? false : ((Float.compare(this.e, ((GraphicsLayerElement)paramObject).e) != 0) ? false : ((Float.compare(this.f, ((GraphicsLayerElement)paramObject).f) != 0) ? false : ((Float.compare(this.g, ((GraphicsLayerElement)paramObject).g) != 0) ? false : ((Float.compare(this.h, ((GraphicsLayerElement)paramObject).h) != 0) ? false : ((Float.compare(this.i, ((GraphicsLayerElement)paramObject).i) != 0) ? false : ((Float.compare(this.j, ((GraphicsLayerElement)paramObject).j) != 0) ? false : ((Float.compare(this.k, ((GraphicsLayerElement)paramObject).k) != 0) ? false : (!f.e(this.l, ((GraphicsLayerElement)paramObject).l) ? false : (!s.c(this.m, ((GraphicsLayerElement)paramObject).m) ? false : ((this.n != ((GraphicsLayerElement)paramObject).n) ? false : (!s.c(null, null) ? false : (!r0.r(this.o, ((GraphicsLayerElement)paramObject).o) ? false : (!r0.r(this.p, ((GraphicsLayerElement)paramObject).p) ? false : (!!a.e(this.q, ((GraphicsLayerElement)paramObject).q)))))))))))))))));
  }
  
  public int hashCode() {
    return ((((((((((((((Float.hashCode(this.b) * 31 + Float.hashCode(this.c)) * 31 + Float.hashCode(this.d)) * 31 + Float.hashCode(this.e)) * 31 + Float.hashCode(this.f)) * 31 + Float.hashCode(this.g)) * 31 + Float.hashCode(this.h)) * 31 + Float.hashCode(this.i)) * 31 + Float.hashCode(this.j)) * 31 + Float.hashCode(this.k)) * 31 + f.h(this.l)) * 31 + this.m.hashCode()) * 31 + Boolean.hashCode(this.n)) * 961 + r0.x(this.o)) * 31 + r0.x(this.p)) * 31 + a.f(this.q);
  }
  
  public e i() {
    return new e(this.b, this.c, this.d, this.e, this.f, this.g, this.h, this.i, this.j, this.k, this.l, this.m, this.n, null, this.o, this.p, this.q, null);
  }
  
  public void k(e parame) {
    parame.z(this.b);
    parame.B(this.c);
    parame.setAlpha(this.d);
    parame.C(this.e);
    parame.f(this.f);
    parame.h0(this.g);
    parame.o(this.h);
    parame.p(this.i);
    parame.q(this.j);
    parame.n(this.k);
    parame.c0(this.l);
    parame.Z0(this.m);
    parame.b0(this.n);
    parame.k(null);
    parame.P0(this.o);
    parame.X0(this.p);
    parame.g(this.q);
    parame.t2();
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("GraphicsLayerElement(scaleX=");
    stringBuilder.append(this.b);
    stringBuilder.append(", scaleY=");
    stringBuilder.append(this.c);
    stringBuilder.append(", alpha=");
    stringBuilder.append(this.d);
    stringBuilder.append(", translationX=");
    stringBuilder.append(this.e);
    stringBuilder.append(", translationY=");
    stringBuilder.append(this.f);
    stringBuilder.append(", shadowElevation=");
    stringBuilder.append(this.g);
    stringBuilder.append(", rotationX=");
    stringBuilder.append(this.h);
    stringBuilder.append(", rotationY=");
    stringBuilder.append(this.i);
    stringBuilder.append(", rotationZ=");
    stringBuilder.append(this.j);
    stringBuilder.append(", cameraDistance=");
    stringBuilder.append(this.k);
    stringBuilder.append(", transformOrigin=");
    stringBuilder.append(f.i(this.l));
    stringBuilder.append(", shape=");
    stringBuilder.append(this.m);
    stringBuilder.append(", clip=");
    stringBuilder.append(this.n);
    stringBuilder.append(", renderEffect=");
    stringBuilder.append((Object)null);
    stringBuilder.append(", ambientShadowColor=");
    stringBuilder.append(r0.y(this.o));
    stringBuilder.append(", spotShadowColor=");
    stringBuilder.append(r0.y(this.p));
    stringBuilder.append(", compositingStrategy=");
    stringBuilder.append(a.g(this.q));
    stringBuilder.append(')');
    return stringBuilder.toString();
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compos\\ui\graphics\GraphicsLayerElement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */