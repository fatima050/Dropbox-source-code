package androidx.compose.ui.graphics;

import androidx.compose.ui.d;
import dbxyzptlk.CI.l;
import dbxyzptlk.Q0.C0;
import dbxyzptlk.Q0.U0;
import dbxyzptlk.Q0.V0;
import dbxyzptlk.Q0.a1;
import dbxyzptlk.g1.p0;
import dbxyzptlk.pI.D;
import kotlin.Metadata;

@Metadata(d1 = {"\000D\n\002\030\002\n\002\020\007\n\002\b\n\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020\013\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\003\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\006\032Â\001\020\031\032\0020\000*\0020\0002\b\b\002\020\002\032\0020\0012\b\b\002\020\003\032\0020\0012\b\b\002\020\004\032\0020\0012\b\b\002\020\005\032\0020\0012\b\b\002\020\006\032\0020\0012\b\b\002\020\007\032\0020\0012\b\b\002\020\b\032\0020\0012\b\b\002\020\t\032\0020\0012\b\b\002\020\n\032\0020\0012\b\b\002\020\013\032\0020\0012\b\b\002\020\r\032\0020\f2\b\b\002\020\017\032\0020\0162\b\b\002\020\021\032\0020\0202\n\b\002\020\023\032\004\030\0010\0222\b\b\002\020\025\032\0020\0242\b\b\002\020\026\032\0020\0242\b\b\002\020\030\032\0020\027H\007ø\001\000¢\006\004\b\031\020\032\032'\020\037\032\0020\000*\0020\0002\022\020\036\032\016\022\004\022\0020\034\022\004\022\0020\0350\033H\007¢\006\004\b\037\020 \032\023\020!\032\0020\000*\0020\000H\007¢\006\004\b!\020\"\002\007\n\005\b¡\0360\001¨\006#"}, d2 = {"Landroidx/compose/ui/d;", "", "scaleX", "scaleY", "alpha", "translationX", "translationY", "shadowElevation", "rotationX", "rotationY", "rotationZ", "cameraDistance", "Landroidx/compose/ui/graphics/f;", "transformOrigin", "Ldbxyzptlk/Q0/a1;", "shape", "", "clip", "Ldbxyzptlk/Q0/V0;", "renderEffect", "Ldbxyzptlk/Q0/r0;", "ambientShadowColor", "spotShadowColor", "Landroidx/compose/ui/graphics/a;", "compositingStrategy", "b", "(Landroidx/compose/ui/d;FFFFFFFFFFJLdbxyzptlk/Q0/a1;ZLdbxyzptlk/Q0/V0;JJI)Landroidx/compose/ui/d;", "Lkotlin/Function1;", "Landroidx/compose/ui/graphics/c;", "Ldbxyzptlk/pI/D;", "block", "a", "(Landroidx/compose/ui/d;Ldbxyzptlk/CI/l;)Landroidx/compose/ui/d;", "d", "(Landroidx/compose/ui/d;)Landroidx/compose/ui/d;", "ui_release"}, k = 2, mv = {1, 8, 0}, xi = 48)
public final class b {
  public static final d a(d paramd, l<? super c, D> paraml) {
    return paramd.g((d)new BlockGraphicsLayerElement(paraml));
  }
  
  public static final d b(d paramd, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, float paramFloat10, long paramLong1, a1 parama1, boolean paramBoolean, V0 paramV0, long paramLong2, long paramLong3, int paramInt) {
    return paramd.g((d)new GraphicsLayerElement(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramFloat7, paramFloat8, paramFloat9, paramFloat10, paramLong1, parama1, paramBoolean, paramV0, paramLong2, paramLong3, paramInt, null));
  }
  
  public static final d d(d paramd) {
    if (p0.c())
      paramd = paramd.g(c((d)d.a, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0L, null, false, null, 0L, 0L, 0, 131071, null)); 
    return paramd;
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compos\\ui\graphics\b.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */