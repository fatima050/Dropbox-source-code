package androidx.compose.ui.graphics;

import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

@Metadata(d1 = {"\000\030\n\002\030\002\n\002\020\000\n\002\020\b\n\002\b\003\n\002\020\016\n\002\b\005\b@\030\000 \n2\0020\001:\001\nB\021\b\000\022\006\020\003\032\0020\002¢\006\004\b\004\020\005J\020\020\007\032\0020\006HÖ\001¢\006\004\b\007\020\bJ\020\020\t\032\0020\002HÖ\001¢\006\004\b\t\020\005\001\003\001\0020\002¨\006\013"}, d2 = {"Landroidx/compose/ui/graphics/a;", "", "", "value", "d", "(I)I", "", "g", "(I)Ljava/lang/String;", "f", "a", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class a {
  public static final a a = new a(null);
  
  public static final int b = d(0);
  
  public static final int c = d(1);
  
  public static final int d = d(2);
  
  public static int d(int paramInt) {
    return paramInt;
  }
  
  public static final boolean e(int paramInt1, int paramInt2) {
    boolean bool;
    if (paramInt1 == paramInt2) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public static int f(int paramInt) {
    return Integer.hashCode(paramInt);
  }
  
  public static String g(int paramInt) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("CompositingStrategy(value=");
    stringBuilder.append(paramInt);
    stringBuilder.append(')');
    return stringBuilder.toString();
  }
  
  @Metadata(d1 = {"\000\024\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\b\t\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003R\035\020\005\032\0020\0048\006ø\001\000ø\001\001¢\006\f\n\004\b\005\020\006\032\004\b\007\020\bR\035\020\t\032\0020\0048\006ø\001\000ø\001\001¢\006\f\n\004\b\t\020\006\032\004\b\n\020\bR\035\020\013\032\0020\0048\006ø\001\000ø\001\001¢\006\f\n\004\b\013\020\006\032\004\b\f\020\b\002\013\n\005\b¡\0360\001\n\002\b!¨\006\r"}, d2 = {"Landroidx/compose/ui/graphics/a$a;", "", "<init>", "()V", "Landroidx/compose/ui/graphics/a;", "Auto", "I", "a", "()I", "Offscreen", "c", "ModulateAlpha", "b", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class a {
    public a() {}
    
    public final int a() {
      return a.a();
    }
    
    public final int b() {
      return a.b();
    }
    
    public final int c() {
      return a.c();
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compos\\ui\graphics\a.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */