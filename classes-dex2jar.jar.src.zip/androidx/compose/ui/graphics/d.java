package androidx.compose.ui.graphics;

import dbxyzptlk.DI.s;
import dbxyzptlk.P0.l;
import dbxyzptlk.Q0.C0;
import dbxyzptlk.Q0.U0;
import dbxyzptlk.Q0.V0;
import dbxyzptlk.Q0.a1;
import dbxyzptlk.Q0.r0;
import dbxyzptlk.z1.f;
import kotlin.Metadata;

@Metadata(d1 = {"\000`\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\020\b\n\002\b\007\n\002\020\007\n\002\b\032\n\002\030\002\n\002\b\031\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\006\n\002\020\013\n\002\b\005\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\013\n\002\030\002\n\002\b\005\b\000\030\0002\0020\001B\007¢\006\004\b\002\020\003J\r\020\005\032\0020\004¢\006\004\b\005\020\003R\"\020\r\032\0020\0068\000@\000X\016¢\006\022\n\004\b\007\020\b\032\004\b\t\020\n\"\004\b\013\020\fR*\020\026\032\0020\0162\006\020\017\032\0020\0168\026@VX\016¢\006\022\n\004\b\020\020\021\032\004\b\022\020\023\"\004\b\024\020\025R*\020\032\032\0020\0162\006\020\017\032\0020\0168\026@VX\016¢\006\022\n\004\b\027\020\021\032\004\b\030\020\023\"\004\b\031\020\025R*\020\035\032\0020\0162\006\020\017\032\0020\0168\026@VX\016¢\006\022\n\004\b\033\020\021\032\004\b\020\020\023\"\004\b\034\020\025R*\020!\032\0020\0162\006\020\017\032\0020\0168\026@VX\016¢\006\022\n\004\b\036\020\021\032\004\b\037\020\023\"\004\b \020\025R*\020$\032\0020\0162\006\020\017\032\0020\0168\026@VX\016¢\006\022\n\004\b\"\020\021\032\004\b#\020\023\"\004\b\"\020\025R*\020(\032\0020\0162\006\020\017\032\0020\0168\026@VX\016¢\006\022\n\004\b%\020\021\032\004\b&\020\023\"\004\b'\020\025R0\020/\032\0020)2\006\020\017\032\0020)8\026@VX\016ø\001\000ø\001\001¢\006\022\n\004\b*\020+\032\004\b\033\020,\"\004\b-\020.R0\0203\032\0020)2\006\020\017\032\0020)8\026@VX\016ø\001\000ø\001\001¢\006\022\n\004\b0\020+\032\004\b1\020,\"\004\b2\020.R*\0207\032\0020\0162\006\020\017\032\0020\0168\026@VX\016¢\006\022\n\004\b4\020\021\032\004\b5\020\023\"\004\b6\020\025R*\020;\032\0020\0162\006\020\017\032\0020\0168\026@VX\016¢\006\022\n\004\b8\020\021\032\004\b9\020\023\"\004\b:\020\025R*\020>\032\0020\0162\006\020\017\032\0020\0168\026@VX\016¢\006\022\n\004\b\t\020\021\032\004\b<\020\023\"\004\b=\020\025R*\020B\032\0020\0162\006\020\017\032\0020\0168\026@VX\016¢\006\022\n\004\b?\020\021\032\004\b@\020\023\"\004\bA\020\025R0\020F\032\0020C2\006\020\017\032\0020C8\026@VX\016ø\001\000ø\001\001¢\006\022\n\004\bA\020+\032\004\bD\020,\"\004\bE\020.R*\020M\032\0020G2\006\020\017\032\0020G8\026@VX\016¢\006\022\n\004\b6\020H\032\004\bI\020J\"\004\bK\020LR*\020S\032\0020N2\006\020\017\032\0020N8\026@VX\016¢\006\022\n\004\b:\020O\032\004\b*\020P\"\004\bQ\020RR0\020U\032\0020T2\006\020\017\032\0020T8\026@VX\016ø\001\000ø\001\001¢\006\022\n\004\b=\020\b\032\004\b4\020\n\"\004\b%\020\fR(\020X\032\0020V8\026@\026X\016ø\001\000ø\001\001¢\006\022\n\004\b&\020+\032\004\b\027\020,\"\004\bW\020.R\"\020`\032\0020Y8\000@\000X\016¢\006\022\n\004\bZ\020[\032\004\b\\\020]\"\004\b^\020_R\024\020b\032\0020\0168VX\004¢\006\006\032\004\ba\020\023R\024\020d\032\0020\0168VX\004¢\006\006\032\004\bc\020\023R.\020f\032\004\030\0010e2\b\020\017\032\004\030\0010e8\026@VX\016¢\006\022\n\004\bf\020g\032\004\b?\020h\"\004\b8\020i\002\013\n\005\b¡\0360\001\n\002\b!¨\006j"}, d2 = {"Landroidx/compose/ui/graphics/d;", "Landroidx/compose/ui/graphics/c;", "<init>", "()V", "Ldbxyzptlk/pI/D;", "x", "", "a", "I", "l", "()I", "setMutatedFields$ui_release", "(I)V", "mutatedFields", "", "value", "b", "F", "c1", "()F", "z", "(F)V", "scaleX", "c", "E1", "B", "scaleY", "d", "setAlpha", "alpha", "e", "x0", "C", "translationX", "f", "u0", "translationY", "g", "r", "h0", "shadowElevation", "Ldbxyzptlk/Q0/r0;", "h", "J", "()J", "P0", "(J)V", "ambientShadowColor", "i", "v", "X0", "spotShadowColor", "j", "A1", "o", "rotationX", "k", "M0", "p", "rotationY", "y", "q", "rotationZ", "m", "Y", "n", "cameraDistance", "Landroidx/compose/ui/graphics/f;", "A", "c0", "transformOrigin", "Ldbxyzptlk/Q0/a1;", "Ldbxyzptlk/Q0/a1;", "u", "()Ldbxyzptlk/Q0/a1;", "Z0", "(Ldbxyzptlk/Q0/a1;)V", "shape", "", "Z", "()Z", "b0", "(Z)V", "clip", "Landroidx/compose/ui/graphics/a;", "compositingStrategy", "Ldbxyzptlk/P0/l;", "E", "size", "Ldbxyzptlk/z1/d;", "s", "Ldbxyzptlk/z1/d;", "getGraphicsDensity$ui_release", "()Ldbxyzptlk/z1/d;", "D", "(Ldbxyzptlk/z1/d;)V", "graphicsDensity", "getDensity", "density", "v1", "fontScale", "Ldbxyzptlk/Q0/V0;", "renderEffect", "Ldbxyzptlk/Q0/V0;", "()Ldbxyzptlk/Q0/V0;", "(Ldbxyzptlk/Q0/V0;)V", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class d implements c {
  public int a;
  
  public float b = 1.0F;
  
  public float c = 1.0F;
  
  public float d = 1.0F;
  
  public float e;
  
  public float f;
  
  public float g;
  
  public long h = C0.a();
  
  public long i = C0.a();
  
  public float j;
  
  public float k;
  
  public float l;
  
  public float m = 8.0F;
  
  public long n = f.b.a();
  
  public a1 o = U0.a();
  
  public boolean p;
  
  public int q = a.a.a();
  
  public long r = l.b.a();
  
  public dbxyzptlk.z1.d s = f.b(1.0F, 0.0F, 2, null);
  
  public long A() {
    return this.n;
  }
  
  public float A1() {
    return this.j;
  }
  
  public void B(float paramFloat) {
    if (this.c != paramFloat) {
      this.a |= 0x2;
      this.c = paramFloat;
    } 
  }
  
  public void C(float paramFloat) {
    if (this.e != paramFloat) {
      this.a |= 0x8;
      this.e = paramFloat;
    } 
  }
  
  public final void D(dbxyzptlk.z1.d paramd) {
    this.s = paramd;
  }
  
  public void E(long paramLong) {
    this.r = paramLong;
  }
  
  public float E1() {
    return this.c;
  }
  
  public float M0() {
    return this.k;
  }
  
  public void P0(long paramLong) {
    if (!r0.r(this.h, paramLong)) {
      this.a |= 0x40;
      this.h = paramLong;
    } 
  }
  
  public void X0(long paramLong) {
    if (!r0.r(this.i, paramLong)) {
      this.a |= 0x80;
      this.i = paramLong;
    } 
  }
  
  public float Y() {
    return this.m;
  }
  
  public void Z0(a1 parama1) {
    if (!s.c(this.o, parama1)) {
      this.a |= 0x2000;
      this.o = parama1;
    } 
  }
  
  public float b() {
    return this.d;
  }
  
  public void b0(boolean paramBoolean) {
    if (this.p != paramBoolean) {
      this.a |= 0x4000;
      this.p = paramBoolean;
    } 
  }
  
  public long c() {
    return this.r;
  }
  
  public void c0(long paramLong) {
    if (!f.e(this.n, paramLong)) {
      this.a |= 0x1000;
      this.n = paramLong;
    } 
  }
  
  public float c1() {
    return this.b;
  }
  
  public long d() {
    return this.h;
  }
  
  public void f(float paramFloat) {
    if (this.f != paramFloat) {
      this.a |= 0x10;
      this.f = paramFloat;
    } 
  }
  
  public void g(int paramInt) {
    if (!a.e(this.q, paramInt)) {
      this.a |= 0x8000;
      this.q = paramInt;
    } 
  }
  
  public float getDensity() {
    return this.s.getDensity();
  }
  
  public boolean h() {
    return this.p;
  }
  
  public void h0(float paramFloat) {
    if (this.g != paramFloat) {
      this.a |= 0x20;
      this.g = paramFloat;
    } 
  }
  
  public int j() {
    return this.q;
  }
  
  public void k(V0 paramV0) {
    if (!s.c(null, paramV0))
      this.a |= 0x20000; 
  }
  
  public final int l() {
    return this.a;
  }
  
  public V0 m() {
    return null;
  }
  
  public void n(float paramFloat) {
    if (this.m != paramFloat) {
      this.a |= 0x800;
      this.m = paramFloat;
    } 
  }
  
  public void o(float paramFloat) {
    if (this.j != paramFloat) {
      this.a |= 0x100;
      this.j = paramFloat;
    } 
  }
  
  public void p(float paramFloat) {
    if (this.k != paramFloat) {
      this.a |= 0x200;
      this.k = paramFloat;
    } 
  }
  
  public void q(float paramFloat) {
    if (this.l != paramFloat) {
      this.a |= 0x400;
      this.l = paramFloat;
    } 
  }
  
  public float r() {
    return this.g;
  }
  
  public void setAlpha(float paramFloat) {
    if (this.d != paramFloat) {
      this.a |= 0x4;
      this.d = paramFloat;
    } 
  }
  
  public a1 u() {
    return this.o;
  }
  
  public float u0() {
    return this.f;
  }
  
  public long v() {
    return this.i;
  }
  
  public float v1() {
    return this.s.v1();
  }
  
  public final void x() {
    z(1.0F);
    B(1.0F);
    setAlpha(1.0F);
    C(0.0F);
    f(0.0F);
    h0(0.0F);
    P0(C0.a());
    X0(C0.a());
    o(0.0F);
    p(0.0F);
    q(0.0F);
    n(8.0F);
    c0(f.b.a());
    Z0(U0.a());
    b0(false);
    k(null);
    g(a.a.a());
    E(l.b.a());
    this.a = 0;
  }
  
  public float x0() {
    return this.e;
  }
  
  public float y() {
    return this.l;
  }
  
  public void z(float paramFloat) {
    if (this.b != paramFloat) {
      this.a |= 0x1;
      this.b = paramFloat;
    } 
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compos\\ui\graphics\d.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */