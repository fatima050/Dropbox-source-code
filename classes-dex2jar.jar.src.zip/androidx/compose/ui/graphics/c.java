package androidx.compose.ui.graphics;

import dbxyzptlk.P0.l;
import dbxyzptlk.Q0.V0;
import dbxyzptlk.Q0.a1;
import dbxyzptlk.z1.d;
import kotlin.Metadata;

@Metadata(d1 = {"\000H\n\002\030\002\n\002\030\002\n\002\020\007\n\002\b\024\n\002\030\002\n\002\b\024\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\005\n\002\020\013\n\002\b\007\n\002\030\002\n\002\b\006\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\003\bf\030\0002\0020\001R\034\020\007\032\0020\0028&@&X¦\016¢\006\f\032\004\b\003\020\004\"\004\b\005\020\006R\034\020\n\032\0020\0028&@&X¦\016¢\006\f\032\004\b\b\020\004\"\004\b\t\020\006R\034\020\r\032\0020\0028&@&X¦\016¢\006\f\032\004\b\013\020\004\"\004\b\f\020\006R\034\020\020\032\0020\0028&@&X¦\016¢\006\f\032\004\b\016\020\004\"\004\b\017\020\006R\034\020\023\032\0020\0028&@&X¦\016¢\006\f\032\004\b\021\020\004\"\004\b\022\020\006R\034\020\026\032\0020\0028&@&X¦\016¢\006\f\032\004\b\024\020\004\"\004\b\025\020\006R*\020\030\032\0020\0272\006\020\030\032\0020\0278V@VX\016ø\001\000ø\001\001¢\006\f\032\004\b\031\020\032\"\004\b\033\020\034R*\020\035\032\0020\0272\006\020\035\032\0020\0278V@VX\016ø\001\000ø\001\001¢\006\f\032\004\b\036\020\032\"\004\b\037\020\034R\034\020\"\032\0020\0028&@&X¦\016¢\006\f\032\004\b \020\004\"\004\b!\020\006R\034\020%\032\0020\0028&@&X¦\016¢\006\f\032\004\b#\020\004\"\004\b$\020\006R\034\020(\032\0020\0028&@&X¦\016¢\006\f\032\004\b&\020\004\"\004\b'\020\006R\034\020+\032\0020\0028&@&X¦\016¢\006\f\032\004\b)\020\004\"\004\b*\020\006R\"\020/\032\0020,8&@&X¦\016ø\001\000ø\001\001¢\006\f\032\004\b-\020\032\"\004\b.\020\034R\034\0205\032\002008&@&X¦\016¢\006\f\032\004\b1\0202\"\004\b3\0204R\"\020=\032\002068f@&X¦\016¢\006\022\022\004\b;\020<\032\004\b7\0208\"\004\b9\020:R(\020D\032\004\030\0010>2\b\020?\032\004\030\0010>8V@VX\016¢\006\f\032\004\b@\020A\"\004\bB\020CR*\020F\032\0020E2\006\020F\032\0020E8V@VX\016ø\001\000ø\001\001¢\006\f\032\004\bG\020H\"\004\bI\020JR\032\020M\032\0020K8VX\004ø\001\000ø\001\001¢\006\006\032\004\bL\020\032ø\001\002\002\021\n\005\b¡\0360\001\n\002\b!\n\004\b!0\001¨\006NÀ\006\003"}, d2 = {"Landroidx/compose/ui/graphics/c;", "Ldbxyzptlk/z1/d;", "", "c1", "()F", "z", "(F)V", "scaleX", "E1", "B", "scaleY", "getAlpha", "setAlpha", "alpha", "x0", "C", "translationX", "u0", "f", "translationY", "getShadowElevation", "h0", "shadowElevation", "Ldbxyzptlk/Q0/r0;", "ambientShadowColor", "getAmbientShadowColor-0d7_KjU", "()J", "P0", "(J)V", "spotShadowColor", "getSpotShadowColor-0d7_KjU", "X0", "A1", "o", "rotationX", "M0", "p", "rotationY", "y", "q", "rotationZ", "Y", "n", "cameraDistance", "Landroidx/compose/ui/graphics/f;", "A", "c0", "transformOrigin", "Ldbxyzptlk/Q0/a1;", "getShape", "()Ldbxyzptlk/Q0/a1;", "Z0", "(Ldbxyzptlk/Q0/a1;)V", "shape", "", "getClip", "()Z", "b0", "(Z)V", "getClip$annotations", "()V", "clip", "Ldbxyzptlk/Q0/V0;", "<anonymous parameter 0>", "getRenderEffect", "()Ldbxyzptlk/Q0/V0;", "k", "(Ldbxyzptlk/Q0/V0;)V", "renderEffect", "Landroidx/compose/ui/graphics/a;", "compositingStrategy", "getCompositingStrategy--NrFUSI", "()I", "g", "(I)V", "Ldbxyzptlk/P0/l;", "c", "size", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public interface c extends d {
  long A();
  
  float A1();
  
  void B(float paramFloat);
  
  void C(float paramFloat);
  
  float E1();
  
  float M0();
  
  default void P0(long paramLong) {}
  
  default void X0(long paramLong) {}
  
  float Y();
  
  void Z0(a1 parama1);
  
  void b0(boolean paramBoolean);
  
  default long c() {
    return l.b.a();
  }
  
  void c0(long paramLong);
  
  float c1();
  
  void f(float paramFloat);
  
  default void g(int paramInt) {}
  
  void h0(float paramFloat);
  
  default void k(V0 paramV0) {}
  
  void n(float paramFloat);
  
  void o(float paramFloat);
  
  void p(float paramFloat);
  
  void q(float paramFloat);
  
  void setAlpha(float paramFloat);
  
  float u0();
  
  float x0();
  
  float y();
  
  void z(float paramFloat);
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compos\\ui\graphics\c.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */