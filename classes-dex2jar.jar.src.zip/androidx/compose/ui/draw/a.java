package androidx.compose.ui.draw;

import androidx.compose.ui.d;
import dbxyzptlk.CI.l;
import dbxyzptlk.N0.c;
import dbxyzptlk.N0.d;
import dbxyzptlk.N0.e;
import dbxyzptlk.N0.j;
import dbxyzptlk.S0.c;
import dbxyzptlk.S0.f;
import dbxyzptlk.pI.D;
import kotlin.Metadata;

@Metadata(d1 = {"\0000\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\003\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\032%\020\005\032\0020\000*\0020\0002\022\020\004\032\016\022\004\022\0020\002\022\004\022\0020\0030\001¢\006\004\b\005\020\006\032%\020\n\032\0020\000*\0020\0002\022\020\t\032\016\022\004\022\0020\007\022\004\022\0020\b0\001¢\006\004\b\n\020\006\032!\020\f\032\0020\0132\022\020\t\032\016\022\004\022\0020\007\022\004\022\0020\b0\001¢\006\004\b\f\020\r\032%\020\017\032\0020\000*\0020\0002\022\020\004\032\016\022\004\022\0020\016\022\004\022\0020\0030\001¢\006\004\b\017\020\006¨\006\020"}, d2 = {"Landroidx/compose/ui/d;", "Lkotlin/Function1;", "Ldbxyzptlk/S0/f;", "Ldbxyzptlk/pI/D;", "onDraw", "b", "(Landroidx/compose/ui/d;Ldbxyzptlk/CI/l;)Landroidx/compose/ui/d;", "Ldbxyzptlk/N0/e;", "Ldbxyzptlk/N0/j;", "onBuildDrawCache", "c", "Ldbxyzptlk/N0/c;", "a", "(Ldbxyzptlk/CI/l;)Ldbxyzptlk/N0/c;", "Ldbxyzptlk/S0/c;", "d", "ui_release"}, k = 2, mv = {1, 8, 0}, xi = 48)
public final class a {
  public static final c a(l<? super e, j> paraml) {
    return (c)new d(new e(), paraml);
  }
  
  public static final d b(d paramd, l<? super f, D> paraml) {
    return paramd.g((d)new DrawBehindElement(paraml));
  }
  
  public static final d c(d paramd, l<? super e, j> paraml) {
    return paramd.g((d)new DrawWithCacheElement(paraml));
  }
  
  public static final d d(d paramd, l<? super c, D> paraml) {
    return paramd.g((d)new DrawWithContentElement(paraml));
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compos\\ui\draw\a.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */