package androidx.compose.ui.draw;

import androidx.compose.ui.d;
import dbxyzptlk.DI.s;
import dbxyzptlk.K0.c;
import dbxyzptlk.N0.m;
import dbxyzptlk.P0.l;
import dbxyzptlk.Q0.s0;
import dbxyzptlk.T0.d;
import dbxyzptlk.d1.f;
import dbxyzptlk.f1.G;
import dbxyzptlk.f1.n;
import dbxyzptlk.f1.o;
import dbxyzptlk.f1.w;
import dbxyzptlk.f1.y;
import kotlin.Metadata;

@Metadata(d1 = {"\000R\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\020\013\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020\007\n\000\n\002\030\002\n\002\b\006\n\002\030\002\n\002\b\002\n\002\020\016\n\002\b\002\n\002\020\b\n\002\b\002\n\002\020\000\n\002\b\034\b\b\030\0002\b\022\004\022\0020\0020\001B9\022\006\020\004\032\0020\003\022\006\020\006\032\0020\005\022\006\020\b\032\0020\007\022\006\020\n\032\0020\t\022\006\020\f\032\0020\013\022\b\020\016\032\004\030\0010\r¢\006\004\b\017\020\020J\017\020\021\032\0020\002H\026¢\006\004\b\021\020\022J\027\020\025\032\0020\0242\006\020\023\032\0020\002H\026¢\006\004\b\025\020\026J\020\020\030\032\0020\027HÖ\001¢\006\004\b\030\020\031J\020\020\033\032\0020\032HÖ\001¢\006\004\b\033\020\034J\032\020\037\032\0020\0052\b\020\036\032\004\030\0010\035HÖ\003¢\006\004\b\037\020 R\027\020\004\032\0020\0038\006¢\006\f\n\004\b!\020\"\032\004\b#\020$R\027\020\006\032\0020\0058\006¢\006\f\n\004\b%\020&\032\004\b'\020(R\027\020\b\032\0020\0078\006¢\006\f\n\004\b)\020*\032\004\b+\020,R\027\020\n\032\0020\t8\006¢\006\f\n\004\b-\020.\032\004\b/\0200R\027\020\f\032\0020\0138\006¢\006\f\n\004\b1\0202\032\004\b3\0204R\031\020\016\032\004\030\0010\r8\006¢\006\f\n\004\b5\0206\032\004\b7\0208¨\0069"}, d2 = {"Landroidx/compose/ui/draw/PainterElement;", "Ldbxyzptlk/f1/G;", "Ldbxyzptlk/N0/m;", "Ldbxyzptlk/T0/d;", "painter", "", "sizeToIntrinsics", "Ldbxyzptlk/K0/c;", "alignment", "Ldbxyzptlk/d1/f;", "contentScale", "", "alpha", "Ldbxyzptlk/Q0/s0;", "colorFilter", "<init>", "(Ldbxyzptlk/T0/d;ZLdbxyzptlk/K0/c;Ldbxyzptlk/d1/f;FLdbxyzptlk/Q0/s0;)V", "i", "()Ldbxyzptlk/N0/m;", "node", "Ldbxyzptlk/pI/D;", "k", "(Ldbxyzptlk/N0/m;)V", "", "toString", "()Ljava/lang/String;", "", "hashCode", "()I", "", "other", "equals", "(Ljava/lang/Object;)Z", "b", "Ldbxyzptlk/T0/d;", "getPainter", "()Ldbxyzptlk/T0/d;", "c", "Z", "getSizeToIntrinsics", "()Z", "d", "Ldbxyzptlk/K0/c;", "getAlignment", "()Ldbxyzptlk/K0/c;", "e", "Ldbxyzptlk/d1/f;", "getContentScale", "()Ldbxyzptlk/d1/f;", "f", "F", "getAlpha", "()F", "g", "Ldbxyzptlk/Q0/s0;", "getColorFilter", "()Ldbxyzptlk/Q0/s0;", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
final class PainterElement extends G<m> {
  public final d b;
  
  public final boolean c;
  
  public final c d;
  
  public final f e;
  
  public final float f;
  
  public final s0 g;
  
  public PainterElement(d paramd, boolean paramBoolean, c paramc, f paramf, float paramFloat, s0 params0) {
    this.b = paramd;
    this.c = paramBoolean;
    this.d = paramc;
    this.e = paramf;
    this.f = paramFloat;
    this.g = params0;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof PainterElement))
      return false; 
    paramObject = paramObject;
    return !s.c(this.b, ((PainterElement)paramObject).b) ? false : ((this.c != ((PainterElement)paramObject).c) ? false : (!s.c(this.d, ((PainterElement)paramObject).d) ? false : (!s.c(this.e, ((PainterElement)paramObject).e) ? false : ((Float.compare(this.f, ((PainterElement)paramObject).f) != 0) ? false : (!!s.c(this.g, ((PainterElement)paramObject).g))))));
  }
  
  public int hashCode() {
    int i;
    int k = this.b.hashCode();
    int m = Boolean.hashCode(this.c);
    int i1 = this.d.hashCode();
    int n = this.e.hashCode();
    int j = Float.hashCode(this.f);
    s0 s01 = this.g;
    if (s01 == null) {
      i = 0;
    } else {
      i = s01.hashCode();
    } 
    return ((((k * 31 + m) * 31 + i1) * 31 + n) * 31 + j) * 31 + i;
  }
  
  public m i() {
    return new m(this.b, this.c, this.d, this.e, this.f, this.g);
  }
  
  public void k(m paramm) {
    boolean bool;
    boolean bool2 = paramm.m2();
    boolean bool1 = this.c;
    if (bool2 != bool1 || (bool1 && !l.f(paramm.l2().j(), this.b.j()))) {
      bool = true;
    } else {
      bool = false;
    } 
    paramm.u2(this.b);
    paramm.v2(this.c);
    paramm.r2(this.d);
    paramm.t2(this.e);
    paramm.setAlpha(this.f);
    paramm.s2(this.g);
    if (bool)
      y.b((w)paramm); 
    o.a((n)paramm);
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("PainterElement(painter=");
    stringBuilder.append(this.b);
    stringBuilder.append(", sizeToIntrinsics=");
    stringBuilder.append(this.c);
    stringBuilder.append(", alignment=");
    stringBuilder.append(this.d);
    stringBuilder.append(", contentScale=");
    stringBuilder.append(this.e);
    stringBuilder.append(", alpha=");
    stringBuilder.append(this.f);
    stringBuilder.append(", colorFilter=");
    stringBuilder.append(this.g);
    stringBuilder.append(')');
    return stringBuilder.toString();
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compos\\ui\draw\PainterElement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */