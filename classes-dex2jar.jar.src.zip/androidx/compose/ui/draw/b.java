package androidx.compose.ui.draw;

import androidx.compose.ui.d;
import dbxyzptlk.K0.c;
import dbxyzptlk.Q0.s0;
import dbxyzptlk.T0.d;
import dbxyzptlk.d1.f;
import kotlin.Metadata;

@Metadata(d1 = {"\000*\n\002\030\002\n\002\030\002\n\000\n\002\020\013\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020\007\n\000\n\002\030\002\n\002\b\004\032M\020\r\032\0020\000*\0020\0002\006\020\002\032\0020\0012\b\b\002\020\004\032\0020\0032\b\b\002\020\006\032\0020\0052\b\b\002\020\b\032\0020\0072\b\b\002\020\n\032\0020\t2\n\b\002\020\f\032\004\030\0010\013¢\006\004\b\r\020\016¨\006\017"}, d2 = {"Landroidx/compose/ui/d;", "Ldbxyzptlk/T0/d;", "painter", "", "sizeToIntrinsics", "Ldbxyzptlk/K0/c;", "alignment", "Ldbxyzptlk/d1/f;", "contentScale", "", "alpha", "Ldbxyzptlk/Q0/s0;", "colorFilter", "a", "(Landroidx/compose/ui/d;Ldbxyzptlk/T0/d;ZLdbxyzptlk/K0/c;Ldbxyzptlk/d1/f;FLdbxyzptlk/Q0/s0;)Landroidx/compose/ui/d;", "ui_release"}, k = 2, mv = {1, 8, 0}, xi = 48)
public final class b {
  public static final d a(d paramd, d paramd1, boolean paramBoolean, c paramc, f paramf, float paramFloat, s0 params0) {
    return paramd.g((d)new PainterElement(paramd1, paramBoolean, paramc, paramf, paramFloat, params0));
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compos\\ui\draw\b.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */