package androidx.compose.ui.platform;

import android.content.ComponentCallbacks;
import android.content.ComponentCallbacks2;
import android.content.Context;
import android.content.res.Configuration;
import android.view.View;
import androidx.lifecycle.LifecycleOwner;
import dbxyzptlk.CI.p;
import dbxyzptlk.DI.u;
import dbxyzptlk.g1.E1;
import dbxyzptlk.g1.U;
import dbxyzptlk.g1.d0;
import dbxyzptlk.g1.h0;
import dbxyzptlk.pI.D;
import dbxyzptlk.x0.A0;
import dbxyzptlk.x0.G;
import dbxyzptlk.x0.H;
import dbxyzptlk.x0.J;
import dbxyzptlk.x0.k0;
import dbxyzptlk.x0.n;
import dbxyzptlk.x0.u;
import dbxyzptlk.x0.w0;
import kotlin.KotlinNothingValueException;
import kotlin.Metadata;

@Metadata(d1 = {"\000T\n\002\030\002\n\000\n\002\030\002\n\002\030\002\n\002\b\003\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\020\016\n\000\n\002\020\001\n\002\b\002\n\002\030\002\n\002\b\n\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\032%\020\005\032\0020\0032\006\020\001\032\0020\0002\f\020\004\032\b\022\004\022\0020\0030\002H\001¢\006\004\b\005\020\006\032!\020\f\032\0020\0132\006\020\b\032\0020\0072\b\020\n\032\004\030\0010\tH\003¢\006\004\b\f\020\r\032\027\020\021\032\0020\0202\006\020\017\032\0020\016H\002¢\006\004\b\021\020\022\"\035\020\027\032\b\022\004\022\0020\t0\0238\006¢\006\f\n\004\b\005\020\024\032\004\b\025\020\026\"\035\020\032\032\b\022\004\022\0020\0070\0238\006¢\006\f\n\004\b\030\020\024\032\004\b\031\020\026\" \020\035\032\b\022\004\022\0020\0130\0238\000X\004¢\006\f\n\004\b\033\020\024\032\004\b\034\020\026\"\035\020!\032\b\022\004\022\0020\0360\0238\006¢\006\f\n\004\b\037\020\024\032\004\b \020\026\"\035\020%\032\b\022\004\022\0020\"0\0238\006¢\006\f\n\004\b#\020\024\032\004\b$\020\026\"\035\020(\032\b\022\004\022\0020&0\0238\006¢\006\f\n\004\b\025\020\024\032\004\b'\020\026¨\006)²\006\016\020\n\032\0020\t8\n@\nX\002"}, d2 = {"Landroidx/compose/ui/platform/AndroidComposeView;", "owner", "Lkotlin/Function0;", "Ldbxyzptlk/pI/D;", "content", "a", "(Landroidx/compose/ui/platform/AndroidComposeView;Ldbxyzptlk/CI/p;Ldbxyzptlk/x0/k;I)V", "Landroid/content/Context;", "context", "Landroid/content/res/Configuration;", "configuration", "Ldbxyzptlk/k1/d;", "m", "(Landroid/content/Context;Landroid/content/res/Configuration;Ldbxyzptlk/x0/k;I)Ldbxyzptlk/k1/d;", "", "name", "", "l", "(Ljava/lang/String;)Ljava/lang/Void;", "Ldbxyzptlk/x0/w0;", "Ldbxyzptlk/x0/w0;", "f", "()Ldbxyzptlk/x0/w0;", "LocalConfiguration", "b", "g", "LocalContext", "c", "h", "LocalImageVectorCache", "Landroidx/lifecycle/LifecycleOwner;", "d", "i", "LocalLifecycleOwner", "Ldbxyzptlk/J4/d;", "e", "j", "LocalSavedStateRegistryOwner", "Landroid/view/View;", "k", "LocalView", "ui_release"}, k = 2, mv = {1, 8, 0}, xi = 48)
public final class g {
  public static final w0<Configuration> a = u.d(null, a.f, 1, null);
  
  public static final w0<Context> b = u.e(b.f);
  
  public static final w0<dbxyzptlk.k1.d> c = u.e(c.f);
  
  public static final w0<LifecycleOwner> d = u.e(d.f);
  
  public static final w0<dbxyzptlk.J4.d> e = u.e(e.f);
  
  public static final w0<View> f = u.e(f.f);
  
  public static final void a(AndroidComposeView paramAndroidComposeView, p<? super dbxyzptlk.x0.k, ? super Integer, D> paramp, dbxyzptlk.x0.k paramk, int paramInt) {
    // Byte code:
    //   0: aload_2
    //   1: ldc 1396852028
    //   3: invokeinterface x : (I)Ldbxyzptlk/x0/k;
    //   8: astore #6
    //   10: invokestatic I : ()Z
    //   13: ifeq -> 25
    //   16: ldc 1396852028
    //   18: iload_3
    //   19: iconst_m1
    //   20: ldc 'androidx.compose.ui.platform.ProvideAndroidCompositionLocals (AndroidCompositionLocals.android.kt:83)'
    //   22: invokestatic U : (IIILjava/lang/String;)V
    //   25: aload_0
    //   26: invokevirtual getContext : ()Landroid/content/Context;
    //   29: astore #7
    //   31: aload #6
    //   33: ldc -492369756
    //   35: invokeinterface I : (I)V
    //   40: aload #6
    //   42: invokeinterface J : ()Ljava/lang/Object;
    //   47: astore #5
    //   49: getstatic dbxyzptlk/x0/k.a : Ldbxyzptlk/x0/k$a;
    //   52: astore #10
    //   54: aload #5
    //   56: astore_2
    //   57: aload #5
    //   59: aload #10
    //   61: invokevirtual a : ()Ljava/lang/Object;
    //   64: if_acmpne -> 97
    //   67: new android/content/res/Configuration
    //   70: dup
    //   71: aload #7
    //   73: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   76: invokevirtual getConfiguration : ()Landroid/content/res/Configuration;
    //   79: invokespecial <init> : (Landroid/content/res/Configuration;)V
    //   82: aconst_null
    //   83: iconst_2
    //   84: aconst_null
    //   85: invokestatic j : (Ljava/lang/Object;Ldbxyzptlk/x0/W0;ILjava/lang/Object;)Ldbxyzptlk/x0/k0;
    //   88: astore_2
    //   89: aload #6
    //   91: aload_2
    //   92: invokeinterface D : (Ljava/lang/Object;)V
    //   97: aload #6
    //   99: invokeinterface R : ()V
    //   104: aload_2
    //   105: checkcast dbxyzptlk/x0/k0
    //   108: astore #9
    //   110: aload #6
    //   112: ldc -230243351
    //   114: invokeinterface I : (I)V
    //   119: aload #6
    //   121: aload #9
    //   123: invokeinterface q : (Ljava/lang/Object;)Z
    //   128: istore #4
    //   130: aload #6
    //   132: invokeinterface J : ()Ljava/lang/Object;
    //   137: astore #5
    //   139: iload #4
    //   141: ifne -> 157
    //   144: aload #5
    //   146: astore_2
    //   147: aload #5
    //   149: aload #10
    //   151: invokevirtual a : ()Ljava/lang/Object;
    //   154: if_acmpne -> 175
    //   157: new androidx/compose/ui/platform/g$g
    //   160: dup
    //   161: aload #9
    //   163: invokespecial <init> : (Ldbxyzptlk/x0/k0;)V
    //   166: astore_2
    //   167: aload #6
    //   169: aload_2
    //   170: invokeinterface D : (Ljava/lang/Object;)V
    //   175: aload_2
    //   176: checkcast dbxyzptlk/CI/l
    //   179: astore_2
    //   180: aload #6
    //   182: invokeinterface R : ()V
    //   187: aload_0
    //   188: aload_2
    //   189: invokevirtual setConfigurationChangeObserver : (Ldbxyzptlk/CI/l;)V
    //   192: aload #6
    //   194: ldc -492369756
    //   196: invokeinterface I : (I)V
    //   201: aload #6
    //   203: invokeinterface J : ()Ljava/lang/Object;
    //   208: astore #5
    //   210: aload #5
    //   212: astore_2
    //   213: aload #5
    //   215: aload #10
    //   217: invokevirtual a : ()Ljava/lang/Object;
    //   220: if_acmpne -> 241
    //   223: new dbxyzptlk/g1/U
    //   226: dup
    //   227: aload #7
    //   229: invokespecial <init> : (Landroid/content/Context;)V
    //   232: astore_2
    //   233: aload #6
    //   235: aload_2
    //   236: invokeinterface D : (Ljava/lang/Object;)V
    //   241: aload #6
    //   243: invokeinterface R : ()V
    //   248: aload_2
    //   249: checkcast dbxyzptlk/g1/U
    //   252: astore #8
    //   254: aload_0
    //   255: invokevirtual getViewTreeOwners : ()Landroidx/compose/ui/platform/AndroidComposeView$c;
    //   258: astore #11
    //   260: aload #11
    //   262: ifnull -> 551
    //   265: aload #6
    //   267: ldc -492369756
    //   269: invokeinterface I : (I)V
    //   274: aload #6
    //   276: invokeinterface J : ()Ljava/lang/Object;
    //   281: astore #5
    //   283: aload #5
    //   285: astore_2
    //   286: aload #5
    //   288: aload #10
    //   290: invokevirtual a : ()Ljava/lang/Object;
    //   293: if_acmpne -> 314
    //   296: aload_0
    //   297: aload #11
    //   299: invokevirtual b : ()Ldbxyzptlk/J4/d;
    //   302: invokestatic b : (Landroid/view/View;Ldbxyzptlk/J4/d;)Ldbxyzptlk/g1/h0;
    //   305: astore_2
    //   306: aload #6
    //   308: aload_2
    //   309: invokeinterface D : (Ljava/lang/Object;)V
    //   314: aload #6
    //   316: invokeinterface R : ()V
    //   321: aload_2
    //   322: checkcast dbxyzptlk/g1/h0
    //   325: astore #12
    //   327: getstatic dbxyzptlk/pI/D.a : Ldbxyzptlk/pI/D;
    //   330: new androidx/compose/ui/platform/g$h
    //   333: dup
    //   334: aload #12
    //   336: invokespecial <init> : (Ldbxyzptlk/g1/h0;)V
    //   339: aload #6
    //   341: bipush #6
    //   343: invokestatic a : (Ljava/lang/Object;Ldbxyzptlk/CI/l;Ldbxyzptlk/x0/k;I)V
    //   346: aload #7
    //   348: aload #9
    //   350: invokestatic b : (Ldbxyzptlk/x0/k0;)Landroid/content/res/Configuration;
    //   353: aload #6
    //   355: bipush #72
    //   357: invokestatic m : (Landroid/content/Context;Landroid/content/res/Configuration;Ldbxyzptlk/x0/k;I)Ldbxyzptlk/k1/d;
    //   360: astore #10
    //   362: getstatic androidx/compose/ui/platform/g.a : Ldbxyzptlk/x0/w0;
    //   365: aload #9
    //   367: invokestatic b : (Ldbxyzptlk/x0/k0;)Landroid/content/res/Configuration;
    //   370: invokevirtual c : (Ljava/lang/Object;)Ldbxyzptlk/x0/x0;
    //   373: astore_2
    //   374: getstatic androidx/compose/ui/platform/g.b : Ldbxyzptlk/x0/w0;
    //   377: aload #7
    //   379: invokevirtual c : (Ljava/lang/Object;)Ldbxyzptlk/x0/x0;
    //   382: astore #7
    //   384: getstatic androidx/compose/ui/platform/g.d : Ldbxyzptlk/x0/w0;
    //   387: aload #11
    //   389: invokevirtual a : ()Landroidx/lifecycle/LifecycleOwner;
    //   392: invokevirtual c : (Ljava/lang/Object;)Ldbxyzptlk/x0/x0;
    //   395: astore #5
    //   397: getstatic androidx/compose/ui/platform/g.e : Ldbxyzptlk/x0/w0;
    //   400: aload #11
    //   402: invokevirtual b : ()Ldbxyzptlk/J4/d;
    //   405: invokevirtual c : (Ljava/lang/Object;)Ldbxyzptlk/x0/x0;
    //   408: astore #9
    //   410: invokestatic b : ()Ldbxyzptlk/x0/w0;
    //   413: aload #12
    //   415: invokevirtual c : (Ljava/lang/Object;)Ldbxyzptlk/x0/x0;
    //   418: astore #11
    //   420: getstatic androidx/compose/ui/platform/g.f : Ldbxyzptlk/x0/w0;
    //   423: aload_0
    //   424: invokevirtual getView : ()Landroid/view/View;
    //   427: invokevirtual c : (Ljava/lang/Object;)Ldbxyzptlk/x0/x0;
    //   430: astore #12
    //   432: getstatic androidx/compose/ui/platform/g.c : Ldbxyzptlk/x0/w0;
    //   435: aload #10
    //   437: invokevirtual c : (Ljava/lang/Object;)Ldbxyzptlk/x0/x0;
    //   440: astore #10
    //   442: aload #6
    //   444: ldc_w 1471621628
    //   447: iconst_1
    //   448: new androidx/compose/ui/platform/g$i
    //   451: dup
    //   452: aload_0
    //   453: aload #8
    //   455: aload_1
    //   456: invokespecial <init> : (Landroidx/compose/ui/platform/AndroidComposeView;Ldbxyzptlk/g1/U;Ldbxyzptlk/CI/p;)V
    //   459: invokestatic b : (Ldbxyzptlk/x0/k;IZLjava/lang/Object;)Ldbxyzptlk/F0/a;
    //   462: astore #8
    //   464: bipush #7
    //   466: anewarray dbxyzptlk/x0/x0
    //   469: dup
    //   470: iconst_0
    //   471: aload_2
    //   472: aastore
    //   473: dup
    //   474: iconst_1
    //   475: aload #7
    //   477: aastore
    //   478: dup
    //   479: iconst_2
    //   480: aload #5
    //   482: aastore
    //   483: dup
    //   484: iconst_3
    //   485: aload #9
    //   487: aastore
    //   488: dup
    //   489: iconst_4
    //   490: aload #11
    //   492: aastore
    //   493: dup
    //   494: iconst_5
    //   495: aload #12
    //   497: aastore
    //   498: dup
    //   499: bipush #6
    //   501: aload #10
    //   503: aastore
    //   504: aload #8
    //   506: aload #6
    //   508: bipush #56
    //   510: invokestatic b : ([Ldbxyzptlk/x0/x0;Ldbxyzptlk/CI/p;Ldbxyzptlk/x0/k;I)V
    //   513: invokestatic I : ()Z
    //   516: ifeq -> 522
    //   519: invokestatic T : ()V
    //   522: aload #6
    //   524: invokeinterface z : ()Ldbxyzptlk/x0/K0;
    //   529: astore_2
    //   530: aload_2
    //   531: ifnull -> 550
    //   534: aload_2
    //   535: new androidx/compose/ui/platform/g$j
    //   538: dup
    //   539: aload_0
    //   540: aload_1
    //   541: iload_3
    //   542: invokespecial <init> : (Landroidx/compose/ui/platform/AndroidComposeView;Ldbxyzptlk/CI/p;I)V
    //   545: invokeinterface a : (Ldbxyzptlk/CI/p;)V
    //   550: return
    //   551: new java/lang/IllegalStateException
    //   554: dup
    //   555: ldc_w 'Called when the ViewTreeOwnersAvailability is not yet in Available state'
    //   558: invokespecial <init> : (Ljava/lang/String;)V
    //   561: athrow
  }
  
  public static final Configuration b(k0<Configuration> paramk0) {
    return (Configuration)paramk0.getValue();
  }
  
  public static final void c(k0<Configuration> paramk0, Configuration paramConfiguration) {
    paramk0.setValue(paramConfiguration);
  }
  
  public static final w0<Configuration> f() {
    return a;
  }
  
  public static final w0<Context> g() {
    return b;
  }
  
  public static final w0<dbxyzptlk.k1.d> h() {
    return c;
  }
  
  public static final w0<LifecycleOwner> i() {
    return d;
  }
  
  public static final w0<dbxyzptlk.J4.d> j() {
    return e;
  }
  
  public static final w0<View> k() {
    return f;
  }
  
  public static final Void l(String paramString) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("CompositionLocal ");
    stringBuilder.append(paramString);
    stringBuilder.append(" not present");
    throw new IllegalStateException(stringBuilder.toString().toString());
  }
  
  public static final dbxyzptlk.k1.d m(Context paramContext, Configuration paramConfiguration, dbxyzptlk.x0.k paramk, int paramInt) {
    paramk.I(-485908294);
    if (n.I())
      n.U(-485908294, paramInt, -1, "androidx.compose.ui.platform.obtainImageVectorCache (AndroidCompositionLocals.android.kt:131)"); 
    paramk.I(-492369756);
    Object object3 = paramk.J();
    dbxyzptlk.x0.k.a a = dbxyzptlk.x0.k.a;
    Object object2 = object3;
    if (object3 == a.a()) {
      object2 = new dbxyzptlk.k1.d();
      paramk.D(object2);
    } 
    paramk.R();
    dbxyzptlk.k1.d d = (dbxyzptlk.k1.d)object2;
    paramk.I(-492369756);
    object3 = paramk.J();
    object2 = object3;
    if (object3 == a.a()) {
      object2 = new Configuration();
      if (paramConfiguration != null)
        object2.setTo(paramConfiguration); 
      paramk.D(object2);
    } 
    paramk.R();
    object3 = object2;
    paramk.I(-492369756);
    object2 = paramk.J();
    Object object1 = object2;
    if (object2 == a.a()) {
      object1 = new l((Configuration)object3, d);
      paramk.D(object1);
    } 
    paramk.R();
    J.a(d, new k(paramContext, (l)object1), paramk, 8);
    if (n.I())
      n.T(); 
    paramk.R();
    return d;
  }
  
  @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"Landroid/content/res/Configuration;", "b", "()Landroid/content/res/Configuration;"}, k = 3, mv = {1, 8, 0})
  public static final class a extends u implements dbxyzptlk.CI.a<Configuration> {
    public static final a f = new a();
    
    public a() {
      super(0);
    }
    
    public final Configuration b() {
      g.e("LocalConfiguration");
      throw new KotlinNothingValueException();
    }
  }
  
  @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"Landroid/content/Context;", "b", "()Landroid/content/Context;"}, k = 3, mv = {1, 8, 0})
  public static final class b extends u implements dbxyzptlk.CI.a<Context> {
    public static final b f = new b();
    
    public b() {
      super(0);
    }
    
    public final Context b() {
      g.e("LocalContext");
      throw new KotlinNothingValueException();
    }
  }
  
  @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"Ldbxyzptlk/k1/d;", "b", "()Ldbxyzptlk/k1/d;"}, k = 3, mv = {1, 8, 0})
  public static final class c extends u implements dbxyzptlk.CI.a<dbxyzptlk.k1.d> {
    public static final c f = new c();
    
    public c() {
      super(0);
    }
    
    public final dbxyzptlk.k1.d b() {
      g.e("LocalImageVectorCache");
      throw new KotlinNothingValueException();
    }
  }
  
  @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"Landroidx/lifecycle/LifecycleOwner;", "b", "()Landroidx/lifecycle/LifecycleOwner;"}, k = 3, mv = {1, 8, 0})
  public static final class d extends u implements dbxyzptlk.CI.a<LifecycleOwner> {
    public static final d f = new d();
    
    public d() {
      super(0);
    }
    
    public final LifecycleOwner b() {
      g.e("LocalLifecycleOwner");
      throw new KotlinNothingValueException();
    }
  }
  
  @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"Ldbxyzptlk/J4/d;", "b", "()Ldbxyzptlk/J4/d;"}, k = 3, mv = {1, 8, 0})
  public static final class e extends u implements dbxyzptlk.CI.a<dbxyzptlk.J4.d> {
    public static final e f = new e();
    
    public e() {
      super(0);
    }
    
    public final dbxyzptlk.J4.d b() {
      g.e("LocalSavedStateRegistryOwner");
      throw new KotlinNothingValueException();
    }
  }
  
  @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"Landroid/view/View;", "b", "()Landroid/view/View;"}, k = 3, mv = {1, 8, 0})
  public static final class f extends u implements dbxyzptlk.CI.a<View> {
    public static final f f = new f();
    
    public f() {
      super(0);
    }
    
    public final View b() {
      g.e("LocalView");
      throw new KotlinNothingValueException();
    }
  }
  
  @Metadata(d1 = {"\000\016\n\002\030\002\n\000\n\002\030\002\n\002\b\002\020\003\032\0020\0022\006\020\001\032\0020\000H\n¢\006\004\b\003\020\004"}, d2 = {"Landroid/content/res/Configuration;", "it", "Ldbxyzptlk/pI/D;", "a", "(Landroid/content/res/Configuration;)V"}, k = 3, mv = {1, 8, 0})
  public static final class g extends u implements dbxyzptlk.CI.l<Configuration, D> {
    public final k0<Configuration> f;
    
    public g(k0<Configuration> param1k0) {
      super(1);
    }
    
    public final void a(Configuration param1Configuration) {
      g.d(this.f, new Configuration(param1Configuration));
    }
  }
  
  @Metadata(d1 = {"\000\f\n\002\030\002\n\002\030\002\n\002\b\002\020\002\032\0020\001*\0020\000H\n¢\006\004\b\002\020\003"}, d2 = {"Ldbxyzptlk/x0/H;", "Ldbxyzptlk/x0/G;", "a", "(Ldbxyzptlk/x0/H;)Ldbxyzptlk/x0/G;"}, k = 3, mv = {1, 8, 0})
  public static final class h extends u implements dbxyzptlk.CI.l<H, G> {
    public final h0 f;
    
    public h(h0 param1h0) {
      super(1);
    }
    
    public final G a(H param1H) {
      return new a(this.f);
    }
    
    @Metadata(d1 = {"\000\021\n\000\n\002\030\002\n\002\030\002\n\002\b\003*\001\000\b\n\030\0002\0020\001J\017\020\003\032\0020\002H\026¢\006\004\b\003\020\004¨\006\005"}, d2 = {"androidx/compose/ui/platform/g$h$a", "Ldbxyzptlk/x0/G;", "Ldbxyzptlk/pI/D;", "dispose", "()V", "runtime_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
    public static final class a implements G {
      public final h0 a;
      
      public a(h0 param2h0) {}
      
      public void dispose() {
        this.a.b();
      }
    }
  }
  
  @Metadata(d1 = {"\000\021\n\000\n\002\030\002\n\002\030\002\n\002\b\003*\001\000\b\n\030\0002\0020\001J\017\020\003\032\0020\002H\026¢\006\004\b\003\020\004¨\006\005"}, d2 = {"androidx/compose/ui/platform/g$h$a", "Ldbxyzptlk/x0/G;", "Ldbxyzptlk/pI/D;", "dispose", "()V", "runtime_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class a implements G {
    public final h0 a;
    
    public a(h0 param1h0) {}
    
    public void dispose() {
      this.a.b();
    }
  }
  
  @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\013¢\006\004\b\001\020\002"}, d2 = {"Ldbxyzptlk/pI/D;", "a", "(Ldbxyzptlk/x0/k;I)V"}, k = 3, mv = {1, 8, 0})
  public static final class i extends u implements p<dbxyzptlk.x0.k, Integer, D> {
    public final AndroidComposeView f;
    
    public final U g;
    
    public final p<dbxyzptlk.x0.k, Integer, D> h;
    
    public i(AndroidComposeView param1AndroidComposeView, U param1U, p<? super dbxyzptlk.x0.k, ? super Integer, D> param1p) {
      super(2);
    }
    
    public final void a(dbxyzptlk.x0.k param1k, int param1Int) {
      if ((param1Int & 0xB) != 2 || !param1k.b()) {
        if (n.I())
          n.U(1471621628, param1Int, -1, "androidx.compose.ui.platform.ProvideAndroidCompositionLocals.<anonymous> (AndroidCompositionLocals.android.kt:118)"); 
        d0.a(this.f, (E1)this.g, this.h, param1k, 72);
        if (n.I())
          n.T(); 
        return;
      } 
      param1k.k();
    }
  }
  
  @Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
  public static final class j extends u implements p<dbxyzptlk.x0.k, Integer, D> {
    public final AndroidComposeView f;
    
    public final p<dbxyzptlk.x0.k, Integer, D> g;
    
    public final int h;
    
    public j(AndroidComposeView param1AndroidComposeView, p<? super dbxyzptlk.x0.k, ? super Integer, D> param1p, int param1Int) {
      super(2);
    }
    
    public final void a(dbxyzptlk.x0.k param1k, int param1Int) {
      g.a(this.f, this.g, param1k, A0.a(this.h | 0x1));
    }
  }
  
  @Metadata(d1 = {"\000\f\n\002\030\002\n\002\030\002\n\002\b\002\020\002\032\0020\001*\0020\000H\n¢\006\004\b\002\020\003"}, d2 = {"Ldbxyzptlk/x0/H;", "Ldbxyzptlk/x0/G;", "a", "(Ldbxyzptlk/x0/H;)Ldbxyzptlk/x0/G;"}, k = 3, mv = {1, 8, 0})
  public static final class k extends u implements dbxyzptlk.CI.l<H, G> {
    public final Context f;
    
    public final g.l g;
    
    public k(Context param1Context, g.l param1l) {
      super(1);
    }
    
    public final G a(H param1H) {
      this.f.getApplicationContext().registerComponentCallbacks((ComponentCallbacks)this.g);
      return new a(this.f, this.g);
    }
    
    @Metadata(d1 = {"\000\021\n\000\n\002\030\002\n\002\030\002\n\002\b\003*\001\000\b\n\030\0002\0020\001J\017\020\003\032\0020\002H\026¢\006\004\b\003\020\004¨\006\005"}, d2 = {"androidx/compose/ui/platform/g$k$a", "Ldbxyzptlk/x0/G;", "Ldbxyzptlk/pI/D;", "dispose", "()V", "runtime_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
    public static final class a implements G {
      public final Context a;
      
      public final g.l b;
      
      public a(Context param2Context, g.l param2l) {}
      
      public void dispose() {
        this.a.getApplicationContext().unregisterComponentCallbacks((ComponentCallbacks)this.b);
      }
    }
  }
  
  @Metadata(d1 = {"\000\021\n\000\n\002\030\002\n\002\030\002\n\002\b\003*\001\000\b\n\030\0002\0020\001J\017\020\003\032\0020\002H\026¢\006\004\b\003\020\004¨\006\005"}, d2 = {"androidx/compose/ui/platform/g$k$a", "Ldbxyzptlk/x0/G;", "Ldbxyzptlk/pI/D;", "dispose", "()V", "runtime_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class a implements G {
    public final Context a;
    
    public final g.l b;
    
    public a(Context param1Context, g.l param1l) {}
    
    public void dispose() {
      this.a.getApplicationContext().unregisterComponentCallbacks((ComponentCallbacks)this.b);
    }
  }
  
  @Metadata(d1 = {"\000\037\n\000\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\004\n\002\020\b\n\002\b\004*\001\000\b\n\030\0002\0020\001J\027\020\005\032\0020\0042\006\020\003\032\0020\002H\026¢\006\004\b\005\020\006J\017\020\007\032\0020\004H\026¢\006\004\b\007\020\bJ\027\020\013\032\0020\0042\006\020\n\032\0020\tH\026¢\006\004\b\013\020\f¨\006\r"}, d2 = {"androidx/compose/ui/platform/g$l", "Landroid/content/ComponentCallbacks2;", "Landroid/content/res/Configuration;", "configuration", "Ldbxyzptlk/pI/D;", "onConfigurationChanged", "(Landroid/content/res/Configuration;)V", "onLowMemory", "()V", "", "level", "onTrimMemory", "(I)V", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class l implements ComponentCallbacks2 {
    public final Configuration a;
    
    public final dbxyzptlk.k1.d b;
    
    public l(Configuration param1Configuration, dbxyzptlk.k1.d param1d) {}
    
    public void onConfigurationChanged(Configuration param1Configuration) {
      int i = this.a.updateFrom(param1Configuration);
      this.b.c(i);
      this.a.setTo(param1Configuration);
    }
    
    public void onLowMemory() {
      this.b.a();
    }
    
    public void onTrimMemory(int param1Int) {
      this.b.a();
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compos\\ui\platform\g.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */