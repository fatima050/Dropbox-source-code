package androidx.compose.ui.platform;

import android.content.Context;
import android.util.AttributeSet;
import dbxyzptlk.CI.p;
import dbxyzptlk.DI.u;
import dbxyzptlk.pI.D;
import dbxyzptlk.x0.A0;
import dbxyzptlk.x0.K0;
import dbxyzptlk.x0.X0;
import dbxyzptlk.x0.k;
import dbxyzptlk.x0.k0;
import dbxyzptlk.x0.n;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

@Metadata(d1 = {"\000D\n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020\b\n\002\b\003\n\002\030\002\n\002\b\002\n\002\020\r\n\002\b\002\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\002\n\002\020\013\n\002\b\t\b\007\030\0002\0020\001B'\b\007\022\006\020\003\032\0020\002\022\n\b\002\020\005\032\004\030\0010\004\022\b\b\002\020\007\032\0020\006¢\006\004\b\b\020\tJ\017\020\013\032\0020\nH\027¢\006\004\b\013\020\fJ\017\020\016\032\0020\rH\026¢\006\004\b\016\020\017J\033\020\022\032\0020\n2\f\020\021\032\b\022\004\022\0020\n0\020¢\006\004\b\022\020\023R\"\020\021\032\020\022\f\022\n\022\004\022\0020\n\030\0010\0200\0248\002X\004¢\006\006\n\004\b\025\020\026R*\020\037\032\0020\0272\006\020\030\032\0020\0278\024@RX\016¢\006\022\n\004\b\031\020\032\022\004\b\035\020\036\032\004\b\033\020\034¨\006 "}, d2 = {"Landroidx/compose/ui/platform/ComposeView;", "Landroidx/compose/ui/platform/AbstractComposeView;", "Landroid/content/Context;", "context", "Landroid/util/AttributeSet;", "attrs", "", "defStyleAttr", "<init>", "(Landroid/content/Context;Landroid/util/AttributeSet;I)V", "Ldbxyzptlk/pI/D;", "a", "(Ldbxyzptlk/x0/k;I)V", "", "getAccessibilityClassName", "()Ljava/lang/CharSequence;", "Lkotlin/Function0;", "content", "setContent", "(Ldbxyzptlk/CI/p;)V", "Ldbxyzptlk/x0/k0;", "i", "Ldbxyzptlk/x0/k0;", "", "<set-?>", "j", "Z", "getShouldCreateCompositionOnAttachedToWindow", "()Z", "getShouldCreateCompositionOnAttachedToWindow$annotations", "()V", "shouldCreateCompositionOnAttachedToWindow", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class ComposeView extends AbstractComposeView {
  public static final int k = 8;
  
  public final k0<p<k, Integer, D>> i = X0.j(null, null, 2, null);
  
  public boolean j;
  
  public ComposeView(Context paramContext) {
    this(paramContext, null, 0, 6, null);
  }
  
  public ComposeView(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 0, 4, null);
  }
  
  public ComposeView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
  }
  
  public void a(k paramk, int paramInt) {
    paramk = paramk.x(420213850);
    if (n.I())
      n.U(420213850, paramInt, -1, "androidx.compose.ui.platform.ComposeView.Content (ComposeView.android.kt:426)"); 
    p p = (p)this.i.getValue();
    if (p != null)
      p.invoke(paramk, Integer.valueOf(0)); 
    if (n.I())
      n.T(); 
    K0 k01 = paramk.z();
    if (k01 != null)
      k01.a(new a(this, paramInt)); 
  }
  
  public CharSequence getAccessibilityClassName() {
    return ComposeView.class.getName();
  }
  
  public boolean getShouldCreateCompositionOnAttachedToWindow() {
    return this.j;
  }
  
  public final void setContent(p<? super k, ? super Integer, D> paramp) {
    this.j = true;
    this.i.setValue(paramp);
    if (isAttachedToWindow())
      d(); 
  }
  
  @Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
  public static final class a extends u implements p<k, Integer, D> {
    public final ComposeView f;
    
    public final int g;
    
    public a(ComposeView param1ComposeView, int param1Int) {
      super(2);
    }
    
    public final void a(k param1k, int param1Int) {
      this.f.a(param1k, A0.a(this.g | 0x1));
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compos\\ui\platform\ComposeView.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */