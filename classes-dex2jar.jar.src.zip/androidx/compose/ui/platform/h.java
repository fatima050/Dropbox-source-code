package androidx.compose.ui.platform;

import android.os.Handler;
import android.os.Looper;
import android.view.Choreographer;
import dbxyzptlk.CI.p;
import dbxyzptlk.DI.u;
import dbxyzptlk.bK.F;
import dbxyzptlk.bK.Z;
import dbxyzptlk.d2.i;
import dbxyzptlk.g1.S;
import dbxyzptlk.g1.T;
import dbxyzptlk.pI.D;
import dbxyzptlk.pI.j;
import dbxyzptlk.pI.k;
import dbxyzptlk.qI.k;
import dbxyzptlk.tI.g;
import dbxyzptlk.x0.b0;
import java.util.ArrayList;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

@Metadata(d1 = {"\000i\n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\030\002\n\000\n\002\030\002\n\002\b\007\n\002\020\t\n\002\b\t\n\002\020\000\n\002\b\003\n\002\030\002\n\002\b\003\n\002\020!\n\002\b\005\n\002\020\013\n\002\b\005\n\002\b\004\n\002\030\002\n\002\b\007*\0016\b\007\030\000 @2\0020\001:\001\034B\031\b\002\022\006\020\003\032\0020\002\022\006\020\005\032\0020\004¢\006\004\b\006\020\007J\027\020\013\032\0020\n2\006\020\t\032\0020\bH\000¢\006\004\b\013\020\fJ\027\020\r\032\0020\n2\006\020\t\032\0020\bH\000¢\006\004\b\r\020\fJ\037\020\022\032\0020\n2\006\020\017\032\0020\0162\006\020\021\032\0020\020H\026¢\006\004\b\022\020\023J\021\020\024\032\004\030\0010\020H\002¢\006\004\b\024\020\025J\017\020\026\032\0020\nH\002¢\006\004\b\026\020\027J\027\020\032\032\0020\n2\006\020\031\032\0020\030H\002¢\006\004\b\032\020\033R\027\020\003\032\0020\0028\006¢\006\f\n\004\b\034\020\035\032\004\b\036\020\037R\024\020\005\032\0020\0048\002X\004¢\006\006\n\004\b \020!R\024\020%\032\0020\"8\002X\004¢\006\006\n\004\b#\020$R\032\020)\032\b\022\004\022\0020\0200&8\002X\004¢\006\006\n\004\b'\020(R\034\020-\032\b\022\004\022\0020\b0*8\002@\002X\016¢\006\006\n\004\b+\020,R\034\020/\032\b\022\004\022\0020\b0*8\002@\002X\016¢\006\006\n\004\b.\020,R\026\0203\032\002008\002@\002X\016¢\006\006\n\004\b1\0202R\026\0205\032\002008\002@\002X\016¢\006\006\n\004\b4\0202R\024\0209\032\002068\002X\004¢\006\006\n\004\b7\0208R\027\020?\032\0020:8\006¢\006\f\n\004\b;\020<\032\004\b=\020>¨\006A"}, d2 = {"Landroidx/compose/ui/platform/h;", "Ldbxyzptlk/bK/F;", "Landroid/view/Choreographer;", "choreographer", "Landroid/os/Handler;", "handler", "<init>", "(Landroid/view/Choreographer;Landroid/os/Handler;)V", "Landroid/view/Choreographer$FrameCallback;", "callback", "Ldbxyzptlk/pI/D;", "Z1", "(Landroid/view/Choreographer$FrameCallback;)V", "c2", "Ldbxyzptlk/tI/g;", "context", "Ljava/lang/Runnable;", "block", "i0", "(Ldbxyzptlk/tI/g;Ljava/lang/Runnable;)V", "H1", "()Ljava/lang/Runnable;", "Q1", "()V", "", "frameTimeNanos", "N1", "(J)V", "c", "Landroid/view/Choreographer;", "v1", "()Landroid/view/Choreographer;", "d", "Landroid/os/Handler;", "", "e", "Ljava/lang/Object;", "lock", "Ldbxyzptlk/qI/k;", "f", "Ldbxyzptlk/qI/k;", "toRunTrampolined", "", "g", "Ljava/util/List;", "toRunOnFrame", "h", "spareToRunOnFrame", "", "i", "Z", "scheduledTrampolineDispatch", "j", "scheduledFrameDispatch", "androidx/compose/ui/platform/h$d", "k", "Landroidx/compose/ui/platform/h$d;", "dispatchCallback", "Ldbxyzptlk/x0/b0;", "l", "Ldbxyzptlk/x0/b0;", "G1", "()Ldbxyzptlk/x0/b0;", "frameClock", "m", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class h extends F {
  public static final c m = new c(null);
  
  public static final int n = 8;
  
  public static final j<g> o = k.a(a.f);
  
  public static final ThreadLocal<g> p = new b();
  
  public final Choreographer c;
  
  public final Handler d;
  
  public final Object e;
  
  public final k<Runnable> f;
  
  public List<Choreographer.FrameCallback> g;
  
  public List<Choreographer.FrameCallback> h;
  
  public boolean i;
  
  public boolean j;
  
  public final d k;
  
  public final b0 l;
  
  public h(Choreographer paramChoreographer, Handler paramHandler) {
    this.c = paramChoreographer;
    this.d = paramHandler;
    this.e = new Object();
    this.f = new k();
    this.g = new ArrayList<>();
    this.h = new ArrayList<>();
    this.k = new d(this);
    this.l = (b0)new T(paramChoreographer, this);
  }
  
  public final b0 G1() {
    return this.l;
  }
  
  public final Runnable H1() {
    synchronized (this.e) {
      return (Runnable)this.f.A();
    } 
  }
  
  public final void N1(long paramLong) {
    synchronized (this.e) {
      boolean bool = this.j;
      if (!bool)
        return; 
      byte b = 0;
      this.j = false;
      List<Choreographer.FrameCallback> list = this.g;
      this.g = this.h;
      this.h = list;
      int i = list.size();
      while (b < i) {
        ((Choreographer.FrameCallback)list.get(b)).doFrame(paramLong);
        b++;
      } 
      list.clear();
      return;
    } 
  }
  
  public final void Q1() {
    while (true) {
      boolean bool;
      Runnable runnable;
      for (runnable = H1(); runnable != null; runnable = H1())
        runnable.run(); 
      Object object = this.e;
      /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
      try {
        if (this.f.isEmpty()) {
          bool = false;
          this.i = false;
        } else {
          bool = true;
        } 
      } finally {}
      /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
      if (!bool)
        return; 
    } 
  }
  
  public final void Z1(Choreographer.FrameCallback paramFrameCallback) {
    Object object = this.e;
    /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
    try {
      this.g.add(paramFrameCallback);
      if (!this.j) {
        this.j = true;
        this.c.postFrameCallback(this.k);
      } 
    } finally {}
    D d1 = D.a;
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
  }
  
  public final void c2(Choreographer.FrameCallback paramFrameCallback) {
    synchronized (this.e) {
      this.g.remove(paramFrameCallback);
      return;
    } 
  }
  
  public void i0(g paramg, Runnable paramRunnable) {
    Object object = this.e;
    /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
    try {
      this.f.addLast(paramRunnable);
      if (!this.i) {
        this.i = true;
        this.d.post(this.k);
        if (!this.j) {
          this.j = true;
          this.c.postFrameCallback(this.k);
        } 
      } 
    } finally {}
    D d1 = D.a;
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
  }
  
  public final Choreographer v1() {
    return this.c;
  }
  
  @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"Ldbxyzptlk/tI/g;", "b", "()Ldbxyzptlk/tI/g;"}, k = 3, mv = {1, 8, 0})
  public static final class a extends u implements dbxyzptlk.CI.a<g> {
    public static final a f = new a();
    
    public a() {
      super(0);
    }
    
    public final g b() {
      Choreographer choreographer;
      if (S.a()) {
        choreographer = Choreographer.getInstance();
      } else {
        choreographer = (Choreographer)dbxyzptlk.bK.h.e((g)Z.c(), (p)new a(null));
      } 
      h h = new h(choreographer, i.a(Looper.getMainLooper()), null);
      return h.s((g)h.G1());
    }
  }
  
  @Metadata(d1 = {"\000\021\n\000\n\002\030\002\n\002\030\002\n\002\b\003*\001\000\b\n\030\0002\b\022\004\022\0020\0020\001J\017\020\003\032\0020\002H\024¢\006\004\b\003\020\004¨\006\005"}, d2 = {"androidx/compose/ui/platform/h$b", "Ljava/lang/ThreadLocal;", "Ldbxyzptlk/tI/g;", "a", "()Ldbxyzptlk/tI/g;", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class b extends ThreadLocal<g> {
    public g a() {
      Choreographer choreographer = Choreographer.getInstance();
      Looper looper = Looper.myLooper();
      if (looper != null) {
        h h = new h(choreographer, i.a(looper), null);
        return h.s((g)h.G1());
      } 
      throw new IllegalStateException("no Looper on this thread");
    }
  }
  
  @Metadata(d1 = {"\000\034\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\b\007\n\002\030\002\n\002\b\003\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003R\033\020\t\032\0020\0048FX\002¢\006\f\n\004\b\005\020\006\032\004\b\007\020\bR\021\020\013\032\0020\0048F¢\006\006\032\004\b\n\020\bR\032\020\r\032\b\022\004\022\0020\0040\f8\002X\004¢\006\006\n\004\b\r\020\016¨\006\017"}, d2 = {"Landroidx/compose/ui/platform/h$c;", "", "<init>", "()V", "Ldbxyzptlk/tI/g;", "Main$delegate", "Ldbxyzptlk/pI/j;", "b", "()Ldbxyzptlk/tI/g;", "Main", "a", "CurrentThread", "Ljava/lang/ThreadLocal;", "currentThread", "Ljava/lang/ThreadLocal;", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class c {
    public c() {}
    
    public final g a() {
      g g;
      if (S.a()) {
        g = b();
      } else {
        g = h.y0().get();
        if (g == null)
          throw new IllegalStateException("no AndroidUiDispatcher for this thread"); 
      } 
      return g;
    }
    
    public final g b() {
      return (g)h.Q0().getValue();
    }
  }
  
  @Metadata(d1 = {"\000\035\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\t\n\002\b\004*\001\000\b\n\030\0002\0020\0012\0020\002J\017\020\004\032\0020\003H\026¢\006\004\b\004\020\005J\027\020\b\032\0020\0032\006\020\007\032\0020\006H\026¢\006\004\b\b\020\t¨\006\n"}, d2 = {"androidx/compose/ui/platform/h$d", "Landroid/view/Choreographer$FrameCallback;", "Ljava/lang/Runnable;", "Ldbxyzptlk/pI/D;", "run", "()V", "", "frameTimeNanos", "doFrame", "(J)V", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class d implements Choreographer.FrameCallback, Runnable {
    public final h a;
    
    public d(h param1h) {}
    
    public void doFrame(long param1Long) {
      h.A0(this.a).removeCallbacks(this);
      h.q1(this.a);
      h.l1(this.a, param1Long);
    }
    
    public void run() {
      h.q1(this.a);
      Object object = h.J0(this.a);
      h h1 = this.a;
      /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
      try {
        if (h.h1(h1).isEmpty()) {
          h1.v1().removeFrameCallback(this);
          h.s1(h1, false);
        } 
      } finally {}
      D d1 = D.a;
      /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compos\\ui\platform\h.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */