package androidx.compose.ui.platform;

import android.annotation.SuppressLint;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Outline;
import android.graphics.Rect;
import android.os.Build;
import android.view.View;
import android.view.ViewOutlineProvider;
import androidx.compose.ui.graphics.d;
import androidx.compose.ui.graphics.f;
import dbxyzptlk.CI.l;
import dbxyzptlk.CI.p;
import dbxyzptlk.DI.s;
import dbxyzptlk.DI.u;
import dbxyzptlk.P0.d;
import dbxyzptlk.P0.f;
import dbxyzptlk.P0.m;
import dbxyzptlk.Q0.G;
import dbxyzptlk.Q0.H0;
import dbxyzptlk.Q0.N0;
import dbxyzptlk.Q0.j0;
import dbxyzptlk.Q0.k0;
import dbxyzptlk.f1.S;
import dbxyzptlk.g1.B0;
import dbxyzptlk.g1.v0;
import dbxyzptlk.pI.D;
import dbxyzptlk.z1.d;
import dbxyzptlk.z1.n;
import dbxyzptlk.z1.r;
import dbxyzptlk.z1.t;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

@Metadata(d1 = {"\000Æ\001\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\020\013\n\002\b\002\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\005\n\002\020\b\n\002\b\013\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\016\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\b\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\004\n\002\020\t\n\002\b\t\n\002\020\007\n\002\b\005\n\002\030\002\n\002\b\005\b\000\030\000 |2\0020\0012\0020\0022\0020\003:\002B!B9\022\006\020\005\032\0020\004\022\006\020\007\032\0020\006\022\022\020\013\032\016\022\004\022\0020\t\022\004\022\0020\n0\b\022\f\020\r\032\b\022\004\022\0020\n0\f¢\006\004\b\016\020\017J'\020\026\032\0020\n2\006\020\021\032\0020\0202\006\020\023\032\0020\0222\006\020\025\032\0020\024H\026¢\006\004\b\026\020\027J\017\020\031\032\0020\030H\026¢\006\004\b\031\020\032J\032\020\035\032\0020\0302\006\020\034\032\0020\033H\026ø\001\000¢\006\004\b\035\020\036J\032\020!\032\0020\n2\006\020 \032\0020\037H\026ø\001\000¢\006\004\b!\020\"J\032\020$\032\0020\n2\006\020\034\032\0020#H\026ø\001\000¢\006\004\b$\020\"J\027\020&\032\0020\n2\006\020%\032\0020\tH\026¢\006\004\b&\020'J\027\020)\032\0020\n2\006\020%\032\0020(H\024¢\006\004\b)\020*J\017\020+\032\0020\nH\026¢\006\004\b+\020,J7\0203\032\0020\n2\006\020-\032\0020\0302\006\020/\032\0020.2\006\0200\032\0020.2\006\0201\032\0020.2\006\0202\032\0020.H\024¢\006\004\b3\0204J\017\0205\032\0020\nH\026¢\006\004\b5\020,J\017\020/\032\0020\nH\026¢\006\004\b/\020,J\017\0206\032\0020\nH\026¢\006\004\b6\020,J\"\0202\032\0020\0332\006\0207\032\0020\0332\006\0208\032\0020\030H\026ø\001\000¢\006\004\b2\0209J\037\020<\032\0020\n2\006\020;\032\0020:2\006\0208\032\0020\030H\026¢\006\004\b<\020=J1\020>\032\0020\n2\022\020\013\032\016\022\004\022\0020\t\022\004\022\0020\n0\b2\f\020\r\032\b\022\004\022\0020\n0\fH\026¢\006\004\b>\020?J\032\020B\032\0020\n2\006\020A\032\0020@H\026ø\001\000¢\006\004\bB\020CJ\032\020D\032\0020\n2\006\020A\032\0020@H\026ø\001\000¢\006\004\bD\020CJ\017\020E\032\0020\nH\002¢\006\004\bE\020,J\017\020F\032\0020\nH\002¢\006\004\bF\020,R\027\020\005\032\0020\0048\006¢\006\f\n\004\b<\020G\032\004\bH\020IR\027\020\007\032\0020\0068\006¢\006\f\n\004\b2\020J\032\004\bK\020LR$\020\013\032\020\022\004\022\0020\t\022\004\022\0020\n\030\0010\b8\002@\002X\016¢\006\006\n\004\bB\020MR\036\020\r\032\n\022\004\022\0020\n\030\0010\f8\002@\002X\016¢\006\006\n\004\b!\020NR\024\020Q\032\0020O8\002X\004¢\006\006\n\004\b5\020PR\026\020S\032\0020\0308\002@\002X\016¢\006\006\n\004\b&\020RR\030\020V\032\004\030\0010T8\002@\002X\016¢\006\006\n\004\b\026\020UR*\020[\032\0020\0302\006\020W\032\0020\0308\006@BX\016¢\006\022\n\004\b>\020R\032\004\bX\020\032\"\004\bY\020ZR\026\020\\\032\0020\0308\002@\002X\016¢\006\006\n\004\b\035\020RR\024\020_\032\0020]8\002X\004¢\006\006\n\004\bD\020^R\032\020b\032\b\022\004\022\0020\0010`8\002X\004¢\006\006\n\004\b$\020aR\034\020e\032\0020c8\002@\002X\016ø\001\000ø\001\001¢\006\006\n\004\b/\020dR\026\020g\032\0020\0308\002@\002X\016¢\006\006\n\004\bf\020RR\032\020l\032\0020h8\026X\004¢\006\f\n\004\bi\020d\032\004\bj\020kR\026\020o\032\0020.8\002@\002X\016¢\006\006\n\004\bm\020nR\024\020q\032\0020h8VX\004¢\006\006\032\004\bp\020kR$\020w\032\0020r2\006\020W\032\0020r8F@FX\016¢\006\f\032\004\bs\020t\"\004\bu\020vR\026\020{\032\004\030\0010x8BX\004¢\006\006\032\004\by\020z\002\013\n\005\b¡\0360\001\n\002\b!¨\006}"}, d2 = {"Landroidx/compose/ui/platform/ViewLayer;", "Landroid/view/View;", "Ldbxyzptlk/f1/S;", "", "Landroidx/compose/ui/platform/AndroidComposeView;", "ownerView", "Landroidx/compose/ui/platform/DrawChildContainer;", "container", "Lkotlin/Function1;", "Ldbxyzptlk/Q0/j0;", "Ldbxyzptlk/pI/D;", "drawBlock", "Lkotlin/Function0;", "invalidateParentLayer", "<init>", "(Landroidx/compose/ui/platform/AndroidComposeView;Landroidx/compose/ui/platform/DrawChildContainer;Ldbxyzptlk/CI/l;Ldbxyzptlk/CI/a;)V", "Landroidx/compose/ui/graphics/d;", "scope", "Ldbxyzptlk/z1/t;", "layoutDirection", "Ldbxyzptlk/z1/d;", "density", "g", "(Landroidx/compose/ui/graphics/d;Ldbxyzptlk/z1/t;Ldbxyzptlk/z1/d;)V", "", "hasOverlappingRendering", "()Z", "Ldbxyzptlk/P0/f;", "position", "i", "(J)Z", "Ldbxyzptlk/z1/r;", "size", "d", "(J)V", "Ldbxyzptlk/z1/n;", "k", "canvas", "f", "(Ldbxyzptlk/Q0/j0;)V", "Landroid/graphics/Canvas;", "dispatchDraw", "(Landroid/graphics/Canvas;)V", "invalidate", "()V", "changed", "", "l", "t", "r", "b", "onLayout", "(ZIIII)V", "e", "forceLayout", "point", "inverse", "(JZ)J", "Ldbxyzptlk/P0/d;", "rect", "a", "(Ldbxyzptlk/P0/d;Z)V", "h", "(Ldbxyzptlk/CI/l;Ldbxyzptlk/CI/a;)V", "Ldbxyzptlk/Q0/H0;", "matrix", "c", "([F)V", "j", "x", "w", "Landroidx/compose/ui/platform/AndroidComposeView;", "getOwnerView", "()Landroidx/compose/ui/platform/AndroidComposeView;", "Landroidx/compose/ui/platform/DrawChildContainer;", "getContainer", "()Landroidx/compose/ui/platform/DrawChildContainer;", "Ldbxyzptlk/CI/l;", "Ldbxyzptlk/CI/a;", "Ldbxyzptlk/g1/B0;", "Ldbxyzptlk/g1/B0;", "outlineResolver", "Z", "clipToBounds", "Landroid/graphics/Rect;", "Landroid/graphics/Rect;", "clipBoundsCache", "value", "v", "setInvalidated", "(Z)V", "isInvalidated", "drawnWithZ", "Ldbxyzptlk/Q0/k0;", "Ldbxyzptlk/Q0/k0;", "canvasHolder", "Ldbxyzptlk/g1/v0;", "Ldbxyzptlk/g1/v0;", "matrixCache", "Landroidx/compose/ui/graphics/f;", "J", "mTransformOrigin", "m", "mHasOverlappingRendering", "", "n", "getLayerId", "()J", "layerId", "o", "I", "mutatedFields", "getOwnerViewId", "ownerViewId", "", "getCameraDistancePx", "()F", "setCameraDistancePx", "(F)V", "cameraDistancePx", "Ldbxyzptlk/Q0/N0;", "getManualClipPath", "()Ldbxyzptlk/Q0/N0;", "manualClipPath", "p", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class ViewLayer extends View implements S {
  public static final c p = new c(null);
  
  public static final int q = 8;
  
  public static final p<View, Matrix, D> r = b.f;
  
  public static final ViewOutlineProvider s = new a();
  
  public static Method t;
  
  public static Field u;
  
  public static boolean v;
  
  public static boolean w;
  
  public final AndroidComposeView a;
  
  public final DrawChildContainer b;
  
  public l<? super j0, D> c;
  
  public dbxyzptlk.CI.a<D> d;
  
  public final B0 e;
  
  public boolean f;
  
  public Rect g;
  
  public boolean h;
  
  public boolean i;
  
  public final k0 j;
  
  public final v0<View> k;
  
  public long l;
  
  public boolean m;
  
  public final long n;
  
  public int o;
  
  public ViewLayer(AndroidComposeView paramAndroidComposeView, DrawChildContainer paramDrawChildContainer, l<? super j0, D> paraml, dbxyzptlk.CI.a<D> parama) {
    super(paramAndroidComposeView.getContext());
    this.a = paramAndroidComposeView;
    this.b = paramDrawChildContainer;
    this.c = paraml;
    this.d = parama;
    this.e = new B0(paramAndroidComposeView.getDensity());
    this.j = new k0();
    this.k = new v0(r);
    this.l = f.b.a();
    this.m = true;
    setWillNotDraw(false);
    paramDrawChildContainer.addView((View)this);
    this.n = View.generateViewId();
  }
  
  private final N0 getManualClipPath() {
    return (!getClipToOutline() || this.e.e()) ? null : this.e.c();
  }
  
  private final void setInvalidated(boolean paramBoolean) {
    if (paramBoolean != this.h) {
      this.h = paramBoolean;
      this.a.q0((S)this, paramBoolean);
    } 
  }
  
  public void a(d paramd, boolean paramBoolean) {
    if (paramBoolean) {
      float[] arrayOfFloat = this.k.a(this);
      if (arrayOfFloat != null) {
        H0.g(arrayOfFloat, paramd);
      } else {
        paramd.g(0.0F, 0.0F, 0.0F, 0.0F);
      } 
    } else {
      H0.g(this.k.b(this), paramd);
    } 
  }
  
  public long b(long paramLong, boolean paramBoolean) {
    if (paramBoolean) {
      float[] arrayOfFloat = this.k.a(this);
      if (arrayOfFloat != null) {
        paramLong = H0.f(arrayOfFloat, paramLong);
      } else {
        paramLong = f.b.a();
      } 
    } else {
      paramLong = H0.f(this.k.b(this), paramLong);
    } 
    return paramLong;
  }
  
  public void c(float[] paramArrayOffloat) {
    H0.k(paramArrayOffloat, this.k.b(this));
  }
  
  public void d(long paramLong) {
    int i = r.h(paramLong);
    int j = r.g(paramLong);
    if (i != getWidth() || j != getHeight()) {
      float f2 = f.f(this.l);
      float f1 = i;
      setPivotX(f2 * f1);
      f2 = f.g(this.l);
      float f3 = j;
      setPivotY(f2 * f3);
      this.e.i(m.a(f1, f3));
      x();
      layout(getLeft(), getTop(), getLeft() + i, getTop() + j);
      w();
      this.k.c();
    } 
  }
  
  public void dispatchDraw(Canvas paramCanvas) {
    boolean bool;
    k0 k01 = this.j;
    Canvas canvas = k01.a().B();
    k01.a().C(paramCanvas);
    G g = k01.a();
    if (getManualClipPath() != null || !paramCanvas.isHardwareAccelerated()) {
      g.w();
      this.e.a((j0)g);
      bool = true;
    } else {
      bool = false;
    } 
    l<? super j0, D> l1 = this.c;
    if (l1 != null)
      l1.invoke(g); 
    if (bool)
      g.o(); 
    k01.a().C(canvas);
    setInvalidated(false);
  }
  
  public void e() {
    setInvalidated(false);
    this.a.x0();
    this.c = null;
    this.d = null;
    this.a.v0((S)this);
    this.b.removeViewInLayout((View)this);
  }
  
  public void f(j0 paramj0) {
    boolean bool;
    if (getElevation() > 0.0F) {
      bool = true;
    } else {
      bool = false;
    } 
    this.i = bool;
    if (bool)
      paramj0.s(); 
    this.b.a(paramj0, (View)this, getDrawingTime());
    if (this.i)
      paramj0.l(); 
  }
  
  public void forceLayout() {}
  
  public void g(d paramd, t paramt, d paramd1) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual l : ()I
    //   4: aload_0
    //   5: getfield o : I
    //   8: ior
    //   9: istore #6
    //   11: iload #6
    //   13: sipush #4096
    //   16: iand
    //   17: ifeq -> 64
    //   20: aload_1
    //   21: invokevirtual A : ()J
    //   24: lstore #10
    //   26: aload_0
    //   27: lload #10
    //   29: putfield l : J
    //   32: aload_0
    //   33: lload #10
    //   35: invokestatic f : (J)F
    //   38: aload_0
    //   39: invokevirtual getWidth : ()I
    //   42: i2f
    //   43: fmul
    //   44: invokevirtual setPivotX : (F)V
    //   47: aload_0
    //   48: aload_0
    //   49: getfield l : J
    //   52: invokestatic g : (J)F
    //   55: aload_0
    //   56: invokevirtual getHeight : ()I
    //   59: i2f
    //   60: fmul
    //   61: invokevirtual setPivotY : (F)V
    //   64: iload #6
    //   66: iconst_1
    //   67: iand
    //   68: ifeq -> 79
    //   71: aload_0
    //   72: aload_1
    //   73: invokevirtual c1 : ()F
    //   76: invokevirtual setScaleX : (F)V
    //   79: iload #6
    //   81: iconst_2
    //   82: iand
    //   83: ifeq -> 94
    //   86: aload_0
    //   87: aload_1
    //   88: invokevirtual E1 : ()F
    //   91: invokevirtual setScaleY : (F)V
    //   94: iload #6
    //   96: iconst_4
    //   97: iand
    //   98: ifeq -> 109
    //   101: aload_0
    //   102: aload_1
    //   103: invokevirtual b : ()F
    //   106: invokevirtual setAlpha : (F)V
    //   109: iload #6
    //   111: bipush #8
    //   113: iand
    //   114: ifeq -> 125
    //   117: aload_0
    //   118: aload_1
    //   119: invokevirtual x0 : ()F
    //   122: invokevirtual setTranslationX : (F)V
    //   125: iload #6
    //   127: bipush #16
    //   129: iand
    //   130: ifeq -> 141
    //   133: aload_0
    //   134: aload_1
    //   135: invokevirtual u0 : ()F
    //   138: invokevirtual setTranslationY : (F)V
    //   141: iload #6
    //   143: bipush #32
    //   145: iand
    //   146: ifeq -> 157
    //   149: aload_0
    //   150: aload_1
    //   151: invokevirtual r : ()F
    //   154: invokevirtual setElevation : (F)V
    //   157: iload #6
    //   159: sipush #1024
    //   162: iand
    //   163: ifeq -> 174
    //   166: aload_0
    //   167: aload_1
    //   168: invokevirtual y : ()F
    //   171: invokevirtual setRotation : (F)V
    //   174: iload #6
    //   176: sipush #256
    //   179: iand
    //   180: ifeq -> 191
    //   183: aload_0
    //   184: aload_1
    //   185: invokevirtual A1 : ()F
    //   188: invokevirtual setRotationX : (F)V
    //   191: iload #6
    //   193: sipush #512
    //   196: iand
    //   197: ifeq -> 208
    //   200: aload_0
    //   201: aload_1
    //   202: invokevirtual M0 : ()F
    //   205: invokevirtual setRotationY : (F)V
    //   208: iload #6
    //   210: sipush #2048
    //   213: iand
    //   214: ifeq -> 225
    //   217: aload_0
    //   218: aload_1
    //   219: invokevirtual Y : ()F
    //   222: invokevirtual setCameraDistancePx : (F)V
    //   225: aload_0
    //   226: invokespecial getManualClipPath : ()Ldbxyzptlk/Q0/N0;
    //   229: astore #12
    //   231: iconst_0
    //   232: istore #9
    //   234: aload #12
    //   236: ifnull -> 245
    //   239: iconst_1
    //   240: istore #4
    //   242: goto -> 248
    //   245: iconst_0
    //   246: istore #4
    //   248: aload_1
    //   249: invokevirtual h : ()Z
    //   252: ifeq -> 271
    //   255: aload_1
    //   256: invokevirtual u : ()Ldbxyzptlk/Q0/a1;
    //   259: invokestatic a : ()Ldbxyzptlk/Q0/a1;
    //   262: if_acmpeq -> 271
    //   265: iconst_1
    //   266: istore #7
    //   268: goto -> 274
    //   271: iconst_0
    //   272: istore #7
    //   274: iload #6
    //   276: sipush #24576
    //   279: iand
    //   280: ifeq -> 325
    //   283: aload_1
    //   284: invokevirtual h : ()Z
    //   287: ifeq -> 306
    //   290: aload_1
    //   291: invokevirtual u : ()Ldbxyzptlk/Q0/a1;
    //   294: invokestatic a : ()Ldbxyzptlk/Q0/a1;
    //   297: if_acmpne -> 306
    //   300: iconst_1
    //   301: istore #8
    //   303: goto -> 309
    //   306: iconst_0
    //   307: istore #8
    //   309: aload_0
    //   310: iload #8
    //   312: putfield f : Z
    //   315: aload_0
    //   316: invokevirtual w : ()V
    //   319: aload_0
    //   320: iload #7
    //   322: invokevirtual setClipToOutline : (Z)V
    //   325: aload_0
    //   326: getfield e : Ldbxyzptlk/g1/B0;
    //   329: aload_1
    //   330: invokevirtual u : ()Ldbxyzptlk/Q0/a1;
    //   333: aload_1
    //   334: invokevirtual b : ()F
    //   337: iload #7
    //   339: aload_1
    //   340: invokevirtual r : ()F
    //   343: aload_2
    //   344: aload_3
    //   345: invokevirtual h : (Ldbxyzptlk/Q0/a1;FZFLdbxyzptlk/z1/t;Ldbxyzptlk/z1/d;)Z
    //   348: istore #7
    //   350: aload_0
    //   351: getfield e : Ldbxyzptlk/g1/B0;
    //   354: invokevirtual b : ()Z
    //   357: ifeq -> 364
    //   360: aload_0
    //   361: invokevirtual x : ()V
    //   364: aload_0
    //   365: invokespecial getManualClipPath : ()Ldbxyzptlk/Q0/N0;
    //   368: ifnull -> 377
    //   371: iconst_1
    //   372: istore #5
    //   374: goto -> 380
    //   377: iconst_0
    //   378: istore #5
    //   380: iload #4
    //   382: iload #5
    //   384: if_icmpne -> 397
    //   387: iload #5
    //   389: ifeq -> 401
    //   392: iload #7
    //   394: ifeq -> 401
    //   397: aload_0
    //   398: invokevirtual invalidate : ()V
    //   401: aload_0
    //   402: getfield i : Z
    //   405: ifne -> 433
    //   408: aload_0
    //   409: invokevirtual getElevation : ()F
    //   412: fconst_0
    //   413: fcmpl
    //   414: ifle -> 433
    //   417: aload_0
    //   418: getfield d : Ldbxyzptlk/CI/a;
    //   421: astore_2
    //   422: aload_2
    //   423: ifnull -> 433
    //   426: aload_2
    //   427: invokeinterface invoke : ()Ljava/lang/Object;
    //   432: pop
    //   433: iload #6
    //   435: sipush #7963
    //   438: iand
    //   439: ifeq -> 449
    //   442: aload_0
    //   443: getfield k : Ldbxyzptlk/g1/v0;
    //   446: invokevirtual c : ()V
    //   449: getstatic android/os/Build$VERSION.SDK_INT : I
    //   452: istore #4
    //   454: iload #4
    //   456: bipush #28
    //   458: if_icmplt -> 506
    //   461: iload #6
    //   463: bipush #64
    //   465: iand
    //   466: ifeq -> 483
    //   469: getstatic dbxyzptlk/g1/O1.a : Ldbxyzptlk/g1/O1;
    //   472: aload_0
    //   473: aload_1
    //   474: invokevirtual d : ()J
    //   477: invokestatic i : (J)I
    //   480: invokevirtual a : (Landroid/view/View;I)V
    //   483: iload #6
    //   485: sipush #128
    //   488: iand
    //   489: ifeq -> 506
    //   492: getstatic dbxyzptlk/g1/O1.a : Ldbxyzptlk/g1/O1;
    //   495: aload_0
    //   496: aload_1
    //   497: invokevirtual v : ()J
    //   500: invokestatic i : (J)I
    //   503: invokevirtual b : (Landroid/view/View;I)V
    //   506: iload #4
    //   508: bipush #31
    //   510: if_icmplt -> 537
    //   513: ldc_w 131072
    //   516: iload #6
    //   518: iand
    //   519: ifeq -> 537
    //   522: getstatic dbxyzptlk/g1/Q1.a : Ldbxyzptlk/g1/Q1;
    //   525: astore_2
    //   526: aload_1
    //   527: invokevirtual m : ()Ldbxyzptlk/Q0/V0;
    //   530: pop
    //   531: aload_2
    //   532: aload_0
    //   533: aconst_null
    //   534: invokevirtual a : (Landroid/view/View;Ldbxyzptlk/Q0/V0;)V
    //   537: iload #6
    //   539: ldc_w 32768
    //   542: iand
    //   543: ifeq -> 620
    //   546: aload_1
    //   547: invokevirtual j : ()I
    //   550: istore #4
    //   552: getstatic androidx/compose/ui/graphics/a.a : Landroidx/compose/ui/graphics/a$a;
    //   555: astore_2
    //   556: iload #4
    //   558: aload_2
    //   559: invokevirtual c : ()I
    //   562: invokestatic e : (II)Z
    //   565: ifeq -> 580
    //   568: aload_0
    //   569: iconst_2
    //   570: aconst_null
    //   571: invokevirtual setLayerType : (ILandroid/graphics/Paint;)V
    //   574: iconst_1
    //   575: istore #7
    //   577: goto -> 614
    //   580: iload #4
    //   582: aload_2
    //   583: invokevirtual b : ()I
    //   586: invokestatic e : (II)Z
    //   589: ifeq -> 605
    //   592: aload_0
    //   593: iconst_0
    //   594: aconst_null
    //   595: invokevirtual setLayerType : (ILandroid/graphics/Paint;)V
    //   598: iload #9
    //   600: istore #7
    //   602: goto -> 614
    //   605: aload_0
    //   606: iconst_0
    //   607: aconst_null
    //   608: invokevirtual setLayerType : (ILandroid/graphics/Paint;)V
    //   611: goto -> 574
    //   614: aload_0
    //   615: iload #7
    //   617: putfield m : Z
    //   620: aload_0
    //   621: aload_1
    //   622: invokevirtual l : ()I
    //   625: putfield o : I
    //   628: return
  }
  
  public final float getCameraDistancePx() {
    return getCameraDistance() / (getResources().getDisplayMetrics()).densityDpi;
  }
  
  public final DrawChildContainer getContainer() {
    return this.b;
  }
  
  public long getLayerId() {
    return this.n;
  }
  
  public final AndroidComposeView getOwnerView() {
    return this.a;
  }
  
  public long getOwnerViewId() {
    long l1;
    if (Build.VERSION.SDK_INT >= 29) {
      l1 = d.a((View)this.a);
    } else {
      l1 = -1L;
    } 
    return l1;
  }
  
  public void h(l<? super j0, D> paraml, dbxyzptlk.CI.a<D> parama) {
    this.b.addView((View)this);
    this.f = false;
    this.i = false;
    this.l = f.b.a();
    this.c = paraml;
    this.d = parama;
  }
  
  public boolean hasOverlappingRendering() {
    return this.m;
  }
  
  public boolean i(long paramLong) {
    float f1 = f.o(paramLong);
    float f2 = f.p(paramLong);
    boolean bool1 = this.f;
    boolean bool = true;
    if (bool1) {
      if (0.0F > f1 || f1 >= getWidth() || 0.0F > f2 || f2 >= getHeight())
        bool = false; 
      return bool;
    } 
    return getClipToOutline() ? this.e.f(paramLong) : true;
  }
  
  public void invalidate() {
    if (!this.h) {
      setInvalidated(true);
      super.invalidate();
      this.a.invalidate();
    } 
  }
  
  public void j(float[] paramArrayOffloat) {
    float[] arrayOfFloat = this.k.a(this);
    if (arrayOfFloat != null)
      H0.k(paramArrayOffloat, arrayOfFloat); 
  }
  
  public void k(long paramLong) {
    int i = n.j(paramLong);
    if (i != getLeft()) {
      offsetLeftAndRight(i - getLeft());
      this.k.c();
    } 
    i = n.k(paramLong);
    if (i != getTop()) {
      offsetTopAndBottom(i - getTop());
      this.k.c();
    } 
  }
  
  public void l() {
    if (this.h && !w) {
      p.d((View)this);
      setInvalidated(false);
    } 
  }
  
  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
  
  public final void setCameraDistancePx(float paramFloat) {
    setCameraDistance(paramFloat * (getResources().getDisplayMetrics()).densityDpi);
  }
  
  public final boolean v() {
    return this.h;
  }
  
  public final void w() {
    Rect rect;
    if (this.f) {
      rect = this.g;
      if (rect == null) {
        this.g = new Rect(0, 0, getWidth(), getHeight());
      } else {
        s.e(rect);
        rect.set(0, 0, getWidth(), getHeight());
      } 
      rect = this.g;
    } else {
      rect = null;
    } 
    setClipBounds(rect);
  }
  
  public final void x() {
    ViewOutlineProvider viewOutlineProvider;
    if (this.e.d() != null) {
      viewOutlineProvider = s;
    } else {
      viewOutlineProvider = null;
    } 
    setOutlineProvider(viewOutlineProvider);
  }
  
  @Metadata(d1 = {"\000\035\n\000\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\003*\001\000\b\n\030\0002\0020\001J\037\020\007\032\0020\0062\006\020\003\032\0020\0022\006\020\005\032\0020\004H\026¢\006\004\b\007\020\b¨\006\t"}, d2 = {"androidx/compose/ui/platform/ViewLayer$a", "Landroid/view/ViewOutlineProvider;", "Landroid/view/View;", "view", "Landroid/graphics/Outline;", "outline", "Ldbxyzptlk/pI/D;", "getOutline", "(Landroid/view/View;Landroid/graphics/Outline;)V", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class a extends ViewOutlineProvider {
    public void getOutline(View param1View, Outline param1Outline) {
      s.f(param1View, "null cannot be cast to non-null type androidx.compose.ui.platform.ViewLayer");
      Outline outline = ViewLayer.n((ViewLayer)param1View).d();
      s.e(outline);
      param1Outline.set(outline);
    }
  }
  
  @Metadata(d1 = {"\000\024\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\002\020\005\032\0020\0042\006\020\001\032\0020\0002\006\020\003\032\0020\002H\n¢\006\004\b\005\020\006"}, d2 = {"Landroid/view/View;", "view", "Landroid/graphics/Matrix;", "matrix", "Ldbxyzptlk/pI/D;", "a", "(Landroid/view/View;Landroid/graphics/Matrix;)V"}, k = 3, mv = {1, 8, 0})
  public static final class b extends u implements p<View, Matrix, D> {
    public static final b f = new b();
    
    public b() {
      super(2);
    }
    
    public final void a(View param1View, Matrix param1Matrix) {
      param1Matrix.set(param1View.getMatrix());
    }
  }
  
  @Metadata(d1 = {"\000>\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\020\013\n\002\b\t\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\003\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\027\020\007\032\0020\0062\006\020\005\032\0020\004H\007¢\006\004\b\007\020\bR$\020\013\032\0020\t2\006\020\n\032\0020\t8\006@BX\016¢\006\f\n\004\b\013\020\f\032\004\b\r\020\016R*\020\017\032\0020\t2\006\020\n\032\0020\t8\006@@X\016¢\006\022\n\004\b\017\020\f\032\004\b\020\020\016\"\004\b\021\020\022R&\020\025\032\024\022\004\022\0020\004\022\004\022\0020\024\022\004\022\0020\0060\0238\002X\004¢\006\006\n\004\b\025\020\026R\030\020\030\032\004\030\0010\0278\002@\002X\016¢\006\006\n\004\b\030\020\031R\030\020\033\032\004\030\0010\0328\002@\002X\016¢\006\006\n\004\b\033\020\034¨\006\035"}, d2 = {"Landroidx/compose/ui/platform/ViewLayer$c;", "", "<init>", "()V", "Landroid/view/View;", "view", "Ldbxyzptlk/pI/D;", "d", "(Landroid/view/View;)V", "", "<set-?>", "hasRetrievedMethod", "Z", "a", "()Z", "shouldUseDispatchDraw", "b", "c", "(Z)V", "Lkotlin/Function2;", "Landroid/graphics/Matrix;", "getMatrix", "Ldbxyzptlk/CI/p;", "Ljava/lang/reflect/Field;", "recreateDisplayList", "Ljava/lang/reflect/Field;", "Ljava/lang/reflect/Method;", "updateDisplayListIfDirtyMethod", "Ljava/lang/reflect/Method;", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class c {
    public c() {}
    
    public final boolean a() {
      return ViewLayer.m();
    }
    
    public final boolean b() {
      return ViewLayer.p();
    }
    
    public final void c(boolean param1Boolean) {
      ViewLayer.t(param1Boolean);
    }
    
    @SuppressLint({"BanUncheckedReflection"})
    public final void d(View param1View) {
      try {
        if (!a()) {
          ViewLayer.r(true);
          int i = Build.VERSION.SDK_INT;
          if (i < 28) {
            ViewLayer.u(View.class.getDeclaredMethod("updateDisplayListIfDirty", null));
            ViewLayer.s(View.class.getDeclaredField("mRecreateDisplayList"));
          } else {
            ViewLayer.u((Method)Class.class.getDeclaredMethod("getDeclaredMethod", new Class[] { String.class, (new Class[0]).getClass() }).invoke(View.class, new Object[] { "updateDisplayListIfDirty", new Class[0] }));
            ViewLayer.s((Field)Class.class.getDeclaredMethod("getDeclaredField", new Class[] { String.class }).invoke(View.class, new Object[] { "mRecreateDisplayList" }));
          } 
          Method method1 = ViewLayer.q();
          if (method1 != null)
            method1.setAccessible(true); 
          Field field1 = ViewLayer.o();
          if (field1 != null)
            field1.setAccessible(true); 
        } 
        Field field = ViewLayer.o();
        if (field != null)
          field.setBoolean(param1View, true); 
        Method method = ViewLayer.q();
      } finally {
        param1View = null;
      } 
    }
  }
  
  class ViewLayer {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compos\\ui\platform\ViewLayer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */