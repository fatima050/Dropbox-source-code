package androidx.compose.ui.platform;

import android.content.Context;
import android.os.IBinder;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import androidx.compose.ui.node.Owner;
import dbxyzptlk.CI.p;
import dbxyzptlk.DI.u;
import dbxyzptlk.F0.c;
import dbxyzptlk.pI.D;
import dbxyzptlk.x0.C0;
import dbxyzptlk.x0.k;
import dbxyzptlk.x0.n;
import dbxyzptlk.x0.o;
import dbxyzptlk.x0.p;
import java.lang.ref.WeakReference;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

@Metadata(d1 = {"\000l\n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020\b\n\002\b\003\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\b\n\002\030\002\n\002\b\r\n\002\020\013\n\002\b\017\n\002\030\002\n\002\b\b\n\002\030\002\n\002\b\b\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\022\b'\030\0002\0020\001B'\b\007\022\006\020\003\032\0020\002\022\n\b\002\020\005\032\004\030\0010\004\022\b\b\002\020\007\032\0020\006¢\006\004\b\b\020\tJ\017\020\013\032\0020\nH\002¢\006\004\b\013\020\fJ\023\020\016\032\0020\r*\0020\rH\002¢\006\004\b\016\020\017J\017\020\020\032\0020\rH\002¢\006\004\b\020\020\021J\017\020\022\032\0020\nH\002¢\006\004\b\022\020\fJ\027\020\024\032\0020\n2\b\020\023\032\004\030\0010\r¢\006\004\b\024\020\025J\025\020\030\032\0020\n2\006\020\027\032\0020\026¢\006\004\b\030\020\031J\017\020\032\032\0020\nH'¢\006\004\b\032\020\033J\r\020\034\032\0020\n¢\006\004\b\034\020\fJ\r\020\035\032\0020\n¢\006\004\b\035\020\fJ\017\020\036\032\0020\nH\024¢\006\004\b\036\020\fJ\037\020!\032\0020\n2\006\020\037\032\0020\0062\006\020 \032\0020\006H\004¢\006\004\b!\020\"J\037\020#\032\0020\n2\006\020\037\032\0020\0062\006\020 \032\0020\006H\020¢\006\004\b#\020\"J7\020*\032\0020\n2\006\020%\032\0020$2\006\020&\032\0020\0062\006\020'\032\0020\0062\006\020(\032\0020\0062\006\020)\032\0020\006H\004¢\006\004\b*\020+J7\020,\032\0020\n2\006\020%\032\0020$2\006\020&\032\0020\0062\006\020'\032\0020\0062\006\020(\032\0020\0062\006\020)\032\0020\006H\020¢\006\004\b,\020+J\027\020.\032\0020\n2\006\020-\032\0020\006H\026¢\006\004\b.\020/J\017\0200\032\0020$H\026¢\006\004\b0\0201J\027\0202\032\0020\n2\006\0200\032\0020$H\026¢\006\004\b2\0203J\031\0206\032\0020\n2\b\0205\032\004\030\00104H\026¢\006\004\b6\0207J!\0206\032\0020\n2\b\0205\032\004\030\001042\006\0208\032\0020\006H\026¢\006\004\b6\0209J)\0206\032\0020\n2\b\0205\032\004\030\001042\006\020:\032\0020\0062\006\020;\032\0020\006H\026¢\006\004\b6\020<J#\0206\032\0020\n2\b\0205\032\004\030\001042\b\020>\032\004\030\0010=H\026¢\006\004\b6\020?J+\0206\032\0020\n2\b\0205\032\004\030\001042\006\0208\032\0020\0062\b\020>\032\004\030\0010=H\026¢\006\004\b6\020@J+\020A\032\0020$2\b\0205\032\004\030\001042\006\0208\032\0020\0062\b\020>\032\004\030\0010=H\024¢\006\004\bA\020BJ3\020A\032\0020$2\b\0205\032\004\030\001042\006\0208\032\0020\0062\b\020>\032\004\030\0010=2\006\020C\032\0020$H\024¢\006\004\bA\020DJ\017\020E\032\0020$H\026¢\006\004\bE\0201R\036\020H\032\n\022\004\022\0020\r\030\0010F8\002@\002X\016¢\006\006\n\004\b\032\020GR(\020N\032\004\030\0010I2\b\020J\032\004\030\0010I8\002@BX\016¢\006\f\n\004\b\016\020K\"\004\bL\020MR\030\020Q\032\004\030\0010O8\002@\002X\016¢\006\006\n\004\b\013\020PR(\020T\032\004\030\0010\r2\b\020J\032\004\030\0010\r8\002@BX\016¢\006\f\n\004\b\034\020R\"\004\bS\020\025R$\020X\032\n\022\004\022\0020\n\030\0010U8\002@\002X\016¢\006\f\n\004\b\035\020V\022\004\bW\020\fR0\020]\032\0020$2\006\020J\032\0020$8F@FX\016¢\006\030\n\004\b\022\020Y\022\004\b\\\020\f\032\004\bZ\0201\"\004\b[\0203R\026\020^\032\0020$8\002@\002X\016¢\006\006\n\004\b,\020YR\026\020_\032\0020$8\002@\002X\016¢\006\006\n\004\b#\020YR\030\020b\032\0020$*\0020\r8BX\004¢\006\006\032\004\b`\020aR\024\020d\032\0020$8TX\004¢\006\006\032\004\bc\0201R\021\020f\032\0020$8F¢\006\006\032\004\be\0201¨\006g"}, d2 = {"Landroidx/compose/ui/platform/AbstractComposeView;", "Landroid/view/ViewGroup;", "Landroid/content/Context;", "context", "Landroid/util/AttributeSet;", "attrs", "", "defStyleAttr", "<init>", "(Landroid/content/Context;Landroid/util/AttributeSet;I)V", "Ldbxyzptlk/pI/D;", "c", "()V", "Ldbxyzptlk/x0/p;", "b", "(Ldbxyzptlk/x0/p;)Ldbxyzptlk/x0/p;", "j", "()Ldbxyzptlk/x0/p;", "f", "parent", "setParentCompositionContext", "(Ldbxyzptlk/x0/p;)V", "Landroidx/compose/ui/platform/j;", "strategy", "setViewCompositionStrategy", "(Landroidx/compose/ui/platform/j;)V", "a", "(Ldbxyzptlk/x0/k;I)V", "d", "e", "onAttachedToWindow", "widthMeasureSpec", "heightMeasureSpec", "onMeasure", "(II)V", "h", "", "changed", "left", "top", "right", "bottom", "onLayout", "(ZIIII)V", "g", "layoutDirection", "onRtlPropertiesChanged", "(I)V", "isTransitionGroup", "()Z", "setTransitionGroup", "(Z)V", "Landroid/view/View;", "child", "addView", "(Landroid/view/View;)V", "index", "(Landroid/view/View;I)V", "width", "height", "(Landroid/view/View;II)V", "Landroid/view/ViewGroup$LayoutParams;", "params", "(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V", "(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)V", "addViewInLayout", "(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)Z", "preventRequestLayout", "(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;Z)Z", "shouldDelayChildPressedState", "Ljava/lang/ref/WeakReference;", "Ljava/lang/ref/WeakReference;", "cachedViewTreeCompositionContext", "Landroid/os/IBinder;", "value", "Landroid/os/IBinder;", "setPreviousAttachedWindowToken", "(Landroid/os/IBinder;)V", "previousAttachedWindowToken", "Ldbxyzptlk/x0/o;", "Ldbxyzptlk/x0/o;", "composition", "Ldbxyzptlk/x0/p;", "setParentContext", "parentContext", "Lkotlin/Function0;", "Ldbxyzptlk/CI/a;", "getDisposeViewCompositionStrategy$annotations", "disposeViewCompositionStrategy", "Z", "getShowLayoutBounds", "setShowLayoutBounds", "getShowLayoutBounds$annotations", "showLayoutBounds", "creatingComposition", "isTransitionGroupSet", "i", "(Ldbxyzptlk/x0/p;)Z", "isAlive", "getShouldCreateCompositionOnAttachedToWindow", "shouldCreateCompositionOnAttachedToWindow", "getHasComposition", "hasComposition", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public abstract class AbstractComposeView extends ViewGroup {
  public WeakReference<p> a;
  
  public IBinder b;
  
  public o c;
  
  public p d;
  
  public dbxyzptlk.CI.a<D> e;
  
  public boolean f;
  
  public boolean g;
  
  public boolean h;
  
  public AbstractComposeView(Context paramContext) {
    this(paramContext, null, 0, 6, null);
  }
  
  public AbstractComposeView(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 0, 4, null);
  }
  
  public AbstractComposeView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    setClipChildren(false);
    setClipToPadding(false);
    this.e = j.a.a().a(this);
  }
  
  private final void setParentContext(p paramp) {
    if (this.d != paramp) {
      this.d = paramp;
      if (paramp != null)
        this.a = null; 
      o o1 = this.c;
      if (o1 != null) {
        o1.dispose();
        this.c = null;
        if (isAttachedToWindow())
          f(); 
      } 
    } 
  }
  
  private final void setPreviousAttachedWindowToken(IBinder paramIBinder) {
    if (this.b != paramIBinder) {
      this.b = paramIBinder;
      this.a = null;
    } 
  }
  
  public abstract void a(k paramk, int paramInt);
  
  public void addView(View paramView) {
    c();
    super.addView(paramView);
  }
  
  public void addView(View paramView, int paramInt) {
    c();
    super.addView(paramView, paramInt);
  }
  
  public void addView(View paramView, int paramInt1, int paramInt2) {
    c();
    super.addView(paramView, paramInt1, paramInt2);
  }
  
  public void addView(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams) {
    c();
    super.addView(paramView, paramInt, paramLayoutParams);
  }
  
  public void addView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    c();
    super.addView(paramView, paramLayoutParams);
  }
  
  public boolean addViewInLayout(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams) {
    c();
    return super.addViewInLayout(paramView, paramInt, paramLayoutParams);
  }
  
  public boolean addViewInLayout(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams, boolean paramBoolean) {
    c();
    return super.addViewInLayout(paramView, paramInt, paramLayoutParams, paramBoolean);
  }
  
  public final p b(p paramp) {
    p p1;
    if (i(paramp)) {
      p1 = paramp;
    } else {
      p1 = null;
    } 
    if (p1 != null)
      this.a = new WeakReference<>(p1); 
    return paramp;
  }
  
  public final void c() {
    if (this.g)
      return; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Cannot add views to ");
    stringBuilder.append(getClass().getSimpleName());
    stringBuilder.append("; only Compose content is supported");
    throw new UnsupportedOperationException(stringBuilder.toString());
  }
  
  public final void d() {
    if (this.d != null || isAttachedToWindow()) {
      f();
      return;
    } 
    throw new IllegalStateException("createComposition requires either a parent reference or the View to be attachedto a window. Attach the View or call setParentCompositionReference.");
  }
  
  public final void e() {
    o o1 = this.c;
    if (o1 != null)
      o1.dispose(); 
    this.c = null;
    requestLayout();
  }
  
  public final void f() {
    if (this.c == null)
      try {
        this.g = true;
        p p1 = j();
        a a1 = new a();
        this(this);
        this.c = l.c(this, p1, (p<? super k, ? super Integer, D>)c.c(-656146368, true, a1));
      } finally {
        this.g = false;
      }  
  }
  
  public void g(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    View view = getChildAt(0);
    if (view != null)
      view.layout(getPaddingLeft(), getPaddingTop(), paramInt3 - paramInt1 - getPaddingRight(), paramInt4 - paramInt2 - getPaddingBottom()); 
  }
  
  public final boolean getHasComposition() {
    boolean bool;
    if (this.c != null) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public boolean getShouldCreateCompositionOnAttachedToWindow() {
    return true;
  }
  
  public final boolean getShowLayoutBounds() {
    return this.f;
  }
  
  public void h(int paramInt1, int paramInt2) {
    View view = getChildAt(0);
    if (view == null) {
      super.onMeasure(paramInt1, paramInt2);
      return;
    } 
    int j = Math.max(0, View.MeasureSpec.getSize(paramInt1) - getPaddingLeft() - getPaddingRight());
    int i = Math.max(0, View.MeasureSpec.getSize(paramInt2) - getPaddingTop() - getPaddingBottom());
    view.measure(View.MeasureSpec.makeMeasureSpec(j, View.MeasureSpec.getMode(paramInt1)), View.MeasureSpec.makeMeasureSpec(i, View.MeasureSpec.getMode(paramInt2)));
    setMeasuredDimension(view.getMeasuredWidth() + getPaddingLeft() + getPaddingRight(), view.getMeasuredHeight() + getPaddingTop() + getPaddingBottom());
  }
  
  public final boolean i(p paramp) {
    return (!(paramp instanceof C0) || ((C0.d<C0.d>)((C0)paramp).d0().getValue()).compareTo(C0.d.ShuttingDown) > 0);
  }
  
  public boolean isTransitionGroup() {
    return (!this.h || super.isTransitionGroup());
  }
  
  public final p j() {
    p p2 = this.d;
    p p1 = p2;
    if (p2 == null) {
      p1 = WindowRecomposer_androidKt.d((View)this);
      p p3 = null;
      if (p1 != null) {
        p2 = b(p1);
      } else {
        p2 = null;
      } 
      p1 = p2;
      if (p2 == null) {
        WeakReference<p> weakReference = this.a;
        p1 = p3;
        if (weakReference != null) {
          p p5 = weakReference.get();
          p1 = p3;
          if (p5 != null) {
            p1 = p3;
            if (i(p5))
              p1 = p5; 
          } 
        } 
        p p4 = p1;
        p1 = p4;
        if (p4 == null)
          p1 = b((p)WindowRecomposer_androidKt.h((View)this)); 
      } 
    } 
    return p1;
  }
  
  public void onAttachedToWindow() {
    super.onAttachedToWindow();
    setPreviousAttachedWindowToken(getWindowToken());
    if (getShouldCreateCompositionOnAttachedToWindow())
      f(); 
  }
  
  public final void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    g(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public final void onMeasure(int paramInt1, int paramInt2) {
    f();
    h(paramInt1, paramInt2);
  }
  
  public void onRtlPropertiesChanged(int paramInt) {
    View view = getChildAt(0);
    if (view != null)
      view.setLayoutDirection(paramInt); 
  }
  
  public final void setParentCompositionContext(p paramp) {
    setParentContext(paramp);
  }
  
  public final void setShowLayoutBounds(boolean paramBoolean) {
    this.f = paramBoolean;
    View view = getChildAt(0);
    if (view != null)
      ((Owner)view).setShowLayoutBounds(paramBoolean); 
  }
  
  public void setTransitionGroup(boolean paramBoolean) {
    super.setTransitionGroup(paramBoolean);
    this.h = true;
  }
  
  public final void setViewCompositionStrategy(j paramj) {
    dbxyzptlk.CI.a<D> a1 = this.e;
    if (a1 != null)
      a1.invoke(); 
    this.e = paramj.a(this);
  }
  
  public boolean shouldDelayChildPressedState() {
    return false;
  }
  
  @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\013¢\006\004\b\001\020\002"}, d2 = {"Ldbxyzptlk/pI/D;", "a", "(Ldbxyzptlk/x0/k;I)V"}, k = 3, mv = {1, 8, 0})
  public static final class a extends u implements p<k, Integer, D> {
    public final AbstractComposeView f;
    
    public a(AbstractComposeView param1AbstractComposeView) {
      super(2);
    }
    
    public final void a(k param1k, int param1Int) {
      if ((param1Int & 0xB) != 2 || !param1k.b()) {
        if (n.I())
          n.U(-656146368, param1Int, -1, "androidx.compose.ui.platform.AbstractComposeView.ensureCompositionCreated.<anonymous> (ComposeView.android.kt:251)"); 
        this.f.a(param1k, 8);
        if (n.I())
          n.T(); 
        return;
      } 
      param1k.k();
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compos\\ui\platform\AbstractComposeView.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */