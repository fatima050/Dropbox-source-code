package androidx.compose.ui.platform;

import android.content.ContentResolver;
import android.content.Context;
import android.database.ContentObserver;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.View;
import android.view.ViewParent;
import androidx.lifecycle.LifecycleEventObserver;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.f;
import dbxyzptlk.CI.p;
import dbxyzptlk.DI.K;
import dbxyzptlk.K0.h;
import dbxyzptlk.U2.h;
import dbxyzptlk.bK.J;
import dbxyzptlk.bK.K;
import dbxyzptlk.bK.L;
import dbxyzptlk.bK.h;
import dbxyzptlk.bK.w0;
import dbxyzptlk.d2.i;
import dbxyzptlk.dK.d;
import dbxyzptlk.dK.g;
import dbxyzptlk.eK.M;
import dbxyzptlk.eK.S;
import dbxyzptlk.eK.j;
import dbxyzptlk.eK.k;
import dbxyzptlk.g1.X1;
import dbxyzptlk.g1.w0;
import dbxyzptlk.pI.D;
import dbxyzptlk.pI.p;
import dbxyzptlk.tI.d;
import dbxyzptlk.tI.g;
import dbxyzptlk.tI.h;
import dbxyzptlk.vI.f;
import dbxyzptlk.vI.l;
import dbxyzptlk.x0.C0;
import dbxyzptlk.x0.o0;
import dbxyzptlk.x0.p;
import java.util.LinkedHashMap;
import java.util.Map;
import kotlin.KotlinNothingValueException;
import kotlin.Metadata;

@Metadata(d1 = {"\000:\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\020\007\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\020%\n\002\b\021\032\023\020\002\032\004\030\0010\001*\0020\000¢\006\004\b\002\020\003\032\035\020\b\032\b\022\004\022\0020\0070\0062\006\020\005\032\0020\004H\002¢\006\004\b\b\020\t\032)\020\017\032\0020\016*\0020\0002\b\b\002\020\013\032\0020\n2\n\b\002\020\r\032\004\030\0010\fH\007¢\006\004\b\017\020\020\"&\020\024\032\024\022\004\022\0020\004\022\n\022\b\022\004\022\0020\0070\0060\0218\002X\004¢\006\006\n\004\b\022\020\023\",\020\031\032\004\030\0010\001*\0020\0002\b\020\025\032\004\030\0010\0018F@FX\016¢\006\f\032\004\b\026\020\003\"\004\b\027\020\030\"\030\020\034\032\0020\000*\0020\0008BX\004¢\006\006\032\004\b\032\020\033\"\036\020!\032\0020\016*\0020\0008@X\004¢\006\f\022\004\b\037\020 \032\004\b\035\020\036¨\006\""}, d2 = {"Landroid/view/View;", "Ldbxyzptlk/x0/p;", "d", "(Landroid/view/View;)Ldbxyzptlk/x0/p;", "Landroid/content/Context;", "applicationContext", "Ldbxyzptlk/eK/S;", "", "e", "(Landroid/content/Context;)Ldbxyzptlk/eK/S;", "Ldbxyzptlk/tI/g;", "coroutineContext", "Landroidx/lifecycle/f;", "lifecycle", "Ldbxyzptlk/x0/C0;", "b", "(Landroid/view/View;Ldbxyzptlk/tI/g;Landroidx/lifecycle/f;)Ldbxyzptlk/x0/C0;", "", "a", "Ljava/util/Map;", "animationScale", "value", "f", "i", "(Landroid/view/View;Ldbxyzptlk/x0/p;)V", "compositionContext", "g", "(Landroid/view/View;)Landroid/view/View;", "contentChild", "h", "(Landroid/view/View;)Ldbxyzptlk/x0/C0;", "getWindowRecomposer$annotations", "(Landroid/view/View;)V", "windowRecomposer", "ui_release"}, k = 2, mv = {1, 8, 0}, xi = 48)
public final class WindowRecomposer_androidKt {
  public static final Map<Context, S<Float>> a = new LinkedHashMap<>();
  
  public static final C0 b(View paramView, g paramg, f paramf) {
    // Byte code:
    //   0: aload_1
    //   1: getstatic dbxyzptlk/tI/e.Ma : Ldbxyzptlk/tI/e$b;
    //   4: invokeinterface c : (Ldbxyzptlk/tI/g$c;)Ldbxyzptlk/tI/g$b;
    //   9: ifnull -> 26
    //   12: aload_1
    //   13: astore_3
    //   14: aload_1
    //   15: getstatic dbxyzptlk/x0/b0.Qa : Ldbxyzptlk/x0/b0$b;
    //   18: invokeinterface c : (Ldbxyzptlk/tI/g$c;)Ldbxyzptlk/tI/g$b;
    //   23: ifnonnull -> 39
    //   26: getstatic androidx/compose/ui/platform/h.m : Landroidx/compose/ui/platform/h$c;
    //   29: invokevirtual a : ()Ldbxyzptlk/tI/g;
    //   32: aload_1
    //   33: invokeinterface s : (Ldbxyzptlk/tI/g;)Ldbxyzptlk/tI/g;
    //   38: astore_3
    //   39: aload_3
    //   40: getstatic dbxyzptlk/x0/b0.Qa : Ldbxyzptlk/x0/b0$b;
    //   43: invokeinterface c : (Ldbxyzptlk/tI/g$c;)Ldbxyzptlk/tI/g$b;
    //   48: checkcast dbxyzptlk/x0/b0
    //   51: astore_1
    //   52: aload_1
    //   53: ifnull -> 72
    //   56: new dbxyzptlk/x0/o0
    //   59: dup
    //   60: aload_1
    //   61: invokespecial <init> : (Ldbxyzptlk/x0/b0;)V
    //   64: astore_1
    //   65: aload_1
    //   66: invokevirtual h : ()V
    //   69: goto -> 74
    //   72: aconst_null
    //   73: astore_1
    //   74: new dbxyzptlk/DI/K
    //   77: dup
    //   78: invokespecial <init> : ()V
    //   81: astore #6
    //   83: aload_3
    //   84: getstatic dbxyzptlk/K0/g.v0 : Ldbxyzptlk/K0/g$b;
    //   87: invokeinterface c : (Ldbxyzptlk/tI/g$c;)Ldbxyzptlk/tI/g$b;
    //   92: checkcast dbxyzptlk/K0/g
    //   95: astore #5
    //   97: aload #5
    //   99: astore #4
    //   101: aload #5
    //   103: ifnonnull -> 122
    //   106: new dbxyzptlk/g1/w0
    //   109: dup
    //   110: invokespecial <init> : ()V
    //   113: astore #4
    //   115: aload #6
    //   117: aload #4
    //   119: putfield a : Ljava/lang/Object;
    //   122: aload_1
    //   123: ifnull -> 132
    //   126: aload_1
    //   127: astore #5
    //   129: goto -> 137
    //   132: getstatic dbxyzptlk/tI/h.a : Ldbxyzptlk/tI/h;
    //   135: astore #5
    //   137: aload_3
    //   138: aload #5
    //   140: invokeinterface s : (Ldbxyzptlk/tI/g;)Ldbxyzptlk/tI/g;
    //   145: aload #4
    //   147: invokeinterface s : (Ldbxyzptlk/tI/g;)Ldbxyzptlk/tI/g;
    //   152: astore_3
    //   153: new dbxyzptlk/x0/C0
    //   156: dup
    //   157: aload_3
    //   158: invokespecial <init> : (Ldbxyzptlk/tI/g;)V
    //   161: astore #4
    //   163: aload #4
    //   165: invokevirtual l0 : ()V
    //   168: aload_3
    //   169: invokestatic a : (Ldbxyzptlk/tI/g;)Ldbxyzptlk/bK/J;
    //   172: astore #5
    //   174: aload_2
    //   175: astore_3
    //   176: aload_2
    //   177: ifnonnull -> 201
    //   180: aload_0
    //   181: invokestatic a : (Landroid/view/View;)Landroidx/lifecycle/LifecycleOwner;
    //   184: astore_2
    //   185: aload_2
    //   186: ifnull -> 199
    //   189: aload_2
    //   190: invokeinterface getLifecycle : ()Landroidx/lifecycle/f;
    //   195: astore_3
    //   196: goto -> 201
    //   199: aconst_null
    //   200: astore_3
    //   201: aload_3
    //   202: ifnull -> 241
    //   205: aload_0
    //   206: new androidx/compose/ui/platform/WindowRecomposer_androidKt$a
    //   209: dup
    //   210: aload_0
    //   211: aload #4
    //   213: invokespecial <init> : (Landroid/view/View;Ldbxyzptlk/x0/C0;)V
    //   216: invokevirtual addOnAttachStateChangeListener : (Landroid/view/View$OnAttachStateChangeListener;)V
    //   219: aload_3
    //   220: new androidx/compose/ui/platform/WindowRecomposer_androidKt$createLifecycleAwareWindowRecomposer$2
    //   223: dup
    //   224: aload #5
    //   226: aload_1
    //   227: aload #4
    //   229: aload #6
    //   231: aload_0
    //   232: invokespecial <init> : (Ldbxyzptlk/bK/J;Ldbxyzptlk/x0/o0;Ldbxyzptlk/x0/C0;Ldbxyzptlk/DI/K;Landroid/view/View;)V
    //   235: invokevirtual a : (Ldbxyzptlk/U2/h;)V
    //   238: aload #4
    //   240: areturn
    //   241: new java/lang/StringBuilder
    //   244: dup
    //   245: invokespecial <init> : ()V
    //   248: astore_1
    //   249: aload_1
    //   250: ldc 'ViewTreeLifecycleOwner not found from '
    //   252: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   255: pop
    //   256: aload_1
    //   257: aload_0
    //   258: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   261: pop
    //   262: new java/lang/IllegalStateException
    //   265: dup
    //   266: aload_1
    //   267: invokevirtual toString : ()Ljava/lang/String;
    //   270: invokevirtual toString : ()Ljava/lang/String;
    //   273: invokespecial <init> : (Ljava/lang/String;)V
    //   276: athrow
  }
  
  public static final p d(View paramView) {
    p p = f(paramView);
    if (p != null)
      return p; 
    for (ViewParent viewParent = paramView.getParent(); p == null && viewParent instanceof View; viewParent = viewParent.getParent())
      p = f((View)viewParent); 
    return p;
  }
  
  public static final S<Float> e(Context paramContext) {
    S<Float> s2;
    Map<Context, S<Float>> map = a;
    /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{java/util/Map<[ObjectType{android/content/Context}, ObjectType{dbxyzptlk/eK/S<ObjectType{java/lang/Float}>}]>}, name=null} */
    try {
      ContentResolver contentResolver2 = (ContentResolver)map.get(paramContext);
      ContentResolver contentResolver1 = contentResolver2;
      if (contentResolver2 == null) {
        contentResolver1 = paramContext.getContentResolver();
        Uri uri = Settings.Global.getUriFor("animator_duration_scale");
        d<D> d = g.b(-1, null, null, 6, null);
        Handler handler = i.a(Looper.getMainLooper());
        c c = new c();
        this(d, handler);
        b b = new b();
        this(contentResolver1, uri, c, d, paramContext, null);
        s2 = k.m0(k.P(b), K.b(), M.a.b(M.a, 0L, 0L, 3, null), Float.valueOf(Settings.Global.getFloat(paramContext.getContentResolver(), "animator_duration_scale", 1.0F)));
        map.put(paramContext, s2);
      } 
    } finally {}
    S<Float> s1 = s2;
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/util/Map<[ObjectType{android/content/Context}, ObjectType{dbxyzptlk/eK/S<ObjectType{java/lang/Float}>}]>}, name=null} */
    return s1;
  }
  
  public static final p f(View paramView) {
    Object object = paramView.getTag(h.androidx_compose_ui_view_composition_context);
    if (object instanceof p) {
      object = object;
    } else {
      object = null;
    } 
    return (p)object;
  }
  
  public static final View g(View paramView) {
    ViewParent viewParent = paramView.getParent();
    while (viewParent instanceof View) {
      View view = (View)viewParent;
      if (view.getId() == 16908290)
        return paramView; 
      viewParent = view.getParent();
      paramView = view;
    } 
    return paramView;
  }
  
  public static final C0 h(View paramView) {
    if (paramView.isAttachedToWindow()) {
      paramView = g(paramView);
      p p = f(paramView);
      if (p == null) {
        C0 c0 = X1.a.a(paramView);
      } else {
        if (p instanceof C0)
          return (C0)p; 
        throw new IllegalStateException("root viewTreeParentCompositionContext is not a Recomposer");
      } 
      return (C0)paramView;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Cannot locate windowRecomposer; View ");
    stringBuilder.append(paramView);
    stringBuilder.append(" is not attached to a window");
    throw new IllegalStateException(stringBuilder.toString().toString());
  }
  
  public static final void i(View paramView, p paramp) {
    paramView.setTag(h.androidx_compose_ui_view_composition_context, paramp);
  }
  
  @Metadata(d1 = {"\000\027\n\000\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\004*\001\000\b\n\030\0002\0020\001J\027\020\005\032\0020\0042\006\020\003\032\0020\002H\026¢\006\004\b\005\020\006J\027\020\007\032\0020\0042\006\020\003\032\0020\002H\026¢\006\004\b\007\020\006¨\006\b"}, d2 = {"androidx/compose/ui/platform/WindowRecomposer_androidKt$a", "Landroid/view/View$OnAttachStateChangeListener;", "Landroid/view/View;", "v", "Ldbxyzptlk/pI/D;", "onViewAttachedToWindow", "(Landroid/view/View;)V", "onViewDetachedFromWindow", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class a implements View.OnAttachStateChangeListener {
    public final View a;
    
    public final C0 b;
    
    public a(View param1View, C0 param1C0) {}
    
    public void onViewAttachedToWindow(View param1View) {}
    
    public void onViewDetachedFromWindow(View param1View) {
      this.a.removeOnAttachStateChangeListener(this);
      this.b.Y();
    }
  }
  
  @f(c = "androidx.compose.ui.platform.WindowRecomposer_androidKt$getAnimationScaleFlowFor$1$1$1", f = "WindowRecomposer.android.kt", l = {115, 121}, m = "invokeSuspend")
  @Metadata(d1 = {"\000\020\n\002\030\002\n\002\020\007\n\002\030\002\n\002\b\002\020\003\032\0020\002*\b\022\004\022\0020\0010\000H@¢\006\004\b\003\020\004"}, d2 = {"Ldbxyzptlk/eK/j;", "", "Ldbxyzptlk/pI/D;", "<anonymous>", "(Ldbxyzptlk/eK/j;)V"}, k = 3, mv = {1, 8, 0})
  public static final class b extends l implements p<j<? super Float>, d<? super D>, Object> {
    public final Context A;
    
    public Object t;
    
    public int u;
    
    public Object v;
    
    public final ContentResolver w;
    
    public final Uri x;
    
    public final WindowRecomposer_androidKt.c y;
    
    public final d<D> z;
    
    public b(ContentResolver param1ContentResolver, Uri param1Uri, WindowRecomposer_androidKt.c param1c, d<D> param1d, Context param1Context, d<? super b> param1d1) {
      super(2, param1d1);
    }
    
    public final Object a(j<? super Float> param1j, d<? super D> param1d) {
      return ((b)create(param1j, param1d)).invokeSuspend(D.a);
    }
    
    public final d<D> create(Object param1Object, d<?> param1d) {
      b b1 = new b(this.w, this.x, this.y, this.z, this.A, (d)param1d);
      b1.v = param1Object;
      return (d<D>)b1;
    }
    
    public final Object invokeSuspend(Object param1Object) {
      // Byte code:
      //   0: invokestatic g : ()Ljava/lang/Object;
      //   3: astore #6
      //   5: aload_0
      //   6: getfield u : I
      //   9: istore_2
      //   10: iload_2
      //   11: ifeq -> 92
      //   14: iload_2
      //   15: iconst_1
      //   16: if_icmpeq -> 65
      //   19: iload_2
      //   20: iconst_2
      //   21: if_icmpne -> 55
      //   24: aload_0
      //   25: getfield t : Ljava/lang/Object;
      //   28: checkcast dbxyzptlk/dK/f
      //   31: astore #4
      //   33: aload_0
      //   34: getfield v : Ljava/lang/Object;
      //   37: checkcast dbxyzptlk/eK/j
      //   40: astore_3
      //   41: aload_1
      //   42: invokestatic b : (Ljava/lang/Object;)V
      //   45: aload #4
      //   47: astore_1
      //   48: goto -> 130
      //   51: astore_1
      //   52: goto -> 257
      //   55: new java/lang/IllegalStateException
      //   58: dup
      //   59: ldc 'call to 'resume' before 'invoke' with coroutine'
      //   61: invokespecial <init> : (Ljava/lang/String;)V
      //   64: athrow
      //   65: aload_0
      //   66: getfield t : Ljava/lang/Object;
      //   69: checkcast dbxyzptlk/dK/f
      //   72: astore #4
      //   74: aload_0
      //   75: getfield v : Ljava/lang/Object;
      //   78: checkcast dbxyzptlk/eK/j
      //   81: astore_3
      //   82: aload_1
      //   83: invokestatic b : (Ljava/lang/Object;)V
      //   86: aload_1
      //   87: astore #5
      //   89: goto -> 167
      //   92: aload_1
      //   93: invokestatic b : (Ljava/lang/Object;)V
      //   96: aload_0
      //   97: getfield v : Ljava/lang/Object;
      //   100: checkcast dbxyzptlk/eK/j
      //   103: astore_3
      //   104: aload_0
      //   105: getfield w : Landroid/content/ContentResolver;
      //   108: aload_0
      //   109: getfield x : Landroid/net/Uri;
      //   112: iconst_0
      //   113: aload_0
      //   114: getfield y : Landroidx/compose/ui/platform/WindowRecomposer_androidKt$c;
      //   117: invokevirtual registerContentObserver : (Landroid/net/Uri;ZLandroid/database/ContentObserver;)V
      //   120: aload_0
      //   121: getfield z : Ldbxyzptlk/dK/d;
      //   124: invokeinterface iterator : ()Ldbxyzptlk/dK/f;
      //   129: astore_1
      //   130: aload_0
      //   131: aload_3
      //   132: putfield v : Ljava/lang/Object;
      //   135: aload_0
      //   136: aload_1
      //   137: putfield t : Ljava/lang/Object;
      //   140: aload_0
      //   141: iconst_1
      //   142: putfield u : I
      //   145: aload_1
      //   146: aload_0
      //   147: invokeinterface a : (Ldbxyzptlk/tI/d;)Ljava/lang/Object;
      //   152: astore #5
      //   154: aload #5
      //   156: aload #6
      //   158: if_acmpne -> 164
      //   161: aload #6
      //   163: areturn
      //   164: aload_1
      //   165: astore #4
      //   167: aload #5
      //   169: checkcast java/lang/Boolean
      //   172: invokevirtual booleanValue : ()Z
      //   175: ifeq -> 242
      //   178: aload #4
      //   180: invokeinterface next : ()Ljava/lang/Object;
      //   185: pop
      //   186: aload_0
      //   187: getfield A : Landroid/content/Context;
      //   190: invokevirtual getContentResolver : ()Landroid/content/ContentResolver;
      //   193: ldc 'animator_duration_scale'
      //   195: fconst_1
      //   196: invokestatic getFloat : (Landroid/content/ContentResolver;Ljava/lang/String;F)F
      //   199: invokestatic c : (F)Ljava/lang/Float;
      //   202: astore_1
      //   203: aload_0
      //   204: aload_3
      //   205: putfield v : Ljava/lang/Object;
      //   208: aload_0
      //   209: aload #4
      //   211: putfield t : Ljava/lang/Object;
      //   214: aload_0
      //   215: iconst_2
      //   216: putfield u : I
      //   219: aload_3
      //   220: aload_1
      //   221: aload_0
      //   222: invokeinterface c : (Ljava/lang/Object;Ldbxyzptlk/tI/d;)Ljava/lang/Object;
      //   227: astore #5
      //   229: aload #4
      //   231: astore_1
      //   232: aload #5
      //   234: aload #6
      //   236: if_acmpne -> 48
      //   239: aload #6
      //   241: areturn
      //   242: aload_0
      //   243: getfield w : Landroid/content/ContentResolver;
      //   246: aload_0
      //   247: getfield y : Landroidx/compose/ui/platform/WindowRecomposer_androidKt$c;
      //   250: invokevirtual unregisterContentObserver : (Landroid/database/ContentObserver;)V
      //   253: getstatic dbxyzptlk/pI/D.a : Ldbxyzptlk/pI/D;
      //   256: areturn
      //   257: aload_0
      //   258: getfield w : Landroid/content/ContentResolver;
      //   261: aload_0
      //   262: getfield y : Landroidx/compose/ui/platform/WindowRecomposer_androidKt$c;
      //   265: invokevirtual unregisterContentObserver : (Landroid/database/ContentObserver;)V
      //   268: aload_1
      //   269: athrow
      // Exception table:
      //   from	to	target	type
      //   41	45	51	finally
      //   82	86	51	finally
      //   120	130	51	finally
      //   130	154	51	finally
      //   167	229	51	finally
    }
  }
  
  @Metadata(d1 = {"\000\035\n\000\n\002\030\002\n\002\020\013\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\003*\001\000\b\n\030\0002\0020\001J!\020\007\032\0020\0062\006\020\003\032\0020\0022\b\020\005\032\004\030\0010\004H\026¢\006\004\b\007\020\b¨\006\t"}, d2 = {"androidx/compose/ui/platform/WindowRecomposer_androidKt$c", "Landroid/database/ContentObserver;", "", "selfChange", "Landroid/net/Uri;", "uri", "Ldbxyzptlk/pI/D;", "onChange", "(ZLandroid/net/Uri;)V", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class c extends ContentObserver {
    public final d<D> a;
    
    public c(d<D> param1d, Handler param1Handler) {
      super(param1Handler);
    }
    
    public void onChange(boolean param1Boolean, Uri param1Uri) {
      this.a.k(D.a);
    }
  }
  
  @Metadata(d1 = {"\000\035\n\000\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\003*\001\000\b\n\030\0002\0020\001J\037\020\007\032\0020\0062\006\020\003\032\0020\0022\006\020\005\032\0020\004H\026¢\006\004\b\007\020\b¨\006\t"}, d2 = {"androidx/compose/ui/platform/WindowRecomposer_androidKt$createLifecycleAwareWindowRecomposer$2", "Landroidx/lifecycle/LifecycleEventObserver;", "Landroidx/lifecycle/LifecycleOwner;", "source", "Landroidx/lifecycle/f$a;", "event", "Ldbxyzptlk/pI/D;", "f", "(Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/f$a;)V", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class WindowRecomposer_androidKt$createLifecycleAwareWindowRecomposer$2 implements LifecycleEventObserver {
    public final J a;
    
    public final o0 b;
    
    public final C0 c;
    
    public final K<w0> d;
    
    public final View e;
    
    public WindowRecomposer_androidKt$createLifecycleAwareWindowRecomposer$2(J param1J, o0 param1o0, C0 param1C0, K<w0> param1K, View param1View) {}
    
    public void f(LifecycleOwner param1LifecycleOwner, f.a param1a) {
      o0 o01;
      int i = a.a[param1a.ordinal()];
      if (i != 1) {
        if (i != 2) {
          if (i != 3) {
            if (i == 4)
              this.c.Y(); 
          } else {
            this.c.l0();
          } 
        } else {
          o01 = this.b;
          if (o01 != null)
            o01.j(); 
          this.c.x0();
        } 
      } else {
        h.d(this.a, null, L.UNDISPATCHED, new b(this.d, this.c, (LifecycleOwner)o01, this, this.e, null), 1, null);
      } 
    }
    
    @f(c = "androidx.compose.ui.platform.WindowRecomposer_androidKt$createLifecycleAwareWindowRecomposer$2$onStateChanged$1", f = "WindowRecomposer.android.kt", l = {394}, m = "invokeSuspend")
    @Metadata(d1 = {"\000\f\n\002\030\002\n\002\030\002\n\002\b\002\020\002\032\0020\001*\0020\000H@¢\006\004\b\002\020\003"}, d2 = {"Ldbxyzptlk/bK/J;", "Ldbxyzptlk/pI/D;", "<anonymous>", "(Ldbxyzptlk/bK/J;)V"}, k = 3, mv = {1, 8, 0})
    public static final class b extends l implements p<J, d<? super D>, Object> {
      public int t;
      
      public Object u;
      
      public final K<w0> v;
      
      public final C0 w;
      
      public final LifecycleOwner x;
      
      public final WindowRecomposer_androidKt$createLifecycleAwareWindowRecomposer$2 y;
      
      public final View z;
      
      public b(K<w0> param1K, C0 param1C0, LifecycleOwner param1LifecycleOwner, WindowRecomposer_androidKt$createLifecycleAwareWindowRecomposer$2 param1WindowRecomposer_androidKt$createLifecycleAwareWindowRecomposer$2, View param1View, d<? super b> param1d) {
        super(2, param1d);
      }
      
      public final d<D> create(Object param1Object, d<?> param1d) {
        b b1 = new b(this.v, this.w, this.x, this.y, this.z, (d)param1d);
        b1.u = param1Object;
        return (d<D>)b1;
      }
      
      public final Object invoke(J param1J, d<? super D> param1d) {
        return ((b)create(param1J, param1d)).invokeSuspend(D.a);
      }
      
      public final Object invokeSuspend(Object param1Object) {
        Object object = dbxyzptlk.uI.c.g();
        int i = this.t;
        if (i != 0) {
          if (i == 1) {
            object = this.u;
            try {
              p.b(param1Object);
            } finally {
              Exception exception = null;
              param1Object = object;
            } 
          } else {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
          } 
        } else {
          p.b(param1Object);
          J j = (J)this.u;
          try {
            w0 w0 = (w0)this.v.a;
          } finally {
            object = null;
          } 
          try {
            C0 c0 = this.w;
            this.u = param1Object;
            this.t = 1;
            Object object1 = c0.y0((d)this);
            if (object1 == object)
              return object; 
            object = param1Object;
            if (object != null)
              w0.a.a((w0)object, null, 1, null); 
            this.x.getLifecycle().d((h)this.y);
            return D.a;
          } finally {}
          if (param1Object != null)
            w0.a.a((w0)param1Object, null, 1, null); 
          this.x.getLifecycle().d((h)this.y);
          throw object;
        } 
        if (object != null)
          w0.a.a((w0)object, null, 1, null); 
        this.x.getLifecycle().d((h)this.y);
        return D.a;
      }
      
      @f(c = "androidx.compose.ui.platform.WindowRecomposer_androidKt$createLifecycleAwareWindowRecomposer$2$onStateChanged$1$1$1", f = "WindowRecomposer.android.kt", l = {389}, m = "invokeSuspend")
      @Metadata(d1 = {"\000\f\n\002\030\002\n\002\030\002\n\002\b\002\020\002\032\0020\001*\0020\000H@¢\006\004\b\002\020\003"}, d2 = {"Ldbxyzptlk/bK/J;", "Ldbxyzptlk/pI/D;", "<anonymous>", "(Ldbxyzptlk/bK/J;)V"}, k = 3, mv = {1, 8, 0})
      public static final class a extends l implements p<J, d<? super D>, Object> {
        public int t;
        
        public final S<Float> u;
        
        public final w0 v;
        
        public a(S<Float> param2S, w0 param2w0, d<? super a> param2d) {
          super(2, param2d);
        }
        
        public final d<D> create(Object param2Object, d<?> param2d) {
          return (d<D>)new a(this.u, this.v, (d)param2d);
        }
        
        public final Object invoke(J param2J, d<? super D> param2d) {
          return ((a)create(param2J, param2d)).invokeSuspend(D.a);
        }
        
        public final Object invokeSuspend(Object<Float> param2Object) {
          Object object = dbxyzptlk.uI.c.g();
          int i = this.t;
          if (i != 0) {
            if (i != 1)
              throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine"); 
            p.b(param2Object);
          } else {
            p.b(param2Object);
            param2Object = (Object<Float>)this.u;
            a a1 = new a(this.v);
            this.t = 1;
            if (param2Object.a(a1, (d)this) == object)
              return object; 
          } 
          throw new KotlinNothingValueException();
        }
        
        @Metadata(d1 = {"\000\016\n\002\020\007\n\000\n\002\030\002\n\002\b\002\020\003\032\0020\0022\006\020\001\032\0020\000H@¢\006\004\b\003\020\004"}, d2 = {"", "scaleFactor", "Ldbxyzptlk/pI/D;", "a", "(FLdbxyzptlk/tI/d;)Ljava/lang/Object;"}, k = 3, mv = {1, 8, 0})
        public static final class a<T> implements j {
          public final w0 a;
          
          public a(w0 param3w0) {}
          
          public final Object a(float param3Float, d<? super D> param3d) {
            this.a.h(param3Float);
            return D.a;
          }
        }
      }
      
      @Metadata(d1 = {"\000\016\n\002\020\007\n\000\n\002\030\002\n\002\b\002\020\003\032\0020\0022\006\020\001\032\0020\000H@¢\006\004\b\003\020\004"}, d2 = {"", "scaleFactor", "Ldbxyzptlk/pI/D;", "a", "(FLdbxyzptlk/tI/d;)Ljava/lang/Object;"}, k = 3, mv = {1, 8, 0})
      public static final class a<T> implements j {
        public final w0 a;
        
        public a(w0 param2w0) {}
        
        public final Object a(float param2Float, d<? super D> param2d) {
          this.a.h(param2Float);
          return D.a;
        }
      }
    }
    
    @f(c = "androidx.compose.ui.platform.WindowRecomposer_androidKt$createLifecycleAwareWindowRecomposer$2$onStateChanged$1$1$1", f = "WindowRecomposer.android.kt", l = {389}, m = "invokeSuspend")
    @Metadata(d1 = {"\000\f\n\002\030\002\n\002\030\002\n\002\b\002\020\002\032\0020\001*\0020\000H@¢\006\004\b\002\020\003"}, d2 = {"Ldbxyzptlk/bK/J;", "Ldbxyzptlk/pI/D;", "<anonymous>", "(Ldbxyzptlk/bK/J;)V"}, k = 3, mv = {1, 8, 0})
    public static final class a extends l implements p<J, d<? super D>, Object> {
      public int t;
      
      public final S<Float> u;
      
      public final w0 v;
      
      public a(S<Float> param1S, w0 param1w0, d<? super a> param1d) {
        super(2, param1d);
      }
      
      public final d<D> create(Object param1Object, d<?> param1d) {
        return (d<D>)new a(this.u, this.v, (d)param1d);
      }
      
      public final Object invoke(J param1J, d<? super D> param1d) {
        return ((a)create(param1J, param1d)).invokeSuspend(D.a);
      }
      
      public final Object invokeSuspend(Object<Float> param1Object) {
        Object object = dbxyzptlk.uI.c.g();
        int i = this.t;
        if (i != 0) {
          if (i != 1)
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine"); 
          p.b(param1Object);
        } else {
          p.b(param1Object);
          param1Object = (Object<Float>)this.u;
          a a1 = new a(this.v);
          this.t = 1;
          if (param1Object.a(a1, (d)this) == object)
            return object; 
        } 
        throw new KotlinNothingValueException();
      }
      
      @Metadata(d1 = {"\000\016\n\002\020\007\n\000\n\002\030\002\n\002\b\002\020\003\032\0020\0022\006\020\001\032\0020\000H@¢\006\004\b\003\020\004"}, d2 = {"", "scaleFactor", "Ldbxyzptlk/pI/D;", "a", "(FLdbxyzptlk/tI/d;)Ljava/lang/Object;"}, k = 3, mv = {1, 8, 0})
      public static final class a<T> implements j {
        public final w0 a;
        
        public a(w0 param3w0) {}
        
        public final Object a(float param3Float, d<? super D> param3d) {
          this.a.h(param3Float);
          return D.a;
        }
      }
    }
    
    @Metadata(d1 = {"\000\016\n\002\020\007\n\000\n\002\030\002\n\002\b\002\020\003\032\0020\0022\006\020\001\032\0020\000H@¢\006\004\b\003\020\004"}, d2 = {"", "scaleFactor", "Ldbxyzptlk/pI/D;", "a", "(FLdbxyzptlk/tI/d;)Ljava/lang/Object;"}, k = 3, mv = {1, 8, 0})
    public static final class a<T> implements j {
      public final w0 a;
      
      public a(w0 param1w0) {}
      
      public final Object a(float param1Float, d<? super D> param1d) {
        this.a.h(param1Float);
        return D.a;
      }
    }
  }
  
  @f(c = "androidx.compose.ui.platform.WindowRecomposer_androidKt$createLifecycleAwareWindowRecomposer$2$onStateChanged$1", f = "WindowRecomposer.android.kt", l = {394}, m = "invokeSuspend")
  @Metadata(d1 = {"\000\f\n\002\030\002\n\002\030\002\n\002\b\002\020\002\032\0020\001*\0020\000H@¢\006\004\b\002\020\003"}, d2 = {"Ldbxyzptlk/bK/J;", "Ldbxyzptlk/pI/D;", "<anonymous>", "(Ldbxyzptlk/bK/J;)V"}, k = 3, mv = {1, 8, 0})
  public static final class b extends l implements p<J, d<? super D>, Object> {
    public int t;
    
    public Object u;
    
    public final K<w0> v;
    
    public final C0 w;
    
    public final LifecycleOwner x;
    
    public final WindowRecomposer_androidKt$createLifecycleAwareWindowRecomposer$2 y;
    
    public final View z;
    
    public b(K<w0> param1K, C0 param1C0, LifecycleOwner param1LifecycleOwner, WindowRecomposer_androidKt$createLifecycleAwareWindowRecomposer$2 param1WindowRecomposer_androidKt$createLifecycleAwareWindowRecomposer$2, View param1View, d<? super b> param1d) {
      super(2, param1d);
    }
    
    public final d<D> create(Object param1Object, d<?> param1d) {
      b b1 = new b(this.v, this.w, this.x, this.y, this.z, (d)param1d);
      b1.u = param1Object;
      return (d<D>)b1;
    }
    
    public final Object invoke(J param1J, d<? super D> param1d) {
      return ((b)create(param1J, param1d)).invokeSuspend(D.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = dbxyzptlk.uI.c.g();
      int i = this.t;
      if (i != 0) {
        if (i == 1) {
          object = this.u;
          try {
            p.b(param1Object);
          } finally {
            Exception exception = null;
            param1Object = object;
          } 
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        p.b(param1Object);
        J j = (J)this.u;
        try {
          w0 w0 = (w0)this.v.a;
        } finally {
          object = null;
        } 
        try {
          C0 c0 = this.w;
          this.u = param1Object;
          this.t = 1;
          Object object1 = c0.y0((d)this);
          if (object1 == object)
            return object; 
          object = param1Object;
          if (object != null)
            w0.a.a((w0)object, null, 1, null); 
          this.x.getLifecycle().d((h)this.y);
          return D.a;
        } finally {}
        if (param1Object != null)
          w0.a.a((w0)param1Object, null, 1, null); 
        this.x.getLifecycle().d((h)this.y);
        throw object;
      } 
      if (object != null)
        w0.a.a((w0)object, null, 1, null); 
      this.x.getLifecycle().d((h)this.y);
      return D.a;
    }
    
    @f(c = "androidx.compose.ui.platform.WindowRecomposer_androidKt$createLifecycleAwareWindowRecomposer$2$onStateChanged$1$1$1", f = "WindowRecomposer.android.kt", l = {389}, m = "invokeSuspend")
    @Metadata(d1 = {"\000\f\n\002\030\002\n\002\030\002\n\002\b\002\020\002\032\0020\001*\0020\000H@¢\006\004\b\002\020\003"}, d2 = {"Ldbxyzptlk/bK/J;", "Ldbxyzptlk/pI/D;", "<anonymous>", "(Ldbxyzptlk/bK/J;)V"}, k = 3, mv = {1, 8, 0})
    public static final class a extends l implements p<J, d<? super D>, Object> {
      public int t;
      
      public final S<Float> u;
      
      public final w0 v;
      
      public a(S<Float> param2S, w0 param2w0, d<? super a> param2d) {
        super(2, param2d);
      }
      
      public final d<D> create(Object param2Object, d<?> param2d) {
        return (d<D>)new a(this.u, this.v, (d)param2d);
      }
      
      public final Object invoke(J param2J, d<? super D> param2d) {
        return ((a)create(param2J, param2d)).invokeSuspend(D.a);
      }
      
      public final Object invokeSuspend(Object<Float> param2Object) {
        Object object = dbxyzptlk.uI.c.g();
        int i = this.t;
        if (i != 0) {
          if (i != 1)
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine"); 
          p.b(param2Object);
        } else {
          p.b(param2Object);
          param2Object = (Object<Float>)this.u;
          a a1 = new a(this.v);
          this.t = 1;
          if (param2Object.a(a1, (d)this) == object)
            return object; 
        } 
        throw new KotlinNothingValueException();
      }
      
      @Metadata(d1 = {"\000\016\n\002\020\007\n\000\n\002\030\002\n\002\b\002\020\003\032\0020\0022\006\020\001\032\0020\000H@¢\006\004\b\003\020\004"}, d2 = {"", "scaleFactor", "Ldbxyzptlk/pI/D;", "a", "(FLdbxyzptlk/tI/d;)Ljava/lang/Object;"}, k = 3, mv = {1, 8, 0})
      public static final class a<T> implements j {
        public final w0 a;
        
        public a(w0 param3w0) {}
        
        public final Object a(float param3Float, d<? super D> param3d) {
          this.a.h(param3Float);
          return D.a;
        }
      }
    }
    
    @Metadata(d1 = {"\000\016\n\002\020\007\n\000\n\002\030\002\n\002\b\002\020\003\032\0020\0022\006\020\001\032\0020\000H@¢\006\004\b\003\020\004"}, d2 = {"", "scaleFactor", "Ldbxyzptlk/pI/D;", "a", "(FLdbxyzptlk/tI/d;)Ljava/lang/Object;"}, k = 3, mv = {1, 8, 0})
    public static final class a<T> implements j {
      public final w0 a;
      
      public a(w0 param2w0) {}
      
      public final Object a(float param2Float, d<? super D> param2d) {
        this.a.h(param2Float);
        return D.a;
      }
    }
  }
  
  @f(c = "androidx.compose.ui.platform.WindowRecomposer_androidKt$createLifecycleAwareWindowRecomposer$2$onStateChanged$1$1$1", f = "WindowRecomposer.android.kt", l = {389}, m = "invokeSuspend")
  @Metadata(d1 = {"\000\f\n\002\030\002\n\002\030\002\n\002\b\002\020\002\032\0020\001*\0020\000H@¢\006\004\b\002\020\003"}, d2 = {"Ldbxyzptlk/bK/J;", "Ldbxyzptlk/pI/D;", "<anonymous>", "(Ldbxyzptlk/bK/J;)V"}, k = 3, mv = {1, 8, 0})
  public static final class a extends l implements p<J, d<? super D>, Object> {
    public int t;
    
    public final S<Float> u;
    
    public final w0 v;
    
    public a(S<Float> param1S, w0 param1w0, d<? super a> param1d) {
      super(2, param1d);
    }
    
    public final d<D> create(Object param1Object, d<?> param1d) {
      return (d<D>)new a(this.u, this.v, (d)param1d);
    }
    
    public final Object invoke(J param1J, d<? super D> param1d) {
      return ((a)create(param1J, param1d)).invokeSuspend(D.a);
    }
    
    public final Object invokeSuspend(Object<Float> param1Object) {
      Object object = dbxyzptlk.uI.c.g();
      int i = this.t;
      if (i != 0) {
        if (i != 1)
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine"); 
        p.b(param1Object);
      } else {
        p.b(param1Object);
        param1Object = (Object<Float>)this.u;
        a a1 = new a(this.v);
        this.t = 1;
        if (param1Object.a(a1, (d)this) == object)
          return object; 
      } 
      throw new KotlinNothingValueException();
    }
    
    @Metadata(d1 = {"\000\016\n\002\020\007\n\000\n\002\030\002\n\002\b\002\020\003\032\0020\0022\006\020\001\032\0020\000H@¢\006\004\b\003\020\004"}, d2 = {"", "scaleFactor", "Ldbxyzptlk/pI/D;", "a", "(FLdbxyzptlk/tI/d;)Ljava/lang/Object;"}, k = 3, mv = {1, 8, 0})
    public static final class a<T> implements j {
      public final w0 a;
      
      public a(w0 param3w0) {}
      
      public final Object a(float param3Float, d<? super D> param3d) {
        this.a.h(param3Float);
        return D.a;
      }
    }
  }
  
  @Metadata(d1 = {"\000\016\n\002\020\007\n\000\n\002\030\002\n\002\b\002\020\003\032\0020\0022\006\020\001\032\0020\000H@¢\006\004\b\003\020\004"}, d2 = {"", "scaleFactor", "Ldbxyzptlk/pI/D;", "a", "(FLdbxyzptlk/tI/d;)Ljava/lang/Object;"}, k = 3, mv = {1, 8, 0})
  public static final class a<T> implements j {
    public final w0 a;
    
    public a(w0 param1w0) {}
    
    public final Object a(float param1Float, d<? super D> param1d) {
      this.a.h(param1Float);
      return D.a;
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compos\\ui\platform\WindowRecomposer_androidKt.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */