package androidx.compose.ui.platform;

import dbxyzptlk.CI.l;
import dbxyzptlk.f1.Z;
import dbxyzptlk.pI.D;
import kotlin.Metadata;

@Metadata(d1 = {"\000\f\n\002\030\002\n\002\030\002\n\002\b\003\bg\030\000 \0022\0020\001:\001\003ø\001\000\002\006\n\004\b!0\001¨\006\004À\006\001"}, d2 = {"Landroidx/compose/ui/platform/k;", "Ldbxyzptlk/f1/Z;", "s0", "a", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public interface k extends Z {
  public static final a s0 = a.a;
  
  @Metadata(d1 = {"\000\034\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\t\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003R6\020\016\032\020\022\004\022\0020\005\022\004\022\0020\006\030\0010\0048\006@\006X\016¢\006\030\n\004\b\007\020\b\022\004\b\r\020\003\032\004\b\t\020\n\"\004\b\013\020\f¨\006\017"}, d2 = {"Landroidx/compose/ui/platform/k$a;", "", "<init>", "()V", "Lkotlin/Function1;", "Landroidx/compose/ui/platform/k;", "Ldbxyzptlk/pI/D;", "b", "Ldbxyzptlk/CI/l;", "a", "()Ldbxyzptlk/CI/l;", "setOnViewCreatedCallback", "(Ldbxyzptlk/CI/l;)V", "getOnViewCreatedCallback$annotations", "onViewCreatedCallback", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class a {
    public static final a a = new a();
    
    public static l<? super k, D> b;
    
    public final l<k, D> a() {
      return (l)b;
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compos\\ui\platform\k.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */