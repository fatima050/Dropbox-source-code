package androidx.compose.ui.platform;

import android.view.DragEvent;
import android.view.View;
import androidx.compose.ui.d;
import dbxyzptlk.CI.l;
import dbxyzptlk.CI.q;
import dbxyzptlk.DI.u;
import dbxyzptlk.M0.b;
import dbxyzptlk.M0.c;
import dbxyzptlk.M0.d;
import dbxyzptlk.M0.e;
import dbxyzptlk.M0.g;
import dbxyzptlk.M0.h;
import dbxyzptlk.P0.l;
import dbxyzptlk.S0.f;
import dbxyzptlk.V.b;
import dbxyzptlk.f1.G;
import dbxyzptlk.pI.D;
import java.util.Iterator;
import kotlin.Metadata;

@Metadata(d1 = {"\000Z\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\013\n\002\b\003\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\006\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\005\b\002\030\0002\0020\0012\0020\002B3\022*\020\n\032&\022\004\022\0020\004\022\004\022\0020\005\022\020\022\016\022\004\022\0020\007\022\004\022\0020\b0\006\022\004\022\0020\t0\003¢\006\004\b\013\020\fJ\037\020\021\032\0020\t2\006\020\016\032\0020\r2\006\020\020\032\0020\017H\026¢\006\004\b\021\020\022J\027\020\025\032\0020\b2\006\020\024\032\0020\023H\026¢\006\004\b\025\020\026J\027\020\027\032\0020\t2\006\020\024\032\0020\023H\026¢\006\004\b\027\020\030R8\020\n\032&\022\004\022\0020\004\022\004\022\0020\005\022\020\022\016\022\004\022\0020\007\022\004\022\0020\b0\006\022\004\022\0020\t0\0038\002X\004¢\006\006\n\004\b\025\020\031R\024\020\034\032\0020\0328\002X\004¢\006\006\n\004\b\027\020\033R\032\020 \032\b\022\004\022\0020\0230\0358\002X\004¢\006\006\n\004\b\036\020\037R\032\020%\032\0020!8\026X\004¢\006\f\n\004\b\"\020#\032\004\b\"\020$¨\006&"}, d2 = {"Landroidx/compose/ui/platform/DragAndDropModifierOnDragListener;", "Landroid/view/View$OnDragListener;", "Ldbxyzptlk/M0/c;", "Lkotlin/Function3;", "Ldbxyzptlk/M0/h;", "Ldbxyzptlk/P0/l;", "Lkotlin/Function1;", "Ldbxyzptlk/S0/f;", "Ldbxyzptlk/pI/D;", "", "startDrag", "<init>", "(Ldbxyzptlk/CI/q;)V", "Landroid/view/View;", "view", "Landroid/view/DragEvent;", "event", "onDrag", "(Landroid/view/View;Landroid/view/DragEvent;)Z", "Ldbxyzptlk/M0/d;", "node", "a", "(Ldbxyzptlk/M0/d;)V", "b", "(Ldbxyzptlk/M0/d;)Z", "Ldbxyzptlk/CI/q;", "Ldbxyzptlk/M0/e;", "Ldbxyzptlk/M0/e;", "rootDragAndDropNode", "Ldbxyzptlk/V/b;", "c", "Ldbxyzptlk/V/b;", "interestedNodes", "Landroidx/compose/ui/d;", "d", "Landroidx/compose/ui/d;", "()Landroidx/compose/ui/d;", "modifier", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class DragAndDropModifierOnDragListener implements View.OnDragListener, c {
  public final q<h, l, l<? super f, D>, Boolean> a;
  
  public final e b;
  
  public final b<d> c;
  
  public final d d;
  
  public DragAndDropModifierOnDragListener(q<? super h, ? super l, ? super l<? super f, D>, Boolean> paramq) {
    this.a = (q)paramq;
    this.b = new e(a.f);
    this.c = new b(0, 1, null);
    this.d = (d)new DragAndDropModifierOnDragListener$modifier$1(this);
  }
  
  public void a(d paramd) {
    this.c.add(paramd);
  }
  
  public boolean b(d paramd) {
    return this.c.contains(paramd);
  }
  
  public d d() {
    return this.d;
  }
  
  public boolean onDrag(View paramView, DragEvent paramDragEvent) {
    b b1 = new b(paramDragEvent);
    int i = paramDragEvent.getAction();
    boolean bool1 = false;
    switch (i) {
      default:
        return bool1;
      case 6:
        this.b.F(b1);
      case 5:
        this.b.l1(b1);
      case 4:
        this.b.h1(b1);
      case 3:
        bool1 = this.b.T0(b1);
      case 2:
        this.b.G1(b1);
      case 1:
        break;
    } 
    boolean bool2 = this.b.k2(b1);
    Iterator<d> iterator = this.c.iterator();
    while (true) {
      bool1 = bool2;
      if (iterator.hasNext()) {
        ((d)iterator.next()).Q(b1);
        continue;
      } 
      break;
    } 
  }
  
  @Metadata(d1 = {"\000\016\n\002\030\002\n\000\n\002\030\002\n\002\b\002\020\003\032\004\030\0010\0022\006\020\001\032\0020\000H\n¢\006\004\b\003\020\004"}, d2 = {"Ldbxyzptlk/M0/b;", "it", "Ldbxyzptlk/M0/g;", "a", "(Ldbxyzptlk/M0/b;)Ldbxyzptlk/M0/g;"}, k = 3, mv = {1, 8, 0})
  public static final class a extends u implements l<b, g> {
    public static final a f = new a();
    
    public a() {
      super(1);
    }
    
    public final g a(b param1b) {
      return null;
    }
  }
  
  @Metadata(d1 = {"\000/\n\000\n\002\030\002\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\002\n\002\020\b\n\002\b\002\n\002\020\000\n\000\n\002\020\013\n\002\b\003*\001\000\b\n\030\0002\b\022\004\022\0020\0020\001J\017\020\003\032\0020\002H\026¢\006\004\b\003\020\004J\027\020\007\032\0020\0062\006\020\005\032\0020\002H\026¢\006\004\b\007\020\bJ\017\020\n\032\0020\tH\026¢\006\004\b\n\020\013J\032\020\017\032\0020\0162\b\020\r\032\004\030\0010\fH\002¢\006\004\b\017\020\020¨\006\021"}, d2 = {"androidx/compose/ui/platform/DragAndDropModifierOnDragListener$modifier$1", "Ldbxyzptlk/f1/G;", "Ldbxyzptlk/M0/e;", "i", "()Ldbxyzptlk/M0/e;", "node", "Ldbxyzptlk/pI/D;", "k", "(Ldbxyzptlk/M0/e;)V", "", "hashCode", "()I", "", "other", "", "equals", "(Ljava/lang/Object;)Z", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class DragAndDropModifierOnDragListener$modifier$1 extends G<e> {
    public final DragAndDropModifierOnDragListener b;
    
    public DragAndDropModifierOnDragListener$modifier$1(DragAndDropModifierOnDragListener param1DragAndDropModifierOnDragListener) {}
    
    public boolean equals(Object param1Object) {
      boolean bool;
      if (param1Object == this) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    public int hashCode() {
      return DragAndDropModifierOnDragListener.c(this.b).hashCode();
    }
    
    public e i() {
      return DragAndDropModifierOnDragListener.c(this.b);
    }
    
    public void k(e param1e) {}
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compos\\ui\platform\DragAndDropModifierOnDragListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */