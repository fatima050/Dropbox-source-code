package androidx.compose.ui.platform;

import android.view.View;
import androidx.lifecycle.LifecycleOwner;
import dbxyzptlk.DI.K;
import dbxyzptlk.DI.u;
import dbxyzptlk.U2.A;
import dbxyzptlk.g1.H1;
import dbxyzptlk.g1.J1;
import dbxyzptlk.pI.D;
import kotlin.Metadata;

@Metadata(d1 = {"\000\032\n\002\030\002\n\002\020\000\n\002\030\002\n\000\n\002\030\002\n\002\030\002\n\002\b\006\bf\030\000 \0062\0020\001:\004\006\b\t\nJ\035\020\006\032\b\022\004\022\0020\0050\0042\006\020\003\032\0020\002H&¢\006\004\b\006\020\007ø\001\000\002\006\n\004\b!0\001¨\006\013À\006\001"}, d2 = {"Landroidx/compose/ui/platform/j;", "", "Landroidx/compose/ui/platform/AbstractComposeView;", "view", "Lkotlin/Function0;", "Ldbxyzptlk/pI/D;", "a", "(Landroidx/compose/ui/platform/AbstractComposeView;)Ldbxyzptlk/CI/a;", "b", "c", "d", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public interface j {
  public static final a a = a.a;
  
  dbxyzptlk.CI.a<D> a(AbstractComposeView paramAbstractComposeView);
  
  @Metadata(d1 = {"\000\024\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\b\004\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003R\021\020\007\032\0020\0048F¢\006\006\032\004\b\005\020\006¨\006\b"}, d2 = {"Landroidx/compose/ui/platform/j$a;", "", "<init>", "()V", "Landroidx/compose/ui/platform/j;", "a", "()Landroidx/compose/ui/platform/j;", "Default", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class a {
    public static final a a = new a();
    
    public final j a() {
      return j.b.b;
    }
  }
  
  @Metadata(d1 = {"\000\036\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\030\002\n\002\b\003\bÇ\002\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\035\020\b\032\b\022\004\022\0020\0070\0062\006\020\005\032\0020\004H\026¢\006\004\b\b\020\t¨\006\n"}, d2 = {"Landroidx/compose/ui/platform/j$b;", "Landroidx/compose/ui/platform/j;", "<init>", "()V", "Landroidx/compose/ui/platform/AbstractComposeView;", "view", "Lkotlin/Function0;", "Ldbxyzptlk/pI/D;", "a", "(Landroidx/compose/ui/platform/AbstractComposeView;)Ldbxyzptlk/CI/a;", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class b implements j {
    public static final b b = new b();
    
    public static final void c(AbstractComposeView param1AbstractComposeView) {
      param1AbstractComposeView.e();
    }
    
    public dbxyzptlk.CI.a<D> a(AbstractComposeView param1AbstractComposeView) {
      b b1 = new b(param1AbstractComposeView);
      param1AbstractComposeView.addOnAttachStateChangeListener(b1);
      H1 h1 = new H1(param1AbstractComposeView);
      dbxyzptlk.p2.a.a((View)param1AbstractComposeView, (dbxyzptlk.p2.b)h1);
      return new a(param1AbstractComposeView, b1, (dbxyzptlk.p2.b)h1);
    }
    
    @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"Ldbxyzptlk/pI/D;", "b", "()V"}, k = 3, mv = {1, 8, 0})
    public static final class a extends u implements dbxyzptlk.CI.a<D> {
      public final AbstractComposeView f;
      
      public final j.b.b g;
      
      public final dbxyzptlk.p2.b h;
      
      public a(AbstractComposeView param2AbstractComposeView, j.b.b param2b, dbxyzptlk.p2.b param2b1) {
        super(0);
      }
      
      public final void b() {
        this.f.removeOnAttachStateChangeListener(this.g);
        dbxyzptlk.p2.a.g((View)this.f, this.h);
      }
    }
    
    @Metadata(d1 = {"\000\027\n\000\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\004*\001\000\b\n\030\0002\0020\001J\027\020\005\032\0020\0042\006\020\003\032\0020\002H\026¢\006\004\b\005\020\006J\027\020\007\032\0020\0042\006\020\003\032\0020\002H\026¢\006\004\b\007\020\006¨\006\b"}, d2 = {"androidx/compose/ui/platform/j$b$b", "Landroid/view/View$OnAttachStateChangeListener;", "Landroid/view/View;", "v", "Ldbxyzptlk/pI/D;", "onViewAttachedToWindow", "(Landroid/view/View;)V", "onViewDetachedFromWindow", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
    public static final class b implements View.OnAttachStateChangeListener {
      public final AbstractComposeView a;
      
      public b(AbstractComposeView param2AbstractComposeView) {}
      
      public void onViewAttachedToWindow(View param2View) {}
      
      public void onViewDetachedFromWindow(View param2View) {
        if (!dbxyzptlk.p2.a.f((View)this.a))
          this.a.e(); 
      }
    }
  }
  
  @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"Ldbxyzptlk/pI/D;", "b", "()V"}, k = 3, mv = {1, 8, 0})
  public static final class a extends u implements dbxyzptlk.CI.a<D> {
    public final AbstractComposeView f;
    
    public final j.b.b g;
    
    public final dbxyzptlk.p2.b h;
    
    public a(AbstractComposeView param1AbstractComposeView, j.b.b param1b, dbxyzptlk.p2.b param1b1) {
      super(0);
    }
    
    public final void b() {
      this.f.removeOnAttachStateChangeListener(this.g);
      dbxyzptlk.p2.a.g((View)this.f, this.h);
    }
  }
  
  @Metadata(d1 = {"\000\027\n\000\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\004*\001\000\b\n\030\0002\0020\001J\027\020\005\032\0020\0042\006\020\003\032\0020\002H\026¢\006\004\b\005\020\006J\027\020\007\032\0020\0042\006\020\003\032\0020\002H\026¢\006\004\b\007\020\006¨\006\b"}, d2 = {"androidx/compose/ui/platform/j$b$b", "Landroid/view/View$OnAttachStateChangeListener;", "Landroid/view/View;", "v", "Ldbxyzptlk/pI/D;", "onViewAttachedToWindow", "(Landroid/view/View;)V", "onViewDetachedFromWindow", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class b implements View.OnAttachStateChangeListener {
    public final AbstractComposeView a;
    
    public b(AbstractComposeView param1AbstractComposeView) {}
    
    public void onViewAttachedToWindow(View param1View) {}
    
    public void onViewDetachedFromWindow(View param1View) {
      if (!dbxyzptlk.p2.a.f((View)this.a))
        this.a.e(); 
    }
  }
  
  class j {}
  
  @Metadata(d1 = {"\000\036\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\030\002\n\002\b\003\bÇ\002\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\035\020\b\032\b\022\004\022\0020\0070\0062\006\020\005\032\0020\004H\026¢\006\004\b\b\020\t¨\006\n"}, d2 = {"Landroidx/compose/ui/platform/j$d;", "Landroidx/compose/ui/platform/j;", "<init>", "()V", "Landroidx/compose/ui/platform/AbstractComposeView;", "view", "Lkotlin/Function0;", "Ldbxyzptlk/pI/D;", "a", "(Landroidx/compose/ui/platform/AbstractComposeView;)Ldbxyzptlk/CI/a;", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class d implements j {
    public static final d b = new d();
    
    public dbxyzptlk.CI.a<D> a(AbstractComposeView param1AbstractComposeView) {
      if (param1AbstractComposeView.isAttachedToWindow()) {
        LifecycleOwner lifecycleOwner = A.a((View)param1AbstractComposeView);
        if (lifecycleOwner != null)
          return J1.b(param1AbstractComposeView, lifecycleOwner.getLifecycle()); 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("View tree for ");
        stringBuilder.append(param1AbstractComposeView);
        stringBuilder.append(" has no ViewTreeLifecycleOwner");
        throw new IllegalStateException(stringBuilder.toString().toString());
      } 
      K<dbxyzptlk.CI.a<D>> k = new K();
      c c = new c(param1AbstractComposeView, k);
      param1AbstractComposeView.addOnAttachStateChangeListener(c);
      k.a = new a(param1AbstractComposeView, c);
      return new b(k);
    }
    
    @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"Ldbxyzptlk/pI/D;", "b", "()V"}, k = 3, mv = {1, 8, 0})
    public static final class a extends u implements dbxyzptlk.CI.a<D> {
      public final AbstractComposeView f;
      
      public final j.d.c g;
      
      public a(AbstractComposeView param2AbstractComposeView, j.d.c param2c) {
        super(0);
      }
      
      public final void b() {
        this.f.removeOnAttachStateChangeListener(this.g);
      }
    }
    
    @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"Ldbxyzptlk/pI/D;", "b", "()V"}, k = 3, mv = {1, 8, 0})
    public static final class b extends u implements dbxyzptlk.CI.a<D> {
      public final K<dbxyzptlk.CI.a<D>> f;
      
      public b(K<dbxyzptlk.CI.a<D>> param2K) {
        super(0);
      }
      
      public final void b() {
        ((dbxyzptlk.CI.a)this.f.a).invoke();
      }
    }
    
    @Metadata(d1 = {"\000\027\n\000\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\004*\001\000\b\n\030\0002\0020\001J\027\020\005\032\0020\0042\006\020\003\032\0020\002H\026¢\006\004\b\005\020\006J\027\020\007\032\0020\0042\006\020\003\032\0020\002H\026¢\006\004\b\007\020\006¨\006\b"}, d2 = {"androidx/compose/ui/platform/j$d$c", "Landroid/view/View$OnAttachStateChangeListener;", "Landroid/view/View;", "v", "Ldbxyzptlk/pI/D;", "onViewAttachedToWindow", "(Landroid/view/View;)V", "onViewDetachedFromWindow", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
    public static final class c implements View.OnAttachStateChangeListener {
      public final AbstractComposeView a;
      
      public final K<dbxyzptlk.CI.a<D>> b;
      
      public c(AbstractComposeView param2AbstractComposeView, K<dbxyzptlk.CI.a<D>> param2K) {}
      
      public void onViewAttachedToWindow(View param2View) {
        LifecycleOwner lifecycleOwner = A.a((View)this.a);
        AbstractComposeView abstractComposeView = this.a;
        if (lifecycleOwner != null) {
          this.b.a = J1.b(abstractComposeView, lifecycleOwner.getLifecycle());
          this.a.removeOnAttachStateChangeListener(this);
          return;
        } 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("View tree for ");
        stringBuilder.append(abstractComposeView);
        stringBuilder.append(" has no ViewTreeLifecycleOwner");
        throw new IllegalStateException(stringBuilder.toString().toString());
      }
      
      public void onViewDetachedFromWindow(View param2View) {}
    }
  }
  
  @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"Ldbxyzptlk/pI/D;", "b", "()V"}, k = 3, mv = {1, 8, 0})
  public static final class a extends u implements dbxyzptlk.CI.a<D> {
    public final AbstractComposeView f;
    
    public final j.d.c g;
    
    public a(AbstractComposeView param1AbstractComposeView, j.d.c param1c) {
      super(0);
    }
    
    public final void b() {
      this.f.removeOnAttachStateChangeListener(this.g);
    }
  }
  
  @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"Ldbxyzptlk/pI/D;", "b", "()V"}, k = 3, mv = {1, 8, 0})
  public static final class b extends u implements dbxyzptlk.CI.a<D> {
    public final K<dbxyzptlk.CI.a<D>> f;
    
    public b(K<dbxyzptlk.CI.a<D>> param1K) {
      super(0);
    }
    
    public final void b() {
      ((dbxyzptlk.CI.a)this.f.a).invoke();
    }
  }
  
  @Metadata(d1 = {"\000\027\n\000\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\004*\001\000\b\n\030\0002\0020\001J\027\020\005\032\0020\0042\006\020\003\032\0020\002H\026¢\006\004\b\005\020\006J\027\020\007\032\0020\0042\006\020\003\032\0020\002H\026¢\006\004\b\007\020\006¨\006\b"}, d2 = {"androidx/compose/ui/platform/j$d$c", "Landroid/view/View$OnAttachStateChangeListener;", "Landroid/view/View;", "v", "Ldbxyzptlk/pI/D;", "onViewAttachedToWindow", "(Landroid/view/View;)V", "onViewDetachedFromWindow", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class c implements View.OnAttachStateChangeListener {
    public final AbstractComposeView a;
    
    public final K<dbxyzptlk.CI.a<D>> b;
    
    public c(AbstractComposeView param1AbstractComposeView, K<dbxyzptlk.CI.a<D>> param1K) {}
    
    public void onViewAttachedToWindow(View param1View) {
      LifecycleOwner lifecycleOwner = A.a((View)this.a);
      AbstractComposeView abstractComposeView = this.a;
      if (lifecycleOwner != null) {
        this.b.a = J1.b(abstractComposeView, lifecycleOwner.getLifecycle());
        this.a.removeOnAttachStateChangeListener(this);
        return;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("View tree for ");
      stringBuilder.append(abstractComposeView);
      stringBuilder.append(" has no ViewTreeLifecycleOwner");
      throw new IllegalStateException(stringBuilder.toString().toString());
    }
    
    public void onViewDetachedFromWindow(View param1View) {}
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compos\\ui\platform\j.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */