package androidx.compose.ui.platform;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.os.Trace;
import android.util.Log;
import android.util.LongSparseArray;
import android.util.SparseArray;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewStructure;
import android.view.ViewTreeObserver;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.animation.AnimationUtils;
import android.view.autofill.AutofillValue;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.translation.ViewTranslationCallback;
import android.view.translation.ViewTranslationRequest;
import android.view.translation.ViewTranslationResponse;
import androidx.compose.ui.focus.FocusOwnerImpl;
import androidx.compose.ui.node.Owner;
import androidx.compose.ui.semantics.EmptySemanticsElement;
import androidx.compose.ui.viewinterop.AndroidViewHolder;
import androidx.lifecycle.DefaultLifecycleObserver;
import androidx.lifecycle.LifecycleOwner;
import dbxyzptlk.CI.l;
import dbxyzptlk.DI.s;
import dbxyzptlk.DI.u;
import dbxyzptlk.J4.e;
import dbxyzptlk.O0.j;
import dbxyzptlk.O0.u;
import dbxyzptlk.P0.l;
import dbxyzptlk.Q0.G;
import dbxyzptlk.Q0.H0;
import dbxyzptlk.Q0.j0;
import dbxyzptlk.Q0.k0;
import dbxyzptlk.U2.A;
import dbxyzptlk.a1.C;
import dbxyzptlk.a1.E;
import dbxyzptlk.a1.N;
import dbxyzptlk.a1.P;
import dbxyzptlk.a1.Q;
import dbxyzptlk.a1.v;
import dbxyzptlk.a1.x;
import dbxyzptlk.d1.G;
import dbxyzptlk.d1.Y;
import dbxyzptlk.d1.Z;
import dbxyzptlk.d1.c0;
import dbxyzptlk.f1.B;
import dbxyzptlk.f1.S;
import dbxyzptlk.f1.U;
import dbxyzptlk.f1.Z;
import dbxyzptlk.g1.B1;
import dbxyzptlk.g1.G;
import dbxyzptlk.g1.H;
import dbxyzptlk.g1.K;
import dbxyzptlk.g1.K1;
import dbxyzptlk.g1.L;
import dbxyzptlk.g1.M;
import dbxyzptlk.g1.N;
import dbxyzptlk.g1.O;
import dbxyzptlk.g1.P;
import dbxyzptlk.g1.Q;
import dbxyzptlk.g1.S1;
import dbxyzptlk.g1.T1;
import dbxyzptlk.g1.U1;
import dbxyzptlk.g1.V;
import dbxyzptlk.g1.X;
import dbxyzptlk.g1.Y;
import dbxyzptlk.g1.a0;
import dbxyzptlk.g1.b0;
import dbxyzptlk.g1.e;
import dbxyzptlk.g1.f0;
import dbxyzptlk.g1.j;
import dbxyzptlk.g1.l;
import dbxyzptlk.g1.t0;
import dbxyzptlk.g1.t1;
import dbxyzptlk.g1.z1;
import dbxyzptlk.h2.h0;
import dbxyzptlk.h2.l0;
import dbxyzptlk.l1.r;
import dbxyzptlk.pI.D;
import dbxyzptlk.pI.y;
import dbxyzptlk.s1.l;
import dbxyzptlk.t1.K;
import dbxyzptlk.t1.S;
import dbxyzptlk.t1.U;
import dbxyzptlk.x0.X0;
import dbxyzptlk.x0.h1;
import dbxyzptlk.x0.k0;
import dbxyzptlk.z1.t;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Consumer;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

@Metadata(d1 = {"\000Ü\005\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\020\013\n\002\b\005\n\002\020\b\n\000\n\002\030\002\n\000\n\002\020\016\n\002\b\003\n\002\030\002\n\002\b\007\n\002\030\002\n\002\b\n\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\b\n\002\020\t\n\002\b\016\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\013\n\002\030\002\n\002\b\007\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\006\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\031\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\007\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\006\n\002\030\002\n\002\b\b\n\002\030\002\n\002\b\004\n\002\030\002\n\002\030\002\n\002\b\003\n\002\020\026\n\000\n\002\020\025\n\000\n\002\030\002\n\002\030\002\n\002\b\003\n\002\030\002\n\002\030\002\n\002\b\b\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\006\n\002\030\002\n\000\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\020\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\007\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\004\n\002\020!\n\002\b\005\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\b\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\n\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\b\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b$\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\004\n\002\030\002\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\006\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\007\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\b\004\n\002\030\002\n\002\b\b\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\t\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\t\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\005*\002è\003\b\000\030\000 \0042\0020\0012\0020\0022\0020\0032\0020\0042\0020\005:\004()\001B\027\022\006\020\007\032\0020\006\022\006\020\t\032\0020\b¢\006\004\b\n\020\013J6\020\025\032\0020\0242\006\020\r\032\0020\f2\006\020\017\032\0020\0162\022\020\023\032\016\022\004\022\0020\021\022\004\022\0020\0220\020H\002ø\001\000¢\006\004\b\025\020\026J\027\020\030\032\0020\0222\006\020\027\032\0020\001H\002¢\006\004\b\030\020\031J'\020 \032\0020\0222\006\020\033\032\0020\0322\006\020\035\032\0020\0342\006\020\037\032\0020\036H\002¢\006\004\b \020!J\033\020$\032\0020\0222\n\b\002\020#\032\004\030\0010\"H\002¢\006\004\b$\020%J\023\020&\032\0020\024*\0020\"H\002¢\006\004\b&\020'J%\020+\032\0020*2\006\020(\032\0020\0322\006\020)\032\0020\032H\002ø\001\001ø\001\000¢\006\004\b+\020,J\035\020.\032\0020*2\006\020-\032\0020\032H\002ø\001\001ø\001\000¢\006\004\b.\020/J\017\0200\032\0020\022H\002¢\006\004\b0\0201J\027\0203\032\0020\0222\006\0202\032\0020\"H\002¢\006\004\b3\020%J\027\0204\032\0020\0222\006\0202\032\0020\"H\002¢\006\004\b4\020%J\027\0207\032\0020\0242\006\0206\032\00205H\002¢\006\004\b7\0208J\035\020;\032\0020:2\006\0209\032\00205H\002ø\001\001ø\001\000¢\006\004\b;\020<J\037\020>\032\0020\0242\006\0206\032\002052\006\020=\032\00205H\002¢\006\004\b>\020?J\027\020@\032\0020\0242\006\0206\032\00205H\002¢\006\004\b@\0208J\035\020A\032\0020:2\006\0209\032\00205H\002ø\001\001ø\001\000¢\006\004\bA\020<J1\020F\032\0020\0222\006\0209\032\002052\006\020B\032\0020\0322\006\020D\032\0020C2\b\b\002\020E\032\0020\024H\002¢\006\004\bF\020GJ\027\020H\032\0020\0242\006\0209\032\00205H\002¢\006\004\bH\0208J\017\020I\032\0020\022H\002¢\006\004\bI\0201J\027\020J\032\0020\0222\006\0209\032\00205H\002¢\006\004\bJ\020KJ\017\020L\032\0020\022H\002¢\006\004\bL\0201J\017\020M\032\0020\024H\002¢\006\004\bM\020NJ\027\020O\032\0020\0242\006\0206\032\00205H\002¢\006\004\bO\0208J\027\020P\032\0020\0242\006\0206\032\00205H\002¢\006\004\bP\0208J!\020T\032\004\030\0010R2\006\020Q\032\0020\0322\006\020S\032\0020RH\002¢\006\004\bT\020UJ\027\020X\032\0020\0222\006\020W\032\0020VH\026¢\006\004\bX\020YJ\027\020\\\032\0020\0222\006\020[\032\0020ZH\026¢\006\004\b\\\020]J)\020a\032\0020\0222\006\020^\032\0020\0242\006\020_\032\0020\0322\b\020`\032\004\030\0010VH\024¢\006\004\ba\020bJ\027\020d\032\0020\0222\006\020c\032\0020\024H\026¢\006\004\bd\020eJ\027\020g\032\0020\0242\006\0206\032\0020fH\026¢\006\004\bg\020hJ\027\020i\032\0020\0242\006\0206\032\0020fH\026¢\006\004\bi\020hJ\027\020j\032\0020\0222\006\0202\032\0020\"H\026¢\006\004\bj\020%J\027\020k\032\0020\0222\006\0202\032\0020\"H\026¢\006\004\bk\020%J\r\020l\032\0020\022¢\006\004\bl\0201J\017\020m\032\0020\022H\026¢\006\004\bm\0201J\035\020p\032\0020\0222\f\020o\032\b\022\004\022\0020\0220nH\026¢\006\004\bp\020qJ\035\020u\032\0020\0222\006\020s\032\0020r2\006\020t\032\0020\"¢\006\004\bu\020vJ\025\020w\032\0020\0222\006\020s\032\0020r¢\006\004\bw\020xJ\035\020{\032\0020\0222\006\020s\032\0020r2\006\020z\032\0020y¢\006\004\b{\020|J\027\020(\032\0020\0222\006\020}\032\0020\024H\026¢\006\004\b(\020eJ%\020\001\032\0020\0222\006\020t\032\0020\"2\006\020\032\0020~H\026ø\001\000¢\006\006\b\001\020\001J#\020\001\032\0020\0222\006\020t\032\0020\"2\007\020\001\032\0020\024H\026¢\006\006\b\001\020\001J5\020\001\032\0020\0222\006\020t\032\0020\"2\007\020\001\032\0020\0242\007\020\001\032\0020\0242\007\020\001\032\0020\024H\026¢\006\006\b\001\020\001J,\020\001\032\0020\0222\006\020t\032\0020\"2\007\020\001\032\0020\0242\007\020\001\032\0020\024H\026¢\006\006\b\001\020\001J\031\020\001\032\0020\0222\006\020t\032\0020\"H\026¢\006\005\b\001\020%J$\020\001\032\0020\0222\007\020\001\032\0020\0322\007\020\001\032\0020\032H\024¢\006\006\b\001\020\001J>\020\001\032\0020\0222\007\020\001\032\0020\0242\007\020\001\032\0020\0322\007\020\001\032\0020\0322\007\020\001\032\0020\0322\006\020)\032\0020\032H\024¢\006\006\b\001\020\001J\032\020\001\032\0020\0222\006\020z\032\0020yH\024¢\006\006\b\001\020\001J8\020\001\032\0030\0012\024\020\001\032\017\022\005\022\0030\001\022\004\022\0020\0220\0202\r\020\001\032\b\022\004\022\0020\0220nH\026¢\006\006\b\001\020\001J\034\020\001\032\0020\0242\b\020\001\032\0030\001H\000¢\006\006\b\001\020 \001J\021\020¡\001\032\0020\022H\026¢\006\005\b¡\001\0201J\031\020¢\001\032\0020\0222\006\020t\032\0020\"H\026¢\006\005\b¢\001\020%J\033\020¤\001\032\0020\0222\007\020o\032\0030£\001H\026¢\006\006\b¤\001\020¥\001J\"\020©\001\032\005\030\0010¨\0012\b\020§\001\032\0030¦\001H\026ø\001\000¢\006\006\b©\001\020ª\001J\032\020«\001\032\0020\0222\006\020z\032\0020yH\024¢\006\006\b«\001\020\001J%\020­\001\032\0020\0222\b\020\001\032\0030\0012\007\020¬\001\032\0020\024H\000¢\006\006\b­\001\020®\001J&\020±\001\032\0020\0222\024\020°\001\032\017\022\005\022\0030¯\001\022\004\022\0020\0220\020¢\006\006\b±\001\020²\001J\023\020³\001\032\0020\022H@¢\006\006\b³\001\020´\001J\021\020µ\001\032\0020\022H\026¢\006\005\bµ\001\0201J\021\020¶\001\032\0020\022H\024¢\006\005\b¶\001\0201J\021\020·\001\032\0020\022H\024¢\006\005\b·\001\0201J'\020»\001\032\0020\0222\n\020¹\001\032\005\030\0010¸\0012\007\020º\001\032\0020\032H\026¢\006\006\b»\001\020¼\001J#\020À\001\032\0020\0222\017\020¿\001\032\n\022\005\022\0030¾\0010½\001H\026¢\006\006\bÀ\001\020Á\001J9\020É\001\032\0020\0222\b\020Ã\001\032\0030Â\0012\b\020Å\001\032\0030Ä\0012\021\020È\001\032\f\022\007\022\005\030\0010Ç\0010Æ\001H\027¢\006\006\bÉ\001\020Ê\001J%\020Î\001\032\0020\0222\021\020Í\001\032\f\022\007\022\005\030\0010Ì\0010Ë\001H\027¢\006\006\bÎ\001\020Ï\001J\031\020Ð\001\032\0020\0242\006\0206\032\00205H\026¢\006\005\bÐ\001\0208J\031\020Ñ\001\032\0020\0242\006\0209\032\00205H\026¢\006\005\bÑ\001\0208J\032\020Ò\001\032\0020\0242\006\020_\032\0020\032H\026¢\006\006\bÒ\001\020Ó\001J\032\020Ô\001\032\0020\0242\006\020_\032\0020\032H\026¢\006\006\bÔ\001\020Ó\001J \020×\001\032\0030Õ\0012\b\020Ö\001\032\0030Õ\001H\026ø\001\000¢\006\006\b×\001\020Ø\001J\037\020Û\001\032\0020\0222\b\020Ú\001\032\0030Ù\001H\026ø\001\000¢\006\006\bÛ\001\020Ü\001J \020Þ\001\032\0030Õ\0012\b\020Ý\001\032\0030Õ\001H\026ø\001\000¢\006\006\bÞ\001\020Ø\001J\021\020ß\001\032\0020\024H\026¢\006\005\bß\001\020NJ\037\020ã\001\032\005\030\0010â\0012\b\020á\001\032\0030à\001H\026¢\006\006\bã\001\020ä\001J \020æ\001\032\0030Õ\0012\b\020å\001\032\0030Õ\001H\026ø\001\000¢\006\006\bæ\001\020Ø\001J \020\001\032\0030Õ\0012\b\020Ö\001\032\0030Õ\001H\026ø\001\000¢\006\006\b\001\020Ø\001J\034\020é\001\032\0020\0222\b\020è\001\032\0030ç\001H\024¢\006\006\bé\001\020ê\001J\033\020ì\001\032\0020\0222\007\020ë\001\032\0020\032H\026¢\006\006\bì\001\020í\001J\031\020î\001\032\0020\0242\006\0206\032\00205H\026¢\006\005\bî\001\0208J\032\020ï\001\032\004\030\0010R2\006\020Q\032\0020\032¢\006\006\bï\001\020ð\001J\021\020ñ\001\032\0020\024H\026¢\006\005\bñ\001\020NR\035\020\t\032\0020\b8\026X\004¢\006\017\n\005\b(\020ò\001\032\006\bó\001\020ô\001R\037\020ö\001\032\0030Õ\0018\002@\002X\016ø\001\000ø\001\001¢\006\007\n\005\b)\020õ\001R\030\020÷\001\032\0020\0248\002@\002X\016¢\006\007\n\005\b\001\020\030R \020ý\001\032\0030ø\0018\026X\004¢\006\020\n\006\bù\001\020ú\001\032\006\bû\001\020ü\001R,\020\002\032\0030þ\0012\b\020ÿ\001\032\0030þ\0018\026@RX\016¢\006\020\n\006\bÛ\001\020\002\032\006\b\002\020\002R\030\020\002\032\0030\0028\002X\004¢\006\b\n\006\b\002\020\002R \020\002\032\0030\0028\026X\004¢\006\020\n\006\b¤\001\020\002\032\006\b\002\020\002R\027\020\002\032\0030\0028\002X\004¢\006\007\n\005\bp\020\002R \020\002\032\0030\0028\026X\004¢\006\020\n\006\b\001\020\002\032\006\b\002\020\002R\030\020\002\032\0030\0028\002X\004¢\006\b\n\006\bÞ\001\020\002R\030\020\002\032\0030\0028\002X\004¢\006\b\n\006\b\001\020\002R\030\020\002\032\0030\0028\002X\004¢\006\b\n\006\b\001\020\002R\030\020\002\032\0030\0028\002X\004¢\006\b\n\006\bæ\001\020\002R\037\020£\002\032\0020\"8\026X\004¢\006\020\n\006\b\002\020 \002\032\006\b¡\002\020¢\002R \020¨\002\032\0030¤\0028\026X\004¢\006\020\n\006\b\001\020¥\002\032\006\b¦\002\020§\002R\037\020­\002\032\0030©\0028\026X\004¢\006\017\n\005\bm\020ª\002\032\006\b«\002\020¬\002R\030\020°\002\032\0030®\0028\002X\004¢\006\b\n\006\b\001\020¯\002R \020µ\002\032\0030±\0028\026X\004¢\006\020\n\006\b\001\020²\002\032\006\b³\002\020´\002R\037\020¹\002\032\n\022\005\022\0030\0010¶\0028\002X\004¢\006\b\n\006\b·\002\020¸\002R#\020º\002\032\f\022\005\022\0030\001\030\0010¶\0028\002@\002X\016¢\006\b\n\006\b\001\020¸\002R\030\020»\002\032\0020\0248\002@\002X\016¢\006\007\n\005\b¢\001\020\030R\030\020¾\002\032\0030¼\0028\002X\004¢\006\b\n\006\b\001\020½\002R\027\020Á\002\032\0030¿\0028\002X\004¢\006\007\n\005\bj\020À\002R6\020Ç\002\032\017\022\005\022\0030ç\001\022\004\022\0020\0220\0208\006@\006X\016¢\006\030\n\006\bÂ\002\020Ã\002\032\006\bÄ\002\020Å\002\"\006\bÆ\002\020²\001R\032\020Ë\002\032\005\030\0010È\0028\002X\004¢\006\b\n\006\bÉ\002\020Ê\002R\027\020Ì\002\032\0020\0248\002@\002X\016¢\006\006\n\004\bk\020\030R \020Ñ\002\032\0030Í\0028\026X\004¢\006\020\n\006\b×\001\020Î\002\032\006\bÏ\002\020Ð\002R \020Ö\002\032\0030Ò\0028\026X\004¢\006\020\n\006\b¡\001\020Ó\002\032\006\bÔ\002\020Õ\002R \020Ü\002\032\0030×\0028\026X\004¢\006\020\n\006\bØ\002\020Ù\002\032\006\bÚ\002\020Û\002R-\020á\002\032\0020\0248\026@\026X\016¢\006\034\n\005\bÝ\002\020\030\022\005\bà\002\0201\032\005\bÞ\002\020N\"\005\bß\002\020eR\034\020å\002\032\005\030\0010â\0028\002@\002X\016¢\006\b\n\006\bã\002\020ä\002R\034\020é\002\032\005\030\0010æ\0028\002@\002X\016¢\006\b\n\006\bç\002\020è\002R!\020ì\002\032\004\030\0010~8\002@\002X\016ø\001\000ø\001\001¢\006\b\n\006\bê\002\020ë\002R\030\020î\002\032\0020\0248\002@\002X\016¢\006\007\n\005\bí\002\020\030R\030\020ò\002\032\0030ï\0028\002X\004¢\006\b\n\006\bð\002\020ñ\002R \020÷\002\032\0030ó\0028\026X\004¢\006\020\n\006\bõ\001\020ô\002\032\006\bõ\002\020ö\002R \020ú\002\032\0030ø\0028\002@\002X\016ø\001\000ø\001\001¢\006\b\n\006\bù\002\020õ\001R\030\020ý\002\032\0030Ä\0018\002X\004¢\006\b\n\006\bû\002\020ü\002R\036\020\003\032\0030Ù\0018\002X\004ø\001\000ø\001\001¢\006\b\n\006\bþ\002\020ÿ\002R\036\020\003\032\0030Ù\0018\002X\004ø\001\000ø\001\001¢\006\b\n\006\b\003\020ÿ\002R\036\020\003\032\0030Ù\0018\002X\004ø\001\000ø\001\001¢\006\b\n\006\b\003\020ÿ\002R0\020\003\032\0020C8\000@\000X\016¢\006\037\n\006\b\003\020õ\001\022\005\b\003\0201\032\006\b\003\020\003\"\006\b\003\020\003R\030\020\003\032\0020\0248\002@\002X\016¢\006\007\n\005\b\003\020\030R \020\003\032\0030Õ\0018\002@\002X\016ø\001\000ø\001\001¢\006\b\n\006\b\003\020õ\001R\030\020\003\032\0020\0248\002@\002X\016¢\006\007\n\005\b\003\020\030R9\020\003\032\005\030\0010¯\0012\n\020ÿ\001\032\005\030\0010¯\0018B@BX\002¢\006\030\n\006\b\003\020\003\032\006\b\003\020\003\"\006\b\003\020\003R\"\020\003\032\005\030\0010¯\0018FX\002¢\006\017\n\005\bu\020\003\032\006\b\003\020\003R'\020\003\032\021\022\005\022\0030¯\001\022\004\022\0020\022\030\0010\0208\002@\002X\016¢\006\007\n\005\b \020Ã\002R\027\020\003\032\0030\0038\002X\004¢\006\007\n\005\bM\020\003R\027\020¢\003\032\0030 \0038\002X\004¢\006\007\n\005\b.\020¡\003R\027\020¥\003\032\0030£\0038\002X\004¢\006\007\n\005\b{\020¤\003R\027\020¨\003\032\0030¦\0038\002X\004¢\006\007\n\005\bT\020§\003R \020­\003\032\0030©\0038\026X\004¢\006\020\n\006\b©\001\020ª\003\032\006\b«\003\020¬\003R%\020²\003\032\n\022\005\022\0030¯\0030®\0038\002X\004ø\001\000ø\001\001¢\006\b\n\006\b°\003\020±\003R \020¸\003\032\0030³\0038\026X\004¢\006\020\n\006\b´\003\020µ\003\032\006\b¶\003\020·\003R&\020¾\003\032\0030¹\0038\026X\004¢\006\026\n\005\b;\020º\003\022\005\b½\003\0201\032\006\b»\003\020¼\003R4\020Ä\003\032\0030¿\0032\b\020ÿ\001\032\0030¿\0038V@RX\002¢\006\027\n\005\b7\020\003\032\006\bÀ\003\020Á\003\"\006\bÂ\003\020Ã\003R\030\020Å\003\032\0020\0328\002@\002X\016¢\006\007\n\005\b>\020ð\002R5\020ë\001\032\0030Æ\0032\b\020ÿ\001\032\0030Æ\0038V@RX\002¢\006\030\n\006\bµ\001\020\003\032\006\bÇ\003\020È\003\"\006\bÉ\003\020Ê\003R\037\020Ï\003\032\0030Ë\0038\026X\004¢\006\017\n\005\b4\020Ì\003\032\006\bÍ\003\020Î\003R\027\020Ò\003\032\0030Ð\0038\002X\004¢\006\007\n\005\b3\020Ñ\003R\037\020×\003\032\0030Ó\0038\026X\004¢\006\017\n\005\bO\020Ô\003\032\006\bÕ\003\020Ö\003R\037\020Ü\003\032\0030Ø\0038\026X\004¢\006\017\n\005\b@\020Ù\003\032\006\bÚ\003\020Û\003R\032\020Þ\003\032\004\030\001058\002@\002X\016¢\006\007\n\005\bH\020Ý\003R\030\020ß\003\032\0020C8\002@\002X\016¢\006\007\n\005\bP\020õ\001R\037\020ã\003\032\n\022\005\022\0030\0010à\0038\002X\004¢\006\b\n\006\bá\003\020â\003R&\020ç\003\032\021\022\f\022\n\022\004\022\0020\022\030\0010n0ä\0038\002X\004¢\006\b\n\006\bå\003\020æ\003R\030\020ë\003\032\0030è\0038\002X\004¢\006\b\n\006\bé\003\020ê\003R\030\020ï\003\032\0030ì\0038\002X\004¢\006\b\n\006\bí\003\020î\003R\030\020ñ\003\032\0020\0248\002@\002X\016¢\006\007\n\005\bð\003\020\030R\035\020ô\003\032\b\022\004\022\0020\0220n8\002X\004¢\006\b\n\006\bò\003\020ó\003R\030\020ø\003\032\0030õ\0038\002X\004¢\006\b\n\006\bö\003\020÷\003R\030\020ú\003\032\0020\0248\002@\002X\016¢\006\007\n\005\bù\003\020\030R \020\004\032\0030û\0038\026X\004¢\006\020\n\006\bü\003\020ý\003\032\006\bþ\003\020ÿ\003R\034\020\004\032\0020\032*\0030ç\0018BX\004¢\006\b\032\006\b°\003\020\004R\026\020s\032\0020R8VX\004¢\006\b\032\006\b\004\020\004R\030\020\004\032\0030\0048VX\004¢\006\b\032\006\b\004\020\004R\032\020À\001\032\005\030\0010\0048VX\004¢\006\b\032\006\b\004\020\004R\030\020\004\032\0030â\0028@X\004¢\006\b\032\006\b\004\020\004R\027\020\004\032\0020C8VX\004¢\006\b\032\006\b\004\020\003R\026\020\004\032\0020\0248VX\004¢\006\007\032\005\b\004\020NR\030\020\004\032\0030\0048VX\004¢\006\b\032\006\b\004\020\004R\030\020\004\032\0030\0048VX\004¢\006\b\032\006\b\004\020\004\002\013\n\005\b¡\0360\001\n\002\b!¨\006\004"}, d2 = {"Landroidx/compose/ui/platform/AndroidComposeView;", "Landroid/view/ViewGroup;", "Landroidx/compose/ui/node/Owner;", "Landroidx/compose/ui/platform/k;", "Ldbxyzptlk/a1/P;", "Landroidx/lifecycle/DefaultLifecycleObserver;", "Landroid/content/Context;", "context", "Ldbxyzptlk/tI/g;", "coroutineContext", "<init>", "(Landroid/content/Context;Ldbxyzptlk/tI/g;)V", "Ldbxyzptlk/M0/h;", "transferData", "Ldbxyzptlk/P0/l;", "decorationSize", "Lkotlin/Function1;", "Ldbxyzptlk/S0/f;", "Ldbxyzptlk/pI/D;", "drawDragDecoration", "", "F0", "(Ldbxyzptlk/M0/h;JLdbxyzptlk/CI/l;)Z", "viewGroup", "Z", "(Landroid/view/ViewGroup;)V", "", "virtualViewId", "Landroid/view/accessibility/AccessibilityNodeInfo;", "info", "", "extraDataKey", "V", "(ILandroid/view/accessibility/AccessibilityNodeInfo;Ljava/lang/String;)V", "Landroidx/compose/ui/node/f;", "nodeToRemeasure", "y0", "(Landroidx/compose/ui/node/f;)V", "Y", "(Landroidx/compose/ui/node/f;)Z", "a", "b", "Ldbxyzptlk/pI/y;", "r0", "(II)J", "measureSpec", "a0", "(I)J", "H0", "()V", "node", "l0", "k0", "Landroid/view/MotionEvent;", "event", "h0", "(Landroid/view/MotionEvent;)Z", "motionEvent", "Ldbxyzptlk/a1/Q;", "g0", "(Landroid/view/MotionEvent;)I", "lastEvent", "i0", "(Landroid/view/MotionEvent;Landroid/view/MotionEvent;)Z", "n0", "C0", "action", "", "eventTime", "forceHover", "D0", "(Landroid/view/MotionEvent;IJZ)V", "o0", "s0", "t0", "(Landroid/view/MotionEvent;)V", "u0", "W", "()Z", "m0", "p0", "accessibilityId", "Landroid/view/View;", "currentView", "c0", "(ILandroid/view/View;)Landroid/view/View;", "Landroid/graphics/Rect;", "rect", "getFocusedRect", "(Landroid/graphics/Rect;)V", "Landroidx/lifecycle/LifecycleOwner;", "owner", "onResume", "(Landroidx/lifecycle/LifecycleOwner;)V", "gainFocus", "direction", "previouslyFocusedRect", "onFocusChanged", "(ZILandroid/graphics/Rect;)V", "hasWindowFocus", "onWindowFocusChanged", "(Z)V", "Landroid/view/KeyEvent;", "dispatchKeyEvent", "(Landroid/view/KeyEvent;)Z", "dispatchKeyEventPreIme", "w", "z", "x0", "p", "Lkotlin/Function0;", "listener", "h", "(Ldbxyzptlk/CI/a;)V", "Landroidx/compose/ui/viewinterop/AndroidViewHolder;", "view", "layoutNode", "U", "(Landroidx/compose/ui/viewinterop/AndroidViewHolder;Landroidx/compose/ui/node/f;)V", "w0", "(Landroidx/compose/ui/viewinterop/AndroidViewHolder;)V", "Landroid/graphics/Canvas;", "canvas", "b0", "(Landroidx/compose/ui/viewinterop/AndroidViewHolder;Landroid/graphics/Canvas;)V", "sendPointerUpdate", "Ldbxyzptlk/z1/b;", "constraints", "k", "(Landroidx/compose/ui/node/f;J)V", "affectsLookahead", "v", "(Landroidx/compose/ui/node/f;Z)V", "forceRequest", "scheduleMeasureAndLayout", "o", "(Landroidx/compose/ui/node/f;ZZZ)V", "q", "(Landroidx/compose/ui/node/f;ZZ)V", "c", "widthMeasureSpec", "heightMeasureSpec", "onMeasure", "(II)V", "changed", "l", "t", "r", "onLayout", "(ZIIII)V", "onDraw", "(Landroid/graphics/Canvas;)V", "Ldbxyzptlk/Q0/j0;", "drawBlock", "invalidateParentLayer", "Ldbxyzptlk/f1/S;", "i", "(Ldbxyzptlk/CI/l;Ldbxyzptlk/CI/a;)Ldbxyzptlk/f1/S;", "layer", "v0", "(Ldbxyzptlk/f1/S;)Z", "B", "u", "Landroidx/compose/ui/node/Owner$b;", "g", "(Landroidx/compose/ui/node/Owner$b;)V", "Ldbxyzptlk/Y0/b;", "keyEvent", "Landroidx/compose/ui/focus/c;", "d0", "(Landroid/view/KeyEvent;)Landroidx/compose/ui/focus/c;", "dispatchDraw", "isDirty", "q0", "(Ldbxyzptlk/f1/S;Z)V", "Landroidx/compose/ui/platform/AndroidComposeView$c;", "callback", "setOnViewTreeOwnersAvailable", "(Ldbxyzptlk/CI/l;)V", "X", "(Ldbxyzptlk/tI/d;)Ljava/lang/Object;", "j0", "onAttachedToWindow", "onDetachedFromWindow", "Landroid/view/ViewStructure;", "structure", "flags", "onProvideAutofillVirtualStructure", "(Landroid/view/ViewStructure;I)V", "Landroid/util/SparseArray;", "Landroid/view/autofill/AutofillValue;", "values", "autofill", "(Landroid/util/SparseArray;)V", "", "virtualIds", "", "supportedFormats", "Ljava/util/function/Consumer;", "Landroid/view/translation/ViewTranslationRequest;", "requestsCollector", "onCreateVirtualViewTranslationRequests", "([J[ILjava/util/function/Consumer;)V", "Landroid/util/LongSparseArray;", "Landroid/view/translation/ViewTranslationResponse;", "response", "onVirtualViewTranslationResponses", "(Landroid/util/LongSparseArray;)V", "dispatchGenericMotionEvent", "dispatchTouchEvent", "canScrollHorizontally", "(I)Z", "canScrollVertically", "Ldbxyzptlk/P0/f;", "localPosition", "A", "(J)J", "Ldbxyzptlk/Q0/H0;", "localTransform", "e", "([F)V", "positionOnScreen", "j", "onCheckIsTextEditor", "Landroid/view/inputmethod/EditorInfo;", "outAttrs", "Landroid/view/inputmethod/InputConnection;", "onCreateInputConnection", "(Landroid/view/inputmethod/EditorInfo;)Landroid/view/inputmethod/InputConnection;", "positionInWindow", "m", "Landroid/content/res/Configuration;", "newConfig", "onConfigurationChanged", "(Landroid/content/res/Configuration;)V", "layoutDirection", "onRtlPropertiesChanged", "(I)V", "dispatchHoverEvent", "findViewByAccessibilityIdTraversal", "(I)Landroid/view/View;", "shouldDelayChildPressedState", "Ldbxyzptlk/tI/g;", "getCoroutineContext", "()Ldbxyzptlk/tI/g;", "J", "lastDownPointerPosition", "superclassInitComplete", "Ldbxyzptlk/f1/B;", "d", "Ldbxyzptlk/f1/B;", "getSharedDrawScope", "()Ldbxyzptlk/f1/B;", "sharedDrawScope", "Ldbxyzptlk/z1/d;", "<set-?>", "Ldbxyzptlk/z1/d;", "getDensity", "()Ldbxyzptlk/z1/d;", "density", "Landroidx/compose/ui/semantics/EmptySemanticsElement;", "f", "Landroidx/compose/ui/semantics/EmptySemanticsElement;", "semanticsModifier", "Ldbxyzptlk/O0/j;", "Ldbxyzptlk/O0/j;", "getFocusOwner", "()Ldbxyzptlk/O0/j;", "focusOwner", "Landroidx/compose/ui/platform/DragAndDropModifierOnDragListener;", "Landroidx/compose/ui/platform/DragAndDropModifierOnDragListener;", "dragAndDropModifierOnDragListener", "Ldbxyzptlk/M0/c;", "Ldbxyzptlk/M0/c;", "getDragAndDropManager", "()Ldbxyzptlk/M0/c;", "dragAndDropManager", "Ldbxyzptlk/g1/U1;", "Ldbxyzptlk/g1/U1;", "_windowInfo", "Landroidx/compose/ui/d;", "Landroidx/compose/ui/d;", "keyInputModifier", "rotaryInputModifier", "Ldbxyzptlk/Q0/k0;", "Ldbxyzptlk/Q0/k0;", "canvasHolder", "n", "Landroidx/compose/ui/node/f;", "getRoot", "()Landroidx/compose/ui/node/f;", "root", "Ldbxyzptlk/f1/Z;", "Ldbxyzptlk/f1/Z;", "getRootForTest", "()Ldbxyzptlk/f1/Z;", "rootForTest", "Ldbxyzptlk/l1/r;", "Ldbxyzptlk/l1/r;", "getSemanticsOwner", "()Ldbxyzptlk/l1/r;", "semanticsOwner", "Landroidx/compose/ui/platform/AndroidComposeViewAccessibilityDelegateCompat;", "Landroidx/compose/ui/platform/AndroidComposeViewAccessibilityDelegateCompat;", "composeAccessibilityDelegate", "Ldbxyzptlk/L0/i;", "Ldbxyzptlk/L0/i;", "getAutofillTree", "()Ldbxyzptlk/L0/i;", "autofillTree", "", "s", "Ljava/util/List;", "dirtyLayers", "postponedDirtyLayers", "isDrawingContent", "Ldbxyzptlk/a1/i;", "Ldbxyzptlk/a1/i;", "motionEventAdapter", "Ldbxyzptlk/a1/E;", "Ldbxyzptlk/a1/E;", "pointerInputEventProcessor", "x", "Ldbxyzptlk/CI/l;", "getConfigurationChangeObserver", "()Ldbxyzptlk/CI/l;", "setConfigurationChangeObserver", "configurationChangeObserver", "Ldbxyzptlk/L0/a;", "y", "Ldbxyzptlk/L0/a;", "_autofill", "observationClearRequested", "Ldbxyzptlk/g1/e;", "Ldbxyzptlk/g1/e;", "getClipboardManager", "()Ldbxyzptlk/g1/e;", "clipboardManager", "Ldbxyzptlk/g1/d;", "Ldbxyzptlk/g1/d;", "getAccessibilityManager", "()Ldbxyzptlk/g1/d;", "accessibilityManager", "Ldbxyzptlk/f1/U;", "C", "Ldbxyzptlk/f1/U;", "getSnapshotObserver", "()Ldbxyzptlk/f1/U;", "snapshotObserver", "D", "getShowLayoutBounds", "setShowLayoutBounds", "getShowLayoutBounds$annotations", "showLayoutBounds", "Landroidx/compose/ui/platform/AndroidViewsHandler;", "E", "Landroidx/compose/ui/platform/AndroidViewsHandler;", "_androidViewsHandler", "Landroidx/compose/ui/platform/DrawChildContainer;", "F", "Landroidx/compose/ui/platform/DrawChildContainer;", "viewLayersContainer", "G", "Ldbxyzptlk/z1/b;", "onMeasureConstraints", "H", "wasMeasuredWithMultipleConstraints", "Landroidx/compose/ui/node/k;", "I", "Landroidx/compose/ui/node/k;", "measureAndLayoutDelegate", "Ldbxyzptlk/g1/K1;", "Ldbxyzptlk/g1/K1;", "getViewConfiguration", "()Ldbxyzptlk/g1/K1;", "viewConfiguration", "Ldbxyzptlk/z1/n;", "K", "globalPosition", "L", "[I", "tmpPositionArray", "M", "[F", "tmpMatrix", "N", "viewToWindowMatrix", "O", "windowToViewMatrix", "P", "getLastMatrixRecalculationAnimationTime$ui_release", "()J", "setLastMatrixRecalculationAnimationTime$ui_release", "(J)V", "getLastMatrixRecalculationAnimationTime$ui_release$annotations", "lastMatrixRecalculationAnimationTime", "Q", "forceUseMatrixCache", "R", "windowPosition", "S", "isRenderNodeCompatible", "T", "Ldbxyzptlk/x0/k0;", "get_viewTreeOwners", "()Landroidx/compose/ui/platform/AndroidComposeView$c;", "set_viewTreeOwners", "(Landroidx/compose/ui/platform/AndroidComposeView$c;)V", "_viewTreeOwners", "Ldbxyzptlk/x0/h1;", "getViewTreeOwners", "viewTreeOwners", "onViewTreeOwnersAvailable", "Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;", "Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;", "globalLayoutListener", "Landroid/view/ViewTreeObserver$OnScrollChangedListener;", "Landroid/view/ViewTreeObserver$OnScrollChangedListener;", "scrollChangedListener", "Landroid/view/ViewTreeObserver$OnTouchModeChangeListener;", "Landroid/view/ViewTreeObserver$OnTouchModeChangeListener;", "touchModeChangeListener", "Ldbxyzptlk/t1/U;", "Ldbxyzptlk/t1/U;", "legacyTextInputServiceAndroid", "Ldbxyzptlk/t1/S;", "Ldbxyzptlk/t1/S;", "getTextInputService", "()Ldbxyzptlk/t1/S;", "textInputService", "Ldbxyzptlk/K0/k;", "Ldbxyzptlk/g1/P;", "e0", "Ljava/util/concurrent/atomic/AtomicReference;", "textInputSessionMutex", "Ldbxyzptlk/g1/z1;", "f0", "Ldbxyzptlk/g1/z1;", "getSoftwareKeyboardController", "()Ldbxyzptlk/g1/z1;", "softwareKeyboardController", "Ldbxyzptlk/s1/k$b;", "Ldbxyzptlk/s1/k$b;", "getFontLoader", "()Ldbxyzptlk/s1/k$b;", "getFontLoader$annotations", "fontLoader", "Ldbxyzptlk/s1/l$b;", "getFontFamilyResolver", "()Ldbxyzptlk/s1/l$b;", "setFontFamilyResolver", "(Ldbxyzptlk/s1/l$b;)V", "fontFamilyResolver", "currentFontWeightAdjustment", "Ldbxyzptlk/z1/t;", "getLayoutDirection", "()Ldbxyzptlk/z1/t;", "setLayoutDirection", "(Ldbxyzptlk/z1/t;)V", "Ldbxyzptlk/W0/a;", "Ldbxyzptlk/W0/a;", "getHapticFeedBack", "()Ldbxyzptlk/W0/a;", "hapticFeedBack", "Ldbxyzptlk/X0/c;", "Ldbxyzptlk/X0/c;", "_inputModeManager", "Ldbxyzptlk/e1/f;", "Ldbxyzptlk/e1/f;", "getModifierLocalManager", "()Ldbxyzptlk/e1/f;", "modifierLocalManager", "Ldbxyzptlk/g1/B1;", "Ldbxyzptlk/g1/B1;", "getTextToolbar", "()Ldbxyzptlk/g1/B1;", "textToolbar", "Landroid/view/MotionEvent;", "previousMotionEvent", "relayoutTime", "Ldbxyzptlk/g1/S1;", "A0", "Ldbxyzptlk/g1/S1;", "layerCache", "Ldbxyzptlk/z0/d;", "V0", "Ldbxyzptlk/z0/d;", "endApplyChangesListeners", "androidx/compose/ui/platform/AndroidComposeView$n", "x1", "Landroidx/compose/ui/platform/AndroidComposeView$n;", "resendMotionEventRunnable", "Ljava/lang/Runnable;", "y1", "Ljava/lang/Runnable;", "sendHoverExitEvent", "V1", "hoverExitReceived", "x2", "Ldbxyzptlk/CI/a;", "resendMotionEventOnLayout", "Ldbxyzptlk/g1/X;", "y2", "Ldbxyzptlk/g1/X;", "matrixToWindow", "V2", "keyboardModifiersRequireUpdate", "Ldbxyzptlk/a1/x;", "V3", "Ldbxyzptlk/a1/x;", "getPointerIconService", "()Ldbxyzptlk/a1/x;", "pointerIconService", "(Landroid/content/res/Configuration;)I", "fontWeightAdjustmentCompat", "getView", "()Landroid/view/View;", "Ldbxyzptlk/g1/T1;", "getWindowInfo", "()Ldbxyzptlk/g1/T1;", "windowInfo", "Ldbxyzptlk/L0/d;", "getAutofill", "()Ldbxyzptlk/L0/d;", "getAndroidViewsHandler$ui_release", "()Landroidx/compose/ui/platform/AndroidViewsHandler;", "androidViewsHandler", "getMeasureIteration", "measureIteration", "getHasPendingMeasureOrLayout", "hasPendingMeasureOrLayout", "Ldbxyzptlk/d1/Y$a;", "getPlacementScope", "()Ldbxyzptlk/d1/Y$a;", "placementScope", "Ldbxyzptlk/X0/b;", "getInputModeManager", "()Ldbxyzptlk/X0/b;", "inputModeManager", "A4", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class AndroidComposeView extends ViewGroup implements Owner, k, P, DefaultLifecycleObserver {
  public static final b A4 = new b(null);
  
  public static Method A5;
  
  public static final int B4 = 8;
  
  public static Class<?> V4;
  
  public final e A;
  
  public final S1<S> A0;
  
  public final dbxyzptlk.g1.d B;
  
  public final U C;
  
  public boolean D;
  
  public AndroidViewsHandler E;
  
  public DrawChildContainer F;
  
  public dbxyzptlk.z1.b G;
  
  public boolean H;
  
  public final androidx.compose.ui.node.k I;
  
  public final K1 J;
  
  public long K;
  
  public final int[] L;
  
  public final float[] M;
  
  public final float[] N;
  
  public final float[] O;
  
  public long P;
  
  public boolean Q;
  
  public long R;
  
  public boolean S;
  
  public final k0 T;
  
  public final h1 U;
  
  public l<? super c, D> V;
  
  public final dbxyzptlk.z0.d<dbxyzptlk.CI.a<D>> V0;
  
  public boolean V1;
  
  public boolean V2;
  
  public final x V3;
  
  public final ViewTreeObserver.OnGlobalLayoutListener W;
  
  public final dbxyzptlk.tI.g a;
  
  public final ViewTreeObserver.OnScrollChangedListener a0;
  
  public long b;
  
  public final ViewTreeObserver.OnTouchModeChangeListener b0;
  
  public boolean c;
  
  public final U c0;
  
  public final B d;
  
  public final S d0;
  
  public dbxyzptlk.z1.d e;
  
  public final AtomicReference e0;
  
  public final EmptySemanticsElement f;
  
  public final z1 f0;
  
  public final j g;
  
  public final dbxyzptlk.s1.k.b g0;
  
  public final DragAndDropModifierOnDragListener h;
  
  public final k0 h0;
  
  public final dbxyzptlk.M0.c i;
  
  public int i0;
  
  public final U1 j;
  
  public final k0 j0;
  
  public final androidx.compose.ui.d k;
  
  public final dbxyzptlk.W0.a k0;
  
  public final androidx.compose.ui.d l;
  
  public final dbxyzptlk.X0.c l0;
  
  public final k0 m;
  
  public final dbxyzptlk.e1.f m0;
  
  public final androidx.compose.ui.node.f n;
  
  public final B1 n0;
  
  public final Z o;
  
  public MotionEvent o0;
  
  public final r p;
  
  public long p0;
  
  public final AndroidComposeViewAccessibilityDelegateCompat q;
  
  public final dbxyzptlk.L0.i r;
  
  public final List<S> s;
  
  public List<S> t;
  
  public boolean u;
  
  public final dbxyzptlk.a1.i v;
  
  public final E w;
  
  public l<? super Configuration, D> x;
  
  public final n x1;
  
  public final dbxyzptlk.CI.a<D> x2;
  
  public final dbxyzptlk.L0.a y;
  
  public final Runnable y1;
  
  public final X y2;
  
  public boolean z;
  
  public AndroidComposeView(Context paramContext, dbxyzptlk.tI.g paramg) {
    super(paramContext);
    Y y;
    this.a = paramg;
    dbxyzptlk.P0.f.a a1 = dbxyzptlk.P0.f.b;
    this.b = a1.b();
    this.c = true;
    this.d = new B(null, 1, null);
    this.e = dbxyzptlk.z1.a.a(paramContext);
    EmptySemanticsElement emptySemanticsElement = EmptySemanticsElement.b;
    this.f = emptySemanticsElement;
    this.g = (j)new FocusOwnerImpl(new h(this));
    DragAndDropModifierOnDragListener dragAndDropModifierOnDragListener = new DragAndDropModifierOnDragListener(new g(this));
    this.h = dragAndDropModifierOnDragListener;
    this.i = dragAndDropModifierOnDragListener;
    this.j = new U1();
    androidx.compose.ui.d.a a2 = androidx.compose.ui.d.a;
    androidx.compose.ui.d d1 = androidx.compose.ui.input.key.a.a((androidx.compose.ui.d)a2, new i(this));
    this.k = d1;
    androidx.compose.ui.d d2 = androidx.compose.ui.input.rotary.a.a((androidx.compose.ui.d)a2, o.f);
    this.l = d2;
    this.m = new k0();
    androidx.compose.ui.node.f f1 = new androidx.compose.ui.node.f(false, 0, 3, null);
    f1.j((G)c0.b);
    f1.e(getDensity());
    f1.g(a2.g((androidx.compose.ui.d)emptySemanticsElement).g(d2).g(getFocusOwner().f()).g(d1).g(dragAndDropModifierOnDragListener.d()));
    this.n = f1;
    this.o = this;
    this.p = new r(getRoot());
    AndroidComposeViewAccessibilityDelegateCompat androidComposeViewAccessibilityDelegateCompat = new AndroidComposeViewAccessibilityDelegateCompat(this);
    this.q = androidComposeViewAccessibilityDelegateCompat;
    this.r = new dbxyzptlk.L0.i();
    this.s = new ArrayList<>();
    this.v = new dbxyzptlk.a1.i();
    this.w = new E(getRoot());
    this.x = f.f;
    if (W()) {
      dbxyzptlk.L0.a a3 = new dbxyzptlk.L0.a((View)this, getAutofillTree());
    } else {
      d1 = null;
    } 
    this.y = (dbxyzptlk.L0.a)d1;
    this.A = new e(paramContext);
    this.B = new dbxyzptlk.g1.d(paramContext);
    this.C = new U(new p(this));
    this.I = new androidx.compose.ui.node.k(getRoot());
    this.J = (K1)new V(ViewConfiguration.get(paramContext));
    this.K = dbxyzptlk.z1.o.a(2147483647, 2147483647);
    this.L = new int[] { 0, 0 };
    float[] arrayOfFloat = H0.c(null, 1, null);
    this.M = arrayOfFloat;
    this.N = H0.c(null, 1, null);
    this.O = H0.c(null, 1, null);
    this.P = -1L;
    this.R = a1.a();
    this.S = true;
    this.T = X0.j(null, null, 2, null);
    this.U = X0.d(new q(this));
    this.W = (ViewTreeObserver.OnGlobalLayoutListener)new dbxyzptlk.g1.i(this);
    this.a0 = (ViewTreeObserver.OnScrollChangedListener)new j(this);
    this.b0 = (ViewTreeObserver.OnTouchModeChangeListener)new dbxyzptlk.g1.k(this);
    U u = new U(getView(), this);
    this.c0 = u;
    this.d0 = new S((K)N.f().invoke(u));
    this.e0 = dbxyzptlk.K0.k.a();
    this.f0 = (z1)new f0(getTextInputService());
    this.g0 = (dbxyzptlk.s1.k.b)new O(paramContext);
    this.h0 = X0.i(dbxyzptlk.s1.p.a(paramContext), X0.p());
    this.i0 = e0(paramContext.getResources().getConfiguration());
    this.j0 = X0.j(N.e(paramContext.getResources().getConfiguration()), null, 2, null);
    this.k0 = (dbxyzptlk.W0.a)new dbxyzptlk.W0.c((View)this);
    if (isInTouchMode()) {
      m = dbxyzptlk.X0.a.b.b();
    } else {
      m = dbxyzptlk.X0.a.b.a();
    } 
    this.l0 = new dbxyzptlk.X0.c(m, new d(this), null);
    this.m0 = new dbxyzptlk.e1.f(this);
    this.n0 = (B1)new Q((View)this);
    this.A0 = new S1();
    this.V0 = new dbxyzptlk.z0.d((Object[])new dbxyzptlk.CI.a[16], 0);
    this.x1 = new n(this);
    this.y1 = (Runnable)new l(this);
    this.x2 = new m(this);
    int m = Build.VERSION.SDK_INT;
    if (m >= 29) {
      a0 a0 = new a0();
    } else {
      y = new Y(arrayOfFloat, null);
    } 
    this.y2 = (X)y;
    setWillNotDraw(false);
    setFocusable(true);
    M.a.a((View)this, 1, false);
    setFocusableInTouchMode(true);
    setClipChildren(false);
    h0.q0((View)this, androidComposeViewAccessibilityDelegateCompat);
    l<k, D> l1 = k.s0.a();
    if (l1 != null)
      l1.invoke(this); 
    setOnDragListener(dragAndDropModifierOnDragListener);
    getRoot().t(this);
    if (m >= 29)
      G.a.a((View)this); 
    this.V3 = new k(this);
  }
  
  public static final void A0(AndroidComposeView paramAndroidComposeView) {
    paramAndroidComposeView.H0();
  }
  
  public static final void B0(AndroidComposeView paramAndroidComposeView) {
    paramAndroidComposeView.V1 = false;
    MotionEvent motionEvent = paramAndroidComposeView.o0;
    s.e(motionEvent);
    if (motionEvent.getActionMasked() == 10) {
      paramAndroidComposeView.C0(motionEvent);
      return;
    } 
    throw new IllegalStateException("The ACTION_HOVER_EXIT event was not cleared.");
  }
  
  public static final void G0(AndroidComposeView paramAndroidComposeView, boolean paramBoolean) {
    int m;
    dbxyzptlk.X0.c c1 = paramAndroidComposeView.l0;
    if (paramBoolean) {
      m = dbxyzptlk.X0.a.b.b();
    } else {
      m = dbxyzptlk.X0.a.b.a();
    } 
    c1.b(m);
  }
  
  public static final void f0(AndroidComposeView paramAndroidComposeView) {
    paramAndroidComposeView.H0();
  }
  
  private final c get_viewTreeOwners() {
    return (c)this.T.getValue();
  }
  
  private void setFontFamilyResolver(l.b paramb) {
    this.h0.setValue(paramb);
  }
  
  private void setLayoutDirection(t paramt) {
    this.j0.setValue(paramt);
  }
  
  private final void set_viewTreeOwners(c paramc) {
    this.T.setValue(paramc);
  }
  
  public long A(long paramLong) {
    s0();
    paramLong = H0.f(this.N, paramLong);
    return dbxyzptlk.P0.g.a(dbxyzptlk.P0.f.o(paramLong) + dbxyzptlk.P0.f.o(this.R), dbxyzptlk.P0.f.p(paramLong) + dbxyzptlk.P0.f.p(this.R));
  }
  
  public void B() {
    this.q.z0();
  }
  
  public final int C0(MotionEvent paramMotionEvent) {
    // Byte code:
    //   0: aload_0
    //   1: getfield V2 : Z
    //   4: ifeq -> 26
    //   7: aload_0
    //   8: iconst_0
    //   9: putfield V2 : Z
    //   12: aload_0
    //   13: getfield j : Ldbxyzptlk/g1/U1;
    //   16: aload_1
    //   17: invokevirtual getMetaState : ()I
    //   20: invokestatic b : (I)I
    //   23: invokevirtual a : (I)V
    //   26: aload_0
    //   27: getfield v : Ldbxyzptlk/a1/i;
    //   30: aload_1
    //   31: aload_0
    //   32: invokevirtual c : (Landroid/view/MotionEvent;Ldbxyzptlk/a1/P;)Ldbxyzptlk/a1/C;
    //   35: astore #6
    //   37: aload #6
    //   39: ifnull -> 191
    //   42: aload #6
    //   44: invokevirtual b : ()Ljava/util/List;
    //   47: astore #7
    //   49: aload #7
    //   51: invokeinterface size : ()I
    //   56: iconst_1
    //   57: isub
    //   58: istore_2
    //   59: iload_2
    //   60: iflt -> 103
    //   63: iload_2
    //   64: iconst_1
    //   65: isub
    //   66: istore_3
    //   67: aload #7
    //   69: iload_2
    //   70: invokeinterface get : (I)Ljava/lang/Object;
    //   75: astore #5
    //   77: aload #5
    //   79: checkcast dbxyzptlk/a1/D
    //   82: invokevirtual a : ()Z
    //   85: ifeq -> 91
    //   88: goto -> 106
    //   91: iload_3
    //   92: ifge -> 98
    //   95: goto -> 103
    //   98: iload_3
    //   99: istore_2
    //   100: goto -> 63
    //   103: aconst_null
    //   104: astore #5
    //   106: aload #5
    //   108: checkcast dbxyzptlk/a1/D
    //   111: astore #5
    //   113: aload #5
    //   115: ifnull -> 127
    //   118: aload_0
    //   119: aload #5
    //   121: invokevirtual f : ()J
    //   124: putfield b : J
    //   127: aload_0
    //   128: getfield w : Ldbxyzptlk/a1/E;
    //   131: aload #6
    //   133: aload_0
    //   134: aload_0
    //   135: aload_1
    //   136: invokevirtual o0 : (Landroid/view/MotionEvent;)Z
    //   139: invokevirtual a : (Ldbxyzptlk/a1/C;Ldbxyzptlk/a1/P;Z)I
    //   142: istore_3
    //   143: aload_1
    //   144: invokevirtual getActionMasked : ()I
    //   147: istore #4
    //   149: iload #4
    //   151: ifeq -> 162
    //   154: iload_3
    //   155: istore_2
    //   156: iload #4
    //   158: iconst_5
    //   159: if_icmpne -> 204
    //   162: iload_3
    //   163: istore_2
    //   164: iload_3
    //   165: invokestatic c : (I)Z
    //   168: ifne -> 204
    //   171: aload_0
    //   172: getfield v : Ldbxyzptlk/a1/i;
    //   175: aload_1
    //   176: aload_1
    //   177: invokevirtual getActionIndex : ()I
    //   180: invokevirtual getPointerId : (I)I
    //   183: invokevirtual e : (I)V
    //   186: iload_3
    //   187: istore_2
    //   188: goto -> 204
    //   191: aload_0
    //   192: getfield w : Ldbxyzptlk/a1/E;
    //   195: invokevirtual b : ()V
    //   198: iconst_0
    //   199: iconst_0
    //   200: invokestatic a : (ZZ)I
    //   203: istore_2
    //   204: iload_2
    //   205: ireturn
  }
  
  public final void D0(MotionEvent paramMotionEvent, int paramInt, long paramLong, boolean paramBoolean) {
    long l1;
    int m = paramMotionEvent.getActionMasked();
    byte b1 = -1;
    if (m != 1) {
      if (m != 6) {
        m = b1;
      } else {
        m = paramMotionEvent.getActionIndex();
      } 
    } else {
      m = b1;
      if (paramInt != 9) {
        m = b1;
        if (paramInt != 10)
          m = 0; 
      } 
    } 
    int i1 = paramMotionEvent.getPointerCount();
    if (m >= 0) {
      b1 = 1;
    } else {
      b1 = 0;
    } 
    int i2 = i1 - b1;
    if (i2 == 0)
      return; 
    MotionEvent.PointerProperties[] arrayOfPointerProperties = new MotionEvent.PointerProperties[i2];
    for (b1 = 0; b1 < i2; b1++)
      arrayOfPointerProperties[b1] = new MotionEvent.PointerProperties(); 
    MotionEvent.PointerCoords[] arrayOfPointerCoords = new MotionEvent.PointerCoords[i2];
    for (b1 = 0; b1 < i2; b1++)
      arrayOfPointerCoords[b1] = new MotionEvent.PointerCoords(); 
    for (b1 = 0; b1 < i2; b1++) {
      if (m < 0 || b1 < m) {
        i1 = 0;
      } else {
        i1 = 1;
      } 
      i1 += b1;
      paramMotionEvent.getPointerProperties(i1, arrayOfPointerProperties[b1]);
      MotionEvent.PointerCoords pointerCoords = arrayOfPointerCoords[b1];
      paramMotionEvent.getPointerCoords(i1, pointerCoords);
      l1 = A(dbxyzptlk.P0.g.a(pointerCoords.x, pointerCoords.y));
      pointerCoords.x = dbxyzptlk.P0.f.o(l1);
      pointerCoords.y = dbxyzptlk.P0.f.p(l1);
    } 
    if (paramBoolean) {
      m = 0;
    } else {
      m = paramMotionEvent.getButtonState();
    } 
    if (paramMotionEvent.getDownTime() == paramMotionEvent.getEventTime()) {
      l1 = paramLong;
    } else {
      l1 = paramMotionEvent.getDownTime();
    } 
    MotionEvent motionEvent = MotionEvent.obtain(l1, paramLong, paramInt, i2, arrayOfPointerProperties, arrayOfPointerCoords, paramMotionEvent.getMetaState(), m, paramMotionEvent.getXPrecision(), paramMotionEvent.getYPrecision(), paramMotionEvent.getDeviceId(), paramMotionEvent.getEdgeFlags(), paramMotionEvent.getSource(), paramMotionEvent.getFlags());
    C c1 = this.v.c(motionEvent, this);
    s.e(c1);
    this.w.a(c1, this, true);
    motionEvent.recycle();
  }
  
  public final boolean F0(dbxyzptlk.M0.h paramh, long paramLong, l<? super dbxyzptlk.S0.f, D> paraml) {
    Resources resources = getContext().getResources();
    dbxyzptlk.M0.a a1 = new dbxyzptlk.M0.a(dbxyzptlk.z1.f.a((resources.getDisplayMetrics()).density, (resources.getConfiguration()).fontScale), paramLong, paraml, null);
    return H.a.a((View)this, paramh, a1);
  }
  
  public final void H0() {
    // Byte code:
    //   0: aload_0
    //   1: aload_0
    //   2: getfield L : [I
    //   5: invokevirtual getLocationOnScreen : ([I)V
    //   8: aload_0
    //   9: getfield K : J
    //   12: lstore #6
    //   14: lload #6
    //   16: invokestatic c : (J)I
    //   19: istore_1
    //   20: lload #6
    //   22: invokestatic d : (J)I
    //   25: istore_3
    //   26: aload_0
    //   27: getfield L : [I
    //   30: astore #8
    //   32: iconst_0
    //   33: istore #5
    //   35: aload #8
    //   37: iconst_0
    //   38: iaload
    //   39: istore_2
    //   40: iload_1
    //   41: iload_2
    //   42: if_icmpne -> 57
    //   45: iload #5
    //   47: istore #4
    //   49: iload_3
    //   50: aload #8
    //   52: iconst_1
    //   53: iaload
    //   54: if_icmpeq -> 107
    //   57: aload_0
    //   58: iload_2
    //   59: aload #8
    //   61: iconst_1
    //   62: iaload
    //   63: invokestatic a : (II)J
    //   66: putfield K : J
    //   69: iload #5
    //   71: istore #4
    //   73: iload_1
    //   74: ldc_w 2147483647
    //   77: if_icmpeq -> 107
    //   80: iload #5
    //   82: istore #4
    //   84: iload_3
    //   85: ldc_w 2147483647
    //   88: if_icmpeq -> 107
    //   91: aload_0
    //   92: invokevirtual getRoot : ()Landroidx/compose/ui/node/f;
    //   95: invokevirtual S : ()Landroidx/compose/ui/node/g;
    //   98: invokevirtual F : ()Landroidx/compose/ui/node/g$b;
    //   101: invokevirtual M1 : ()V
    //   104: iconst_1
    //   105: istore #4
    //   107: aload_0
    //   108: getfield I : Landroidx/compose/ui/node/k;
    //   111: iload #4
    //   113: invokevirtual c : (Z)V
    //   116: return
  }
  
  public final void U(AndroidViewHolder paramAndroidViewHolder, androidx.compose.ui.node.f paramf) {
    getAndroidViewsHandler$ui_release().getHolderToLayoutNode().put(paramAndroidViewHolder, paramf);
    getAndroidViewsHandler$ui_release().addView((View)paramAndroidViewHolder);
    getAndroidViewsHandler$ui_release().getLayoutNodeToHolder().put(paramf, paramAndroidViewHolder);
    h0.A0((View)paramAndroidViewHolder, 1);
    h0.q0((View)paramAndroidViewHolder, (dbxyzptlk.h2.a)new e(this, paramf, this));
  }
  
  public final void V(int paramInt, AccessibilityNodeInfo paramAccessibilityNodeInfo, String paramString) {
    if (s.c(paramString, this.q.Y())) {
      Integer integer = this.q.a0().get(Integer.valueOf(paramInt));
      if (integer != null)
        paramAccessibilityNodeInfo.getExtras().putInt(paramString, integer.intValue()); 
    } else if (s.c(paramString, this.q.X())) {
      Integer integer = this.q.Z().get(Integer.valueOf(paramInt));
      if (integer != null)
        paramAccessibilityNodeInfo.getExtras().putInt(paramString, integer.intValue()); 
    } 
  }
  
  public final boolean W() {
    return true;
  }
  
  public final Object X(dbxyzptlk.tI.d<? super D> paramd) {
    Object object = this.q.G(paramd);
    return (object == dbxyzptlk.uI.c.g()) ? object : D.a;
  }
  
  public final boolean Y(androidx.compose.ui.node.f paramf) {
    if (!this.H) {
      paramf = paramf.m0();
      return (paramf != null && !paramf.L());
    } 
    return true;
  }
  
  public final void Z(ViewGroup paramViewGroup) {
    int m = paramViewGroup.getChildCount();
    for (byte b1 = 0; b1 < m; b1++) {
      View view = paramViewGroup.getChildAt(b1);
      if (view instanceof AndroidComposeView) {
        ((AndroidComposeView)view).p();
      } else if (view instanceof ViewGroup) {
        Z((ViewGroup)view);
      } 
    } 
  }
  
  public void a(boolean paramBoolean) {
    if (this.I.k() || this.I.l()) {
      dbxyzptlk.CI.a a1;
      Trace.beginSection("AndroidOwner:measureAndLayout");
      if (paramBoolean) {
        try {
          a1 = this.x2;
        } finally {}
      } else {
        a1 = null;
      } 
      if (this.I.p(a1))
        requestLayout(); 
      androidx.compose.ui.node.k.d(this.I, false, 1, null);
      D d1 = D.a;
      Trace.endSection();
    } 
  }
  
  public final long a0(int paramInt) {
    long l1;
    int m = View.MeasureSpec.getMode(paramInt);
    paramInt = View.MeasureSpec.getSize(paramInt);
    if (m != Integer.MIN_VALUE) {
      if (m != 0) {
        if (m == 1073741824) {
          l1 = r0(paramInt, paramInt);
        } else {
          throw new IllegalStateException();
        } 
      } else {
        l1 = r0(0, 2147483647);
      } 
    } else {
      l1 = r0(0, paramInt);
    } 
    return l1;
  }
  
  public void autofill(SparseArray<AutofillValue> paramSparseArray) {
    if (W()) {
      dbxyzptlk.L0.a a1 = this.y;
      if (a1 != null)
        dbxyzptlk.L0.c.a(a1, paramSparseArray); 
    } 
  }
  
  public final void b0(AndroidViewHolder paramAndroidViewHolder, Canvas paramCanvas) {
    getAndroidViewsHandler$ui_release().a(paramAndroidViewHolder, paramCanvas);
  }
  
  public void c(androidx.compose.ui.node.f paramf) {
    this.I.E(paramf);
    z0(this, null, 1, null);
  }
  
  public final View c0(int paramInt, View paramView) {
    if (Build.VERSION.SDK_INT < 29) {
      Method method = View.class.getDeclaredMethod("getAccessibilityViewId", null);
      method.setAccessible(true);
      if (s.c(method.invoke(paramView, null), Integer.valueOf(paramInt)))
        return paramView; 
      if (paramView instanceof ViewGroup) {
        ViewGroup viewGroup = (ViewGroup)paramView;
        int m = viewGroup.getChildCount();
        for (byte b1 = 0; b1 < m; b1++) {
          View view = c0(paramInt, viewGroup.getChildAt(b1));
          if (view != null)
            return view; 
        } 
      } 
    } 
    return null;
  }
  
  public boolean canScrollHorizontally(int paramInt) {
    return this.q.J(false, paramInt, this.b);
  }
  
  public boolean canScrollVertically(int paramInt) {
    return this.q.J(true, paramInt, this.b);
  }
  
  public androidx.compose.ui.focus.c d0(KeyEvent paramKeyEvent) {
    long l1 = dbxyzptlk.Y0.d.a(paramKeyEvent);
    dbxyzptlk.Y0.a.a a1 = dbxyzptlk.Y0.a.b;
    if (dbxyzptlk.Y0.a.q(l1, a1.m())) {
      int m;
      if (dbxyzptlk.Y0.d.f(paramKeyEvent)) {
        m = androidx.compose.ui.focus.c.b.f();
      } else {
        m = androidx.compose.ui.focus.c.b.e();
      } 
      androidx.compose.ui.focus.c c1 = androidx.compose.ui.focus.c.i(m);
    } else if (dbxyzptlk.Y0.a.q(l1, a1.f())) {
      androidx.compose.ui.focus.c c1 = androidx.compose.ui.focus.c.i(androidx.compose.ui.focus.c.b.g());
    } else if (dbxyzptlk.Y0.a.q(l1, a1.e())) {
      androidx.compose.ui.focus.c c1 = androidx.compose.ui.focus.c.i(androidx.compose.ui.focus.c.b.d());
    } else {
      boolean bool = dbxyzptlk.Y0.a.q(l1, a1.g());
      boolean bool1 = true;
      if (bool) {
        bool = true;
      } else {
        bool = dbxyzptlk.Y0.a.q(l1, a1.l());
      } 
      if (bool) {
        androidx.compose.ui.focus.c c1 = androidx.compose.ui.focus.c.i(androidx.compose.ui.focus.c.b.h());
      } else {
        if (dbxyzptlk.Y0.a.q(l1, a1.d())) {
          bool = true;
        } else {
          bool = dbxyzptlk.Y0.a.q(l1, a1.k());
        } 
        if (bool) {
          androidx.compose.ui.focus.c c1 = androidx.compose.ui.focus.c.i(androidx.compose.ui.focus.c.b.a());
        } else {
          if (dbxyzptlk.Y0.a.q(l1, a1.c())) {
            bool = true;
          } else {
            bool = dbxyzptlk.Y0.a.q(l1, a1.h());
          } 
          if (bool) {
            bool = true;
          } else {
            bool = dbxyzptlk.Y0.a.q(l1, a1.j());
          } 
          if (bool) {
            androidx.compose.ui.focus.c c1 = androidx.compose.ui.focus.c.i(androidx.compose.ui.focus.c.b.b());
          } else {
            if (dbxyzptlk.Y0.a.q(l1, a1.a())) {
              bool = bool1;
            } else {
              bool = dbxyzptlk.Y0.a.q(l1, a1.i());
            } 
            if (bool) {
              androidx.compose.ui.focus.c c1 = androidx.compose.ui.focus.c.i(androidx.compose.ui.focus.c.b.c());
            } else {
              paramKeyEvent = null;
            } 
          } 
        } 
      } 
    } 
    return (androidx.compose.ui.focus.c)paramKeyEvent;
  }
  
  public void dispatchDraw(Canvas paramCanvas) {
    if (!isAttachedToWindow())
      k0(getRoot()); 
    Owner.b(this, false, 1, null);
    dbxyzptlk.I0.k.e.k();
    this.u = true;
    k0 k01 = this.m;
    Canvas canvas = k01.a().B();
    k01.a().C(paramCanvas);
    G g1 = k01.a();
    getRoot().A((j0)g1);
    k01.a().C(canvas);
    if (!this.s.isEmpty()) {
      int m = this.s.size();
      for (byte b1 = 0; b1 < m; b1++)
        ((S)this.s.get(b1)).l(); 
    } 
    if (ViewLayer.p.b()) {
      int m = paramCanvas.save();
      paramCanvas.clipRect(0.0F, 0.0F, 0.0F, 0.0F);
      super.dispatchDraw(paramCanvas);
      paramCanvas.restoreToCount(m);
    } 
    this.s.clear();
    this.u = false;
    List<S> list = this.t;
    if (list != null) {
      s.e(list);
      this.s.addAll(list);
      list.clear();
    } 
  }
  
  public boolean dispatchGenericMotionEvent(MotionEvent paramMotionEvent) {
    boolean bool;
    if (paramMotionEvent.getActionMasked() == 8) {
      if (paramMotionEvent.isFromSource(4194304)) {
        bool = h0(paramMotionEvent);
      } else {
        if (m0(paramMotionEvent) || !isAttachedToWindow())
          return super.dispatchGenericMotionEvent(paramMotionEvent); 
        bool = Q.c(g0(paramMotionEvent));
      } 
    } else {
      bool = super.dispatchGenericMotionEvent(paramMotionEvent);
    } 
    return bool;
  }
  
  public boolean dispatchHoverEvent(MotionEvent paramMotionEvent) {
    if (this.V1) {
      removeCallbacks(this.y1);
      this.y1.run();
    } 
    if (m0(paramMotionEvent) || !isAttachedToWindow())
      return false; 
    this.q.P(paramMotionEvent);
    int m = paramMotionEvent.getActionMasked();
    if (m != 7) {
      if (m == 10 && o0(paramMotionEvent)) {
        if (paramMotionEvent.getToolType(0) == 3 && paramMotionEvent.getButtonState() != 0)
          return false; 
        MotionEvent motionEvent = this.o0;
        if (motionEvent != null)
          motionEvent.recycle(); 
        this.o0 = MotionEvent.obtainNoHistory(paramMotionEvent);
        this.V1 = true;
        post(this.y1);
        return false;
      } 
    } else if (!p0(paramMotionEvent)) {
      return false;
    } 
    return Q.c(g0(paramMotionEvent));
  }
  
  public boolean dispatchKeyEvent(KeyEvent paramKeyEvent) {
    boolean bool;
    if (isFocused()) {
      this.j.a(N.b(paramKeyEvent.getMetaState()));
      if (getFocusOwner().h(dbxyzptlk.Y0.b.b(paramKeyEvent)) || super.dispatchKeyEvent(paramKeyEvent))
        return true; 
      bool = false;
    } else {
      bool = super.dispatchKeyEvent(paramKeyEvent);
    } 
    return bool;
  }
  
  public boolean dispatchKeyEventPreIme(KeyEvent paramKeyEvent) {
    boolean bool;
    if ((isFocused() && getFocusOwner().d(dbxyzptlk.Y0.b.b(paramKeyEvent))) || super.dispatchKeyEventPreIme(paramKeyEvent)) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public boolean dispatchTouchEvent(MotionEvent paramMotionEvent) {
    if (this.V1) {
      removeCallbacks(this.y1);
      MotionEvent motionEvent = this.o0;
      s.e(motionEvent);
      if (paramMotionEvent.getActionMasked() != 0 || i0(paramMotionEvent, motionEvent)) {
        this.y1.run();
      } else {
        this.V1 = false;
      } 
    } 
    if (m0(paramMotionEvent) || !isAttachedToWindow())
      return false; 
    if (paramMotionEvent.getActionMasked() == 2 && !p0(paramMotionEvent))
      return false; 
    int m = g0(paramMotionEvent);
    if (Q.b(m))
      getParent().requestDisallowInterceptTouchEvent(true); 
    return Q.c(m);
  }
  
  public void e(float[] paramArrayOffloat) {
    s0();
    H0.k(paramArrayOffloat, this.N);
    N.c(paramArrayOffloat, dbxyzptlk.P0.f.o(this.R), dbxyzptlk.P0.f.p(this.R), this.M);
  }
  
  public final int e0(Configuration paramConfiguration) {
    boolean bool;
    if (Build.VERSION.SDK_INT >= 31) {
      bool = dbxyzptlk.g1.g.a(paramConfiguration);
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public final View findViewByAccessibilityIdTraversal(int paramInt) {
    Method method1;
    Method method2 = null;
    try {
      if (Build.VERSION.SDK_INT >= 29) {
        method1 = View.class.getDeclaredMethod("findViewByAccessibilityIdTraversal", new Class[] { int.class });
        method1.setAccessible(true);
        Object object = method1.invoke(this, new Object[] { Integer.valueOf(paramInt) });
        method1 = method2;
        if (object instanceof View)
          View view = (View)object; 
      } else {
        View view = c0(paramInt, (View)this);
      } 
    } catch (NoSuchMethodException noSuchMethodException) {
      method1 = method2;
    } 
    return (View)method1;
  }
  
  public void g(Owner.b paramb) {
    this.I.v(paramb);
    z0(this, null, 1, null);
  }
  
  public final int g0(MotionEvent paramMotionEvent) {
    removeCallbacks(this.x1);
    try {
      int i1;
      MotionEvent motionEvent;
      t0(paramMotionEvent);
      boolean bool = true;
      this.Q = true;
      a(false);
      Trace.beginSection("AndroidOwner:onTouch");
      try {
        i1 = paramMotionEvent.getActionMasked();
        motionEvent = this.o0;
        if (motionEvent != null && motionEvent.getToolType(0) == 3) {
          m = 1;
        } else {
          m = 0;
        } 
      } finally {}
      if (motionEvent != null && i0(paramMotionEvent, motionEvent))
        if (n0(motionEvent)) {
          this.w.b();
        } else if (motionEvent.getActionMasked() != 10 && m) {
          E0(this, motionEvent, 10, motionEvent.getEventTime(), false, 8, null);
        }  
      if (paramMotionEvent.getToolType(0) != 3)
        bool = false; 
      if (!m && bool && i1 != 3 && i1 != 9 && o0(paramMotionEvent))
        E0(this, paramMotionEvent, 9, paramMotionEvent.getEventTime(), false, 8, null); 
      if (motionEvent != null)
        motionEvent.recycle(); 
      this.o0 = MotionEvent.obtainNoHistory(paramMotionEvent);
      int m = C0(paramMotionEvent);
      Trace.endSection();
      return m;
    } finally {
      this.Q = false;
    } 
  }
  
  public dbxyzptlk.g1.d getAccessibilityManager() {
    return this.B;
  }
  
  public final AndroidViewsHandler getAndroidViewsHandler$ui_release() {
    if (this.E == null) {
      AndroidViewsHandler androidViewsHandler1 = new AndroidViewsHandler(getContext());
      this.E = androidViewsHandler1;
      addView((View)androidViewsHandler1);
    } 
    AndroidViewsHandler androidViewsHandler = this.E;
    s.e(androidViewsHandler);
    return androidViewsHandler;
  }
  
  public dbxyzptlk.L0.d getAutofill() {
    return (dbxyzptlk.L0.d)this.y;
  }
  
  public dbxyzptlk.L0.i getAutofillTree() {
    return this.r;
  }
  
  public e getClipboardManager() {
    return this.A;
  }
  
  public final l<Configuration, D> getConfigurationChangeObserver() {
    return (l)this.x;
  }
  
  public dbxyzptlk.tI.g getCoroutineContext() {
    return this.a;
  }
  
  public dbxyzptlk.z1.d getDensity() {
    return this.e;
  }
  
  public dbxyzptlk.M0.c getDragAndDropManager() {
    return this.i;
  }
  
  public j getFocusOwner() {
    return this.g;
  }
  
  public void getFocusedRect(Rect paramRect) {
    dbxyzptlk.P0.h h = getFocusOwner().n();
    if (h != null) {
      paramRect.left = dbxyzptlk.GI.c.d(h.m());
      paramRect.top = dbxyzptlk.GI.c.d(h.p());
      paramRect.right = dbxyzptlk.GI.c.d(h.n());
      paramRect.bottom = dbxyzptlk.GI.c.d(h.i());
      D d1 = D.a;
    } else {
      h = null;
    } 
    if (h == null)
      super.getFocusedRect(paramRect); 
  }
  
  public l.b getFontFamilyResolver() {
    return (l.b)this.h0.getValue();
  }
  
  public dbxyzptlk.s1.k.b getFontLoader() {
    return this.g0;
  }
  
  public dbxyzptlk.W0.a getHapticFeedBack() {
    return this.k0;
  }
  
  public boolean getHasPendingMeasureOrLayout() {
    return this.I.k();
  }
  
  public dbxyzptlk.X0.b getInputModeManager() {
    return (dbxyzptlk.X0.b)this.l0;
  }
  
  public final long getLastMatrixRecalculationAnimationTime$ui_release() {
    return this.P;
  }
  
  public t getLayoutDirection() {
    return (t)this.j0.getValue();
  }
  
  public long getMeasureIteration() {
    return this.I.o();
  }
  
  public dbxyzptlk.e1.f getModifierLocalManager() {
    return this.m0;
  }
  
  public Y.a getPlacementScope() {
    return Z.b(this);
  }
  
  public x getPointerIconService() {
    return this.V3;
  }
  
  public androidx.compose.ui.node.f getRoot() {
    return this.n;
  }
  
  public Z getRootForTest() {
    return this.o;
  }
  
  public r getSemanticsOwner() {
    return this.p;
  }
  
  public B getSharedDrawScope() {
    return this.d;
  }
  
  public boolean getShowLayoutBounds() {
    return this.D;
  }
  
  public U getSnapshotObserver() {
    return this.C;
  }
  
  public z1 getSoftwareKeyboardController() {
    return this.f0;
  }
  
  public S getTextInputService() {
    return this.d0;
  }
  
  public B1 getTextToolbar() {
    return this.n0;
  }
  
  public View getView() {
    return (View)this;
  }
  
  public K1 getViewConfiguration() {
    return this.J;
  }
  
  public final c getViewTreeOwners() {
    return (c)this.U.getValue();
  }
  
  public T1 getWindowInfo() {
    return (T1)this.j;
  }
  
  public void h(dbxyzptlk.CI.a<D> parama) {
    if (!this.V0.j(parama))
      this.V0.c(parama); 
  }
  
  public final boolean h0(MotionEvent paramMotionEvent) {
    ViewConfiguration viewConfiguration = ViewConfiguration.get(getContext());
    float f1 = -paramMotionEvent.getAxisValue(26);
    dbxyzptlk.c1.c c1 = new dbxyzptlk.c1.c(f1 * l0.i(viewConfiguration, getContext()), f1 * l0.e(viewConfiguration, getContext()), paramMotionEvent.getEventTime(), paramMotionEvent.getDeviceId());
    return getFocusOwner().j(c1);
  }
  
  public S i(l<? super j0, D> paraml, dbxyzptlk.CI.a<D> parama) {
    S s = (S)this.A0.b();
    if (s != null) {
      s.h(paraml, parama);
      return s;
    } 
    if (isHardwareAccelerated() && this.S)
      try {
        return (S)new t1(this, paraml, parama);
      } finally {
        s = null;
      }  
    if (this.F == null) {
      ViewLayerContainer viewLayerContainer;
      ViewLayer.c c1 = ViewLayer.p;
      if (!c1.a())
        c1.d(new View(getContext())); 
      if (c1.b()) {
        DrawChildContainer drawChildContainer1 = new DrawChildContainer(getContext());
      } else {
        viewLayerContainer = new ViewLayerContainer(getContext());
      } 
      this.F = (DrawChildContainer)viewLayerContainer;
      addView((View)viewLayerContainer);
    } 
    DrawChildContainer drawChildContainer = this.F;
    s.e(drawChildContainer);
    return new ViewLayer(this, drawChildContainer, paraml, parama);
  }
  
  public final boolean i0(MotionEvent paramMotionEvent1, MotionEvent paramMotionEvent2) {
    if (paramMotionEvent2.getSource() == paramMotionEvent1.getSource()) {
      boolean bool = false;
      return (paramMotionEvent2.getToolType(0) != paramMotionEvent1.getToolType(0)) ? true : bool;
    } 
    return true;
  }
  
  public long j(long paramLong) {
    s0();
    float f1 = dbxyzptlk.P0.f.o(paramLong);
    float f2 = dbxyzptlk.P0.f.o(this.R);
    float f4 = dbxyzptlk.P0.f.p(paramLong);
    float f3 = dbxyzptlk.P0.f.p(this.R);
    return H0.f(this.O, dbxyzptlk.P0.g.a(f1 - f2, f4 - f3));
  }
  
  public void j0() {
    k0(getRoot());
  }
  
  public void k(androidx.compose.ui.node.f paramf, long paramLong) {
    Trace.beginSection("AndroidOwner:measureAndLayout");
    try {
      this.I.q(paramf, paramLong);
      if (!this.I.k())
        androidx.compose.ui.node.k.d(this.I, false, 1, null); 
    } finally {}
    D d1 = D.a;
    Trace.endSection();
  }
  
  public final void k0(androidx.compose.ui.node.f paramf) {
    paramf.D0();
    dbxyzptlk.z0.d d1 = paramf.u0();
    int m = d1.p();
    if (m > 0) {
      int i2;
      Object[] arrayOfObject = d1.o();
      int i1 = 0;
      do {
        k0((androidx.compose.ui.node.f)arrayOfObject[i1]);
        i2 = i1 + 1;
        i1 = i2;
      } while (i2 < m);
    } 
  }
  
  public final void l0(androidx.compose.ui.node.f paramf) {
    androidx.compose.ui.node.k k1 = this.I;
    int m = 0;
    androidx.compose.ui.node.k.I(k1, paramf, false, 2, null);
    dbxyzptlk.z0.d d1 = paramf.u0();
    int i1 = d1.p();
    if (i1 > 0) {
      int i2;
      Object[] arrayOfObject = d1.o();
      do {
        l0((androidx.compose.ui.node.f)arrayOfObject[m]);
        i2 = m + 1;
        m = i2;
      } while (i2 < i1);
    } 
  }
  
  public long m(long paramLong) {
    s0();
    return H0.f(this.O, paramLong);
  }
  
  public final boolean m0(MotionEvent paramMotionEvent) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual getX : ()F
    //   4: fstore_2
    //   5: fload_2
    //   6: invokestatic isInfinite : (F)Z
    //   9: ifne -> 82
    //   12: fload_2
    //   13: invokestatic isNaN : (F)Z
    //   16: ifne -> 82
    //   19: aload_1
    //   20: invokevirtual getY : ()F
    //   23: fstore_2
    //   24: fload_2
    //   25: invokestatic isInfinite : (F)Z
    //   28: ifne -> 82
    //   31: fload_2
    //   32: invokestatic isNaN : (F)Z
    //   35: ifne -> 82
    //   38: aload_1
    //   39: invokevirtual getRawX : ()F
    //   42: fstore_2
    //   43: fload_2
    //   44: invokestatic isInfinite : (F)Z
    //   47: ifne -> 82
    //   50: fload_2
    //   51: invokestatic isNaN : (F)Z
    //   54: ifne -> 82
    //   57: aload_1
    //   58: invokevirtual getRawY : ()F
    //   61: fstore_2
    //   62: fload_2
    //   63: invokestatic isInfinite : (F)Z
    //   66: ifne -> 82
    //   69: fload_2
    //   70: invokestatic isNaN : (F)Z
    //   73: ifne -> 82
    //   76: iconst_0
    //   77: istore #5
    //   79: goto -> 85
    //   82: iconst_1
    //   83: istore #5
    //   85: iload #5
    //   87: istore #6
    //   89: iload #5
    //   91: ifne -> 198
    //   94: aload_1
    //   95: invokevirtual getPointerCount : ()I
    //   98: istore #4
    //   100: iconst_1
    //   101: istore_3
    //   102: iload #5
    //   104: istore #6
    //   106: iload_3
    //   107: iload #4
    //   109: if_icmpge -> 198
    //   112: aload_1
    //   113: iload_3
    //   114: invokevirtual getX : (I)F
    //   117: fstore_2
    //   118: fload_2
    //   119: invokestatic isInfinite : (F)Z
    //   122: ifne -> 180
    //   125: fload_2
    //   126: invokestatic isNaN : (F)Z
    //   129: ifne -> 180
    //   132: aload_1
    //   133: iload_3
    //   134: invokevirtual getY : (I)F
    //   137: fstore_2
    //   138: fload_2
    //   139: invokestatic isInfinite : (F)Z
    //   142: ifne -> 180
    //   145: fload_2
    //   146: invokestatic isNaN : (F)Z
    //   149: ifne -> 180
    //   152: getstatic android/os/Build$VERSION.SDK_INT : I
    //   155: bipush #29
    //   157: if_icmplt -> 174
    //   160: getstatic dbxyzptlk/g1/x0.a : Ldbxyzptlk/g1/x0;
    //   163: aload_1
    //   164: iload_3
    //   165: invokevirtual a : (Landroid/view/MotionEvent;I)Z
    //   168: ifne -> 174
    //   171: goto -> 180
    //   174: iconst_0
    //   175: istore #5
    //   177: goto -> 183
    //   180: iconst_1
    //   181: istore #5
    //   183: iload #5
    //   185: istore #6
    //   187: iload #5
    //   189: ifne -> 198
    //   192: iinc #3, 1
    //   195: goto -> 102
    //   198: iload #6
    //   200: ireturn
  }
  
  public final boolean n0(MotionEvent paramMotionEvent) {
    int m = paramMotionEvent.getButtonState();
    boolean bool2 = true;
    if (m != 0)
      return true; 
    m = paramMotionEvent.getActionMasked();
    boolean bool1 = bool2;
    if (m != 0) {
      bool1 = bool2;
      if (m != 2) {
        bool1 = bool2;
        if (m != 6)
          bool1 = false; 
      } 
    } 
    return bool1;
  }
  
  public void o(androidx.compose.ui.node.f paramf, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) {
    if (paramBoolean1) {
      if (this.I.C(paramf, paramBoolean2) && paramBoolean3)
        y0(paramf); 
    } else if (this.I.H(paramf, paramBoolean2) && paramBoolean3) {
      y0(paramf);
    } 
  }
  
  public final boolean o0(MotionEvent paramMotionEvent) {
    boolean bool;
    float f2 = paramMotionEvent.getX();
    float f1 = paramMotionEvent.getY();
    if (0.0F <= f2 && f2 <= getWidth() && 0.0F <= f1 && f1 <= getHeight()) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public void onAttachedToWindow() {
    int m;
    super.onAttachedToWindow();
    l0(getRoot());
    k0(getRoot());
    getSnapshotObserver().k();
    if (W()) {
      dbxyzptlk.L0.a a1 = this.y;
      if (a1 != null)
        dbxyzptlk.L0.g.a.a(a1); 
    } 
    LifecycleOwner lifecycleOwner = A.a((View)this);
    dbxyzptlk.J4.d d1 = e.a((View)this);
    c c3 = getViewTreeOwners();
    if (c3 == null || (lifecycleOwner != null && d1 != null && (lifecycleOwner != c3.a() || d1 != c3.a())))
      if (lifecycleOwner != null) {
        if (d1 != null) {
          if (c3 != null) {
            LifecycleOwner lifecycleOwner1 = c3.a();
            if (lifecycleOwner1 != null) {
              androidx.lifecycle.f f1 = lifecycleOwner1.getLifecycle();
              if (f1 != null)
                f1.d((dbxyzptlk.U2.h)this); 
            } 
          } 
          lifecycleOwner.getLifecycle().a((dbxyzptlk.U2.h)this);
          c c4 = new c(lifecycleOwner, d1);
          set_viewTreeOwners(c4);
          l<? super c, D> l1 = this.V;
          if (l1 != null)
            l1.invoke(c4); 
          this.V = null;
        } else {
          throw new IllegalStateException("Composed into the View which doesn't propagateViewTreeSavedStateRegistryOwner!");
        } 
      } else {
        throw new IllegalStateException("Composed into the View which doesn't propagate ViewTreeLifecycleOwner!");
      }  
    dbxyzptlk.X0.c c2 = this.l0;
    if (isInTouchMode()) {
      m = dbxyzptlk.X0.a.b.b();
    } else {
      m = dbxyzptlk.X0.a.b.a();
    } 
    c2.b(m);
    c c1 = getViewTreeOwners();
    s.e(c1);
    c1.a().getLifecycle().a((dbxyzptlk.U2.h)this);
    c1 = getViewTreeOwners();
    s.e(c1);
    c1.a().getLifecycle().a((dbxyzptlk.U2.h)this.q);
    getViewTreeObserver().addOnGlobalLayoutListener(this.W);
    getViewTreeObserver().addOnScrollChangedListener(this.a0);
    getViewTreeObserver().addOnTouchModeChangeListener(this.b0);
    if (Build.VERSION.SDK_INT >= 31)
      K.a.b((View)this, dbxyzptlk.g1.h.a(new a())); 
  }
  
  public boolean onCheckIsTextEditor() {
    P p = (P)dbxyzptlk.K0.k.c(this.e0);
    return (p == null) ? this.c0.q() : p.b();
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    this.e = dbxyzptlk.z1.a.a(getContext());
    if (e0(paramConfiguration) != this.i0) {
      this.i0 = e0(paramConfiguration);
      setFontFamilyResolver(dbxyzptlk.s1.p.a(getContext()));
    } 
    this.x.invoke(paramConfiguration);
  }
  
  public InputConnection onCreateInputConnection(EditorInfo paramEditorInfo) {
    P p = (P)dbxyzptlk.K0.k.c(this.e0);
    return (p == null) ? this.c0.n(paramEditorInfo) : p.a(paramEditorInfo);
  }
  
  public void onCreateVirtualViewTranslationRequests(long[] paramArrayOflong, int[] paramArrayOfint, Consumer<ViewTranslationRequest> paramConsumer) {
    this.q.w0(paramArrayOflong, paramArrayOfint, paramConsumer);
  }
  
  public void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    getSnapshotObserver().l();
    c c1 = getViewTreeOwners();
    if (c1 != null) {
      LifecycleOwner lifecycleOwner = c1.a();
      if (lifecycleOwner != null) {
        androidx.lifecycle.f f1 = lifecycleOwner.getLifecycle();
        if (f1 != null)
          f1.d((dbxyzptlk.U2.h)this); 
      } 
    } 
    c1 = getViewTreeOwners();
    if (c1 != null) {
      LifecycleOwner lifecycleOwner = c1.a();
      if (lifecycleOwner != null) {
        androidx.lifecycle.f f1 = lifecycleOwner.getLifecycle();
        if (f1 != null)
          f1.d((dbxyzptlk.U2.h)this.q); 
      } 
    } 
    if (W()) {
      dbxyzptlk.L0.a a1 = this.y;
      if (a1 != null)
        dbxyzptlk.L0.g.a.b(a1); 
    } 
    getViewTreeObserver().removeOnGlobalLayoutListener(this.W);
    getViewTreeObserver().removeOnScrollChangedListener(this.a0);
    getViewTreeObserver().removeOnTouchModeChangeListener(this.b0);
    if (Build.VERSION.SDK_INT >= 31)
      K.a.a((View)this); 
  }
  
  public void onDraw(Canvas paramCanvas) {}
  
  public void onFocusChanged(boolean paramBoolean, int paramInt, Rect paramRect) {
    super.onFocusChanged(paramBoolean, paramInt, paramRect);
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Owner FocusChanged(");
    stringBuilder.append(paramBoolean);
    stringBuilder.append(')');
    Log.d("Compose Focus", stringBuilder.toString());
    u u = getFocusOwner().c();
    j j1 = new j(paramBoolean, this);
    u.d(u).c(j1);
    if (u.e(u)) {
      if (paramBoolean) {
        getFocusOwner().b();
      } else {
        getFocusOwner().o();
      } 
    } else {
      try {
        u.a(u);
        if (paramBoolean) {
          getFocusOwner().b();
        } else {
          getFocusOwner().o();
        } 
      } finally {}
      D d1 = D.a;
      u.c(u);
    } 
  }
  
  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this.I.p(this.x2);
    this.G = null;
    H0();
    if (this.E != null)
      getAndroidViewsHandler$ui_release().layout(0, 0, paramInt3 - paramInt1, paramInt4 - paramInt2); 
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    Trace.beginSection("AndroidOwner:onMeasure");
    try {
      if (!isAttachedToWindow())
        l0(getRoot()); 
    } finally {
      Exception exception;
    } 
    long l1 = a0(paramInt1);
    int m = (int)y.b(l1 >>> 32L);
    paramInt1 = (int)y.b(l1 & 0xFFFFFFFFL);
    l1 = a0(paramInt2);
    l1 = dbxyzptlk.z1.c.a(m, paramInt1, (int)y.b(l1 >>> 32L), (int)y.b(0xFFFFFFFFL & l1));
    dbxyzptlk.z1.b b1 = this.G;
    boolean bool = false;
    if (b1 == null) {
      this.G = dbxyzptlk.z1.b.b(l1);
      this.H = false;
    } else {
      if (b1 != null)
        bool = dbxyzptlk.z1.b.g(b1.t(), l1); 
      if (!bool)
        this.H = true; 
    } 
    this.I.J(l1);
    this.I.r();
    setMeasuredDimension(getRoot().r0(), getRoot().M());
    if (this.E != null)
      getAndroidViewsHandler$ui_release().measure(View.MeasureSpec.makeMeasureSpec(getRoot().r0(), 1073741824), View.MeasureSpec.makeMeasureSpec(getRoot().M(), 1073741824)); 
    D d1 = D.a;
    Trace.endSection();
  }
  
  public void onProvideAutofillVirtualStructure(ViewStructure paramViewStructure, int paramInt) {
    if (W() && paramViewStructure != null) {
      dbxyzptlk.L0.a a1 = this.y;
      if (a1 != null)
        dbxyzptlk.L0.c.b(a1, paramViewStructure); 
    } 
  }
  
  public void onResume(LifecycleOwner paramLifecycleOwner) {
    setShowLayoutBounds(b.a(A4));
  }
  
  public void onRtlPropertiesChanged(int paramInt) {
    if (this.c) {
      t t = N.a(paramInt);
      setLayoutDirection(t);
      getFocusOwner().a(t);
    } 
  }
  
  public void onVirtualViewTranslationResponses(LongSparseArray<ViewTranslationResponse> paramLongSparseArray) {
    this.q.B0(paramLongSparseArray);
  }
  
  public void onWindowFocusChanged(boolean paramBoolean) {
    this.j.b(paramBoolean);
    this.V2 = true;
    super.onWindowFocusChanged(paramBoolean);
    if (paramBoolean) {
      paramBoolean = b.a(A4);
      if (getShowLayoutBounds() != paramBoolean) {
        setShowLayoutBounds(paramBoolean);
        j0();
      } 
    } 
  }
  
  public void p() {
    if (this.z) {
      getSnapshotObserver().b();
      this.z = false;
    } 
    AndroidViewsHandler androidViewsHandler = this.E;
    if (androidViewsHandler != null)
      Z((ViewGroup)androidViewsHandler); 
    while (this.V0.w()) {
      int m = this.V0.p();
      for (byte b1 = 0; b1 < m; b1++) {
        dbxyzptlk.CI.a a1 = (dbxyzptlk.CI.a)this.V0.o()[b1];
        this.V0.G(b1, null);
        if (a1 != null)
          a1.invoke(); 
      } 
      this.V0.E(0, m);
    } 
  }
  
  public final boolean p0(MotionEvent paramMotionEvent) {
    int m = paramMotionEvent.getPointerCount();
    boolean bool2 = true;
    if (m != 1)
      return true; 
    MotionEvent motionEvent = this.o0;
    boolean bool1 = bool2;
    if (motionEvent != null) {
      bool1 = bool2;
      if (motionEvent.getPointerCount() == paramMotionEvent.getPointerCount()) {
        bool1 = bool2;
        if (paramMotionEvent.getRawX() == motionEvent.getRawX()) {
          bool1 = bool2;
          if (paramMotionEvent.getRawY() == motionEvent.getRawY())
            bool1 = false; 
        } 
      } 
    } 
    return bool1;
  }
  
  public void q(androidx.compose.ui.node.f paramf, boolean paramBoolean1, boolean paramBoolean2) {
    if (paramBoolean1) {
      if (this.I.A(paramf, paramBoolean2))
        z0(this, null, 1, null); 
    } else if (this.I.F(paramf, paramBoolean2)) {
      z0(this, null, 1, null);
    } 
  }
  
  public final void q0(S paramS, boolean paramBoolean) {
    if (!paramBoolean) {
      if (!this.u) {
        this.s.remove(paramS);
        List<S> list = this.t;
        if (list != null)
          list.remove(paramS); 
      } 
    } else if (!this.u) {
      this.s.add(paramS);
    } else {
      List<S> list2 = this.t;
      List<S> list1 = list2;
      if (list2 == null) {
        list1 = new ArrayList<>();
        this.t = list1;
      } 
      list1.add(paramS);
    } 
  }
  
  public final long r0(int paramInt1, int paramInt2) {
    long l1 = y.b(y.b(paramInt1) << 32L);
    return y.b(y.b(paramInt2) | l1);
  }
  
  public final void s0() {
    if (!this.Q) {
      long l1 = AnimationUtils.currentAnimationTimeMillis();
      if (l1 != this.P) {
        View view;
        this.P = l1;
        u0();
        ViewParent viewParent = getParent();
        AndroidComposeView androidComposeView = this;
        while (viewParent instanceof ViewGroup) {
          view = (View)viewParent;
          viewParent = ((ViewGroup)view).getParent();
        } 
        view.getLocationOnScreen(this.L);
        int[] arrayOfInt2 = this.L;
        float f1 = arrayOfInt2[0];
        float f2 = arrayOfInt2[1];
        view.getLocationInWindow(arrayOfInt2);
        int[] arrayOfInt1 = this.L;
        this.R = dbxyzptlk.P0.g.a(f1 - arrayOfInt1[0], f2 - arrayOfInt1[1]);
      } 
    } 
  }
  
  public final void setConfigurationChangeObserver(l<? super Configuration, D> paraml) {
    this.x = paraml;
  }
  
  public final void setLastMatrixRecalculationAnimationTime$ui_release(long paramLong) {
    this.P = paramLong;
  }
  
  public final void setOnViewTreeOwnersAvailable(l<? super c, D> paraml) {
    c c1 = getViewTreeOwners();
    if (c1 != null)
      paraml.invoke(c1); 
    if (!isAttachedToWindow())
      this.V = paraml; 
  }
  
  public void setShowLayoutBounds(boolean paramBoolean) {
    this.D = paramBoolean;
  }
  
  public boolean shouldDelayChildPressedState() {
    return false;
  }
  
  public long t(long paramLong) {
    s0();
    return H0.f(this.N, paramLong);
  }
  
  public final void t0(MotionEvent paramMotionEvent) {
    this.P = AnimationUtils.currentAnimationTimeMillis();
    u0();
    long l1 = H0.f(this.N, dbxyzptlk.P0.g.a(paramMotionEvent.getX(), paramMotionEvent.getY()));
    this.R = dbxyzptlk.P0.g.a(paramMotionEvent.getRawX() - dbxyzptlk.P0.f.o(l1), paramMotionEvent.getRawY() - dbxyzptlk.P0.f.p(l1));
  }
  
  public void u(androidx.compose.ui.node.f paramf) {
    this.q.y0(paramf);
  }
  
  public final void u0() {
    this.y2.a((View)this, this.N);
    t0.a(this.N, this.O);
  }
  
  public void v(androidx.compose.ui.node.f paramf, boolean paramBoolean) {
    this.I.g(paramf, paramBoolean);
  }
  
  public final boolean v0(S paramS) {
    if (this.F != null)
      ViewLayer.p.b(); 
    this.A0.c(paramS);
    return true;
  }
  
  public void w(androidx.compose.ui.node.f paramf) {}
  
  public final void w0(AndroidViewHolder paramAndroidViewHolder) {
    h((dbxyzptlk.CI.a<D>)new l(this, paramAndroidViewHolder));
  }
  
  public final void x0() {
    this.z = true;
  }
  
  public final void y0(androidx.compose.ui.node.f paramf) {
    if (!isLayoutRequested() && isAttachedToWindow()) {
      if (paramf != null) {
        while (paramf != null && paramf.d0() == androidx.compose.ui.node.f.g.InMeasureBlock && Y(paramf))
          paramf = paramf.m0(); 
        if (paramf == getRoot()) {
          requestLayout();
          return;
        } 
      } 
      if (getWidth() == 0 || getHeight() == 0) {
        requestLayout();
        return;
      } 
      invalidate();
    } 
  }
  
  public void z(androidx.compose.ui.node.f paramf) {
    this.I.t(paramf);
    x0();
  }
  
  @Metadata(d1 = {"\000\032\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\020\013\n\002\b\005\b\003\030\0002\0020\001B\007¢\006\004\b\002\020\003J\027\020\007\032\0020\0062\006\020\005\032\0020\004H\026¢\006\004\b\007\020\bJ\027\020\t\032\0020\0062\006\020\005\032\0020\004H\026¢\006\004\b\t\020\bJ\027\020\n\032\0020\0062\006\020\005\032\0020\004H\026¢\006\004\b\n\020\b¨\006\013"}, d2 = {"Landroidx/compose/ui/platform/AndroidComposeView$a;", "Landroid/view/translation/ViewTranslationCallback;", "<init>", "()V", "Landroid/view/View;", "view", "", "onShowTranslation", "(Landroid/view/View;)Z", "onHideTranslation", "onClearTranslation", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class a implements ViewTranslationCallback {
    public boolean onClearTranslation(View param1View) {
      s.f(param1View, "null cannot be cast to non-null type androidx.compose.ui.platform.AndroidComposeView");
      AndroidComposeView.I((AndroidComposeView)param1View).v0();
      return true;
    }
    
    public boolean onHideTranslation(View param1View) {
      s.f(param1View, "null cannot be cast to non-null type androidx.compose.ui.platform.AndroidComposeView");
      AndroidComposeView.I((AndroidComposeView)param1View).x0();
      return true;
    }
    
    public boolean onShowTranslation(View param1View) {
      s.f(param1View, "null cannot be cast to non-null type androidx.compose.ui.platform.AndroidComposeView");
      AndroidComposeView.I((AndroidComposeView)param1View).A0();
      return true;
    }
  }
  
  @Metadata(d1 = {"\0004\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\013\n\002\b\002\n\002\020\016\n\002\b\002\n\002\020\b\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\003\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\017\020\005\032\0020\004H\002¢\006\004\b\005\020\006R\024\020\b\032\0020\0078\002XT¢\006\006\n\004\b\b\020\tR\024\020\013\032\0020\n8\002XT¢\006\006\n\004\b\013\020\fR\030\020\016\032\004\030\0010\r8\002@\002X\016¢\006\006\n\004\b\016\020\017R\034\020\021\032\b\022\002\b\003\030\0010\0208\002@\002X\016¢\006\006\n\004\b\021\020\022¨\006\023"}, d2 = {"Landroidx/compose/ui/platform/AndroidComposeView$b;", "", "<init>", "()V", "", "b", "()Z", "", "FocusTag", "Ljava/lang/String;", "", "MaximumLayerCacheSize", "I", "Ljava/lang/reflect/Method;", "getBooleanMethod", "Ljava/lang/reflect/Method;", "Ljava/lang/Class;", "systemPropertiesClass", "Ljava/lang/Class;", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class b {
    public b() {}
    
    public final boolean b() {
      boolean bool1;
      boolean bool2 = false;
      try {
        Class clazz = AndroidComposeView.N();
        Boolean bool = null;
        if (clazz == null) {
          AndroidComposeView.S(Class.forName("android.os.SystemProperties"));
          clazz = AndroidComposeView.N();
          if (clazz != null) {
            Method method1 = clazz.getDeclaredMethod("getBoolean", new Class[] { String.class, boolean.class });
          } else {
            clazz = null;
          } 
          AndroidComposeView.Q((Method)clazz);
        } 
        Method method = AndroidComposeView.J();
        if (method != null) {
          Object object = method.invoke(null, new Object[] { "debug.layout", Boolean.FALSE });
        } else {
          method = null;
        } 
        if (method instanceof Boolean)
          bool = (Boolean)method; 
        bool1 = bool2;
        if (bool != null)
          bool1 = bool.booleanValue(); 
      } catch (Exception exception) {
        bool1 = bool2;
      } 
      return bool1;
    }
  }
  
  @Metadata(d1 = {"\000\026\n\002\030\002\n\002\020\000\n\002\030\002\n\000\n\002\030\002\n\002\b\n\b\007\030\0002\0020\001B\027\022\006\020\003\032\0020\002\022\006\020\005\032\0020\004¢\006\004\b\006\020\007R\027\020\003\032\0020\0028\006¢\006\f\n\004\b\b\020\t\032\004\b\b\020\nR\027\020\005\032\0020\0048\006¢\006\f\n\004\b\013\020\f\032\004\b\013\020\r¨\006\016"}, d2 = {"Landroidx/compose/ui/platform/AndroidComposeView$c;", "", "Landroidx/lifecycle/LifecycleOwner;", "lifecycleOwner", "Ldbxyzptlk/J4/d;", "savedStateRegistryOwner", "<init>", "(Landroidx/lifecycle/LifecycleOwner;Ldbxyzptlk/J4/d;)V", "a", "Landroidx/lifecycle/LifecycleOwner;", "()Landroidx/lifecycle/LifecycleOwner;", "b", "Ldbxyzptlk/J4/d;", "()Ldbxyzptlk/J4/d;", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class c {
    public final LifecycleOwner a;
    
    public final dbxyzptlk.J4.d b;
    
    public c(LifecycleOwner param1LifecycleOwner, dbxyzptlk.J4.d param1d) {
      this.a = param1LifecycleOwner;
      this.b = param1d;
    }
    
    public final LifecycleOwner a() {
      return this.a;
    }
    
    public final dbxyzptlk.J4.d b() {
      return this.b;
    }
  }
  
  @Metadata(d1 = {"\000\016\n\002\030\002\n\000\n\002\020\013\n\002\b\002\020\003\032\0020\0022\006\020\001\032\0020\000H\n¢\006\004\b\003\020\004"}, d2 = {"Ldbxyzptlk/X0/a;", "it", "", "a", "(I)Ljava/lang/Boolean;"}, k = 3, mv = {1, 8, 0})
  public static final class d extends u implements l<dbxyzptlk.X0.a, Boolean> {
    public final AndroidComposeView f;
    
    public d(AndroidComposeView param1AndroidComposeView) {
      super(1);
    }
    
    public final Boolean a(int param1Int) {
      boolean bool;
      dbxyzptlk.X0.a.a a = dbxyzptlk.X0.a.b;
      if (dbxyzptlk.X0.a.f(param1Int, a.b())) {
        bool = this.f.isInTouchMode();
      } else if (dbxyzptlk.X0.a.f(param1Int, a.a())) {
        if (this.f.isInTouchMode()) {
          bool = this.f.requestFocusFromTouch();
        } else {
          bool = true;
        } 
      } else {
        bool = false;
      } 
      return Boolean.valueOf(bool);
    }
  }
  
  @Metadata(d1 = {"\000\016\n\002\030\002\n\000\n\002\030\002\n\002\b\002\020\003\032\0020\0022\006\020\001\032\0020\000H\n¢\006\004\b\003\020\004"}, d2 = {"Landroid/content/res/Configuration;", "it", "Ldbxyzptlk/pI/D;", "a", "(Landroid/content/res/Configuration;)V"}, k = 3, mv = {1, 8, 0})
  public static final class f extends u implements l<Configuration, D> {
    public static final f f = new f();
    
    public f() {
      super(1);
    }
    
    public final void a(Configuration param1Configuration) {}
  }
  
  @Metadata(d1 = {"\000\f\n\002\030\002\n\002\030\002\n\002\b\003\020\003\032\0020\0012\f\020\002\032\b\022\004\022\0020\0010\000H\n¢\006\004\b\003\020\004"}, d2 = {"Lkotlin/Function0;", "Ldbxyzptlk/pI/D;", "it", "a", "(Ldbxyzptlk/CI/a;)V"}, k = 3, mv = {1, 8, 0})
  public static final class h extends u implements l<dbxyzptlk.CI.a<? extends D>, D> {
    public final AndroidComposeView f;
    
    public h(AndroidComposeView param1AndroidComposeView) {
      super(1);
    }
    
    public final void a(dbxyzptlk.CI.a<D> param1a) {
      this.f.h(param1a);
    }
  }
  
  @Metadata(d1 = {"\000\016\n\002\030\002\n\000\n\002\020\013\n\002\b\002\020\003\032\0020\0022\006\020\001\032\0020\000H\n¢\006\004\b\003\020\004"}, d2 = {"Ldbxyzptlk/Y0/b;", "it", "", "a", "(Landroid/view/KeyEvent;)Ljava/lang/Boolean;"}, k = 3, mv = {1, 8, 0})
  public static final class i extends u implements l<dbxyzptlk.Y0.b, Boolean> {
    public final AndroidComposeView f;
    
    public i(AndroidComposeView param1AndroidComposeView) {
      super(1);
    }
    
    public final Boolean a(KeyEvent param1KeyEvent) {
      androidx.compose.ui.focus.c c = this.f.d0(param1KeyEvent);
      return (c == null || !dbxyzptlk.Y0.c.e(dbxyzptlk.Y0.d.b(param1KeyEvent), dbxyzptlk.Y0.c.a.a())) ? Boolean.FALSE : Boolean.valueOf(this.f.getFocusOwner().l(c.o()));
    }
  }
  
  @Metadata(d1 = {"\000\027\n\000\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\005*\001\000\b\n\030\0002\0020\001J\031\020\005\032\0020\0042\b\020\003\032\004\030\0010\002H\026¢\006\004\b\005\020\006R\026\020\b\032\0020\0028\002@\002X\016¢\006\006\n\004\b\005\020\007¨\006\t"}, d2 = {"androidx/compose/ui/platform/AndroidComposeView$k", "Ldbxyzptlk/a1/x;", "Ldbxyzptlk/a1/v;", "value", "Ldbxyzptlk/pI/D;", "a", "(Ldbxyzptlk/a1/v;)V", "Ldbxyzptlk/a1/v;", "currentIcon", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class k implements x {
    public v a = v.a.a();
    
    public final AndroidComposeView b;
    
    public k(AndroidComposeView param1AndroidComposeView) {}
    
    public void a(v param1v) {
      v v1 = param1v;
      if (param1v == null)
        v1 = v.a.a(); 
      this.a = v1;
      L.a.a((View)this.b, v1);
    }
  }
  
  @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"Ldbxyzptlk/pI/D;", "b", "()V"}, k = 3, mv = {1, 8, 0})
  public static final class m extends u implements dbxyzptlk.CI.a<D> {
    public final AndroidComposeView f;
    
    public m(AndroidComposeView param1AndroidComposeView) {
      super(0);
    }
    
    public final void b() {
      MotionEvent motionEvent = AndroidComposeView.K(this.f);
      if (motionEvent != null) {
        int i = motionEvent.getActionMasked();
        if (i == 7 || i == 9) {
          AndroidComposeView.R(this.f, SystemClock.uptimeMillis());
          AndroidComposeView androidComposeView = this.f;
          androidComposeView.post(AndroidComposeView.M(androidComposeView));
        } 
      } 
    }
  }
  
  @Metadata(d1 = {"\000\021\n\000\n\002\030\002\n\002\030\002\n\002\b\003*\001\000\b\n\030\0002\0020\001J\017\020\003\032\0020\002H\026¢\006\004\b\003\020\004¨\006\005"}, d2 = {"androidx/compose/ui/platform/AndroidComposeView$n", "Ljava/lang/Runnable;", "Ldbxyzptlk/pI/D;", "run", "()V", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class n implements Runnable {
    public final AndroidComposeView a;
    
    public n(AndroidComposeView param1AndroidComposeView) {}
    
    public void run() {
      this.a.removeCallbacks(this);
      MotionEvent motionEvent = AndroidComposeView.K(this.a);
      if (motionEvent != null) {
        byte b = 0;
        if (motionEvent.getToolType(0) == 3)
          b = 1; 
        int i = motionEvent.getActionMasked();
        if (b ? (i != 10 && i != 1) : (i != 1)) {
          byte b1 = 7;
          b = b1;
          if (i != 7) {
            b = b1;
            if (i != 9)
              b = 2; 
          } 
          AndroidComposeView androidComposeView = this.a;
          AndroidComposeView.P(androidComposeView, motionEvent, b, AndroidComposeView.L(androidComposeView), false);
        } 
      } 
    }
  }
  
  @Metadata(d1 = {"\000\016\n\002\030\002\n\000\n\002\020\013\n\002\b\002\020\003\032\0020\0022\006\020\001\032\0020\000H\n¢\006\004\b\003\020\004"}, d2 = {"Ldbxyzptlk/c1/c;", "it", "", "a", "(Ldbxyzptlk/c1/c;)Ljava/lang/Boolean;"}, k = 3, mv = {1, 8, 0})
  public static final class o extends u implements l<dbxyzptlk.c1.c, Boolean> {
    public static final o f = new o();
    
    public o() {
      super(1);
    }
    
    public final Boolean a(dbxyzptlk.c1.c param1c) {
      return Boolean.FALSE;
    }
  }
  
  @Metadata(d1 = {"\000\f\n\002\030\002\n\002\030\002\n\002\b\003\020\003\032\0020\0012\f\020\002\032\b\022\004\022\0020\0010\000H\n¢\006\004\b\003\020\004"}, d2 = {"Lkotlin/Function0;", "Ldbxyzptlk/pI/D;", "command", "b", "(Ldbxyzptlk/CI/a;)V"}, k = 3, mv = {1, 8, 0})
  public static final class p extends u implements l<dbxyzptlk.CI.a<? extends D>, D> {
    public final AndroidComposeView f;
    
    public p(AndroidComposeView param1AndroidComposeView) {
      super(1);
    }
    
    public static final void c(dbxyzptlk.CI.a param1a) {
      param1a.invoke();
    }
    
    public final void b(dbxyzptlk.CI.a<D> param1a) {
      Handler handler = this.f.getHandler();
      if (handler != null) {
        Looper looper = handler.getLooper();
      } else {
        handler = null;
      } 
      if (handler == Looper.myLooper()) {
        param1a.invoke();
      } else {
        handler = this.f.getHandler();
        if (handler != null)
          handler.post((Runnable)new dbxyzptlk.g1.m(param1a)); 
      } 
    }
  }
  
  @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\004\030\0010\000H\n¢\006\004\b\001\020\002"}, d2 = {"Landroidx/compose/ui/platform/AndroidComposeView$c;", "b", "()Landroidx/compose/ui/platform/AndroidComposeView$c;"}, k = 3, mv = {1, 8, 0})
  public static final class q extends u implements dbxyzptlk.CI.a<c> {
    public final AndroidComposeView f;
    
    public q(AndroidComposeView param1AndroidComposeView) {
      super(0);
    }
    
    public final AndroidComposeView.c b() {
      return AndroidComposeView.O(this.f);
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compos\\ui\platform\AndroidComposeView.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */