package androidx.compose.ui.platform;

import dbxyzptlk.CI.l;
import dbxyzptlk.CI.p;
import dbxyzptlk.DI.u;
import dbxyzptlk.I0.k;
import dbxyzptlk.bK.J;
import dbxyzptlk.bK.K;
import dbxyzptlk.bK.h;
import dbxyzptlk.dK.d;
import dbxyzptlk.dK.f;
import dbxyzptlk.dK.g;
import dbxyzptlk.dK.k;
import dbxyzptlk.dK.s;
import dbxyzptlk.pI.D;
import dbxyzptlk.pI.p;
import dbxyzptlk.tI.d;
import dbxyzptlk.uI.c;
import dbxyzptlk.vI.f;
import dbxyzptlk.vI.l;
import java.util.concurrent.atomic.AtomicBoolean;
import kotlin.Metadata;

@Metadata(d1 = {"\000\032\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\005\bÀ\002\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\r\020\005\032\0020\004¢\006\004\b\005\020\003R\024\020\b\032\0020\0068\002X\004¢\006\006\n\004\b\005\020\007R\024\020\n\032\0020\0068\002X\004¢\006\006\n\004\b\t\020\007¨\006\013"}, d2 = {"Landroidx/compose/ui/platform/i;", "", "<init>", "()V", "Ldbxyzptlk/pI/D;", "b", "Ljava/util/concurrent/atomic/AtomicBoolean;", "Ljava/util/concurrent/atomic/AtomicBoolean;", "started", "c", "sent", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class i {
  public static final i a = new i();
  
  public static final AtomicBoolean b = new AtomicBoolean(false);
  
  public static final AtomicBoolean c = new AtomicBoolean(false);
  
  public static final int d = 8;
  
  public final void b() {
    if (b.compareAndSet(false, true)) {
      d<D> d = g.b(1, null, null, 6, null);
      h.d(K.a(h.m.b()), null, null, new a(d, null), 3, null);
      k.e.i(new b(d));
    } 
  }
  
  @f(c = "androidx.compose.ui.platform.GlobalSnapshotManager$ensureStarted$1", f = "GlobalSnapshotManager.android.kt", l = {67}, m = "invokeSuspend")
  @Metadata(d1 = {"\000\f\n\002\030\002\n\002\030\002\n\002\b\002\020\002\032\0020\001*\0020\000H@¢\006\004\b\002\020\003"}, d2 = {"Ldbxyzptlk/bK/J;", "Ldbxyzptlk/pI/D;", "<anonymous>", "(Ldbxyzptlk/bK/J;)V"}, k = 3, mv = {1, 8, 0})
  public static final class a extends l implements p<J, d<? super D>, Object> {
    public Object t;
    
    public Object u;
    
    public int v;
    
    public final d<D> w;
    
    public a(d<D> param1d, d<? super a> param1d1) {
      super(2, param1d1);
    }
    
    public final d<D> create(Object param1Object, d<?> param1d) {
      return (d<D>)new a(this.w, (d)param1d);
    }
    
    public final Object invoke(J param1J, d<? super D> param1d) {
      return ((a)create(param1J, param1d)).invokeSuspend(D.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      d<D> d2;
      f f;
      Object object = c.g();
      int i = this.v;
      if (i != 0) {
        if (i == 1) {
          f = (f)this.u;
          s s2 = (s)this.t;
          s s1 = s2;
          try {
            p.b(param1Object);
          } finally {}
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        p.b(param1Object);
        d2 = this.w;
        d<D> d3 = d2;
        f = d2.iterator();
        d3 = d2;
      } 
      d<D> d1 = d2;
      if (((Boolean)param1Object).booleanValue()) {
        d1 = d2;
        param1Object = f.next();
        d1 = d2;
        i.a().set(false);
        d1 = d2;
        k.e.k();
      } else {
        d1 = d2;
        param1Object = D.a;
        k.a((s)d2, null);
        return D.a;
      } 
      d1 = d2;
    }
  }
  
  @Metadata(d1 = {"\000\016\n\002\020\000\n\000\n\002\030\002\n\002\b\002\020\003\032\0020\0022\006\020\001\032\0020\000H\n¢\006\004\b\003\020\004"}, d2 = {"", "it", "Ldbxyzptlk/pI/D;", "a", "(Ljava/lang/Object;)V"}, k = 3, mv = {1, 8, 0})
  public static final class b extends u implements l<Object, D> {
    public final d<D> f;
    
    public b(d<D> param1d) {
      super(1);
    }
    
    public final void a(Object param1Object) {
      if (i.a().compareAndSet(false, true))
        this.f.k(D.a); 
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compos\\ui\platform\i.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */