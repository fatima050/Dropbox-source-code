package androidx.compose.ui.platform;

import android.view.View;
import android.view.ViewGroup;
import androidx.compose.ui.node.f;
import dbxyzptlk.CI.p;
import dbxyzptlk.K0.h;
import dbxyzptlk.f1.i0;
import dbxyzptlk.g1.p0;
import dbxyzptlk.pI.D;
import dbxyzptlk.x0.I0;
import dbxyzptlk.x0.e;
import dbxyzptlk.x0.k;
import dbxyzptlk.x0.o;
import dbxyzptlk.x0.p;
import dbxyzptlk.x0.s;
import java.util.Collections;
import java.util.WeakHashMap;
import kotlin.Metadata;

@Metadata(d1 = {"\000:\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\032\037\020\005\032\0020\0042\006\020\001\032\0020\0002\006\020\003\032\0020\002H\001¢\006\004\b\005\020\006\032)\020\f\032\0020\013*\0020\0072\006\020\003\032\0020\0022\f\020\n\032\b\022\004\022\0020\t0\bH\000¢\006\004\b\f\020\r\032-\020\020\032\0020\0132\006\020\017\032\0020\0162\006\020\003\032\0020\0022\f\020\n\032\b\022\004\022\0020\t0\bH\002¢\006\004\b\020\020\021\"\024\020\024\032\0020\0228\002X\004¢\006\006\n\004\b\005\020\023¨\006\025"}, d2 = {"Landroidx/compose/ui/node/f;", "container", "Ldbxyzptlk/x0/p;", "parent", "Ldbxyzptlk/x0/I0;", "a", "(Landroidx/compose/ui/node/f;Ldbxyzptlk/x0/p;)Ldbxyzptlk/x0/I0;", "Landroidx/compose/ui/platform/AbstractComposeView;", "Lkotlin/Function0;", "Ldbxyzptlk/pI/D;", "content", "Ldbxyzptlk/x0/o;", "c", "(Landroidx/compose/ui/platform/AbstractComposeView;Ldbxyzptlk/x0/p;Ldbxyzptlk/CI/p;)Ldbxyzptlk/x0/o;", "Landroidx/compose/ui/platform/AndroidComposeView;", "owner", "b", "(Landroidx/compose/ui/platform/AndroidComposeView;Ldbxyzptlk/x0/p;Ldbxyzptlk/CI/p;)Ldbxyzptlk/x0/o;", "Landroid/view/ViewGroup$LayoutParams;", "Landroid/view/ViewGroup$LayoutParams;", "DefaultLayoutParams", "ui_release"}, k = 2, mv = {1, 8, 0}, xi = 48)
public final class l {
  public static final ViewGroup.LayoutParams a = new ViewGroup.LayoutParams(-2, -2);
  
  public static final I0 a(f paramf, p paramp) {
    return s.b((e)new i0(paramf), paramp);
  }
  
  public static final o b(AndroidComposeView paramAndroidComposeView, p paramp, p<? super k, ? super Integer, D> paramp1) {
    if (p0.c() && paramAndroidComposeView.getTag(h.inspection_slot_table_set) == null)
      paramAndroidComposeView.setTag(h.inspection_slot_table_set, Collections.newSetFromMap(new WeakHashMap<>())); 
    o o = s.a((e)new i0(paramAndroidComposeView.getRoot()), paramp);
    Object object1 = paramAndroidComposeView.getView().getTag(h.wrapped_composition_tag);
    if (object1 instanceof WrappedComposition) {
      object1 = object1;
    } else {
      object1 = null;
    } 
    Object object2 = object1;
    if (object1 == null) {
      object2 = new WrappedComposition(paramAndroidComposeView, o);
      paramAndroidComposeView.getView().setTag(h.wrapped_composition_tag, object2);
    } 
    object2.u(paramp1);
    return (o)object2;
  }
  
  public static final o c(AbstractComposeView paramAbstractComposeView, p paramp, p<? super k, ? super Integer, D> paramp1) {
    i.a.b();
    int i = paramAbstractComposeView.getChildCount();
    AndroidComposeView androidComposeView1 = null;
    if (i > 0) {
      View view = paramAbstractComposeView.getChildAt(0);
      if (view instanceof AndroidComposeView)
        androidComposeView1 = (AndroidComposeView)view; 
    } else {
      paramAbstractComposeView.removeAllViews();
    } 
    AndroidComposeView androidComposeView2 = androidComposeView1;
    if (androidComposeView1 == null) {
      androidComposeView2 = new AndroidComposeView(paramAbstractComposeView.getContext(), paramp.h());
      paramAbstractComposeView.addView(androidComposeView2.getView(), a);
    } 
    return b(androidComposeView2, paramp, paramp1);
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compos\\ui\platform\l.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */