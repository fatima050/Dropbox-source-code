package androidx.compose.ui.platform;

import androidx.lifecycle.LifecycleEventObserver;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.f;
import dbxyzptlk.CI.l;
import dbxyzptlk.CI.p;
import dbxyzptlk.DI.S;
import dbxyzptlk.DI.u;
import dbxyzptlk.F0.c;
import dbxyzptlk.J0.d;
import dbxyzptlk.K0.h;
import dbxyzptlk.U2.h;
import dbxyzptlk.bK.J;
import dbxyzptlk.g1.c0;
import dbxyzptlk.pI.D;
import dbxyzptlk.pI.p;
import dbxyzptlk.tI.d;
import dbxyzptlk.uI.c;
import dbxyzptlk.vI.f;
import dbxyzptlk.vI.l;
import dbxyzptlk.x0.J;
import dbxyzptlk.x0.k;
import dbxyzptlk.x0.n;
import dbxyzptlk.x0.o;
import dbxyzptlk.x0.u;
import kotlin.Metadata;

@Metadata(d1 = {"\000B\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\000\n\002\030\002\n\002\b\004\n\002\030\002\n\002\030\002\n\002\b\005\n\002\030\002\n\000\n\002\030\002\n\002\b\013\n\002\020\013\n\002\b\003\n\002\030\002\n\002\b\t\b\002\030\0002\0020\0012\0020\0022\0020\003B\027\022\006\020\005\032\0020\004\022\006\020\006\032\0020\001¢\006\004\b\007\020\bJ\035\020\f\032\0020\n2\f\020\013\032\b\022\004\022\0020\n0\tH\026¢\006\004\b\f\020\rJ\017\020\016\032\0020\nH\026¢\006\004\b\016\020\017J\037\020\024\032\0020\n2\006\020\021\032\0020\0202\006\020\023\032\0020\022H\026¢\006\004\b\024\020\025R\027\020\005\032\0020\0048\006¢\006\f\n\004\b\026\020\027\032\004\b\030\020\031R\027\020\006\032\0020\0018\006¢\006\f\n\004\b\032\020\033\032\004\b\034\020\035R\026\020!\032\0020\0368\002@\002X\016¢\006\006\n\004\b\037\020 R\030\020%\032\004\030\0010\"8\002@\002X\016¢\006\006\n\004\b#\020$R\034\020(\032\b\022\004\022\0020\n0\t8\002@\002X\016¢\006\006\n\004\b&\020'R\024\020)\032\0020\0368VX\004¢\006\006\032\004\b)\020*¨\006+"}, d2 = {"Landroidx/compose/ui/platform/WrappedComposition;", "Ldbxyzptlk/x0/o;", "Landroidx/lifecycle/LifecycleEventObserver;", "", "Landroidx/compose/ui/platform/AndroidComposeView;", "owner", "original", "<init>", "(Landroidx/compose/ui/platform/AndroidComposeView;Ldbxyzptlk/x0/o;)V", "Lkotlin/Function0;", "Ldbxyzptlk/pI/D;", "content", "u", "(Ldbxyzptlk/CI/p;)V", "dispose", "()V", "Landroidx/lifecycle/LifecycleOwner;", "source", "Landroidx/lifecycle/f$a;", "event", "f", "(Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/f$a;)V", "a", "Landroidx/compose/ui/platform/AndroidComposeView;", "D", "()Landroidx/compose/ui/platform/AndroidComposeView;", "b", "Ldbxyzptlk/x0/o;", "C", "()Ldbxyzptlk/x0/o;", "", "c", "Z", "disposed", "Landroidx/lifecycle/f;", "d", "Landroidx/lifecycle/f;", "addedToLifecycle", "e", "Ldbxyzptlk/CI/p;", "lastContent", "isDisposed", "()Z", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
final class WrappedComposition implements o, LifecycleEventObserver {
  public final AndroidComposeView a;
  
  public final o b;
  
  public boolean c;
  
  public f d;
  
  public p<? super k, ? super Integer, D> e;
  
  public WrappedComposition(AndroidComposeView paramAndroidComposeView, o paramo) {
    this.a = paramAndroidComposeView;
    this.b = paramo;
    this.e = c0.a.a();
  }
  
  public final o C() {
    return this.b;
  }
  
  public final AndroidComposeView D() {
    return this.a;
  }
  
  public void dispose() {
    if (!this.c) {
      this.c = true;
      this.a.getView().setTag(h.wrapped_composition_tag, null);
      f f1 = this.d;
      if (f1 != null)
        f1.d((h)this); 
    } 
    this.b.dispose();
  }
  
  public void f(LifecycleOwner paramLifecycleOwner, f.a parama) {
    if (parama == f.a.ON_DESTROY) {
      dispose();
    } else if (parama == f.a.ON_CREATE && !this.c) {
      u(this.e);
    } 
  }
  
  public boolean isDisposed() {
    return this.b.isDisposed();
  }
  
  public void u(p<? super k, ? super Integer, D> paramp) {
    this.a.setOnViewTreeOwnersAvailable(new a(this, paramp));
  }
  
  @Metadata(d1 = {"\000\016\n\002\030\002\n\000\n\002\030\002\n\002\b\002\020\003\032\0020\0022\006\020\001\032\0020\000H\n¢\006\004\b\003\020\004"}, d2 = {"Landroidx/compose/ui/platform/AndroidComposeView$c;", "it", "Ldbxyzptlk/pI/D;", "a", "(Landroidx/compose/ui/platform/AndroidComposeView$c;)V"}, k = 3, mv = {1, 8, 0})
  public static final class a extends u implements l<AndroidComposeView.c, D> {
    public final WrappedComposition f;
    
    public final p<k, Integer, D> g;
    
    public a(WrappedComposition param1WrappedComposition, p<? super k, ? super Integer, D> param1p) {
      super(1);
    }
    
    public final void a(AndroidComposeView.c param1c) {
      if (!WrappedComposition.z(this.f)) {
        f f = param1c.a().getLifecycle();
        WrappedComposition.B(this.f, this.g);
        if (WrappedComposition.d(this.f) == null) {
          WrappedComposition.A(this.f, f);
          f.a((h)this.f);
        } else if (f.b().isAtLeast(f.b.CREATED)) {
          this.f.C().u((p)c.c(-2000640158, true, new a(this.f, this.g)));
        } 
      } 
    }
    
    @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\013¢\006\004\b\001\020\002"}, d2 = {"Ldbxyzptlk/pI/D;", "a", "(Ldbxyzptlk/x0/k;I)V"}, k = 3, mv = {1, 8, 0})
    public static final class a extends u implements p<k, Integer, D> {
      public final WrappedComposition f;
      
      public final p<k, Integer, D> g;
      
      public a(WrappedComposition param2WrappedComposition, p<? super k, ? super Integer, D> param2p) {
        super(2);
      }
      
      public final void a(k param2k, int param2Int) {
        if ((param2Int & 0xB) != 2 || !param2k.b()) {
          Object object1;
          if (n.I())
            n.U(-2000640158, param2Int, -1, "androidx.compose.ui.platform.WrappedComposition.setContent.<anonymous>.<anonymous> (Wrapper.android.kt:124)"); 
          Object object = this.f.D().getTag(h.inspection_slot_table_set);
          if (S.r(object)) {
            object1 = object;
          } else {
            object1 = null;
          } 
          object = object1;
          if (object1 == null) {
            object = this.f.D().getParent();
            if (object instanceof android.view.View) {
              object = object;
            } else {
              object = null;
            } 
            if (object != null) {
              object = object.getTag(h.inspection_slot_table_set);
            } else {
              object = null;
            } 
            if (S.r(object)) {
              object = object;
            } else {
              object = null;
            } 
          } 
          if (object != null) {
            object.add(param2k.K());
            param2k.F();
          } 
          J.d(this.f.D(), new a(this.f, null), param2k, 72);
          u.a(d.a().c(object), (p)c.b(param2k, -1193460702, true, new b(this.f, this.g)), param2k, 56);
          if (n.I())
            n.T(); 
          return;
        } 
        param2k.k();
      }
      
      @f(c = "androidx.compose.ui.platform.WrappedComposition$setContent$1$1$1", f = "Wrapper.android.kt", l = {136}, m = "invokeSuspend")
      @Metadata(d1 = {"\000\f\n\002\030\002\n\002\030\002\n\002\b\002\020\002\032\0020\001*\0020\000H@¢\006\004\b\002\020\003"}, d2 = {"Ldbxyzptlk/bK/J;", "Ldbxyzptlk/pI/D;", "<anonymous>", "(Ldbxyzptlk/bK/J;)V"}, k = 3, mv = {1, 8, 0})
      public static final class a extends l implements p<J, d<? super D>, Object> {
        public int t;
        
        public final WrappedComposition u;
        
        public a(WrappedComposition param3WrappedComposition, d<? super a> param3d) {
          super(2, param3d);
        }
        
        public final d<D> create(Object param3Object, d<?> param3d) {
          return (d<D>)new a(this.u, (d)param3d);
        }
        
        public final Object invoke(J param3J, d<? super D> param3d) {
          return ((a)create(param3J, param3d)).invokeSuspend(D.a);
        }
        
        public final Object invokeSuspend(Object param3Object) {
          Object object = c.g();
          int i = this.t;
          if (i != 0) {
            if (i == 1) {
              p.b(param3Object);
            } else {
              throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            } 
          } else {
            p.b(param3Object);
            param3Object = this.u.D();
            this.t = 1;
            if (param3Object.X((d<? super D>)this) == object)
              return object; 
          } 
          return D.a;
        }
      }
      
      @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\013¢\006\004\b\001\020\002"}, d2 = {"Ldbxyzptlk/pI/D;", "a", "(Ldbxyzptlk/x0/k;I)V"}, k = 3, mv = {1, 8, 0})
      public static final class b extends u implements p<k, Integer, D> {
        public final WrappedComposition f;
        
        public final p<k, Integer, D> g;
        
        public b(WrappedComposition param3WrappedComposition, p<? super k, ? super Integer, D> param3p) {
          super(2);
        }
        
        public final void a(k param3k, int param3Int) {
          if ((param3Int & 0xB) != 2 || !param3k.b()) {
            if (n.I())
              n.U(-1193460702, param3Int, -1, "androidx.compose.ui.platform.WrappedComposition.setContent.<anonymous>.<anonymous>.<anonymous> (Wrapper.android.kt:138)"); 
            g.a(this.f.D(), this.g, param3k, 8);
            if (n.I())
              n.T(); 
            return;
          } 
          param3k.k();
        }
      }
    }
    
    @f(c = "androidx.compose.ui.platform.WrappedComposition$setContent$1$1$1", f = "Wrapper.android.kt", l = {136}, m = "invokeSuspend")
    @Metadata(d1 = {"\000\f\n\002\030\002\n\002\030\002\n\002\b\002\020\002\032\0020\001*\0020\000H@¢\006\004\b\002\020\003"}, d2 = {"Ldbxyzptlk/bK/J;", "Ldbxyzptlk/pI/D;", "<anonymous>", "(Ldbxyzptlk/bK/J;)V"}, k = 3, mv = {1, 8, 0})
    public static final class a extends l implements p<J, d<? super D>, Object> {
      public int t;
      
      public final WrappedComposition u;
      
      public a(WrappedComposition param2WrappedComposition, d<? super a> param2d) {
        super(2, param2d);
      }
      
      public final d<D> create(Object param2Object, d<?> param2d) {
        return (d<D>)new a(this.u, (d)param2d);
      }
      
      public final Object invoke(J param2J, d<? super D> param2d) {
        return ((a)create(param2J, param2d)).invokeSuspend(D.a);
      }
      
      public final Object invokeSuspend(Object param2Object) {
        Object object = c.g();
        int i = this.t;
        if (i != 0) {
          if (i == 1) {
            p.b(param2Object);
          } else {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
          } 
        } else {
          p.b(param2Object);
          param2Object = this.u.D();
          this.t = 1;
          if (param2Object.X((d<? super D>)this) == object)
            return object; 
        } 
        return D.a;
      }
    }
    
    @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\013¢\006\004\b\001\020\002"}, d2 = {"Ldbxyzptlk/pI/D;", "a", "(Ldbxyzptlk/x0/k;I)V"}, k = 3, mv = {1, 8, 0})
    public static final class b extends u implements p<k, Integer, D> {
      public final WrappedComposition f;
      
      public final p<k, Integer, D> g;
      
      public b(WrappedComposition param2WrappedComposition, p<? super k, ? super Integer, D> param2p) {
        super(2);
      }
      
      public final void a(k param2k, int param2Int) {
        if ((param2Int & 0xB) != 2 || !param2k.b()) {
          if (n.I())
            n.U(-1193460702, param2Int, -1, "androidx.compose.ui.platform.WrappedComposition.setContent.<anonymous>.<anonymous>.<anonymous> (Wrapper.android.kt:138)"); 
          g.a(this.f.D(), this.g, param2k, 8);
          if (n.I())
            n.T(); 
          return;
        } 
        param2k.k();
      }
    }
  }
  
  @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\013¢\006\004\b\001\020\002"}, d2 = {"Ldbxyzptlk/pI/D;", "a", "(Ldbxyzptlk/x0/k;I)V"}, k = 3, mv = {1, 8, 0})
  public static final class a extends u implements p<k, Integer, D> {
    public final WrappedComposition f;
    
    public final p<k, Integer, D> g;
    
    public a(WrappedComposition param1WrappedComposition, p<? super k, ? super Integer, D> param1p) {
      super(2);
    }
    
    public final void a(k param1k, int param1Int) {
      if ((param1Int & 0xB) != 2 || !param1k.b()) {
        Object object1;
        if (n.I())
          n.U(-2000640158, param1Int, -1, "androidx.compose.ui.platform.WrappedComposition.setContent.<anonymous>.<anonymous> (Wrapper.android.kt:124)"); 
        Object object = this.f.D().getTag(h.inspection_slot_table_set);
        if (S.r(object)) {
          object1 = object;
        } else {
          object1 = null;
        } 
        object = object1;
        if (object1 == null) {
          object = this.f.D().getParent();
          if (object instanceof android.view.View) {
            object = object;
          } else {
            object = null;
          } 
          if (object != null) {
            object = object.getTag(h.inspection_slot_table_set);
          } else {
            object = null;
          } 
          if (S.r(object)) {
            object = object;
          } else {
            object = null;
          } 
        } 
        if (object != null) {
          object.add(param1k.K());
          param1k.F();
        } 
        J.d(this.f.D(), new a(this.f, null), param1k, 72);
        u.a(d.a().c(object), (p)c.b(param1k, -1193460702, true, new b(this.f, this.g)), param1k, 56);
        if (n.I())
          n.T(); 
        return;
      } 
      param1k.k();
    }
    
    @f(c = "androidx.compose.ui.platform.WrappedComposition$setContent$1$1$1", f = "Wrapper.android.kt", l = {136}, m = "invokeSuspend")
    @Metadata(d1 = {"\000\f\n\002\030\002\n\002\030\002\n\002\b\002\020\002\032\0020\001*\0020\000H@¢\006\004\b\002\020\003"}, d2 = {"Ldbxyzptlk/bK/J;", "Ldbxyzptlk/pI/D;", "<anonymous>", "(Ldbxyzptlk/bK/J;)V"}, k = 3, mv = {1, 8, 0})
    public static final class a extends l implements p<J, d<? super D>, Object> {
      public int t;
      
      public final WrappedComposition u;
      
      public a(WrappedComposition param3WrappedComposition, d<? super a> param3d) {
        super(2, param3d);
      }
      
      public final d<D> create(Object param3Object, d<?> param3d) {
        return (d<D>)new a(this.u, (d)param3d);
      }
      
      public final Object invoke(J param3J, d<? super D> param3d) {
        return ((a)create(param3J, param3d)).invokeSuspend(D.a);
      }
      
      public final Object invokeSuspend(Object param3Object) {
        Object object = c.g();
        int i = this.t;
        if (i != 0) {
          if (i == 1) {
            p.b(param3Object);
          } else {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
          } 
        } else {
          p.b(param3Object);
          param3Object = this.u.D();
          this.t = 1;
          if (param3Object.X((d<? super D>)this) == object)
            return object; 
        } 
        return D.a;
      }
    }
    
    @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\013¢\006\004\b\001\020\002"}, d2 = {"Ldbxyzptlk/pI/D;", "a", "(Ldbxyzptlk/x0/k;I)V"}, k = 3, mv = {1, 8, 0})
    public static final class b extends u implements p<k, Integer, D> {
      public final WrappedComposition f;
      
      public final p<k, Integer, D> g;
      
      public b(WrappedComposition param3WrappedComposition, p<? super k, ? super Integer, D> param3p) {
        super(2);
      }
      
      public final void a(k param3k, int param3Int) {
        if ((param3Int & 0xB) != 2 || !param3k.b()) {
          if (n.I())
            n.U(-1193460702, param3Int, -1, "androidx.compose.ui.platform.WrappedComposition.setContent.<anonymous>.<anonymous>.<anonymous> (Wrapper.android.kt:138)"); 
          g.a(this.f.D(), this.g, param3k, 8);
          if (n.I())
            n.T(); 
          return;
        } 
        param3k.k();
      }
    }
  }
  
  @f(c = "androidx.compose.ui.platform.WrappedComposition$setContent$1$1$1", f = "Wrapper.android.kt", l = {136}, m = "invokeSuspend")
  @Metadata(d1 = {"\000\f\n\002\030\002\n\002\030\002\n\002\b\002\020\002\032\0020\001*\0020\000H@¢\006\004\b\002\020\003"}, d2 = {"Ldbxyzptlk/bK/J;", "Ldbxyzptlk/pI/D;", "<anonymous>", "(Ldbxyzptlk/bK/J;)V"}, k = 3, mv = {1, 8, 0})
  public static final class a extends l implements p<J, d<? super D>, Object> {
    public int t;
    
    public final WrappedComposition u;
    
    public a(WrappedComposition param1WrappedComposition, d<? super a> param1d) {
      super(2, param1d);
    }
    
    public final d<D> create(Object param1Object, d<?> param1d) {
      return (d<D>)new a(this.u, (d)param1d);
    }
    
    public final Object invoke(J param1J, d<? super D> param1d) {
      return ((a)create(param1J, param1d)).invokeSuspend(D.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = c.g();
      int i = this.t;
      if (i != 0) {
        if (i == 1) {
          p.b(param1Object);
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        p.b(param1Object);
        param1Object = this.u.D();
        this.t = 1;
        if (param1Object.X((d<? super D>)this) == object)
          return object; 
      } 
      return D.a;
    }
  }
  
  @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\013¢\006\004\b\001\020\002"}, d2 = {"Ldbxyzptlk/pI/D;", "a", "(Ldbxyzptlk/x0/k;I)V"}, k = 3, mv = {1, 8, 0})
  public static final class b extends u implements p<k, Integer, D> {
    public final WrappedComposition f;
    
    public final p<k, Integer, D> g;
    
    public b(WrappedComposition param1WrappedComposition, p<? super k, ? super Integer, D> param1p) {
      super(2);
    }
    
    public final void a(k param1k, int param1Int) {
      if ((param1Int & 0xB) != 2 || !param1k.b()) {
        if (n.I())
          n.U(-1193460702, param1Int, -1, "androidx.compose.ui.platform.WrappedComposition.setContent.<anonymous>.<anonymous>.<anonymous> (Wrapper.android.kt:138)"); 
        g.a(this.f.D(), this.g, param1k, 8);
        if (n.I())
          n.T(); 
        return;
      } 
      param1k.k();
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compos\\ui\platform\WrappedComposition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */