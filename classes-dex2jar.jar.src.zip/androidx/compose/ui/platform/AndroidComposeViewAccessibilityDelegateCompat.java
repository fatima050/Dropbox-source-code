package androidx.compose.ui.platform;

import android.accessibilityservice.AccessibilityServiceInfo;
import android.graphics.Rect;
import android.graphics.RectF;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Parcelable;
import android.os.SystemClock;
import android.text.SpannableString;
import android.util.LongSparseArray;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewStructure;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityManager;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityNodeProvider;
import android.view.autofill.AutofillId;
import android.view.translation.ViewTranslationRequest;
import android.view.translation.ViewTranslationResponse;
import androidx.compose.ui.node.Owner;
import androidx.compose.ui.node.f;
import androidx.compose.ui.node.l;
import androidx.compose.ui.viewinterop.AndroidViewHolder;
import androidx.lifecycle.DefaultLifecycleObserver;
import androidx.lifecycle.LifecycleOwner;
import dbxyzptlk.CI.l;
import dbxyzptlk.CI.p;
import dbxyzptlk.DI.s;
import dbxyzptlk.DI.u;
import dbxyzptlk.GI.c;
import dbxyzptlk.K0.h;
import dbxyzptlk.P0.f;
import dbxyzptlk.P0.g;
import dbxyzptlk.P0.h;
import dbxyzptlk.Q0.T0;
import dbxyzptlk.V.F;
import dbxyzptlk.V.b;
import dbxyzptlk.dK.g;
import dbxyzptlk.f1.K;
import dbxyzptlk.f1.T;
import dbxyzptlk.f1.g;
import dbxyzptlk.f1.h;
import dbxyzptlk.g1.A;
import dbxyzptlk.g1.B;
import dbxyzptlk.g1.C;
import dbxyzptlk.g1.D;
import dbxyzptlk.g1.c;
import dbxyzptlk.g1.p;
import dbxyzptlk.g1.w1;
import dbxyzptlk.g1.x1;
import dbxyzptlk.h2.a;
import dbxyzptlk.i2.t;
import dbxyzptlk.i2.u;
import dbxyzptlk.j1.c;
import dbxyzptlk.l1.g;
import dbxyzptlk.l1.h;
import dbxyzptlk.l1.j;
import dbxyzptlk.l1.l;
import dbxyzptlk.l1.m;
import dbxyzptlk.l1.p;
import dbxyzptlk.l1.s;
import dbxyzptlk.l1.t;
import dbxyzptlk.l1.w;
import dbxyzptlk.n1.E;
import dbxyzptlk.n1.F;
import dbxyzptlk.n1.J;
import dbxyzptlk.pI.D;
import dbxyzptlk.qI.A;
import dbxyzptlk.qI.P;
import dbxyzptlk.qI.s;
import dbxyzptlk.qI.w;
import dbxyzptlk.s1.l;
import dbxyzptlk.v1.t;
import dbxyzptlk.vI.f;
import dbxyzptlk.z1.t;
import dbxyzptlk.z1.v;
import io.sentry.android.core.r0;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Consumer;
import kotlin.Metadata;
import kotlin.NoWhenBranchMatchedException;
import kotlin.jvm.internal.DefaultConstructorMarker;

@Metadata(d1 = {"\000À\003\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\003\n\002\020\036\n\002\030\002\n\000\n\002\020\013\n\000\n\002\020\b\n\000\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\020%\n\002\020!\n\002\b\006\n\002\030\002\n\002\b\t\n\002\030\002\n\002\b\006\n\002\020\016\n\002\b\005\n\002\030\002\n\002\b\b\n\002\020 \n\002\b\003\n\002\030\002\n\002\b\b\n\002\020\r\n\002\b\005\n\002\030\002\n\002\b\007\n\002\030\002\n\000\n\002\030\002\n\002\b\b\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\005\n\002\020$\n\002\b\007\n\002\030\002\n\002\b\n\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\020\n\002\030\002\n\002\b\027\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\002\n\002\020\007\n\002\b\005\n\002\030\002\n\002\b\t\n\002\020\026\n\000\n\002\020\025\n\000\n\002\030\002\n\002\030\002\n\002\b\003\n\002\030\002\n\002\030\002\n\002\b\r\n\002\030\002\n\002\b\b\n\002\030\002\n\002\b\n\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\r\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\f\n\002\030\002\n\002\b\021\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\023\n\002\030\002\n\002\b\006\n\002\030\002\n\002\b\021\b\000\030\000 »\0012\0020\0012\0020\002:\026ÿ\002\003ë\001ï\001ö\001ÿ\001\002\002\002\002\002B\017\022\006\020\004\032\0020\003¢\006\004\b\005\020\006J8\020\020\032\0020\n2\f\020\t\032\b\022\004\022\0020\b0\0072\006\020\013\032\0020\n2\006\020\r\032\0020\f2\006\020\017\032\0020\016H\002ø\001\000¢\006\004\b\020\020\021J\031\020\024\032\004\030\0010\0232\006\020\022\032\0020\fH\002¢\006\004\b\024\020\025J\027\020\030\032\0020\0272\006\020\026\032\0020\bH\002¢\006\004\b\030\020\031JQ\020\"\032\b\022\004\022\0020\0340 2\006\020\032\032\0020\n2\026\020\036\032\022\022\004\022\0020\0340\033j\b\022\004\022\0020\034`\0352\032\b\002\020!\032\024\022\004\022\0020\f\022\n\022\b\022\004\022\0020\0340 0\037H\002¢\006\004\b\"\020#JI\020(\032\0020'2\006\020$\032\0020\0342\026\020%\032\022\022\004\022\0020\0340\033j\b\022\004\022\0020\034`\0352\030\020&\032\024\022\004\022\0020\f\022\n\022\b\022\004\022\0020\0340 0\037H\002¢\006\004\b(\020)J+\020+\032\b\022\004\022\0020\0340 2\006\020\032\032\0020\n2\f\020*\032\b\022\004\022\0020\0340 H\002¢\006\004\b+\020,J\017\020-\032\0020'H\002¢\006\004\b-\020.J\027\020/\032\0020\n2\006\020\026\032\0020\034H\002¢\006\004\b/\0200J'\0204\032\0020'2\006\020\022\032\0020\f2\006\0202\032\002012\006\0203\032\0020\034H\002¢\006\004\b4\0205J\037\0206\032\0020'2\006\020\026\032\0020\0342\006\0202\032\00201H\002¢\006\004\b6\0207J\031\0209\032\004\030\001082\006\020\026\032\0020\034H\002¢\006\004\b9\020:J\037\020;\032\0020'2\006\020\026\032\0020\0342\006\0202\032\00201H\002¢\006\004\b;\0207J\027\020<\032\0020\n2\006\020\026\032\0020\034H\002¢\006\004\b<\0200J\037\020=\032\0020'2\006\020\026\032\0020\0342\006\0202\032\00201H\002¢\006\004\b=\0207J\031\020?\032\004\030\0010>2\006\020\026\032\0020\034H\002¢\006\004\b?\020@J\037\020A\032\0020'2\006\020\026\032\0020\0342\006\0202\032\00201H\002¢\006\004\bA\0207J\027\020B\032\0020\n2\006\020\022\032\0020\fH\002¢\006\004\bB\020CJ\027\020D\032\0020\n2\006\020\022\032\0020\fH\002¢\006\004\bD\020CJ=\020I\032\0020\n2\006\020\022\032\0020\f2\006\020E\032\0020\f2\n\b\002\020F\032\004\030\0010\f2\020\b\002\020H\032\n\022\004\022\00208\030\0010GH\002¢\006\004\bI\020JJ\027\020M\032\0020\n2\006\020L\032\0020KH\002¢\006\004\bM\020NJ\037\020O\032\0020K2\006\020\022\032\0020\f2\006\020E\032\0020\fH\003¢\006\004\bO\020PJ?\020V\032\0020K2\006\020\022\032\0020\f2\b\020Q\032\004\030\0010\f2\b\020R\032\004\030\0010\f2\b\020S\032\004\030\0010\f2\b\020U\032\004\030\0010TH\002¢\006\004\bV\020WJ\027\020X\032\0020\n2\006\020\022\032\0020\fH\002¢\006\004\bX\020CJ)\020\\\032\0020\n2\006\020\022\032\0020\f2\006\020Y\032\0020\f2\b\020[\032\004\030\0010ZH\002¢\006\004\b\\\020]J1\020_\032\0020'2\006\020\022\032\0020\f2\006\0202\032\0020\0232\006\020^\032\002082\b\020[\032\004\030\0010ZH\002¢\006\004\b_\020`J#\020e\032\004\030\0010d2\b\020a\032\004\030\0010\0342\006\020c\032\0020bH\002¢\006\004\be\020fJ\027\020g\032\0020'2\006\020\022\032\0020\fH\002¢\006\004\bg\020hJ/\020k\032\004\030\0018\000\"\b\b\000\020i*\0020T2\b\020U\032\004\030\0018\0002\b\b\001\020j\032\0020\fH\002¢\006\004\bk\020lJ\027\020o\032\0020'2\006\020n\032\0020mH\002¢\006\004\bo\020pJ\027\020q\032\0020'2\006\020n\032\0020mH\002¢\006\004\bq\020pJ%\020t\032\0020'2\006\020n\032\0020m2\f\020s\032\b\022\004\022\0020\f0rH\002¢\006\004\bt\020uJ\017\020v\032\0020'H\002¢\006\004\bv\020.J\017\020w\032\0020'H\002¢\006\004\bw\020.J#\020z\032\0020'2\022\020y\032\016\022\004\022\0020\f\022\004\022\0020\b0xH\002¢\006\004\bz\020{J\037\020~\032\0020'2\006\020|\032\0020\f2\006\020}\032\00208H\002¢\006\004\b~\020J*\020\001\032\0020\n2\006\020|\032\0020\f2\016\020\001\032\t\022\005\022\0030\0010GH\002¢\006\006\b\001\020\001J\034\020\001\032\0020'2\b\020\001\032\0030\001H\002¢\006\006\b\001\020\001J.\020\001\032\0020'2\007\020\001\032\0020\f2\006\020F\032\0020\f2\t\020\001\032\004\030\00108H\002¢\006\006\b\001\020\001J\032\020\001\032\005\030\0010\001*\0030\001H\002¢\006\006\b\001\020\001J\037\020\001\032\005\030\0010\0012\b\020\001\032\0030\001H\002¢\006\006\b\001\020\001J\031\020\001\032\005\030\0010\001*\0020\034H\002¢\006\006\b\001\020\001J'\020\001\032\0020'2\007\020\001\032\0020\f2\n\020\001\032\005\030\0010\001H\002¢\006\006\b\001\020\001J\032\020\001\032\0020'2\007\020\001\032\0020\fH\002¢\006\005\b\001\020hJ\021\020\001\032\0020'H\002¢\006\005\b\001\020.J\032\020\001\032\0020'2\006\020\026\032\0020\034H\002¢\006\006\b\001\020\001J\032\020\001\032\0020'2\006\020\026\032\0020\034H\002¢\006\006\b\001\020\001J\032\020 \001\032\0020'2\006\020\026\032\0020\034H\002¢\006\006\b \001\020\001J\021\020¡\001\032\0020'H\002¢\006\005\b¡\001\020.J\021\020¢\001\032\0020'H\002¢\006\005\b¢\001\020.J\021\020£\001\032\0020'H\002¢\006\005\b£\001\020.J%\020§\001\032\0020'2\007\020¤\001\032\0020\0342\b\020¦\001\032\0030¥\001H\002¢\006\006\b§\001\020¨\001J\033\020ª\001\032\0020'2\007\020©\001\032\0020\nH\002¢\006\006\bª\001\020«\001J%\020¬\001\032\0020'2\007\020¤\001\032\0020\0342\b\020¦\001\032\0030¥\001H\002¢\006\006\b¬\001\020¨\001J\032\020­\001\032\0020\f2\006\020|\032\0020\fH\002¢\006\006\b­\001\020®\001J5\020²\001\032\0020\n2\006\020\026\032\0020\0342\007\020¯\001\032\0020\f2\007\020°\001\032\0020\n2\007\020±\001\032\0020\nH\002¢\006\006\b²\001\020³\001J\032\020´\001\032\0020'2\007\020\001\032\0020\fH\002¢\006\005\b´\001\020hJ5\020¸\001\032\0020\n2\006\020\026\032\0020\0342\007\020µ\001\032\0020\f2\007\020¶\001\032\0020\f2\007\020·\001\032\0020\nH\002¢\006\006\b¸\001\020¹\001J\030\020i\032\0020\f2\006\020\026\032\0020\034H\002¢\006\005\bi\020º\001J\032\020»\001\032\0020\f2\006\020\026\032\0020\034H\002¢\006\006\b»\001\020º\001J\031\020¼\001\032\0020\n2\006\020\026\032\0020\034H\002¢\006\005\b¼\001\0200J(\020¾\001\032\005\030\0010½\0012\b\020\026\032\004\030\0010\0342\007\020¯\001\032\0020\fH\002¢\006\006\b¾\001\020¿\001J\035\020À\001\032\004\030\001082\b\020\026\032\004\030\0010\034H\002¢\006\005\bÀ\001\020:J\032\020Â\001\032\005\030\0010Á\001*\0030\001H\002¢\006\006\bÂ\001\020Ã\001J\034\020©\001\032\0020'2\b\020Å\001\032\0030Ä\001H\026¢\006\006\b©\001\020Æ\001J\034\020Ç\001\032\0020'2\b\020Å\001\032\0030Ä\001H\026¢\006\006\bÇ\001\020Æ\001J-\020È\001\032\0020\n2\006\020\013\032\0020\n2\006\020\r\032\0020\f2\006\020\017\032\0020\016H\000ø\001\000¢\006\006\bÈ\001\020É\001J\033\020Ë\001\032\0020\n2\007\020L\032\0030Ê\001H\000¢\006\006\bË\001\020Ì\001J&\020Ð\001\032\0020\f2\b\020Î\001\032\0030Í\0012\b\020Ï\001\032\0030Í\001H\001¢\006\006\bÐ\001\020Ñ\001J\035\020Ô\001\032\0030Ó\0012\b\020Ò\001\032\0030\001H\026¢\006\006\bÔ\001\020Õ\001J\021\020Ö\001\032\0020'H\000¢\006\005\bÖ\001\020.J\023\020×\001\032\0020'H@¢\006\006\b×\001\020Ø\001J\031\020Ù\001\032\0020'2\006\020n\032\0020mH\000¢\006\005\bÙ\001\020pJ\021\020Ú\001\032\0020'H\000¢\006\005\bÚ\001\020.J\021\020Û\001\032\0020'H\000¢\006\005\bÛ\001\020.J\021\020Ü\001\032\0020'H\000¢\006\005\bÜ\001\020.J9\020ä\001\032\0020'2\b\020Þ\001\032\0030Ý\0012\b\020à\001\032\0030ß\0012\021\020ã\001\032\f\022\007\022\005\030\0010â\0010á\001H\001¢\006\006\bä\001\020å\001J%\020é\001\032\0020'2\021\020è\001\032\f\022\007\022\005\030\0010ç\0010æ\001H\001¢\006\006\bé\001\020ê\001R\033\020\004\032\0020\0038\006¢\006\020\n\006\bë\001\020ì\001\032\006\bí\001\020î\001R/\020ô\001\032\0020\f8\000@\000X\016¢\006\036\n\006\bï\001\020\001\022\005\bó\001\020.\032\006\bð\001\020ñ\001\"\005\bò\001\020hR=\020ý\001\032\017\022\004\022\0020K\022\004\022\0020\n0õ\0018\000@\000X\016¢\006\037\n\006\bö\001\020÷\001\022\005\bü\001\020.\032\006\bø\001\020ù\001\"\006\bú\001\020û\001R\030\020\002\032\0030þ\0018\002X\004¢\006\b\n\006\bÿ\001\020\002R2\020\002\032\0020\n2\007\020\002\032\0020\n8\000@@X\016¢\006\030\n\006\b\002\020\002\032\006\b\002\020\002\"\006\b\002\020«\001R\030\020\002\032\0030\0028\002X\004¢\006\b\n\006\b\002\020\002R\030\020\002\032\0030\0028\002X\004¢\006\b\n\006\b\002\020\002RD\020\002\032-\022\017\022\r \002*\005\030\0010\0020\002 \002*\025\022\017\022\r \002*\005\030\0010\0020\002\030\0010G0 8\002@\002X\016¢\006\b\n\006\b\002\020\002R\032\020\002\032\0030\0028\002@\002X\016¢\006\b\n\006\b\002\020\002R\030\020\002\032\0030\0028\002X\004¢\006\b\n\006\b\002\020\002R\032\020 \002\032\0030Ó\0018\002@\002X\016¢\006\b\n\006\b\002\020\002R\031\020¢\002\032\0020\f8\002@\002X\016¢\006\b\n\006\b¡\002\020\001R\033\020¥\002\032\004\030\0010\0238\002@\002X\016¢\006\b\n\006\b£\002\020¤\002R\031\020§\002\032\0020\n8\002@\002X\016¢\006\b\n\006\b¦\002\020\002R7\020­\002\032\"\022\004\022\0020\f\022\005\022\0030©\0020¨\002j\020\022\004\022\0020\f\022\005\022\0030©\002`ª\0028\002X\004¢\006\b\n\006\b«\002\020¬\002R7\020¯\002\032\"\022\004\022\0020\f\022\005\022\0030©\0020¨\002j\020\022\004\022\0020\f\022\005\022\0030©\002`ª\0028\002X\004¢\006\b\n\006\b®\002\020¬\002R'\020³\002\032\020\022\013\022\t\022\004\022\0020T0°\0020°\0028\002@\002X\016¢\006\b\n\006\b±\002\020²\002R,\020µ\002\032\025\022\020\022\016\022\004\022\0020T\022\004\022\0020\f0x0°\0028\002@\002X\016¢\006\b\n\006\b´\002\020²\002R\031\020·\002\032\0020\f8\002@\002X\016¢\006\b\n\006\b¶\002\020\001R\033\020º\002\032\004\030\0010\f8\002@\002X\016¢\006\b\n\006\b¸\002\020¹\002R\035\020¼\002\032\b\022\004\022\0020m0r8\002X\004¢\006\b\n\006\bÎ\001\020»\002R\036\020¿\002\032\t\022\004\022\0020'0½\0028\002X\004¢\006\b\n\006\bÏ\001\020¾\002R\031\020Á\002\032\0020\n8\002@\002X\016¢\006\b\n\006\bÀ\002\020\002R0\020Æ\002\032\0020\n8\000@\000X\016¢\006\037\n\006\bÂ\002\020\002\022\005\bÅ\002\020.\032\006\bÃ\002\020\002\"\006\bÄ\002\020«\001R3\020Î\002\032\005\030\0010\0018\000@\000X\016¢\006\037\n\006\bÇ\002\020È\002\022\005\bÍ\002\020.\032\006\bÉ\002\020Ê\002\"\006\bË\002\020Ì\002R%\020Ò\002\032\020\022\004\022\0020\f\022\005\022\0030\0010Ï\0028\002X\004¢\006\b\n\006\bÐ\002\020Ñ\002R\035\020Ô\002\032\b\022\004\022\0020\f0r8\002X\004¢\006\b\n\006\bÓ\002\020»\002R\033\020×\002\032\005\030\0010Õ\0028\002@\002X\016¢\006\007\n\005\b_\020Ö\002R+\020\t\032\016\022\004\022\0020\f\022\004\022\0020\b0x8B@\002X\016¢\006\017\n\005\b\030\020Ø\002\032\006\bÙ\002\020Ú\002R\037\020Û\002\032\b\022\004\022\0020\f0r8\002@\002X\016¢\006\b\n\006\b×\001\020»\002RG\020à\002\032 \022\004\022\0020\f\022\004\022\0020\f0¨\002j\017\022\004\022\0020\f\022\004\022\0020\f`ª\0028\000@\000X\016¢\006\030\n\006\b\001\020¬\002\032\006\bÜ\002\020Ý\002\"\006\bÞ\002\020ß\002RG\020â\002\032 \022\004\022\0020\f\022\004\022\0020\f0¨\002j\017\022\004\022\0020\f\022\004\022\0020\f`ª\0028\000@\000X\016¢\006\030\n\006\b\001\020¬\002\032\006\b\002\020Ý\002\"\006\bá\002\020ß\002R\037\020æ\002\032\002088\000XD¢\006\020\n\006\bÈ\001\020ã\002\032\006\bä\002\020å\002R\036\020è\002\032\002088\000XD¢\006\017\n\005\b\020\020ã\002\032\006\bç\002\020å\002R\027\020ë\002\032\0030é\0028\002X\004¢\006\007\n\005\bv\020ê\002R&\020ì\002\032\017\022\004\022\0020\f\022\005\022\0030¥\0010\0378\002@\002X\016¢\006\b\n\006\b£\001\020Ø\002R\031\020î\002\032\0030¥\0018\002@\002X\016¢\006\007\n\005\b\024\020í\002R\030\020ï\002\032\0020\n8\002@\002X\016¢\006\007\n\005\bV\020\002R\030\020ò\002\032\0030ð\0028\002X\004¢\006\b\n\006\bË\001\020ñ\002R\036\020ô\002\032\t\022\005\022\0030\0010 8\002X\004¢\006\b\n\006\bó\002\020\002R$\020õ\002\032\020\022\005\022\0030\001\022\004\022\0020'0õ\0018\002X\004¢\006\007\n\005\b(\020÷\001R\027\020÷\002\032\0020\n8BX\004¢\006\b\032\006\bö\002\020\002R\036\020ú\002\032\0020\n8BX\004¢\006\017\022\005\bù\002\020.\032\006\bø\002\020\002R\027\020ü\002\032\0020\n8BX\004¢\006\b\032\006\bû\002\020\002R\027\020þ\002\032\0020\n8@X\004¢\006\b\032\006\bý\002\020\002\002\007\n\005\b¡\0360\001¨\006\003"}, d2 = {"Landroidx/compose/ui/platform/AndroidComposeViewAccessibilityDelegateCompat;", "Ldbxyzptlk/h2/a;", "Landroidx/lifecycle/DefaultLifecycleObserver;", "Landroidx/compose/ui/platform/AndroidComposeView;", "view", "<init>", "(Landroidx/compose/ui/platform/AndroidComposeView;)V", "", "Ldbxyzptlk/g1/x1;", "currentSemanticsNodes", "", "vertical", "", "direction", "Ldbxyzptlk/P0/f;", "position", "K", "(Ljava/util/Collection;ZIJ)Z", "virtualViewId", "Landroid/view/accessibility/AccessibilityNodeInfo;", "N", "(I)Landroid/view/accessibility/AccessibilityNodeInfo;", "node", "Landroid/graphics/Rect;", "F", "(Ldbxyzptlk/g1/x1;)Landroid/graphics/Rect;", "layoutIsRtl", "Ljava/util/ArrayList;", "Ldbxyzptlk/l1/p;", "Lkotlin/collections/ArrayList;", "parentListToSort", "", "", "containerChildrenMapping", "f1", "(ZLjava/util/ArrayList;Ljava/util/Map;)Ljava/util/List;", "currNode", "geometryList", "containerMapToChildren", "Ldbxyzptlk/pI/D;", "R", "(Ldbxyzptlk/l1/p;Ljava/util/ArrayList;Ljava/util/Map;)V", "listToSort", "i1", "(ZLjava/util/List;)Ljava/util/List;", "d1", "()V", "r0", "(Ldbxyzptlk/l1/p;)Z", "Ldbxyzptlk/i2/t;", "info", "semanticsNode", "F0", "(ILdbxyzptlk/i2/t;Ldbxyzptlk/l1/p;)V", "Z0", "(Ldbxyzptlk/l1/p;Ldbxyzptlk/i2/t;)V", "", "c0", "(Ldbxyzptlk/l1/p;)Ljava/lang/String;", "b1", "b0", "a1", "Landroid/text/SpannableString;", "d0", "(Ldbxyzptlk/l1/p;)Landroid/text/SpannableString;", "c1", "m0", "(I)Z", "requestAccessibilityFocus", "eventType", "contentChangeType", "", "contentDescription", "Q0", "(IILjava/lang/Integer;Ljava/util/List;)Z", "Landroid/view/accessibility/AccessibilityEvent;", "event", "P0", "(Landroid/view/accessibility/AccessibilityEvent;)Z", "createEvent", "(II)Landroid/view/accessibility/AccessibilityEvent;", "fromIndex", "toIndex", "itemCount", "", "text", "O", "(ILjava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/CharSequence;)Landroid/view/accessibility/AccessibilityEvent;", "clearAccessibilityFocus", "action", "Landroid/os/Bundle;", "arguments", "C0", "(IILandroid/os/Bundle;)Z", "extraDataKey", "E", "(ILandroid/view/accessibility/AccessibilityNodeInfo;Ljava/lang/String;Landroid/os/Bundle;)V", "textNode", "Ldbxyzptlk/P0/h;", "bounds", "Landroid/graphics/RectF;", "j1", "(Ldbxyzptlk/l1/p;Ldbxyzptlk/P0/h;)Landroid/graphics/RectF;", "updateHoveredVirtualView", "(I)V", "T", "size", "n1", "(Ljava/lang/CharSequence;I)Ljava/lang/CharSequence;", "Landroidx/compose/ui/node/f;", "layoutNode", "u0", "(Landroidx/compose/ui/node/f;)V", "W0", "Ldbxyzptlk/V/b;", "subtreeChangedSemanticsNodesIds", "V0", "(Landroidx/compose/ui/node/f;Ldbxyzptlk/V/b;)V", "L", "q1", "", "newSemanticsNodes", "U0", "(Ljava/util/Map;)V", "id", "newText", "O0", "(ILjava/lang/String;)V", "Ldbxyzptlk/g1/w1;", "oldScrollObservationScopes", "I0", "(ILjava/util/List;)Z", "scrollObservationScope", "J0", "(Ldbxyzptlk/g1/w1;)V", "semanticsNodeId", "title", "S0", "(IILjava/lang/String;)V", "Landroid/view/View;", "Ldbxyzptlk/j1/c;", "V", "(Landroid/view/View;)Ldbxyzptlk/j1/c;", "Ldbxyzptlk/l1/l;", "configuration", "Ldbxyzptlk/n1/F;", "h0", "(Ldbxyzptlk/l1/l;)Ldbxyzptlk/n1/F;", "Ldbxyzptlk/j1/e;", "k1", "(Ldbxyzptlk/l1/p;)Ldbxyzptlk/j1/e;", "virtualId", "viewStructure", "H", "(ILdbxyzptlk/j1/e;)V", "I", "t0", "o1", "(Ldbxyzptlk/l1/p;)V", "p1", "r1", "e1", "j0", "M", "newNode", "Landroidx/compose/ui/platform/AndroidComposeViewAccessibilityDelegateCompat$i;", "oldNode", "M0", "(Ldbxyzptlk/l1/p;Landroidx/compose/ui/platform/AndroidComposeViewAccessibilityDelegateCompat$i;)V", "onStart", "l0", "(Z)V", "N0", "L0", "(I)I", "granularity", "forward", "extendSelection", "m1", "(Ldbxyzptlk/l1/p;IZZ)Z", "T0", "start", "end", "traversalMode", "X0", "(Ldbxyzptlk/l1/p;IIZ)Z", "(Ldbxyzptlk/l1/p;)I", "S", "n0", "Ldbxyzptlk/g1/a;", "f0", "(Ldbxyzptlk/l1/p;I)Ldbxyzptlk/g1/a;", "e0", "Ldbxyzptlk/n1/d;", "g0", "(Ldbxyzptlk/l1/l;)Ldbxyzptlk/n1/d;", "Landroidx/lifecycle/LifecycleOwner;", "owner", "(Landroidx/lifecycle/LifecycleOwner;)V", "onStop", "J", "(ZIJ)Z", "Landroid/view/MotionEvent;", "P", "(Landroid/view/MotionEvent;)Z", "", "x", "y", "k0", "(FF)I", "host", "Ldbxyzptlk/i2/u;", "getAccessibilityNodeProvider", "(Landroid/view/View;)Ldbxyzptlk/i2/u;", "z0", "G", "(Ldbxyzptlk/tI/d;)Ljava/lang/Object;", "y0", "A0", "x0", "v0", "", "virtualIds", "", "supportedFormats", "Ljava/util/function/Consumer;", "Landroid/view/translation/ViewTranslationRequest;", "requestsCollector", "w0", "([J[ILjava/util/function/Consumer;)V", "Landroid/util/LongSparseArray;", "Landroid/view/translation/ViewTranslationResponse;", "response", "B0", "(Landroid/util/LongSparseArray;)V", "d", "Landroidx/compose/ui/platform/AndroidComposeView;", "i0", "()Landroidx/compose/ui/platform/AndroidComposeView;", "e", "getHoveredVirtualViewId$ui_release", "()I", "setHoveredVirtualViewId$ui_release", "getHoveredVirtualViewId$ui_release$annotations", "hoveredVirtualViewId", "Lkotlin/Function1;", "f", "Ldbxyzptlk/CI/l;", "getOnSendAccessibilityEvent$ui_release", "()Ldbxyzptlk/CI/l;", "setOnSendAccessibilityEvent$ui_release", "(Ldbxyzptlk/CI/l;)V", "getOnSendAccessibilityEvent$ui_release$annotations", "onSendAccessibilityEvent", "Landroid/view/accessibility/AccessibilityManager;", "g", "Landroid/view/accessibility/AccessibilityManager;", "accessibilityManager", "value", "h", "Z", "getAccessibilityForceEnabledForTesting$ui_release", "()Z", "setAccessibilityForceEnabledForTesting$ui_release", "accessibilityForceEnabledForTesting", "Landroid/view/accessibility/AccessibilityManager$AccessibilityStateChangeListener;", "i", "Landroid/view/accessibility/AccessibilityManager$AccessibilityStateChangeListener;", "enabledStateListener", "Landroid/view/accessibility/AccessibilityManager$TouchExplorationStateChangeListener;", "j", "Landroid/view/accessibility/AccessibilityManager$TouchExplorationStateChangeListener;", "touchExplorationStateListener", "Landroid/accessibilityservice/AccessibilityServiceInfo;", "kotlin.jvm.PlatformType", "k", "Ljava/util/List;", "enabledServices", "Landroidx/compose/ui/platform/AndroidComposeViewAccessibilityDelegateCompat$k;", "l", "Landroidx/compose/ui/platform/AndroidComposeViewAccessibilityDelegateCompat$k;", "translateStatus", "Landroid/os/Handler;", "m", "Landroid/os/Handler;", "handler", "n", "Ldbxyzptlk/i2/u;", "nodeProvider", "o", "focusedVirtualViewId", "p", "Landroid/view/accessibility/AccessibilityNodeInfo;", "currentlyFocusedANI", "q", "sendingFocusAffectingEvent", "Ljava/util/HashMap;", "Ldbxyzptlk/l1/j;", "Lkotlin/collections/HashMap;", "r", "Ljava/util/HashMap;", "pendingHorizontalScrollEvents", "s", "pendingVerticalScrollEvents", "Ldbxyzptlk/V/F;", "t", "Ldbxyzptlk/V/F;", "actionIdToLabel", "u", "labelToActionId", "v", "accessibilityCursorPosition", "w", "Ljava/lang/Integer;", "previousTraversedNode", "Ldbxyzptlk/V/b;", "subtreeChangedLayoutNodes", "Ldbxyzptlk/dK/d;", "Ldbxyzptlk/dK/d;", "boundsUpdateChannel", "z", "currentSemanticsNodesInvalidated", "A", "U", "setContentCaptureForceEnabledForTesting$ui_release", "getContentCaptureForceEnabledForTesting$ui_release$annotations", "contentCaptureForceEnabledForTesting", "B", "Ldbxyzptlk/j1/c;", "getContentCaptureSession$ui_release", "()Ldbxyzptlk/j1/c;", "Y0", "(Ldbxyzptlk/j1/c;)V", "getContentCaptureSession$ui_release$annotations", "contentCaptureSession", "Ldbxyzptlk/V/a;", "C", "Ldbxyzptlk/V/a;", "bufferedContentCaptureAppearedNodes", "D", "bufferedContentCaptureDisappearedNodes", "Landroidx/compose/ui/platform/AndroidComposeViewAccessibilityDelegateCompat$g;", "Landroidx/compose/ui/platform/AndroidComposeViewAccessibilityDelegateCompat$g;", "pendingTextTraversedEvent", "Ljava/util/Map;", "W", "()Ljava/util/Map;", "paneDisplayed", "a0", "()Ljava/util/HashMap;", "setIdToBeforeMap$ui_release", "(Ljava/util/HashMap;)V", "idToBeforeMap", "setIdToAfterMap$ui_release", "idToAfterMap", "Ljava/lang/String;", "Y", "()Ljava/lang/String;", "ExtraDataTestTraversalBeforeVal", "X", "ExtraDataTestTraversalAfterVal", "Ldbxyzptlk/v1/t;", "Ldbxyzptlk/v1/t;", "urlSpanCache", "previousSemanticsNodes", "Landroidx/compose/ui/platform/AndroidComposeViewAccessibilityDelegateCompat$i;", "previousSemanticsRoot", "checkingForSemanticsChanges", "Ljava/lang/Runnable;", "Ljava/lang/Runnable;", "semanticsChangeChecker", "Q", "scrollObservationScopes", "scheduleScrollEventIfNeededLambda", "o0", "isEnabled", "q0", "isEnabledForContentCapture$annotations", "isEnabledForContentCapture", "s0", "isTouchExplorationEnabled", "p0", "isEnabledForAccessibility", "b", "c", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class AndroidComposeViewAccessibilityDelegateCompat extends a implements DefaultLifecycleObserver {
  public static final d S = new d(null);
  
  public static final int T = 8;
  
  public static final int[] U = new int[] { 
      h.accessibility_custom_action_0, h.accessibility_custom_action_1, h.accessibility_custom_action_2, h.accessibility_custom_action_3, h.accessibility_custom_action_4, h.accessibility_custom_action_5, h.accessibility_custom_action_6, h.accessibility_custom_action_7, h.accessibility_custom_action_8, h.accessibility_custom_action_9, 
      h.accessibility_custom_action_10, h.accessibility_custom_action_11, h.accessibility_custom_action_12, h.accessibility_custom_action_13, h.accessibility_custom_action_14, h.accessibility_custom_action_15, h.accessibility_custom_action_16, h.accessibility_custom_action_17, h.accessibility_custom_action_18, h.accessibility_custom_action_19, 
      h.accessibility_custom_action_20, h.accessibility_custom_action_21, h.accessibility_custom_action_22, h.accessibility_custom_action_23, h.accessibility_custom_action_24, h.accessibility_custom_action_25, h.accessibility_custom_action_26, h.accessibility_custom_action_27, h.accessibility_custom_action_28, h.accessibility_custom_action_29, 
      h.accessibility_custom_action_30, h.accessibility_custom_action_31 };
  
  public boolean A;
  
  public c B;
  
  public final dbxyzptlk.V.a<Integer, dbxyzptlk.j1.e> C;
  
  public final b<Integer> D;
  
  public g E;
  
  public Map<Integer, x1> F;
  
  public b<Integer> G;
  
  public HashMap<Integer, Integer> H;
  
  public HashMap<Integer, Integer> I;
  
  public final String J;
  
  public final String K;
  
  public final t L;
  
  public Map<Integer, i> M;
  
  public i N;
  
  public boolean O;
  
  public final Runnable P;
  
  public final List<w1> Q;
  
  public final l<w1, D> R;
  
  public final AndroidComposeView d;
  
  public int e;
  
  public l<? super AccessibilityEvent, Boolean> f;
  
  public final AccessibilityManager g;
  
  public boolean h;
  
  public final AccessibilityManager.AccessibilityStateChangeListener i;
  
  public final AccessibilityManager.TouchExplorationStateChangeListener j;
  
  public List<AccessibilityServiceInfo> k;
  
  public k l;
  
  public final Handler m;
  
  public u n;
  
  public int o;
  
  public AccessibilityNodeInfo p;
  
  public boolean q;
  
  public final HashMap<Integer, j> r;
  
  public final HashMap<Integer, j> s;
  
  public F<F<CharSequence>> t;
  
  public F<Map<CharSequence, Integer>> u;
  
  public int v;
  
  public Integer w;
  
  public final b<f> x;
  
  public final dbxyzptlk.dK.d<D> y;
  
  public boolean z;
  
  public AndroidComposeViewAccessibilityDelegateCompat(AndroidComposeView paramAndroidComposeView) {
    this.d = paramAndroidComposeView;
    this.e = Integer.MIN_VALUE;
    this.f = new o(this);
    Object object = paramAndroidComposeView.getContext().getSystemService("accessibility");
    s.f(object, "null cannot be cast to non-null type android.view.accessibility.AccessibilityManager");
    object = object;
    this.g = (AccessibilityManager)object;
    this.i = (AccessibilityManager.AccessibilityStateChangeListener)new dbxyzptlk.g1.n(this);
    this.j = (AccessibilityManager.TouchExplorationStateChangeListener)new dbxyzptlk.g1.o(this);
    this.k = object.getEnabledAccessibilityServiceList(-1);
    this.l = k.SHOW_ORIGINAL;
    this.m = new Handler(Looper.getMainLooper());
    this.n = new u(new e(this));
    this.o = Integer.MIN_VALUE;
    this.r = new HashMap<>();
    this.s = new HashMap<>();
    this.t = new F(0, 1, null);
    this.u = new F(0, 1, null);
    this.v = -1;
    this.x = new b(0, 1, null);
    this.y = g.b(1, null, null, 6, null);
    this.z = true;
    this.C = new dbxyzptlk.V.a();
    this.D = new b(0, 1, null);
    this.F = P.k();
    this.G = new b(0, 1, null);
    this.H = new HashMap<>();
    this.I = new HashMap<>();
    this.J = "android.view.accessibility.extra.EXTRA_DATA_TEST_TRAVERSALBEFORE_VAL";
    this.K = "android.view.accessibility.extra.EXTRA_DATA_TEST_TRAVERSALAFTER_VAL";
    this.L = new t();
    this.M = new LinkedHashMap<>();
    this.N = new i(paramAndroidComposeView.getSemanticsOwner().a(), P.k());
    paramAndroidComposeView.addOnAttachStateChangeListener(new a(this));
    this.P = (Runnable)new p(this);
    this.Q = new ArrayList<>();
    this.R = new q(this);
  }
  
  public static final boolean D0(j paramj, float paramFloat) {
    boolean bool;
    if ((paramFloat < 0.0F && ((Number)paramj.c().invoke()).floatValue() > 0.0F) || (paramFloat > 0.0F && ((Number)paramj.c().invoke()).floatValue() < ((Number)paramj.a().invoke()).floatValue())) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public static final float E0(float paramFloat1, float paramFloat2) {
    if (Math.signum(paramFloat1) == Math.signum(paramFloat2)) {
      if (Math.abs(paramFloat1) >= Math.abs(paramFloat2))
        paramFloat1 = paramFloat2; 
    } else {
      paramFloat1 = 0.0F;
    } 
    return paramFloat1;
  }
  
  public static final boolean G0(j paramj) {
    boolean bool;
    if ((((Number)paramj.c().invoke()).floatValue() > 0.0F && !paramj.b()) || (((Number)paramj.c().invoke()).floatValue() < ((Number)paramj.a().invoke()).floatValue() && paramj.b())) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public static final boolean H0(j paramj) {
    boolean bool;
    if ((((Number)paramj.c().invoke()).floatValue() < ((Number)paramj.a().invoke()).floatValue() && !paramj.b()) || (((Number)paramj.c().invoke()).floatValue() > 0.0F && paramj.b())) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public static final void K0(AndroidComposeViewAccessibilityDelegateCompat paramAndroidComposeViewAccessibilityDelegateCompat) {
    Owner.b(paramAndroidComposeViewAccessibilityDelegateCompat.d, false, 1, null);
    paramAndroidComposeViewAccessibilityDelegateCompat.L();
    paramAndroidComposeViewAccessibilityDelegateCompat.O = false;
  }
  
  public static final void Q(AndroidComposeViewAccessibilityDelegateCompat paramAndroidComposeViewAccessibilityDelegateCompat, boolean paramBoolean) {
    List<AccessibilityServiceInfo> list;
    if (paramBoolean) {
      list = paramAndroidComposeViewAccessibilityDelegateCompat.g.getEnabledAccessibilityServiceList(-1);
    } else {
      list = s.m();
    } 
    paramAndroidComposeViewAccessibilityDelegateCompat.k = list;
  }
  
  public static final int g1(p paramp, Object paramObject1, Object paramObject2) {
    return ((Number)paramp.invoke(paramObject1, paramObject2)).intValue();
  }
  
  public static final boolean h1(ArrayList<dbxyzptlk.pI.n<h, List<p>>> paramArrayList, p paramp) {
    boolean bool;
    float f2 = paramp.j().p();
    float f1 = paramp.j().i();
    if (f2 >= f1) {
      bool = true;
    } else {
      bool = false;
    } 
    int j = s.o(paramArrayList);
    if (j >= 0) {
      int m = 0;
      while (true) {
        boolean bool1;
        h h = (h)((dbxyzptlk.pI.n)paramArrayList.get(m)).c();
        if (h.p() >= h.i()) {
          bool1 = true;
        } else {
          bool1 = false;
        } 
        if (!bool && !bool1 && Math.max(f2, h.p()) < Math.min(f1, h.i())) {
          paramArrayList.set(m, new dbxyzptlk.pI.n(h.s(0.0F, f2, Float.POSITIVE_INFINITY, f1), ((dbxyzptlk.pI.n)paramArrayList.get(m)).d()));
          ((List<p>)((dbxyzptlk.pI.n)paramArrayList.get(m)).d()).add(paramp);
          return true;
        } 
        if (m != j) {
          m++;
          continue;
        } 
        break;
      } 
    } 
    return false;
  }
  
  public static final void l1(AndroidComposeViewAccessibilityDelegateCompat paramAndroidComposeViewAccessibilityDelegateCompat, boolean paramBoolean) {
    paramAndroidComposeViewAccessibilityDelegateCompat.k = paramAndroidComposeViewAccessibilityDelegateCompat.g.getEnabledAccessibilityServiceList(-1);
  }
  
  private final boolean o0() {
    return (p0() || q0());
  }
  
  public final void A0() {
    this.l = k.SHOW_TRANSLATED;
    e1();
  }
  
  public final void B0(LongSparseArray<ViewTranslationResponse> paramLongSparseArray) {
    l.a.d(this, paramLongSparseArray);
  }
  
  public final boolean C0(int paramInt1, int paramInt2, Bundle paramBundle) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual W : ()Ljava/util/Map;
    //   4: iload_1
    //   5: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   8: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   13: checkcast dbxyzptlk/g1/x1
    //   16: astore #28
    //   18: iconst_0
    //   19: istore #25
    //   21: iconst_0
    //   22: istore #17
    //   24: iconst_0
    //   25: istore #20
    //   27: iconst_0
    //   28: istore #21
    //   30: iconst_0
    //   31: istore #18
    //   33: iconst_0
    //   34: istore #13
    //   36: iconst_0
    //   37: istore #22
    //   39: iconst_0
    //   40: istore #16
    //   42: iconst_0
    //   43: istore #24
    //   45: iconst_0
    //   46: istore #23
    //   48: iconst_0
    //   49: istore #19
    //   51: iconst_0
    //   52: istore #14
    //   54: iconst_0
    //   55: istore #12
    //   57: iconst_0
    //   58: istore #15
    //   60: aload #28
    //   62: ifnull -> 77
    //   65: aload #28
    //   67: invokevirtual b : ()Ldbxyzptlk/l1/p;
    //   70: astore #30
    //   72: aload #30
    //   74: ifnonnull -> 83
    //   77: iconst_0
    //   78: istore #12
    //   80: goto -> 2841
    //   83: iload_2
    //   84: bipush #64
    //   86: if_icmpeq -> 2834
    //   89: iload_2
    //   90: sipush #128
    //   93: if_icmpeq -> 2828
    //   96: iload_2
    //   97: sipush #256
    //   100: if_icmpeq -> 2777
    //   103: iload_2
    //   104: sipush #512
    //   107: if_icmpeq -> 2777
    //   110: iload_2
    //   111: sipush #16384
    //   114: if_icmpeq -> 2720
    //   117: iload_2
    //   118: ldc_w 131072
    //   121: if_icmpeq -> 2648
    //   124: aload #30
    //   126: invokestatic b : (Ldbxyzptlk/l1/p;)Z
    //   129: ifne -> 134
    //   132: iconst_0
    //   133: ireturn
    //   134: iload_2
    //   135: iconst_1
    //   136: if_icmpeq -> 2591
    //   139: aconst_null
    //   140: astore #28
    //   142: aconst_null
    //   143: astore #29
    //   145: iload_2
    //   146: iconst_2
    //   147: if_icmpeq -> 2543
    //   150: iload_2
    //   151: lookupswitch default -> 264, 16 -> 2456, 32 -> 2399, 4096 -> 1681, 8192 -> 1681, 32768 -> 1622, 65536 -> 1563, 262144 -> 1504, 524288 -> 1445, 1048576 -> 1386, 2097152 -> 1282, 16908342 -> 846, 16908349 -> 746, 16908372 -> 687
    //   264: iload_2
    //   265: tableswitch default -> 296, 16908344 -> 1681, 16908345 -> 1681, 16908346 -> 1681, 16908347 -> 1681
    //   296: iload_2
    //   297: tableswitch default -> 328, 16908358 -> 628, 16908359 -> 569, 16908360 -> 510, 16908361 -> 451
    //   328: aload_0
    //   329: getfield t : Ldbxyzptlk/V/F;
    //   332: iload_1
    //   333: invokevirtual i : (I)Ljava/lang/Object;
    //   336: checkcast dbxyzptlk/V/F
    //   339: astore_3
    //   340: aload_3
    //   341: ifnull -> 449
    //   344: aload_3
    //   345: iload_2
    //   346: invokevirtual i : (I)Ljava/lang/Object;
    //   349: checkcast java/lang/CharSequence
    //   352: astore_3
    //   353: aload_3
    //   354: ifnonnull -> 360
    //   357: goto -> 449
    //   360: aload #30
    //   362: invokevirtual v : ()Ldbxyzptlk/l1/l;
    //   365: getstatic dbxyzptlk/l1/k.a : Ldbxyzptlk/l1/k;
    //   368: invokevirtual d : ()Ldbxyzptlk/l1/w;
    //   371: invokestatic a : (Ldbxyzptlk/l1/l;Ldbxyzptlk/l1/w;)Ljava/lang/Object;
    //   374: checkcast java/util/List
    //   377: astore #28
    //   379: aload #28
    //   381: ifnonnull -> 386
    //   384: iconst_0
    //   385: ireturn
    //   386: aload #28
    //   388: invokeinterface size : ()I
    //   393: istore_2
    //   394: iconst_0
    //   395: istore_1
    //   396: iload_1
    //   397: iload_2
    //   398: if_icmpge -> 449
    //   401: aload #28
    //   403: iload_1
    //   404: invokeinterface get : (I)Ljava/lang/Object;
    //   409: checkcast dbxyzptlk/l1/e
    //   412: astore #29
    //   414: aload #29
    //   416: invokevirtual b : ()Ljava/lang/String;
    //   419: aload_3
    //   420: invokestatic c : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   423: ifeq -> 443
    //   426: aload #29
    //   428: invokevirtual a : ()Ldbxyzptlk/CI/a;
    //   431: invokeinterface invoke : ()Ljava/lang/Object;
    //   436: checkcast java/lang/Boolean
    //   439: invokevirtual booleanValue : ()Z
    //   442: ireturn
    //   443: iinc #1, 1
    //   446: goto -> 396
    //   449: iconst_0
    //   450: ireturn
    //   451: aload #30
    //   453: invokevirtual v : ()Ldbxyzptlk/l1/l;
    //   456: getstatic dbxyzptlk/l1/k.a : Ldbxyzptlk/l1/k;
    //   459: invokevirtual o : ()Ldbxyzptlk/l1/w;
    //   462: invokestatic a : (Ldbxyzptlk/l1/l;Ldbxyzptlk/l1/w;)Ljava/lang/Object;
    //   465: checkcast dbxyzptlk/l1/a
    //   468: astore_3
    //   469: iload #15
    //   471: istore #12
    //   473: aload_3
    //   474: ifnull -> 507
    //   477: aload_3
    //   478: invokevirtual a : ()Ldbxyzptlk/pI/f;
    //   481: checkcast dbxyzptlk/CI/a
    //   484: astore_3
    //   485: iload #15
    //   487: istore #12
    //   489: aload_3
    //   490: ifnull -> 507
    //   493: aload_3
    //   494: invokeinterface invoke : ()Ljava/lang/Object;
    //   499: checkcast java/lang/Boolean
    //   502: invokevirtual booleanValue : ()Z
    //   505: istore #12
    //   507: iload #12
    //   509: ireturn
    //   510: aload #30
    //   512: invokevirtual v : ()Ldbxyzptlk/l1/l;
    //   515: getstatic dbxyzptlk/l1/k.a : Ldbxyzptlk/l1/k;
    //   518: invokevirtual n : ()Ldbxyzptlk/l1/w;
    //   521: invokestatic a : (Ldbxyzptlk/l1/l;Ldbxyzptlk/l1/w;)Ljava/lang/Object;
    //   524: checkcast dbxyzptlk/l1/a
    //   527: astore_3
    //   528: iload #25
    //   530: istore #12
    //   532: aload_3
    //   533: ifnull -> 566
    //   536: aload_3
    //   537: invokevirtual a : ()Ldbxyzptlk/pI/f;
    //   540: checkcast dbxyzptlk/CI/a
    //   543: astore_3
    //   544: iload #25
    //   546: istore #12
    //   548: aload_3
    //   549: ifnull -> 566
    //   552: aload_3
    //   553: invokeinterface invoke : ()Ljava/lang/Object;
    //   558: checkcast java/lang/Boolean
    //   561: invokevirtual booleanValue : ()Z
    //   564: istore #12
    //   566: iload #12
    //   568: ireturn
    //   569: aload #30
    //   571: invokevirtual v : ()Ldbxyzptlk/l1/l;
    //   574: getstatic dbxyzptlk/l1/k.a : Ldbxyzptlk/l1/k;
    //   577: invokevirtual m : ()Ldbxyzptlk/l1/w;
    //   580: invokestatic a : (Ldbxyzptlk/l1/l;Ldbxyzptlk/l1/w;)Ljava/lang/Object;
    //   583: checkcast dbxyzptlk/l1/a
    //   586: astore_3
    //   587: iload #17
    //   589: istore #12
    //   591: aload_3
    //   592: ifnull -> 625
    //   595: aload_3
    //   596: invokevirtual a : ()Ldbxyzptlk/pI/f;
    //   599: checkcast dbxyzptlk/CI/a
    //   602: astore_3
    //   603: iload #17
    //   605: istore #12
    //   607: aload_3
    //   608: ifnull -> 625
    //   611: aload_3
    //   612: invokeinterface invoke : ()Ljava/lang/Object;
    //   617: checkcast java/lang/Boolean
    //   620: invokevirtual booleanValue : ()Z
    //   623: istore #12
    //   625: iload #12
    //   627: ireturn
    //   628: aload #30
    //   630: invokevirtual v : ()Ldbxyzptlk/l1/l;
    //   633: getstatic dbxyzptlk/l1/k.a : Ldbxyzptlk/l1/k;
    //   636: invokevirtual p : ()Ldbxyzptlk/l1/w;
    //   639: invokestatic a : (Ldbxyzptlk/l1/l;Ldbxyzptlk/l1/w;)Ljava/lang/Object;
    //   642: checkcast dbxyzptlk/l1/a
    //   645: astore_3
    //   646: iload #20
    //   648: istore #12
    //   650: aload_3
    //   651: ifnull -> 684
    //   654: aload_3
    //   655: invokevirtual a : ()Ldbxyzptlk/pI/f;
    //   658: checkcast dbxyzptlk/CI/a
    //   661: astore_3
    //   662: iload #20
    //   664: istore #12
    //   666: aload_3
    //   667: ifnull -> 684
    //   670: aload_3
    //   671: invokeinterface invoke : ()Ljava/lang/Object;
    //   676: checkcast java/lang/Boolean
    //   679: invokevirtual booleanValue : ()Z
    //   682: istore #12
    //   684: iload #12
    //   686: ireturn
    //   687: aload #30
    //   689: invokevirtual v : ()Ldbxyzptlk/l1/l;
    //   692: getstatic dbxyzptlk/l1/k.a : Ldbxyzptlk/l1/k;
    //   695: invokevirtual k : ()Ldbxyzptlk/l1/w;
    //   698: invokestatic a : (Ldbxyzptlk/l1/l;Ldbxyzptlk/l1/w;)Ljava/lang/Object;
    //   701: checkcast dbxyzptlk/l1/a
    //   704: astore_3
    //   705: iload #21
    //   707: istore #12
    //   709: aload_3
    //   710: ifnull -> 743
    //   713: aload_3
    //   714: invokevirtual a : ()Ldbxyzptlk/pI/f;
    //   717: checkcast dbxyzptlk/CI/a
    //   720: astore_3
    //   721: iload #21
    //   723: istore #12
    //   725: aload_3
    //   726: ifnull -> 743
    //   729: aload_3
    //   730: invokeinterface invoke : ()Ljava/lang/Object;
    //   735: checkcast java/lang/Boolean
    //   738: invokevirtual booleanValue : ()Z
    //   741: istore #12
    //   743: iload #12
    //   745: ireturn
    //   746: iload #18
    //   748: istore #12
    //   750: aload_3
    //   751: ifnull -> 843
    //   754: aload_3
    //   755: ldc_w 'android.view.accessibility.action.ARGUMENT_PROGRESS_VALUE'
    //   758: invokevirtual containsKey : (Ljava/lang/String;)Z
    //   761: ifne -> 771
    //   764: iload #18
    //   766: istore #12
    //   768: goto -> 843
    //   771: aload #30
    //   773: invokevirtual v : ()Ldbxyzptlk/l1/l;
    //   776: getstatic dbxyzptlk/l1/k.a : Ldbxyzptlk/l1/k;
    //   779: invokevirtual u : ()Ldbxyzptlk/l1/w;
    //   782: invokestatic a : (Ldbxyzptlk/l1/l;Ldbxyzptlk/l1/w;)Ljava/lang/Object;
    //   785: checkcast dbxyzptlk/l1/a
    //   788: astore #28
    //   790: iload #18
    //   792: istore #12
    //   794: aload #28
    //   796: ifnull -> 843
    //   799: aload #28
    //   801: invokevirtual a : ()Ldbxyzptlk/pI/f;
    //   804: checkcast dbxyzptlk/CI/l
    //   807: astore #28
    //   809: iload #18
    //   811: istore #12
    //   813: aload #28
    //   815: ifnull -> 843
    //   818: aload #28
    //   820: aload_3
    //   821: ldc_w 'android.view.accessibility.action.ARGUMENT_PROGRESS_VALUE'
    //   824: invokevirtual getFloat : (Ljava/lang/String;)F
    //   827: invokestatic valueOf : (F)Ljava/lang/Float;
    //   830: invokeinterface invoke : (Ljava/lang/Object;)Ljava/lang/Object;
    //   835: checkcast java/lang/Boolean
    //   838: invokevirtual booleanValue : ()Z
    //   841: istore #12
    //   843: iload #12
    //   845: ireturn
    //   846: aload #30
    //   848: invokevirtual q : ()Ldbxyzptlk/l1/p;
    //   851: astore_3
    //   852: aload_3
    //   853: astore #28
    //   855: aload_3
    //   856: ifnull -> 898
    //   859: aload_3
    //   860: invokevirtual m : ()Ldbxyzptlk/l1/l;
    //   863: astore #29
    //   865: aload_3
    //   866: astore #28
    //   868: aload #29
    //   870: ifnull -> 898
    //   873: aload #29
    //   875: getstatic dbxyzptlk/l1/k.a : Ldbxyzptlk/l1/k;
    //   878: invokevirtual s : ()Ldbxyzptlk/l1/w;
    //   881: invokestatic a : (Ldbxyzptlk/l1/l;Ldbxyzptlk/l1/w;)Ljava/lang/Object;
    //   884: checkcast dbxyzptlk/l1/a
    //   887: astore #29
    //   889: aload_3
    //   890: astore #28
    //   892: aload #29
    //   894: astore_3
    //   895: goto -> 900
    //   898: aconst_null
    //   899: astore_3
    //   900: aload #28
    //   902: ifnull -> 964
    //   905: aload_3
    //   906: ifnull -> 912
    //   909: goto -> 964
    //   912: aload #28
    //   914: invokevirtual q : ()Ldbxyzptlk/l1/p;
    //   917: astore_3
    //   918: aload_3
    //   919: astore #28
    //   921: aload_3
    //   922: ifnull -> 898
    //   925: aload_3
    //   926: invokevirtual m : ()Ldbxyzptlk/l1/l;
    //   929: astore #29
    //   931: aload_3
    //   932: astore #28
    //   934: aload #29
    //   936: ifnull -> 898
    //   939: aload #29
    //   941: getstatic dbxyzptlk/l1/k.a : Ldbxyzptlk/l1/k;
    //   944: invokevirtual s : ()Ldbxyzptlk/l1/w;
    //   947: invokestatic a : (Ldbxyzptlk/l1/l;Ldbxyzptlk/l1/w;)Ljava/lang/Object;
    //   950: checkcast dbxyzptlk/l1/a
    //   953: astore #29
    //   955: aload_3
    //   956: astore #28
    //   958: aload #29
    //   960: astore_3
    //   961: goto -> 900
    //   964: aload #28
    //   966: ifnonnull -> 971
    //   969: iconst_0
    //   970: ireturn
    //   971: aload #28
    //   973: invokevirtual o : ()Ldbxyzptlk/d1/v;
    //   976: invokeinterface i : ()Ldbxyzptlk/d1/r;
    //   981: invokestatic a : (Ldbxyzptlk/d1/r;)Ldbxyzptlk/P0/h;
    //   984: astore #29
    //   986: aload #28
    //   988: invokevirtual o : ()Ldbxyzptlk/d1/v;
    //   991: invokeinterface i : ()Ldbxyzptlk/d1/r;
    //   996: invokeinterface r : ()Ldbxyzptlk/d1/r;
    //   1001: astore #31
    //   1003: aload #31
    //   1005: ifnull -> 1018
    //   1008: aload #31
    //   1010: invokestatic e : (Ldbxyzptlk/d1/r;)J
    //   1013: lstore #26
    //   1015: goto -> 1026
    //   1018: getstatic dbxyzptlk/P0/f.b : Ldbxyzptlk/P0/f$a;
    //   1021: invokevirtual c : ()J
    //   1024: lstore #26
    //   1026: aload #29
    //   1028: lload #26
    //   1030: invokevirtual x : (J)Ldbxyzptlk/P0/h;
    //   1033: astore #29
    //   1035: aload #30
    //   1037: invokevirtual r : ()J
    //   1040: aload #30
    //   1042: invokevirtual t : ()J
    //   1045: invokestatic c : (J)J
    //   1048: invokestatic b : (JJ)Ldbxyzptlk/P0/h;
    //   1051: astore #31
    //   1053: aload #28
    //   1055: invokevirtual v : ()Ldbxyzptlk/l1/l;
    //   1058: astore #33
    //   1060: getstatic dbxyzptlk/l1/s.a : Ldbxyzptlk/l1/s;
    //   1063: astore #32
    //   1065: aload #33
    //   1067: aload #32
    //   1069: invokevirtual i : ()Ldbxyzptlk/l1/w;
    //   1072: invokestatic a : (Ldbxyzptlk/l1/l;Ldbxyzptlk/l1/w;)Ljava/lang/Object;
    //   1075: checkcast dbxyzptlk/l1/j
    //   1078: astore #33
    //   1080: aload #28
    //   1082: invokevirtual v : ()Ldbxyzptlk/l1/l;
    //   1085: aload #32
    //   1087: invokevirtual E : ()Ldbxyzptlk/l1/w;
    //   1090: invokestatic a : (Ldbxyzptlk/l1/l;Ldbxyzptlk/l1/w;)Ljava/lang/Object;
    //   1093: checkcast dbxyzptlk/l1/j
    //   1096: astore #28
    //   1098: aload #31
    //   1100: invokevirtual m : ()F
    //   1103: aload #29
    //   1105: invokevirtual m : ()F
    //   1108: fsub
    //   1109: aload #31
    //   1111: invokevirtual n : ()F
    //   1114: aload #29
    //   1116: invokevirtual n : ()F
    //   1119: fsub
    //   1120: invokestatic E0 : (FF)F
    //   1123: fstore #5
    //   1125: fload #5
    //   1127: fstore #4
    //   1129: aload #33
    //   1131: ifnull -> 1152
    //   1134: fload #5
    //   1136: fstore #4
    //   1138: aload #33
    //   1140: invokevirtual b : ()Z
    //   1143: iconst_1
    //   1144: if_icmpne -> 1152
    //   1147: fload #5
    //   1149: fneg
    //   1150: fstore #4
    //   1152: fload #4
    //   1154: fstore #5
    //   1156: aload #30
    //   1158: invokevirtual o : ()Ldbxyzptlk/d1/v;
    //   1161: invokeinterface getLayoutDirection : ()Ldbxyzptlk/z1/t;
    //   1166: getstatic dbxyzptlk/z1/t.Rtl : Ldbxyzptlk/z1/t;
    //   1169: if_acmpne -> 1177
    //   1172: fload #4
    //   1174: fneg
    //   1175: fstore #5
    //   1177: aload #31
    //   1179: invokevirtual p : ()F
    //   1182: aload #29
    //   1184: invokevirtual p : ()F
    //   1187: fsub
    //   1188: aload #31
    //   1190: invokevirtual i : ()F
    //   1193: aload #29
    //   1195: invokevirtual i : ()F
    //   1198: fsub
    //   1199: invokestatic E0 : (FF)F
    //   1202: fstore #6
    //   1204: fload #6
    //   1206: fstore #4
    //   1208: aload #28
    //   1210: ifnull -> 1231
    //   1213: fload #6
    //   1215: fstore #4
    //   1217: aload #28
    //   1219: invokevirtual b : ()Z
    //   1222: iconst_1
    //   1223: if_icmpne -> 1231
    //   1226: fload #6
    //   1228: fneg
    //   1229: fstore #4
    //   1231: iload #13
    //   1233: istore #12
    //   1235: aload_3
    //   1236: ifnull -> 1279
    //   1239: aload_3
    //   1240: invokevirtual a : ()Ldbxyzptlk/pI/f;
    //   1243: checkcast dbxyzptlk/CI/p
    //   1246: astore_3
    //   1247: iload #13
    //   1249: istore #12
    //   1251: aload_3
    //   1252: ifnull -> 1279
    //   1255: aload_3
    //   1256: fload #5
    //   1258: invokestatic valueOf : (F)Ljava/lang/Float;
    //   1261: fload #4
    //   1263: invokestatic valueOf : (F)Ljava/lang/Float;
    //   1266: invokeinterface invoke : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1271: checkcast java/lang/Boolean
    //   1274: invokevirtual booleanValue : ()Z
    //   1277: istore #12
    //   1279: iload #12
    //   1281: ireturn
    //   1282: aload #29
    //   1284: astore #28
    //   1286: aload_3
    //   1287: ifnull -> 1299
    //   1290: aload_3
    //   1291: ldc_w 'ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE'
    //   1294: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   1297: astore #28
    //   1299: aload #30
    //   1301: invokevirtual v : ()Ldbxyzptlk/l1/l;
    //   1304: getstatic dbxyzptlk/l1/k.a : Ldbxyzptlk/l1/k;
    //   1307: invokevirtual w : ()Ldbxyzptlk/l1/w;
    //   1310: invokestatic a : (Ldbxyzptlk/l1/l;Ldbxyzptlk/l1/w;)Ljava/lang/Object;
    //   1313: checkcast dbxyzptlk/l1/a
    //   1316: astore_3
    //   1317: iload #22
    //   1319: istore #12
    //   1321: aload_3
    //   1322: ifnull -> 1383
    //   1325: aload_3
    //   1326: invokevirtual a : ()Ldbxyzptlk/pI/f;
    //   1329: checkcast dbxyzptlk/CI/l
    //   1332: astore #29
    //   1334: iload #22
    //   1336: istore #12
    //   1338: aload #29
    //   1340: ifnull -> 1383
    //   1343: aload #28
    //   1345: astore_3
    //   1346: aload #28
    //   1348: ifnonnull -> 1355
    //   1351: ldc_w ''
    //   1354: astore_3
    //   1355: aload #29
    //   1357: new dbxyzptlk/n1/d
    //   1360: dup
    //   1361: aload_3
    //   1362: aconst_null
    //   1363: aconst_null
    //   1364: bipush #6
    //   1366: aconst_null
    //   1367: invokespecial <init> : (Ljava/lang/String;Ljava/util/List;Ljava/util/List;ILkotlin/jvm/internal/DefaultConstructorMarker;)V
    //   1370: invokeinterface invoke : (Ljava/lang/Object;)Ljava/lang/Object;
    //   1375: checkcast java/lang/Boolean
    //   1378: invokevirtual booleanValue : ()Z
    //   1381: istore #12
    //   1383: iload #12
    //   1385: ireturn
    //   1386: aload #30
    //   1388: invokevirtual v : ()Ldbxyzptlk/l1/l;
    //   1391: getstatic dbxyzptlk/l1/k.a : Ldbxyzptlk/l1/k;
    //   1394: invokevirtual f : ()Ldbxyzptlk/l1/w;
    //   1397: invokestatic a : (Ldbxyzptlk/l1/l;Ldbxyzptlk/l1/w;)Ljava/lang/Object;
    //   1400: checkcast dbxyzptlk/l1/a
    //   1403: astore_3
    //   1404: iload #16
    //   1406: istore #12
    //   1408: aload_3
    //   1409: ifnull -> 1442
    //   1412: aload_3
    //   1413: invokevirtual a : ()Ldbxyzptlk/pI/f;
    //   1416: checkcast dbxyzptlk/CI/a
    //   1419: astore_3
    //   1420: iload #16
    //   1422: istore #12
    //   1424: aload_3
    //   1425: ifnull -> 1442
    //   1428: aload_3
    //   1429: invokeinterface invoke : ()Ljava/lang/Object;
    //   1434: checkcast java/lang/Boolean
    //   1437: invokevirtual booleanValue : ()Z
    //   1440: istore #12
    //   1442: iload #12
    //   1444: ireturn
    //   1445: aload #30
    //   1447: invokevirtual v : ()Ldbxyzptlk/l1/l;
    //   1450: getstatic dbxyzptlk/l1/k.a : Ldbxyzptlk/l1/k;
    //   1453: invokevirtual b : ()Ldbxyzptlk/l1/w;
    //   1456: invokestatic a : (Ldbxyzptlk/l1/l;Ldbxyzptlk/l1/w;)Ljava/lang/Object;
    //   1459: checkcast dbxyzptlk/l1/a
    //   1462: astore_3
    //   1463: iload #24
    //   1465: istore #12
    //   1467: aload_3
    //   1468: ifnull -> 1501
    //   1471: aload_3
    //   1472: invokevirtual a : ()Ldbxyzptlk/pI/f;
    //   1475: checkcast dbxyzptlk/CI/a
    //   1478: astore_3
    //   1479: iload #24
    //   1481: istore #12
    //   1483: aload_3
    //   1484: ifnull -> 1501
    //   1487: aload_3
    //   1488: invokeinterface invoke : ()Ljava/lang/Object;
    //   1493: checkcast java/lang/Boolean
    //   1496: invokevirtual booleanValue : ()Z
    //   1499: istore #12
    //   1501: iload #12
    //   1503: ireturn
    //   1504: aload #30
    //   1506: invokevirtual v : ()Ldbxyzptlk/l1/l;
    //   1509: getstatic dbxyzptlk/l1/k.a : Ldbxyzptlk/l1/k;
    //   1512: invokevirtual g : ()Ldbxyzptlk/l1/w;
    //   1515: invokestatic a : (Ldbxyzptlk/l1/l;Ldbxyzptlk/l1/w;)Ljava/lang/Object;
    //   1518: checkcast dbxyzptlk/l1/a
    //   1521: astore_3
    //   1522: iload #23
    //   1524: istore #12
    //   1526: aload_3
    //   1527: ifnull -> 1560
    //   1530: aload_3
    //   1531: invokevirtual a : ()Ldbxyzptlk/pI/f;
    //   1534: checkcast dbxyzptlk/CI/a
    //   1537: astore_3
    //   1538: iload #23
    //   1540: istore #12
    //   1542: aload_3
    //   1543: ifnull -> 1560
    //   1546: aload_3
    //   1547: invokeinterface invoke : ()Ljava/lang/Object;
    //   1552: checkcast java/lang/Boolean
    //   1555: invokevirtual booleanValue : ()Z
    //   1558: istore #12
    //   1560: iload #12
    //   1562: ireturn
    //   1563: aload #30
    //   1565: invokevirtual v : ()Ldbxyzptlk/l1/l;
    //   1568: getstatic dbxyzptlk/l1/k.a : Ldbxyzptlk/l1/k;
    //   1571: invokevirtual e : ()Ldbxyzptlk/l1/w;
    //   1574: invokestatic a : (Ldbxyzptlk/l1/l;Ldbxyzptlk/l1/w;)Ljava/lang/Object;
    //   1577: checkcast dbxyzptlk/l1/a
    //   1580: astore_3
    //   1581: iload #19
    //   1583: istore #12
    //   1585: aload_3
    //   1586: ifnull -> 1619
    //   1589: aload_3
    //   1590: invokevirtual a : ()Ldbxyzptlk/pI/f;
    //   1593: checkcast dbxyzptlk/CI/a
    //   1596: astore_3
    //   1597: iload #19
    //   1599: istore #12
    //   1601: aload_3
    //   1602: ifnull -> 1619
    //   1605: aload_3
    //   1606: invokeinterface invoke : ()Ljava/lang/Object;
    //   1611: checkcast java/lang/Boolean
    //   1614: invokevirtual booleanValue : ()Z
    //   1617: istore #12
    //   1619: iload #12
    //   1621: ireturn
    //   1622: aload #30
    //   1624: invokevirtual v : ()Ldbxyzptlk/l1/l;
    //   1627: getstatic dbxyzptlk/l1/k.a : Ldbxyzptlk/l1/k;
    //   1630: invokevirtual q : ()Ldbxyzptlk/l1/w;
    //   1633: invokestatic a : (Ldbxyzptlk/l1/l;Ldbxyzptlk/l1/w;)Ljava/lang/Object;
    //   1636: checkcast dbxyzptlk/l1/a
    //   1639: astore_3
    //   1640: iload #14
    //   1642: istore #12
    //   1644: aload_3
    //   1645: ifnull -> 1678
    //   1648: aload_3
    //   1649: invokevirtual a : ()Ldbxyzptlk/pI/f;
    //   1652: checkcast dbxyzptlk/CI/a
    //   1655: astore_3
    //   1656: iload #14
    //   1658: istore #12
    //   1660: aload_3
    //   1661: ifnull -> 1678
    //   1664: aload_3
    //   1665: invokeinterface invoke : ()Ljava/lang/Object;
    //   1670: checkcast java/lang/Boolean
    //   1673: invokevirtual booleanValue : ()Z
    //   1676: istore #12
    //   1678: iload #12
    //   1680: ireturn
    //   1681: iload_2
    //   1682: sipush #4096
    //   1685: if_icmpne -> 1694
    //   1688: iconst_1
    //   1689: istore #7
    //   1691: goto -> 1697
    //   1694: iconst_0
    //   1695: istore #7
    //   1697: iload_2
    //   1698: sipush #8192
    //   1701: if_icmpne -> 1709
    //   1704: iconst_1
    //   1705: istore_1
    //   1706: goto -> 1711
    //   1709: iconst_0
    //   1710: istore_1
    //   1711: iload_2
    //   1712: ldc_w 16908345
    //   1715: if_icmpne -> 1724
    //   1718: iconst_1
    //   1719: istore #8
    //   1721: goto -> 1727
    //   1724: iconst_0
    //   1725: istore #8
    //   1727: iload_2
    //   1728: ldc_w 16908347
    //   1731: if_icmpne -> 1740
    //   1734: iconst_1
    //   1735: istore #9
    //   1737: goto -> 1743
    //   1740: iconst_0
    //   1741: istore #9
    //   1743: iload_2
    //   1744: ldc_w 16908344
    //   1747: if_icmpne -> 1756
    //   1750: iconst_1
    //   1751: istore #10
    //   1753: goto -> 1759
    //   1756: iconst_0
    //   1757: istore #10
    //   1759: iload_2
    //   1760: ldc_w 16908346
    //   1763: if_icmpne -> 1772
    //   1766: iconst_1
    //   1767: istore #11
    //   1769: goto -> 1775
    //   1772: iconst_0
    //   1773: istore #11
    //   1775: iload #8
    //   1777: ifne -> 1802
    //   1780: iload #9
    //   1782: ifne -> 1802
    //   1785: iload #7
    //   1787: ifne -> 1802
    //   1790: iload_1
    //   1791: ifeq -> 1797
    //   1794: goto -> 1802
    //   1797: iconst_0
    //   1798: istore_2
    //   1799: goto -> 1804
    //   1802: iconst_1
    //   1803: istore_2
    //   1804: iload #10
    //   1806: ifne -> 1832
    //   1809: iload #11
    //   1811: ifne -> 1832
    //   1814: iload #7
    //   1816: ifne -> 1832
    //   1819: iload_1
    //   1820: ifeq -> 1826
    //   1823: goto -> 1832
    //   1826: iconst_0
    //   1827: istore #11
    //   1829: goto -> 1835
    //   1832: iconst_1
    //   1833: istore #11
    //   1835: iload #7
    //   1837: ifne -> 1844
    //   1840: iload_1
    //   1841: ifeq -> 2060
    //   1844: aload #30
    //   1846: invokevirtual v : ()Ldbxyzptlk/l1/l;
    //   1849: getstatic dbxyzptlk/l1/s.a : Ldbxyzptlk/l1/s;
    //   1852: invokevirtual t : ()Ldbxyzptlk/l1/w;
    //   1855: invokestatic a : (Ldbxyzptlk/l1/l;Ldbxyzptlk/l1/w;)Ljava/lang/Object;
    //   1858: checkcast dbxyzptlk/l1/h
    //   1861: astore_3
    //   1862: aload #30
    //   1864: invokevirtual v : ()Ldbxyzptlk/l1/l;
    //   1867: getstatic dbxyzptlk/l1/k.a : Ldbxyzptlk/l1/k;
    //   1870: invokevirtual u : ()Ldbxyzptlk/l1/w;
    //   1873: invokestatic a : (Ldbxyzptlk/l1/l;Ldbxyzptlk/l1/w;)Ljava/lang/Object;
    //   1876: checkcast dbxyzptlk/l1/a
    //   1879: astore #28
    //   1881: aload_3
    //   1882: ifnull -> 2060
    //   1885: aload #28
    //   1887: ifnull -> 2060
    //   1890: aload_3
    //   1891: invokevirtual c : ()Ldbxyzptlk/KI/e;
    //   1894: invokeinterface k : ()Ljava/lang/Comparable;
    //   1899: checkcast java/lang/Number
    //   1902: invokevirtual floatValue : ()F
    //   1905: aload_3
    //   1906: invokevirtual c : ()Ldbxyzptlk/KI/e;
    //   1909: invokeinterface e : ()Ljava/lang/Comparable;
    //   1914: checkcast java/lang/Number
    //   1917: invokevirtual floatValue : ()F
    //   1920: invokestatic d : (FF)F
    //   1923: fstore #4
    //   1925: aload_3
    //   1926: invokevirtual c : ()Ldbxyzptlk/KI/e;
    //   1929: invokeinterface e : ()Ljava/lang/Comparable;
    //   1934: checkcast java/lang/Number
    //   1937: invokevirtual floatValue : ()F
    //   1940: aload_3
    //   1941: invokevirtual c : ()Ldbxyzptlk/KI/e;
    //   1944: invokeinterface k : ()Ljava/lang/Comparable;
    //   1949: checkcast java/lang/Number
    //   1952: invokevirtual floatValue : ()F
    //   1955: invokestatic h : (FF)F
    //   1958: fstore #5
    //   1960: aload_3
    //   1961: invokevirtual d : ()I
    //   1964: ifle -> 1991
    //   1967: fload #4
    //   1969: fload #5
    //   1971: fsub
    //   1972: fstore #4
    //   1974: aload_3
    //   1975: invokevirtual d : ()I
    //   1978: iconst_1
    //   1979: iadd
    //   1980: istore_2
    //   1981: fload #4
    //   1983: iload_2
    //   1984: i2f
    //   1985: fdiv
    //   1986: fstore #5
    //   1988: goto -> 2004
    //   1991: fload #4
    //   1993: fload #5
    //   1995: fsub
    //   1996: fstore #4
    //   1998: bipush #20
    //   2000: istore_2
    //   2001: goto -> 1981
    //   2004: fload #5
    //   2006: fstore #4
    //   2008: iload_1
    //   2009: ifeq -> 2017
    //   2012: fload #5
    //   2014: fneg
    //   2015: fstore #4
    //   2017: aload #28
    //   2019: invokevirtual a : ()Ldbxyzptlk/pI/f;
    //   2022: checkcast dbxyzptlk/CI/l
    //   2025: astore #28
    //   2027: aload #28
    //   2029: ifnull -> 2057
    //   2032: aload #28
    //   2034: aload_3
    //   2035: invokevirtual b : ()F
    //   2038: fload #4
    //   2040: fadd
    //   2041: invokestatic valueOf : (F)Ljava/lang/Float;
    //   2044: invokeinterface invoke : (Ljava/lang/Object;)Ljava/lang/Object;
    //   2049: checkcast java/lang/Boolean
    //   2052: invokevirtual booleanValue : ()Z
    //   2055: istore #12
    //   2057: iload #12
    //   2059: ireturn
    //   2060: aload #30
    //   2062: invokevirtual o : ()Ldbxyzptlk/d1/v;
    //   2065: invokeinterface i : ()Ldbxyzptlk/d1/r;
    //   2070: invokestatic a : (Ldbxyzptlk/d1/r;)Ldbxyzptlk/P0/h;
    //   2073: invokevirtual o : ()J
    //   2076: lstore #26
    //   2078: aload #30
    //   2080: invokevirtual v : ()Ldbxyzptlk/l1/l;
    //   2083: getstatic dbxyzptlk/l1/k.a : Ldbxyzptlk/l1/k;
    //   2086: invokevirtual s : ()Ldbxyzptlk/l1/w;
    //   2089: invokestatic a : (Ldbxyzptlk/l1/l;Ldbxyzptlk/l1/w;)Ljava/lang/Object;
    //   2092: checkcast dbxyzptlk/l1/a
    //   2095: astore_3
    //   2096: aload_3
    //   2097: ifnonnull -> 2102
    //   2100: iconst_0
    //   2101: ireturn
    //   2102: aload #30
    //   2104: invokevirtual v : ()Ldbxyzptlk/l1/l;
    //   2107: astore #29
    //   2109: getstatic dbxyzptlk/l1/s.a : Ldbxyzptlk/l1/s;
    //   2112: astore #28
    //   2114: aload #29
    //   2116: aload #28
    //   2118: invokevirtual i : ()Ldbxyzptlk/l1/w;
    //   2121: invokestatic a : (Ldbxyzptlk/l1/l;Ldbxyzptlk/l1/w;)Ljava/lang/Object;
    //   2124: checkcast dbxyzptlk/l1/j
    //   2127: astore #29
    //   2129: aload #29
    //   2131: ifnull -> 2273
    //   2134: iload_2
    //   2135: ifeq -> 2273
    //   2138: lload #26
    //   2140: invokestatic i : (J)F
    //   2143: fstore #5
    //   2145: iload #8
    //   2147: ifne -> 2158
    //   2150: fload #5
    //   2152: fstore #4
    //   2154: iload_1
    //   2155: ifeq -> 2163
    //   2158: fload #5
    //   2160: fneg
    //   2161: fstore #4
    //   2163: fload #4
    //   2165: fstore #5
    //   2167: aload #29
    //   2169: invokevirtual b : ()Z
    //   2172: ifeq -> 2180
    //   2175: fload #4
    //   2177: fneg
    //   2178: fstore #5
    //   2180: fload #5
    //   2182: fstore #4
    //   2184: aload #30
    //   2186: invokevirtual o : ()Ldbxyzptlk/d1/v;
    //   2189: invokeinterface getLayoutDirection : ()Ldbxyzptlk/z1/t;
    //   2194: getstatic dbxyzptlk/z1/t.Rtl : Ldbxyzptlk/z1/t;
    //   2197: if_acmpne -> 2219
    //   2200: iload #8
    //   2202: ifne -> 2214
    //   2205: fload #5
    //   2207: fstore #4
    //   2209: iload #9
    //   2211: ifeq -> 2219
    //   2214: fload #5
    //   2216: fneg
    //   2217: fstore #4
    //   2219: aload #29
    //   2221: fload #4
    //   2223: invokestatic D0 : (Ldbxyzptlk/l1/j;F)Z
    //   2226: ifeq -> 2273
    //   2229: aload_3
    //   2230: invokevirtual a : ()Ldbxyzptlk/pI/f;
    //   2233: checkcast dbxyzptlk/CI/p
    //   2236: astore_3
    //   2237: aload_3
    //   2238: ifnull -> 2267
    //   2241: aload_3
    //   2242: fload #4
    //   2244: invokestatic valueOf : (F)Ljava/lang/Float;
    //   2247: fconst_0
    //   2248: invokestatic valueOf : (F)Ljava/lang/Float;
    //   2251: invokeinterface invoke : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   2256: checkcast java/lang/Boolean
    //   2259: invokevirtual booleanValue : ()Z
    //   2262: istore #12
    //   2264: goto -> 2270
    //   2267: iconst_0
    //   2268: istore #12
    //   2270: iload #12
    //   2272: ireturn
    //   2273: aload #30
    //   2275: invokevirtual v : ()Ldbxyzptlk/l1/l;
    //   2278: aload #28
    //   2280: invokevirtual E : ()Ldbxyzptlk/l1/w;
    //   2283: invokestatic a : (Ldbxyzptlk/l1/l;Ldbxyzptlk/l1/w;)Ljava/lang/Object;
    //   2286: checkcast dbxyzptlk/l1/j
    //   2289: astore #28
    //   2291: aload #28
    //   2293: ifnull -> 2397
    //   2296: iload #11
    //   2298: ifeq -> 2397
    //   2301: lload #26
    //   2303: invokestatic g : (J)F
    //   2306: fstore #5
    //   2308: iload #10
    //   2310: ifne -> 2321
    //   2313: fload #5
    //   2315: fstore #4
    //   2317: iload_1
    //   2318: ifeq -> 2326
    //   2321: fload #5
    //   2323: fneg
    //   2324: fstore #4
    //   2326: fload #4
    //   2328: fstore #5
    //   2330: aload #28
    //   2332: invokevirtual b : ()Z
    //   2335: ifeq -> 2343
    //   2338: fload #4
    //   2340: fneg
    //   2341: fstore #5
    //   2343: aload #28
    //   2345: fload #5
    //   2347: invokestatic D0 : (Ldbxyzptlk/l1/j;F)Z
    //   2350: ifeq -> 2397
    //   2353: aload_3
    //   2354: invokevirtual a : ()Ldbxyzptlk/pI/f;
    //   2357: checkcast dbxyzptlk/CI/p
    //   2360: astore_3
    //   2361: aload_3
    //   2362: ifnull -> 2391
    //   2365: aload_3
    //   2366: fconst_0
    //   2367: invokestatic valueOf : (F)Ljava/lang/Float;
    //   2370: fload #5
    //   2372: invokestatic valueOf : (F)Ljava/lang/Float;
    //   2375: invokeinterface invoke : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   2380: checkcast java/lang/Boolean
    //   2383: invokevirtual booleanValue : ()Z
    //   2386: istore #12
    //   2388: goto -> 2394
    //   2391: iconst_0
    //   2392: istore #12
    //   2394: iload #12
    //   2396: ireturn
    //   2397: iconst_0
    //   2398: ireturn
    //   2399: aload #30
    //   2401: invokevirtual v : ()Ldbxyzptlk/l1/l;
    //   2404: getstatic dbxyzptlk/l1/k.a : Ldbxyzptlk/l1/k;
    //   2407: invokevirtual l : ()Ldbxyzptlk/l1/w;
    //   2410: invokestatic a : (Ldbxyzptlk/l1/l;Ldbxyzptlk/l1/w;)Ljava/lang/Object;
    //   2413: checkcast dbxyzptlk/l1/a
    //   2416: astore_3
    //   2417: aload_3
    //   2418: ifnull -> 2450
    //   2421: aload_3
    //   2422: invokevirtual a : ()Ldbxyzptlk/pI/f;
    //   2425: checkcast dbxyzptlk/CI/a
    //   2428: astore_3
    //   2429: aload_3
    //   2430: ifnull -> 2450
    //   2433: aload_3
    //   2434: invokeinterface invoke : ()Ljava/lang/Object;
    //   2439: checkcast java/lang/Boolean
    //   2442: invokevirtual booleanValue : ()Z
    //   2445: istore #12
    //   2447: goto -> 2453
    //   2450: iconst_0
    //   2451: istore #12
    //   2453: iload #12
    //   2455: ireturn
    //   2456: aload #30
    //   2458: invokevirtual v : ()Ldbxyzptlk/l1/l;
    //   2461: getstatic dbxyzptlk/l1/k.a : Ldbxyzptlk/l1/k;
    //   2464: invokevirtual j : ()Ldbxyzptlk/l1/w;
    //   2467: invokestatic a : (Ldbxyzptlk/l1/l;Ldbxyzptlk/l1/w;)Ljava/lang/Object;
    //   2470: checkcast dbxyzptlk/l1/a
    //   2473: astore #29
    //   2475: aload #28
    //   2477: astore_3
    //   2478: aload #29
    //   2480: ifnull -> 2512
    //   2483: aload #29
    //   2485: invokevirtual a : ()Ldbxyzptlk/pI/f;
    //   2488: checkcast dbxyzptlk/CI/a
    //   2491: astore #29
    //   2493: aload #28
    //   2495: astore_3
    //   2496: aload #29
    //   2498: ifnull -> 2512
    //   2501: aload #29
    //   2503: invokeinterface invoke : ()Ljava/lang/Object;
    //   2508: checkcast java/lang/Boolean
    //   2511: astore_3
    //   2512: aload_0
    //   2513: iload_1
    //   2514: iconst_1
    //   2515: aconst_null
    //   2516: aconst_null
    //   2517: bipush #12
    //   2519: aconst_null
    //   2520: invokestatic R0 : (Landroidx/compose/ui/platform/AndroidComposeViewAccessibilityDelegateCompat;IILjava/lang/Integer;Ljava/util/List;ILjava/lang/Object;)Z
    //   2523: pop
    //   2524: aload_3
    //   2525: ifnull -> 2537
    //   2528: aload_3
    //   2529: invokevirtual booleanValue : ()Z
    //   2532: istore #12
    //   2534: goto -> 2540
    //   2537: iconst_0
    //   2538: istore #12
    //   2540: iload #12
    //   2542: ireturn
    //   2543: aload #30
    //   2545: invokevirtual v : ()Ldbxyzptlk/l1/l;
    //   2548: getstatic dbxyzptlk/l1/s.a : Ldbxyzptlk/l1/s;
    //   2551: invokevirtual g : ()Ldbxyzptlk/l1/w;
    //   2554: invokestatic a : (Ldbxyzptlk/l1/l;Ldbxyzptlk/l1/w;)Ljava/lang/Object;
    //   2557: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
    //   2560: invokestatic c : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   2563: ifeq -> 2585
    //   2566: aload_0
    //   2567: getfield d : Landroidx/compose/ui/platform/AndroidComposeView;
    //   2570: invokevirtual getFocusOwner : ()Ldbxyzptlk/O0/j;
    //   2573: iconst_0
    //   2574: iconst_1
    //   2575: aconst_null
    //   2576: invokestatic k : (Ldbxyzptlk/O0/g;ZILjava/lang/Object;)V
    //   2579: iconst_1
    //   2580: istore #12
    //   2582: goto -> 2588
    //   2585: iconst_0
    //   2586: istore #12
    //   2588: iload #12
    //   2590: ireturn
    //   2591: aload #30
    //   2593: invokevirtual v : ()Ldbxyzptlk/l1/l;
    //   2596: getstatic dbxyzptlk/l1/k.a : Ldbxyzptlk/l1/k;
    //   2599: invokevirtual r : ()Ldbxyzptlk/l1/w;
    //   2602: invokestatic a : (Ldbxyzptlk/l1/l;Ldbxyzptlk/l1/w;)Ljava/lang/Object;
    //   2605: checkcast dbxyzptlk/l1/a
    //   2608: astore_3
    //   2609: aload_3
    //   2610: ifnull -> 2642
    //   2613: aload_3
    //   2614: invokevirtual a : ()Ldbxyzptlk/pI/f;
    //   2617: checkcast dbxyzptlk/CI/a
    //   2620: astore_3
    //   2621: aload_3
    //   2622: ifnull -> 2642
    //   2625: aload_3
    //   2626: invokeinterface invoke : ()Ljava/lang/Object;
    //   2631: checkcast java/lang/Boolean
    //   2634: invokevirtual booleanValue : ()Z
    //   2637: istore #12
    //   2639: goto -> 2645
    //   2642: iconst_0
    //   2643: istore #12
    //   2645: iload #12
    //   2647: ireturn
    //   2648: iconst_m1
    //   2649: istore_2
    //   2650: aload_3
    //   2651: ifnull -> 2666
    //   2654: aload_3
    //   2655: ldc_w 'ACTION_ARGUMENT_SELECTION_START_INT'
    //   2658: iconst_m1
    //   2659: invokevirtual getInt : (Ljava/lang/String;I)I
    //   2662: istore_1
    //   2663: goto -> 2668
    //   2666: iconst_m1
    //   2667: istore_1
    //   2668: aload_3
    //   2669: ifnull -> 2681
    //   2672: aload_3
    //   2673: ldc_w 'ACTION_ARGUMENT_SELECTION_END_INT'
    //   2676: iconst_m1
    //   2677: invokevirtual getInt : (Ljava/lang/String;I)I
    //   2680: istore_2
    //   2681: aload_0
    //   2682: aload #30
    //   2684: iload_1
    //   2685: iload_2
    //   2686: iconst_0
    //   2687: invokevirtual X0 : (Ldbxyzptlk/l1/p;IIZ)Z
    //   2690: istore #12
    //   2692: iload #12
    //   2694: ifeq -> 2717
    //   2697: aload_0
    //   2698: aload_0
    //   2699: aload #30
    //   2701: invokevirtual n : ()I
    //   2704: invokevirtual L0 : (I)I
    //   2707: iconst_0
    //   2708: aconst_null
    //   2709: aconst_null
    //   2710: bipush #12
    //   2712: aconst_null
    //   2713: invokestatic R0 : (Landroidx/compose/ui/platform/AndroidComposeViewAccessibilityDelegateCompat;IILjava/lang/Integer;Ljava/util/List;ILjava/lang/Object;)Z
    //   2716: pop
    //   2717: iload #12
    //   2719: ireturn
    //   2720: aload #30
    //   2722: invokevirtual v : ()Ldbxyzptlk/l1/l;
    //   2725: getstatic dbxyzptlk/l1/k.a : Ldbxyzptlk/l1/k;
    //   2728: invokevirtual c : ()Ldbxyzptlk/l1/w;
    //   2731: invokestatic a : (Ldbxyzptlk/l1/l;Ldbxyzptlk/l1/w;)Ljava/lang/Object;
    //   2734: checkcast dbxyzptlk/l1/a
    //   2737: astore_3
    //   2738: aload_3
    //   2739: ifnull -> 2771
    //   2742: aload_3
    //   2743: invokevirtual a : ()Ldbxyzptlk/pI/f;
    //   2746: checkcast dbxyzptlk/CI/a
    //   2749: astore_3
    //   2750: aload_3
    //   2751: ifnull -> 2771
    //   2754: aload_3
    //   2755: invokeinterface invoke : ()Ljava/lang/Object;
    //   2760: checkcast java/lang/Boolean
    //   2763: invokevirtual booleanValue : ()Z
    //   2766: istore #12
    //   2768: goto -> 2774
    //   2771: iconst_0
    //   2772: istore #12
    //   2774: iload #12
    //   2776: ireturn
    //   2777: aload_3
    //   2778: ifnull -> 2826
    //   2781: aload_3
    //   2782: ldc_w 'ACTION_ARGUMENT_MOVEMENT_GRANULARITY_INT'
    //   2785: invokevirtual getInt : (Ljava/lang/String;)I
    //   2788: istore_1
    //   2789: aload_3
    //   2790: ldc_w 'ACTION_ARGUMENT_EXTEND_SELECTION_BOOLEAN'
    //   2793: invokevirtual getBoolean : (Ljava/lang/String;)Z
    //   2796: istore #13
    //   2798: iload_2
    //   2799: sipush #256
    //   2802: if_icmpne -> 2811
    //   2805: iconst_1
    //   2806: istore #12
    //   2808: goto -> 2814
    //   2811: iconst_0
    //   2812: istore #12
    //   2814: aload_0
    //   2815: aload #30
    //   2817: iload_1
    //   2818: iload #12
    //   2820: iload #13
    //   2822: invokevirtual m1 : (Ldbxyzptlk/l1/p;IZZ)Z
    //   2825: ireturn
    //   2826: iconst_0
    //   2827: ireturn
    //   2828: aload_0
    //   2829: iload_1
    //   2830: invokevirtual clearAccessibilityFocus : (I)Z
    //   2833: ireturn
    //   2834: aload_0
    //   2835: iload_1
    //   2836: invokevirtual requestAccessibilityFocus : (I)Z
    //   2839: istore #12
    //   2841: iload #12
    //   2843: ireturn
  }
  
  public final void E(int paramInt, AccessibilityNodeInfo paramAccessibilityNodeInfo, String paramString, Bundle paramBundle) {
    x1 x1 = W().get(Integer.valueOf(paramInt));
    if (x1 != null) {
      p p = x1.b();
      if (p != null) {
        String str = e0(p);
        if (s.c(paramString, this.J)) {
          Integer integer = this.H.get(Integer.valueOf(paramInt));
          if (integer != null)
            paramAccessibilityNodeInfo.getExtras().putInt(paramString, integer.intValue()); 
        } else {
          Integer integer;
          if (s.c(paramString, this.K)) {
            integer = this.I.get(Integer.valueOf(paramInt));
            if (integer != null)
              paramAccessibilityNodeInfo.getExtras().putInt(paramString, integer.intValue()); 
          } else {
            ArrayList<RectF> arrayList;
            if (p.v().j(dbxyzptlk.l1.k.a.h()) && integer != null && s.c(paramString, "android.view.accessibility.extra.DATA_TEXT_CHARACTER_LOCATION_KEY")) {
              int j = integer.getInt("android.view.accessibility.extra.DATA_TEXT_CHARACTER_LOCATION_ARG_START_INDEX", -1);
              int m = integer.getInt("android.view.accessibility.extra.DATA_TEXT_CHARACTER_LOCATION_ARG_LENGTH", -1);
              if (m > 0 && j >= 0) {
                if (str != null) {
                  paramInt = str.length();
                } else {
                  paramInt = Integer.MAX_VALUE;
                } 
                if (j >= paramInt)
                  r0.d("AccessibilityDelegate", "Invalid arguments for accessibility character locations"); 
                F f = h0(p.v());
                if (f == null)
                  return; 
                arrayList = new ArrayList();
                for (paramInt = 0; paramInt < m; paramInt++) {
                  int n = j + paramInt;
                  if (n >= f.l().j().length()) {
                    arrayList.add(null);
                  } else {
                    arrayList.add(j1(p, f.d(n)));
                  } 
                } 
                paramAccessibilityNodeInfo.getExtras().putParcelableArray(paramString, (Parcelable[])arrayList.toArray((Object[])new RectF[0]));
                return;
              } 
            } else {
              l l1 = p.v();
              s s = s.a;
              if (l1.j(s.y()) && arrayList != null && s.c(paramString, "androidx.compose.ui.semantics.testTag")) {
                String str1 = (String)m.a(p.v(), s.y());
                if (str1 != null)
                  paramAccessibilityNodeInfo.getExtras().putCharSequence(paramString, str1); 
              } else if (s.c(paramString, "androidx.compose.ui.semantics.id")) {
                paramAccessibilityNodeInfo.getExtras().putInt(paramString, p.n());
              } 
              return;
            } 
            r0.d("AccessibilityDelegate", "Invalid arguments for accessibility character locations");
          } 
        } 
      } 
    } 
  }
  
  public final Rect F(x1 paramx1) {
    Rect rect = paramx1.a();
    long l2 = this.d.A(g.a(rect.left, rect.top));
    long l1 = this.d.A(g.a(rect.right, rect.bottom));
    return new Rect((int)(float)Math.floor(f.o(l2)), (int)(float)Math.floor(f.p(l2)), (int)(float)Math.ceil(f.o(l1)), (int)(float)Math.ceil(f.p(l1)));
  }
  
  public final void F0(int paramInt, t paramt, p paramp) {
    StringBuilder stringBuilder;
    paramt.i0("android.view.View");
    l l2 = paramp.v();
    s s1 = s.a;
    dbxyzptlk.l1.i i1 = (dbxyzptlk.l1.i)m.a(l2, s1.u());
    if (i1 != null) {
      i1.n();
      if (paramp.w() || paramp.s().isEmpty()) {
        dbxyzptlk.l1.i.a a4 = dbxyzptlk.l1.i.b;
        int n = a4.g();
        if (dbxyzptlk.l1.i.k(i1.n(), n)) {
          paramt.I0(this.d.getContext().getResources().getString(dbxyzptlk.K0.i.tab));
        } else {
          n = a4.f();
          if (dbxyzptlk.l1.i.k(i1.n(), n)) {
            paramt.I0(this.d.getContext().getResources().getString(dbxyzptlk.K0.i.switch_role));
          } else {
            String str = C.n(i1.n());
            n = a4.d();
            if (!dbxyzptlk.l1.i.k(i1.n(), n) || paramp.z() || paramp.v().x())
              paramt.i0(str); 
          } 
        } 
      } 
      D d1 = D.a;
    } 
    if (paramp.v().j(dbxyzptlk.l1.k.a.w()))
      paramt.i0("android.widget.EditText"); 
    if (paramp.m().j(s1.z()))
      paramt.i0("android.widget.TextView"); 
    paramt.C0(this.d.getContext().getPackageName());
    paramt.w0(C.k(paramp));
    List<p> list = paramp.s();
    int m = list.size();
    int j;
    for (j = 0; j < m; j++) {
      p p1 = list.get(j);
      if (W().containsKey(Integer.valueOf(p1.n()))) {
        AndroidViewHolder androidViewHolder = (AndroidViewHolder)this.d.getAndroidViewsHandler$ui_release().getLayoutNodeToHolder().get(p1.p());
        if (androidViewHolder != null) {
          paramt.c((View)androidViewHolder);
        } else if (p1.n() != -1) {
          paramt.d((View)this.d, p1.n());
        } 
      } 
    } 
    if (paramInt == this.o) {
      paramt.b0(true);
      paramt.b(t.a.l);
    } else {
      paramt.b0(false);
      paramt.b(t.a.k);
    } 
    c1(paramp, paramt);
    Z0(paramp, paramt);
    b1(paramp, paramt);
    a1(paramp, paramt);
    l l3 = paramp.v();
    s1 = s.a;
    dbxyzptlk.m1.a a2 = (dbxyzptlk.m1.a)m.a(l3, s1.C());
    if (a2 != null) {
      if (a2 == dbxyzptlk.m1.a.On) {
        paramt.h0(true);
      } else if (a2 == dbxyzptlk.m1.a.Off) {
        paramt.h0(false);
      } 
      D d1 = D.a;
    } 
    Boolean bool1 = (Boolean)m.a(paramp.v(), s1.w());
    if (bool1 != null) {
      boolean bool2;
      boolean bool3 = bool1.booleanValue();
      j = dbxyzptlk.l1.i.b.g();
      if (i1 == null) {
        bool2 = false;
      } else {
        bool2 = dbxyzptlk.l1.i.k(i1.n(), j);
      } 
      if (bool2) {
        paramt.L0(bool3);
      } else {
        paramt.h0(bool3);
      } 
      D d1 = D.a;
    } 
    if (!paramp.v().x() || paramp.s().isEmpty())
      paramt.m0(C.g(paramp)); 
    String str2 = (String)m.a(paramp.v(), s1.y());
    if (str2 != null) {
      boolean bool2;
      p p1 = paramp;
      while (true) {
        if (p1 != null) {
          l l4 = p1.v();
          t t1 = t.a;
          if (l4.j(t1.a())) {
            boolean bool3 = ((Boolean)p1.v().m(t1.a())).booleanValue();
            break;
          } 
          p1 = p1.q();
          continue;
        } 
        bool2 = false;
        break;
      } 
      if (bool2)
        paramt.W0(str2); 
    } 
    l l1 = paramp.v();
    s s2 = s.a;
    if ((D)m.a(l1, s2.h()) != null) {
      paramt.u0(true);
      D d1 = D.a;
    } 
    paramt.G0(paramp.m().j(s2.s()));
    l1 = paramp.v();
    dbxyzptlk.l1.k k1 = dbxyzptlk.l1.k.a;
    paramt.p0(l1.j(k1.w()));
    paramt.q0(C.b(paramp));
    paramt.s0(paramp.v().j(s2.g()));
    boolean bool = paramt.K();
    j = 2;
    if (bool) {
      paramt.t0(((Boolean)paramp.v().m(s2.g())).booleanValue());
      if (paramt.L()) {
        paramt.a(2);
      } else {
        paramt.a(1);
      } 
    } 
    paramt.X0(C.l(paramp));
    g g1 = (g)m.a(paramp.v(), s2.q());
    if (g1 != null) {
      m = g1.i();
      g.a a4 = g.b;
      if (g.f(m, a4.b()) || !g.f(m, a4.a()))
        j = 1; 
      paramt.y0(j);
      D d1 = D.a;
    } 
    paramt.j0(false);
    dbxyzptlk.l1.a a1 = (dbxyzptlk.l1.a)m.a(paramp.v(), k1.j());
    if (a1 != null) {
      bool = s.c(m.a(paramp.v(), s2.w()), Boolean.TRUE);
      paramt.j0(bool ^ true);
      if (C.b(paramp) && !bool)
        paramt.b(new t.a(16, a1.b())); 
      D d1 = D.a;
    } 
    paramt.z0(false);
    a1 = (dbxyzptlk.l1.a)m.a(paramp.v(), k1.l());
    if (a1 != null) {
      paramt.z0(true);
      if (C.b(paramp))
        paramt.b(new t.a(32, a1.b())); 
      D d1 = D.a;
    } 
    a1 = (dbxyzptlk.l1.a)m.a(paramp.v(), k1.c());
    if (a1 != null) {
      paramt.b(new t.a(16384, a1.b()));
      D d1 = D.a;
    } 
    if (C.b(paramp)) {
      a1 = (dbxyzptlk.l1.a)m.a(paramp.v(), k1.w());
      if (a1 != null) {
        paramt.b(new t.a(2097152, a1.b()));
        D d1 = D.a;
      } 
      a1 = (dbxyzptlk.l1.a)m.a(paramp.v(), k1.k());
      if (a1 != null) {
        paramt.b(new t.a(16908372, a1.b()));
        D d1 = D.a;
      } 
      a1 = (dbxyzptlk.l1.a)m.a(paramp.v(), k1.e());
      if (a1 != null) {
        paramt.b(new t.a(65536, a1.b()));
        D d1 = D.a;
      } 
      a1 = (dbxyzptlk.l1.a)m.a(paramp.v(), k1.q());
      if (a1 != null) {
        if (paramt.L() && this.d.getClipboardManager().a())
          paramt.b(new t.a(32768, a1.b())); 
        D d1 = D.a;
      } 
    } 
    String str1 = e0(paramp);
    if (str1 == null || str1.length() == 0) {
      j = 1;
    } else {
      j = 0;
    } 
    if (j == 0) {
      paramt.R0(T(paramp), S(paramp));
      dbxyzptlk.l1.a a4 = (dbxyzptlk.l1.a)m.a(paramp.v(), k1.v());
      if (a4 != null) {
        String str = a4.b();
      } else {
        a4 = null;
      } 
      paramt.b(new t.a(131072, (CharSequence)a4));
      paramt.a(256);
      paramt.a(512);
      paramt.B0(11);
      List list1 = (List)m.a(paramp.v(), s2.c());
      if (list1 == null || list1.isEmpty()) {
        j = 1;
      } else {
        j = 0;
      } 
      if (j != 0 && paramp.v().j(k1.h()) && !C.c(paramp))
        paramt.B0(paramt.v() | 0x14); 
    } 
    m = Build.VERSION.SDK_INT;
    ArrayList<String> arrayList = new ArrayList();
    arrayList.add("androidx.compose.ui.semantics.id");
    CharSequence charSequence = paramt.y();
    if (charSequence == null || charSequence.length() == 0) {
      j = 1;
    } else {
      j = 0;
    } 
    if (j == 0 && paramp.v().j(k1.h()))
      arrayList.add("android.view.accessibility.extra.DATA_TEXT_CHARACTER_LOCATION_KEY"); 
    if (paramp.v().j(s2.y()))
      arrayList.add("androidx.compose.ui.semantics.testTag"); 
    c.a.a(paramt.Y0(), arrayList);
    h h = (h)m.a(paramp.v(), s2.t());
    if (h != null) {
      if (paramp.v().j(k1.u())) {
        paramt.i0("android.widget.SeekBar");
      } else {
        paramt.i0("android.widget.ProgressBar");
      } 
      if (h != h.d.a())
        paramt.H0(t.g.a(1, ((Number)h.c().e()).floatValue(), ((Number)h.c().k()).floatValue(), h.b())); 
      if (paramp.v().j(k1.u()) && C.b(paramp)) {
        if (h.b() < dbxyzptlk.KI.n.d(((Number)h.c().k()).floatValue(), ((Number)h.c().e()).floatValue()))
          paramt.b(t.a.q); 
        if (h.b() > dbxyzptlk.KI.n.h(((Number)h.c().e()).floatValue(), ((Number)h.c().k()).floatValue()))
          paramt.b(t.a.r); 
      } 
    } 
    b.a(paramt, paramp);
    dbxyzptlk.h1.a.d(paramp, paramt);
    dbxyzptlk.h1.a.e(paramp, paramt);
    j j2 = (j)m.a(paramp.v(), s2.i());
    dbxyzptlk.l1.a a3 = (dbxyzptlk.l1.a)m.a(paramp.v(), k1.s());
    if (j2 != null && a3 != null) {
      if (!dbxyzptlk.h1.a.b(paramp))
        paramt.i0("android.widget.HorizontalScrollView"); 
      if (((Number)j2.a().invoke()).floatValue() > 0.0F)
        paramt.K0(true); 
      if (C.b(paramp)) {
        if (H0(j2)) {
          t.a a4;
          paramt.b(t.a.q);
          if (paramp.o().getLayoutDirection() == t.Rtl) {
            j = 1;
          } else {
            j = 0;
          } 
          if (j == 0) {
            a4 = t.a.F;
          } else {
            a4 = t.a.D;
          } 
          paramt.b(a4);
        } 
        if (G0(j2)) {
          t.a a4;
          paramt.b(t.a.r);
          if (paramp.o().getLayoutDirection() == t.Rtl) {
            j = 1;
          } else {
            j = 0;
          } 
          if (j == 0) {
            a4 = t.a.D;
          } else {
            a4 = t.a.F;
          } 
          paramt.b(a4);
        } 
      } 
    } 
    j j1 = (j)m.a(paramp.v(), s2.E());
    if (j1 != null && a3 != null) {
      if (!dbxyzptlk.h1.a.b(paramp))
        paramt.i0("android.widget.ScrollView"); 
      if (((Number)j1.a().invoke()).floatValue() > 0.0F)
        paramt.K0(true); 
      if (C.b(paramp)) {
        if (H0(j1)) {
          paramt.b(t.a.q);
          paramt.b(t.a.E);
        } 
        if (G0(j1)) {
          paramt.b(t.a.r);
          paramt.b(t.a.C);
        } 
      } 
    } 
    if (m >= 29)
      c.a(paramt, paramp); 
    paramt.D0((CharSequence)m.a(paramp.v(), s2.r()));
    if (C.b(paramp)) {
      dbxyzptlk.l1.a a4 = (dbxyzptlk.l1.a)m.a(paramp.v(), k1.g());
      if (a4 != null) {
        paramt.b(new t.a(262144, a4.b()));
        D d1 = D.a;
      } 
      a4 = (dbxyzptlk.l1.a)m.a(paramp.v(), k1.b());
      if (a4 != null) {
        paramt.b(new t.a(524288, a4.b()));
        D d1 = D.a;
      } 
      a4 = (dbxyzptlk.l1.a)m.a(paramp.v(), k1.f());
      if (a4 != null) {
        paramt.b(new t.a(1048576, a4.b()));
        D d1 = D.a;
      } 
      if (paramp.v().j(k1.d())) {
        dbxyzptlk.l1.e e;
        List<dbxyzptlk.l1.e> list1 = (List)paramp.v().m(k1.d());
        j = list1.size();
        int[] arrayOfInt = U;
        if (j < arrayOfInt.length) {
          dbxyzptlk.l1.e<dbxyzptlk.l1.e> e1;
          F f = new F(0, 1, null);
          LinkedHashMap<Object, Object> linkedHashMap = new LinkedHashMap<>();
          if (this.u.d(paramInt)) {
            Map map = (Map)this.u.i(paramInt);
            List<Number> list2 = dbxyzptlk.qI.o.V0(arrayOfInt);
            ArrayList<dbxyzptlk.l1.e> arrayList1 = new ArrayList();
            m = list1.size();
            for (j = 0; j < m; j++) {
              dbxyzptlk.l1.e e2 = list1.get(j);
              s.e(map);
              if (map.containsKey(e2.b())) {
                Integer integer = (Integer)map.get(e2.b());
                s.e(integer);
                f.o(integer.intValue(), e2.b());
                linkedHashMap.put(e2.b(), integer);
                list2.remove(integer);
                paramt.b(new t.a(integer.intValue(), e2.b()));
              } else {
                arrayList1.add(e2);
              } 
            } 
            m = arrayList1.size();
            for (j = 0; j < m; j++) {
              e1 = arrayList1.get(j);
              int n = ((Number)list2.get(j)).intValue();
              f.o(n, e1.b());
              linkedHashMap.put(e1.b(), Integer.valueOf(n));
              paramt.b(new t.a(n, e1.b()));
            } 
          } else {
            m = e1.size();
            for (j = 0; j < m; j++) {
              e = e1.get(j);
              int n = U[j];
              f.o(n, e.b());
              linkedHashMap.put(e.b(), Integer.valueOf(n));
              paramt.b(new t.a(n, e.b()));
            } 
          } 
          this.t.o(paramInt, f);
          this.u.o(paramInt, linkedHashMap);
        } else {
          stringBuilder = new StringBuilder();
          stringBuilder.append("Can't have more than ");
          stringBuilder.append(e.length);
          stringBuilder.append(" custom actions for one widget");
          throw new IllegalStateException(stringBuilder.toString());
        } 
      } 
    } 
    stringBuilder.J0(r0(paramp));
    Integer integer2 = this.H.get(Integer.valueOf(paramInt));
    if (integer2 != null) {
      View view = C.D(this.d.getAndroidViewsHandler$ui_release(), integer2.intValue());
      if (view != null) {
        stringBuilder.U0(view);
      } else {
        stringBuilder.V0((View)this.d, integer2.intValue());
      } 
      E(paramInt, stringBuilder.Y0(), this.J, null);
      D d1 = D.a;
    } 
    Integer integer1 = this.I.get(Integer.valueOf(paramInt));
    if (integer1 != null) {
      View view = C.D(this.d.getAndroidViewsHandler$ui_release(), integer1.intValue());
      if (view != null) {
        stringBuilder.S0(view);
        E(paramInt, stringBuilder.Y0(), this.K, null);
      } 
      D d1 = D.a;
    } 
  }
  
  public final Object G(dbxyzptlk.tI.d<? super D> paramd) {
    // Byte code:
    //   0: aload_1
    //   1: instanceof androidx/compose/ui/platform/AndroidComposeViewAccessibilityDelegateCompat$n
    //   4: ifeq -> 40
    //   7: aload_1
    //   8: checkcast androidx/compose/ui/platform/AndroidComposeViewAccessibilityDelegateCompat$n
    //   11: astore #4
    //   13: aload #4
    //   15: getfield y : I
    //   18: istore_2
    //   19: iload_2
    //   20: ldc_w -2147483648
    //   23: iand
    //   24: ifeq -> 40
    //   27: aload #4
    //   29: iload_2
    //   30: ldc_w -2147483648
    //   33: iadd
    //   34: putfield y : I
    //   37: goto -> 51
    //   40: new androidx/compose/ui/platform/AndroidComposeViewAccessibilityDelegateCompat$n
    //   43: dup
    //   44: aload_0
    //   45: aload_1
    //   46: invokespecial <init> : (Landroidx/compose/ui/platform/AndroidComposeViewAccessibilityDelegateCompat;Ldbxyzptlk/tI/d;)V
    //   49: astore #4
    //   51: aload #4
    //   53: getfield w : Ljava/lang/Object;
    //   56: astore #9
    //   58: invokestatic g : ()Ljava/lang/Object;
    //   61: astore #10
    //   63: aload #4
    //   65: getfield y : I
    //   68: istore_2
    //   69: iload_2
    //   70: ifeq -> 203
    //   73: iload_2
    //   74: iconst_1
    //   75: if_icmpeq -> 150
    //   78: iload_2
    //   79: iconst_2
    //   80: if_icmpne -> 139
    //   83: aload #4
    //   85: getfield v : Ljava/lang/Object;
    //   88: checkcast dbxyzptlk/dK/f
    //   91: astore #7
    //   93: aload #4
    //   95: getfield u : Ljava/lang/Object;
    //   98: checkcast dbxyzptlk/V/b
    //   101: astore #6
    //   103: aload #4
    //   105: getfield t : Ljava/lang/Object;
    //   108: checkcast androidx/compose/ui/platform/AndroidComposeViewAccessibilityDelegateCompat
    //   111: astore #5
    //   113: aload #5
    //   115: astore_1
    //   116: aload #9
    //   118: invokestatic b : (Ljava/lang/Object;)V
    //   121: aload #6
    //   123: astore_1
    //   124: aload #4
    //   126: astore #6
    //   128: aload_1
    //   129: astore #8
    //   131: goto -> 239
    //   134: astore #4
    //   136: goto -> 598
    //   139: new java/lang/IllegalStateException
    //   142: dup
    //   143: ldc_w 'call to 'resume' before 'invoke' with coroutine'
    //   146: invokespecial <init> : (Ljava/lang/String;)V
    //   149: athrow
    //   150: aload #4
    //   152: getfield v : Ljava/lang/Object;
    //   155: checkcast dbxyzptlk/dK/f
    //   158: astore #7
    //   160: aload #4
    //   162: getfield u : Ljava/lang/Object;
    //   165: checkcast dbxyzptlk/V/b
    //   168: astore #5
    //   170: aload #4
    //   172: getfield t : Ljava/lang/Object;
    //   175: checkcast androidx/compose/ui/platform/AndroidComposeViewAccessibilityDelegateCompat
    //   178: astore #8
    //   180: aload #8
    //   182: astore_1
    //   183: aload #9
    //   185: invokestatic b : (Ljava/lang/Object;)V
    //   188: aload #4
    //   190: astore #6
    //   192: aload #8
    //   194: astore #4
    //   196: aload #9
    //   198: astore #8
    //   200: goto -> 316
    //   203: aload #9
    //   205: invokestatic b : (Ljava/lang/Object;)V
    //   208: new dbxyzptlk/V/b
    //   211: astore #8
    //   213: aload #8
    //   215: iconst_0
    //   216: iconst_1
    //   217: aconst_null
    //   218: invokespecial <init> : (IILkotlin/jvm/internal/DefaultConstructorMarker;)V
    //   221: aload_0
    //   222: getfield y : Ldbxyzptlk/dK/d;
    //   225: invokeinterface iterator : ()Ldbxyzptlk/dK/f;
    //   230: astore #7
    //   232: aload_0
    //   233: astore #5
    //   235: aload #4
    //   237: astore #6
    //   239: aload #5
    //   241: astore_1
    //   242: aload #6
    //   244: aload #5
    //   246: putfield t : Ljava/lang/Object;
    //   249: aload #5
    //   251: astore_1
    //   252: aload #6
    //   254: aload #8
    //   256: putfield u : Ljava/lang/Object;
    //   259: aload #5
    //   261: astore_1
    //   262: aload #6
    //   264: aload #7
    //   266: putfield v : Ljava/lang/Object;
    //   269: aload #5
    //   271: astore_1
    //   272: aload #6
    //   274: iconst_1
    //   275: putfield y : I
    //   278: aload #5
    //   280: astore_1
    //   281: aload #7
    //   283: aload #6
    //   285: invokeinterface a : (Ldbxyzptlk/tI/d;)Ljava/lang/Object;
    //   290: astore #4
    //   292: aload #4
    //   294: aload #10
    //   296: if_acmpne -> 302
    //   299: aload #10
    //   301: areturn
    //   302: aload #8
    //   304: astore_1
    //   305: aload #4
    //   307: astore #8
    //   309: aload #5
    //   311: astore #4
    //   313: aload_1
    //   314: astore #5
    //   316: aload #4
    //   318: astore_1
    //   319: aload #8
    //   321: checkcast java/lang/Boolean
    //   324: invokevirtual booleanValue : ()Z
    //   327: ifeq -> 582
    //   330: aload #4
    //   332: astore_1
    //   333: aload #7
    //   335: invokeinterface next : ()Ljava/lang/Object;
    //   340: pop
    //   341: aload #4
    //   343: astore_1
    //   344: aload #4
    //   346: invokevirtual q0 : ()Z
    //   349: ifeq -> 360
    //   352: aload #4
    //   354: astore_1
    //   355: aload #4
    //   357: invokevirtual t0 : ()V
    //   360: aload #4
    //   362: astore_1
    //   363: aload #4
    //   365: invokevirtual p0 : ()Z
    //   368: ifeq -> 480
    //   371: aload #4
    //   373: astore_1
    //   374: aload #4
    //   376: getfield x : Ldbxyzptlk/V/b;
    //   379: invokevirtual size : ()I
    //   382: istore_3
    //   383: iconst_0
    //   384: istore_2
    //   385: iload_2
    //   386: iload_3
    //   387: if_icmpge -> 435
    //   390: aload #4
    //   392: astore_1
    //   393: aload #4
    //   395: getfield x : Ldbxyzptlk/V/b;
    //   398: iload_2
    //   399: invokevirtual z : (I)Ljava/lang/Object;
    //   402: checkcast androidx/compose/ui/node/f
    //   405: astore #8
    //   407: aload #4
    //   409: astore_1
    //   410: aload #4
    //   412: aload #8
    //   414: aload #5
    //   416: invokevirtual V0 : (Landroidx/compose/ui/node/f;Ldbxyzptlk/V/b;)V
    //   419: aload #4
    //   421: astore_1
    //   422: aload #4
    //   424: aload #8
    //   426: invokevirtual W0 : (Landroidx/compose/ui/node/f;)V
    //   429: iinc #2, 1
    //   432: goto -> 385
    //   435: aload #4
    //   437: astore_1
    //   438: aload #5
    //   440: invokevirtual clear : ()V
    //   443: aload #4
    //   445: astore_1
    //   446: aload #4
    //   448: getfield O : Z
    //   451: ifne -> 480
    //   454: aload #4
    //   456: astore_1
    //   457: aload #4
    //   459: iconst_1
    //   460: putfield O : Z
    //   463: aload #4
    //   465: astore_1
    //   466: aload #4
    //   468: getfield m : Landroid/os/Handler;
    //   471: aload #4
    //   473: getfield P : Ljava/lang/Runnable;
    //   476: invokevirtual post : (Ljava/lang/Runnable;)Z
    //   479: pop
    //   480: aload #4
    //   482: astore_1
    //   483: aload #4
    //   485: getfield x : Ldbxyzptlk/V/b;
    //   488: invokevirtual clear : ()V
    //   491: aload #4
    //   493: astore_1
    //   494: aload #4
    //   496: getfield r : Ljava/util/HashMap;
    //   499: invokevirtual clear : ()V
    //   502: aload #4
    //   504: astore_1
    //   505: aload #4
    //   507: getfield s : Ljava/util/HashMap;
    //   510: invokevirtual clear : ()V
    //   513: aload #4
    //   515: astore_1
    //   516: aload #6
    //   518: aload #4
    //   520: putfield t : Ljava/lang/Object;
    //   523: aload #4
    //   525: astore_1
    //   526: aload #6
    //   528: aload #5
    //   530: putfield u : Ljava/lang/Object;
    //   533: aload #4
    //   535: astore_1
    //   536: aload #6
    //   538: aload #7
    //   540: putfield v : Ljava/lang/Object;
    //   543: aload #4
    //   545: astore_1
    //   546: aload #6
    //   548: iconst_2
    //   549: putfield y : I
    //   552: aload #4
    //   554: astore_1
    //   555: ldc2_w 100
    //   558: aload #6
    //   560: invokestatic a : (JLdbxyzptlk/tI/d;)Ljava/lang/Object;
    //   563: astore #8
    //   565: aload #5
    //   567: astore_1
    //   568: aload #4
    //   570: astore #5
    //   572: aload #8
    //   574: aload #10
    //   576: if_acmpne -> 128
    //   579: aload #10
    //   581: areturn
    //   582: aload #4
    //   584: getfield x : Ldbxyzptlk/V/b;
    //   587: invokevirtual clear : ()V
    //   590: getstatic dbxyzptlk/pI/D.a : Ldbxyzptlk/pI/D;
    //   593: areturn
    //   594: astore #4
    //   596: aload_0
    //   597: astore_1
    //   598: aload_1
    //   599: getfield x : Ldbxyzptlk/V/b;
    //   602: invokevirtual clear : ()V
    //   605: aload #4
    //   607: athrow
    // Exception table:
    //   from	to	target	type
    //   116	121	134	finally
    //   183	188	134	finally
    //   208	232	594	finally
    //   242	249	134	finally
    //   252	259	134	finally
    //   262	269	134	finally
    //   272	278	134	finally
    //   281	292	134	finally
    //   319	330	134	finally
    //   333	341	134	finally
    //   344	352	134	finally
    //   355	360	134	finally
    //   363	371	134	finally
    //   374	383	134	finally
    //   393	407	134	finally
    //   410	419	134	finally
    //   422	429	134	finally
    //   438	443	134	finally
    //   446	454	134	finally
    //   457	463	134	finally
    //   466	480	134	finally
    //   483	491	134	finally
    //   494	502	134	finally
    //   505	513	134	finally
    //   516	523	134	finally
    //   526	533	134	finally
    //   536	543	134	finally
    //   546	552	134	finally
    //   555	565	134	finally
  }
  
  public final void H(int paramInt, dbxyzptlk.j1.e parame) {
    if (parame == null)
      return; 
    if (this.D.contains(Integer.valueOf(paramInt))) {
      this.D.remove(Integer.valueOf(paramInt));
    } else {
      this.C.put(Integer.valueOf(paramInt), parame);
    } 
  }
  
  public final void I(int paramInt) {
    if (this.C.containsKey(Integer.valueOf(paramInt))) {
      this.C.remove(Integer.valueOf(paramInt));
    } else {
      this.D.add(Integer.valueOf(paramInt));
    } 
  }
  
  public final boolean I0(int paramInt, List<w1> paramList) {
    boolean bool;
    w1 w1 = C.d(paramList, paramInt);
    if (w1 != null) {
      bool = false;
    } else {
      w1 = new w1(paramInt, this.Q, null, null, null, null);
      bool = true;
    } 
    this.Q.add(w1);
    return bool;
  }
  
  public final boolean J(boolean paramBoolean, int paramInt, long paramLong) {
    return !s.c(Looper.getMainLooper().getThread(), Thread.currentThread()) ? false : K(W().values(), paramBoolean, paramInt, paramLong);
  }
  
  public final void J0(w1 paramw1) {
    if (!paramw1.k0())
      return; 
    this.d.getSnapshotObserver().i((T)paramw1, this.R, (dbxyzptlk.CI.a)new p(paramw1, this));
  }
  
  public final boolean K(Collection<x1> paramCollection, boolean paramBoolean, int paramInt, long paramLong) {
    w w;
    boolean bool1 = f.l(paramLong, f.b.b());
    boolean bool = false;
    if (bool1 || !f.r(paramLong))
      return false; 
    if (paramBoolean == true) {
      w = s.a.E();
    } else if (!paramBoolean) {
      w = s.a.i();
    } else {
      throw new NoWhenBranchMatchedException();
    } 
    paramCollection = paramCollection;
    if (paramCollection instanceof Collection && paramCollection.isEmpty()) {
      paramBoolean = bool;
    } else {
      Iterator<x1> iterator = paramCollection.iterator();
      while (true) {
        paramBoolean = bool;
        if (iterator.hasNext()) {
          x1 x1 = iterator.next();
          if (T0.c(x1.a()).f(paramLong)) {
            j j = (j)m.a(x1.b().m(), w);
            if (j != null) {
              int m;
              if (j.b()) {
                m = -paramInt;
              } else {
                m = paramInt;
              } 
              int n = m;
              if (paramInt == 0) {
                n = m;
                if (j.b())
                  n = -1; 
              } 
              if ((n < 0) ? (((Number)j.c().invoke()).floatValue() > 0.0F) : (((Number)j.c().invoke()).floatValue() < ((Number)j.a().invoke()).floatValue())) {
                m = 1;
                continue;
              } 
            } 
          } 
          boolean bool2 = false;
          continue;
        } 
        break;
        if (SYNTHETIC_LOCAL_VARIABLE_6 != null) {
          paramBoolean = true;
          break;
        } 
      } 
    } 
    return paramBoolean;
  }
  
  public final void L() {
    if (p0())
      M0(this.d.getSemanticsOwner().a(), this.N); 
    if (q0())
      N0(this.d.getSemanticsOwner().a(), this.N); 
    U0(W());
    q1();
  }
  
  public final int L0(int paramInt) {
    int j = paramInt;
    if (paramInt == this.d.getSemanticsOwner().a().n())
      j = -1; 
    return j;
  }
  
  public final void M() {
    Iterator<x1> iterator = W().values().iterator();
    while (iterator.hasNext()) {
      l l1 = ((x1)iterator.next()).b().v();
      if (m.a(l1, s.a.o()) != null) {
        dbxyzptlk.l1.a a1 = (dbxyzptlk.l1.a)m.a(l1, dbxyzptlk.l1.k.a.a());
        if (a1 != null) {
          dbxyzptlk.CI.a a2 = (dbxyzptlk.CI.a)a1.a();
          if (a2 != null)
            Boolean bool = (Boolean)a2.invoke(); 
        } 
      } 
    } 
  }
  
  public final void M0(p paramp, i parami) {
    LinkedHashSet<Integer> linkedHashSet = new LinkedHashSet();
    List<p> list2 = paramp.s();
    int j = list2.size();
    boolean bool = false;
    byte b1;
    for (b1 = 0; b1 < j; b1++) {
      p p1 = list2.get(b1);
      if (W().containsKey(Integer.valueOf(p1.n()))) {
        if (!parami.a().contains(Integer.valueOf(p1.n()))) {
          u0(paramp.p());
          return;
        } 
        linkedHashSet.add(Integer.valueOf(p1.n()));
      } 
    } 
    Iterator<Integer> iterator = parami.a().iterator();
    while (iterator.hasNext()) {
      if (!linkedHashSet.contains(Integer.valueOf(((Number)iterator.next()).intValue()))) {
        u0(paramp.p());
        return;
      } 
    } 
    List<p> list1 = paramp.s();
    j = list1.size();
    for (b1 = bool; b1 < j; b1++) {
      p p1 = list1.get(b1);
      if (W().containsKey(Integer.valueOf(p1.n()))) {
        linkedHashSet = (LinkedHashSet<Integer>)this.M.get(Integer.valueOf(p1.n()));
        s.e(linkedHashSet);
        M0(p1, (i)linkedHashSet);
      } 
    } 
  }
  
  public final AccessibilityNodeInfo N(int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: getfield d : Landroidx/compose/ui/platform/AndroidComposeView;
    //   4: invokevirtual getViewTreeOwners : ()Landroidx/compose/ui/platform/AndroidComposeView$c;
    //   7: astore #4
    //   9: aconst_null
    //   10: astore #6
    //   12: aconst_null
    //   13: astore #5
    //   15: aload #4
    //   17: ifnull -> 56
    //   20: aload #4
    //   22: invokevirtual a : ()Landroidx/lifecycle/LifecycleOwner;
    //   25: astore #4
    //   27: aload #4
    //   29: ifnull -> 56
    //   32: aload #4
    //   34: invokeinterface getLifecycle : ()Landroidx/lifecycle/f;
    //   39: astore #4
    //   41: aload #4
    //   43: ifnull -> 56
    //   46: aload #4
    //   48: invokevirtual b : ()Landroidx/lifecycle/f$b;
    //   51: astore #4
    //   53: goto -> 59
    //   56: aconst_null
    //   57: astore #4
    //   59: aload #4
    //   61: getstatic androidx/lifecycle/f$b.DESTROYED : Landroidx/lifecycle/f$b;
    //   64: if_acmpne -> 69
    //   67: aconst_null
    //   68: areturn
    //   69: invokestatic V : ()Ldbxyzptlk/i2/t;
    //   72: astore #9
    //   74: aload_0
    //   75: invokevirtual W : ()Ljava/util/Map;
    //   78: iload_1
    //   79: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   82: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   87: checkcast dbxyzptlk/g1/x1
    //   90: astore #8
    //   92: aload #8
    //   94: ifnonnull -> 99
    //   97: aconst_null
    //   98: areturn
    //   99: aload #8
    //   101: invokevirtual b : ()Ldbxyzptlk/l1/p;
    //   104: astore #7
    //   106: iconst_m1
    //   107: istore_2
    //   108: iload_1
    //   109: iconst_m1
    //   110: if_icmpne -> 151
    //   113: aload_0
    //   114: getfield d : Landroidx/compose/ui/platform/AndroidComposeView;
    //   117: invokestatic G : (Landroid/view/View;)Landroid/view/ViewParent;
    //   120: astore #6
    //   122: aload #5
    //   124: astore #4
    //   126: aload #6
    //   128: instanceof android/view/View
    //   131: ifeq -> 141
    //   134: aload #6
    //   136: checkcast android/view/View
    //   139: astore #4
    //   141: aload #9
    //   143: aload #4
    //   145: invokevirtual E0 : (Landroid/view/View;)V
    //   148: goto -> 220
    //   151: aload #7
    //   153: invokevirtual q : ()Ldbxyzptlk/l1/p;
    //   156: astore #5
    //   158: aload #6
    //   160: astore #4
    //   162: aload #5
    //   164: ifnull -> 177
    //   167: aload #5
    //   169: invokevirtual n : ()I
    //   172: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   175: astore #4
    //   177: aload #4
    //   179: ifnull -> 256
    //   182: aload #4
    //   184: invokevirtual intValue : ()I
    //   187: istore_3
    //   188: iload_3
    //   189: aload_0
    //   190: getfield d : Landroidx/compose/ui/platform/AndroidComposeView;
    //   193: invokevirtual getSemanticsOwner : ()Ldbxyzptlk/l1/r;
    //   196: invokevirtual a : ()Ldbxyzptlk/l1/p;
    //   199: invokevirtual n : ()I
    //   202: if_icmpne -> 208
    //   205: goto -> 210
    //   208: iload_3
    //   209: istore_2
    //   210: aload #9
    //   212: aload_0
    //   213: getfield d : Landroidx/compose/ui/platform/AndroidComposeView;
    //   216: iload_2
    //   217: invokevirtual F0 : (Landroid/view/View;I)V
    //   220: aload #9
    //   222: aload_0
    //   223: getfield d : Landroidx/compose/ui/platform/AndroidComposeView;
    //   226: iload_1
    //   227: invokevirtual O0 : (Landroid/view/View;I)V
    //   230: aload #9
    //   232: aload_0
    //   233: aload #8
    //   235: invokevirtual F : (Ldbxyzptlk/g1/x1;)Landroid/graphics/Rect;
    //   238: invokevirtual e0 : (Landroid/graphics/Rect;)V
    //   241: aload_0
    //   242: iload_1
    //   243: aload #9
    //   245: aload #7
    //   247: invokevirtual F0 : (ILdbxyzptlk/i2/t;Ldbxyzptlk/l1/p;)V
    //   250: aload #9
    //   252: invokevirtual Y0 : ()Landroid/view/accessibility/AccessibilityNodeInfo;
    //   255: areturn
    //   256: new java/lang/StringBuilder
    //   259: dup
    //   260: invokespecial <init> : ()V
    //   263: astore #4
    //   265: aload #4
    //   267: ldc_w 'semanticsNode '
    //   270: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   273: pop
    //   274: aload #4
    //   276: iload_1
    //   277: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   280: pop
    //   281: aload #4
    //   283: ldc_w ' has null parent'
    //   286: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   289: pop
    //   290: new java/lang/IllegalStateException
    //   293: dup
    //   294: aload #4
    //   296: invokevirtual toString : ()Ljava/lang/String;
    //   299: invokevirtual toString : ()Ljava/lang/String;
    //   302: invokespecial <init> : (Ljava/lang/String;)V
    //   305: athrow
  }
  
  public final void N0(p paramp, i parami) {
    List<p> list2 = paramp.s();
    int j = list2.size();
    boolean bool = false;
    byte b1;
    for (b1 = 0; b1 < j; b1++) {
      p p1 = list2.get(b1);
      if (W().containsKey(Integer.valueOf(p1.n())) && !parami.a().contains(Integer.valueOf(p1.n())))
        o1(p1); 
    } 
    for (Map.Entry<Integer, i> entry : this.M.entrySet()) {
      if (!W().containsKey(entry.getKey()))
        I(((Number)entry.getKey()).intValue()); 
    } 
    List<p> list1 = paramp.s();
    j = list1.size();
    for (b1 = bool; b1 < j; b1++) {
      p p1 = list1.get(b1);
      if (W().containsKey(Integer.valueOf(p1.n())) && this.M.containsKey(Integer.valueOf(p1.n()))) {
        paramp = (p)this.M.get(Integer.valueOf(p1.n()));
        s.e(paramp);
        N0(p1, (i)paramp);
      } 
    } 
  }
  
  public final AccessibilityEvent O(int paramInt, Integer paramInteger1, Integer paramInteger2, Integer paramInteger3, CharSequence paramCharSequence) {
    AccessibilityEvent accessibilityEvent = createEvent(paramInt, 8192);
    if (paramInteger1 != null)
      accessibilityEvent.setFromIndex(paramInteger1.intValue()); 
    if (paramInteger2 != null)
      accessibilityEvent.setToIndex(paramInteger2.intValue()); 
    if (paramInteger3 != null)
      accessibilityEvent.setItemCount(paramInteger3.intValue()); 
    if (paramCharSequence != null)
      accessibilityEvent.getText().add(paramCharSequence); 
    return accessibilityEvent;
  }
  
  public final void O0(int paramInt, String paramString) {
    c c1 = this.B;
    if (c1 == null)
      return; 
    if (Build.VERSION.SDK_INT < 29)
      return; 
    AutofillId autofillId = c1.a(paramInt);
    if (autofillId != null) {
      c1.c(autofillId, paramString);
      return;
    } 
    throw new IllegalStateException("Invalid content capture ID");
  }
  
  public final boolean P(MotionEvent paramMotionEvent) {
    if (!s0())
      return false; 
    int j = paramMotionEvent.getAction();
    boolean bool1 = true;
    boolean bool2 = true;
    if (j != 7 && j != 9) {
      if (j != 10)
        return false; 
      if (this.e != Integer.MIN_VALUE) {
        updateHoveredVirtualView(-2147483648);
        bool1 = bool2;
      } else {
        bool1 = this.d.getAndroidViewsHandler$ui_release().dispatchGenericMotionEvent(paramMotionEvent);
      } 
      return bool1;
    } 
    j = k0(paramMotionEvent.getX(), paramMotionEvent.getY());
    bool2 = this.d.getAndroidViewsHandler$ui_release().dispatchGenericMotionEvent(paramMotionEvent);
    updateHoveredVirtualView(j);
    if (j == Integer.MIN_VALUE)
      bool1 = bool2; 
    return bool1;
  }
  
  public final boolean P0(AccessibilityEvent paramAccessibilityEvent) {
    if (!p0())
      return false; 
    if (paramAccessibilityEvent.getEventType() == 2048 || paramAccessibilityEvent.getEventType() == 32768)
      this.q = true; 
    try {
      return ((Boolean)this.f.invoke(paramAccessibilityEvent)).booleanValue();
    } finally {
      this.q = false;
    } 
  }
  
  public final boolean Q0(int paramInt1, int paramInt2, Integer paramInteger, List<String> paramList) {
    if (paramInt1 == Integer.MIN_VALUE || !o0())
      return false; 
    AccessibilityEvent accessibilityEvent = createEvent(paramInt1, paramInt2);
    if (paramInteger != null)
      accessibilityEvent.setContentChangeTypes(paramInteger.intValue()); 
    if (paramList != null)
      accessibilityEvent.setContentDescription(dbxyzptlk.B1.a.e(paramList, ",", null, null, 0, null, null, 62, null)); 
    return P0(accessibilityEvent);
  }
  
  public final void R(p paramp, ArrayList<p> paramArrayList, Map<Integer, List<p>> paramMap) {
    boolean bool;
    t t1 = paramp.o().getLayoutDirection();
    t t2 = t.Rtl;
    byte b1 = 0;
    if (t1 == t2) {
      bool = true;
    } else {
      bool = false;
    } 
    boolean bool1 = ((Boolean)paramp.m().p(s.a.p(), (dbxyzptlk.CI.a)D.f)).booleanValue();
    if ((bool1 || r0(paramp)) && W().keySet().contains(Integer.valueOf(paramp.n())))
      paramArrayList.add(paramp); 
    if (bool1) {
      paramMap.put(Integer.valueOf(paramp.n()), i1(bool, A.o1(paramp.k())));
    } else {
      List<p> list = paramp.k();
      int j = list.size();
      while (b1 < j) {
        R(list.get(b1), paramArrayList, paramMap);
        b1++;
      } 
    } 
  }
  
  public final int S(p paramp) {
    l l1 = paramp.v();
    s s = s.a;
    return (!l1.j(s.c()) && paramp.v().j(s.A())) ? J.i(((J)paramp.v().m(s.A())).r()) : this.v;
  }
  
  public final void S0(int paramInt1, int paramInt2, String paramString) {
    AccessibilityEvent accessibilityEvent = createEvent(L0(paramInt1), 32);
    accessibilityEvent.setContentChangeTypes(paramInt2);
    if (paramString != null)
      accessibilityEvent.getText().add(paramString); 
    P0(accessibilityEvent);
  }
  
  public final int T(p paramp) {
    l l1 = paramp.v();
    s s = s.a;
    return (!l1.j(s.c()) && paramp.v().j(s.A())) ? J.n(((J)paramp.v().m(s.A())).r()) : this.v;
  }
  
  public final void T0(int paramInt) {
    g g1 = this.E;
    if (g1 != null) {
      if (paramInt != g1.d().n())
        return; 
      if (SystemClock.uptimeMillis() - g1.f() <= 1000L) {
        AccessibilityEvent accessibilityEvent = createEvent(L0(g1.d().n()), 131072);
        accessibilityEvent.setFromIndex(g1.b());
        accessibilityEvent.setToIndex(g1.e());
        accessibilityEvent.setAction(g1.a());
        accessibilityEvent.setMovementGranularity(g1.c());
        accessibilityEvent.getText().add(e0(g1.d()));
        P0(accessibilityEvent);
      } 
    } 
    this.E = null;
  }
  
  public final boolean U() {
    return this.A;
  }
  
  public final void U0(Map<Integer, x1> paramMap) {
    ArrayList<w1> arrayList = new ArrayList<>(this.Q);
    this.Q.clear();
    Iterator<Number> iterator = paramMap.keySet().iterator();
    while (iterator.hasNext()) {
      p p;
      int j = ((Number)iterator.next()).intValue();
      i i1 = this.M.get(Integer.valueOf(j));
      x1 x1 = paramMap.get(Integer.valueOf(j));
      if (x1 != null) {
        p = x1.b();
      } else {
        p = null;
      } 
      if (p != null) {
        Object object1;
        if (i1 == null) {
          Iterator<Map.Entry> iterator2 = p.v().iterator();
          while (iterator2.hasNext()) {
            x1 = (x1)((Map.Entry)iterator2.next()).getKey();
            s s = s.a;
            if (s.c(x1, s.z())) {
              List list = (List)m.a(p.v(), s.z());
              if (list != null) {
                dbxyzptlk.n1.d d1 = (dbxyzptlk.n1.d)A.r0(list);
              } else {
                list = null;
              } 
              O0(p.n(), String.valueOf(list));
            } 
          } 
          continue;
        } 
        Iterator iterator1 = p.v().iterator();
        boolean bool = false;
        while (true)
          object1 = SYNTHETIC_LOCAL_VARIABLE_10; 
        Object object2 = object1;
        if (object1 == null)
          boolean bool1 = C.m(p, i1.c()); 
        continue;
      } 
      throw new IllegalStateException("no value for specified key");
      if (SYNTHETIC_LOCAL_VARIABLE_10 != null)
        R0(this, L0(SYNTHETIC_LOCAL_VARIABLE_6), 2048, Integer.valueOf(0), null, 8, null); 
    } 
  }
  
  public final c V(View paramView) {
    dbxyzptlk.j1.d.c(paramView, 1);
    return dbxyzptlk.j1.d.b(paramView);
  }
  
  public final void V0(f paramf, b<Integer> paramb) {
    if (!paramf.I0())
      return; 
    if (this.d.getAndroidViewsHandler$ui_release().getLayoutNodeToHolder().containsKey(paramf))
      return; 
    int m = this.x.size();
    int j;
    for (j = 0; j < m; j++) {
      if (C.j((f)this.x.z(j), paramf))
        return; 
    } 
    if (!paramf.i0().r(K.a(8)))
      paramf = C.e(paramf, (l)s.f); 
    if (paramf != null) {
      l l1 = paramf.G();
      if (l1 != null) {
        f f1 = paramf;
        if (!l1.x()) {
          f f2 = C.e(paramf, (l)r.f);
          f1 = paramf;
          if (f2 != null)
            f1 = f2; 
        } 
        j = f1.o0();
        if (!paramb.add(Integer.valueOf(j)))
          return; 
        R0(this, L0(j), 2048, Integer.valueOf(1), null, 8, null);
      } 
    } 
  }
  
  public final Map<Integer, x1> W() {
    if (this.z) {
      this.z = false;
      this.F = C.f(this.d.getSemanticsOwner());
      if (p0())
        d1(); 
    } 
    return this.F;
  }
  
  public final void W0(f paramf) {
    if (!paramf.I0())
      return; 
    if (this.d.getAndroidViewsHandler$ui_release().getLayoutNodeToHolder().containsKey(paramf))
      return; 
    int j = paramf.o0();
    j j1 = this.r.get(Integer.valueOf(j));
    j j2 = this.s.get(Integer.valueOf(j));
    if (j1 == null && j2 == null)
      return; 
    AccessibilityEvent accessibilityEvent = createEvent(j, 4096);
    if (j1 != null) {
      accessibilityEvent.setScrollX((int)((Number)j1.c().invoke()).floatValue());
      accessibilityEvent.setMaxScrollX((int)((Number)j1.a().invoke()).floatValue());
    } 
    if (j2 != null) {
      accessibilityEvent.setScrollY((int)((Number)j2.c().invoke()).floatValue());
      accessibilityEvent.setMaxScrollY((int)((Number)j2.a().invoke()).floatValue());
    } 
    P0(accessibilityEvent);
  }
  
  public final String X() {
    return this.K;
  }
  
  public final boolean X0(p paramp, int paramInt1, int paramInt2, boolean paramBoolean) {
    dbxyzptlk.CI.q q;
    l l1 = paramp.v();
    dbxyzptlk.l1.k k1 = dbxyzptlk.l1.k.a;
    boolean bool2 = l1.j(k1.v());
    boolean bool = false;
    boolean bool1 = false;
    if (bool2 && C.b(paramp)) {
      q = (dbxyzptlk.CI.q)((dbxyzptlk.l1.a)paramp.v().m(k1.v())).a();
      if (q != null)
        bool1 = ((Boolean)q.h(Integer.valueOf(paramInt1), Integer.valueOf(paramInt2), Boolean.valueOf(paramBoolean))).booleanValue(); 
      return bool1;
    } 
    if (paramInt1 == paramInt2 && paramInt2 == this.v)
      return false; 
    String str = e0((p)q);
    if (str == null)
      return false; 
    if (paramInt1 < 0 || paramInt1 != paramInt2 || paramInt2 > str.length())
      paramInt1 = -1; 
    this.v = paramInt1;
    paramInt1 = bool;
    if (str.length() > 0)
      paramInt1 = 1; 
    paramInt2 = L0(q.n());
    Integer integer = null;
    if (paramInt1 != 0) {
      Integer integer1 = Integer.valueOf(this.v);
    } else {
      l1 = null;
    } 
    if (paramInt1 != 0) {
      Integer integer1 = Integer.valueOf(this.v);
    } else {
      k1 = null;
    } 
    if (paramInt1 != 0)
      integer = Integer.valueOf(str.length()); 
    P0(O(paramInt2, (Integer)l1, (Integer)k1, integer, str));
    T0(q.n());
    return true;
  }
  
  public final String Y() {
    return this.J;
  }
  
  public final void Y0(c paramc) {
    this.B = paramc;
  }
  
  public final HashMap<Integer, Integer> Z() {
    return this.I;
  }
  
  public final void Z0(p paramp, t paramt) {
    l l1 = paramp.v();
    s s = s.a;
    if (l1.j(s.f())) {
      paramt.n0(true);
      paramt.r0((CharSequence)m.a(paramp.v(), s.f()));
    } 
  }
  
  public final HashMap<Integer, Integer> a0() {
    return this.H;
  }
  
  public final void a1(p paramp, t paramt) {
    paramt.g0(b0(paramp));
  }
  
  public final boolean b0(p paramp) {
    boolean bool1;
    l l1 = paramp.v();
    s s = s.a;
    dbxyzptlk.m1.a a1 = (dbxyzptlk.m1.a)m.a(l1, s.C());
    dbxyzptlk.l1.i i1 = (dbxyzptlk.l1.i)m.a(paramp.v(), s.u());
    boolean bool = true;
    boolean bool3 = false;
    if (a1 != null) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    boolean bool2 = bool1;
    if ((Boolean)m.a(paramp.v(), s.w()) != null) {
      int j = dbxyzptlk.l1.i.b.g();
      if (i1 == null) {
        bool2 = bool3;
      } else {
        bool2 = dbxyzptlk.l1.i.k(i1.n(), j);
      } 
      if (!bool2)
        bool1 = bool; 
      bool2 = bool1;
    } 
    return bool2;
  }
  
  public final void b1(p paramp, t paramt) {
    paramt.P0(c0(paramp));
  }
  
  public final String c0(p paramp) {
    l l1 = paramp.v();
    s s = s.a;
    Object object3 = m.a(l1, s.x());
    dbxyzptlk.m1.a a1 = (dbxyzptlk.m1.a)m.a(paramp.v(), s.C());
    dbxyzptlk.l1.i i1 = (dbxyzptlk.l1.i)m.a(paramp.v(), s.u());
    byte b2 = 0;
    byte b1 = 0;
    Object object2 = object3;
    if (a1 != null) {
      int j = m.a[a1.ordinal()];
      if (j != 1) {
        if (j != 2) {
          if (j != 3) {
            object2 = object3;
          } else {
            object2 = object3;
            if (object3 == null)
              object2 = this.d.getContext().getResources().getString(dbxyzptlk.K0.i.indeterminate); 
          } 
        } else {
          boolean bool1;
          j = dbxyzptlk.l1.i.b.f();
          if (i1 == null) {
            bool1 = false;
          } else {
            bool1 = dbxyzptlk.l1.i.k(i1.n(), j);
          } 
          object2 = object3;
          if (bool1) {
            object2 = object3;
            if (object3 == null)
              object2 = this.d.getContext().getResources().getString(dbxyzptlk.K0.i.off); 
          } 
        } 
      } else {
        boolean bool1;
        j = dbxyzptlk.l1.i.b.f();
        if (i1 == null) {
          bool1 = false;
        } else {
          bool1 = dbxyzptlk.l1.i.k(i1.n(), j);
        } 
        object2 = object3;
        if (bool1) {
          object2 = object3;
          if (object3 == null)
            object2 = this.d.getContext().getResources().getString(dbxyzptlk.K0.i.on); 
        } 
      } 
    } 
    Boolean bool = (Boolean)m.a(paramp.v(), s.w());
    object3 = object2;
    if (bool != null) {
      boolean bool1;
      boolean bool2 = bool.booleanValue();
      int j = dbxyzptlk.l1.i.b.g();
      if (i1 == null) {
        bool1 = false;
      } else {
        bool1 = dbxyzptlk.l1.i.k(i1.n(), j);
      } 
      object3 = object2;
      if (!bool1) {
        object3 = object2;
        if (object2 == null)
          if (bool2) {
            object3 = this.d.getContext().getResources().getString(dbxyzptlk.K0.i.selected);
          } else {
            object3 = this.d.getContext().getResources().getString(dbxyzptlk.K0.i.not_selected);
          }  
      } 
    } 
    object2 = m.a(paramp.v(), s.t());
    Object object1 = object3;
    if (object2 != null)
      if (object2 != h.d.a()) {
        object1 = object3;
        if (object3 == null) {
          int j;
          object1 = object2.c();
          if (((Number)object1.k()).floatValue() - ((Number)object1.e()).floatValue() == 0.0F) {
            j = 1;
          } else {
            j = 0;
          } 
          if (j) {
            f = 0.0F;
          } else {
            f = (object2.b() - ((Number)object1.e()).floatValue()) / (((Number)object1.k()).floatValue() - ((Number)object1.e()).floatValue());
          } 
          float f = dbxyzptlk.KI.n.l(f, 0.0F, 1.0F);
          if (f == 0.0F) {
            j = 1;
          } else {
            j = 0;
          } 
          if (j) {
            j = b2;
          } else {
            j = b1;
            if (f == 1.0F)
              j = 1; 
            if (j) {
              j = 100;
            } else {
              j = dbxyzptlk.KI.n.m(c.d(f * 100), 1, 99);
            } 
          } 
          object1 = this.d.getContext().getResources().getString(dbxyzptlk.K0.i.template_percent, new Object[] { Integer.valueOf(j) });
        } 
      } else {
        object1 = object3;
        if (object3 == null)
          object1 = this.d.getContext().getResources().getString(dbxyzptlk.K0.i.in_progress); 
      }  
    return (String)object1;
  }
  
  public final void c1(p paramp, t paramt) {
    paramt.Q0((CharSequence)d0(paramp));
  }
  
  public final boolean clearAccessibilityFocus(int paramInt) {
    if (m0(paramInt)) {
      this.o = Integer.MIN_VALUE;
      this.p = null;
      this.d.invalidate();
      R0(this, paramInt, 65536, null, null, 12, null);
      return true;
    } 
    return false;
  }
  
  public final AccessibilityEvent createEvent(int paramInt1, int paramInt2) {
    AccessibilityEvent accessibilityEvent = AccessibilityEvent.obtain(paramInt2);
    accessibilityEvent.setEnabled(true);
    accessibilityEvent.setClassName("android.view.View");
    accessibilityEvent.setPackageName(this.d.getContext().getPackageName());
    accessibilityEvent.setSource((View)this.d, paramInt1);
    if (p0()) {
      x1 x1 = W().get(Integer.valueOf(paramInt1));
      if (x1 != null)
        accessibilityEvent.setPassword(x1.b().m().j(s.a.s())); 
    } 
    return accessibilityEvent;
  }
  
  public final SpannableString d0(p paramp) {
    l.b b1 = this.d.getFontFamilyResolver();
    dbxyzptlk.n1.d d1 = g0(paramp.v());
    p p1 = null;
    if (d1 != null) {
      SpannableString spannableString = dbxyzptlk.v1.a.b(d1, this.d.getDensity(), b1, this.L);
    } else {
      d1 = null;
    } 
    SpannableString spannableString2 = (SpannableString)n1(d1, 100000);
    List list = (List)m.a(paramp.v(), s.a.z());
    paramp = p1;
    if (list != null) {
      dbxyzptlk.n1.d d2 = (dbxyzptlk.n1.d)A.r0(list);
      paramp = p1;
      if (d2 != null)
        spannableString1 = dbxyzptlk.v1.a.b(d2, this.d.getDensity(), b1, this.L); 
    } 
    SpannableString spannableString3 = n1(spannableString1, 100000);
    SpannableString spannableString1 = spannableString2;
    if (spannableString2 == null)
      spannableString1 = spannableString3; 
    return spannableString1;
  }
  
  public final void d1() {
    boolean bool;
    this.H.clear();
    this.I.clear();
    x1 x1 = W().get(Integer.valueOf(-1));
    if (x1 != null) {
      p p = x1.b();
    } else {
      x1 = null;
    } 
    s.e(x1);
    t t1 = x1.o().getLayoutDirection();
    t t2 = t.Rtl;
    byte b1 = 1;
    if (t1 == t2) {
      bool = true;
    } else {
      bool = false;
    } 
    List<p> list = i1(bool, s.s((Object[])new p[] { (p)x1 }));
    int j = s.o(list);
    if (1 <= j)
      while (true) {
        int m = ((p)list.get(b1 - 1)).n();
        int n = ((p)list.get(b1)).n();
        this.H.put(Integer.valueOf(m), Integer.valueOf(n));
        this.I.put(Integer.valueOf(n), Integer.valueOf(m));
        if (b1 != j) {
          b1++;
          continue;
        } 
        break;
      }  
  }
  
  public final String e0(p paramp) {
    String str2;
    String str1;
    dbxyzptlk.n1.d d2 = null;
    p p1 = null;
    if (paramp == null)
      return null; 
    l l1 = paramp.v();
    s s = s.a;
    if (l1.j(s.c()))
      return dbxyzptlk.B1.a.e((List)paramp.v().m(s.c()), ",", null, null, 0, null, null, 62, null); 
    if (paramp.v().j(dbxyzptlk.l1.k.a.w())) {
      d2 = g0(paramp.v());
      paramp = p1;
      if (d2 != null)
        str2 = d2.i(); 
      return str2;
    } 
    List list = (List)m.a(str2.v(), s.z());
    dbxyzptlk.n1.d d1 = d2;
    if (list != null) {
      dbxyzptlk.n1.d d3 = (dbxyzptlk.n1.d)A.r0(list);
      d1 = d2;
      if (d3 != null)
        str1 = d3.i(); 
    } 
    return str1;
  }
  
  public final void e1() {
    Iterator<x1> iterator = W().values().iterator();
    while (iterator.hasNext()) {
      l l1 = ((x1)iterator.next()).b().v();
      if (s.c(m.a(l1, s.a.o()), Boolean.FALSE)) {
        dbxyzptlk.l1.a a1 = (dbxyzptlk.l1.a)m.a(l1, dbxyzptlk.l1.k.a.y());
        if (a1 != null) {
          l l2 = (l)a1.a();
          if (l2 != null)
            Boolean bool = (Boolean)l2.invoke(Boolean.TRUE); 
        } 
      } 
    } 
  }
  
  public final dbxyzptlk.g1.a f0(p paramp, int paramInt) {
    b b1;
    if (paramp == null)
      return null; 
    String str = e0(paramp);
    if (str == null || str.length() == 0)
      return null; 
    if (paramInt != 1) {
      if (paramInt != 2) {
        e e;
        c c1;
        if (paramInt != 4)
          if (paramInt != 8) {
            if (paramInt != 16)
              return null; 
          } else {
            e = e.c.a();
            e.e(str);
            return (dbxyzptlk.g1.a)e;
          }  
        if (!e.v().j(dbxyzptlk.l1.k.a.h()))
          return null; 
        F f = h0(e.v());
        if (f == null)
          return null; 
        if (paramInt == 4) {
          c1 = c.d.a();
          c1.j(str, f);
        } else {
          d d2 = d.f.a();
          d2.j(str, f, (p)c1);
          d d1 = d2;
        } 
      } else {
        f f = f.d.a((this.d.getContext().getResources().getConfiguration()).locale);
        f.e(str);
      } 
    } else {
      b1 = b.d.a((this.d.getContext().getResources().getConfiguration()).locale);
      b1.e(str);
    } 
    return (dbxyzptlk.g1.a)b1;
  }
  
  public final List<p> f1(boolean paramBoolean, ArrayList<p> paramArrayList, Map<Integer, List<p>> paramMap) {
    ArrayList<dbxyzptlk.pI.n<h, List<p>>> arrayList = new ArrayList();
    int m = s.o(paramArrayList);
    byte b1 = 0;
    if (m >= 0) {
      int n = 0;
      while (true) {
        p p = paramArrayList.get(n);
        if (!n || !h1(arrayList, p))
          arrayList.add(new dbxyzptlk.pI.n(p.j(), s.s((Object[])new p[] { p }))); 
        if (n != m) {
          n++;
          continue;
        } 
        break;
      } 
    } 
    w.B(arrayList, (Comparator)j.a);
    ArrayList<p> arrayList1 = new ArrayList();
    m = arrayList.size();
    int j;
    for (j = 0; j < m; j++) {
      f f;
      dbxyzptlk.pI.n n = arrayList.get(j);
      List list = (List)n.d();
      if (paramBoolean) {
        h h = h.a;
      } else {
        f = f.a;
      } 
      w.B(list, (Comparator)new B((Comparator)new A((Comparator)f, f.J.b())));
      arrayList1.addAll((Collection)n.d());
    } 
    w.B(arrayList1, (Comparator)new dbxyzptlk.g1.q((p)t.f));
    for (j = b1; j <= s.o(arrayList1); j++) {
      List<? extends p> list = paramMap.get(Integer.valueOf(((p)arrayList1.get(j)).n()));
      if (list != null) {
        if (!r0(arrayList1.get(j))) {
          arrayList1.remove(j);
        } else {
          j++;
        } 
        arrayList1.addAll(j, list);
        j += list.size();
        continue;
      } 
    } 
    return arrayList1;
  }
  
  public final dbxyzptlk.n1.d g0(l paraml) {
    return (dbxyzptlk.n1.d)m.a(paraml, s.a.e());
  }
  
  public u getAccessibilityNodeProvider(View paramView) {
    return this.n;
  }
  
  public final F h0(l paraml) {
    F f;
    ArrayList<F> arrayList = new ArrayList();
    dbxyzptlk.l1.a a1 = (dbxyzptlk.l1.a)m.a(paraml, dbxyzptlk.l1.k.a.h());
    l l1 = null;
    paraml = l1;
    if (a1 != null) {
      l l2 = (l)a1.a();
      paraml = l1;
      if (l2 != null) {
        paraml = l1;
        if (((Boolean)l2.invoke(arrayList)).booleanValue())
          f = arrayList.get(0); 
      } 
    } 
    return f;
  }
  
  public final AndroidComposeView i0() {
    return this.d;
  }
  
  public final List<p> i1(boolean paramBoolean, List<p> paramList) {
    LinkedHashMap<Object, Object> linkedHashMap = new LinkedHashMap<>();
    ArrayList<p> arrayList = new ArrayList();
    int j = paramList.size();
    for (byte b1 = 0; b1 < j; b1++)
      R(paramList.get(b1), arrayList, (Map)linkedHashMap); 
    return f1(paramBoolean, arrayList, (Map)linkedHashMap);
  }
  
  public final void j0() {
    Iterator<x1> iterator = W().values().iterator();
    while (iterator.hasNext()) {
      l l1 = ((x1)iterator.next()).b().v();
      if (s.c(m.a(l1, s.a.o()), Boolean.TRUE)) {
        dbxyzptlk.l1.a a1 = (dbxyzptlk.l1.a)m.a(l1, dbxyzptlk.l1.k.a.y());
        if (a1 != null) {
          l l2 = (l)a1.a();
          if (l2 != null)
            Boolean bool = (Boolean)l2.invoke(Boolean.FALSE); 
        } 
      } 
    } 
  }
  
  public final RectF j1(p paramp, h paramh) {
    RectF rectF;
    h h2 = null;
    if (paramp == null)
      return null; 
    paramh = paramh.x(paramp.r());
    h h1 = paramp.i();
    if (paramh.v(h1)) {
      h1 = paramh.t(h1);
    } else {
      h1 = null;
    } 
    paramh = h2;
    if (h1 != null) {
      long l1 = this.d.A(g.a(h1.m(), h1.p()));
      long l2 = this.d.A(g.a(h1.n(), h1.i()));
      rectF = new RectF(f.o(l1), f.p(l1), f.o(l2), f.p(l2));
    } 
    return rectF;
  }
  
  public final int k0(float paramFloat1, float paramFloat2) {
    AndroidComposeView androidComposeView = this.d;
    f f = null;
    Owner.b(androidComposeView, false, 1, null);
    dbxyzptlk.f1.q q = new dbxyzptlk.f1.q();
    f.y0(this.d.getRoot(), g.a(paramFloat1, paramFloat2), q, false, false, 12, null);
    androidx.compose.ui.d.c c1 = (androidx.compose.ui.d.c)A.D0((List)q);
    if (c1 != null)
      f = h.k((g)c1); 
    if (f != null) {
      l l1 = f.i0();
      if (l1 != null && l1.r(K.a(8)) == true && C.l(dbxyzptlk.l1.q.a(f, false)) && (AndroidViewHolder)this.d.getAndroidViewsHandler$ui_release().getLayoutNodeToHolder().get(f) == null)
        return L0(f.o0()); 
    } 
    return Integer.MIN_VALUE;
  }
  
  public final dbxyzptlk.j1.e k1(p paramp) {
    AutofillId autofillId1;
    AutofillId autofillId2;
    c c1 = this.B;
    if (c1 == null)
      return null; 
    if (Build.VERSION.SDK_INT < 29)
      return null; 
    dbxyzptlk.j1.a a1 = dbxyzptlk.j1.d.a((View)this.d);
    if (a1 == null)
      return null; 
    p p1 = paramp.q();
    if (p1 != null) {
      autofillId2 = c1.a(p1.n());
      autofillId1 = autofillId2;
      if (autofillId2 == null)
        return null; 
    } else {
      autofillId1 = autofillId2.a();
    } 
    dbxyzptlk.j1.e e = c1.b(autofillId1, paramp.n());
    if (e == null)
      return null; 
    l l1 = paramp.v();
    s s = s.a;
    if (l1.j(s.s()))
      return null; 
    List list2 = (List)m.a(l1, s.z());
    if (list2 != null) {
      e.a("android.widget.TextView");
      e.d(dbxyzptlk.B1.a.e(list2, "\n", null, null, 0, null, null, 62, null));
    } 
    dbxyzptlk.n1.d d1 = (dbxyzptlk.n1.d)m.a(l1, s.e());
    if (d1 != null) {
      e.a("android.widget.EditText");
      e.d((CharSequence)d1);
    } 
    List list1 = (List)m.a(l1, s.c());
    if (list1 != null)
      e.b(dbxyzptlk.B1.a.e(list1, "\n", null, null, 0, null, null, 62, null)); 
    dbxyzptlk.l1.i i1 = (dbxyzptlk.l1.i)m.a(l1, s.u());
    if (i1 != null) {
      String str = C.n(i1.n());
      if (str != null)
        e.a(str); 
    } 
    F f = h0(l1);
    if (f != null) {
      E e1 = f.l();
      e.e(v.h(e1.i().l()) * e1.b().getDensity() * e1.b().v1(), 0, 0, 0);
    } 
    h h = paramp.h();
    e.c((int)h.m(), (int)h.p(), 0, 0, (int)h.r(), (int)h.l());
    return e;
  }
  
  public final void l0(boolean paramBoolean) {
    if (paramBoolean) {
      o1(this.d.getSemanticsOwner().a());
    } else {
      p1(this.d.getSemanticsOwner().a());
    } 
    t0();
  }
  
  public final boolean m0(int paramInt) {
    boolean bool;
    if (this.o == paramInt) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public final boolean m1(p paramp, int paramInt, boolean paramBoolean1, boolean paramBoolean2) {
    int j = paramp.n();
    Integer integer = this.w;
    if (integer == null || j != integer.intValue()) {
      this.v = -1;
      this.w = Integer.valueOf(paramp.n());
    } 
    String str = e0(paramp);
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (str != null)
      if (str.length() == 0) {
        bool1 = bool2;
      } else {
        int i1;
        char c1;
        int[] arrayOfInt;
        dbxyzptlk.g1.a a1 = f0(paramp, paramInt);
        if (a1 == null)
          return false; 
        int m = S(paramp);
        j = m;
        if (m == -1)
          if (paramBoolean1) {
            j = 0;
          } else {
            j = str.length();
          }  
        if (paramBoolean1) {
          arrayOfInt = a1.a(j);
        } else {
          arrayOfInt = arrayOfInt.b(j);
        } 
        if (arrayOfInt == null)
          return false; 
        m = arrayOfInt[0];
        bool1 = true;
        int n = arrayOfInt[1];
        if (paramBoolean2 && n0(paramp)) {
          i1 = T(paramp);
          j = i1;
          if (i1 == -1)
            if (paramBoolean1) {
              j = m;
            } else {
              j = n;
            }  
          if (paramBoolean1) {
            i1 = n;
          } else {
            i1 = m;
          } 
        } else {
          if (paramBoolean1) {
            j = n;
          } else {
            j = m;
          } 
          i1 = j;
        } 
        if (paramBoolean1) {
          c1 = 'Ā';
        } else {
          c1 = 'Ȁ';
        } 
        this.E = new g(paramp, c1, paramInt, m, n, SystemClock.uptimeMillis());
        X0(paramp, j, i1, true);
      }  
    return bool1;
  }
  
  public final boolean n0(p paramp) {
    boolean bool;
    l l1 = paramp.v();
    s s = s.a;
    if (!l1.j(s.c()) && paramp.v().j(s.e())) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public final <T extends CharSequence> T n1(T paramT, int paramInt) {
    if (paramInt > 0) {
      CharSequence charSequence;
      T t1 = paramT;
      if (paramT != null)
        if (paramT.length() == 0) {
          t1 = paramT;
        } else if (paramT.length() <= paramInt) {
          t1 = paramT;
        } else {
          int m = paramInt - 1;
          int j = paramInt;
          if (Character.isHighSurrogate(paramT.charAt(m))) {
            j = paramInt;
            if (Character.isLowSurrogate(paramT.charAt(paramInt)))
              j = m; 
          } 
          charSequence = paramT.subSequence(0, j);
          s.f(charSequence, "null cannot be cast to non-null type T of androidx.compose.ui.platform.AndroidComposeViewAccessibilityDelegateCompat.trimToSize");
        }  
      return (T)charSequence;
    } 
    throw new IllegalArgumentException("size should be greater than 0");
  }
  
  public final void o1(p paramp) {
    if (!q0())
      return; 
    r1(paramp);
    H(paramp.n(), k1(paramp));
    List<p> list = paramp.s();
    int j = list.size();
    for (byte b1 = 0; b1 < j; b1++)
      o1(list.get(b1)); 
  }
  
  public void onStart(LifecycleOwner paramLifecycleOwner) {
    l0(true);
  }
  
  public void onStop(LifecycleOwner paramLifecycleOwner) {
    l0(false);
  }
  
  public final boolean p0() {
    return (this.h || (this.g.isEnabled() && !this.k.isEmpty()));
  }
  
  public final void p1(p paramp) {
    if (!q0())
      return; 
    I(paramp.n());
    List<p> list = paramp.s();
    int j = list.size();
    for (byte b1 = 0; b1 < j; b1++)
      p1(list.get(b1)); 
  }
  
  public final boolean q0() {
    boolean bool;
    if (!C.v() && (this.B != null || this.A)) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public final void q1() {
    b b1 = new b(0, 1, null);
    Iterator<Number> iterator = this.G.iterator();
    while (iterator.hasNext()) {
      int j = ((Number)iterator.next()).intValue();
      x1 x1 = W().get(Integer.valueOf(j));
      if (x1 != null) {
        p p = x1.b();
      } else {
        x1 = null;
      } 
      if (x1 == null || !C.i((p)x1)) {
        b1.add(Integer.valueOf(j));
        i i1 = this.M.get(Integer.valueOf(j));
        if (i1 != null) {
          l l1 = i1.c();
          if (l1 != null) {
            String str = (String)m.a(l1, s.a.r());
            continue;
          } 
        } 
        i1 = null;
        continue;
      } 
      continue;
      S0(SYNTHETIC_LOCAL_VARIABLE_1, 32, (String)SYNTHETIC_LOCAL_VARIABLE_2);
    } 
    this.G.m(b1);
    this.M.clear();
    for (Map.Entry<Integer, x1> entry : W().entrySet()) {
      if (C.i(((x1)entry.getValue()).b()) && this.G.add(entry.getKey()))
        S0(((Number)entry.getKey()).intValue(), 16, (String)((x1)entry.getValue()).b().v().m(s.a.r())); 
      this.M.put((Integer)entry.getKey(), new i(((x1)entry.getValue()).b(), W()));
    } 
    this.N = new i(this.d.getSemanticsOwner().a(), W());
  }
  
  public final boolean r0(p paramp) {
    boolean bool1;
    String str = C.g(paramp);
    boolean bool3 = true;
    if (str != null || d0(paramp) != null || c0(paramp) != null || b0(paramp)) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    boolean bool2 = bool3;
    if (!paramp.v().x())
      if (paramp.z() && bool1) {
        bool2 = bool3;
      } else {
        bool2 = false;
      }  
    return bool2;
  }
  
  public final void r1(p paramp) {
    l l1 = paramp.v();
    Boolean bool = (Boolean)m.a(l1, s.a.o());
    if (this.l == k.SHOW_ORIGINAL && s.c(bool, Boolean.TRUE)) {
      dbxyzptlk.l1.a a1 = (dbxyzptlk.l1.a)m.a(l1, dbxyzptlk.l1.k.a.y());
      if (a1 != null) {
        l l2 = (l)a1.a();
        if (l2 != null)
          bool = (Boolean)l2.invoke(Boolean.FALSE); 
      } 
    } else if (this.l == k.SHOW_TRANSLATED && s.c(bool, Boolean.FALSE)) {
      dbxyzptlk.l1.a a1 = (dbxyzptlk.l1.a)m.a(l1, dbxyzptlk.l1.k.a.y());
      if (a1 != null) {
        l l2 = (l)a1.a();
        if (l2 != null)
          Boolean bool1 = (Boolean)l2.invoke(Boolean.TRUE); 
      } 
    } 
  }
  
  public final boolean requestAccessibilityFocus(int paramInt) {
    if (!s0())
      return false; 
    if (!m0(paramInt)) {
      int j = this.o;
      if (j != Integer.MIN_VALUE)
        R0(this, j, 65536, null, null, 12, null); 
      this.o = paramInt;
      this.d.invalidate();
      R0(this, paramInt, 32768, null, null, 12, null);
      return true;
    } 
    return false;
  }
  
  public final boolean s0() {
    return (this.h || (this.g.isEnabled() && this.g.isTouchExplorationEnabled()));
  }
  
  public final void t0() {
    c c1 = this.B;
    if (c1 == null)
      return; 
    if (Build.VERSION.SDK_INT < 29)
      return; 
    boolean bool = this.C.isEmpty();
    byte b1 = 0;
    if (!bool) {
      List<dbxyzptlk.j1.e> list = A.l1(this.C.values());
      ArrayList<ViewStructure> arrayList = new ArrayList(list.size());
      int j = list.size();
      for (byte b2 = 0; b2 < j; b2++)
        arrayList.add(((dbxyzptlk.j1.e)list.get(b2)).f()); 
      c1.d(arrayList);
      this.C.clear();
    } 
    if (!this.D.isEmpty()) {
      List<Number> list = A.l1((Iterable)this.D);
      ArrayList<Long> arrayList = new ArrayList(list.size());
      int j = list.size();
      for (byte b2 = b1; b2 < j; b2++)
        arrayList.add(Long.valueOf(((Number)list.get(b2)).intValue())); 
      c1.e(A.m1(arrayList));
      this.D.clear();
    } 
  }
  
  public final void u0(f paramf) {
    if (this.x.add(paramf))
      this.y.k(D.a); 
  }
  
  public final void updateHoveredVirtualView(int paramInt) {
    int j = this.e;
    if (j == paramInt)
      return; 
    this.e = paramInt;
    R0(this, paramInt, 128, null, null, 12, null);
    R0(this, j, 256, null, null, 12, null);
  }
  
  public final void v0() {
    this.l = k.SHOW_ORIGINAL;
    M();
  }
  
  public final void w0(long[] paramArrayOflong, int[] paramArrayOfint, Consumer<ViewTranslationRequest> paramConsumer) {
    l.a.c(this, paramArrayOflong, paramArrayOfint, paramConsumer);
  }
  
  public final void x0() {
    this.l = k.SHOW_ORIGINAL;
    j0();
  }
  
  public final void y0(f paramf) {
    this.z = true;
    if (!o0())
      return; 
    u0(paramf);
  }
  
  public final void z0() {
    this.z = true;
    if (o0() && !this.O) {
      this.O = true;
      this.m.post(this.P);
    } 
  }
  
  @Metadata(d1 = {"\000\027\n\000\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\004*\001\000\b\n\030\0002\0020\001J\027\020\005\032\0020\0042\006\020\003\032\0020\002H\026¢\006\004\b\005\020\006J\027\020\007\032\0020\0042\006\020\003\032\0020\002H\026¢\006\004\b\007\020\006¨\006\b"}, d2 = {"androidx/compose/ui/platform/AndroidComposeViewAccessibilityDelegateCompat$a", "Landroid/view/View$OnAttachStateChangeListener;", "Landroid/view/View;", "view", "Ldbxyzptlk/pI/D;", "onViewAttachedToWindow", "(Landroid/view/View;)V", "onViewDetachedFromWindow", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class a implements View.OnAttachStateChangeListener {
    public final AndroidComposeViewAccessibilityDelegateCompat a;
    
    public a(AndroidComposeViewAccessibilityDelegateCompat param1AndroidComposeViewAccessibilityDelegateCompat) {}
    
    public void onViewAttachedToWindow(View param1View) {
      AccessibilityManager accessibilityManager = AndroidComposeViewAccessibilityDelegateCompat.i(this.a);
      AndroidComposeViewAccessibilityDelegateCompat androidComposeViewAccessibilityDelegateCompat = this.a;
      accessibilityManager.addAccessibilityStateChangeListener(AndroidComposeViewAccessibilityDelegateCompat.o(androidComposeViewAccessibilityDelegateCompat));
      accessibilityManager.addTouchExplorationStateChangeListener(AndroidComposeViewAccessibilityDelegateCompat.w(androidComposeViewAccessibilityDelegateCompat));
      if (!this.a.U()) {
        AndroidComposeViewAccessibilityDelegateCompat androidComposeViewAccessibilityDelegateCompat1 = this.a;
        androidComposeViewAccessibilityDelegateCompat1.Y0(AndroidComposeViewAccessibilityDelegateCompat.j(androidComposeViewAccessibilityDelegateCompat1, param1View));
      } 
    }
    
    public void onViewDetachedFromWindow(View param1View) {
      AndroidComposeViewAccessibilityDelegateCompat.q(this.a).removeCallbacks(AndroidComposeViewAccessibilityDelegateCompat.u(this.a));
      AccessibilityManager accessibilityManager = AndroidComposeViewAccessibilityDelegateCompat.i(this.a);
      AndroidComposeViewAccessibilityDelegateCompat androidComposeViewAccessibilityDelegateCompat = this.a;
      accessibilityManager.removeAccessibilityStateChangeListener(AndroidComposeViewAccessibilityDelegateCompat.o(androidComposeViewAccessibilityDelegateCompat));
      accessibilityManager.removeTouchExplorationStateChangeListener(AndroidComposeViewAccessibilityDelegateCompat.w(androidComposeViewAccessibilityDelegateCompat));
      this.a.Y0(null);
    }
  }
  
  class AndroidComposeViewAccessibilityDelegateCompat {}
  
  class AndroidComposeViewAccessibilityDelegateCompat {}
  
  @Metadata(d1 = {"\000,\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\025\n\002\b\002\n\002\020\b\n\002\b\003\n\002\020\016\n\002\b\007\n\002\020\t\n\002\b\006\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003R\024\020\005\032\0020\0048\002X\004¢\006\006\n\004\b\005\020\006R\024\020\b\032\0020\0078\006XT¢\006\006\n\004\b\b\020\tR\024\020\n\032\0020\0078\006XT¢\006\006\n\004\b\n\020\tR\024\020\f\032\0020\0138\006XT¢\006\006\n\004\b\f\020\rR\024\020\016\032\0020\0138\006XT¢\006\006\n\004\b\016\020\rR\024\020\017\032\0020\0138\006XT¢\006\006\n\004\b\017\020\rR\024\020\020\032\0020\0078\006XT¢\006\006\n\004\b\020\020\tR\024\020\021\032\0020\0138\006XT¢\006\006\n\004\b\021\020\rR\024\020\022\032\0020\0078\006XT¢\006\006\n\004\b\022\020\tR\024\020\024\032\0020\0238\006XT¢\006\006\n\004\b\024\020\025R\024\020\026\032\0020\0138\006XT¢\006\006\n\004\b\026\020\rR\024\020\027\032\0020\0138\006XT¢\006\006\n\004\b\027\020\rR\024\020\030\032\0020\0238\006XT¢\006\006\n\004\b\030\020\025¨\006\031"}, d2 = {"Landroidx/compose/ui/platform/AndroidComposeViewAccessibilityDelegateCompat$d;", "", "<init>", "()V", "", "AccessibilityActionsResourceIds", "[I", "", "AccessibilityCursorPositionUndefined", "I", "AccessibilitySliderStepsCount", "", "ClassName", "Ljava/lang/String;", "ExtraDataIdKey", "ExtraDataTestTagKey", "InvalidId", "LogTag", "ParcelSafeTextLength", "", "SendRecurringAccessibilityEventsIntervalMillis", "J", "TextClassName", "TextFieldClassName", "TextTraversedEventTimeoutMillis", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class d {
    public d() {}
  }
  
  @Metadata(d1 = {"\0006\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\b\n\000\n\002\030\002\n\002\b\003\n\002\030\002\n\000\n\002\020\013\n\002\b\003\n\002\020\016\n\000\n\002\030\002\n\002\b\005\b\004\030\0002\0020\001B\007¢\006\004\b\002\020\003J\031\020\007\032\004\030\0010\0062\006\020\005\032\0020\004H\026¢\006\004\b\007\020\bJ)\020\r\032\0020\f2\006\020\005\032\0020\0042\006\020\t\032\0020\0042\b\020\013\032\004\030\0010\nH\026¢\006\004\b\r\020\016J1\020\023\032\0020\0222\006\020\005\032\0020\0042\006\020\017\032\0020\0062\006\020\021\032\0020\0202\b\020\013\032\004\030\0010\nH\026¢\006\004\b\023\020\024J\031\020\026\032\004\030\0010\0062\006\020\025\032\0020\004H\026¢\006\004\b\026\020\b¨\006\027"}, d2 = {"Landroidx/compose/ui/platform/AndroidComposeViewAccessibilityDelegateCompat$e;", "Landroid/view/accessibility/AccessibilityNodeProvider;", "<init>", "(Landroidx/compose/ui/platform/AndroidComposeViewAccessibilityDelegateCompat;)V", "", "virtualViewId", "Landroid/view/accessibility/AccessibilityNodeInfo;", "createAccessibilityNodeInfo", "(I)Landroid/view/accessibility/AccessibilityNodeInfo;", "action", "Landroid/os/Bundle;", "arguments", "", "performAction", "(IILandroid/os/Bundle;)Z", "info", "", "extraDataKey", "Ldbxyzptlk/pI/D;", "addExtraDataToAccessibilityNodeInfo", "(ILandroid/view/accessibility/AccessibilityNodeInfo;Ljava/lang/String;Landroid/os/Bundle;)V", "focus", "findFocus", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public final class e extends AccessibilityNodeProvider {
    public final AndroidComposeViewAccessibilityDelegateCompat a;
    
    public e(AndroidComposeViewAccessibilityDelegateCompat this$0) {}
    
    public void addExtraDataToAccessibilityNodeInfo(int param1Int, AccessibilityNodeInfo param1AccessibilityNodeInfo, String param1String, Bundle param1Bundle) {
      AndroidComposeViewAccessibilityDelegateCompat.e(this.a, param1Int, param1AccessibilityNodeInfo, param1String, param1Bundle);
    }
    
    public AccessibilityNodeInfo createAccessibilityNodeInfo(int param1Int) {
      AccessibilityNodeInfo accessibilityNodeInfo = AndroidComposeViewAccessibilityDelegateCompat.h(this.a, param1Int);
      if (AndroidComposeViewAccessibilityDelegateCompat.v(this.a) && param1Int == AndroidComposeViewAccessibilityDelegateCompat.p(this.a))
        AndroidComposeViewAccessibilityDelegateCompat.D(this.a, accessibilityNodeInfo); 
      return accessibilityNodeInfo;
    }
    
    public AccessibilityNodeInfo findFocus(int param1Int) {
      return createAccessibilityNodeInfo(AndroidComposeViewAccessibilityDelegateCompat.p(this.a));
    }
    
    public boolean performAction(int param1Int1, int param1Int2, Bundle param1Bundle) {
      return AndroidComposeViewAccessibilityDelegateCompat.A(this.a, param1Int1, param1Int2, param1Bundle);
    }
  }
  
  class AndroidComposeViewAccessibilityDelegateCompat {}
  
  class AndroidComposeViewAccessibilityDelegateCompat {}
  
  class AndroidComposeViewAccessibilityDelegateCompat {}
  
  @Metadata(d1 = {"\0006\n\002\030\002\n\002\020\000\n\002\030\002\n\000\n\002\020$\n\002\020\b\n\002\030\002\n\002\b\003\n\002\020\013\n\002\b\006\n\002\030\002\n\002\b\004\n\002\020#\n\002\b\004\b\002\030\0002\0020\001B#\022\006\020\003\032\0020\002\022\022\020\007\032\016\022\004\022\0020\005\022\004\022\0020\0060\004¢\006\004\b\b\020\tJ\r\020\013\032\0020\n¢\006\004\b\013\020\fR\027\020\003\032\0020\0028\006¢\006\f\n\004\b\r\020\016\032\004\b\017\020\020R\027\020\025\032\0020\0218\006¢\006\f\n\004\b\017\020\022\032\004\b\023\020\024R\035\020\031\032\b\022\004\022\0020\0050\0268\006¢\006\f\n\004\b\023\020\027\032\004\b\r\020\030¨\006\032"}, d2 = {"Landroidx/compose/ui/platform/AndroidComposeViewAccessibilityDelegateCompat$i;", "", "Ldbxyzptlk/l1/p;", "semanticsNode", "", "", "Ldbxyzptlk/g1/x1;", "currentSemanticsNodes", "<init>", "(Ldbxyzptlk/l1/p;Ljava/util/Map;)V", "", "d", "()Z", "a", "Ldbxyzptlk/l1/p;", "b", "()Ldbxyzptlk/l1/p;", "Ldbxyzptlk/l1/l;", "Ldbxyzptlk/l1/l;", "c", "()Ldbxyzptlk/l1/l;", "unmergedConfig", "", "Ljava/util/Set;", "()Ljava/util/Set;", "children", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class i {
    public final p a;
    
    public final l b;
    
    public final Set<Integer> c;
    
    public i(p param1p, Map<Integer, x1> param1Map) {
      this.a = param1p;
      this.b = param1p.v();
      this.c = new LinkedHashSet<>();
      List<p> list = param1p.s();
      int j = list.size();
      for (byte b = 0; b < j; b++) {
        param1p = list.get(b);
        if (param1Map.containsKey(Integer.valueOf(param1p.n())))
          this.c.add(Integer.valueOf(param1p.n())); 
      } 
    }
    
    public final Set<Integer> a() {
      return this.c;
    }
    
    public final p b() {
      return this.a;
    }
    
    public final l c() {
      return this.b;
    }
    
    public final boolean d() {
      return this.b.j(s.a.r());
    }
  }
  
  class AndroidComposeViewAccessibilityDelegateCompat {}
  
  @Metadata(d1 = {"\000\f\n\002\030\002\n\002\020\020\n\002\b\005\b\001\030\0002\b\022\004\022\0020\0000\001B\t\b\002¢\006\004\b\002\020\003j\002\b\004j\002\b\005¨\006\006"}, d2 = {"Landroidx/compose/ui/platform/AndroidComposeViewAccessibilityDelegateCompat$k;", "", "<init>", "(Ljava/lang/String;I)V", "SHOW_ORIGINAL", "SHOW_TRANSLATED", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public enum k {
    SHOW_ORIGINAL, SHOW_TRANSLATED;
    
    private static final k[] $VALUES = a();
    
    static {
    
    }
  }
  
  class AndroidComposeViewAccessibilityDelegateCompat {}
  
  class AndroidComposeViewAccessibilityDelegateCompat {}
  
  @f(c = "androidx.compose.ui.platform.AndroidComposeViewAccessibilityDelegateCompat", f = "AndroidComposeViewAccessibilityDelegateCompat.android.kt", l = {2213, 2249}, m = "boundsUpdatesEventLoop$ui_release")
  @Metadata(k = 3, mv = {1, 8, 0}, xi = 48)
  public static final class n extends dbxyzptlk.vI.d {
    public Object t;
    
    public Object u;
    
    public Object v;
    
    public Object w;
    
    public final AndroidComposeViewAccessibilityDelegateCompat x;
    
    public int y;
    
    public n(AndroidComposeViewAccessibilityDelegateCompat param1AndroidComposeViewAccessibilityDelegateCompat, dbxyzptlk.tI.d<? super n> param1d) {
      super(param1d);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      this.w = param1Object;
      this.y |= Integer.MIN_VALUE;
      return this.x.G((dbxyzptlk.tI.d<? super D>)this);
    }
  }
  
  @Metadata(d1 = {"\000\016\n\002\030\002\n\000\n\002\020\013\n\002\b\002\020\003\032\0020\0022\006\020\001\032\0020\000H\n¢\006\004\b\003\020\004"}, d2 = {"Landroid/view/accessibility/AccessibilityEvent;", "it", "", "a", "(Landroid/view/accessibility/AccessibilityEvent;)Ljava/lang/Boolean;"}, k = 3, mv = {1, 8, 0})
  public static final class o extends u implements l<AccessibilityEvent, Boolean> {
    public final AndroidComposeViewAccessibilityDelegateCompat f;
    
    public o(AndroidComposeViewAccessibilityDelegateCompat param1AndroidComposeViewAccessibilityDelegateCompat) {
      super(1);
    }
    
    public final Boolean a(AccessibilityEvent param1AccessibilityEvent) {
      return Boolean.valueOf(this.f.i0().getParent().requestSendAccessibilityEvent((View)this.f.i0(), param1AccessibilityEvent));
    }
  }
  
  @Metadata(d1 = {"\000\016\n\002\030\002\n\000\n\002\030\002\n\002\b\002\020\003\032\0020\0022\006\020\001\032\0020\000H\n¢\006\004\b\003\020\004"}, d2 = {"Ldbxyzptlk/g1/w1;", "it", "Ldbxyzptlk/pI/D;", "a", "(Ldbxyzptlk/g1/w1;)V"}, k = 3, mv = {1, 8, 0})
  public static final class q extends u implements l<w1, D> {
    public final AndroidComposeViewAccessibilityDelegateCompat f;
    
    public q(AndroidComposeViewAccessibilityDelegateCompat param1AndroidComposeViewAccessibilityDelegateCompat) {
      super(1);
    }
    
    public final void a(w1 param1w1) {
      AndroidComposeViewAccessibilityDelegateCompat.B(this.f, param1w1);
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compos\\ui\platform\AndroidComposeViewAccessibilityDelegateCompat.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */