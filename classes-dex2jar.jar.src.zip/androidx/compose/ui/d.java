package androidx.compose.ui;

import androidx.compose.ui.node.n;
import dbxyzptlk.CI.l;
import dbxyzptlk.CI.p;
import dbxyzptlk.K0.f;
import dbxyzptlk.bK.J;
import dbxyzptlk.bK.K;
import dbxyzptlk.bK.w0;
import dbxyzptlk.bK.z0;
import dbxyzptlk.f1.P;
import dbxyzptlk.f1.g;
import dbxyzptlk.f1.h;
import dbxyzptlk.pI.D;
import dbxyzptlk.tI.g;
import java.util.concurrent.CancellationException;
import kotlin.Metadata;

@Metadata(d1 = {"\000$\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\030\002\n\002\b\003\n\002\030\002\n\002\020\013\n\002\b\b\bg\030\000 \0072\0020\001:\003\007\021\fJ7\020\007\032\0028\000\"\004\b\000\020\0022\006\020\003\032\0028\0002\030\020\006\032\024\022\004\022\0028\000\022\004\022\0020\005\022\004\022\0028\0000\004H&¢\006\004\b\007\020\bJ#\020\f\032\0020\n2\022\020\013\032\016\022\004\022\0020\005\022\004\022\0020\n0\tH&¢\006\004\b\f\020\rJ\030\020\017\032\0020\0002\006\020\016\032\0020\000H\004¢\006\004\b\017\020\020ø\001\000\002\006\n\004\b!0\001¨\006\022À\006\003"}, d2 = {"Landroidx/compose/ui/d;", "", "R", "initial", "Lkotlin/Function2;", "Landroidx/compose/ui/d$b;", "operation", "a", "(Ljava/lang/Object;Ldbxyzptlk/CI/p;)Ljava/lang/Object;", "Lkotlin/Function1;", "", "predicate", "c", "(Ldbxyzptlk/CI/l;)Z", "other", "g", "(Landroidx/compose/ui/d;)Landroidx/compose/ui/d;", "b", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public interface d {
  public static final a a = a.b;
  
  <R> R a(R paramR, p<? super R, ? super b, ? extends R> paramp);
  
  boolean c(l<? super b, Boolean> paraml);
  
  default d g(d paramd) {
    if (paramd == a) {
      paramd = this;
    } else {
      paramd = new a(this, paramd);
    } 
    return paramd;
  }
  
  @Metadata(d1 = {"\000,\n\002\030\002\n\002\030\002\n\002\b\004\n\002\030\002\n\002\030\002\n\002\b\003\n\002\030\002\n\002\020\013\n\002\b\006\n\002\020\016\n\002\b\003\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J7\020\t\032\0028\000\"\004\b\000\020\0042\006\020\005\032\0028\0002\030\020\b\032\024\022\004\022\0028\000\022\004\022\0020\007\022\004\022\0028\0000\006H\026¢\006\004\b\t\020\nJ#\020\016\032\0020\f2\022\020\r\032\016\022\004\022\0020\007\022\004\022\0020\f0\013H\026¢\006\004\b\016\020\017J\030\020\021\032\0020\0012\006\020\020\032\0020\001H\004¢\006\004\b\021\020\022J\017\020\024\032\0020\023H\026¢\006\004\b\024\020\025¨\006\026"}, d2 = {"Landroidx/compose/ui/d$a;", "Landroidx/compose/ui/d;", "<init>", "()V", "R", "initial", "Lkotlin/Function2;", "Landroidx/compose/ui/d$b;", "operation", "a", "(Ljava/lang/Object;Ldbxyzptlk/CI/p;)Ljava/lang/Object;", "Lkotlin/Function1;", "", "predicate", "c", "(Ldbxyzptlk/CI/l;)Z", "other", "g", "(Landroidx/compose/ui/d;)Landroidx/compose/ui/d;", "", "toString", "()Ljava/lang/String;", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class a implements d {
    public static final a b = new a();
    
    public <R> R a(R param1R, p<? super R, ? super d.b, ? extends R> param1p) {
      return param1R;
    }
    
    public boolean c(l<? super d.b, Boolean> param1l) {
      return true;
    }
    
    public d g(d param1d) {
      return param1d;
    }
    
    public String toString() {
      return "Modifier";
    }
  }
  
  @Metadata(d1 = {"\000 \n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\003\n\002\030\002\n\002\020\013\n\002\b\004\bf\030\0002\0020\001J7\020\006\032\0028\000\"\004\b\000\020\0022\006\020\003\032\0028\0002\030\020\005\032\024\022\004\022\0028\000\022\004\022\0020\000\022\004\022\0028\0000\004H\026¢\006\004\b\006\020\007J#\020\013\032\0020\t2\022\020\n\032\016\022\004\022\0020\000\022\004\022\0020\t0\bH\026¢\006\004\b\013\020\fø\001\000\002\006\n\004\b!0\001¨\006\rÀ\006\003"}, d2 = {"Landroidx/compose/ui/d$b;", "Landroidx/compose/ui/d;", "R", "initial", "Lkotlin/Function2;", "operation", "a", "(Ljava/lang/Object;Ldbxyzptlk/CI/p;)Ljava/lang/Object;", "Lkotlin/Function1;", "", "predicate", "c", "(Ldbxyzptlk/CI/l;)Z", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static interface b extends d {
    default <R> R a(R param1R, p<? super R, ? super b, ? extends R> param1p) {
      return (R)param1p.invoke(param1R, this);
    }
    
    default boolean c(l<? super b, Boolean> param1l) {
      return ((Boolean)param1l.invoke(this)).booleanValue();
    }
  }
  
  @Metadata(d1 = {"\000B\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\n\n\002\030\002\n\002\b\r\n\002\030\002\n\002\b\003\n\002\020\b\n\002\b\023\n\002\030\002\n\002\b\013\n\002\020\013\n\002\b\031\b'\030\0002\0020\001B\007¢\006\004\b\002\020\003J\031\020\007\032\0020\0062\b\020\005\032\004\030\0010\004H\020¢\006\004\b\007\020\bJ\017\020\t\032\0020\006H\020¢\006\004\b\t\020\003J\017\020\n\032\0020\006H\020¢\006\004\b\n\020\003J\017\020\013\032\0020\006H\020¢\006\004\b\013\020\003J\017\020\f\032\0020\006H\020¢\006\004\b\f\020\003J\017\020\r\032\0020\006H\020¢\006\004\b\r\020\003J\017\020\016\032\0020\006H\026¢\006\004\b\016\020\003J\017\020\017\032\0020\006H\026¢\006\004\b\017\020\003J\017\020\020\032\0020\006H\026¢\006\004\b\020\020\003J\035\020\023\032\0020\0062\f\020\022\032\b\022\004\022\0020\0060\021H\007¢\006\004\b\023\020\024J\027\020\026\032\0020\0062\006\020\025\032\0020\000H\000¢\006\004\b\026\020\027R*\020\036\032\0020\0002\006\020\030\032\0020\0008\006@BX\016¢\006\022\n\004\b\031\020\032\022\004\b\035\020\003\032\004\b\033\020\034R\030\020\"\032\004\030\0010\0378\002@\002X\016¢\006\006\n\004\b \020!R\"\020*\032\0020#8\000@\000X\016¢\006\022\n\004\b$\020%\032\004\b&\020'\"\004\b(\020)R\"\020.\032\0020#8\000@\000X\016¢\006\022\n\004\b+\020%\032\004\b,\020'\"\004\b-\020)R$\0202\032\004\030\0010\0008\000@\000X\016¢\006\022\n\004\b/\020\032\032\004\b0\020\034\"\004\b1\020\027R$\0206\032\004\030\0010\0008\000@\000X\016¢\006\022\n\004\b3\020\032\032\004\b4\020\034\"\004\b5\020\027R$\020>\032\004\030\001078\000@\000X\016¢\006\022\n\004\b8\0209\032\004\b:\020;\"\004\b<\020=R(\020\005\032\004\030\0010\0042\b\020\030\032\004\030\0010\0048\000@BX\016¢\006\f\n\004\b?\020@\032\004\bA\020BR\"\020J\032\0020C8\000@\000X\016¢\006\022\n\004\bD\020E\032\004\bF\020G\"\004\bH\020IR\"\020N\032\0020C8\000@\000X\016¢\006\022\n\004\bK\020E\032\004\bL\020G\"\004\bM\020IR\026\020P\032\0020C8\002@\002X\016¢\006\006\n\004\bO\020ER\026\020R\032\0020C8\002@\002X\016¢\006\006\n\004\bQ\020ER$\020U\032\0020C2\006\020\030\032\0020C8\006@BX\016¢\006\f\n\004\bS\020E\032\004\bT\020GR\021\020X\032\0020\0378F¢\006\006\032\004\bV\020WR\032\020[\032\0020C8VX\004¢\006\f\022\004\bZ\020\003\032\004\bY\020G¨\006\\"}, d2 = {"Landroidx/compose/ui/d$c;", "Ldbxyzptlk/f1/g;", "<init>", "()V", "Landroidx/compose/ui/node/n;", "coordinator", "Ldbxyzptlk/pI/D;", "j2", "(Landroidx/compose/ui/node/n;)V", "S1", "Y1", "Z1", "T1", "X1", "U1", "V1", "W1", "Lkotlin/Function0;", "effect", "i2", "(Ldbxyzptlk/CI/a;)V", "owner", "b2", "(Landroidx/compose/ui/d$c;)V", "<set-?>", "a", "Landroidx/compose/ui/d$c;", "Q0", "()Landroidx/compose/ui/d$c;", "getNode$annotations", "node", "Ldbxyzptlk/bK/J;", "b", "Ldbxyzptlk/bK/J;", "scope", "", "c", "I", "M1", "()I", "e2", "(I)V", "kindSet", "d", "H1", "a2", "aggregateChildKindSet", "e", "O1", "g2", "parent", "f", "I1", "c2", "child", "Ldbxyzptlk/f1/P;", "g", "Ldbxyzptlk/f1/P;", "N1", "()Ldbxyzptlk/f1/P;", "f2", "(Ldbxyzptlk/f1/P;)V", "ownerScope", "h", "Landroidx/compose/ui/node/n;", "J1", "()Landroidx/compose/ui/node/n;", "", "i", "Z", "L1", "()Z", "d2", "(Z)V", "insertedNodeAwaitingAttachForInvalidation", "j", "Q1", "h2", "updatedNodeAwaitingAttachForInvalidation", "k", "onAttachRunExpected", "l", "onDetachRunExpected", "m", "R1", "isAttached", "K1", "()Ldbxyzptlk/bK/J;", "coroutineScope", "P1", "getShouldAutoInvalidate$annotations", "shouldAutoInvalidate", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static abstract class c implements g {
    public c a = this;
    
    public J b;
    
    public int c;
    
    public int d = -1;
    
    public c e;
    
    public c f;
    
    public P g;
    
    public n h;
    
    public boolean i;
    
    public boolean j;
    
    public boolean k;
    
    public boolean l;
    
    public boolean m;
    
    public final int H1() {
      return this.d;
    }
    
    public final c I1() {
      return this.f;
    }
    
    public final n J1() {
      return this.h;
    }
    
    public final J K1() {
      J j2 = this.b;
      J j1 = j2;
      if (j2 == null) {
        j1 = K.a(h.l(this).getCoroutineContext().s((g)z0.a((w0)h.l(this).getCoroutineContext().c((g.c)w0.Ia))));
        this.b = j1;
      } 
      return j1;
    }
    
    public final boolean L1() {
      return this.i;
    }
    
    public final int M1() {
      return this.c;
    }
    
    public final P N1() {
      return this.g;
    }
    
    public final c O1() {
      return this.e;
    }
    
    public boolean P1() {
      return true;
    }
    
    public final c Q0() {
      return this.a;
    }
    
    public final boolean Q1() {
      return this.j;
    }
    
    public final boolean R1() {
      return this.m;
    }
    
    public void S1() {
      if (!this.m) {
        if (this.h != null) {
          this.m = true;
          this.k = true;
          return;
        } 
        throw new IllegalStateException("attach invoked on a node without a coordinator");
      } 
      throw new IllegalStateException("node attached multiple times");
    }
    
    public void T1() {
      if (this.m) {
        if (!this.k) {
          if (!this.l) {
            this.m = false;
            J j = this.b;
            if (j != null) {
              K.d(j, (CancellationException)new f());
              this.b = null;
            } 
            return;
          } 
          throw new IllegalStateException("Must run runDetachLifecycle() before markAsDetached()");
        } 
        throw new IllegalStateException("Must run runAttachLifecycle() before markAsDetached()");
      } 
      throw new IllegalStateException("Cannot detach a node that is not attached");
    }
    
    public void U1() {}
    
    public void V1() {}
    
    public void W1() {}
    
    public void X1() {
      if (this.m) {
        W1();
        return;
      } 
      throw new IllegalStateException("reset() called on an unattached node");
    }
    
    public void Y1() {
      if (this.m) {
        if (this.k) {
          this.k = false;
          U1();
          this.l = true;
          return;
        } 
        throw new IllegalStateException("Must run runAttachLifecycle() only once after markAsAttached()");
      } 
      throw new IllegalStateException("Must run markAsAttached() prior to runAttachLifecycle");
    }
    
    public void Z1() {
      if (this.m) {
        if (this.h != null) {
          if (this.l) {
            this.l = false;
            V1();
            return;
          } 
          throw new IllegalStateException("Must run runDetachLifecycle() once after runAttachLifecycle() and before markAsDetached()");
        } 
        throw new IllegalStateException("detach invoked on a node without a coordinator");
      } 
      throw new IllegalStateException("node detached multiple times");
    }
    
    public final void a2(int param1Int) {
      this.d = param1Int;
    }
    
    public final void b2(c param1c) {
      this.a = param1c;
    }
    
    public final void c2(c param1c) {
      this.f = param1c;
    }
    
    public final void d2(boolean param1Boolean) {
      this.i = param1Boolean;
    }
    
    public final void e2(int param1Int) {
      this.c = param1Int;
    }
    
    public final void f2(P param1P) {
      this.g = param1P;
    }
    
    public final void g2(c param1c) {
      this.e = param1c;
    }
    
    public final void h2(boolean param1Boolean) {
      this.j = param1Boolean;
    }
    
    public final void i2(dbxyzptlk.CI.a<D> param1a) {
      h.l(this).h(param1a);
    }
    
    public void j2(n param1n) {
      this.h = param1n;
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compos\\ui\d.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */