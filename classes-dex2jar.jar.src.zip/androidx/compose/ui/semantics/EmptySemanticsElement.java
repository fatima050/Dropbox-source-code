package androidx.compose.ui.semantics;

import androidx.compose.ui.d;
import dbxyzptlk.f1.G;
import dbxyzptlk.l1.f;
import kotlin.Metadata;

@Metadata(d1 = {"\000.\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\002\n\002\020\b\n\002\b\002\n\002\020\000\n\000\n\002\020\013\n\002\b\003\bÀ\002\030\0002\b\022\004\022\0020\0020\001B\t\b\002¢\006\004\b\003\020\004J\017\020\005\032\0020\002H\026¢\006\004\b\005\020\006J\027\020\t\032\0020\b2\006\020\007\032\0020\002H\026¢\006\004\b\t\020\nJ\017\020\f\032\0020\013H\026¢\006\004\b\f\020\rJ\032\020\021\032\0020\0202\b\020\017\032\004\030\0010\016H\002¢\006\004\b\021\020\022¨\006\023"}, d2 = {"Landroidx/compose/ui/semantics/EmptySemanticsElement;", "Ldbxyzptlk/f1/G;", "Ldbxyzptlk/l1/f;", "<init>", "()V", "i", "()Ldbxyzptlk/l1/f;", "node", "Ldbxyzptlk/pI/D;", "k", "(Ldbxyzptlk/l1/f;)V", "", "hashCode", "()I", "", "other", "", "equals", "(Ljava/lang/Object;)Z", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class EmptySemanticsElement extends G<f> {
  public static final EmptySemanticsElement b = new EmptySemanticsElement();
  
  public boolean equals(Object paramObject) {
    boolean bool;
    if (paramObject == this) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public int hashCode() {
    return System.identityHashCode(this);
  }
  
  public f i() {
    return new f();
  }
  
  public void k(f paramf) {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compos\\ui\semantics\EmptySemanticsElement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */