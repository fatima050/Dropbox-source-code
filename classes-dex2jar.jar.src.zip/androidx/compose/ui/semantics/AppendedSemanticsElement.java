package androidx.compose.ui.semantics;

import androidx.compose.ui.d;
import dbxyzptlk.CI.l;
import dbxyzptlk.DI.s;
import dbxyzptlk.f1.G;
import dbxyzptlk.l1.d;
import dbxyzptlk.l1.l;
import dbxyzptlk.l1.n;
import dbxyzptlk.l1.x;
import dbxyzptlk.pI.D;
import kotlin.Metadata;

@Metadata(d1 = {"\000F\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\013\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\b\n\002\020\016\n\002\b\002\n\002\020\b\n\002\b\002\n\002\020\000\n\002\b\013\n\002\030\002\n\002\b\004\b\b\030\0002\b\022\004\022\0020\0020\0012\0020\003B#\022\006\020\005\032\0020\004\022\022\020\t\032\016\022\004\022\0020\007\022\004\022\0020\b0\006¢\006\004\b\n\020\013J\017\020\f\032\0020\002H\026¢\006\004\b\f\020\rJ\027\020\017\032\0020\b2\006\020\016\032\0020\002H\026¢\006\004\b\017\020\020J\020\020\022\032\0020\021HÖ\001¢\006\004\b\022\020\023J\020\020\025\032\0020\024HÖ\001¢\006\004\b\025\020\026J\032\020\031\032\0020\0042\b\020\030\032\004\030\0010\027HÖ\003¢\006\004\b\031\020\032R\027\020\005\032\0020\0048\006¢\006\f\n\004\b\033\020\034\032\004\b\035\020\036R#\020\t\032\016\022\004\022\0020\007\022\004\022\0020\b0\0068\006¢\006\f\n\004\b\037\020 \032\004\b!\020\"R\024\020&\032\0020#8VX\004¢\006\006\032\004\b$\020%¨\006'"}, d2 = {"Landroidx/compose/ui/semantics/AppendedSemanticsElement;", "Ldbxyzptlk/f1/G;", "Ldbxyzptlk/l1/d;", "Ldbxyzptlk/l1/n;", "", "mergeDescendants", "Lkotlin/Function1;", "Ldbxyzptlk/l1/x;", "Ldbxyzptlk/pI/D;", "properties", "<init>", "(ZLdbxyzptlk/CI/l;)V", "i", "()Ldbxyzptlk/l1/d;", "node", "k", "(Ldbxyzptlk/l1/d;)V", "", "toString", "()Ljava/lang/String;", "", "hashCode", "()I", "", "other", "equals", "(Ljava/lang/Object;)Z", "b", "Z", "getMergeDescendants", "()Z", "c", "Ldbxyzptlk/CI/l;", "getProperties", "()Ldbxyzptlk/CI/l;", "Ldbxyzptlk/l1/l;", "z", "()Ldbxyzptlk/l1/l;", "semanticsConfiguration", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class AppendedSemanticsElement extends G<d> implements n {
  public final boolean b;
  
  public final l<x, D> c;
  
  public AppendedSemanticsElement(boolean paramBoolean, l<? super x, D> paraml) {
    this.b = paramBoolean;
    this.c = (l)paraml;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof AppendedSemanticsElement))
      return false; 
    paramObject = paramObject;
    return (this.b != ((AppendedSemanticsElement)paramObject).b) ? false : (!!s.c(this.c, ((AppendedSemanticsElement)paramObject).c));
  }
  
  public int hashCode() {
    return Boolean.hashCode(this.b) * 31 + this.c.hashCode();
  }
  
  public d i() {
    return new d(this.b, false, this.c);
  }
  
  public void k(d paramd) {
    paramd.k2(this.b);
    paramd.l2(this.c);
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("AppendedSemanticsElement(mergeDescendants=");
    stringBuilder.append(this.b);
    stringBuilder.append(", properties=");
    stringBuilder.append(this.c);
    stringBuilder.append(')');
    return stringBuilder.toString();
  }
  
  public l z() {
    l l1 = new l();
    l1.B(this.b);
    this.c.invoke(l1);
    return l1;
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compos\\ui\semantics\AppendedSemanticsElement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */