package androidx.compose.ui.input.pointer;

import androidx.compose.ui.d;
import dbxyzptlk.CI.p;
import dbxyzptlk.DI.s;
import dbxyzptlk.a1.J;
import dbxyzptlk.a1.V;
import dbxyzptlk.f1.G;
import dbxyzptlk.pI.D;
import dbxyzptlk.tI.d;
import java.util.Arrays;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

@Metadata(d1 = {"\000>\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\021\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\t\n\002\020\013\n\002\b\002\n\002\020\b\n\002\b\021\b\000\030\0002\b\022\004\022\0020\0020\001BY\022\n\b\002\020\004\032\004\030\0010\003\022\n\b\002\020\005\032\004\030\0010\003\022\024\b\002\020\007\032\016\022\b\b\001\022\004\030\0010\003\030\0010\006\022\"\020\f\032\036\b\001\022\004\022\0020\t\022\n\022\b\022\004\022\0020\0130\n\022\006\022\004\030\0010\0030\b¢\006\004\b\r\020\016J\017\020\017\032\0020\002H\026¢\006\004\b\017\020\020J\027\020\022\032\0020\0132\006\020\021\032\0020\002H\026¢\006\004\b\022\020\023J\032\020\026\032\0020\0252\b\020\024\032\004\030\0010\003H\002¢\006\004\b\026\020\027J\017\020\031\032\0020\030H\026¢\006\004\b\031\020\032R\031\020\004\032\004\030\0010\0038\006¢\006\f\n\004\b\033\020\034\032\004\b\035\020\036R\031\020\005\032\004\030\0010\0038\006¢\006\f\n\004\b\037\020\034\032\004\b \020\036R#\020\007\032\016\022\b\b\001\022\004\030\0010\003\030\0010\0068\006¢\006\f\n\004\b!\020\"\032\004\b#\020$R3\020\f\032\036\b\001\022\004\022\0020\t\022\n\022\b\022\004\022\0020\0130\n\022\006\022\004\030\0010\0030\b8\006¢\006\f\n\004\b%\020&\032\004\b'\020(¨\006)"}, d2 = {"Landroidx/compose/ui/input/pointer/SuspendPointerInputElement;", "Ldbxyzptlk/f1/G;", "Ldbxyzptlk/a1/V;", "", "key1", "key2", "", "keys", "Lkotlin/Function2;", "Ldbxyzptlk/a1/J;", "Ldbxyzptlk/tI/d;", "Ldbxyzptlk/pI/D;", "pointerInputHandler", "<init>", "(Ljava/lang/Object;Ljava/lang/Object;[Ljava/lang/Object;Ldbxyzptlk/CI/p;)V", "i", "()Ldbxyzptlk/a1/V;", "node", "k", "(Ldbxyzptlk/a1/V;)V", "other", "", "equals", "(Ljava/lang/Object;)Z", "", "hashCode", "()I", "b", "Ljava/lang/Object;", "getKey1", "()Ljava/lang/Object;", "c", "getKey2", "d", "[Ljava/lang/Object;", "getKeys", "()[Ljava/lang/Object;", "e", "Ldbxyzptlk/CI/p;", "getPointerInputHandler", "()Ldbxyzptlk/CI/p;", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class SuspendPointerInputElement extends G<V> {
  public final Object b;
  
  public final Object c;
  
  public final Object[] d;
  
  public final p<J, d<? super D>, Object> e;
  
  public SuspendPointerInputElement(Object paramObject1, Object paramObject2, Object[] paramArrayOfObject, p<? super J, ? super d<? super D>, ? extends Object> paramp) {
    this.b = paramObject1;
    this.c = paramObject2;
    this.d = paramArrayOfObject;
    this.e = (p)paramp;
  }
  
  public boolean equals(Object paramObject) {
    Object[] arrayOfObject;
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof SuspendPointerInputElement))
      return false; 
    Object object = this.b;
    SuspendPointerInputElement suspendPointerInputElement = (SuspendPointerInputElement)paramObject;
    if (!s.c(object, suspendPointerInputElement.b))
      return false; 
    if (!s.c(this.c, suspendPointerInputElement.c))
      return false; 
    paramObject = this.d;
    if (paramObject != null) {
      arrayOfObject = suspendPointerInputElement.d;
      if (arrayOfObject == null)
        return false; 
      if (!Arrays.equals((Object[])paramObject, arrayOfObject))
        return false; 
    } else if (((SuspendPointerInputElement)arrayOfObject).d != null) {
      return false;
    } 
    return true;
  }
  
  public int hashCode() {
    byte b1;
    byte b2;
    Object object = this.b;
    int i = 0;
    if (object != null) {
      b1 = object.hashCode();
    } else {
      b1 = 0;
    } 
    object = this.c;
    if (object != null) {
      b2 = object.hashCode();
    } else {
      b2 = 0;
    } 
    object = this.d;
    if (object != null)
      i = Arrays.hashCode((Object[])object); 
    return (b1 * 31 + b2) * 31 + i;
  }
  
  public V i() {
    return new V(this.e);
  }
  
  public void k(V paramV) {
    paramV.p2(this.e);
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compos\\ui\input\pointer\SuspendPointerInputElement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */