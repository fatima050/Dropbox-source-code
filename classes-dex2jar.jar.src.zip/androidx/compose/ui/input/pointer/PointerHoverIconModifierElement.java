package androidx.compose.ui.input.pointer;

import androidx.compose.ui.d;
import dbxyzptlk.DI.s;
import dbxyzptlk.a1.u;
import dbxyzptlk.a1.v;
import dbxyzptlk.f1.G;
import kotlin.Metadata;

@Metadata(d1 = {"\000:\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\020\013\n\002\b\006\n\002\030\002\n\002\b\002\n\002\020\016\n\002\b\002\n\002\020\b\n\002\b\002\n\002\020\000\n\002\b\f\b\b\030\0002\b\022\004\022\0020\0020\001B\031\022\006\020\004\032\0020\003\022\b\b\002\020\006\032\0020\005¢\006\004\b\007\020\bJ\017\020\t\032\0020\002H\026¢\006\004\b\t\020\nJ\027\020\r\032\0020\f2\006\020\013\032\0020\002H\026¢\006\004\b\r\020\016J\020\020\020\032\0020\017HÖ\001¢\006\004\b\020\020\021J\020\020\023\032\0020\022HÖ\001¢\006\004\b\023\020\024J\032\020\027\032\0020\0052\b\020\026\032\004\030\0010\025HÖ\003¢\006\004\b\027\020\030R\027\020\004\032\0020\0038\006¢\006\f\n\004\b\031\020\032\032\004\b\033\020\034R\027\020\006\032\0020\0058\006¢\006\f\n\004\b\035\020\036\032\004\b\037\020 ¨\006!"}, d2 = {"Landroidx/compose/ui/input/pointer/PointerHoverIconModifierElement;", "Ldbxyzptlk/f1/G;", "Ldbxyzptlk/a1/u;", "Ldbxyzptlk/a1/v;", "icon", "", "overrideDescendants", "<init>", "(Ldbxyzptlk/a1/v;Z)V", "i", "()Ldbxyzptlk/a1/u;", "node", "Ldbxyzptlk/pI/D;", "k", "(Ldbxyzptlk/a1/u;)V", "", "toString", "()Ljava/lang/String;", "", "hashCode", "()I", "", "other", "equals", "(Ljava/lang/Object;)Z", "b", "Ldbxyzptlk/a1/v;", "getIcon", "()Ldbxyzptlk/a1/v;", "c", "Z", "getOverrideDescendants", "()Z", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class PointerHoverIconModifierElement extends G<u> {
  public final v b;
  
  public final boolean c;
  
  public PointerHoverIconModifierElement(v paramv, boolean paramBoolean) {
    this.b = paramv;
    this.c = paramBoolean;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof PointerHoverIconModifierElement))
      return false; 
    paramObject = paramObject;
    return !s.c(this.b, ((PointerHoverIconModifierElement)paramObject).b) ? false : (!(this.c != ((PointerHoverIconModifierElement)paramObject).c));
  }
  
  public int hashCode() {
    return this.b.hashCode() * 31 + Boolean.hashCode(this.c);
  }
  
  public u i() {
    return new u(this.b, this.c);
  }
  
  public void k(u paramu) {
    paramu.v2(this.b);
    paramu.w2(this.c);
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("PointerHoverIconModifierElement(icon=");
    stringBuilder.append(this.b);
    stringBuilder.append(", overrideDescendants=");
    stringBuilder.append(this.c);
    stringBuilder.append(')');
    return stringBuilder.toString();
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compos\\ui\input\pointer\PointerHoverIconModifierElement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */