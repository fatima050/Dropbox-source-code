package androidx.compose.ui.input.pointer;

import java.util.concurrent.CancellationException;
import kotlin.Metadata;

@Metadata(d1 = {"\000\034\n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\020\t\n\002\b\002\n\002\020\003\n\000\b\007\030\0002\0060\001j\002`\002B\r\022\006\020\003\032\0020\004¢\006\002\020\005J\b\020\006\032\0020\007H\026¨\006\b"}, d2 = {"Landroidx/compose/ui/input/pointer/PointerEventTimeoutCancellationException;", "Ljava/util/concurrent/CancellationException;", "Lkotlinx/coroutines/CancellationException;", "time", "", "(J)V", "fillInStackTrace", "", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class PointerEventTimeoutCancellationException extends CancellationException {
  static {
  
  }
  
  public PointerEventTimeoutCancellationException(long paramLong) {
    super(stringBuilder.toString());
  }
  
  public Throwable fillInStackTrace() {
    setStackTrace(new StackTraceElement[0]);
    return this;
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compos\\ui\input\pointer\PointerEventTimeoutCancellationException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */