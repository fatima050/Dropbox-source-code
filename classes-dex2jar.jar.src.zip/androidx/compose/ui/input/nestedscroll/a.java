package androidx.compose.ui.input.nestedscroll;

import androidx.compose.ui.d;
import dbxyzptlk.Z0.b;
import kotlin.Metadata;

@Metadata(d1 = {"\000\022\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\004\032%\020\005\032\0020\000*\0020\0002\006\020\002\032\0020\0012\n\b\002\020\004\032\004\030\0010\003¢\006\004\b\005\020\006¨\006\007"}, d2 = {"Landroidx/compose/ui/d;", "Ldbxyzptlk/Z0/a;", "connection", "Ldbxyzptlk/Z0/b;", "dispatcher", "a", "(Landroidx/compose/ui/d;Ldbxyzptlk/Z0/a;Ldbxyzptlk/Z0/b;)Landroidx/compose/ui/d;", "ui_release"}, k = 2, mv = {1, 8, 0}, xi = 48)
public final class a {
  public static final d a(d paramd, dbxyzptlk.Z0.a parama, b paramb) {
    return paramd.g((d)new NestedScrollElement(parama, paramb));
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compos\\ui\input\nestedscroll\a.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */