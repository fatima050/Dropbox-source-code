package androidx.compose.ui.input.nestedscroll;

import androidx.compose.ui.d;
import dbxyzptlk.DI.s;
import dbxyzptlk.Z0.a;
import dbxyzptlk.Z0.b;
import dbxyzptlk.Z0.c;
import dbxyzptlk.f1.G;
import kotlin.Metadata;

@Metadata(d1 = {"\0008\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\006\n\002\030\002\n\002\b\002\n\002\020\b\n\002\b\002\n\002\020\000\n\000\n\002\020\013\n\002\b\013\b\002\030\0002\b\022\004\022\0020\0020\001B\031\022\006\020\004\032\0020\003\022\b\020\006\032\004\030\0010\005¢\006\004\b\007\020\bJ\017\020\t\032\0020\002H\026¢\006\004\b\t\020\nJ\027\020\r\032\0020\f2\006\020\013\032\0020\002H\026¢\006\004\b\r\020\016J\017\020\020\032\0020\017H\026¢\006\004\b\020\020\021J\032\020\025\032\0020\0242\b\020\023\032\004\030\0010\022H\002¢\006\004\b\025\020\026R\027\020\004\032\0020\0038\006¢\006\f\n\004\b\027\020\030\032\004\b\031\020\032R\031\020\006\032\004\030\0010\0058\006¢\006\f\n\004\b\033\020\034\032\004\b\035\020\036¨\006\037"}, d2 = {"Landroidx/compose/ui/input/nestedscroll/NestedScrollElement;", "Ldbxyzptlk/f1/G;", "Ldbxyzptlk/Z0/c;", "Ldbxyzptlk/Z0/a;", "connection", "Ldbxyzptlk/Z0/b;", "dispatcher", "<init>", "(Ldbxyzptlk/Z0/a;Ldbxyzptlk/Z0/b;)V", "i", "()Ldbxyzptlk/Z0/c;", "node", "Ldbxyzptlk/pI/D;", "k", "(Ldbxyzptlk/Z0/c;)V", "", "hashCode", "()I", "", "other", "", "equals", "(Ljava/lang/Object;)Z", "b", "Ldbxyzptlk/Z0/a;", "getConnection", "()Ldbxyzptlk/Z0/a;", "c", "Ldbxyzptlk/Z0/b;", "getDispatcher", "()Ldbxyzptlk/Z0/b;", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
final class NestedScrollElement extends G<c> {
  public final a b;
  
  public final b c;
  
  public NestedScrollElement(a parama, b paramb) {
    this.b = parama;
    this.c = paramb;
  }
  
  public boolean equals(Object paramObject) {
    if (!(paramObject instanceof NestedScrollElement))
      return false; 
    paramObject = paramObject;
    return !s.c(((NestedScrollElement)paramObject).b, this.b) ? false : (!!s.c(((NestedScrollElement)paramObject).c, this.c));
  }
  
  public int hashCode() {
    byte b1;
    int i = this.b.hashCode();
    b b2 = this.c;
    if (b2 != null) {
      b1 = b2.hashCode();
    } else {
      b1 = 0;
    } 
    return i * 31 + b1;
  }
  
  public c i() {
    return new c(this.b, this.c);
  }
  
  public void k(c paramc) {
    paramc.r2(this.b, this.c);
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compos\\ui\input\nestedscroll\NestedScrollElement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */