package androidx.compose.ui.input.key;

import androidx.compose.ui.d;
import dbxyzptlk.CI.l;
import dbxyzptlk.DI.s;
import dbxyzptlk.Y0.b;
import dbxyzptlk.Y0.f;
import dbxyzptlk.f1.G;
import kotlin.Metadata;

@Metadata(d1 = {"\000<\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\013\n\002\b\007\n\002\030\002\n\002\b\002\n\002\020\016\n\002\b\002\n\002\020\b\n\002\b\002\n\002\020\000\n\002\b\n\b\b\030\0002\b\022\004\022\0020\0020\001B3\022\024\020\006\032\020\022\004\022\0020\004\022\004\022\0020\005\030\0010\003\022\024\020\007\032\020\022\004\022\0020\004\022\004\022\0020\005\030\0010\003¢\006\004\b\b\020\tJ\017\020\n\032\0020\002H\026¢\006\004\b\n\020\013J\027\020\016\032\0020\r2\006\020\f\032\0020\002H\026¢\006\004\b\016\020\017J\020\020\021\032\0020\020HÖ\001¢\006\004\b\021\020\022J\020\020\024\032\0020\023HÖ\001¢\006\004\b\024\020\025J\032\020\030\032\0020\0052\b\020\027\032\004\030\0010\026HÖ\003¢\006\004\b\030\020\031R%\020\006\032\020\022\004\022\0020\004\022\004\022\0020\005\030\0010\0038\006¢\006\f\n\004\b\032\020\033\032\004\b\034\020\035R%\020\007\032\020\022\004\022\0020\004\022\004\022\0020\005\030\0010\0038\006¢\006\f\n\004\b\036\020\033\032\004\b\037\020\035¨\006 "}, d2 = {"Landroidx/compose/ui/input/key/KeyInputElement;", "Ldbxyzptlk/f1/G;", "Ldbxyzptlk/Y0/f;", "Lkotlin/Function1;", "Ldbxyzptlk/Y0/b;", "", "onKeyEvent", "onPreKeyEvent", "<init>", "(Ldbxyzptlk/CI/l;Ldbxyzptlk/CI/l;)V", "i", "()Ldbxyzptlk/Y0/f;", "node", "Ldbxyzptlk/pI/D;", "k", "(Ldbxyzptlk/Y0/f;)V", "", "toString", "()Ljava/lang/String;", "", "hashCode", "()I", "", "other", "equals", "(Ljava/lang/Object;)Z", "b", "Ldbxyzptlk/CI/l;", "getOnKeyEvent", "()Ldbxyzptlk/CI/l;", "c", "getOnPreKeyEvent", "ui_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
final class KeyInputElement extends G<f> {
  public final l<b, Boolean> b;
  
  public final l<b, Boolean> c;
  
  public KeyInputElement(l<? super b, Boolean> paraml1, l<? super b, Boolean> paraml2) {
    this.b = (l)paraml1;
    this.c = (l)paraml2;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof KeyInputElement))
      return false; 
    paramObject = paramObject;
    return !s.c(this.b, ((KeyInputElement)paramObject).b) ? false : (!!s.c(this.c, ((KeyInputElement)paramObject).c));
  }
  
  public int hashCode() {
    int i;
    l<b, Boolean> l1 = this.b;
    int j = 0;
    if (l1 == null) {
      i = 0;
    } else {
      i = l1.hashCode();
    } 
    l1 = this.c;
    if (l1 != null)
      j = l1.hashCode(); 
    return i * 31 + j;
  }
  
  public f i() {
    return new f(this.b, this.c);
  }
  
  public void k(f paramf) {
    paramf.k2(this.b);
    paramf.l2(this.c);
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("KeyInputElement(onKeyEvent=");
    stringBuilder.append(this.b);
    stringBuilder.append(", onPreKeyEvent=");
    stringBuilder.append(this.c);
    stringBuilder.append(')');
    return stringBuilder.toString();
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compos\\ui\input\key\KeyInputElement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */