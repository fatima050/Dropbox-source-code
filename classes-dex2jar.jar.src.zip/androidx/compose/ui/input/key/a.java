package androidx.compose.ui.input.key;

import androidx.compose.ui.d;
import dbxyzptlk.CI.l;
import dbxyzptlk.Y0.b;
import kotlin.Metadata;

@Metadata(d1 = {"\000\024\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\013\n\002\b\006\032%\020\005\032\0020\000*\0020\0002\022\020\004\032\016\022\004\022\0020\002\022\004\022\0020\0030\001¢\006\004\b\005\020\006\032%\020\b\032\0020\000*\0020\0002\022\020\007\032\016\022\004\022\0020\002\022\004\022\0020\0030\001¢\006\004\b\b\020\006¨\006\t"}, d2 = {"Landroidx/compose/ui/d;", "Lkotlin/Function1;", "Ldbxyzptlk/Y0/b;", "", "onKeyEvent", "a", "(Landroidx/compose/ui/d;Ldbxyzptlk/CI/l;)Landroidx/compose/ui/d;", "onPreviewKeyEvent", "b", "ui_release"}, k = 2, mv = {1, 8, 0}, xi = 48)
public final class a {
  public static final d a(d paramd, l<? super b, Boolean> paraml) {
    return paramd.g((d)new KeyInputElement(paraml, null));
  }
  
  public static final d b(d paramd, l<? super b, Boolean> paraml) {
    return paramd.g((d)new KeyInputElement(null, paraml));
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compos\\ui\input\key\a.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */