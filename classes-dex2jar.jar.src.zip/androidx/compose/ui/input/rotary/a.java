package androidx.compose.ui.input.rotary;

import androidx.compose.ui.d;
import dbxyzptlk.CI.l;
import dbxyzptlk.c1.c;
import kotlin.Metadata;

@Metadata(d1 = {"\000\024\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\013\n\002\b\004\032%\020\005\032\0020\000*\0020\0002\022\020\004\032\016\022\004\022\0020\002\022\004\022\0020\0030\001¢\006\004\b\005\020\006¨\006\007"}, d2 = {"Landroidx/compose/ui/d;", "Lkotlin/Function1;", "Ldbxyzptlk/c1/c;", "", "onRotaryScrollEvent", "a", "(Landroidx/compose/ui/d;Ldbxyzptlk/CI/l;)Landroidx/compose/ui/d;", "ui_release"}, k = 2, mv = {1, 8, 0}, xi = 48)
public final class a {
  public static final d a(d paramd, l<? super c, Boolean> paraml) {
    return paramd.g((d)new RotaryInputElement(paraml, null));
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compos\\ui\input\rotary\a.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */