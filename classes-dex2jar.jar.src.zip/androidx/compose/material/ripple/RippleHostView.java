package androidx.compose.material.ripple;

import android.content.Context;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.view.animation.AnimationUtils;
import dbxyzptlk.CI.a;
import dbxyzptlk.DI.s;
import dbxyzptlk.GI.c;
import dbxyzptlk.P0.f;
import dbxyzptlk.P0.l;
import dbxyzptlk.f0.p;
import dbxyzptlk.pI.D;
import dbxyzptlk.w0.j;
import dbxyzptlk.w0.p;
import kotlin.Metadata;

@Metadata(d1 = {"\000j\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\003\n\002\020\013\n\000\n\002\030\002\n\002\b\002\n\002\020\b\n\002\b\r\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\020\007\n\000\n\002\030\002\n\002\b\007\n\002\030\002\n\002\b\004\n\002\020\t\n\002\b\002\n\002\030\002\n\002\b\004\b\000\030\000 +2\0020\001:\0010B\017\022\006\020\003\032\0020\002¢\006\004\b\004\020\005J\027\020\t\032\0020\b2\006\020\007\032\0020\006H\002¢\006\004\b\t\020\nJ\037\020\016\032\0020\b2\006\020\f\032\0020\0132\006\020\r\032\0020\013H\024¢\006\004\b\016\020\017J7\020\025\032\0020\b2\006\020\020\032\0020\0062\006\020\021\032\0020\0132\006\020\022\032\0020\0132\006\020\023\032\0020\0132\006\020\024\032\0020\013H\024¢\006\004\b\025\020\026J\017\020\027\032\0020\bH\026¢\006\004\b\027\020\030J\027\020\033\032\0020\b2\006\020\032\032\0020\031H\026¢\006\004\b\033\020\034JN\020\024\032\0020\b2\006\020\036\032\0020\0352\006\020\037\032\0020\0062\006\020!\032\0020 2\006\020\"\032\0020\0132\006\020$\032\0020#2\006\020&\032\0020%2\f\020(\032\b\022\004\022\0020\b0'ø\001\000¢\006\004\b\024\020)J\r\020*\032\0020\b¢\006\004\b*\020\030J0\020+\032\0020\b2\006\020!\032\0020 2\006\020\"\032\0020\0132\006\020$\032\0020#2\006\020&\032\0020%ø\001\000¢\006\004\b+\020,J\r\020-\032\0020\b¢\006\004\b-\020\030J\027\020.\032\0020\b2\006\020\037\032\0020\006H\002¢\006\004\b.\020\nR\030\0202\032\004\030\0010/8\002@\002X\016¢\006\006\n\004\b0\0201R\030\020\037\032\004\030\0010\0068\002@\002X\016¢\006\006\n\004\b\024\0203R\030\0206\032\004\030\001048\002@\002X\016¢\006\006\n\004\b.\0205R\030\0209\032\004\030\001078\002@\002X\016¢\006\006\n\004\b-\0208R\036\020(\032\n\022\004\022\0020\b\030\0010'8\002@\002X\016¢\006\006\n\004\b*\020:\002\007\n\005\b¡\0360\001¨\006;"}, d2 = {"Landroidx/compose/material/ripple/RippleHostView;", "Landroid/view/View;", "Landroid/content/Context;", "context", "<init>", "(Landroid/content/Context;)V", "", "pressed", "Ldbxyzptlk/pI/D;", "setRippleState", "(Z)V", "", "widthMeasureSpec", "heightMeasureSpec", "onMeasure", "(II)V", "changed", "l", "t", "r", "b", "onLayout", "(ZIIII)V", "refreshDrawableState", "()V", "Landroid/graphics/drawable/Drawable;", "who", "invalidateDrawable", "(Landroid/graphics/drawable/Drawable;)V", "Ldbxyzptlk/f0/p;", "interaction", "bounded", "Ldbxyzptlk/P0/l;", "size", "radius", "Ldbxyzptlk/Q0/r0;", "color", "", "alpha", "Lkotlin/Function0;", "onInvalidateRipple", "(Ldbxyzptlk/f0/p;ZJIJFLdbxyzptlk/CI/a;)V", "e", "f", "(JIJF)V", "d", "c", "Ldbxyzptlk/w0/p;", "a", "Ldbxyzptlk/w0/p;", "ripple", "Ljava/lang/Boolean;", "", "Ljava/lang/Long;", "lastRippleStateChangeTimeMillis", "Ljava/lang/Runnable;", "Ljava/lang/Runnable;", "resetRippleRunnable", "Ldbxyzptlk/CI/a;", "material-ripple_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class RippleHostView extends View {
  public static final a f = new a(null);
  
  public static final int g = 8;
  
  public static final int[] h = new int[] { 16842919, 16842910 };
  
  public static final int[] i = new int[0];
  
  public p a;
  
  public Boolean b;
  
  public Long c;
  
  public Runnable d;
  
  public a<D> e;
  
  public RippleHostView(Context paramContext) {
    super(paramContext);
  }
  
  private final void setRippleState(boolean paramBoolean) {
    long l1;
    long l2 = AnimationUtils.currentAnimationTimeMillis();
    Runnable runnable = this.d;
    if (runnable != null) {
      removeCallbacks(runnable);
      runnable.run();
    } 
    Long long_ = this.c;
    if (long_ != null) {
      l1 = long_.longValue();
    } else {
      l1 = 0L;
    } 
    if (!paramBoolean && l2 - l1 < 5L) {
      j j = new j(this);
      this.d = (Runnable)j;
      postDelayed((Runnable)j, 50L);
    } else {
      int[] arrayOfInt;
      if (paramBoolean) {
        arrayOfInt = h;
      } else {
        arrayOfInt = i;
      } 
      p p1 = this.a;
      if (p1 != null)
        p1.setState(arrayOfInt); 
    } 
    this.c = Long.valueOf(l2);
  }
  
  private static final void setRippleState$lambda$2(RippleHostView paramRippleHostView) {
    p p1 = paramRippleHostView.a;
    if (p1 != null)
      p1.setState(i); 
    paramRippleHostView.d = null;
  }
  
  public final void b(p paramp, boolean paramBoolean, long paramLong1, int paramInt, long paramLong2, float paramFloat, a<D> parama) {
    if (this.a == null || !s.c(Boolean.valueOf(paramBoolean), this.b)) {
      c(paramBoolean);
      this.b = Boolean.valueOf(paramBoolean);
    } 
    p p1 = this.a;
    s.e(p1);
    this.e = parama;
    f(paramLong1, paramInt, paramLong2, paramFloat);
    if (paramBoolean) {
      p1.setHotspot(f.o(paramp.a()), f.p(paramp.a()));
    } else {
      p1.setHotspot(p1.getBounds().centerX(), p1.getBounds().centerY());
    } 
    setRippleState(true);
  }
  
  public final void c(boolean paramBoolean) {
    p p1 = new p(paramBoolean);
    setBackground((Drawable)p1);
    this.a = p1;
  }
  
  public final void d() {
    this.e = null;
    Runnable runnable = this.d;
    if (runnable != null) {
      removeCallbacks(runnable);
      runnable = this.d;
      s.e(runnable);
      runnable.run();
    } else {
      p p2 = this.a;
      if (p2 != null)
        p2.setState(i); 
    } 
    p p1 = this.a;
    if (p1 == null)
      return; 
    p1.setVisible(false, false);
    unscheduleDrawable((Drawable)p1);
  }
  
  public final void e() {
    setRippleState(false);
  }
  
  public final void f(long paramLong1, int paramInt, long paramLong2, float paramFloat) {
    p p1 = this.a;
    if (p1 == null)
      return; 
    p1.c(paramInt);
    p1.b(paramLong2, paramFloat);
    Rect rect = new Rect(0, 0, c.d(l.i(paramLong1)), c.d(l.g(paramLong1)));
    setLeft(rect.left);
    setTop(rect.top);
    setRight(rect.right);
    setBottom(rect.bottom);
    p1.setBounds(rect);
  }
  
  public void invalidateDrawable(Drawable paramDrawable) {
    a<D> a1 = this.e;
    if (a1 != null)
      a1.invoke(); 
  }
  
  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
  
  public void onMeasure(int paramInt1, int paramInt2) {
    setMeasuredDimension(0, 0);
  }
  
  public void refreshDrawableState() {}
  
  class RippleHostView {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compose\material\ripple\RippleHostView.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */