package androidx.compose.runtime;

import android.annotation.SuppressLint;
import android.os.Parcel;
import android.os.Parcelable;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

@Metadata(d1 = {"\000(\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\t\n\002\b\003\n\002\030\002\n\000\n\002\020\b\n\000\n\002\030\002\n\002\b\007\b\001\030\000 \0202\0020\0012\0020\002:\001\021B\017\022\006\020\004\032\0020\003¢\006\004\b\005\020\006J\037\020\f\032\0020\0132\006\020\b\032\0020\0072\006\020\n\032\0020\tH\026¢\006\004\b\f\020\rJ\017\020\016\032\0020\tH\026¢\006\004\b\016\020\017¨\006\022"}, d2 = {"Landroidx/compose/runtime/ParcelableSnapshotMutableLongState;", "Landroidx/compose/runtime/c;", "Landroid/os/Parcelable;", "", "value", "<init>", "(J)V", "Landroid/os/Parcel;", "parcel", "", "flags", "Ldbxyzptlk/pI/D;", "writeToParcel", "(Landroid/os/Parcel;I)V", "describeContents", "()I", "c", "b", "runtime_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
@SuppressLint({"BanParcelableUsage"})
public final class ParcelableSnapshotMutableLongState extends c implements Parcelable {
  public static final Parcelable.Creator<ParcelableSnapshotMutableLongState> CREATOR;
  
  public static final b c = new b(null);
  
  static {
    CREATOR = new a();
  }
  
  public ParcelableSnapshotMutableLongState(long paramLong) {
    super(paramLong);
  }
  
  public int describeContents() {
    return 0;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    paramParcel.writeLong(d());
  }
  
  @Metadata(d1 = {"\000#\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\003\n\002\020\b\n\000\n\002\020\021\n\002\b\003*\001\000\b\n\030\0002\b\022\004\022\0020\0020\001J\027\020\005\032\0020\0022\006\020\004\032\0020\003H\026¢\006\004\b\005\020\006J\037\020\n\032\n\022\006\022\004\030\0010\0020\t2\006\020\b\032\0020\007H\026¢\006\004\b\n\020\013¨\006\f"}, d2 = {"androidx/compose/runtime/ParcelableSnapshotMutableLongState$a", "Landroid/os/Parcelable$Creator;", "Landroidx/compose/runtime/ParcelableSnapshotMutableLongState;", "Landroid/os/Parcel;", "parcel", "a", "(Landroid/os/Parcel;)Landroidx/compose/runtime/ParcelableSnapshotMutableLongState;", "", "size", "", "b", "(I)[Landroidx/compose/runtime/ParcelableSnapshotMutableLongState;", "runtime_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class a implements Parcelable.Creator<ParcelableSnapshotMutableLongState> {
    public ParcelableSnapshotMutableLongState a(Parcel param1Parcel) {
      return new ParcelableSnapshotMutableLongState(param1Parcel.readLong());
    }
    
    public ParcelableSnapshotMutableLongState[] b(int param1Int) {
      return new ParcelableSnapshotMutableLongState[param1Int];
    }
  }
  
  @Metadata(d1 = {"\000\f\n\002\030\002\n\002\020\000\n\002\b\003\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003¨\006\004"}, d2 = {"Landroidx/compose/runtime/ParcelableSnapshotMutableLongState$b;", "", "<init>", "()V", "runtime_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class b {
    public b() {}
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compose\runtime\ParcelableSnapshotMutableLongState.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */