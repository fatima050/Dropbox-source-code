package androidx.compose.runtime;

import dbxyzptlk.DI.s;
import dbxyzptlk.I0.G;
import dbxyzptlk.I0.H;
import dbxyzptlk.I0.I;
import dbxyzptlk.I0.k;
import dbxyzptlk.I0.p;
import dbxyzptlk.I0.u;
import dbxyzptlk.pI.D;
import dbxyzptlk.x0.W0;
import dbxyzptlk.x0.X0;
import dbxyzptlk.x0.i0;
import kotlin.Metadata;

@Metadata(d1 = {"\000<\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\b\n\002\b\003\n\002\030\002\n\002\030\002\n\002\b\007\n\002\020\016\n\002\b\002\n\002\030\002\n\002\b\n\n\002\030\002\n\002\b\004\b\020\030\0002\0020\0012\0020\0022\b\022\004\022\0020\0040\003:\001\"B\017\022\006\020\005\032\0020\004¢\006\004\b\006\020\007J\027\020\n\032\0020\t2\006\020\005\032\0020\bH\026¢\006\004\b\n\020\013J)\020\017\032\004\030\0010\b2\006\020\f\032\0020\b2\006\020\r\032\0020\b2\006\020\016\032\0020\bH\026¢\006\004\b\017\020\020J\017\020\022\032\0020\021H\026¢\006\004\b\022\020\023R\026\020\027\032\0020\0248\002@\002X\016¢\006\006\n\004\b\025\020\026R\024\020\032\032\0020\b8VX\004¢\006\006\032\004\b\030\020\031R$\020\036\032\0020\0042\006\020\005\032\0020\0048V@VX\016¢\006\f\032\004\b\033\020\034\"\004\b\035\020\007R\032\020!\032\b\022\004\022\0020\0040\0378VX\004¢\006\006\032\004\b\025\020 ¨\006#"}, d2 = {"Landroidx/compose/runtime/b;", "Ldbxyzptlk/I0/H;", "Ldbxyzptlk/x0/i0;", "Ldbxyzptlk/I0/u;", "", "value", "<init>", "(I)V", "Ldbxyzptlk/I0/I;", "Ldbxyzptlk/pI/D;", "w", "(Ldbxyzptlk/I0/I;)V", "previous", "current", "applied", "p", "(Ldbxyzptlk/I0/I;Ldbxyzptlk/I0/I;Ldbxyzptlk/I0/I;)Ldbxyzptlk/I0/I;", "", "toString", "()Ljava/lang/String;", "Landroidx/compose/runtime/b$a;", "b", "Landroidx/compose/runtime/b$a;", "next", "x", "()Ldbxyzptlk/I0/I;", "firstStateRecord", "c", "()I", "f", "intValue", "Ldbxyzptlk/x0/W0;", "()Ldbxyzptlk/x0/W0;", "policy", "a", "runtime_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public class b extends H implements i0, u<Integer> {
  public a b;
  
  public b(int paramInt) {
    this.b = new a(paramInt);
  }
  
  public W0<Integer> b() {
    return X0.s();
  }
  
  public int c() {
    return ((a)p.X(this.b, (G)this)).h();
  }
  
  public void f(int paramInt) {
    a a1 = (a)p.F(this.b);
    if (a1.h() != paramInt) {
      a a2 = this.b;
      p.J();
      synchronized (p.I()) {
        k k = k.e.d();
        ((a)p.S(a2, (G)this, k, a1)).i(paramInt);
        D d = D.a;
        p.Q(k, (G)this);
      } 
    } 
  }
  
  public I p(I paramI1, I paramI2, I paramI3) {
    s.f(paramI2, "null cannot be cast to non-null type androidx.compose.runtime.SnapshotMutableIntStateImpl.IntStateStateRecord");
    paramI1 = paramI2;
    s.f(paramI3, "null cannot be cast to non-null type androidx.compose.runtime.SnapshotMutableIntStateImpl.IntStateStateRecord");
    paramI3 = paramI3;
    if (paramI1.h() != paramI3.h())
      paramI2 = null; 
    return paramI2;
  }
  
  public String toString() {
    a a1 = (a)p.F(this.b);
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("MutableIntState(value=");
    stringBuilder.append(a1.h());
    stringBuilder.append(")@");
    stringBuilder.append(hashCode());
    return stringBuilder.toString();
  }
  
  public void w(I paramI) {
    s.f(paramI, "null cannot be cast to non-null type androidx.compose.runtime.SnapshotMutableIntStateImpl.IntStateStateRecord");
    this.b = (a)paramI;
  }
  
  public I x() {
    return this.b;
  }
  
  @Metadata(d1 = {"\000\030\n\002\030\002\n\002\030\002\n\002\020\b\n\002\b\003\n\002\030\002\n\002\b\t\b\002\030\0002\0020\001B\017\022\006\020\003\032\0020\002¢\006\004\b\004\020\005J\027\020\007\032\0020\0062\006\020\003\032\0020\001H\026¢\006\004\b\007\020\bJ\017\020\t\032\0020\001H\026¢\006\004\b\t\020\nR\"\020\003\032\0020\0028\006@\006X\016¢\006\022\n\004\b\t\020\013\032\004\b\f\020\r\"\004\b\016\020\005¨\006\017"}, d2 = {"Landroidx/compose/runtime/b$a;", "Ldbxyzptlk/I0/I;", "", "value", "<init>", "(I)V", "Ldbxyzptlk/pI/D;", "b", "(Ldbxyzptlk/I0/I;)V", "c", "()Ldbxyzptlk/I0/I;", "I", "h", "()I", "i", "runtime_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class a extends I {
    public int c;
    
    public a(int param1Int) {
      this.c = param1Int;
    }
    
    public void b(I param1I) {
      s.f(param1I, "null cannot be cast to non-null type androidx.compose.runtime.SnapshotMutableIntStateImpl.IntStateStateRecord");
      this.c = ((a)param1I).c;
    }
    
    public I c() {
      return new a(this.c);
    }
    
    public final int h() {
      return this.c;
    }
    
    public final void i(int param1Int) {
      this.c = param1Int;
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compose\runtime\b.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */