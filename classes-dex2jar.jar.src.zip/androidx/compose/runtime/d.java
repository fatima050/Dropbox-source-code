package androidx.compose.runtime;

import dbxyzptlk.DI.s;
import dbxyzptlk.I0.G;
import dbxyzptlk.I0.H;
import dbxyzptlk.I0.I;
import dbxyzptlk.I0.k;
import dbxyzptlk.I0.p;
import dbxyzptlk.I0.u;
import dbxyzptlk.pI.D;
import dbxyzptlk.x0.W0;
import kotlin.Metadata;

@Metadata(d1 = {"\0004\n\002\030\002\n\000\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\030\002\n\002\030\002\n\002\b\007\n\002\020\016\n\002\b\005\n\002\030\002\n\002\b\016\b\020\030\000*\004\b\000\020\0012\0020\0022\b\022\004\022\0028\0000\003:\001%B\035\022\006\020\004\032\0028\000\022\f\020\006\032\b\022\004\022\0028\0000\005¢\006\004\b\007\020\bJ\027\020\013\032\0020\n2\006\020\004\032\0020\tH\026¢\006\004\b\013\020\fJ)\020\020\032\004\030\0010\t2\006\020\r\032\0020\t2\006\020\016\032\0020\t2\006\020\017\032\0020\tH\026¢\006\004\b\020\020\021J\017\020\023\032\0020\022H\026¢\006\004\b\023\020\024R \020\006\032\b\022\004\022\0028\0000\0058\026X\004¢\006\f\n\004\b\025\020\026\032\004\b\025\020\027R\034\020\033\032\b\022\004\022\0028\0000\0308\002@\002X\016¢\006\006\n\004\b\031\020\032R*\020\004\032\0028\0002\006\020\004\032\0028\0008V@VX\016¢\006\022\022\004\b \020!\032\004\b\034\020\035\"\004\b\036\020\037R\024\020$\032\0020\t8VX\004¢\006\006\032\004\b\"\020#¨\006&"}, d2 = {"Landroidx/compose/runtime/d;", "T", "Ldbxyzptlk/I0/H;", "Ldbxyzptlk/I0/u;", "value", "Ldbxyzptlk/x0/W0;", "policy", "<init>", "(Ljava/lang/Object;Ldbxyzptlk/x0/W0;)V", "Ldbxyzptlk/I0/I;", "Ldbxyzptlk/pI/D;", "w", "(Ldbxyzptlk/I0/I;)V", "previous", "current", "applied", "p", "(Ldbxyzptlk/I0/I;Ldbxyzptlk/I0/I;Ldbxyzptlk/I0/I;)Ldbxyzptlk/I0/I;", "", "toString", "()Ljava/lang/String;", "b", "Ldbxyzptlk/x0/W0;", "()Ldbxyzptlk/x0/W0;", "Landroidx/compose/runtime/d$a;", "c", "Landroidx/compose/runtime/d$a;", "next", "getValue", "()Ljava/lang/Object;", "setValue", "(Ljava/lang/Object;)V", "getValue$annotations", "()V", "x", "()Ldbxyzptlk/I0/I;", "firstStateRecord", "a", "runtime_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public class d<T> extends H implements u<T> {
  public final W0<T> b;
  
  public a<T> c;
  
  public d(T paramT, W0<T> paramW0) {
    this.b = paramW0;
    this.c = new a<>(paramT);
  }
  
  public W0<T> b() {
    return this.b;
  }
  
  public T getValue() {
    return ((a<T>)p.X(this.c, (G)this)).h();
  }
  
  public I p(I paramI1, I paramI2, I paramI3) {
    s.f(paramI1, "null cannot be cast to non-null type androidx.compose.runtime.SnapshotMutableStateImpl.StateStateRecord<T of androidx.compose.runtime.SnapshotMutableStateImpl>");
    paramI1 = paramI1;
    s.f(paramI2, "null cannot be cast to non-null type androidx.compose.runtime.SnapshotMutableStateImpl.StateStateRecord<T of androidx.compose.runtime.SnapshotMutableStateImpl>");
    a a1 = (a)paramI2;
    s.f(paramI3, "null cannot be cast to non-null type androidx.compose.runtime.SnapshotMutableStateImpl.StateStateRecord<T of androidx.compose.runtime.SnapshotMutableStateImpl>");
    paramI3 = paramI3;
    if (!b().a(a1.h(), paramI3.h())) {
      Object object = b().b(paramI1.h(), a1.h(), paramI3.h());
      if (object != null) {
        paramI2 = paramI3.c();
        s.f(paramI2, "null cannot be cast to non-null type androidx.compose.runtime.SnapshotMutableStateImpl.StateStateRecord<T of androidx.compose.runtime.SnapshotMutableStateImpl.mergeRecords$lambda$2>");
        ((a<Object>)paramI2).i(object);
      } else {
        paramI2 = null;
      } 
    } 
    return paramI2;
  }
  
  public void setValue(T paramT) {
    a a1 = (a)p.F(this.c);
    if (!b().a(a1.h(), paramT)) {
      a<T> a2 = this.c;
      p.J();
      synchronized (p.I()) {
        k k = k.e.d();
        ((a<T>)p.S(a2, (G)this, k, a1)).i(paramT);
        D d1 = D.a;
        p.Q(k, (G)this);
      } 
    } 
  }
  
  public String toString() {
    a a1 = (a)p.F(this.c);
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("MutableState(value=");
    stringBuilder.append(a1.h());
    stringBuilder.append(")@");
    stringBuilder.append(hashCode());
    return stringBuilder.toString();
  }
  
  public void w(I paramI) {
    s.f(paramI, "null cannot be cast to non-null type androidx.compose.runtime.SnapshotMutableStateImpl.StateStateRecord<T of androidx.compose.runtime.SnapshotMutableStateImpl>");
    this.c = (a<T>)paramI;
  }
  
  public I x() {
    return this.c;
  }
  
  @Metadata(d1 = {"\000\026\n\002\030\002\n\000\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\t\b\002\030\000*\004\b\001\020\0012\0020\002B\017\022\006\020\003\032\0028\001¢\006\004\b\004\020\005J\027\020\b\032\0020\0072\006\020\006\032\0020\002H\026¢\006\004\b\b\020\tJ\017\020\n\032\0020\002H\026¢\006\004\b\n\020\013R\"\020\006\032\0028\0018\006@\006X\016¢\006\022\n\004\b\n\020\f\032\004\b\r\020\016\"\004\b\017\020\005¨\006\020"}, d2 = {"Landroidx/compose/runtime/d$a;", "T", "Ldbxyzptlk/I0/I;", "myValue", "<init>", "(Ljava/lang/Object;)V", "value", "Ldbxyzptlk/pI/D;", "b", "(Ldbxyzptlk/I0/I;)V", "c", "()Ldbxyzptlk/I0/I;", "Ljava/lang/Object;", "h", "()Ljava/lang/Object;", "i", "runtime_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class a<T> extends I {
    public T c;
    
    public a(T param1T) {
      this.c = param1T;
    }
    
    public void b(I param1I) {
      s.f(param1I, "null cannot be cast to non-null type androidx.compose.runtime.SnapshotMutableStateImpl.StateStateRecord<T of androidx.compose.runtime.SnapshotMutableStateImpl.StateStateRecord>");
      this.c = ((a)param1I).c;
    }
    
    public I c() {
      return new a(this.c);
    }
    
    public final T h() {
      return this.c;
    }
    
    public final void i(T param1T) {
      this.c = param1T;
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compose\runtime\d.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */