package androidx.compose.runtime;

import android.annotation.SuppressLint;
import android.os.Parcel;
import android.os.Parcelable;
import dbxyzptlk.DI.s;
import dbxyzptlk.x0.W0;
import dbxyzptlk.x0.X0;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

@Metadata(d1 = {"\000,\n\002\030\002\n\000\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\030\002\n\000\n\002\020\b\n\000\n\002\030\002\n\002\b\007\b\001\030\000 \022*\004\b\000\020\0012\b\022\004\022\0028\0000\0022\0020\003:\001\023B\035\022\006\020\004\032\0028\000\022\f\020\006\032\b\022\004\022\0028\0000\005¢\006\004\b\007\020\bJ\037\020\016\032\0020\r2\006\020\n\032\0020\t2\006\020\f\032\0020\013H\026¢\006\004\b\016\020\017J\017\020\020\032\0020\013H\026¢\006\004\b\020\020\021¨\006\024"}, d2 = {"Landroidx/compose/runtime/ParcelableSnapshotMutableState;", "T", "Landroidx/compose/runtime/d;", "Landroid/os/Parcelable;", "value", "Ldbxyzptlk/x0/W0;", "policy", "<init>", "(Ljava/lang/Object;Ldbxyzptlk/x0/W0;)V", "Landroid/os/Parcel;", "parcel", "", "flags", "Ldbxyzptlk/pI/D;", "writeToParcel", "(Landroid/os/Parcel;I)V", "describeContents", "()I", "d", "b", "runtime_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
@SuppressLint({"BanParcelableUsage"})
public final class ParcelableSnapshotMutableState<T> extends d<T> implements Parcelable {
  public static final Parcelable.Creator<ParcelableSnapshotMutableState<Object>> CREATOR;
  
  public static final b d = new b(null);
  
  static {
    CREATOR = (Parcelable.Creator<ParcelableSnapshotMutableState<Object>>)new a();
  }
  
  public ParcelableSnapshotMutableState(T paramT, W0<T> paramW0) {
    super(paramT, paramW0);
  }
  
  public int describeContents() {
    return 0;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    paramParcel.writeValue(getValue());
    W0<T> w0 = b();
    if (s.c(w0, X0.k())) {
      paramInt = 0;
    } else if (s.c(w0, X0.s())) {
      paramInt = 1;
    } else if (s.c(w0, X0.p())) {
      paramInt = 2;
    } else {
      throw new IllegalStateException("Only known types of MutableState's SnapshotMutationPolicy are supported");
    } 
    paramParcel.writeInt(paramInt);
  }
  
  @Metadata(d1 = {"\000-\n\000\n\002\030\002\n\002\030\002\n\002\020\000\n\002\030\002\n\000\n\002\030\002\n\002\b\005\n\002\020\b\n\000\n\002\020\021\n\002\b\003*\001\000\b\n\030\0002\020\022\f\022\n\022\006\022\004\030\0010\0030\0020\001J)\020\b\032\n\022\006\022\004\030\0010\0030\0022\006\020\005\032\0020\0042\b\020\007\032\004\030\0010\006H\026¢\006\004\b\b\020\tJ\037\020\n\032\n\022\006\022\004\030\0010\0030\0022\006\020\005\032\0020\004H\026¢\006\004\b\n\020\013J'\020\017\032\022\022\016\022\f\022\006\022\004\030\0010\003\030\0010\0020\0162\006\020\r\032\0020\fH\026¢\006\004\b\017\020\020¨\006\021"}, d2 = {"androidx/compose/runtime/ParcelableSnapshotMutableState$a", "Landroid/os/Parcelable$ClassLoaderCreator;", "Landroidx/compose/runtime/ParcelableSnapshotMutableState;", "", "Landroid/os/Parcel;", "parcel", "Ljava/lang/ClassLoader;", "loader", "b", "(Landroid/os/Parcel;Ljava/lang/ClassLoader;)Landroidx/compose/runtime/ParcelableSnapshotMutableState;", "a", "(Landroid/os/Parcel;)Landroidx/compose/runtime/ParcelableSnapshotMutableState;", "", "size", "", "c", "(I)[Landroidx/compose/runtime/ParcelableSnapshotMutableState;", "runtime_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class a implements Parcelable.ClassLoaderCreator<ParcelableSnapshotMutableState<Object>> {
    public ParcelableSnapshotMutableState<Object> a(Parcel param1Parcel) {
      return b(param1Parcel, null);
    }
    
    public ParcelableSnapshotMutableState<Object> b(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      W0 w0;
      ClassLoader classLoader = param1ClassLoader;
      if (param1ClassLoader == null)
        classLoader = a.class.getClassLoader(); 
      Object object = param1Parcel.readValue(classLoader);
      int i = param1Parcel.readInt();
      if (i != 0) {
        if (i != 1) {
          if (i == 2) {
            w0 = X0.p();
          } else {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Unsupported MutableState policy ");
            stringBuilder.append(i);
            stringBuilder.append(" was restored");
            throw new IllegalStateException(stringBuilder.toString());
          } 
        } else {
          w0 = X0.s();
        } 
      } else {
        w0 = X0.k();
      } 
      return new ParcelableSnapshotMutableState(object, w0);
    }
    
    public ParcelableSnapshotMutableState<Object>[] c(int param1Int) {
      return (ParcelableSnapshotMutableState<Object>[])new ParcelableSnapshotMutableState[param1Int];
    }
  }
  
  @Metadata(d1 = {"\000\024\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\b\n\002\b\005\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003R\024\020\005\032\0020\0048\002XT¢\006\006\n\004\b\005\020\006R\024\020\007\032\0020\0048\002XT¢\006\006\n\004\b\007\020\006R\024\020\b\032\0020\0048\002XT¢\006\006\n\004\b\b\020\006¨\006\t"}, d2 = {"Landroidx/compose/runtime/ParcelableSnapshotMutableState$b;", "", "<init>", "()V", "", "PolicyNeverEquals", "I", "PolicyReferentialEquality", "PolicyStructuralEquality", "runtime_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class b {
    public b() {}
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compose\runtime\ParcelableSnapshotMutableState.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */