package androidx.compose.foundation;

import androidx.compose.ui.c;
import dbxyzptlk.CI.a;
import dbxyzptlk.CI.l;
import dbxyzptlk.CI.p;
import dbxyzptlk.CI.q;
import dbxyzptlk.bK.K;
import dbxyzptlk.c0.E;
import dbxyzptlk.c0.G;
import dbxyzptlk.d0.v;
import dbxyzptlk.f0.k;
import dbxyzptlk.f0.m;
import dbxyzptlk.g1.p0;
import dbxyzptlk.l1.i;
import dbxyzptlk.pI.D;
import dbxyzptlk.uI.c;
import kotlin.Metadata;

@Metadata(d1 = {"\000B\n\002\030\002\n\002\020\013\n\000\n\002\020\016\n\000\n\002\030\002\n\000\n\002\030\002\n\002\030\002\n\002\b\003\n\002\030\002\n\000\n\002\030\002\n\002\b\n\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\005\032D\020\n\032\0020\000*\0020\0002\b\b\002\020\002\032\0020\0012\n\b\002\020\004\032\004\030\0010\0032\n\b\002\020\006\032\004\030\0010\0052\f\020\t\032\b\022\004\022\0020\b0\007ø\001\000¢\006\004\b\n\020\013\032V\020\020\032\0020\000*\0020\0002\006\020\r\032\0020\f2\b\020\017\032\004\030\0010\0162\b\b\002\020\002\032\0020\0012\n\b\002\020\004\032\004\030\0010\0032\n\b\002\020\006\032\004\030\0010\0052\f\020\t\032\b\022\004\022\0020\b0\007ø\001\000¢\006\004\b\020\020\021\032v\020\025\032\0020\000*\0020\0002\b\b\002\020\002\032\0020\0012\n\b\002\020\004\032\004\030\0010\0032\n\b\002\020\006\032\004\030\0010\0052\n\b\002\020\022\032\004\030\0010\0032\020\b\002\020\023\032\n\022\004\022\0020\b\030\0010\0072\020\b\002\020\024\032\n\022\004\022\0020\b\030\0010\0072\f\020\t\032\b\022\004\022\0020\b0\007H\007ø\001\000¢\006\004\b\025\020\026\032\001\020\027\032\0020\000*\0020\0002\006\020\r\032\0020\f2\b\020\017\032\004\030\0010\0162\b\b\002\020\002\032\0020\0012\n\b\002\020\004\032\004\030\0010\0032\n\b\002\020\006\032\004\030\0010\0052\n\b\002\020\022\032\004\030\0010\0032\020\b\002\020\023\032\n\022\004\022\0020\b\030\0010\0072\020\b\002\020\024\032\n\022\004\022\0020\b\030\0010\0072\f\020\t\032\b\022\004\022\0020\b0\007H\007ø\001\000¢\006\004\b\027\020\030\032=\020\037\032\0020\b*\0020\0312\006\020\033\032\0020\0322\006\020\r\032\0020\f2\006\020\035\032\0020\0342\f\020\036\032\b\022\004\022\0020\0010\007H@ø\001\000¢\006\004\b\037\020 \002\007\n\005\b¡\0360\001¨\006!"}, d2 = {"Landroidx/compose/ui/d;", "", "enabled", "", "onClickLabel", "Ldbxyzptlk/l1/i;", "role", "Lkotlin/Function0;", "Ldbxyzptlk/pI/D;", "onClick", "d", "(Landroidx/compose/ui/d;ZLjava/lang/String;Ldbxyzptlk/l1/i;Ldbxyzptlk/CI/a;)Landroidx/compose/ui/d;", "Ldbxyzptlk/f0/m;", "interactionSource", "Ldbxyzptlk/c0/E;", "indication", "b", "(Landroidx/compose/ui/d;Ldbxyzptlk/f0/m;Ldbxyzptlk/c0/E;ZLjava/lang/String;Ldbxyzptlk/l1/i;Ldbxyzptlk/CI/a;)Landroidx/compose/ui/d;", "onLongClickLabel", "onLongClick", "onDoubleClick", "h", "(Landroidx/compose/ui/d;ZLjava/lang/String;Ldbxyzptlk/l1/i;Ljava/lang/String;Ldbxyzptlk/CI/a;Ldbxyzptlk/CI/a;Ldbxyzptlk/CI/a;)Landroidx/compose/ui/d;", "f", "(Landroidx/compose/ui/d;Ldbxyzptlk/f0/m;Ldbxyzptlk/c0/E;ZLjava/lang/String;Ldbxyzptlk/l1/i;Ljava/lang/String;Ldbxyzptlk/CI/a;Ldbxyzptlk/CI/a;Ldbxyzptlk/CI/a;)Landroidx/compose/ui/d;", "Ldbxyzptlk/d0/v;", "Ldbxyzptlk/P0/f;", "pressPoint", "Landroidx/compose/foundation/a$a;", "interactionData", "delayPressInteraction", "j", "(Ldbxyzptlk/d0/v;JLdbxyzptlk/f0/m;Landroidx/compose/foundation/a$a;Ldbxyzptlk/CI/a;Ldbxyzptlk/tI/d;)Ljava/lang/Object;", "foundation_release"}, k = 2, mv = {1, 8, 0}, xi = 48)
public final class d {
  public static final androidx.compose.ui.d b(androidx.compose.ui.d paramd, m paramm, E paramE, boolean paramBoolean, String paramString, i parami, a<D> parama) {
    l l;
    if (p0.c()) {
      b b = new b(paramm, paramE, paramBoolean, paramString, parami, parama);
    } else {
      l = p0.a();
    } 
    return p0.b(paramd, l, FocusableKt.c(i.a(G.b((androidx.compose.ui.d)androidx.compose.ui.d.a, (k)paramm, paramE), paramm, paramBoolean), paramBoolean, paramm).g((androidx.compose.ui.d)new ClickableElement(paramm, paramBoolean, paramString, parami, parama, null)));
  }
  
  public static final androidx.compose.ui.d d(androidx.compose.ui.d paramd, boolean paramBoolean, String paramString, i parami, a<D> parama) {
    l l;
    if (p0.c()) {
      c c = new c(paramBoolean, paramString, parami, parama);
    } else {
      l = p0.a();
    } 
    return c.a(paramd, l, (q)new a(paramBoolean, paramString, parami, parama));
  }
  
  public static final androidx.compose.ui.d f(androidx.compose.ui.d paramd, m paramm, E paramE, boolean paramBoolean, String paramString1, i parami, String paramString2, a<D> parama1, a<D> parama2, a<D> parama3) {
    l l;
    if (p0.c()) {
      e e = new e(paramE, paramm, paramBoolean, paramString1, parami, parama3, parama2, parama1, paramString2);
    } else {
      l = p0.a();
    } 
    return p0.b(paramd, l, FocusableKt.c(i.a(G.b((androidx.compose.ui.d)androidx.compose.ui.d.a, (k)paramm, paramE), paramm, paramBoolean), paramBoolean, paramm).g((androidx.compose.ui.d)new CombinedClickableElement(paramm, paramBoolean, paramString1, parami, parama3, paramString2, parama1, parama2, null)));
  }
  
  public static final androidx.compose.ui.d h(androidx.compose.ui.d paramd, boolean paramBoolean, String paramString1, i parami, String paramString2, a<D> parama1, a<D> parama2, a<D> parama3) {
    l l;
    if (p0.c()) {
      f f = new f(paramBoolean, paramString1, parami, parama3, parama2, parama1, paramString2);
    } else {
      l = p0.a();
    } 
    return c.a(paramd, l, (q)new d(paramBoolean, paramString1, parami, paramString2, parama1, parama2, parama3));
  }
  
  public static final Object j(v paramv, long paramLong, m paramm, a.a parama, a<Boolean> parama1, dbxyzptlk.tI.d<? super D> paramd) {
    Object object = K.g((p)new g(paramv, paramLong, paramm, parama, parama1, null), paramd);
    return (object == c.g()) ? object : D.a;
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compose\foundation\d.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */