package androidx.compose.foundation;

import androidx.compose.ui.d;
import dbxyzptlk.f0.m;
import kotlin.Metadata;

@Metadata(d1 = {"\000\022\n\002\030\002\n\002\030\002\n\000\n\002\020\013\n\002\b\004\032#\020\005\032\0020\000*\0020\0002\006\020\002\032\0020\0012\b\b\002\020\004\032\0020\003¢\006\004\b\005\020\006¨\006\007"}, d2 = {"Landroidx/compose/ui/d;", "Ldbxyzptlk/f0/m;", "interactionSource", "", "enabled", "a", "(Landroidx/compose/ui/d;Ldbxyzptlk/f0/m;Z)Landroidx/compose/ui/d;", "foundation_release"}, k = 2, mv = {1, 8, 0}, xi = 48)
public final class i {
  public static final d a(d paramd, m paramm, boolean paramBoolean) {
    d.a a;
    if (paramBoolean) {
      HoverableElement hoverableElement = new HoverableElement(paramm);
    } else {
      a = d.a;
    } 
    return paramd.g((d)a);
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compose\foundation\i.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */