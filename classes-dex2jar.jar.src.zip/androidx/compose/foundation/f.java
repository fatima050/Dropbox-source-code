package androidx.compose.foundation;

import dbxyzptlk.CI.a;
import dbxyzptlk.CI.l;
import dbxyzptlk.CI.q;
import dbxyzptlk.P0.g;
import dbxyzptlk.a1.J;
import dbxyzptlk.d0.H;
import dbxyzptlk.f0.m;
import dbxyzptlk.pI.D;
import dbxyzptlk.tI.d;
import dbxyzptlk.uI.c;
import dbxyzptlk.z1.n;
import dbxyzptlk.z1.s;
import kotlin.Metadata;

@Metadata(d1 = {"\000.\n\002\030\002\n\002\030\002\n\002\020\013\n\000\n\002\030\002\n\000\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\005\b\002\030\0002\0020\001B-\022\006\020\003\032\0020\002\022\006\020\005\032\0020\004\022\f\020\b\032\b\022\004\022\0020\0070\006\022\006\020\n\032\0020\t¢\006\004\b\013\020\fJ\024\020\016\032\0020\007*\0020\rH@¢\006\004\b\016\020\017J+\020\020\032\0020\0072\006\020\003\032\0020\0022\006\020\005\032\0020\0042\f\020\b\032\b\022\004\022\0020\0070\006¢\006\004\b\020\020\021¨\006\022"}, d2 = {"Landroidx/compose/foundation/f;", "Landroidx/compose/foundation/b;", "", "enabled", "Ldbxyzptlk/f0/m;", "interactionSource", "Lkotlin/Function0;", "Ldbxyzptlk/pI/D;", "onClick", "Landroidx/compose/foundation/a$a;", "interactionData", "<init>", "(ZLdbxyzptlk/f0/m;Ldbxyzptlk/CI/a;Landroidx/compose/foundation/a$a;)V", "Ldbxyzptlk/a1/J;", "t2", "(Ldbxyzptlk/a1/J;Ldbxyzptlk/tI/d;)Ljava/lang/Object;", "x2", "(ZLdbxyzptlk/f0/m;Ldbxyzptlk/CI/a;)V", "foundation_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class f extends b {
  public f(boolean paramBoolean, m paramm, a<D> parama, a.a parama1) {
    super(paramBoolean, paramm, parama, parama1, null);
  }
  
  public Object t2(J paramJ, d<? super D> paramd) {
    a.a a = q2();
    long l = s.b(paramJ.a());
    a.d(g.a(n.j(l), n.k(l)));
    Object object = H.h(paramJ, (q)new a(this, null), (l)new b(this), paramd);
    return (object == c.g()) ? object : D.a;
  }
  
  public final void x2(boolean paramBoolean, m paramm, a<D> parama) {
    u2(paramBoolean);
    w2(parama);
    v2(paramm);
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compose\foundation\f.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */