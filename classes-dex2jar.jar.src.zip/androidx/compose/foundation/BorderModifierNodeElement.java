package androidx.compose.foundation;

import androidx.compose.ui.d;
import dbxyzptlk.DI.s;
import dbxyzptlk.Q0.a1;
import dbxyzptlk.Q0.h0;
import dbxyzptlk.c0.g;
import dbxyzptlk.f1.G;
import dbxyzptlk.z1.h;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

@Metadata(d1 = {"\000F\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\006\n\002\030\002\n\002\b\002\n\002\020\016\n\002\b\002\n\002\020\b\n\002\b\002\n\002\020\000\n\000\n\002\020\013\n\002\b\017\b\b\030\0002\b\022\004\022\0020\0020\001B\037\022\006\020\004\032\0020\003\022\006\020\006\032\0020\005\022\006\020\b\032\0020\007¢\006\004\b\t\020\nJ\017\020\013\032\0020\002H\026¢\006\004\b\013\020\fJ\027\020\017\032\0020\0162\006\020\r\032\0020\002H\026¢\006\004\b\017\020\020J\020\020\022\032\0020\021HÖ\001¢\006\004\b\022\020\023J\020\020\025\032\0020\024HÖ\001¢\006\004\b\025\020\026J\032\020\032\032\0020\0312\b\020\030\032\004\030\0010\027HÖ\003¢\006\004\b\032\020\033R\035\020\004\032\0020\0038\006ø\001\000ø\001\001¢\006\f\n\004\b\034\020\035\032\004\b\036\020\037R\027\020\006\032\0020\0058\006¢\006\f\n\004\b \020!\032\004\b\"\020#R\027\020\b\032\0020\0078\006¢\006\f\n\004\b$\020%\032\004\b&\020'\002\013\n\005\b¡\0360\001\n\002\b!¨\006("}, d2 = {"Landroidx/compose/foundation/BorderModifierNodeElement;", "Ldbxyzptlk/f1/G;", "Ldbxyzptlk/c0/g;", "Ldbxyzptlk/z1/h;", "width", "Ldbxyzptlk/Q0/h0;", "brush", "Ldbxyzptlk/Q0/a1;", "shape", "<init>", "(FLdbxyzptlk/Q0/h0;Ldbxyzptlk/Q0/a1;Lkotlin/jvm/internal/DefaultConstructorMarker;)V", "i", "()Ldbxyzptlk/c0/g;", "node", "Ldbxyzptlk/pI/D;", "k", "(Ldbxyzptlk/c0/g;)V", "", "toString", "()Ljava/lang/String;", "", "hashCode", "()I", "", "other", "", "equals", "(Ljava/lang/Object;)Z", "b", "F", "getWidth-D9Ej5fM", "()F", "c", "Ldbxyzptlk/Q0/h0;", "getBrush", "()Ldbxyzptlk/Q0/h0;", "d", "Ldbxyzptlk/Q0/a1;", "getShape", "()Ldbxyzptlk/Q0/a1;", "foundation_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class BorderModifierNodeElement extends G<g> {
  public final float b;
  
  public final h0 c;
  
  public final a1 d;
  
  public BorderModifierNodeElement(float paramFloat, h0 paramh0, a1 parama1) {
    this.b = paramFloat;
    this.c = paramh0;
    this.d = parama1;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof BorderModifierNodeElement))
      return false; 
    paramObject = paramObject;
    return !h.v(this.b, ((BorderModifierNodeElement)paramObject).b) ? false : (!s.c(this.c, ((BorderModifierNodeElement)paramObject).c) ? false : (!!s.c(this.d, ((BorderModifierNodeElement)paramObject).d)));
  }
  
  public int hashCode() {
    return (h.x(this.b) * 31 + this.c.hashCode()) * 31 + this.d.hashCode();
  }
  
  public g i() {
    return new g(this.b, this.c, this.d, null);
  }
  
  public void k(g paramg) {
    paramg.x2(this.b);
    paramg.w2(this.c);
    paramg.Z0(this.d);
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("BorderModifierNodeElement(width=");
    stringBuilder.append(h.A(this.b));
    stringBuilder.append(", brush=");
    stringBuilder.append(this.c);
    stringBuilder.append(", shape=");
    stringBuilder.append(this.d);
    stringBuilder.append(')');
    return stringBuilder.toString();
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compose\foundation\BorderModifierNodeElement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */