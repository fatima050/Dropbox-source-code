package androidx.compose.foundation.layout;

import androidx.compose.ui.d;
import dbxyzptlk.CI.l;
import dbxyzptlk.DI.s;
import dbxyzptlk.f1.G;
import dbxyzptlk.g0.L;
import dbxyzptlk.g1.r0;
import dbxyzptlk.pI.D;
import dbxyzptlk.z1.d;
import dbxyzptlk.z1.n;
import kotlin.Metadata;

@Metadata(d1 = {"\000D\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\020\013\n\000\n\002\030\002\n\002\030\002\n\002\b\b\n\002\020\000\n\002\b\003\n\002\020\016\n\002\b\002\n\002\020\b\n\002\b\r\b\002\030\0002\b\022\004\022\0020\0020\001B7\022\022\020\006\032\016\022\004\022\0020\004\022\004\022\0020\0050\003\022\006\020\b\032\0020\007\022\022\020\013\032\016\022\004\022\0020\t\022\004\022\0020\n0\003¢\006\004\b\f\020\rJ\017\020\016\032\0020\002H\026¢\006\004\b\016\020\017J\027\020\021\032\0020\n2\006\020\020\032\0020\002H\026¢\006\004\b\021\020\022J\032\020\025\032\0020\0072\b\020\024\032\004\030\0010\023H\002¢\006\004\b\025\020\026J\017\020\030\032\0020\027H\026¢\006\004\b\030\020\031J\017\020\033\032\0020\032H\026¢\006\004\b\033\020\034R#\020\006\032\016\022\004\022\0020\004\022\004\022\0020\0050\0038\006¢\006\f\n\004\b\035\020\036\032\004\b\037\020 R\027\020\b\032\0020\0078\006¢\006\f\n\004\b!\020\"\032\004\b#\020$R#\020\013\032\016\022\004\022\0020\t\022\004\022\0020\n0\0038\006¢\006\f\n\004\b%\020\036\032\004\b&\020 ¨\006'"}, d2 = {"Landroidx/compose/foundation/layout/OffsetPxElement;", "Ldbxyzptlk/f1/G;", "Ldbxyzptlk/g0/L;", "Lkotlin/Function1;", "Ldbxyzptlk/z1/d;", "Ldbxyzptlk/z1/n;", "offset", "", "rtlAware", "Ldbxyzptlk/g1/r0;", "Ldbxyzptlk/pI/D;", "inspectorInfo", "<init>", "(Ldbxyzptlk/CI/l;ZLdbxyzptlk/CI/l;)V", "i", "()Ldbxyzptlk/g0/L;", "node", "k", "(Ldbxyzptlk/g0/L;)V", "", "other", "equals", "(Ljava/lang/Object;)Z", "", "toString", "()Ljava/lang/String;", "", "hashCode", "()I", "b", "Ldbxyzptlk/CI/l;", "getOffset", "()Ldbxyzptlk/CI/l;", "c", "Z", "getRtlAware", "()Z", "d", "getInspectorInfo", "foundation-layout_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
final class OffsetPxElement extends G<L> {
  public final l<d, n> b;
  
  public final boolean c;
  
  public final l<r0, D> d;
  
  public OffsetPxElement(l<? super d, n> paraml, boolean paramBoolean, l<? super r0, D> paraml1) {
    this.b = (l)paraml;
    this.c = paramBoolean;
    this.d = (l)paraml1;
  }
  
  public boolean equals(Object paramObject) {
    boolean bool = true;
    if (this == paramObject)
      return true; 
    if (paramObject instanceof OffsetPxElement) {
      paramObject = paramObject;
    } else {
      paramObject = null;
    } 
    if (paramObject == null)
      return false; 
    if (!s.c(this.b, ((OffsetPxElement)paramObject).b) || this.c != ((OffsetPxElement)paramObject).c)
      bool = false; 
    return bool;
  }
  
  public int hashCode() {
    return this.b.hashCode() * 31 + Boolean.hashCode(this.c);
  }
  
  public L i() {
    return new L(this.b, this.c);
  }
  
  public void k(L paramL) {
    paramL.m2(this.b);
    paramL.n2(this.c);
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("OffsetPxModifier(offset=");
    stringBuilder.append(this.b);
    stringBuilder.append(", rtlAware=");
    stringBuilder.append(this.c);
    stringBuilder.append(')');
    return stringBuilder.toString();
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compose\foundation\layout\OffsetPxElement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */