package androidx.compose.foundation.layout;

import androidx.compose.ui.d;
import dbxyzptlk.f1.G;
import dbxyzptlk.g0.q;
import dbxyzptlk.g0.s;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

@Metadata(d1 = {"\000>\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\020\007\n\000\n\002\020\016\n\002\b\006\n\002\030\002\n\002\b\002\n\002\020\000\n\000\n\002\020\013\n\002\b\002\n\002\020\b\n\002\b\013\b\002\030\000 \0372\b\022\004\022\0020\0020\001:\001 B\037\022\006\020\004\032\0020\003\022\006\020\006\032\0020\005\022\006\020\b\032\0020\007¢\006\004\b\t\020\nJ\017\020\013\032\0020\002H\026¢\006\004\b\013\020\fJ\027\020\017\032\0020\0162\006\020\r\032\0020\002H\026¢\006\004\b\017\020\020J\032\020\024\032\0020\0232\b\020\022\032\004\030\0010\021H\002¢\006\004\b\024\020\025J\017\020\027\032\0020\026H\026¢\006\004\b\027\020\030R\024\020\004\032\0020\0038\002X\004¢\006\006\n\004\b\031\020\032R\024\020\006\032\0020\0058\002X\004¢\006\006\n\004\b\033\020\034R\024\020\b\032\0020\0078\002X\004¢\006\006\n\004\b\035\020\036¨\006!"}, d2 = {"Landroidx/compose/foundation/layout/FillElement;", "Ldbxyzptlk/f1/G;", "Ldbxyzptlk/g0/s;", "Ldbxyzptlk/g0/q;", "direction", "", "fraction", "", "inspectorName", "<init>", "(Ldbxyzptlk/g0/q;FLjava/lang/String;)V", "i", "()Ldbxyzptlk/g0/s;", "node", "Ldbxyzptlk/pI/D;", "k", "(Ldbxyzptlk/g0/s;)V", "", "other", "", "equals", "(Ljava/lang/Object;)Z", "", "hashCode", "()I", "b", "Ldbxyzptlk/g0/q;", "c", "F", "d", "Ljava/lang/String;", "e", "a", "foundation-layout_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
final class FillElement extends G<s> {
  public static final a e = new a(null);
  
  public final q b;
  
  public final float c;
  
  public final String d;
  
  public FillElement(q paramq, float paramFloat, String paramString) {
    this.b = paramq;
    this.c = paramFloat;
    this.d = paramString;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof FillElement))
      return false; 
    q q1 = this.b;
    paramObject = paramObject;
    return (q1 != ((FillElement)paramObject).b) ? false : ((this.c == ((FillElement)paramObject).c));
  }
  
  public int hashCode() {
    return this.b.hashCode() * 31 + Float.hashCode(this.c);
  }
  
  public s i() {
    return new s(this.b, this.c);
  }
  
  public void k(s params) {
    params.k2(this.b);
    params.l2(this.c);
  }
  
  @Metadata(d1 = {"\000\032\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\007\n\000\n\002\030\002\n\002\b\005\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\027\020\007\032\0020\0062\006\020\005\032\0020\004H\007¢\006\004\b\007\020\bJ\027\020\t\032\0020\0062\006\020\005\032\0020\004H\007¢\006\004\b\t\020\bJ\027\020\n\032\0020\0062\006\020\005\032\0020\004H\007¢\006\004\b\n\020\b¨\006\013"}, d2 = {"Landroidx/compose/foundation/layout/FillElement$a;", "", "<init>", "()V", "", "fraction", "Landroidx/compose/foundation/layout/FillElement;", "c", "(F)Landroidx/compose/foundation/layout/FillElement;", "a", "b", "foundation-layout_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class a {
    public a() {}
    
    public final FillElement a(float param1Float) {
      return new FillElement(q.Vertical, param1Float, "fillMaxHeight");
    }
    
    public final FillElement b(float param1Float) {
      return new FillElement(q.Both, param1Float, "fillMaxSize");
    }
    
    public final FillElement c(float param1Float) {
      return new FillElement(q.Horizontal, param1Float, "fillMaxWidth");
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compose\foundation\layout\FillElement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */