package androidx.compose.foundation.layout;

import androidx.compose.ui.d;
import dbxyzptlk.CI.l;
import dbxyzptlk.f1.G;
import dbxyzptlk.g0.b0;
import dbxyzptlk.g1.r0;
import dbxyzptlk.pI.D;
import dbxyzptlk.z1.h;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

@Metadata(d1 = {"\000:\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\004\n\002\020\013\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\b\n\002\020\000\n\002\b\003\n\002\020\b\n\002\b\f\b\002\030\0002\b\022\004\022\0020\0020\001BK\022\b\b\002\020\004\032\0020\003\022\b\b\002\020\005\032\0020\003\022\b\b\002\020\006\032\0020\003\022\b\b\002\020\007\032\0020\003\022\006\020\t\032\0020\b\022\022\020\r\032\016\022\004\022\0020\013\022\004\022\0020\f0\n¢\006\004\b\016\020\017J\017\020\020\032\0020\002H\026¢\006\004\b\020\020\021J\027\020\023\032\0020\f2\006\020\022\032\0020\002H\026¢\006\004\b\023\020\024J\032\020\027\032\0020\b2\b\020\026\032\004\030\0010\025H\002¢\006\004\b\027\020\030J\017\020\032\032\0020\031H\026¢\006\004\b\032\020\033R\032\020\004\032\0020\0038\002X\004ø\001\000ø\001\001¢\006\006\n\004\b\034\020\035R\032\020\005\032\0020\0038\002X\004ø\001\000ø\001\001¢\006\006\n\004\b\036\020\035R\032\020\006\032\0020\0038\002X\004ø\001\000ø\001\001¢\006\006\n\004\b\037\020\035R\032\020\007\032\0020\0038\002X\004ø\001\000ø\001\001¢\006\006\n\004\b \020\035R\024\020\t\032\0020\b8\002X\004¢\006\006\n\004\b!\020\"R \020\r\032\016\022\004\022\0020\013\022\004\022\0020\f0\n8\002X\004¢\006\006\n\004\b#\020$\002\013\n\005\b¡\0360\001\n\002\b!¨\006%"}, d2 = {"Landroidx/compose/foundation/layout/SizeElement;", "Ldbxyzptlk/f1/G;", "Ldbxyzptlk/g0/b0;", "Ldbxyzptlk/z1/h;", "minWidth", "minHeight", "maxWidth", "maxHeight", "", "enforceIncoming", "Lkotlin/Function1;", "Ldbxyzptlk/g1/r0;", "Ldbxyzptlk/pI/D;", "inspectorInfo", "<init>", "(FFFFZLdbxyzptlk/CI/l;Lkotlin/jvm/internal/DefaultConstructorMarker;)V", "i", "()Ldbxyzptlk/g0/b0;", "node", "k", "(Ldbxyzptlk/g0/b0;)V", "", "other", "equals", "(Ljava/lang/Object;)Z", "", "hashCode", "()I", "b", "F", "c", "d", "e", "f", "Z", "g", "Ldbxyzptlk/CI/l;", "foundation-layout_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
final class SizeElement extends G<b0> {
  public final float b;
  
  public final float c;
  
  public final float d;
  
  public final float e;
  
  public final boolean f;
  
  public final l<r0, D> g;
  
  public SizeElement(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, boolean paramBoolean, l<? super r0, D> paraml) {
    this.b = paramFloat1;
    this.c = paramFloat2;
    this.d = paramFloat3;
    this.e = paramFloat4;
    this.f = paramBoolean;
    this.g = (l)paraml;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof SizeElement))
      return false; 
    float f = this.b;
    paramObject = paramObject;
    return !h.v(f, ((SizeElement)paramObject).b) ? false : (!h.v(this.c, ((SizeElement)paramObject).c) ? false : (!h.v(this.d, ((SizeElement)paramObject).d) ? false : (!h.v(this.e, ((SizeElement)paramObject).e) ? false : (!(this.f != ((SizeElement)paramObject).f)))));
  }
  
  public int hashCode() {
    return (((h.x(this.b) * 31 + h.x(this.c)) * 31 + h.x(this.d)) * 31 + h.x(this.e)) * 31 + Boolean.hashCode(this.f);
  }
  
  public b0 i() {
    return new b0(this.b, this.c, this.d, this.e, this.f, null);
  }
  
  public void k(b0 paramb0) {
    paramb0.p2(this.b);
    paramb0.o2(this.c);
    paramb0.n2(this.d);
    paramb0.m2(this.e);
    paramb0.l2(this.f);
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compose\foundation\layout\SizeElement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */