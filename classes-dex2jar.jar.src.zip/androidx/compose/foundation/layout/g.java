package androidx.compose.foundation.layout;

import androidx.compose.ui.d;
import dbxyzptlk.CI.l;
import dbxyzptlk.DI.s;
import dbxyzptlk.K0.c;
import dbxyzptlk.g1.p0;
import dbxyzptlk.z1.h;
import dbxyzptlk.z1.k;
import kotlin.Metadata;

@Metadata(d1 = {"\000J\n\002\030\002\n\002\030\002\n\002\b\t\n\002\030\002\n\002\b\022\n\002\020\007\n\002\b\004\n\002\030\002\n\000\n\002\020\013\n\002\b\003\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\013\032\036\020\003\032\0020\000*\0020\0002\006\020\002\032\0020\001H\007ø\001\000¢\006\004\b\003\020\004\032\036\020\006\032\0020\000*\0020\0002\006\020\005\032\0020\001H\007ø\001\000¢\006\004\b\006\020\004\032\036\020\b\032\0020\000*\0020\0002\006\020\007\032\0020\001H\007ø\001\000¢\006\004\b\b\020\004\032&\020\t\032\0020\000*\0020\0002\006\020\002\032\0020\0012\006\020\005\032\0020\001H\007ø\001\000¢\006\004\b\t\020\n\032\036\020\f\032\0020\000*\0020\0002\006\020\007\032\0020\013H\007ø\001\000¢\006\004\b\f\020\r\032*\020\020\032\0020\000*\0020\0002\b\b\002\020\016\032\0020\0012\b\b\002\020\017\032\0020\001H\007ø\001\000¢\006\004\b\020\020\n\032*\020\021\032\0020\000*\0020\0002\b\b\002\020\016\032\0020\0012\b\b\002\020\017\032\0020\001H\007ø\001\000¢\006\004\b\021\020\n\032>\020\026\032\0020\000*\0020\0002\b\b\002\020\022\032\0020\0012\b\b\002\020\023\032\0020\0012\b\b\002\020\024\032\0020\0012\b\b\002\020\025\032\0020\001H\007ø\001\000¢\006\004\b\026\020\027\032\036\020\030\032\0020\000*\0020\0002\006\020\002\032\0020\001H\007ø\001\000¢\006\004\b\030\020\004\032\036\020\031\032\0020\000*\0020\0002\006\020\005\032\0020\001H\007ø\001\000¢\006\004\b\031\020\004\032\036\020\032\032\0020\000*\0020\0002\006\020\007\032\0020\001H\007ø\001\000¢\006\004\b\032\020\004\032&\020\033\032\0020\000*\0020\0002\006\020\002\032\0020\0012\006\020\005\032\0020\001H\007ø\001\000¢\006\004\b\033\020\n\032*\020\034\032\0020\000*\0020\0002\b\b\002\020\016\032\0020\0012\b\b\002\020\017\032\0020\001H\007ø\001\000¢\006\004\b\034\020\n\032>\020\035\032\0020\000*\0020\0002\b\b\002\020\022\032\0020\0012\b\b\002\020\023\032\0020\0012\b\b\002\020\024\032\0020\0012\b\b\002\020\025\032\0020\001H\007ø\001\000¢\006\004\b\035\020\027\032\035\020 \032\0020\000*\0020\0002\b\b\003\020\037\032\0020\036H\007¢\006\004\b \020\004\032\035\020!\032\0020\000*\0020\0002\b\b\003\020\037\032\0020\036H\007¢\006\004\b!\020\004\032\035\020\"\032\0020\000*\0020\0002\b\b\003\020\037\032\0020\036H\007¢\006\004\b\"\020\004\032'\020'\032\0020\000*\0020\0002\b\b\002\020$\032\0020#2\b\b\002\020&\032\0020%H\007¢\006\004\b'\020(\032'\020*\032\0020\000*\0020\0002\b\b\002\020$\032\0020)2\b\b\002\020&\032\0020%H\007¢\006\004\b*\020+\032'\020-\032\0020\000*\0020\0002\b\b\002\020$\032\0020,2\b\b\002\020&\032\0020%H\007¢\006\004\b-\020.\032*\020/\032\0020\000*\0020\0002\b\b\002\020\022\032\0020\0012\b\b\002\020\023\032\0020\001H\007ø\001\000¢\006\004\b/\020\n\"\024\0202\032\002008\002X\004¢\006\006\n\004\b/\0201\"\024\0204\032\002008\002X\004¢\006\006\n\004\b3\0201\"\024\0205\032\002008\002X\004¢\006\006\n\004\b!\0201\"\024\0209\032\002068\002X\004¢\006\006\n\004\b7\0208\"\024\020:\032\002068\002X\004¢\006\006\n\004\b\"\0208\"\024\020<\032\002068\002X\004¢\006\006\n\004\b;\0208\"\024\020=\032\002068\002X\004¢\006\006\n\004\b \0208\"\024\020?\032\002068\002X\004¢\006\006\n\004\b>\0208\"\024\020@\032\002068\002X\004¢\006\006\n\004\b\006\0208\002\007\n\005\b¡\0360\001¨\006A"}, d2 = {"Landroidx/compose/ui/d;", "Ldbxyzptlk/z1/h;", "width", "y", "(Landroidx/compose/ui/d;F)Landroidx/compose/ui/d;", "height", "i", "size", "t", "v", "(Landroidx/compose/ui/d;FF)Landroidx/compose/ui/d;", "Ldbxyzptlk/z1/k;", "u", "(Landroidx/compose/ui/d;J)Landroidx/compose/ui/d;", "min", "max", "z", "j", "minWidth", "minHeight", "maxWidth", "maxHeight", "w", "(Landroidx/compose/ui/d;FFFF)Landroidx/compose/ui/d;", "s", "l", "o", "p", "m", "q", "", "fraction", "g", "c", "e", "Ldbxyzptlk/K0/c$b;", "align", "", "unbounded", "F", "(Landroidx/compose/ui/d;Ldbxyzptlk/K0/c$b;Z)Landroidx/compose/ui/d;", "Ldbxyzptlk/K0/c$c;", "B", "(Landroidx/compose/ui/d;Ldbxyzptlk/K0/c$c;Z)Landroidx/compose/ui/d;", "Ldbxyzptlk/K0/c;", "D", "(Landroidx/compose/ui/d;Ldbxyzptlk/K0/c;Z)Landroidx/compose/ui/d;", "a", "Landroidx/compose/foundation/layout/FillElement;", "Landroidx/compose/foundation/layout/FillElement;", "FillWholeMaxWidth", "b", "FillWholeMaxHeight", "FillWholeMaxSize", "Landroidx/compose/foundation/layout/WrapContentElement;", "d", "Landroidx/compose/foundation/layout/WrapContentElement;", "WrapContentWidthCenter", "WrapContentWidthStart", "f", "WrapContentHeightCenter", "WrapContentHeightTop", "h", "WrapContentSizeCenter", "WrapContentSizeTopStart", "foundation-layout_release"}, k = 2, mv = {1, 8, 0}, xi = 48)
public final class g {
  public static final FillElement a;
  
  public static final FillElement b;
  
  public static final FillElement c;
  
  public static final WrapContentElement d;
  
  public static final WrapContentElement e;
  
  public static final WrapContentElement f;
  
  public static final WrapContentElement g;
  
  public static final WrapContentElement h;
  
  public static final WrapContentElement i;
  
  static {
    FillElement.a a1 = FillElement.e;
    a = a1.c(1.0F);
    b = a1.a(1.0F);
    c = a1.b(1.0F);
    WrapContentElement.a a = WrapContentElement.g;
    c.a a2 = c.a;
    d = a.c(a2.g(), false);
    e = a.c(a2.k(), false);
    f = a.a(a2.i(), false);
    g = a.a(a2.l(), false);
    h = a.b(a2.e(), false);
    i = a.b(a2.o(), false);
  }
  
  public static final d B(d paramd, c.c paramc, boolean paramBoolean) {
    WrapContentElement wrapContentElement;
    c.a a = c.a;
    if (s.c(paramc, a.i()) && !paramBoolean) {
      wrapContentElement = f;
    } else if (s.c(wrapContentElement, a.l()) && !paramBoolean) {
      wrapContentElement = g;
    } else {
      wrapContentElement = WrapContentElement.g.a((c.c)wrapContentElement, paramBoolean);
    } 
    return paramd.g((d)wrapContentElement);
  }
  
  public static final d D(d paramd, c paramc, boolean paramBoolean) {
    WrapContentElement wrapContentElement;
    c.a a = c.a;
    if (s.c(paramc, a.e()) && !paramBoolean) {
      wrapContentElement = h;
    } else if (s.c(wrapContentElement, a.o()) && !paramBoolean) {
      wrapContentElement = i;
    } else {
      wrapContentElement = WrapContentElement.g.b((c)wrapContentElement, paramBoolean);
    } 
    return paramd.g((d)wrapContentElement);
  }
  
  public static final d F(d paramd, c.b paramb, boolean paramBoolean) {
    WrapContentElement wrapContentElement;
    c.a a = c.a;
    if (s.c(paramb, a.g()) && !paramBoolean) {
      wrapContentElement = d;
    } else if (s.c(wrapContentElement, a.k()) && !paramBoolean) {
      wrapContentElement = e;
    } else {
      wrapContentElement = WrapContentElement.g.c((c.b)wrapContentElement, paramBoolean);
    } 
    return paramd.g((d)wrapContentElement);
  }
  
  public static final d a(d paramd, float paramFloat1, float paramFloat2) {
    return paramd.g((d)new UnspecifiedConstraintsElement(paramFloat1, paramFloat2, null));
  }
  
  public static final d c(d paramd, float paramFloat) {
    FillElement fillElement;
    if (paramFloat == 1.0F) {
      fillElement = b;
    } else {
      fillElement = FillElement.e.a(paramFloat);
    } 
    return paramd.g((d)fillElement);
  }
  
  public static final d e(d paramd, float paramFloat) {
    FillElement fillElement;
    if (paramFloat == 1.0F) {
      fillElement = c;
    } else {
      fillElement = FillElement.e.b(paramFloat);
    } 
    return paramd.g((d)fillElement);
  }
  
  public static final d g(d paramd, float paramFloat) {
    FillElement fillElement;
    if (paramFloat == 1.0F) {
      fillElement = a;
    } else {
      fillElement = FillElement.e.c(paramFloat);
    } 
    return paramd.g((d)fillElement);
  }
  
  public static final d i(d paramd, float paramFloat) {
    l l;
    if (p0.c()) {
      a a = new a(paramFloat);
    } else {
      l = p0.a();
    } 
    return paramd.g((d)new SizeElement(0.0F, paramFloat, 0.0F, paramFloat, true, l, 5, null));
  }
  
  public static final d j(d paramd, float paramFloat1, float paramFloat2) {
    l l;
    if (p0.c()) {
      b b = new b(paramFloat1, paramFloat2);
    } else {
      l = p0.a();
    } 
    return paramd.g((d)new SizeElement(0.0F, paramFloat1, 0.0F, paramFloat2, true, l, 5, null));
  }
  
  public static final d l(d paramd, float paramFloat) {
    l l;
    if (p0.c()) {
      c c = new c(paramFloat);
    } else {
      l = p0.a();
    } 
    return paramd.g((d)new SizeElement(0.0F, paramFloat, 0.0F, paramFloat, false, l, 5, null));
  }
  
  public static final d m(d paramd, float paramFloat1, float paramFloat2) {
    l l;
    if (p0.c()) {
      d d1 = new d(paramFloat1, paramFloat2);
    } else {
      l = p0.a();
    } 
    return paramd.g((d)new SizeElement(0.0F, paramFloat1, 0.0F, paramFloat2, false, l, 5, null));
  }
  
  public static final d o(d paramd, float paramFloat) {
    l l;
    if (p0.c()) {
      e e = new e(paramFloat);
    } else {
      l = p0.a();
    } 
    return paramd.g((d)new SizeElement(paramFloat, paramFloat, paramFloat, paramFloat, false, l, null));
  }
  
  public static final d p(d paramd, float paramFloat1, float paramFloat2) {
    l l;
    if (p0.c()) {
      f f = new f(paramFloat1, paramFloat2);
    } else {
      l = p0.a();
    } 
    return paramd.g((d)new SizeElement(paramFloat1, paramFloat2, paramFloat1, paramFloat2, false, l, null));
  }
  
  public static final d q(d paramd, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    l l;
    if (p0.c()) {
      g g1 = new g(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
    } else {
      l = p0.a();
    } 
    return paramd.g((d)new SizeElement(paramFloat1, paramFloat2, paramFloat3, paramFloat4, false, l, null));
  }
  
  public static final d s(d paramd, float paramFloat) {
    l l;
    if (p0.c()) {
      h h = new h(paramFloat);
    } else {
      l = p0.a();
    } 
    return paramd.g((d)new SizeElement(paramFloat, 0.0F, paramFloat, 0.0F, false, l, 10, null));
  }
  
  public static final d t(d paramd, float paramFloat) {
    l l;
    if (p0.c()) {
      i i = new i(paramFloat);
    } else {
      l = p0.a();
    } 
    return paramd.g((d)new SizeElement(paramFloat, paramFloat, paramFloat, paramFloat, true, l, null));
  }
  
  public static final d u(d paramd, long paramLong) {
    return v(paramd, k.h(paramLong), k.g(paramLong));
  }
  
  public static final d v(d paramd, float paramFloat1, float paramFloat2) {
    l l;
    if (p0.c()) {
      j j = new j(paramFloat1, paramFloat2);
    } else {
      l = p0.a();
    } 
    return paramd.g((d)new SizeElement(paramFloat1, paramFloat2, paramFloat1, paramFloat2, true, l, null));
  }
  
  public static final d w(d paramd, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    l l;
    if (p0.c()) {
      k k = new k(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
    } else {
      l = p0.a();
    } 
    return paramd.g((d)new SizeElement(paramFloat1, paramFloat2, paramFloat3, paramFloat4, true, l, null));
  }
  
  public static final d y(d paramd, float paramFloat) {
    l l;
    if (p0.c()) {
      l l1 = new l(paramFloat);
    } else {
      l = p0.a();
    } 
    return paramd.g((d)new SizeElement(paramFloat, 0.0F, paramFloat, 0.0F, true, l, 10, null));
  }
  
  public static final d z(d paramd, float paramFloat1, float paramFloat2) {
    l l;
    if (p0.c()) {
      m m = new m(paramFloat1, paramFloat2);
    } else {
      l = p0.a();
    } 
    return paramd.g((d)new SizeElement(paramFloat1, 0.0F, paramFloat2, 0.0F, true, l, 10, null));
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compose\foundation\layout\g.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */