package androidx.compose.foundation.layout;

import androidx.compose.ui.d;
import dbxyzptlk.CI.l;
import dbxyzptlk.f1.G;
import dbxyzptlk.g0.N;
import dbxyzptlk.g1.r0;
import dbxyzptlk.pI.D;
import dbxyzptlk.z1.h;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

@Metadata(d1 = {"\000:\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\004\n\002\020\013\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\b\n\002\020\b\n\002\b\002\n\002\020\000\n\002\b\035\b\002\030\0002\b\022\004\022\0020\0020\001BK\022\b\b\002\020\004\032\0020\003\022\b\b\002\020\005\032\0020\003\022\b\b\002\020\006\032\0020\003\022\b\b\002\020\007\032\0020\003\022\006\020\t\032\0020\b\022\022\020\r\032\016\022\004\022\0020\013\022\004\022\0020\f0\n¢\006\004\b\016\020\017J\017\020\020\032\0020\002H\026¢\006\004\b\020\020\021J\027\020\023\032\0020\f2\006\020\022\032\0020\002H\026¢\006\004\b\023\020\024J\017\020\026\032\0020\025H\026¢\006\004\b\026\020\027J\032\020\032\032\0020\b2\b\020\031\032\004\030\0010\030H\002¢\006\004\b\032\020\033R(\020\004\032\0020\0038\006@\006X\016ø\001\000ø\001\001¢\006\022\n\004\b\034\020\035\032\004\b\036\020\037\"\004\b \020!R(\020\005\032\0020\0038\006@\006X\016ø\001\000ø\001\001¢\006\022\n\004\b\"\020\035\032\004\b#\020\037\"\004\b$\020!R(\020\006\032\0020\0038\006@\006X\016ø\001\000ø\001\001¢\006\022\n\004\b%\020\035\032\004\b&\020\037\"\004\b'\020!R(\020\007\032\0020\0038\006@\006X\016ø\001\000ø\001\001¢\006\022\n\004\b(\020\035\032\004\b)\020\037\"\004\b*\020!R\"\020\t\032\0020\b8\006@\006X\016¢\006\022\n\004\b+\020,\032\004\b-\020.\"\004\b/\0200R#\020\r\032\016\022\004\022\0020\013\022\004\022\0020\f0\n8\006¢\006\f\n\004\b1\0202\032\004\b3\0204\002\013\n\005\b¡\0360\001\n\002\b!¨\0065"}, d2 = {"Landroidx/compose/foundation/layout/PaddingElement;", "Ldbxyzptlk/f1/G;", "Ldbxyzptlk/g0/N;", "Ldbxyzptlk/z1/h;", "start", "top", "end", "bottom", "", "rtlAware", "Lkotlin/Function1;", "Ldbxyzptlk/g1/r0;", "Ldbxyzptlk/pI/D;", "inspectorInfo", "<init>", "(FFFFZLdbxyzptlk/CI/l;Lkotlin/jvm/internal/DefaultConstructorMarker;)V", "i", "()Ldbxyzptlk/g0/N;", "node", "k", "(Ldbxyzptlk/g0/N;)V", "", "hashCode", "()I", "", "other", "equals", "(Ljava/lang/Object;)Z", "b", "F", "getStart-D9Ej5fM", "()F", "setStart-0680j_4", "(F)V", "c", "getTop-D9Ej5fM", "setTop-0680j_4", "d", "getEnd-D9Ej5fM", "setEnd-0680j_4", "e", "getBottom-D9Ej5fM", "setBottom-0680j_4", "f", "Z", "getRtlAware", "()Z", "setRtlAware", "(Z)V", "g", "Ldbxyzptlk/CI/l;", "getInspectorInfo", "()Ldbxyzptlk/CI/l;", "foundation-layout_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
final class PaddingElement extends G<N> {
  public float b;
  
  public float c;
  
  public float d;
  
  public float e;
  
  public boolean f;
  
  public final l<r0, D> g;
  
  public PaddingElement(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, boolean paramBoolean, l<? super r0, D> paraml) {
    this.b = paramFloat1;
    this.c = paramFloat2;
    this.d = paramFloat3;
    this.e = paramFloat4;
    this.f = paramBoolean;
    this.g = (l)paraml;
    if (paramFloat1 >= 0.0F || h.v(paramFloat1, h.b.c())) {
      paramFloat1 = this.c;
      if (paramFloat1 >= 0.0F || h.v(paramFloat1, h.b.c())) {
        paramFloat1 = this.d;
        if (paramFloat1 >= 0.0F || h.v(paramFloat1, h.b.c())) {
          paramFloat1 = this.e;
          if (paramFloat1 >= 0.0F || h.v(paramFloat1, h.b.c()))
            return; 
        } 
      } 
    } 
    throw new IllegalArgumentException("Padding must be non-negative");
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject instanceof PaddingElement) {
      paramObject = paramObject;
    } else {
      paramObject = null;
    } 
    boolean bool2 = false;
    if (paramObject == null)
      return false; 
    boolean bool1 = bool2;
    if (h.v(this.b, ((PaddingElement)paramObject).b)) {
      bool1 = bool2;
      if (h.v(this.c, ((PaddingElement)paramObject).c)) {
        bool1 = bool2;
        if (h.v(this.d, ((PaddingElement)paramObject).d)) {
          bool1 = bool2;
          if (h.v(this.e, ((PaddingElement)paramObject).e)) {
            bool1 = bool2;
            if (this.f == ((PaddingElement)paramObject).f)
              bool1 = true; 
          } 
        } 
      } 
    } 
    return bool1;
  }
  
  public int hashCode() {
    return (((h.x(this.b) * 31 + h.x(this.c)) * 31 + h.x(this.d)) * 31 + h.x(this.e)) * 31 + Boolean.hashCode(this.f);
  }
  
  public N i() {
    return new N(this.b, this.c, this.d, this.e, this.f, null);
  }
  
  public void k(N paramN) {
    paramN.q2(this.b);
    paramN.r2(this.c);
    paramN.o2(this.d);
    paramN.n2(this.e);
    paramN.p2(this.f);
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compose\foundation\layout\PaddingElement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */