package androidx.compose.foundation.layout;

import androidx.compose.ui.d;
import dbxyzptlk.f1.G;
import dbxyzptlk.g0.f0;
import dbxyzptlk.z1.h;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

@Metadata(d1 = {"\0002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\007\n\002\030\002\n\002\b\002\n\002\020\000\n\000\n\002\020\013\n\002\b\002\n\002\020\b\n\002\b\t\b\002\030\0002\b\022\004\022\0020\0020\001B\033\022\b\b\002\020\004\032\0020\003\022\b\b\002\020\005\032\0020\003¢\006\004\b\006\020\007J\017\020\b\032\0020\002H\026¢\006\004\b\b\020\tJ\027\020\f\032\0020\0132\006\020\n\032\0020\002H\026¢\006\004\b\f\020\rJ\032\020\021\032\0020\0202\b\020\017\032\004\030\0010\016H\002¢\006\004\b\021\020\022J\017\020\024\032\0020\023H\026¢\006\004\b\024\020\025R\035\020\004\032\0020\0038\006ø\001\000ø\001\001¢\006\f\n\004\b\026\020\027\032\004\b\030\020\031R\035\020\005\032\0020\0038\006ø\001\000ø\001\001¢\006\f\n\004\b\032\020\027\032\004\b\033\020\031\002\013\n\005\b¡\0360\001\n\002\b!¨\006\034"}, d2 = {"Landroidx/compose/foundation/layout/UnspecifiedConstraintsElement;", "Ldbxyzptlk/f1/G;", "Ldbxyzptlk/g0/f0;", "Ldbxyzptlk/z1/h;", "minWidth", "minHeight", "<init>", "(FFLkotlin/jvm/internal/DefaultConstructorMarker;)V", "i", "()Ldbxyzptlk/g0/f0;", "node", "Ldbxyzptlk/pI/D;", "k", "(Ldbxyzptlk/g0/f0;)V", "", "other", "", "equals", "(Ljava/lang/Object;)Z", "", "hashCode", "()I", "b", "F", "getMinWidth-D9Ej5fM", "()F", "c", "getMinHeight-D9Ej5fM", "foundation-layout_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
final class UnspecifiedConstraintsElement extends G<f0> {
  public final float b;
  
  public final float c;
  
  public UnspecifiedConstraintsElement(float paramFloat1, float paramFloat2) {
    this.b = paramFloat1;
    this.c = paramFloat2;
  }
  
  public boolean equals(Object paramObject) {
    boolean bool = paramObject instanceof UnspecifiedConstraintsElement;
    boolean bool1 = false;
    if (!bool)
      return false; 
    float f = this.b;
    paramObject = paramObject;
    bool = bool1;
    if (h.v(f, ((UnspecifiedConstraintsElement)paramObject).b)) {
      bool = bool1;
      if (h.v(this.c, ((UnspecifiedConstraintsElement)paramObject).c))
        bool = true; 
    } 
    return bool;
  }
  
  public int hashCode() {
    return h.x(this.b) * 31 + h.x(this.c);
  }
  
  public f0 i() {
    return new f0(this.b, this.c, null);
  }
  
  public void k(f0 paramf0) {
    paramf0.l2(this.b);
    paramf0.k2(this.c);
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compose\foundation\layout\UnspecifiedConstraintsElement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */