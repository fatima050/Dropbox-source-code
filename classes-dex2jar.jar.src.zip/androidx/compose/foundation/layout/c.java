package androidx.compose.foundation.layout;

import androidx.compose.ui.d;
import dbxyzptlk.CI.l;
import dbxyzptlk.g0.h;
import dbxyzptlk.g1.p0;
import dbxyzptlk.g1.r0;
import dbxyzptlk.pI.D;
import kotlin.Metadata;

@Metadata(d1 = {"\000\030\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\030\002\n\002\b\006\bÀ\002\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\033\020\007\032\0020\004*\0020\0042\006\020\006\032\0020\005H\027¢\006\004\b\007\020\bJ\023\020\t\032\0020\004*\0020\004H\027¢\006\004\b\t\020\n¨\006\013"}, d2 = {"Landroidx/compose/foundation/layout/c;", "Ldbxyzptlk/g0/h;", "<init>", "()V", "Landroidx/compose/ui/d;", "Ldbxyzptlk/K0/c;", "alignment", "e", "(Landroidx/compose/ui/d;Ldbxyzptlk/K0/c;)Landroidx/compose/ui/d;", "i", "(Landroidx/compose/ui/d;)Landroidx/compose/ui/d;", "foundation-layout_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class c implements h {
  public static final c a = new c();
  
  public d e(d paramd, dbxyzptlk.K0.c paramc) {
    l<? super r0, D> l;
    if (p0.c()) {
      a a = new a(paramc);
    } else {
      l = p0.a();
    } 
    return paramd.g((d)new BoxChildDataElement(paramc, false, l));
  }
  
  public d i(d paramd) {
    l<? super r0, D> l;
    dbxyzptlk.K0.c c1 = dbxyzptlk.K0.c.a.e();
    if (p0.c()) {
      b b = new b();
    } else {
      l = p0.a();
    } 
    return paramd.g((d)new BoxChildDataElement(c1, true, l));
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compose\foundation\layout\c.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */