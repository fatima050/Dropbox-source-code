package androidx.compose.foundation.layout;

import androidx.compose.ui.d;
import dbxyzptlk.CI.l;
import dbxyzptlk.f1.G;
import dbxyzptlk.g0.d;
import dbxyzptlk.g1.r0;
import dbxyzptlk.pI.D;
import kotlin.Metadata;

@Metadata(d1 = {"\0008\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\007\n\000\n\002\020\013\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\b\n\002\020\000\n\002\b\003\n\002\020\b\n\002\b\017\b\002\030\0002\b\022\004\022\0020\0020\001B+\022\006\020\004\032\0020\003\022\006\020\006\032\0020\005\022\022\020\n\032\016\022\004\022\0020\b\022\004\022\0020\t0\007¢\006\004\b\013\020\fJ\017\020\r\032\0020\002H\026¢\006\004\b\r\020\016J\027\020\020\032\0020\t2\006\020\017\032\0020\002H\026¢\006\004\b\020\020\021J\032\020\024\032\0020\0052\b\020\023\032\004\030\0010\022H\002¢\006\004\b\024\020\025J\017\020\027\032\0020\026H\026¢\006\004\b\027\020\030R\027\020\004\032\0020\0038\006¢\006\f\n\004\b\031\020\032\032\004\b\033\020\034R\027\020\006\032\0020\0058\006¢\006\f\n\004\b\035\020\036\032\004\b\037\020 R#\020\n\032\016\022\004\022\0020\b\022\004\022\0020\t0\0078\006¢\006\f\n\004\b!\020\"\032\004\b#\020$¨\006%"}, d2 = {"Landroidx/compose/foundation/layout/AspectRatioElement;", "Ldbxyzptlk/f1/G;", "Ldbxyzptlk/g0/d;", "", "aspectRatio", "", "matchHeightConstraintsFirst", "Lkotlin/Function1;", "Ldbxyzptlk/g1/r0;", "Ldbxyzptlk/pI/D;", "inspectorInfo", "<init>", "(FZLdbxyzptlk/CI/l;)V", "i", "()Ldbxyzptlk/g0/d;", "node", "k", "(Ldbxyzptlk/g0/d;)V", "", "other", "equals", "(Ljava/lang/Object;)Z", "", "hashCode", "()I", "b", "F", "getAspectRatio", "()F", "c", "Z", "getMatchHeightConstraintsFirst", "()Z", "d", "Ldbxyzptlk/CI/l;", "getInspectorInfo", "()Ldbxyzptlk/CI/l;", "foundation-layout_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
final class AspectRatioElement extends G<d> {
  public final float b;
  
  public final boolean c;
  
  public final l<r0, D> d;
  
  public AspectRatioElement(float paramFloat, boolean paramBoolean, l<? super r0, D> paraml) {
    this.b = paramFloat;
    this.c = paramBoolean;
    this.d = (l)paraml;
    if (paramFloat > 0.0F)
      return; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("aspectRatio ");
    stringBuilder.append(paramFloat);
    stringBuilder.append(" must be > 0");
    throw new IllegalArgumentException(stringBuilder.toString().toString());
  }
  
  public boolean equals(Object paramObject) {
    Object object;
    boolean bool = true;
    if (this == paramObject)
      return true; 
    if (paramObject instanceof AspectRatioElement) {
      object = paramObject;
    } else {
      object = null;
    } 
    if (object == null)
      return false; 
    if (this.b != ((AspectRatioElement)object).b || this.c != ((AspectRatioElement)paramObject).c)
      bool = false; 
    return bool;
  }
  
  public int hashCode() {
    return Float.hashCode(this.b) * 31 + Boolean.hashCode(this.c);
  }
  
  public d i() {
    return new d(this.b, this.c);
  }
  
  public void k(d paramd) {
    paramd.l2(this.b);
    paramd.m2(this.c);
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compose\foundation\layout\AspectRatioElement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */