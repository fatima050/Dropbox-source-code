package androidx.compose.foundation.layout;

import dbxyzptlk.CI.l;
import dbxyzptlk.DI.u;
import dbxyzptlk.g0.O;
import dbxyzptlk.g0.P;
import dbxyzptlk.g1.r0;
import dbxyzptlk.pI.D;
import dbxyzptlk.z1.h;
import dbxyzptlk.z1.t;
import kotlin.Metadata;

@Metadata(d1 = {"\000\034\n\002\030\002\n\002\030\002\n\002\b\r\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\013\032>\020\006\032\0020\000*\0020\0002\b\b\002\020\002\032\0020\0012\b\b\002\020\003\032\0020\0012\b\b\002\020\004\032\0020\0012\b\b\002\020\005\032\0020\001H\007ø\001\000¢\006\004\b\006\020\007\032*\020\n\032\0020\000*\0020\0002\b\b\002\020\b\032\0020\0012\b\b\002\020\t\032\0020\001H\007ø\001\000¢\006\004\b\n\020\013\032\036\020\r\032\0020\000*\0020\0002\006\020\f\032\0020\001H\007ø\001\000¢\006\004\b\r\020\016\032\033\020\021\032\0020\000*\0020\0002\006\020\020\032\0020\017H\007¢\006\004\b\021\020\022\032\033\020\025\032\0020\001*\0020\0172\006\020\024\032\0020\023H\007¢\006\004\b\025\020\026\032\033\020\027\032\0020\001*\0020\0172\006\020\024\032\0020\023H\007¢\006\004\b\027\020\026\032\032\020\030\032\0020\0172\006\020\f\032\0020\001H\007ø\001\000¢\006\004\b\030\020\031\032&\020\032\032\0020\0172\b\b\002\020\b\032\0020\0012\b\b\002\020\t\032\0020\001H\007ø\001\000¢\006\004\b\032\020\033\032:\020\034\032\0020\0172\b\b\002\020\002\032\0020\0012\b\b\002\020\003\032\0020\0012\b\b\002\020\004\032\0020\0012\b\b\002\020\005\032\0020\001H\007ø\001\000¢\006\004\b\034\020\035\002\007\n\005\b¡\0360\001¨\006\036"}, d2 = {"Landroidx/compose/ui/d;", "Ldbxyzptlk/z1/h;", "start", "top", "end", "bottom", "l", "(Landroidx/compose/ui/d;FFFF)Landroidx/compose/ui/d;", "horizontal", "vertical", "j", "(Landroidx/compose/ui/d;FF)Landroidx/compose/ui/d;", "all", "i", "(Landroidx/compose/ui/d;F)Landroidx/compose/ui/d;", "Ldbxyzptlk/g0/O;", "paddingValues", "h", "(Landroidx/compose/ui/d;Ldbxyzptlk/g0/O;)Landroidx/compose/ui/d;", "Ldbxyzptlk/z1/t;", "layoutDirection", "g", "(Ldbxyzptlk/g0/O;Ldbxyzptlk/z1/t;)F", "f", "a", "(F)Ldbxyzptlk/g0/O;", "b", "(FF)Ldbxyzptlk/g0/O;", "d", "(FFFF)Ldbxyzptlk/g0/O;", "foundation-layout_release"}, k = 2, mv = {1, 8, 0}, xi = 48)
public final class f {
  public static final O a(float paramFloat) {
    return (O)new P(paramFloat, paramFloat, paramFloat, paramFloat, null);
  }
  
  public static final O b(float paramFloat1, float paramFloat2) {
    return (O)new P(paramFloat1, paramFloat2, paramFloat1, paramFloat2, null);
  }
  
  public static final O d(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    return (O)new P(paramFloat1, paramFloat2, paramFloat3, paramFloat4, null);
  }
  
  public static final float f(O paramO, t paramt) {
    float f1;
    if (paramt == t.Ltr) {
      f1 = paramO.d(paramt);
    } else {
      f1 = paramO.b(paramt);
    } 
    return f1;
  }
  
  public static final float g(O paramO, t paramt) {
    float f1;
    if (paramt == t.Ltr) {
      f1 = paramO.b(paramt);
    } else {
      f1 = paramO.d(paramt);
    } 
    return f1;
  }
  
  public static final androidx.compose.ui.d h(androidx.compose.ui.d paramd, O paramO) {
    return paramd.g((androidx.compose.ui.d)new PaddingValuesElement(paramO, new d(paramO)));
  }
  
  public static final androidx.compose.ui.d i(androidx.compose.ui.d paramd, float paramFloat) {
    return paramd.g((androidx.compose.ui.d)new PaddingElement(paramFloat, paramFloat, paramFloat, paramFloat, true, new c(paramFloat), null));
  }
  
  public static final androidx.compose.ui.d j(androidx.compose.ui.d paramd, float paramFloat1, float paramFloat2) {
    return paramd.g((androidx.compose.ui.d)new PaddingElement(paramFloat1, paramFloat2, paramFloat1, paramFloat2, true, (l)new b(paramFloat1, paramFloat2), null));
  }
  
  public static final androidx.compose.ui.d l(androidx.compose.ui.d paramd, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    return paramd.g((androidx.compose.ui.d)new PaddingElement(paramFloat1, paramFloat2, paramFloat3, paramFloat4, true, new a(paramFloat1, paramFloat2, paramFloat3, paramFloat4), null));
  }
  
  @Metadata(d1 = {"\000\f\n\002\030\002\n\002\030\002\n\002\b\002\020\002\032\0020\001*\0020\000H\n¢\006\004\b\002\020\003"}, d2 = {"Ldbxyzptlk/g1/r0;", "Ldbxyzptlk/pI/D;", "a", "(Ldbxyzptlk/g1/r0;)V"}, k = 3, mv = {1, 8, 0})
  public static final class a extends u implements l<r0, D> {
    public final float f;
    
    public final float g;
    
    public final float h;
    
    public final float i;
    
    public a(float param1Float1, float param1Float2, float param1Float3, float param1Float4) {
      super(1);
    }
    
    public final void a(r0 param1r0) {
      param1r0.b("padding");
      param1r0.a().b("start", h.l(this.f));
      param1r0.a().b("top", h.l(this.g));
      param1r0.a().b("end", h.l(this.h));
      param1r0.a().b("bottom", h.l(this.i));
    }
  }
  
  @Metadata(d1 = {"\000\f\n\002\030\002\n\002\030\002\n\002\b\002\020\002\032\0020\001*\0020\000H\n¢\006\004\b\002\020\003"}, d2 = {"Ldbxyzptlk/g1/r0;", "Ldbxyzptlk/pI/D;", "a", "(Ldbxyzptlk/g1/r0;)V"}, k = 3, mv = {1, 8, 0})
  public static final class c extends u implements l<r0, D> {
    public final float f;
    
    public c(float param1Float) {
      super(1);
    }
    
    public final void a(r0 param1r0) {
      param1r0.b("padding");
      param1r0.c(h.l(this.f));
    }
  }
  
  @Metadata(d1 = {"\000\f\n\002\030\002\n\002\030\002\n\002\b\002\020\002\032\0020\001*\0020\000H\n¢\006\004\b\002\020\003"}, d2 = {"Ldbxyzptlk/g1/r0;", "Ldbxyzptlk/pI/D;", "a", "(Ldbxyzptlk/g1/r0;)V"}, k = 3, mv = {1, 8, 0})
  public static final class d extends u implements l<r0, D> {
    public final O f;
    
    public d(O param1O) {
      super(1);
    }
    
    public final void a(r0 param1r0) {
      param1r0.b("padding");
      param1r0.a().b("paddingValues", this.f);
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compose\foundation\layout\f.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */