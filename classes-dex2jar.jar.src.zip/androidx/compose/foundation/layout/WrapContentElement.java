package androidx.compose.foundation.layout;

import androidx.compose.ui.d;
import dbxyzptlk.CI.p;
import dbxyzptlk.DI.s;
import dbxyzptlk.DI.u;
import dbxyzptlk.f1.G;
import dbxyzptlk.g0.o0;
import dbxyzptlk.g0.q;
import dbxyzptlk.z1.n;
import dbxyzptlk.z1.o;
import dbxyzptlk.z1.r;
import dbxyzptlk.z1.t;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

@Metadata(d1 = {"\000H\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\020\013\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\020\000\n\000\n\002\020\016\n\002\b\006\n\002\030\002\n\002\b\005\n\002\020\b\n\002\b\017\b\002\030\000 (2\b\022\004\022\0020\0020\001:\001)BA\022\006\020\004\032\0020\003\022\006\020\006\032\0020\005\022\030\020\013\032\024\022\004\022\0020\b\022\004\022\0020\t\022\004\022\0020\n0\007\022\006\020\r\032\0020\f\022\006\020\017\032\0020\016¢\006\004\b\020\020\021J\017\020\022\032\0020\002H\026¢\006\004\b\022\020\023J\027\020\026\032\0020\0252\006\020\024\032\0020\002H\026¢\006\004\b\026\020\027J\032\020\031\032\0020\0052\b\020\030\032\004\030\0010\fH\002¢\006\004\b\031\020\032J\017\020\034\032\0020\033H\026¢\006\004\b\034\020\035R\024\020\004\032\0020\0038\002X\004¢\006\006\n\004\b\036\020\037R\024\020\006\032\0020\0058\002X\004¢\006\006\n\004\b \020!R&\020\013\032\024\022\004\022\0020\b\022\004\022\0020\t\022\004\022\0020\n0\0078\002X\004¢\006\006\n\004\b\"\020#R\024\020\r\032\0020\f8\002X\004¢\006\006\n\004\b$\020%R\024\020\017\032\0020\0168\002X\004¢\006\006\n\004\b&\020'¨\006*"}, d2 = {"Landroidx/compose/foundation/layout/WrapContentElement;", "Ldbxyzptlk/f1/G;", "Ldbxyzptlk/g0/o0;", "Ldbxyzptlk/g0/q;", "direction", "", "unbounded", "Lkotlin/Function2;", "Ldbxyzptlk/z1/r;", "Ldbxyzptlk/z1/t;", "Ldbxyzptlk/z1/n;", "alignmentCallback", "", "align", "", "inspectorName", "<init>", "(Ldbxyzptlk/g0/q;ZLdbxyzptlk/CI/p;Ljava/lang/Object;Ljava/lang/String;)V", "i", "()Ldbxyzptlk/g0/o0;", "node", "Ldbxyzptlk/pI/D;", "k", "(Ldbxyzptlk/g0/o0;)V", "other", "equals", "(Ljava/lang/Object;)Z", "", "hashCode", "()I", "b", "Ldbxyzptlk/g0/q;", "c", "Z", "d", "Ldbxyzptlk/CI/p;", "e", "Ljava/lang/Object;", "f", "Ljava/lang/String;", "g", "a", "foundation-layout_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
final class WrapContentElement extends G<o0> {
  public static final a g = new a(null);
  
  public final q b;
  
  public final boolean c;
  
  public final p<r, t, n> d;
  
  public final Object e;
  
  public final String f;
  
  public WrapContentElement(q paramq, boolean paramBoolean, p<? super r, ? super t, n> paramp, Object paramObject, String paramString) {
    this.b = paramq;
    this.c = paramBoolean;
    this.d = (p)paramp;
    this.e = paramObject;
    this.f = paramString;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (paramObject == null)
      return false; 
    if (WrapContentElement.class != paramObject.getClass())
      return false; 
    paramObject = paramObject;
    return (this.b != ((WrapContentElement)paramObject).b) ? false : ((this.c != ((WrapContentElement)paramObject).c) ? false : (!!s.c(this.e, ((WrapContentElement)paramObject).e)));
  }
  
  public int hashCode() {
    return (this.b.hashCode() * 31 + Boolean.hashCode(this.c)) * 31 + this.e.hashCode();
  }
  
  public o0 i() {
    return new o0(this.b, this.c, this.d);
  }
  
  public void k(o0 paramo0) {
    paramo0.m2(this.b);
    paramo0.n2(this.c);
    paramo0.l2(this.d);
  }
  
  @Metadata(d1 = {"\0000\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\000\n\002\020\013\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\003\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\037\020\t\032\0020\b2\006\020\005\032\0020\0042\006\020\007\032\0020\006H\007¢\006\004\b\t\020\nJ\037\020\f\032\0020\b2\006\020\005\032\0020\0132\006\020\007\032\0020\006H\007¢\006\004\b\f\020\rJ\037\020\017\032\0020\b2\006\020\005\032\0020\0162\006\020\007\032\0020\006H\007¢\006\004\b\017\020\020¨\006\021"}, d2 = {"Landroidx/compose/foundation/layout/WrapContentElement$a;", "", "<init>", "()V", "Ldbxyzptlk/K0/c$b;", "align", "", "unbounded", "Landroidx/compose/foundation/layout/WrapContentElement;", "c", "(Ldbxyzptlk/K0/c$b;Z)Landroidx/compose/foundation/layout/WrapContentElement;", "Ldbxyzptlk/K0/c$c;", "a", "(Ldbxyzptlk/K0/c$c;Z)Landroidx/compose/foundation/layout/WrapContentElement;", "Ldbxyzptlk/K0/c;", "b", "(Ldbxyzptlk/K0/c;Z)Landroidx/compose/foundation/layout/WrapContentElement;", "foundation-layout_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class a {
    public a() {}
    
    public final WrapContentElement a(dbxyzptlk.K0.c.c param1c, boolean param1Boolean) {
      return new WrapContentElement(q.Vertical, param1Boolean, new a(param1c), param1c, "wrapContentHeight");
    }
    
    public final WrapContentElement b(dbxyzptlk.K0.c param1c, boolean param1Boolean) {
      return new WrapContentElement(q.Both, param1Boolean, new b(param1c), param1c, "wrapContentSize");
    }
    
    public final WrapContentElement c(dbxyzptlk.K0.c.b param1b, boolean param1Boolean) {
      return new WrapContentElement(q.Horizontal, param1Boolean, new c(param1b), param1b, "wrapContentWidth");
    }
    
    @Metadata(d1 = {"\000\024\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\002\020\005\032\0020\0042\006\020\001\032\0020\0002\006\020\003\032\0020\002H\n¢\006\004\b\005\020\006"}, d2 = {"Ldbxyzptlk/z1/r;", "size", "Ldbxyzptlk/z1/t;", "<anonymous parameter 1>", "Ldbxyzptlk/z1/n;", "a", "(JLdbxyzptlk/z1/t;)J"}, k = 3, mv = {1, 8, 0})
    public static final class a extends u implements p<r, t, n> {
      public final dbxyzptlk.K0.c.c f;
      
      public a(dbxyzptlk.K0.c.c param2c) {
        super(2);
      }
      
      public final long a(long param2Long, t param2t) {
        return o.a(0, this.f.a(0, r.g(param2Long)));
      }
    }
    
    @Metadata(d1 = {"\000\024\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\002\020\005\032\0020\0042\006\020\001\032\0020\0002\006\020\003\032\0020\002H\n¢\006\004\b\005\020\006"}, d2 = {"Ldbxyzptlk/z1/r;", "size", "Ldbxyzptlk/z1/t;", "layoutDirection", "Ldbxyzptlk/z1/n;", "a", "(JLdbxyzptlk/z1/t;)J"}, k = 3, mv = {1, 8, 0})
    public static final class b extends u implements p<r, t, n> {
      public final dbxyzptlk.K0.c f;
      
      public b(dbxyzptlk.K0.c param2c) {
        super(2);
      }
      
      public final long a(long param2Long, t param2t) {
        return this.f.a(r.b.a(), param2Long, param2t);
      }
    }
    
    @Metadata(d1 = {"\000\024\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\002\020\005\032\0020\0042\006\020\001\032\0020\0002\006\020\003\032\0020\002H\n¢\006\004\b\005\020\006"}, d2 = {"Ldbxyzptlk/z1/r;", "size", "Ldbxyzptlk/z1/t;", "layoutDirection", "Ldbxyzptlk/z1/n;", "a", "(JLdbxyzptlk/z1/t;)J"}, k = 3, mv = {1, 8, 0})
    public static final class c extends u implements p<r, t, n> {
      public final dbxyzptlk.K0.c.b f;
      
      public c(dbxyzptlk.K0.c.b param2b) {
        super(2);
      }
      
      public final long a(long param2Long, t param2t) {
        return o.a(this.f.a(0, r.h(param2Long), param2t), 0);
      }
    }
  }
  
  @Metadata(d1 = {"\000\024\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\002\020\005\032\0020\0042\006\020\001\032\0020\0002\006\020\003\032\0020\002H\n¢\006\004\b\005\020\006"}, d2 = {"Ldbxyzptlk/z1/r;", "size", "Ldbxyzptlk/z1/t;", "<anonymous parameter 1>", "Ldbxyzptlk/z1/n;", "a", "(JLdbxyzptlk/z1/t;)J"}, k = 3, mv = {1, 8, 0})
  public static final class a extends u implements p<r, t, n> {
    public final dbxyzptlk.K0.c.c f;
    
    public a(dbxyzptlk.K0.c.c param1c) {
      super(2);
    }
    
    public final long a(long param1Long, t param1t) {
      return o.a(0, this.f.a(0, r.g(param1Long)));
    }
  }
  
  @Metadata(d1 = {"\000\024\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\002\020\005\032\0020\0042\006\020\001\032\0020\0002\006\020\003\032\0020\002H\n¢\006\004\b\005\020\006"}, d2 = {"Ldbxyzptlk/z1/r;", "size", "Ldbxyzptlk/z1/t;", "layoutDirection", "Ldbxyzptlk/z1/n;", "a", "(JLdbxyzptlk/z1/t;)J"}, k = 3, mv = {1, 8, 0})
  public static final class b extends u implements p<r, t, n> {
    public final dbxyzptlk.K0.c f;
    
    public b(dbxyzptlk.K0.c param1c) {
      super(2);
    }
    
    public final long a(long param1Long, t param1t) {
      return this.f.a(r.b.a(), param1Long, param1t);
    }
  }
  
  @Metadata(d1 = {"\000\024\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\002\020\005\032\0020\0042\006\020\001\032\0020\0002\006\020\003\032\0020\002H\n¢\006\004\b\005\020\006"}, d2 = {"Ldbxyzptlk/z1/r;", "size", "Ldbxyzptlk/z1/t;", "layoutDirection", "Ldbxyzptlk/z1/n;", "a", "(JLdbxyzptlk/z1/t;)J"}, k = 3, mv = {1, 8, 0})
  public static final class c extends u implements p<r, t, n> {
    public final dbxyzptlk.K0.c.b f;
    
    public c(dbxyzptlk.K0.c.b param1b) {
      super(2);
    }
    
    public final long a(long param1Long, t param1t) {
      return o.a(this.f.a(0, r.h(param1Long), param1t), 0);
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compose\foundation\layout\WrapContentElement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */