package androidx.compose.foundation.layout;

import androidx.compose.ui.d;
import dbxyzptlk.CI.l;
import dbxyzptlk.g1.p0;
import dbxyzptlk.g1.r0;
import dbxyzptlk.pI.D;
import kotlin.Metadata;

@Metadata(d1 = {"\000\022\n\002\030\002\n\002\020\007\n\000\n\002\020\013\n\002\b\004\032'\020\005\032\0020\000*\0020\0002\b\b\001\020\002\032\0020\0012\b\b\002\020\004\032\0020\003H\007¢\006\004\b\005\020\006¨\006\007"}, d2 = {"Landroidx/compose/ui/d;", "", "ratio", "", "matchHeightConstraintsFirst", "a", "(Landroidx/compose/ui/d;FZ)Landroidx/compose/ui/d;", "foundation-layout_release"}, k = 2, mv = {1, 8, 0}, xi = 48)
public final class b {
  public static final d a(d paramd, float paramFloat, boolean paramBoolean) {
    l<? super r0, D> l;
    if (p0.c()) {
      a a = new a(paramFloat, paramBoolean);
    } else {
      l = p0.a();
    } 
    return paramd.g((d)new AspectRatioElement(paramFloat, paramBoolean, l));
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compose\foundation\layout\b.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */