package androidx.compose.foundation.layout;

import androidx.compose.ui.d;
import dbxyzptlk.CI.l;
import dbxyzptlk.DI.s;
import dbxyzptlk.f1.G;
import dbxyzptlk.g0.O;
import dbxyzptlk.g0.Q;
import dbxyzptlk.g1.r0;
import dbxyzptlk.pI.D;
import kotlin.Metadata;

@Metadata(d1 = {"\0008\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\b\n\002\020\b\n\002\b\002\n\002\020\000\n\000\n\002\020\013\n\002\b\013\b\002\030\0002\b\022\004\022\0020\0020\001B#\022\006\020\004\032\0020\003\022\022\020\b\032\016\022\004\022\0020\006\022\004\022\0020\0070\005¢\006\004\b\t\020\nJ\017\020\013\032\0020\002H\026¢\006\004\b\013\020\fJ\027\020\016\032\0020\0072\006\020\r\032\0020\002H\026¢\006\004\b\016\020\017J\017\020\021\032\0020\020H\026¢\006\004\b\021\020\022J\032\020\026\032\0020\0252\b\020\024\032\004\030\0010\023H\002¢\006\004\b\026\020\027R\027\020\004\032\0020\0038\006¢\006\f\n\004\b\030\020\031\032\004\b\032\020\033R#\020\b\032\016\022\004\022\0020\006\022\004\022\0020\0070\0058\006¢\006\f\n\004\b\034\020\035\032\004\b\036\020\037¨\006 "}, d2 = {"Landroidx/compose/foundation/layout/PaddingValuesElement;", "Ldbxyzptlk/f1/G;", "Ldbxyzptlk/g0/Q;", "Ldbxyzptlk/g0/O;", "paddingValues", "Lkotlin/Function1;", "Ldbxyzptlk/g1/r0;", "Ldbxyzptlk/pI/D;", "inspectorInfo", "<init>", "(Ldbxyzptlk/g0/O;Ldbxyzptlk/CI/l;)V", "i", "()Ldbxyzptlk/g0/Q;", "node", "k", "(Ldbxyzptlk/g0/Q;)V", "", "hashCode", "()I", "", "other", "", "equals", "(Ljava/lang/Object;)Z", "b", "Ldbxyzptlk/g0/O;", "getPaddingValues", "()Ldbxyzptlk/g0/O;", "c", "Ldbxyzptlk/CI/l;", "getInspectorInfo", "()Ldbxyzptlk/CI/l;", "foundation-layout_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
final class PaddingValuesElement extends G<Q> {
  public final O b;
  
  public final l<r0, D> c;
  
  public PaddingValuesElement(O paramO, l<? super r0, D> paraml) {
    this.b = paramO;
    this.c = (l)paraml;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject instanceof PaddingValuesElement) {
      paramObject = paramObject;
    } else {
      paramObject = null;
    } 
    return (paramObject == null) ? false : s.c(this.b, ((PaddingValuesElement)paramObject).b);
  }
  
  public int hashCode() {
    return this.b.hashCode();
  }
  
  public Q i() {
    return new Q(this.b);
  }
  
  public void k(Q paramQ) {
    paramQ.l2(this.b);
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compose\foundation\layout\PaddingValuesElement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */