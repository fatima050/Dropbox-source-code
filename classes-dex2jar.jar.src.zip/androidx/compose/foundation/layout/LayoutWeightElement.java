package androidx.compose.foundation.layout;

import androidx.compose.ui.d;
import dbxyzptlk.f1.G;
import dbxyzptlk.g0.J;
import kotlin.Metadata;

@Metadata(d1 = {"\0002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\007\n\000\n\002\020\013\n\002\b\006\n\002\030\002\n\002\b\002\n\002\020\b\n\002\b\002\n\002\020\000\n\002\b\f\b\000\030\0002\b\022\004\022\0020\0020\001B\027\022\006\020\004\032\0020\003\022\006\020\006\032\0020\005¢\006\004\b\007\020\bJ\017\020\t\032\0020\002H\026¢\006\004\b\t\020\nJ\027\020\r\032\0020\f2\006\020\013\032\0020\002H\026¢\006\004\b\r\020\016J\017\020\020\032\0020\017H\026¢\006\004\b\020\020\021J\032\020\024\032\0020\0052\b\020\023\032\004\030\0010\022H\002¢\006\004\b\024\020\025R\027\020\004\032\0020\0038\006¢\006\f\n\004\b\026\020\027\032\004\b\030\020\031R\027\020\006\032\0020\0058\006¢\006\f\n\004\b\032\020\033\032\004\b\034\020\035¨\006\036"}, d2 = {"Landroidx/compose/foundation/layout/LayoutWeightElement;", "Ldbxyzptlk/f1/G;", "Ldbxyzptlk/g0/J;", "", "weight", "", "fill", "<init>", "(FZ)V", "i", "()Ldbxyzptlk/g0/J;", "node", "Ldbxyzptlk/pI/D;", "k", "(Ldbxyzptlk/g0/J;)V", "", "hashCode", "()I", "", "other", "equals", "(Ljava/lang/Object;)Z", "b", "F", "getWeight", "()F", "c", "Z", "getFill", "()Z", "foundation-layout_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class LayoutWeightElement extends G<J> {
  public final float b;
  
  public final boolean c;
  
  public LayoutWeightElement(float paramFloat, boolean paramBoolean) {
    this.b = paramFloat;
    this.c = paramBoolean;
  }
  
  public boolean equals(Object paramObject) {
    boolean bool = true;
    if (this == paramObject)
      return true; 
    if (paramObject instanceof LayoutWeightElement) {
      paramObject = paramObject;
    } else {
      paramObject = null;
    } 
    if (paramObject == null)
      return false; 
    if (this.b != ((LayoutWeightElement)paramObject).b || this.c != ((LayoutWeightElement)paramObject).c)
      bool = false; 
    return bool;
  }
  
  public int hashCode() {
    return Float.hashCode(this.b) * 31 + Boolean.hashCode(this.c);
  }
  
  public J i() {
    return new J(this.b, this.c);
  }
  
  public void k(J paramJ) {
    paramJ.m2(this.b);
    paramJ.l2(this.c);
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compose\foundation\layout\LayoutWeightElement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */