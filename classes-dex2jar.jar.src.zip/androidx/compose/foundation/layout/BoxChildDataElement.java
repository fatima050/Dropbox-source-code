package androidx.compose.foundation.layout;

import androidx.compose.ui.d;
import dbxyzptlk.CI.l;
import dbxyzptlk.DI.s;
import dbxyzptlk.K0.c;
import dbxyzptlk.f1.G;
import dbxyzptlk.g0.e;
import dbxyzptlk.g1.r0;
import dbxyzptlk.pI.D;
import kotlin.Metadata;

@Metadata(d1 = {"\0008\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\020\013\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\b\n\002\020\b\n\002\b\002\n\002\020\000\n\002\b\020\b\002\030\0002\b\022\004\022\0020\0020\001B+\022\006\020\004\032\0020\003\022\006\020\006\032\0020\005\022\022\020\n\032\016\022\004\022\0020\b\022\004\022\0020\t0\007¢\006\004\b\013\020\fJ\017\020\r\032\0020\002H\026¢\006\004\b\r\020\016J\027\020\020\032\0020\t2\006\020\017\032\0020\002H\026¢\006\004\b\020\020\021J\017\020\023\032\0020\022H\026¢\006\004\b\023\020\024J\032\020\027\032\0020\0052\b\020\026\032\004\030\0010\025H\002¢\006\004\b\027\020\030R\027\020\004\032\0020\0038\006¢\006\f\n\004\b\031\020\032\032\004\b\033\020\034R\027\020\006\032\0020\0058\006¢\006\f\n\004\b\035\020\036\032\004\b\037\020 R#\020\n\032\016\022\004\022\0020\b\022\004\022\0020\t0\0078\006¢\006\f\n\004\b!\020\"\032\004\b#\020$¨\006%"}, d2 = {"Landroidx/compose/foundation/layout/BoxChildDataElement;", "Ldbxyzptlk/f1/G;", "Ldbxyzptlk/g0/e;", "Ldbxyzptlk/K0/c;", "alignment", "", "matchParentSize", "Lkotlin/Function1;", "Ldbxyzptlk/g1/r0;", "Ldbxyzptlk/pI/D;", "inspectorInfo", "<init>", "(Ldbxyzptlk/K0/c;ZLdbxyzptlk/CI/l;)V", "i", "()Ldbxyzptlk/g0/e;", "node", "k", "(Ldbxyzptlk/g0/e;)V", "", "hashCode", "()I", "", "other", "equals", "(Ljava/lang/Object;)Z", "b", "Ldbxyzptlk/K0/c;", "getAlignment", "()Ldbxyzptlk/K0/c;", "c", "Z", "getMatchParentSize", "()Z", "d", "Ldbxyzptlk/CI/l;", "getInspectorInfo", "()Ldbxyzptlk/CI/l;", "foundation-layout_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
final class BoxChildDataElement extends G<e> {
  public final c b;
  
  public final boolean c;
  
  public final l<r0, D> d;
  
  public BoxChildDataElement(c paramc, boolean paramBoolean, l<? super r0, D> paraml) {
    this.b = paramc;
    this.c = paramBoolean;
    this.d = (l)paraml;
  }
  
  public boolean equals(Object paramObject) {
    boolean bool = true;
    if (this == paramObject)
      return true; 
    if (paramObject instanceof BoxChildDataElement) {
      paramObject = paramObject;
    } else {
      paramObject = null;
    } 
    if (paramObject == null)
      return false; 
    if (!s.c(this.b, ((BoxChildDataElement)paramObject).b) || this.c != ((BoxChildDataElement)paramObject).c)
      bool = false; 
    return bool;
  }
  
  public int hashCode() {
    return this.b.hashCode() * 31 + Boolean.hashCode(this.c);
  }
  
  public e i() {
    return new e(this.b, this.c);
  }
  
  public void k(e parame) {
    parame.n2(this.b);
    parame.o2(this.c);
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compose\foundation\layout\BoxChildDataElement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */