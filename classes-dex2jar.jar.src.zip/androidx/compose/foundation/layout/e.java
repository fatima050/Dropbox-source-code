package androidx.compose.foundation.layout;

import androidx.compose.ui.d;
import dbxyzptlk.CI.l;
import dbxyzptlk.DI.u;
import dbxyzptlk.g1.r0;
import dbxyzptlk.pI.D;
import dbxyzptlk.z1.d;
import dbxyzptlk.z1.h;
import dbxyzptlk.z1.n;
import kotlin.Metadata;

@Metadata(d1 = {"\000\034\n\002\030\002\n\002\030\002\n\002\b\004\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\004\032*\020\004\032\0020\000*\0020\0002\b\b\002\020\002\032\0020\0012\b\b\002\020\003\032\0020\001H\007ø\001\000¢\006\004\b\004\020\005\032%\020\n\032\0020\000*\0020\0002\022\020\t\032\016\022\004\022\0020\007\022\004\022\0020\b0\006¢\006\004\b\n\020\013\002\007\n\005\b¡\0360\001¨\006\f"}, d2 = {"Landroidx/compose/ui/d;", "Ldbxyzptlk/z1/h;", "x", "y", "b", "(Landroidx/compose/ui/d;FF)Landroidx/compose/ui/d;", "Lkotlin/Function1;", "Ldbxyzptlk/z1/d;", "Ldbxyzptlk/z1/n;", "offset", "a", "(Landroidx/compose/ui/d;Ldbxyzptlk/CI/l;)Landroidx/compose/ui/d;", "foundation-layout_release"}, k = 2, mv = {1, 8, 0}, xi = 48)
public final class e {
  public static final d a(d paramd, l<? super d, n> paraml) {
    return paramd.g((d)new OffsetPxElement(paraml, true, new b(paraml)));
  }
  
  public static final d b(d paramd, float paramFloat1, float paramFloat2) {
    return paramd.g((d)new OffsetElement(paramFloat1, paramFloat2, true, (l)new a(paramFloat1, paramFloat2), null));
  }
  
  @Metadata(d1 = {"\000\f\n\002\030\002\n\002\030\002\n\002\b\002\020\002\032\0020\001*\0020\000H\n¢\006\004\b\002\020\003"}, d2 = {"Ldbxyzptlk/g1/r0;", "Ldbxyzptlk/pI/D;", "a", "(Ldbxyzptlk/g1/r0;)V"}, k = 3, mv = {1, 8, 0})
  public static final class b extends u implements l<r0, D> {
    public final l<d, n> f;
    
    public b(l<? super d, n> param1l) {
      super(1);
    }
    
    public final void a(r0 param1r0) {
      param1r0.b("offset");
      param1r0.a().b("offset", this.f);
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compose\foundation\layout\e.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */