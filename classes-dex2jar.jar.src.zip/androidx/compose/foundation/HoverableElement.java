package androidx.compose.foundation;

import androidx.compose.ui.d;
import dbxyzptlk.DI.s;
import dbxyzptlk.c0.C;
import dbxyzptlk.f0.m;
import dbxyzptlk.f1.G;
import kotlin.Metadata;

@Metadata(d1 = {"\0002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\006\n\002\030\002\n\002\b\002\n\002\020\b\n\002\b\002\n\002\020\000\n\000\n\002\020\013\n\002\b\005\b\002\030\0002\b\022\004\022\0020\0020\001B\017\022\006\020\004\032\0020\003¢\006\004\b\005\020\006J\017\020\007\032\0020\002H\026¢\006\004\b\007\020\bJ\027\020\013\032\0020\n2\006\020\t\032\0020\002H\026¢\006\004\b\013\020\fJ\017\020\016\032\0020\rH\026¢\006\004\b\016\020\017J\032\020\023\032\0020\0222\b\020\021\032\004\030\0010\020H\002¢\006\004\b\023\020\024R\024\020\004\032\0020\0038\002X\004¢\006\006\n\004\b\025\020\026¨\006\027"}, d2 = {"Landroidx/compose/foundation/HoverableElement;", "Ldbxyzptlk/f1/G;", "Ldbxyzptlk/c0/C;", "Ldbxyzptlk/f0/m;", "interactionSource", "<init>", "(Ldbxyzptlk/f0/m;)V", "i", "()Ldbxyzptlk/c0/C;", "node", "Ldbxyzptlk/pI/D;", "k", "(Ldbxyzptlk/c0/C;)V", "", "hashCode", "()I", "", "other", "", "equals", "(Ljava/lang/Object;)Z", "b", "Ldbxyzptlk/f0/m;", "foundation_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
final class HoverableElement extends G<C> {
  public final m b;
  
  public HoverableElement(m paramm) {
    this.b = paramm;
  }
  
  public boolean equals(Object paramObject) {
    return (this == paramObject) ? true : (!(paramObject instanceof HoverableElement) ? false : (!!s.c(((HoverableElement)paramObject).b, this.b)));
  }
  
  public int hashCode() {
    return this.b.hashCode() * 31;
  }
  
  public C i() {
    return new C(this.b);
  }
  
  public void k(C paramC) {
    paramC.n2(this.b);
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compose\foundation\HoverableElement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */