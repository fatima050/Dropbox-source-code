package androidx.compose.foundation;

import androidx.compose.ui.d;
import dbxyzptlk.CI.l;
import dbxyzptlk.Q0.U0;
import dbxyzptlk.Q0.a1;
import dbxyzptlk.Q0.h0;
import dbxyzptlk.g1.p0;
import kotlin.Metadata;

@Metadata(d1 = {"\000 \n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\030\002\n\000\n\002\020\007\n\002\b\004\032(\020\005\032\0020\000*\0020\0002\006\020\002\032\0020\0012\b\b\002\020\004\032\0020\003H\007ø\001\000¢\006\004\b\005\020\006\032/\020\013\032\0020\000*\0020\0002\006\020\b\032\0020\0072\b\b\002\020\004\032\0020\0032\b\b\003\020\n\032\0020\tH\007¢\006\004\b\013\020\f\002\007\n\005\b¡\0360\001¨\006\r"}, d2 = {"Landroidx/compose/ui/d;", "Ldbxyzptlk/Q0/r0;", "color", "Ldbxyzptlk/Q0/a1;", "shape", "c", "(Landroidx/compose/ui/d;JLdbxyzptlk/Q0/a1;)Landroidx/compose/ui/d;", "Ldbxyzptlk/Q0/h0;", "brush", "", "alpha", "a", "(Landroidx/compose/ui/d;Ldbxyzptlk/Q0/h0;Ldbxyzptlk/Q0/a1;F)Landroidx/compose/ui/d;", "foundation_release"}, k = 2, mv = {1, 8, 0}, xi = 48)
public final class c {
  public static final d a(d paramd, h0 paramh0, a1 parama1, float paramFloat) {
    l l;
    if (p0.c()) {
      a a = new a(paramFloat, paramh0, parama1);
    } else {
      l = p0.a();
    } 
    return paramd.g((d)new BackgroundElement(0L, paramh0, paramFloat, parama1, l, 1, null));
  }
  
  public static final d c(d paramd, long paramLong, a1 parama1) {
    l l;
    if (p0.c()) {
      b b = new b(paramLong, parama1);
    } else {
      l = p0.a();
    } 
    return paramd.g((d)new BackgroundElement(paramLong, null, 1.0F, parama1, l, 2, null));
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compose\foundation\c.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */