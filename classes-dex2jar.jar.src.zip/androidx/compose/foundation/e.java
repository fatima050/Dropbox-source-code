package androidx.compose.foundation;

import dbxyzptlk.CI.a;
import dbxyzptlk.c0.l;
import dbxyzptlk.f0.m;
import dbxyzptlk.f1.g;
import dbxyzptlk.l1.i;
import dbxyzptlk.pI.D;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

@Metadata(d1 = {"\000<\n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\020\013\n\000\n\002\020\016\n\000\n\002\030\002\n\000\n\002\030\002\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\006\b\002\030\0002\0020\001B9\022\006\020\003\032\0020\002\022\006\020\005\032\0020\004\022\b\020\007\032\004\030\0010\006\022\b\020\t\032\004\030\0010\b\022\f\020\f\032\b\022\004\022\0020\0130\n¢\006\004\b\r\020\016JB\020\017\032\0020\0132\006\020\003\032\0020\0022\006\020\005\032\0020\0042\b\020\007\032\004\030\0010\0062\b\020\t\032\004\030\0010\b2\f\020\f\032\b\022\004\022\0020\0130\nø\001\000¢\006\004\b\017\020\020R\032\020\026\032\0020\0218\026X\004¢\006\f\n\004\b\022\020\023\032\004\b\024\020\025R\032\020\034\032\0020\0278\026X\004¢\006\f\n\004\b\030\020\031\032\004\b\032\020\033\002\007\n\005\b¡\0360\001¨\006\035"}, d2 = {"Landroidx/compose/foundation/e;", "Landroidx/compose/foundation/a;", "Ldbxyzptlk/f0/m;", "interactionSource", "", "enabled", "", "onClickLabel", "Ldbxyzptlk/l1/i;", "role", "Lkotlin/Function0;", "Ldbxyzptlk/pI/D;", "onClick", "<init>", "(Ldbxyzptlk/f0/m;ZLjava/lang/String;Ldbxyzptlk/l1/i;Ldbxyzptlk/CI/a;Lkotlin/jvm/internal/DefaultConstructorMarker;)V", "w2", "(Ldbxyzptlk/f0/m;ZLjava/lang/String;Ldbxyzptlk/l1/i;Ldbxyzptlk/CI/a;)V", "Ldbxyzptlk/c0/l;", "v", "Ldbxyzptlk/c0/l;", "v2", "()Ldbxyzptlk/c0/l;", "clickableSemanticsNode", "Landroidx/compose/foundation/f;", "w", "Landroidx/compose/foundation/f;", "u2", "()Landroidx/compose/foundation/f;", "clickablePointerInputNode", "foundation_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class e extends a {
  public final l v;
  
  public final f w;
  
  public e(m paramm, boolean paramBoolean, String paramString, i parami, a<D> parama) {
    super(paramm, paramBoolean, paramString, parami, parama, null);
    this.v = (l)k2((g)new l(paramBoolean, paramString, parami, parama, null, null, null));
    this.w = (f)k2((g)new f(paramBoolean, paramm, parama, s2()));
  }
  
  public f u2() {
    return this.w;
  }
  
  public l v2() {
    return this.v;
  }
  
  public final void w2(m paramm, boolean paramBoolean, String paramString, i parami, a<D> parama) {
    t2(paramm, paramBoolean, paramString, parami, parama);
    v2().m2(paramBoolean, paramString, parami, parama, null, null);
    u2().x2(paramBoolean, paramm, parama);
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compose\foundation\e.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */