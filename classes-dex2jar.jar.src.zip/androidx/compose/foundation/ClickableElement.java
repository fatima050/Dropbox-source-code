package androidx.compose.foundation;

import androidx.compose.ui.d;
import dbxyzptlk.CI.a;
import dbxyzptlk.DI.s;
import dbxyzptlk.f0.m;
import dbxyzptlk.f1.G;
import dbxyzptlk.l1.i;
import dbxyzptlk.pI.D;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

@Metadata(d1 = {"\000@\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\020\013\n\000\n\002\020\016\n\000\n\002\030\002\n\000\n\002\030\002\n\002\030\002\n\002\b\b\n\002\020\000\n\002\b\003\n\002\020\b\n\002\b\r\b\002\030\0002\b\022\004\022\0020\0020\001B;\022\006\020\004\032\0020\003\022\006\020\006\032\0020\005\022\b\020\b\032\004\030\0010\007\022\n\b\002\020\n\032\004\030\0010\t\022\f\020\r\032\b\022\004\022\0020\f0\013¢\006\004\b\016\020\017J\017\020\020\032\0020\002H\026¢\006\004\b\020\020\021J\027\020\023\032\0020\f2\006\020\022\032\0020\002H\026¢\006\004\b\023\020\024J\032\020\027\032\0020\0052\b\020\026\032\004\030\0010\025H\002¢\006\004\b\027\020\030J\017\020\032\032\0020\031H\026¢\006\004\b\032\020\033R\024\020\004\032\0020\0038\002X\004¢\006\006\n\004\b\034\020\035R\024\020\006\032\0020\0058\002X\004¢\006\006\n\004\b\036\020\037R\026\020\b\032\004\030\0010\0078\002X\004¢\006\006\n\004\b \020!R\034\020\n\032\004\030\0010\t8\002X\004ø\001\000ø\001\001¢\006\006\n\004\b\"\020#R\032\020\r\032\b\022\004\022\0020\f0\0138\002X\004¢\006\006\n\004\b$\020%\002\013\n\005\b¡\0360\001\n\002\b!¨\006&"}, d2 = {"Landroidx/compose/foundation/ClickableElement;", "Ldbxyzptlk/f1/G;", "Landroidx/compose/foundation/e;", "Ldbxyzptlk/f0/m;", "interactionSource", "", "enabled", "", "onClickLabel", "Ldbxyzptlk/l1/i;", "role", "Lkotlin/Function0;", "Ldbxyzptlk/pI/D;", "onClick", "<init>", "(Ldbxyzptlk/f0/m;ZLjava/lang/String;Ldbxyzptlk/l1/i;Ldbxyzptlk/CI/a;Lkotlin/jvm/internal/DefaultConstructorMarker;)V", "i", "()Landroidx/compose/foundation/e;", "node", "k", "(Landroidx/compose/foundation/e;)V", "", "other", "equals", "(Ljava/lang/Object;)Z", "", "hashCode", "()I", "b", "Ldbxyzptlk/f0/m;", "c", "Z", "d", "Ljava/lang/String;", "e", "Ldbxyzptlk/l1/i;", "f", "Ldbxyzptlk/CI/a;", "foundation_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
final class ClickableElement extends G<e> {
  public final m b;
  
  public final boolean c;
  
  public final String d;
  
  public final i e;
  
  public final a<D> f;
  
  public ClickableElement(m paramm, boolean paramBoolean, String paramString, i parami, a<D> parama) {
    this.b = paramm;
    this.c = paramBoolean;
    this.d = paramString;
    this.e = parami;
    this.f = parama;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (paramObject == null)
      return false; 
    if (ClickableElement.class != paramObject.getClass())
      return false; 
    paramObject = paramObject;
    return !s.c(this.b, ((ClickableElement)paramObject).b) ? false : ((this.c != ((ClickableElement)paramObject).c) ? false : (!s.c(this.d, ((ClickableElement)paramObject).d) ? false : (!s.c(this.e, ((ClickableElement)paramObject).e) ? false : (!!s.c(this.f, ((ClickableElement)paramObject).f)))));
  }
  
  public int hashCode() {
    byte b;
    int n = this.b.hashCode();
    int k = Boolean.hashCode(this.c);
    String str = this.d;
    int j = 0;
    if (str != null) {
      b = str.hashCode();
    } else {
      b = 0;
    } 
    i i1 = this.e;
    if (i1 != null)
      j = i.l(i1.n()); 
    return (((n * 31 + k) * 31 + b) * 31 + j) * 31 + this.f.hashCode();
  }
  
  public e i() {
    return new e(this.b, this.c, this.d, this.e, this.f, null);
  }
  
  public void k(e parame) {
    parame.w2(this.b, this.c, this.d, this.e, this.f);
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compose\foundation\ClickableElement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */