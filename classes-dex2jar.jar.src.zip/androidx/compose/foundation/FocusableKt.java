package androidx.compose.foundation;

import androidx.compose.ui.d;
import androidx.compose.ui.focus.d;
import dbxyzptlk.CI.l;
import dbxyzptlk.DI.u;
import dbxyzptlk.c0.t;
import dbxyzptlk.f0.m;
import dbxyzptlk.f1.G;
import dbxyzptlk.g1.o0;
import dbxyzptlk.g1.p0;
import dbxyzptlk.g1.r0;
import dbxyzptlk.pI.D;
import kotlin.Metadata;

@Metadata(d1 = {"\000!\n\002\030\002\n\002\020\013\n\000\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\002\n\002\b\005*\001\013\032'\020\005\032\0020\000*\0020\0002\b\b\002\020\002\032\0020\0012\n\b\002\020\004\032\004\030\0010\003¢\006\004\b\005\020\006\032%\020\007\032\0020\000*\0020\0002\006\020\002\032\0020\0012\b\020\004\032\004\030\0010\003H\000¢\006\004\b\007\020\006\"\024\020\n\032\0020\b8\002X\004¢\006\006\n\004\b\005\020\t\"\024\020\016\032\0020\0138\002X\004¢\006\006\n\004\b\f\020\r¨\006\017"}, d2 = {"Landroidx/compose/ui/d;", "", "enabled", "Ldbxyzptlk/f0/m;", "interactionSource", "a", "(Landroidx/compose/ui/d;ZLdbxyzptlk/f0/m;)Landroidx/compose/ui/d;", "c", "Ldbxyzptlk/g1/o0;", "Ldbxyzptlk/g1/o0;", "focusGroupInspectorInfo", "androidx/compose/foundation/FocusableKt$FocusableInNonTouchModeElement$1", "b", "Landroidx/compose/foundation/FocusableKt$FocusableInNonTouchModeElement$1;", "FocusableInNonTouchModeElement", "foundation_release"}, k = 2, mv = {1, 8, 0}, xi = 48)
public final class FocusableKt {
  public static final o0 a;
  
  public static final FocusableKt$FocusableInNonTouchModeElement$1 b = new FocusableKt$FocusableInNonTouchModeElement$1();
  
  public static final d a(d paramd, boolean paramBoolean, m paramm) {
    d.a a;
    if (paramBoolean) {
      d d1 = d.a((d)new FocusableElement(paramm));
    } else {
      a = d.a;
    } 
    return paramd.g((d)a);
  }
  
  public static final d c(d paramd, boolean paramBoolean, m paramm) {
    return p0.b(paramd, new a(paramBoolean, paramm), a(d.a.g((d)b), paramBoolean, paramm));
  }
  
  static {
    l l;
    if (p0.c()) {
      b b = new b();
    } else {
      l = p0.a();
    } 
    a = new o0(l);
  }
  
  @Metadata(d1 = {"\000/\n\000\n\002\030\002\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\002\n\002\020\b\n\002\b\002\n\002\020\000\n\000\n\002\020\013\n\002\b\003*\001\000\b\n\030\0002\b\022\004\022\0020\0020\001J\017\020\003\032\0020\002H\026¢\006\004\b\003\020\004J\027\020\007\032\0020\0062\006\020\005\032\0020\002H\026¢\006\004\b\007\020\bJ\017\020\n\032\0020\tH\026¢\006\004\b\n\020\013J\032\020\017\032\0020\0162\b\020\r\032\004\030\0010\fH\002¢\006\004\b\017\020\020¨\006\021"}, d2 = {"androidx/compose/foundation/FocusableKt$FocusableInNonTouchModeElement$1", "Ldbxyzptlk/f1/G;", "Ldbxyzptlk/c0/t;", "i", "()Ldbxyzptlk/c0/t;", "node", "Ldbxyzptlk/pI/D;", "k", "(Ldbxyzptlk/c0/t;)V", "", "hashCode", "()I", "", "other", "", "equals", "(Ljava/lang/Object;)Z", "foundation_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class FocusableKt$FocusableInNonTouchModeElement$1 extends G<t> {
    public boolean equals(Object param1Object) {
      boolean bool;
      if (this == param1Object) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    public int hashCode() {
      return System.identityHashCode(this);
    }
    
    public t i() {
      return new t();
    }
    
    public void k(t param1t) {}
  }
  
  @Metadata(d1 = {"\000\f\n\002\030\002\n\002\030\002\n\002\b\002\020\002\032\0020\001*\0020\000H\n¢\006\004\b\002\020\003"}, d2 = {"Ldbxyzptlk/g1/r0;", "Ldbxyzptlk/pI/D;", "a", "(Ldbxyzptlk/g1/r0;)V"}, k = 3, mv = {1, 8, 0})
  public static final class a extends u implements l<r0, D> {
    public final boolean f;
    
    public final m g;
    
    public a(boolean param1Boolean, m param1m) {
      super(1);
    }
    
    public final void a(r0 param1r0) {
      param1r0.b("focusableInNonTouchMode");
      param1r0.a().b("enabled", Boolean.valueOf(this.f));
      param1r0.a().b("interactionSource", this.g);
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compose\foundation\FocusableKt.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */