package androidx.compose.foundation;

import androidx.compose.ui.d;
import dbxyzptlk.CI.l;
import dbxyzptlk.DI.s;
import dbxyzptlk.Q0.a1;
import dbxyzptlk.Q0.h0;
import dbxyzptlk.Q0.r0;
import dbxyzptlk.c0.d;
import dbxyzptlk.f1.G;
import dbxyzptlk.g1.r0;
import dbxyzptlk.pI.D;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

@Metadata(d1 = {"\000J\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020\007\n\000\n\002\030\002\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\b\n\002\020\b\n\002\b\002\n\002\020\000\n\000\n\002\020\013\n\002\b\r\b\002\030\0002\b\022\004\022\0020\0020\001BA\022\b\b\002\020\004\032\0020\003\022\n\b\002\020\006\032\004\030\0010\005\022\006\020\b\032\0020\007\022\006\020\n\032\0020\t\022\022\020\016\032\016\022\004\022\0020\f\022\004\022\0020\r0\013¢\006\004\b\017\020\020J\017\020\021\032\0020\002H\026¢\006\004\b\021\020\022J\027\020\024\032\0020\r2\006\020\023\032\0020\002H\026¢\006\004\b\024\020\025J\017\020\027\032\0020\026H\026¢\006\004\b\027\020\030J\032\020\034\032\0020\0332\b\020\032\032\004\030\0010\031H\002¢\006\004\b\034\020\035R\032\020\004\032\0020\0038\002X\004ø\001\000ø\001\001¢\006\006\n\004\b\036\020\037R\026\020\006\032\004\030\0010\0058\002X\004¢\006\006\n\004\b \020!R\024\020\b\032\0020\0078\002X\004¢\006\006\n\004\b\"\020#R\024\020\n\032\0020\t8\002X\004¢\006\006\n\004\b$\020%R \020\016\032\016\022\004\022\0020\f\022\004\022\0020\r0\0138\002X\004¢\006\006\n\004\b&\020'\002\013\n\005\b¡\0360\001\n\002\b!¨\006("}, d2 = {"Landroidx/compose/foundation/BackgroundElement;", "Ldbxyzptlk/f1/G;", "Ldbxyzptlk/c0/d;", "Ldbxyzptlk/Q0/r0;", "color", "Ldbxyzptlk/Q0/h0;", "brush", "", "alpha", "Ldbxyzptlk/Q0/a1;", "shape", "Lkotlin/Function1;", "Ldbxyzptlk/g1/r0;", "Ldbxyzptlk/pI/D;", "inspectorInfo", "<init>", "(JLdbxyzptlk/Q0/h0;FLdbxyzptlk/Q0/a1;Ldbxyzptlk/CI/l;Lkotlin/jvm/internal/DefaultConstructorMarker;)V", "i", "()Ldbxyzptlk/c0/d;", "node", "k", "(Ldbxyzptlk/c0/d;)V", "", "hashCode", "()I", "", "other", "", "equals", "(Ljava/lang/Object;)Z", "b", "J", "c", "Ldbxyzptlk/Q0/h0;", "d", "F", "e", "Ldbxyzptlk/Q0/a1;", "f", "Ldbxyzptlk/CI/l;", "foundation_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
final class BackgroundElement extends G<d> {
  public final long b;
  
  public final h0 c;
  
  public final float d;
  
  public final a1 e;
  
  public final l<r0, D> f;
  
  public BackgroundElement(long paramLong, h0 paramh0, float paramFloat, a1 parama1, l<? super r0, D> paraml) {
    this.b = paramLong;
    this.c = paramh0;
    this.d = paramFloat;
    this.e = parama1;
    this.f = (l)paraml;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject instanceof BackgroundElement) {
      paramObject = paramObject;
    } else {
      paramObject = null;
    } 
    boolean bool2 = false;
    if (paramObject == null)
      return false; 
    boolean bool1 = bool2;
    if (r0.r(this.b, ((BackgroundElement)paramObject).b)) {
      bool1 = bool2;
      if (s.c(this.c, ((BackgroundElement)paramObject).c)) {
        bool1 = bool2;
        if (this.d == ((BackgroundElement)paramObject).d) {
          bool1 = bool2;
          if (s.c(this.e, ((BackgroundElement)paramObject).e))
            bool1 = true; 
        } 
      } 
    } 
    return bool1;
  }
  
  public int hashCode() {
    byte b;
    int i = r0.x(this.b);
    h0 h01 = this.c;
    if (h01 != null) {
      b = h01.hashCode();
    } else {
      b = 0;
    } 
    return ((i * 31 + b) * 31 + Float.hashCode(this.d)) * 31 + this.e.hashCode();
  }
  
  public d i() {
    return new d(this.b, this.c, this.d, this.e, null);
  }
  
  public void k(d paramd) {
    paramd.n2(this.b);
    paramd.m2(this.c);
    paramd.setAlpha(this.d);
    paramd.Z0(this.e);
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compose\foundation\BackgroundElement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */