package androidx.compose.foundation;

import androidx.compose.foundation.gestures.a;
import dbxyzptlk.CI.p;
import dbxyzptlk.DI.u;
import dbxyzptlk.a1.J;
import dbxyzptlk.a1.T;
import dbxyzptlk.a1.U;
import dbxyzptlk.a1.p;
import dbxyzptlk.a1.r;
import dbxyzptlk.c0.m;
import dbxyzptlk.d0.v;
import dbxyzptlk.e1.c;
import dbxyzptlk.e1.h;
import dbxyzptlk.f0.m;
import dbxyzptlk.f1.X;
import dbxyzptlk.f1.e;
import dbxyzptlk.f1.g;
import dbxyzptlk.f1.i;
import dbxyzptlk.pI.D;
import dbxyzptlk.pI.p;
import dbxyzptlk.tI.d;
import dbxyzptlk.uI.c;
import dbxyzptlk.vI.f;
import dbxyzptlk.vI.l;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

@Metadata(d1 = {"\000l\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\013\n\000\n\002\030\002\n\000\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\005\n\002\030\002\n\002\030\002\n\002\b\034\n\002\030\002\n\002\b\003\n\002\030\002\n\002\030\002\n\000\b2\030\0002\0020\0012\0020\0022\0020\0032\0020\004B1\b\004\022\006\020\006\032\0020\005\022\b\020\b\032\004\030\0010\007\022\f\020\013\032\b\022\004\022\0020\n0\t\022\006\020\r\032\0020\f¢\006\004\b\016\020\017J\024\020\021\032\0020\n*\0020\020H¤@¢\006\004\b\021\020\022J*\020\031\032\0020\n2\006\020\024\032\0020\0232\006\020\026\032\0020\0252\006\020\030\032\0020\027H\026ø\001\000¢\006\004\b\031\020\032J\017\020\033\032\0020\nH\026¢\006\004\b\033\020\034J\037\020 \032\0020\n*\0020\0352\006\020\037\032\0020\036H@ø\001\000¢\006\004\b \020!J\017\020\"\032\0020\nH\004¢\006\004\b\"\020\034R\"\020\006\032\0020\0058\004@\004X\016¢\006\022\n\004\b#\020$\032\004\b%\020&\"\004\b'\020(R$\020\b\032\004\030\0010\0078\004@\004X\016¢\006\022\n\004\b)\020*\032\004\b+\020,\"\004\b-\020.R(\020\013\032\b\022\004\022\0020\n0\t8\004@\004X\016¢\006\022\n\004\b/\0200\032\004\b1\0202\"\004\b3\0204R\032\020\r\032\0020\f8\004X\004¢\006\f\n\004\b5\0206\032\004\b7\0208R\032\020:\032\b\022\004\022\0020\0050\t8\002X\004¢\006\006\n\004\b9\0200R\024\020>\032\0020;8\002X\004¢\006\006\n\004\b<\020=\001\002?@\002\007\n\005\b¡\0360\001¨\006A"}, d2 = {"Landroidx/compose/foundation/b;", "Ldbxyzptlk/f1/i;", "Ldbxyzptlk/e1/h;", "Ldbxyzptlk/f1/e;", "Ldbxyzptlk/f1/X;", "", "enabled", "Ldbxyzptlk/f0/m;", "interactionSource", "Lkotlin/Function0;", "Ldbxyzptlk/pI/D;", "onClick", "Landroidx/compose/foundation/a$a;", "interactionData", "<init>", "(ZLdbxyzptlk/f0/m;Ldbxyzptlk/CI/a;Landroidx/compose/foundation/a$a;)V", "Ldbxyzptlk/a1/J;", "t2", "(Ldbxyzptlk/a1/J;Ldbxyzptlk/tI/d;)Ljava/lang/Object;", "Ldbxyzptlk/a1/p;", "pointerEvent", "Ldbxyzptlk/a1/r;", "pass", "Ldbxyzptlk/z1/r;", "bounds", "f1", "(Ldbxyzptlk/a1/p;Ldbxyzptlk/a1/r;J)V", "p0", "()V", "Ldbxyzptlk/d0/v;", "Ldbxyzptlk/P0/f;", "offset", "s2", "(Ldbxyzptlk/d0/v;JLdbxyzptlk/tI/d;)Ljava/lang/Object;", "b1", "p", "Z", "p2", "()Z", "u2", "(Z)V", "q", "Ldbxyzptlk/f0/m;", "getInteractionSource", "()Ldbxyzptlk/f0/m;", "v2", "(Ldbxyzptlk/f0/m;)V", "r", "Ldbxyzptlk/CI/a;", "r2", "()Ldbxyzptlk/CI/a;", "w2", "(Ldbxyzptlk/CI/a;)V", "s", "Landroidx/compose/foundation/a$a;", "q2", "()Landroidx/compose/foundation/a$a;", "t", "delayPressInteraction", "Ldbxyzptlk/a1/U;", "u", "Ldbxyzptlk/a1/U;", "pointerInputNode", "Landroidx/compose/foundation/f;", "Landroidx/compose/foundation/h;", "foundation_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public abstract class b extends i implements h, e, X {
  public boolean p;
  
  public m q;
  
  public dbxyzptlk.CI.a<D> r;
  
  public final a.a s;
  
  public final dbxyzptlk.CI.a<Boolean> t;
  
  public final U u;
  
  public b(boolean paramBoolean, m paramm, dbxyzptlk.CI.a<D> parama, a.a parama1) {
    this.p = paramBoolean;
    this.q = paramm;
    this.r = parama;
    this.s = parama1;
    this.t = new a(this);
    this.u = (U)k2((g)T.a(new b(this, null)));
  }
  
  public final void b1() {
    this.u.b1();
  }
  
  public void f1(p paramp, r paramr, long paramLong) {
    this.u.f1(paramp, paramr, paramLong);
  }
  
  public void p0() {
    this.u.p0();
  }
  
  public final boolean p2() {
    return this.p;
  }
  
  public final a.a q2() {
    return this.s;
  }
  
  public final dbxyzptlk.CI.a<D> r2() {
    return this.r;
  }
  
  public final Object s2(v paramv, long paramLong, d<? super D> paramd) {
    m m1 = this.q;
    if (m1 != null) {
      Object object = d.a(paramv, paramLong, m1, this.s, this.t, paramd);
      if (object == c.g())
        return object; 
    } 
    return D.a;
  }
  
  public abstract Object t2(J paramJ, d<? super D> paramd);
  
  public final void u2(boolean paramBoolean) {
    this.p = paramBoolean;
  }
  
  public final void v2(m paramm) {
    this.q = paramm;
  }
  
  public final void w2(dbxyzptlk.CI.a<D> parama) {
    this.r = parama;
  }
  
  @Metadata(d1 = {"\000\b\n\002\020\013\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"", "b", "()Ljava/lang/Boolean;"}, k = 3, mv = {1, 8, 0})
  public static final class a extends u implements dbxyzptlk.CI.a<Boolean> {
    public final b f;
    
    public a(b param1b) {
      super(0);
    }
    
    public final Boolean b() {
      if (((Boolean)this.f.b((c)a.h())).booleanValue() || m.c(this.f)) {
        boolean bool1 = true;
        return Boolean.valueOf(bool1);
      } 
      boolean bool = false;
      return Boolean.valueOf(bool);
    }
  }
  
  @f(c = "androidx.compose.foundation.AbstractClickablePointerInputNode$pointerInputNode$1", f = "Clickable.kt", l = {938}, m = "invokeSuspend")
  @Metadata(d1 = {"\000\f\n\002\030\002\n\002\030\002\n\002\b\002\020\002\032\0020\001*\0020\000H@¢\006\004\b\002\020\003"}, d2 = {"Ldbxyzptlk/a1/J;", "Ldbxyzptlk/pI/D;", "<anonymous>", "(Ldbxyzptlk/a1/J;)V"}, k = 3, mv = {1, 8, 0})
  public static final class b extends l implements p<J, d<? super D>, Object> {
    public int t;
    
    public Object u;
    
    public final b v;
    
    public b(b param1b, d<? super b> param1d) {
      super(2, param1d);
    }
    
    public final Object a(J param1J, d<? super D> param1d) {
      return ((b)create(param1J, param1d)).invokeSuspend(D.a);
    }
    
    public final d<D> create(Object param1Object, d<?> param1d) {
      b b1 = new b(this.v, (d)param1d);
      b1.u = param1Object;
      return (d<D>)b1;
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = c.g();
      int i = this.t;
      if (i != 0) {
        if (i == 1) {
          p.b(param1Object);
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        p.b(param1Object);
        J j = (J)this.u;
        param1Object = this.v;
        this.t = 1;
        if (param1Object.t2(j, (d<? super D>)this) == object)
          return object; 
      } 
      return D.a;
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compose\foundation\b.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */