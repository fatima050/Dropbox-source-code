package androidx.compose.foundation;

import androidx.compose.ui.d;
import dbxyzptlk.DI.s;
import dbxyzptlk.c0.v;
import dbxyzptlk.f0.m;
import dbxyzptlk.f1.G;
import kotlin.Metadata;

@Metadata(d1 = {"\0002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\006\n\002\030\002\n\002\b\002\n\002\020\000\n\000\n\002\020\013\n\002\b\002\n\002\020\b\n\002\b\005\b\002\030\0002\b\022\004\022\0020\0020\001B\021\022\b\020\004\032\004\030\0010\003¢\006\004\b\005\020\006J\017\020\007\032\0020\002H\026¢\006\004\b\007\020\bJ\027\020\013\032\0020\n2\006\020\t\032\0020\002H\026¢\006\004\b\013\020\fJ\032\020\020\032\0020\0172\b\020\016\032\004\030\0010\rH\002¢\006\004\b\020\020\021J\017\020\023\032\0020\022H\026¢\006\004\b\023\020\024R\026\020\004\032\004\030\0010\0038\002X\004¢\006\006\n\004\b\025\020\026¨\006\027"}, d2 = {"Landroidx/compose/foundation/FocusableElement;", "Ldbxyzptlk/f1/G;", "Ldbxyzptlk/c0/v;", "Ldbxyzptlk/f0/m;", "interactionSource", "<init>", "(Ldbxyzptlk/f0/m;)V", "i", "()Ldbxyzptlk/c0/v;", "node", "Ldbxyzptlk/pI/D;", "k", "(Ldbxyzptlk/c0/v;)V", "", "other", "", "equals", "(Ljava/lang/Object;)Z", "", "hashCode", "()I", "b", "Ldbxyzptlk/f0/m;", "foundation_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
final class FocusableElement extends G<v> {
  public final m b;
  
  public FocusableElement(m paramm) {
    this.b = paramm;
  }
  
  public boolean equals(Object paramObject) {
    return (this == paramObject) ? true : (!(paramObject instanceof FocusableElement) ? false : (!!s.c(this.b, ((FocusableElement)paramObject).b)));
  }
  
  public int hashCode() {
    boolean bool;
    m m1 = this.b;
    if (m1 != null) {
      bool = m1.hashCode();
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public v i() {
    return new v(this.b);
  }
  
  public void k(v paramv) {
    paramv.q2(this.b);
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compose\foundation\FocusableElement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */