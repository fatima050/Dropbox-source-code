package androidx.compose.foundation.gestures;

import android.view.KeyEvent;
import androidx.compose.ui.d;
import androidx.compose.ui.focus.e;
import dbxyzptlk.CI.l;
import dbxyzptlk.CI.p;
import dbxyzptlk.DI.u;
import dbxyzptlk.O0.k;
import dbxyzptlk.O0.s;
import dbxyzptlk.P0.g;
import dbxyzptlk.X.D;
import dbxyzptlk.Y0.c;
import dbxyzptlk.Y0.d;
import dbxyzptlk.Y0.e;
import dbxyzptlk.Z0.d;
import dbxyzptlk.bK.h;
import dbxyzptlk.c0.A;
import dbxyzptlk.c0.S;
import dbxyzptlk.d0.C;
import dbxyzptlk.d0.D;
import dbxyzptlk.d0.E;
import dbxyzptlk.d0.G;
import dbxyzptlk.d0.f;
import dbxyzptlk.d0.g;
import dbxyzptlk.d0.h;
import dbxyzptlk.d0.p;
import dbxyzptlk.d0.r;
import dbxyzptlk.d0.t;
import dbxyzptlk.d1.r;
import dbxyzptlk.f0.m;
import dbxyzptlk.f1.N;
import dbxyzptlk.f1.O;
import dbxyzptlk.f1.e;
import dbxyzptlk.f1.f;
import dbxyzptlk.f1.g;
import dbxyzptlk.f1.i;
import dbxyzptlk.g1.d0;
import dbxyzptlk.l0.g;
import dbxyzptlk.l0.i;
import dbxyzptlk.pI.D;
import dbxyzptlk.x0.t;
import dbxyzptlk.z1.d;
import dbxyzptlk.z1.r;
import kotlin.Metadata;

@Metadata(d1 = {"\000\001\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020\013\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\022\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\006\b\002\030\0002\0020\0012\0020\0022\0020\0032\0020\0042\0020\005BM\022\006\020\007\032\0020\006\022\006\020\t\032\0020\b\022\b\020\013\032\004\030\0010\n\022\006\020\r\032\0020\f\022\006\020\016\032\0020\f\022\b\020\020\032\004\030\0010\017\022\b\020\022\032\004\030\0010\021\022\006\020\024\032\0020\023¢\006\004\b\025\020\026JS\020\030\032\0020\0272\006\020\007\032\0020\0062\006\020\t\032\0020\b2\b\020\013\032\004\030\0010\n2\006\020\r\032\0020\f2\006\020\016\032\0020\f2\b\020\020\032\004\030\0010\0172\b\020\022\032\004\030\0010\0212\006\020\024\032\0020\023¢\006\004\b\030\020\026J\017\020\031\032\0020\027H\026¢\006\004\b\031\020\032J\017\020\033\032\0020\027H\026¢\006\004\b\033\020\032J\027\020\036\032\0020\0272\006\020\035\032\0020\034H\026¢\006\004\b\036\020\037J\032\020\"\032\0020\f2\006\020!\032\0020 H\026ø\001\000¢\006\004\b\"\020#J\032\020$\032\0020\f2\006\020!\032\0020 H\026ø\001\000¢\006\004\b$\020#J\017\020%\032\0020\027H\002¢\006\004\b%\020\032R\026\020\007\032\0020\0068\002@\002X\016¢\006\006\n\004\b&\020'R\026\020\t\032\0020\b8\002@\002X\016¢\006\006\n\004\b(\020)R\030\020\013\032\004\030\0010\n8\002@\002X\016¢\006\006\n\004\b*\020+R\026\020\r\032\0020\f8\002@\002X\016¢\006\006\n\004\b,\020-R\026\020\016\032\0020\f8\002@\002X\016¢\006\006\n\004\b.\020-R\030\020\020\032\004\030\0010\0178\002@\002X\016¢\006\006\n\004\b/\0200R\030\020\022\032\004\030\0010\0218\002@\002X\016¢\006\006\n\004\b1\0202R\027\0208\032\002038\006¢\006\f\n\004\b4\0205\032\004\b6\0207R\027\020>\032\002098\006¢\006\f\n\004\b:\020;\032\004\b<\020=R\027\020D\032\0020?8\006¢\006\f\n\004\b@\020A\032\004\bB\020CR\027\020J\032\0020E8\006¢\006\f\n\004\bF\020G\032\004\bH\020IR\027\020P\032\0020K8\006¢\006\f\n\004\bL\020M\032\004\bN\020OR\027\020V\032\0020Q8\006¢\006\f\n\004\bR\020S\032\004\bT\020UR\027\020\\\032\0020W8\006¢\006\f\n\004\bX\020Y\032\004\bZ\020[\002\007\n\005\b¡\0360\001¨\006]"}, d2 = {"Landroidx/compose/foundation/gestures/b;", "Ldbxyzptlk/f1/i;", "Ldbxyzptlk/f1/N;", "Ldbxyzptlk/f1/e;", "Ldbxyzptlk/O0/k;", "Ldbxyzptlk/Y0/e;", "Ldbxyzptlk/d0/E;", "state", "Ldbxyzptlk/d0/t;", "orientation", "Ldbxyzptlk/c0/S;", "overscrollEffect", "", "enabled", "reverseDirection", "Ldbxyzptlk/d0/p;", "flingBehavior", "Ldbxyzptlk/f0/m;", "interactionSource", "Ldbxyzptlk/d0/f;", "bringIntoViewSpec", "<init>", "(Ldbxyzptlk/d0/E;Ldbxyzptlk/d0/t;Ldbxyzptlk/c0/S;ZZLdbxyzptlk/d0/p;Ldbxyzptlk/f0/m;Ldbxyzptlk/d0/f;)V", "Ldbxyzptlk/pI/D;", "q2", "U1", "()V", "U0", "Landroidx/compose/ui/focus/e;", "focusProperties", "j1", "(Landroidx/compose/ui/focus/e;)V", "Ldbxyzptlk/Y0/b;", "event", "k1", "(Landroid/view/KeyEvent;)Z", "e0", "r2", "p", "Ldbxyzptlk/d0/E;", "q", "Ldbxyzptlk/d0/t;", "r", "Ldbxyzptlk/c0/S;", "s", "Z", "t", "u", "Ldbxyzptlk/d0/p;", "v", "Ldbxyzptlk/f0/m;", "Ldbxyzptlk/Z0/b;", "w", "Ldbxyzptlk/Z0/b;", "getNestedScrollDispatcher", "()Ldbxyzptlk/Z0/b;", "nestedScrollDispatcher", "Ldbxyzptlk/d0/h;", "x", "Ldbxyzptlk/d0/h;", "getDefaultFlingBehavior", "()Ldbxyzptlk/d0/h;", "defaultFlingBehavior", "Ldbxyzptlk/d0/G;", "y", "Ldbxyzptlk/d0/G;", "getScrollingLogic", "()Ldbxyzptlk/d0/G;", "scrollingLogic", "Ldbxyzptlk/d0/D;", "z", "Ldbxyzptlk/d0/D;", "getNestedScrollConnection", "()Ldbxyzptlk/d0/D;", "nestedScrollConnection", "Ldbxyzptlk/d0/g;", "A", "Ldbxyzptlk/d0/g;", "p2", "()Ldbxyzptlk/d0/g;", "contentInViewNode", "Ldbxyzptlk/d0/r;", "B", "Ldbxyzptlk/d0/r;", "getScrollableContainer", "()Ldbxyzptlk/d0/r;", "scrollableContainer", "Ldbxyzptlk/d0/C;", "C", "Ldbxyzptlk/d0/C;", "getScrollableGesturesNode", "()Ldbxyzptlk/d0/C;", "scrollableGesturesNode", "foundation_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class b extends i implements N, e, k, e {
  public final g A;
  
  public final r B;
  
  public final C C;
  
  public E p;
  
  public t q;
  
  public S r;
  
  public boolean s;
  
  public boolean t;
  
  public p u;
  
  public m v;
  
  public final dbxyzptlk.Z0.b w;
  
  public final h x;
  
  public final G y;
  
  public final D z;
  
  public b(E paramE, t paramt, S paramS, boolean paramBoolean1, boolean paramBoolean2, p paramp, m paramm, f paramf) {
    h h1;
    this.p = paramE;
    this.q = paramt;
    this.r = paramS;
    this.s = paramBoolean1;
    this.t = paramBoolean2;
    this.u = paramp;
    this.v = paramm;
    dbxyzptlk.Z0.b b1 = new dbxyzptlk.Z0.b();
    this.w = b1;
    h h2 = new h(D.c(a.e()), null, 2, null);
    this.x = h2;
    E e1 = this.p;
    t t1 = this.q;
    S s = this.r;
    paramBoolean1 = this.t;
    p p2 = this.u;
    p p1 = p2;
    if (p2 == null)
      h1 = h2; 
    G g1 = new G(e1, t1, s, paramBoolean1, (p)h1, b1);
    this.y = g1;
    D d = new D(g1, this.s);
    this.z = d;
    g g2 = (g)k2((g)new g(this.q, this.p, this.t, paramf));
    this.A = g2;
    this.B = (r)k2((g)new r(this.s));
    k2(d.b((dbxyzptlk.Z0.a)d, b1));
    k2((g)s.a());
    k2((g)new i((g)g2));
    k2((g)new A(new a(this)));
    m m1 = this.v;
    this.C = (C)k2((g)new C(g1, this.q, this.s, b1, m1));
  }
  
  public void U0() {
    r2();
  }
  
  public void U1() {
    r2();
    O.a((d.c)this, new b(this));
  }
  
  public boolean e0(KeyEvent paramKeyEvent) {
    return false;
  }
  
  public void j1(e parame) {
    parame.i(false);
  }
  
  public boolean k1(KeyEvent paramKeyEvent) {
    if (this.s) {
      long l = d.a(paramKeyEvent);
      dbxyzptlk.Y0.a.a a = dbxyzptlk.Y0.a.b;
      if ((dbxyzptlk.Y0.a.q(l, a.k()) || dbxyzptlk.Y0.a.q(d.a(paramKeyEvent), a.l())) && c.e(d.b(paramKeyEvent), c.a.a()) && !d.e(paramKeyEvent)) {
        G g1 = this.y;
        if (this.q == t.Vertical) {
          float f;
          int j = r.g(this.A.B2());
          if (dbxyzptlk.Y0.a.q(d.a(paramKeyEvent), a.l())) {
            f = j;
          } else {
            f = -(j);
          } 
          l = g.a(0.0F, f);
        } else {
          float f;
          int j = r.h(this.A.B2());
          if (dbxyzptlk.Y0.a.q(d.a(paramKeyEvent), a.l())) {
            f = j;
          } else {
            f = -(j);
          } 
          l = g.a(f, 0.0F);
        } 
        h.d(K1(), null, null, (p)new c(g1, l, null), 3, null);
        return true;
      } 
    } 
    return false;
  }
  
  public final g p2() {
    return this.A;
  }
  
  public final void q2(E paramE, t paramt, S paramS, boolean paramBoolean1, boolean paramBoolean2, p paramp, m paramm, f paramf) {
    p p1;
    if (this.s != paramBoolean1) {
      this.z.a(paramBoolean1);
      this.B.k2(paramBoolean1);
    } 
    if (paramp == null) {
      h h1 = this.x;
    } else {
      p1 = paramp;
    } 
    this.y.r(paramE, paramt, paramS, paramBoolean2, p1, this.w);
    this.C.r2(paramt, paramBoolean1, paramm);
    this.A.H2(paramt, paramE, paramBoolean2, paramf);
    this.p = paramE;
    this.q = paramt;
    this.r = paramS;
    this.s = paramBoolean1;
    this.t = paramBoolean2;
    this.u = paramp;
    this.v = paramm;
  }
  
  public final void r2() {
    d d = (d)f.a(this, (t)d0.e());
    this.x.d(D.c(d));
  }
  
  @Metadata(d1 = {"\000\016\n\002\030\002\n\000\n\002\030\002\n\002\b\002\020\003\032\0020\0022\b\020\001\032\004\030\0010\000H\n¢\006\004\b\003\020\004"}, d2 = {"Ldbxyzptlk/d1/r;", "it", "Ldbxyzptlk/pI/D;", "a", "(Ldbxyzptlk/d1/r;)V"}, k = 3, mv = {1, 8, 0})
  public static final class a extends u implements l<r, D> {
    public final b f;
    
    public a(b param1b) {
      super(1);
    }
    
    public final void a(r param1r) {
      this.f.p2().F2(param1r);
    }
  }
  
  @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"Ldbxyzptlk/pI/D;", "b", "()V"}, k = 3, mv = {1, 8, 0})
  public static final class b extends u implements dbxyzptlk.CI.a<D> {
    public final b f;
    
    public b(b param1b) {
      super(0);
    }
    
    public final void b() {
      f.a(this.f, (t)d0.e());
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compose\foundation\gestures\b.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */