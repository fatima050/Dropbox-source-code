package androidx.compose.foundation.gestures;

import androidx.compose.ui.d;
import dbxyzptlk.CI.a;
import dbxyzptlk.CI.l;
import dbxyzptlk.CI.q;
import dbxyzptlk.DI.s;
import dbxyzptlk.P0.f;
import dbxyzptlk.a1.A;
import dbxyzptlk.bK.J;
import dbxyzptlk.d0.n;
import dbxyzptlk.d0.o;
import dbxyzptlk.d0.t;
import dbxyzptlk.f0.m;
import dbxyzptlk.f1.G;
import dbxyzptlk.pI.D;
import dbxyzptlk.tI.d;
import dbxyzptlk.z1.y;
import kotlin.Metadata;

@Metadata(d1 = {"\000^\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\030\002\n\002\020\013\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\000\n\000\n\002\030\002\n\002\b\f\n\002\020\b\n\002\b\022\b\000\030\0002\b\022\004\022\0020\0020\001B§\001\022\006\020\004\032\0020\003\022\022\020\b\032\016\022\004\022\0020\006\022\004\022\0020\0070\005\022\006\020\n\032\0020\t\022\006\020\013\032\0020\007\022\b\020\r\032\004\030\0010\f\022\f\020\017\032\b\022\004\022\0020\0070\016\022(\020\026\032$\b\001\022\004\022\0020\021\022\004\022\0020\022\022\n\022\b\022\004\022\0020\0240\023\022\006\022\004\030\0010\0250\020\022(\020\030\032$\b\001\022\004\022\0020\021\022\004\022\0020\027\022\n\022\b\022\004\022\0020\0240\023\022\006\022\004\030\0010\0250\020\022\006\020\031\032\0020\007¢\006\004\b\032\020\033J\017\020\034\032\0020\002H\026¢\006\004\b\034\020\035J\027\020\037\032\0020\0242\006\020\036\032\0020\002H\026¢\006\004\b\037\020 J\032\020\"\032\0020\0072\b\020!\032\004\030\0010\025H\002¢\006\004\b\"\020#J\017\020%\032\0020$H\026¢\006\004\b%\020&R\024\020\004\032\0020\0038\002X\004¢\006\006\n\004\b'\020(R \020\b\032\016\022\004\022\0020\006\022\004\022\0020\0070\0058\002X\004¢\006\006\n\004\b)\020*R\024\020\n\032\0020\t8\002X\004¢\006\006\n\004\b+\020,R\024\020\013\032\0020\0078\002X\004¢\006\006\n\004\b-\020.R\026\020\r\032\004\030\0010\f8\002X\004¢\006\006\n\004\b/\0200R\032\020\017\032\b\022\004\022\0020\0070\0168\002X\004¢\006\006\n\004\b1\0202R6\020\026\032$\b\001\022\004\022\0020\021\022\004\022\0020\022\022\n\022\b\022\004\022\0020\0240\023\022\006\022\004\030\0010\0250\0208\002X\004¢\006\006\n\004\b3\0204R6\020\030\032$\b\001\022\004\022\0020\021\022\004\022\0020\027\022\n\022\b\022\004\022\0020\0240\023\022\006\022\004\030\0010\0250\0208\002X\004¢\006\006\n\004\b\034\0204R\024\020\031\032\0020\0078\002X\004¢\006\006\n\004\b5\020.¨\0066"}, d2 = {"Landroidx/compose/foundation/gestures/DraggableElement;", "Ldbxyzptlk/f1/G;", "Ldbxyzptlk/d0/n;", "Ldbxyzptlk/d0/o;", "state", "Lkotlin/Function1;", "Ldbxyzptlk/a1/A;", "", "canDrag", "Ldbxyzptlk/d0/t;", "orientation", "enabled", "Ldbxyzptlk/f0/m;", "interactionSource", "Lkotlin/Function0;", "startDragImmediately", "Lkotlin/Function3;", "Ldbxyzptlk/bK/J;", "Ldbxyzptlk/P0/f;", "Ldbxyzptlk/tI/d;", "Ldbxyzptlk/pI/D;", "", "onDragStarted", "Ldbxyzptlk/z1/y;", "onDragStopped", "reverseDirection", "<init>", "(Ldbxyzptlk/d0/o;Ldbxyzptlk/CI/l;Ldbxyzptlk/d0/t;ZLdbxyzptlk/f0/m;Ldbxyzptlk/CI/a;Ldbxyzptlk/CI/q;Ldbxyzptlk/CI/q;Z)V", "i", "()Ldbxyzptlk/d0/n;", "node", "k", "(Ldbxyzptlk/d0/n;)V", "other", "equals", "(Ljava/lang/Object;)Z", "", "hashCode", "()I", "b", "Ldbxyzptlk/d0/o;", "c", "Ldbxyzptlk/CI/l;", "d", "Ldbxyzptlk/d0/t;", "e", "Z", "f", "Ldbxyzptlk/f0/m;", "g", "Ldbxyzptlk/CI/a;", "h", "Ldbxyzptlk/CI/q;", "j", "foundation_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class DraggableElement extends G<n> {
  public final o b;
  
  public final l<A, Boolean> c;
  
  public final t d;
  
  public final boolean e;
  
  public final m f;
  
  public final a<Boolean> g;
  
  public final q<J, f, d<? super D>, Object> h;
  
  public final q<J, y, d<? super D>, Object> i;
  
  public final boolean j;
  
  public DraggableElement(o paramo, l<? super A, Boolean> paraml, t paramt, boolean paramBoolean1, m paramm, a<Boolean> parama, q<? super J, ? super f, ? super d<? super D>, ? extends Object> paramq, q<? super J, ? super y, ? super d<? super D>, ? extends Object> paramq1, boolean paramBoolean2) {
    this.b = paramo;
    this.c = (l)paraml;
    this.d = paramt;
    this.e = paramBoolean1;
    this.f = paramm;
    this.g = parama;
    this.h = (q)paramq;
    this.i = (q)paramq1;
    this.j = paramBoolean2;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (paramObject == null)
      return false; 
    if (DraggableElement.class != paramObject.getClass())
      return false; 
    paramObject = paramObject;
    return !s.c(this.b, ((DraggableElement)paramObject).b) ? false : (!s.c(this.c, ((DraggableElement)paramObject).c) ? false : ((this.d != ((DraggableElement)paramObject).d) ? false : ((this.e != ((DraggableElement)paramObject).e) ? false : (!s.c(this.f, ((DraggableElement)paramObject).f) ? false : (!s.c(this.g, ((DraggableElement)paramObject).g) ? false : (!s.c(this.h, ((DraggableElement)paramObject).h) ? false : (!s.c(this.i, ((DraggableElement)paramObject).i) ? false : (!(this.j != ((DraggableElement)paramObject).j)))))))));
  }
  
  public int hashCode() {
    byte b;
    int j = this.b.hashCode();
    int i = this.c.hashCode();
    int k = this.d.hashCode();
    int n = Boolean.hashCode(this.e);
    m m1 = this.f;
    if (m1 != null) {
      b = m1.hashCode();
    } else {
      b = 0;
    } 
    return (((((((j * 31 + i) * 31 + k) * 31 + n) * 31 + b) * 31 + this.g.hashCode()) * 31 + this.h.hashCode()) * 31 + this.i.hashCode()) * 31 + Boolean.hashCode(this.j);
  }
  
  public n i() {
    return new n(this.b, this.c, this.d, this.e, this.f, this.g, this.h, this.i, this.j);
  }
  
  public void k(n paramn) {
    paramn.X2(this.b, this.c, this.d, this.e, this.f, this.g, this.h, this.i, this.j);
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compose\foundation\gestures\DraggableElement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */