package androidx.compose.foundation.gestures;

import dbxyzptlk.CI.l;
import dbxyzptlk.CI.p;
import dbxyzptlk.CI.q;
import dbxyzptlk.DI.u;
import dbxyzptlk.a1.A;
import dbxyzptlk.a1.O;
import dbxyzptlk.a1.p;
import dbxyzptlk.bK.J;
import dbxyzptlk.c0.S;
import dbxyzptlk.d0.A;
import dbxyzptlk.d0.B;
import dbxyzptlk.d0.E;
import dbxyzptlk.d0.p;
import dbxyzptlk.d0.t;
import dbxyzptlk.e1.l;
import dbxyzptlk.f0.m;
import dbxyzptlk.pI.D;
import dbxyzptlk.pI.p;
import dbxyzptlk.vI.l;
import kotlin.Metadata;

@Metadata(d1 = {"\000\001\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020\013\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\030\002\n\002\b\003\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\000\n\002\b\003\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\n\n\002\030\002\n\002\b\004\n\002\b\004*\001:\032O\020\f\032\0020\000*\0020\0002\006\020\002\032\0020\0012\006\020\004\032\0020\0032\b\b\002\020\006\032\0020\0052\b\b\002\020\007\032\0020\0052\n\b\002\020\t\032\004\030\0010\b2\n\b\002\020\013\032\004\030\0010\nH\007¢\006\004\b\f\020\r\032c\020\022\032\0020\000*\0020\0002\006\020\002\032\0020\0012\006\020\004\032\0020\0032\b\020\017\032\004\030\0010\0162\b\b\002\020\006\032\0020\0052\b\b\002\020\007\032\0020\0052\n\b\002\020\t\032\004\030\0010\b2\n\b\002\020\013\032\004\030\0010\n2\b\b\002\020\021\032\0020\020H\007¢\006\004\b\022\020\023\032\024\020\026\032\0020\025*\0020\024H@¢\006\004\b\026\020\027\" \020\034\032\016\022\004\022\0020\031\022\004\022\0020\0050\0308\002X\004¢\006\006\n\004\b\032\020\033\"6\020%\032$\b\001\022\004\022\0020\036\022\004\022\0020\037\022\n\022\b\022\004\022\0020!0 \022\006\022\004\030\0010\"0\0358\002X\004¢\006\006\n\004\b#\020$\"\024\020)\032\0020&8\002X\004¢\006\006\n\004\b'\020(\" \020/\032\b\022\004\022\0020\0050*8\000X\004¢\006\f\n\004\b+\020,\032\004\b-\020.\"\032\0204\032\0020\b8\000X\004¢\006\f\n\004\b0\0201\032\004\b2\0203\"\032\0209\032\002058\000X\004¢\006\f\n\004\b\026\0206\032\004\b7\0208\"\024\020<\032\0020:8\002X\004¢\006\006\n\004\b7\020;¨\006="}, d2 = {"Landroidx/compose/ui/d;", "Ldbxyzptlk/d0/E;", "state", "Ldbxyzptlk/d0/t;", "orientation", "", "enabled", "reverseDirection", "Ldbxyzptlk/d0/p;", "flingBehavior", "Ldbxyzptlk/f0/m;", "interactionSource", "j", "(Landroidx/compose/ui/d;Ldbxyzptlk/d0/E;Ldbxyzptlk/d0/t;ZZLdbxyzptlk/d0/p;Ldbxyzptlk/f0/m;)Landroidx/compose/ui/d;", "Ldbxyzptlk/c0/S;", "overscrollEffect", "Ldbxyzptlk/d0/f;", "bringIntoViewSpec", "i", "(Landroidx/compose/ui/d;Ldbxyzptlk/d0/E;Ldbxyzptlk/d0/t;Ldbxyzptlk/c0/S;ZZLdbxyzptlk/d0/p;Ldbxyzptlk/f0/m;Ldbxyzptlk/d0/f;)Landroidx/compose/ui/d;", "Ldbxyzptlk/a1/c;", "Ldbxyzptlk/a1/p;", "f", "(Ldbxyzptlk/a1/c;Ldbxyzptlk/tI/d;)Ljava/lang/Object;", "Lkotlin/Function1;", "Ldbxyzptlk/a1/A;", "a", "Ldbxyzptlk/CI/l;", "CanDragCalculation", "Lkotlin/Function3;", "Ldbxyzptlk/bK/J;", "Ldbxyzptlk/P0/f;", "Ldbxyzptlk/tI/d;", "Ldbxyzptlk/pI/D;", "", "b", "Ldbxyzptlk/CI/q;", "NoOpOnDragStarted", "Ldbxyzptlk/d0/A;", "c", "Ldbxyzptlk/d0/A;", "NoOpScrollScope", "Ldbxyzptlk/e1/l;", "d", "Ldbxyzptlk/e1/l;", "h", "()Ldbxyzptlk/e1/l;", "ModifierLocalScrollableContainer", "e", "Ldbxyzptlk/d0/p;", "getNoOpFlingBehavior", "()Ldbxyzptlk/d0/p;", "NoOpFlingBehavior", "Ldbxyzptlk/K0/g;", "Ldbxyzptlk/K0/g;", "g", "()Ldbxyzptlk/K0/g;", "DefaultScrollMotionDurationScale", "androidx/compose/foundation/gestures/a$g", "Landroidx/compose/foundation/gestures/a$g;", "UnityDensity", "foundation_release"}, k = 2, mv = {1, 8, 0}, xi = 48)
public final class a {
  public static final l<A, Boolean> a = a.f;
  
  public static final q<J, dbxyzptlk.P0.f, dbxyzptlk.tI.d<? super D>, Object> b = new e(null);
  
  public static final A c = new f();
  
  public static final l<Boolean> d = dbxyzptlk.e1.e.a(c.f);
  
  public static final p e = new d();
  
  public static final dbxyzptlk.K0.g f = new b();
  
  public static final g g = new g();
  
  public static final Object f(dbxyzptlk.a1.c paramc, dbxyzptlk.tI.d<? super p> paramd) {
    // Byte code:
    //   0: aload_1
    //   1: instanceof androidx/compose/foundation/gestures/a$h
    //   4: ifeq -> 37
    //   7: aload_1
    //   8: checkcast androidx/compose/foundation/gestures/a$h
    //   11: astore_3
    //   12: aload_3
    //   13: getfield v : I
    //   16: istore_2
    //   17: iload_2
    //   18: ldc -2147483648
    //   20: iand
    //   21: ifeq -> 37
    //   24: aload_3
    //   25: iload_2
    //   26: ldc -2147483648
    //   28: iadd
    //   29: putfield v : I
    //   32: aload_3
    //   33: astore_1
    //   34: goto -> 46
    //   37: new androidx/compose/foundation/gestures/a$h
    //   40: dup
    //   41: aload_1
    //   42: invokespecial <init> : (Ldbxyzptlk/tI/d;)V
    //   45: astore_1
    //   46: aload_1
    //   47: getfield u : Ljava/lang/Object;
    //   50: astore_3
    //   51: invokestatic g : ()Ljava/lang/Object;
    //   54: astore #5
    //   56: aload_1
    //   57: getfield v : I
    //   60: istore_2
    //   61: iload_2
    //   62: ifeq -> 95
    //   65: iload_2
    //   66: iconst_1
    //   67: if_icmpne -> 85
    //   70: aload_1
    //   71: getfield t : Ljava/lang/Object;
    //   74: checkcast dbxyzptlk/a1/c
    //   77: astore_0
    //   78: aload_3
    //   79: invokestatic b : (Ljava/lang/Object;)V
    //   82: goto -> 132
    //   85: new java/lang/IllegalStateException
    //   88: dup
    //   89: ldc 'call to 'resume' before 'invoke' with coroutine'
    //   91: invokespecial <init> : (Ljava/lang/String;)V
    //   94: athrow
    //   95: aload_3
    //   96: invokestatic b : (Ljava/lang/Object;)V
    //   99: aload_1
    //   100: aload_0
    //   101: putfield t : Ljava/lang/Object;
    //   104: aload_1
    //   105: iconst_1
    //   106: putfield v : I
    //   109: aload_0
    //   110: aconst_null
    //   111: aload_1
    //   112: iconst_1
    //   113: aconst_null
    //   114: invokestatic F1 : (Ldbxyzptlk/a1/c;Ldbxyzptlk/a1/r;Ldbxyzptlk/tI/d;ILjava/lang/Object;)Ljava/lang/Object;
    //   117: astore #4
    //   119: aload #4
    //   121: astore_3
    //   122: aload #4
    //   124: aload #5
    //   126: if_acmpne -> 132
    //   129: aload #5
    //   131: areturn
    //   132: aload_3
    //   133: checkcast dbxyzptlk/a1/p
    //   136: astore_3
    //   137: aload_3
    //   138: invokevirtual f : ()I
    //   141: getstatic dbxyzptlk/a1/s.a : Ldbxyzptlk/a1/s$a;
    //   144: invokevirtual f : ()I
    //   147: invokestatic i : (II)Z
    //   150: ifeq -> 99
    //   153: aload_3
    //   154: areturn
  }
  
  public static final dbxyzptlk.K0.g g() {
    return f;
  }
  
  public static final l<Boolean> h() {
    return d;
  }
  
  public static final androidx.compose.ui.d i(androidx.compose.ui.d paramd, E paramE, t paramt, S paramS, boolean paramBoolean1, boolean paramBoolean2, p paramp, m paramm, dbxyzptlk.d0.f paramf) {
    return paramd.g((androidx.compose.ui.d)new ScrollableElement(paramE, paramt, paramS, paramBoolean1, paramBoolean2, paramp, paramm, paramf));
  }
  
  public static final androidx.compose.ui.d j(androidx.compose.ui.d paramd, E paramE, t paramt, boolean paramBoolean1, boolean paramBoolean2, p paramp, m paramm) {
    return k(paramd, paramE, paramt, null, paramBoolean1, paramBoolean2, paramp, paramm, null, 128, null);
  }
  
  @Metadata(d1 = {"\000\016\n\002\030\002\n\000\n\002\020\013\n\002\b\002\020\003\032\0020\0022\006\020\001\032\0020\000H\n¢\006\004\b\003\020\004"}, d2 = {"Ldbxyzptlk/a1/A;", "down", "", "a", "(Ldbxyzptlk/a1/A;)Ljava/lang/Boolean;"}, k = 3, mv = {1, 8, 0})
  public static final class a extends u implements l<A, Boolean> {
    public static final a f = new a();
    
    public a() {
      super(1);
    }
    
    public final Boolean a(A param1A) {
      return Boolean.valueOf(O.g(param1A.o(), O.a.b()) ^ true);
    }
  }
  
  @Metadata(d1 = {"\000\021\n\000\n\002\030\002\n\002\020\007\n\002\b\004*\001\000\b\n\030\0002\0020\001R\024\020\005\032\0020\0028VX\004¢\006\006\032\004\b\003\020\004¨\006\006"}, d2 = {"androidx/compose/foundation/gestures/a$b", "Ldbxyzptlk/K0/g;", "", "Q", "()F", "scaleFactor", "foundation_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class b implements dbxyzptlk.K0.g {
    public float Q() {
      return 1.0F;
    }
    
    public <E extends dbxyzptlk.tI.g.b> E c(dbxyzptlk.tI.g.c<E> param1c) {
      return (E)dbxyzptlk.K0.g.a.b(this, param1c);
    }
    
    public <R> R g(R param1R, p<? super R, ? super dbxyzptlk.tI.g.b, ? extends R> param1p) {
      return (R)dbxyzptlk.K0.g.a.a(this, param1R, param1p);
    }
    
    public dbxyzptlk.tI.g l(dbxyzptlk.tI.g.c<?> param1c) {
      return dbxyzptlk.K0.g.a.c(this, param1c);
    }
    
    public dbxyzptlk.tI.g s(dbxyzptlk.tI.g param1g) {
      return dbxyzptlk.K0.g.a.d(this, param1g);
    }
  }
  
  @Metadata(d1 = {"\000\b\n\002\020\013\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"", "b", "()Ljava/lang/Boolean;"}, k = 3, mv = {1, 8, 0})
  public static final class c extends u implements dbxyzptlk.CI.a<Boolean> {
    public static final c f = new c();
    
    public c() {
      super(0);
    }
    
    public final Boolean b() {
      return Boolean.FALSE;
    }
  }
  
  @Metadata(d1 = {"\000\025\n\000\n\002\030\002\n\002\030\002\n\002\020\007\n\002\b\004*\001\000\b\n\030\0002\0020\001J\034\020\005\032\0020\003*\0020\0022\006\020\004\032\0020\003H@¢\006\004\b\005\020\006¨\006\007"}, d2 = {"androidx/compose/foundation/gestures/a$d", "Ldbxyzptlk/d0/p;", "Ldbxyzptlk/d0/A;", "", "initialVelocity", "a", "(Ldbxyzptlk/d0/A;FLdbxyzptlk/tI/d;)Ljava/lang/Object;", "foundation_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class d implements p {
    public Object a(A param1A, float param1Float, dbxyzptlk.tI.d<? super Float> param1d) {
      return dbxyzptlk.vI.b.c(0.0F);
    }
  }
  
  @dbxyzptlk.vI.f(c = "androidx.compose.foundation.gestures.ScrollableKt$NoOpOnDragStarted$1", f = "Scrollable.kt", l = {}, m = "invokeSuspend")
  @Metadata(d1 = {"\000\022\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\020\004\032\0020\003*\0020\0002\006\020\002\032\0020\001H@¢\006\004\b\004\020\005"}, d2 = {"Ldbxyzptlk/bK/J;", "Ldbxyzptlk/P0/f;", "it", "Ldbxyzptlk/pI/D;", "<anonymous>", "(Ldbxyzptlk/bK/J;Ldbxyzptlk/P0/f;)V"}, k = 3, mv = {1, 8, 0})
  public static final class e extends l implements q<J, dbxyzptlk.P0.f, dbxyzptlk.tI.d<? super D>, Object> {
    public int t;
    
    public e(dbxyzptlk.tI.d<? super e> param1d) {
      super(3, param1d);
    }
    
    public final Object a(J param1J, long param1Long, dbxyzptlk.tI.d<? super D> param1d) {
      return (new e((dbxyzptlk.tI.d)param1d)).invokeSuspend(D.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      dbxyzptlk.uI.c.g();
      if (this.t == 0) {
        p.b(param1Object);
        return D.a;
      } 
      throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }
  }
  
  @Metadata(d1 = {"\000\021\n\000\n\002\030\002\n\002\020\007\n\002\b\004*\001\000\b\n\030\0002\0020\001J\027\020\004\032\0020\0022\006\020\003\032\0020\002H\026¢\006\004\b\004\020\005¨\006\006"}, d2 = {"androidx/compose/foundation/gestures/a$f", "Ldbxyzptlk/d0/A;", "", "pixels", "a", "(F)F", "foundation_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class f implements A {
    public float a(float param1Float) {
      return param1Float;
    }
  }
  
  @Metadata(d1 = {"\000\021\n\000\n\002\030\002\n\002\020\007\n\002\b\006*\001\000\b\n\030\0002\0020\001R\024\020\005\032\0020\0028VX\004¢\006\006\032\004\b\003\020\004R\024\020\007\032\0020\0028VX\004¢\006\006\032\004\b\006\020\004¨\006\b"}, d2 = {"androidx/compose/foundation/gestures/a$g", "Ldbxyzptlk/z1/d;", "", "getDensity", "()F", "density", "v1", "fontScale", "foundation_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class g implements dbxyzptlk.z1.d {
    public float getDensity() {
      return 1.0F;
    }
    
    public float v1() {
      return 1.0F;
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compose\foundation\gestures\a.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */