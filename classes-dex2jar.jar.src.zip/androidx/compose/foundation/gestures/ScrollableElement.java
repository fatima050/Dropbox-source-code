package androidx.compose.foundation.gestures;

import androidx.compose.ui.d;
import dbxyzptlk.DI.s;
import dbxyzptlk.c0.S;
import dbxyzptlk.d0.E;
import dbxyzptlk.d0.f;
import dbxyzptlk.d0.p;
import dbxyzptlk.d0.t;
import dbxyzptlk.f0.m;
import dbxyzptlk.f1.G;
import kotlin.Metadata;

@Metadata(d1 = {"\000R\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020\013\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\006\n\002\030\002\n\002\b\002\n\002\020\b\n\002\b\002\n\002\020\000\n\002\b!\b\002\030\0002\b\022\004\022\0020\0020\001BM\022\006\020\004\032\0020\003\022\006\020\006\032\0020\005\022\b\020\b\032\004\030\0010\007\022\006\020\n\032\0020\t\022\006\020\013\032\0020\t\022\b\020\r\032\004\030\0010\f\022\b\020\017\032\004\030\0010\016\022\006\020\021\032\0020\020¢\006\004\b\022\020\023J\017\020\024\032\0020\002H\026¢\006\004\b\024\020\025J\027\020\030\032\0020\0272\006\020\026\032\0020\002H\026¢\006\004\b\030\020\031J\017\020\033\032\0020\032H\026¢\006\004\b\033\020\034J\032\020\037\032\0020\t2\b\020\036\032\004\030\0010\035H\002¢\006\004\b\037\020 R\027\020\004\032\0020\0038\006¢\006\f\n\004\b!\020\"\032\004\b#\020$R\027\020\006\032\0020\0058\006¢\006\f\n\004\b%\020&\032\004\b'\020(R\031\020\b\032\004\030\0010\0078\006¢\006\f\n\004\b)\020*\032\004\b+\020,R\027\020\n\032\0020\t8\006¢\006\f\n\004\b-\020.\032\004\b/\0200R\027\020\013\032\0020\t8\006¢\006\f\n\004\b1\020.\032\004\b2\0200R\031\020\r\032\004\030\0010\f8\006¢\006\f\n\004\b3\0204\032\004\b5\0206R\031\020\017\032\004\030\0010\0168\006¢\006\f\n\004\b7\0208\032\004\b9\020:R\027\020\021\032\0020\0208\006¢\006\f\n\004\b\024\020;\032\004\b<\020=¨\006>"}, d2 = {"Landroidx/compose/foundation/gestures/ScrollableElement;", "Ldbxyzptlk/f1/G;", "Landroidx/compose/foundation/gestures/b;", "Ldbxyzptlk/d0/E;", "state", "Ldbxyzptlk/d0/t;", "orientation", "Ldbxyzptlk/c0/S;", "overscrollEffect", "", "enabled", "reverseDirection", "Ldbxyzptlk/d0/p;", "flingBehavior", "Ldbxyzptlk/f0/m;", "interactionSource", "Ldbxyzptlk/d0/f;", "bringIntoViewSpec", "<init>", "(Ldbxyzptlk/d0/E;Ldbxyzptlk/d0/t;Ldbxyzptlk/c0/S;ZZLdbxyzptlk/d0/p;Ldbxyzptlk/f0/m;Ldbxyzptlk/d0/f;)V", "i", "()Landroidx/compose/foundation/gestures/b;", "node", "Ldbxyzptlk/pI/D;", "k", "(Landroidx/compose/foundation/gestures/b;)V", "", "hashCode", "()I", "", "other", "equals", "(Ljava/lang/Object;)Z", "b", "Ldbxyzptlk/d0/E;", "getState", "()Ldbxyzptlk/d0/E;", "c", "Ldbxyzptlk/d0/t;", "getOrientation", "()Ldbxyzptlk/d0/t;", "d", "Ldbxyzptlk/c0/S;", "getOverscrollEffect", "()Ldbxyzptlk/c0/S;", "e", "Z", "getEnabled", "()Z", "f", "getReverseDirection", "g", "Ldbxyzptlk/d0/p;", "getFlingBehavior", "()Ldbxyzptlk/d0/p;", "h", "Ldbxyzptlk/f0/m;", "getInteractionSource", "()Ldbxyzptlk/f0/m;", "Ldbxyzptlk/d0/f;", "getBringIntoViewSpec", "()Ldbxyzptlk/d0/f;", "foundation_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
final class ScrollableElement extends G<b> {
  public final E b;
  
  public final t c;
  
  public final S d;
  
  public final boolean e;
  
  public final boolean f;
  
  public final p g;
  
  public final m h;
  
  public final f i;
  
  public ScrollableElement(E paramE, t paramt, S paramS, boolean paramBoolean1, boolean paramBoolean2, p paramp, m paramm, f paramf) {
    this.b = paramE;
    this.c = paramt;
    this.d = paramS;
    this.e = paramBoolean1;
    this.f = paramBoolean2;
    this.g = paramp;
    this.h = paramm;
    this.i = paramf;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof ScrollableElement))
      return false; 
    E e = this.b;
    paramObject = paramObject;
    return !s.c(e, ((ScrollableElement)paramObject).b) ? false : ((this.c != ((ScrollableElement)paramObject).c) ? false : (!s.c(this.d, ((ScrollableElement)paramObject).d) ? false : ((this.e != ((ScrollableElement)paramObject).e) ? false : ((this.f != ((ScrollableElement)paramObject).f) ? false : (!s.c(this.g, ((ScrollableElement)paramObject).g) ? false : (!s.c(this.h, ((ScrollableElement)paramObject).h) ? false : (!!s.c(this.i, ((ScrollableElement)paramObject).i))))))));
  }
  
  public int hashCode() {
    byte b1;
    byte b2;
    int k = this.b.hashCode();
    int j = this.c.hashCode();
    S s = this.d;
    int i = 0;
    if (s != null) {
      b1 = s.hashCode();
    } else {
      b1 = 0;
    } 
    int n = Boolean.hashCode(this.e);
    int i1 = Boolean.hashCode(this.f);
    p p1 = this.g;
    if (p1 != null) {
      b2 = p1.hashCode();
    } else {
      b2 = 0;
    } 
    m m1 = this.h;
    if (m1 != null)
      i = m1.hashCode(); 
    return ((((((k * 31 + j) * 31 + b1) * 31 + n) * 31 + i1) * 31 + b2) * 31 + i) * 31 + this.i.hashCode();
  }
  
  public b i() {
    return new b(this.b, this.c, this.d, this.e, this.f, this.g, this.h, this.i);
  }
  
  public void k(b paramb) {
    paramb.q2(this.b, this.c, this.d, this.e, this.f, this.g, this.h, this.i);
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compose\foundation\gestures\ScrollableElement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */