package androidx.compose.foundation.relocation;

import androidx.compose.ui.d;
import dbxyzptlk.DI.s;
import dbxyzptlk.f1.G;
import dbxyzptlk.l0.d;
import dbxyzptlk.l0.f;
import kotlin.Metadata;

@Metadata(d1 = {"\0002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\006\n\002\030\002\n\002\b\002\n\002\020\000\n\000\n\002\020\013\n\002\b\002\n\002\020\b\n\002\b\005\b\003\030\0002\b\022\004\022\0020\0020\001B\017\022\006\020\004\032\0020\003¢\006\004\b\005\020\006J\017\020\007\032\0020\002H\026¢\006\004\b\007\020\bJ\027\020\013\032\0020\n2\006\020\t\032\0020\002H\026¢\006\004\b\013\020\fJ\032\020\020\032\0020\0172\b\020\016\032\004\030\0010\rH\002¢\006\004\b\020\020\021J\017\020\023\032\0020\022H\026¢\006\004\b\023\020\024R\024\020\004\032\0020\0038\002X\004¢\006\006\n\004\b\025\020\026¨\006\027"}, d2 = {"Landroidx/compose/foundation/relocation/BringIntoViewRequesterElement;", "Ldbxyzptlk/f1/G;", "Ldbxyzptlk/l0/f;", "Ldbxyzptlk/l0/d;", "requester", "<init>", "(Ldbxyzptlk/l0/d;)V", "i", "()Ldbxyzptlk/l0/f;", "node", "Ldbxyzptlk/pI/D;", "k", "(Ldbxyzptlk/l0/f;)V", "", "other", "", "equals", "(Ljava/lang/Object;)Z", "", "hashCode", "()I", "b", "Ldbxyzptlk/l0/d;", "foundation_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
final class BringIntoViewRequesterElement extends G<f> {
  public final d b;
  
  public BringIntoViewRequesterElement(d paramd) {
    this.b = paramd;
  }
  
  public boolean equals(Object paramObject) {
    return (this == paramObject || (paramObject instanceof BringIntoViewRequesterElement && s.c(this.b, ((BringIntoViewRequesterElement)paramObject).b)));
  }
  
  public int hashCode() {
    return this.b.hashCode();
  }
  
  public f i() {
    return new f(this.b);
  }
  
  public void k(f paramf) {
    paramf.p2(this.b);
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compose\foundation\relocation\BringIntoViewRequesterElement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */