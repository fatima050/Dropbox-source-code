package androidx.compose.foundation.relocation;

import androidx.compose.ui.d;
import dbxyzptlk.l0.d;
import dbxyzptlk.l0.e;
import kotlin.Metadata;

@Metadata(d1 = {"\000\020\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\004\032\017\020\001\032\0020\000H\007¢\006\004\b\001\020\002\032\033\020\005\032\0020\003*\0020\0032\006\020\004\032\0020\000H\007¢\006\004\b\005\020\006¨\006\007"}, d2 = {"Ldbxyzptlk/l0/d;", "a", "()Ldbxyzptlk/l0/d;", "Landroidx/compose/ui/d;", "bringIntoViewRequester", "b", "(Landroidx/compose/ui/d;Ldbxyzptlk/l0/d;)Landroidx/compose/ui/d;", "foundation_release"}, k = 2, mv = {1, 8, 0}, xi = 48)
public final class a {
  public static final d a() {
    return (d)new e();
  }
  
  public static final d b(d paramd, d paramd1) {
    return paramd.g((d)new BringIntoViewRequesterElement(paramd1));
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compose\foundation\relocation\a.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */