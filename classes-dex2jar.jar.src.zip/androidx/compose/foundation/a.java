package androidx.compose.foundation;

import android.view.KeyEvent;
import dbxyzptlk.CI.p;
import dbxyzptlk.DI.s;
import dbxyzptlk.P0.f;
import dbxyzptlk.Y0.d;
import dbxyzptlk.Y0.e;
import dbxyzptlk.a1.p;
import dbxyzptlk.a1.r;
import dbxyzptlk.bK.h;
import dbxyzptlk.c0.m;
import dbxyzptlk.f0.j;
import dbxyzptlk.f0.m;
import dbxyzptlk.f0.o;
import dbxyzptlk.f0.p;
import dbxyzptlk.f1.X;
import dbxyzptlk.f1.i;
import dbxyzptlk.l1.i;
import dbxyzptlk.pI.D;
import java.util.LinkedHashMap;
import java.util.Map;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

@Metadata(d1 = {"\000j\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\020\013\n\000\n\002\020\016\n\000\n\002\030\002\n\000\n\002\030\002\n\002\030\002\n\002\b\007\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\016\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\004\n\002\030\002\n\002\030\002\n\000\b2\030\0002\0020\0012\0020\0022\0020\003:\0017B;\b\004\022\006\020\005\032\0020\004\022\006\020\007\032\0020\006\022\b\020\t\032\004\030\0010\b\022\b\020\013\032\004\030\0010\n\022\f\020\016\032\b\022\004\022\0020\r0\f¢\006\004\b\017\020\020JF\020\021\032\0020\r2\006\020\005\032\0020\0042\006\020\007\032\0020\0062\b\020\t\032\004\030\0010\b2\n\b\002\020\013\032\004\030\0010\n2\f\020\016\032\b\022\004\022\0020\r0\fH\004ø\001\000¢\006\004\b\021\020\020J\017\020\022\032\0020\rH\026¢\006\004\b\022\020\023J\017\020\024\032\0020\rH\004¢\006\004\b\024\020\023J*\020\033\032\0020\r2\006\020\026\032\0020\0252\006\020\030\032\0020\0272\006\020\032\032\0020\031H\026ø\001\000¢\006\004\b\033\020\034J\017\020\035\032\0020\rH\026¢\006\004\b\035\020\023J\032\020 \032\0020\0062\006\020\037\032\0020\036H\026ø\001\000¢\006\004\b \020!J\032\020\"\032\0020\0062\006\020\037\032\0020\036H\026ø\001\000¢\006\004\b\"\020!R\026\020\005\032\0020\0048\002@\002X\016¢\006\006\n\004\b#\020$R\026\020\007\032\0020\0068\002@\002X\016¢\006\006\n\004\b%\020&R\030\020\t\032\004\030\0010\b8\002@\002X\016¢\006\006\n\004\b'\020(R\036\020\013\032\004\030\0010\n8\002@\002X\016ø\001\000ø\001\001¢\006\006\n\004\b)\020*R\034\020\016\032\b\022\004\022\0020\r0\f8\002@\002X\016¢\006\006\n\004\b+\020,R\032\0202\032\0020-8\004X\004¢\006\f\n\004\b.\020/\032\004\b0\0201R\024\0206\032\002038&X¦\004¢\006\006\032\004\b4\0205\001\00289\002\013\n\005\b¡\0360\001\n\002\b!¨\006:"}, d2 = {"Landroidx/compose/foundation/a;", "Ldbxyzptlk/f1/i;", "Ldbxyzptlk/f1/X;", "Ldbxyzptlk/Y0/e;", "Ldbxyzptlk/f0/m;", "interactionSource", "", "enabled", "", "onClickLabel", "Ldbxyzptlk/l1/i;", "role", "Lkotlin/Function0;", "Ldbxyzptlk/pI/D;", "onClick", "<init>", "(Ldbxyzptlk/f0/m;ZLjava/lang/String;Ldbxyzptlk/l1/i;Ldbxyzptlk/CI/a;)V", "t2", "V1", "()V", "q2", "Ldbxyzptlk/a1/p;", "pointerEvent", "Ldbxyzptlk/a1/r;", "pass", "Ldbxyzptlk/z1/r;", "bounds", "f1", "(Ldbxyzptlk/a1/p;Ldbxyzptlk/a1/r;J)V", "p0", "Ldbxyzptlk/Y0/b;", "event", "k1", "(Landroid/view/KeyEvent;)Z", "e0", "p", "Ldbxyzptlk/f0/m;", "q", "Z", "r", "Ljava/lang/String;", "s", "Ldbxyzptlk/l1/i;", "t", "Ldbxyzptlk/CI/a;", "Landroidx/compose/foundation/a$a;", "u", "Landroidx/compose/foundation/a$a;", "s2", "()Landroidx/compose/foundation/a$a;", "interactionData", "Landroidx/compose/foundation/b;", "r2", "()Landroidx/compose/foundation/b;", "clickablePointerInputNode", "a", "Landroidx/compose/foundation/e;", "Landroidx/compose/foundation/g;", "foundation_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public abstract class a extends i implements X, e {
  public m p;
  
  public boolean q;
  
  public String r;
  
  public i s;
  
  public dbxyzptlk.CI.a<D> t;
  
  public final a u;
  
  public a(m paramm, boolean paramBoolean, String paramString, i parami, dbxyzptlk.CI.a<D> parama) {
    this.p = paramm;
    this.q = paramBoolean;
    this.r = paramString;
    this.s = parami;
    this.t = parama;
    this.u = new a();
  }
  
  public void V1() {
    q2();
  }
  
  public boolean e0(KeyEvent paramKeyEvent) {
    return false;
  }
  
  public void f1(p paramp, r paramr, long paramLong) {
    r2().f1(paramp, paramr, paramLong);
  }
  
  public boolean k1(KeyEvent paramKeyEvent) {
    null = this.q;
    boolean bool = false;
    if (null && m.f(paramKeyEvent)) {
      null = bool;
      if (!this.u.b().containsKey(dbxyzptlk.Y0.a.n(d.a(paramKeyEvent)))) {
        p p = new p(this.u.a(), null);
        this.u.b().put(dbxyzptlk.Y0.a.n(d.a(paramKeyEvent)), p);
        h.d(K1(), null, null, (p)new b(this, p, null), 3, null);
      } else {
        return null;
      } 
    } else {
      null = bool;
      if (this.q) {
        null = bool;
        if (m.b(paramKeyEvent)) {
          p p = this.u.b().remove(dbxyzptlk.Y0.a.n(d.a(paramKeyEvent)));
          if (p != null)
            h.d(K1(), null, null, (p)new c(this, p, null), 3, null); 
          this.t.invoke();
        } else {
          return null;
        } 
      } else {
        return null;
      } 
    } 
    return true;
  }
  
  public void p0() {
    r2().p0();
  }
  
  public final void q2() {
    p = this.u.c();
    if (p != null) {
      o o = new o(p);
      this.p.b((j)o);
    } 
    for (p p : this.u.b().values())
      this.p.b((j)new o(p)); 
    this.u.e(null);
    this.u.b().clear();
  }
  
  public abstract b r2();
  
  public final a s2() {
    return this.u;
  }
  
  public final void t2(m paramm, boolean paramBoolean, String paramString, i parami, dbxyzptlk.CI.a<D> parama) {
    if (!s.c(this.p, paramm)) {
      q2();
      this.p = paramm;
    } 
    if (this.q != paramBoolean) {
      if (!paramBoolean)
        q2(); 
      this.q = paramBoolean;
    } 
    this.r = paramString;
    this.s = parami;
    this.t = parama;
  }
  
  @Metadata(d1 = {"\000$\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020%\n\002\030\002\n\002\030\002\n\002\b\013\n\002\030\002\n\002\b\006\b\007\030\0002\0020\001B\007¢\006\004\b\002\020\003R#\020\013\032\016\022\004\022\0020\005\022\004\022\0020\0060\0048\006¢\006\f\n\004\b\007\020\b\032\004\b\t\020\nR$\020\021\032\004\030\0010\0068\006@\006X\016¢\006\022\n\004\b\t\020\f\032\004\b\r\020\016\"\004\b\017\020\020R(\020\027\032\0020\0228\006@\006X\016ø\001\000ø\001\001¢\006\022\n\004\b\r\020\023\032\004\b\007\020\024\"\004\b\025\020\026\002\013\n\005\b¡\0360\001\n\002\b!¨\006\030"}, d2 = {"Landroidx/compose/foundation/a$a;", "", "<init>", "()V", "", "Ldbxyzptlk/Y0/a;", "Ldbxyzptlk/f0/p;", "a", "Ljava/util/Map;", "b", "()Ljava/util/Map;", "currentKeyPressInteractions", "Ldbxyzptlk/f0/p;", "c", "()Ldbxyzptlk/f0/p;", "e", "(Ldbxyzptlk/f0/p;)V", "pressInteraction", "Ldbxyzptlk/P0/f;", "J", "()J", "d", "(J)V", "centreOffset", "foundation_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
  public static final class a {
    public final Map<dbxyzptlk.Y0.a, p> a = new LinkedHashMap<>();
    
    public p b;
    
    public long c = f.b.c();
    
    public final long a() {
      return this.c;
    }
    
    public final Map<dbxyzptlk.Y0.a, p> b() {
      return this.a;
    }
    
    public final p c() {
      return this.b;
    }
    
    public final void d(long param1Long) {
      this.c = param1Long;
    }
    
    public final void e(p param1p) {
      this.b = param1p;
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compose\foundation\a.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */