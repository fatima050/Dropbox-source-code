package androidx.compose.foundation;

import androidx.compose.ui.d;
import dbxyzptlk.DI.s;
import dbxyzptlk.c0.a0;
import dbxyzptlk.c0.b0;
import dbxyzptlk.f1.G;
import kotlin.Metadata;

@Metadata(d1 = {"\0002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\020\013\n\002\b\007\n\002\030\002\n\002\b\002\n\002\020\b\n\002\b\002\n\002\020\000\n\002\b\f\b\000\030\0002\b\022\004\022\0020\0020\001B\037\022\006\020\004\032\0020\003\022\006\020\006\032\0020\005\022\006\020\007\032\0020\005¢\006\004\b\b\020\tJ\017\020\n\032\0020\002H\026¢\006\004\b\n\020\013J\027\020\016\032\0020\r2\006\020\f\032\0020\002H\026¢\006\004\b\016\020\017J\017\020\021\032\0020\020H\026¢\006\004\b\021\020\022J\032\020\025\032\0020\0052\b\020\024\032\004\030\0010\023H\002¢\006\004\b\025\020\026R\027\020\004\032\0020\0038\006¢\006\f\n\004\b\027\020\030\032\004\b\031\020\032R\027\020\006\032\0020\0058\006¢\006\f\n\004\b\033\020\034\032\004\b\006\020\035R\027\020\007\032\0020\0058\006¢\006\f\n\004\b\036\020\034\032\004\b\007\020\035¨\006\037"}, d2 = {"Landroidx/compose/foundation/ScrollingLayoutElement;", "Ldbxyzptlk/f1/G;", "Ldbxyzptlk/c0/b0;", "Ldbxyzptlk/c0/a0;", "scrollState", "", "isReversed", "isVertical", "<init>", "(Ldbxyzptlk/c0/a0;ZZ)V", "i", "()Ldbxyzptlk/c0/b0;", "node", "Ldbxyzptlk/pI/D;", "k", "(Ldbxyzptlk/c0/b0;)V", "", "hashCode", "()I", "", "other", "equals", "(Ljava/lang/Object;)Z", "b", "Ldbxyzptlk/c0/a0;", "getScrollState", "()Ldbxyzptlk/c0/a0;", "c", "Z", "()Z", "d", "foundation_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class ScrollingLayoutElement extends G<b0> {
  public final a0 b;
  
  public final boolean c;
  
  public final boolean d;
  
  public ScrollingLayoutElement(a0 parama0, boolean paramBoolean1, boolean paramBoolean2) {
    this.b = parama0;
    this.c = paramBoolean1;
    this.d = paramBoolean2;
  }
  
  public boolean equals(Object paramObject) {
    boolean bool = paramObject instanceof ScrollingLayoutElement;
    boolean bool1 = false;
    if (!bool)
      return false; 
    a0 a01 = this.b;
    paramObject = paramObject;
    bool = bool1;
    if (s.c(a01, ((ScrollingLayoutElement)paramObject).b)) {
      bool = bool1;
      if (this.c == ((ScrollingLayoutElement)paramObject).c) {
        bool = bool1;
        if (this.d == ((ScrollingLayoutElement)paramObject).d)
          bool = true; 
      } 
    } 
    return bool;
  }
  
  public int hashCode() {
    return (this.b.hashCode() * 31 + Boolean.hashCode(this.c)) * 31 + Boolean.hashCode(this.d);
  }
  
  public b0 i() {
    return new b0(this.b, this.c, this.d);
  }
  
  public void k(b0 paramb0) {
    paramb0.o2(this.b);
    paramb0.n2(this.c);
    paramb0.p2(this.d);
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compose\foundation\ScrollingLayoutElement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */