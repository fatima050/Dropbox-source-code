package androidx.compose.foundation.text.modifiers;

import androidx.compose.ui.d;
import dbxyzptlk.DI.s;
import dbxyzptlk.Q0.u0;
import dbxyzptlk.f1.G;
import dbxyzptlk.n1.L;
import dbxyzptlk.p0.l;
import dbxyzptlk.s1.l;
import dbxyzptlk.y1.t;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

@Metadata(d1 = {"\000J\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\016\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020\013\n\000\n\002\020\b\n\002\b\002\n\002\030\002\n\002\b\006\n\002\030\002\n\002\b\002\n\002\020\000\n\002\b\023\b\000\030\0002\b\022\004\022\0020\0020\001BS\022\006\020\004\032\0020\003\022\006\020\006\032\0020\005\022\006\020\b\032\0020\007\022\b\b\002\020\n\032\0020\t\022\b\b\002\020\f\032\0020\013\022\b\b\002\020\016\032\0020\r\022\b\b\002\020\017\032\0020\r\022\n\b\002\020\021\032\004\030\0010\020¢\006\004\b\022\020\023J\017\020\024\032\0020\002H\026¢\006\004\b\024\020\025J\027\020\030\032\0020\0272\006\020\026\032\0020\002H\026¢\006\004\b\030\020\031J\032\020\034\032\0020\0132\b\020\033\032\004\030\0010\032H\002¢\006\004\b\034\020\035J\017\020\036\032\0020\rH\026¢\006\004\b\036\020\037R\024\020\004\032\0020\0038\002X\004¢\006\006\n\004\b \020!R\024\020\006\032\0020\0058\002X\004¢\006\006\n\004\b\"\020#R\024\020\b\032\0020\0078\002X\004¢\006\006\n\004\b$\020%R\032\020\n\032\0020\t8\002X\004ø\001\000ø\001\001¢\006\006\n\004\b&\020'R\024\020\f\032\0020\0138\002X\004¢\006\006\n\004\b(\020)R\024\020\016\032\0020\r8\002X\004¢\006\006\n\004\b*\020'R\024\020\017\032\0020\r8\002X\004¢\006\006\n\004\b+\020'R\026\020\021\032\004\030\0010\0208\002X\004¢\006\006\n\004\b\024\020,\002\013\n\005\b¡\0360\001\n\002\b!¨\006-"}, d2 = {"Landroidx/compose/foundation/text/modifiers/TextStringSimpleElement;", "Ldbxyzptlk/f1/G;", "Ldbxyzptlk/p0/l;", "", "text", "Ldbxyzptlk/n1/L;", "style", "Ldbxyzptlk/s1/l$b;", "fontFamilyResolver", "Ldbxyzptlk/y1/t;", "overflow", "", "softWrap", "", "maxLines", "minLines", "Ldbxyzptlk/Q0/u0;", "color", "<init>", "(Ljava/lang/String;Ldbxyzptlk/n1/L;Ldbxyzptlk/s1/l$b;IZIILdbxyzptlk/Q0/u0;Lkotlin/jvm/internal/DefaultConstructorMarker;)V", "i", "()Ldbxyzptlk/p0/l;", "node", "Ldbxyzptlk/pI/D;", "k", "(Ldbxyzptlk/p0/l;)V", "", "other", "equals", "(Ljava/lang/Object;)Z", "hashCode", "()I", "b", "Ljava/lang/String;", "c", "Ldbxyzptlk/n1/L;", "d", "Ldbxyzptlk/s1/l$b;", "e", "I", "f", "Z", "g", "h", "Ldbxyzptlk/Q0/u0;", "foundation_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
public final class TextStringSimpleElement extends G<l> {
  public final String b;
  
  public final L c;
  
  public final l.b d;
  
  public final int e;
  
  public final boolean f;
  
  public final int g;
  
  public final int h;
  
  public final u0 i;
  
  public TextStringSimpleElement(String paramString, L paramL, l.b paramb, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, u0 paramu0) {
    this.b = paramString;
    this.c = paramL;
    this.d = paramb;
    this.e = paramInt1;
    this.f = paramBoolean;
    this.g = paramInt2;
    this.h = paramInt3;
    this.i = paramu0;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof TextStringSimpleElement))
      return false; 
    u0 u01 = this.i;
    paramObject = paramObject;
    return !s.c(u01, ((TextStringSimpleElement)paramObject).i) ? false : (!s.c(this.b, ((TextStringSimpleElement)paramObject).b) ? false : (!s.c(this.c, ((TextStringSimpleElement)paramObject).c) ? false : (!s.c(this.d, ((TextStringSimpleElement)paramObject).d) ? false : (!t.e(this.e, ((TextStringSimpleElement)paramObject).e) ? false : ((this.f != ((TextStringSimpleElement)paramObject).f) ? false : ((this.g != ((TextStringSimpleElement)paramObject).g) ? false : (!(this.h != ((TextStringSimpleElement)paramObject).h))))))));
  }
  
  public int hashCode() {
    byte b1;
    int i2 = this.b.hashCode();
    int j = this.c.hashCode();
    int n = this.d.hashCode();
    int i = t.f(this.e);
    int k = Boolean.hashCode(this.f);
    int m = this.g;
    int i1 = this.h;
    u0 u01 = this.i;
    if (u01 != null) {
      b1 = u01.hashCode();
    } else {
      b1 = 0;
    } 
    return ((((((i2 * 31 + j) * 31 + n) * 31 + i) * 31 + k) * 31 + m) * 31 + i1) * 31 + b1;
  }
  
  public l i() {
    return new l(this.b, this.c, this.d, this.e, this.f, this.g, this.h, this.i, null);
  }
  
  public void k(l paraml) {
    paraml.r2(paraml.x2(this.i, this.c), paraml.z2(this.b), paraml.y2(this.c, this.h, this.g, this.f, this.d, this.e));
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\compose\foundation\text\modifiers\TextStringSimpleElement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */