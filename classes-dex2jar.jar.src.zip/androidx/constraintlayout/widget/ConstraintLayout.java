package androidx.constraintlayout.widget;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.util.SparseIntArray;
import android.view.View;
import android.view.ViewGroup;
import dbxyzptlk.G1.e;
import dbxyzptlk.L1.d;
import dbxyzptlk.L1.e;
import dbxyzptlk.L1.f;
import dbxyzptlk.L1.h;
import dbxyzptlk.P1.d;
import io.sentry.android.core.r0;
import java.util.ArrayList;
import java.util.HashMap;

public class ConstraintLayout extends ViewGroup {
  private static final boolean DEBUG = false;
  
  private static final boolean DEBUG_DRAW_CONSTRAINTS = false;
  
  public static final int DESIGN_INFO_ID = 0;
  
  private static final boolean MEASURE = false;
  
  private static final boolean OPTIMIZE_HEIGHT_CHANGE = false;
  
  private static final String TAG = "ConstraintLayout";
  
  private static final boolean USE_CONSTRAINTS_HELPER = true;
  
  public static final String VERSION = "ConstraintLayout-2.1.4";
  
  private static c sSharedValues;
  
  SparseArray<View> mChildrenByIds = new SparseArray();
  
  private ArrayList<ConstraintHelper> mConstraintHelpers = new ArrayList<>(4);
  
  protected dbxyzptlk.P1.a mConstraintLayoutSpec = null;
  
  private b mConstraintSet = null;
  
  private int mConstraintSetId = -1;
  
  private dbxyzptlk.P1.b mConstraintsChangedListener;
  
  private HashMap<String, Integer> mDesignIds = new HashMap<>();
  
  protected boolean mDirtyHierarchy = true;
  
  private int mLastMeasureHeight = -1;
  
  int mLastMeasureHeightMode = 0;
  
  int mLastMeasureHeightSize = -1;
  
  private int mLastMeasureWidth = -1;
  
  int mLastMeasureWidthMode = 0;
  
  int mLastMeasureWidthSize = -1;
  
  protected f mLayoutWidget = new f();
  
  private int mMaxHeight = Integer.MAX_VALUE;
  
  private int mMaxWidth = Integer.MAX_VALUE;
  
  b mMeasurer = new b(this, this);
  
  private e mMetrics;
  
  private int mMinHeight = 0;
  
  private int mMinWidth = 0;
  
  private int mOnMeasureHeightMeasureSpec = 0;
  
  private int mOnMeasureWidthMeasureSpec = 0;
  
  private int mOptimizationLevel = 257;
  
  private SparseArray<e> mTempMapIdToWidget = new SparseArray();
  
  public ConstraintLayout(Context paramContext) {
    super(paramContext);
    init(null, 0, 0);
  }
  
  public ConstraintLayout(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    init(paramAttributeSet, 0, 0);
  }
  
  public ConstraintLayout(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    init(paramAttributeSet, paramInt, 0);
  }
  
  @TargetApi(21)
  public ConstraintLayout(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    super(paramContext, paramAttributeSet, paramInt1, paramInt2);
    init(paramAttributeSet, paramInt1, paramInt2);
  }
  
  private int getPaddingWidth() {
    int i = Math.max(0, getPaddingLeft()) + Math.max(0, getPaddingRight());
    int j = Math.max(0, getPaddingStart()) + Math.max(0, getPaddingEnd());
    if (j > 0)
      i = j; 
    return i;
  }
  
  public static c getSharedValues() {
    if (sSharedValues == null)
      sSharedValues = new c(); 
    return sSharedValues;
  }
  
  private final e getTargetWidget(int paramInt) {
    e e1;
    if (paramInt == 0)
      return (e)this.mLayoutWidget; 
    View view2 = (View)this.mChildrenByIds.get(paramInt);
    View view1 = view2;
    if (view2 == null) {
      view2 = findViewById(paramInt);
      view1 = view2;
      if (view2 != null) {
        view1 = view2;
        if (view2 != this) {
          view1 = view2;
          if (view2.getParent() == this) {
            onViewAdded(view2);
            view1 = view2;
          } 
        } 
      } 
    } 
    if (view1 == this)
      return (e)this.mLayoutWidget; 
    if (view1 == null) {
      view1 = null;
    } else {
      e1 = ((LayoutParams)view1.getLayoutParams()).v0;
    } 
    return e1;
  }
  
  private void init(AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    this.mLayoutWidget.H0(this);
    this.mLayoutWidget.c2(this.mMeasurer);
    this.mChildrenByIds.put(getId(), this);
    this.mConstraintSet = null;
    if (paramAttributeSet != null) {
      TypedArray typedArray = getContext().obtainStyledAttributes(paramAttributeSet, d.ConstraintLayout_Layout, paramInt1, paramInt2);
      paramInt2 = typedArray.getIndexCount();
      for (paramInt1 = 0; paramInt1 < paramInt2; paramInt1++) {
        int i = typedArray.getIndex(paramInt1);
        if (i == d.ConstraintLayout_Layout_android_minWidth) {
          this.mMinWidth = typedArray.getDimensionPixelOffset(i, this.mMinWidth);
        } else if (i == d.ConstraintLayout_Layout_android_minHeight) {
          this.mMinHeight = typedArray.getDimensionPixelOffset(i, this.mMinHeight);
        } else if (i == d.ConstraintLayout_Layout_android_maxWidth) {
          this.mMaxWidth = typedArray.getDimensionPixelOffset(i, this.mMaxWidth);
        } else if (i == d.ConstraintLayout_Layout_android_maxHeight) {
          this.mMaxHeight = typedArray.getDimensionPixelOffset(i, this.mMaxHeight);
        } else if (i == d.ConstraintLayout_Layout_layout_optimizationLevel) {
          this.mOptimizationLevel = typedArray.getInt(i, this.mOptimizationLevel);
        } else if (i == d.ConstraintLayout_Layout_layoutDescription) {
          i = typedArray.getResourceId(i, 0);
          if (i != 0)
            try {
              parseLayoutDescription(i);
            } catch (android.content.res.Resources.NotFoundException notFoundException) {
              this.mConstraintLayoutSpec = null;
            }  
        } else if (i == d.ConstraintLayout_Layout_constraintSet) {
          i = typedArray.getResourceId(i, 0);
          try {
            b b1 = new b();
            this();
            this.mConstraintSet = b1;
            b1.C(getContext(), i);
          } catch (android.content.res.Resources.NotFoundException notFoundException) {
            this.mConstraintSet = null;
          } 
          this.mConstraintSetId = i;
        } 
      } 
      typedArray.recycle();
    } 
    this.mLayoutWidget.d2(this.mOptimizationLevel);
  }
  
  private void markHierarchyDirty() {
    this.mDirtyHierarchy = true;
    this.mLastMeasureWidth = -1;
    this.mLastMeasureHeight = -1;
    this.mLastMeasureWidthSize = -1;
    this.mLastMeasureHeightSize = -1;
    this.mLastMeasureWidthMode = 0;
    this.mLastMeasureHeightMode = 0;
  }
  
  private void setChildrenConstraints() {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual isInEditMode : ()Z
    //   4: istore #4
    //   6: aload_0
    //   7: invokevirtual getChildCount : ()I
    //   10: istore_2
    //   11: iconst_0
    //   12: istore_1
    //   13: iload_1
    //   14: iload_2
    //   15: if_icmpge -> 48
    //   18: aload_0
    //   19: aload_0
    //   20: iload_1
    //   21: invokevirtual getChildAt : (I)Landroid/view/View;
    //   24: invokevirtual getViewWidget : (Landroid/view/View;)Ldbxyzptlk/L1/e;
    //   27: astore #5
    //   29: aload #5
    //   31: ifnonnull -> 37
    //   34: goto -> 42
    //   37: aload #5
    //   39: invokevirtual x0 : ()V
    //   42: iinc #1, 1
    //   45: goto -> 13
    //   48: iload #4
    //   50: ifeq -> 143
    //   53: iconst_0
    //   54: istore_1
    //   55: iload_1
    //   56: iload_2
    //   57: if_icmpge -> 143
    //   60: aload_0
    //   61: iload_1
    //   62: invokevirtual getChildAt : (I)Landroid/view/View;
    //   65: astore #7
    //   67: aload_0
    //   68: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   71: aload #7
    //   73: invokevirtual getId : ()I
    //   76: invokevirtual getResourceName : (I)Ljava/lang/String;
    //   79: astore #6
    //   81: aload_0
    //   82: iconst_0
    //   83: aload #6
    //   85: aload #7
    //   87: invokevirtual getId : ()I
    //   90: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   93: invokevirtual setDesignInformation : (ILjava/lang/Object;Ljava/lang/Object;)V
    //   96: aload #6
    //   98: bipush #47
    //   100: invokevirtual indexOf : (I)I
    //   103: istore_3
    //   104: aload #6
    //   106: astore #5
    //   108: iload_3
    //   109: iconst_m1
    //   110: if_icmpeq -> 123
    //   113: aload #6
    //   115: iload_3
    //   116: iconst_1
    //   117: iadd
    //   118: invokevirtual substring : (I)Ljava/lang/String;
    //   121: astore #5
    //   123: aload_0
    //   124: aload #7
    //   126: invokevirtual getId : ()I
    //   129: invokespecial getTargetWidget : (I)Ldbxyzptlk/L1/e;
    //   132: aload #5
    //   134: invokevirtual I0 : (Ljava/lang/String;)V
    //   137: iinc #1, 1
    //   140: goto -> 55
    //   143: aload_0
    //   144: getfield mConstraintSetId : I
    //   147: iconst_m1
    //   148: if_icmpeq -> 203
    //   151: iconst_0
    //   152: istore_1
    //   153: iload_1
    //   154: iload_2
    //   155: if_icmpge -> 203
    //   158: aload_0
    //   159: iload_1
    //   160: invokevirtual getChildAt : (I)Landroid/view/View;
    //   163: astore #5
    //   165: aload #5
    //   167: invokevirtual getId : ()I
    //   170: aload_0
    //   171: getfield mConstraintSetId : I
    //   174: if_icmpne -> 197
    //   177: aload #5
    //   179: instanceof androidx/constraintlayout/widget/Constraints
    //   182: ifeq -> 197
    //   185: aload_0
    //   186: aload #5
    //   188: checkcast androidx/constraintlayout/widget/Constraints
    //   191: invokevirtual getConstraintSet : ()Landroidx/constraintlayout/widget/b;
    //   194: putfield mConstraintSet : Landroidx/constraintlayout/widget/b;
    //   197: iinc #1, 1
    //   200: goto -> 153
    //   203: aload_0
    //   204: getfield mConstraintSet : Landroidx/constraintlayout/widget/b;
    //   207: astore #5
    //   209: aload #5
    //   211: ifnull -> 221
    //   214: aload #5
    //   216: aload_0
    //   217: iconst_1
    //   218: invokevirtual k : (Landroidx/constraintlayout/widget/ConstraintLayout;Z)V
    //   221: aload_0
    //   222: getfield mLayoutWidget : Ldbxyzptlk/L1/f;
    //   225: invokevirtual A1 : ()V
    //   228: aload_0
    //   229: getfield mConstraintHelpers : Ljava/util/ArrayList;
    //   232: invokevirtual size : ()I
    //   235: istore_3
    //   236: iload_3
    //   237: ifle -> 268
    //   240: iconst_0
    //   241: istore_1
    //   242: iload_1
    //   243: iload_3
    //   244: if_icmpge -> 268
    //   247: aload_0
    //   248: getfield mConstraintHelpers : Ljava/util/ArrayList;
    //   251: iload_1
    //   252: invokevirtual get : (I)Ljava/lang/Object;
    //   255: checkcast androidx/constraintlayout/widget/ConstraintHelper
    //   258: aload_0
    //   259: invokevirtual u : (Landroidx/constraintlayout/widget/ConstraintLayout;)V
    //   262: iinc #1, 1
    //   265: goto -> 242
    //   268: iconst_0
    //   269: istore_1
    //   270: iload_1
    //   271: iload_2
    //   272: if_icmpge -> 305
    //   275: aload_0
    //   276: iload_1
    //   277: invokevirtual getChildAt : (I)Landroid/view/View;
    //   280: astore #5
    //   282: aload #5
    //   284: instanceof androidx/constraintlayout/widget/Placeholder
    //   287: ifeq -> 299
    //   290: aload #5
    //   292: checkcast androidx/constraintlayout/widget/Placeholder
    //   295: aload_0
    //   296: invokevirtual c : (Landroidx/constraintlayout/widget/ConstraintLayout;)V
    //   299: iinc #1, 1
    //   302: goto -> 270
    //   305: aload_0
    //   306: getfield mTempMapIdToWidget : Landroid/util/SparseArray;
    //   309: invokevirtual clear : ()V
    //   312: aload_0
    //   313: getfield mTempMapIdToWidget : Landroid/util/SparseArray;
    //   316: iconst_0
    //   317: aload_0
    //   318: getfield mLayoutWidget : Ldbxyzptlk/L1/f;
    //   321: invokevirtual put : (ILjava/lang/Object;)V
    //   324: aload_0
    //   325: getfield mTempMapIdToWidget : Landroid/util/SparseArray;
    //   328: aload_0
    //   329: invokevirtual getId : ()I
    //   332: aload_0
    //   333: getfield mLayoutWidget : Ldbxyzptlk/L1/f;
    //   336: invokevirtual put : (ILjava/lang/Object;)V
    //   339: iconst_0
    //   340: istore_1
    //   341: iload_1
    //   342: iload_2
    //   343: if_icmpge -> 381
    //   346: aload_0
    //   347: iload_1
    //   348: invokevirtual getChildAt : (I)Landroid/view/View;
    //   351: astore #6
    //   353: aload_0
    //   354: aload #6
    //   356: invokevirtual getViewWidget : (Landroid/view/View;)Ldbxyzptlk/L1/e;
    //   359: astore #5
    //   361: aload_0
    //   362: getfield mTempMapIdToWidget : Landroid/util/SparseArray;
    //   365: aload #6
    //   367: invokevirtual getId : ()I
    //   370: aload #5
    //   372: invokevirtual put : (ILjava/lang/Object;)V
    //   375: iinc #1, 1
    //   378: goto -> 341
    //   381: iconst_0
    //   382: istore_1
    //   383: iload_1
    //   384: iload_2
    //   385: if_icmpge -> 452
    //   388: aload_0
    //   389: iload_1
    //   390: invokevirtual getChildAt : (I)Landroid/view/View;
    //   393: astore #6
    //   395: aload_0
    //   396: aload #6
    //   398: invokevirtual getViewWidget : (Landroid/view/View;)Ldbxyzptlk/L1/e;
    //   401: astore #5
    //   403: aload #5
    //   405: ifnonnull -> 411
    //   408: goto -> 446
    //   411: aload #6
    //   413: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   416: checkcast androidx/constraintlayout/widget/ConstraintLayout$LayoutParams
    //   419: astore #7
    //   421: aload_0
    //   422: getfield mLayoutWidget : Ldbxyzptlk/L1/f;
    //   425: aload #5
    //   427: invokevirtual a : (Ldbxyzptlk/L1/e;)V
    //   430: aload_0
    //   431: iload #4
    //   433: aload #6
    //   435: aload #5
    //   437: aload #7
    //   439: aload_0
    //   440: getfield mTempMapIdToWidget : Landroid/util/SparseArray;
    //   443: invokevirtual applyConstraintsFromLayoutParams : (ZLandroid/view/View;Ldbxyzptlk/L1/e;Landroidx/constraintlayout/widget/ConstraintLayout$LayoutParams;Landroid/util/SparseArray;)V
    //   446: iinc #1, 1
    //   449: goto -> 383
    //   452: return
    //   453: astore #5
    //   455: goto -> 137
    // Exception table:
    //   from	to	target	type
    //   67	104	453	android/content/res/Resources$NotFoundException
    //   113	123	453	android/content/res/Resources$NotFoundException
    //   123	137	453	android/content/res/Resources$NotFoundException
  }
  
  private void setWidgetBaseline(e parame, LayoutParams paramLayoutParams, SparseArray<e> paramSparseArray, int paramInt, d.b paramb) {
    View view = (View)this.mChildrenByIds.get(paramInt);
    e e1 = (e)paramSparseArray.get(paramInt);
    if (e1 != null && view != null && view.getLayoutParams() instanceof LayoutParams) {
      paramLayoutParams.g0 = true;
      d.b b1 = d.b.BASELINE;
      if (paramb == b1) {
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        layoutParams.g0 = true;
        layoutParams.v0.Q0(true);
      } 
      parame.q(b1).b(e1.q(paramb), paramLayoutParams.D, paramLayoutParams.C, true);
      parame.Q0(true);
      parame.q(d.b.TOP).q();
      parame.q(d.b.BOTTOM).q();
    } 
  }
  
  private boolean updateHierarchy() {
    boolean bool1;
    int i = getChildCount();
    boolean bool2 = false;
    byte b1 = 0;
    while (true) {
      bool1 = bool2;
      if (b1 < i) {
        if (getChildAt(b1).isLayoutRequested()) {
          bool1 = true;
          break;
        } 
        b1++;
        continue;
      } 
      break;
    } 
    if (bool1)
      setChildrenConstraints(); 
    return bool1;
  }
  
  public void applyConstraintsFromLayoutParams(boolean paramBoolean, View paramView, e parame, LayoutParams paramLayoutParams, SparseArray<e> paramSparseArray) {
    paramLayoutParams.c();
    paramLayoutParams.w0 = false;
    parame.p1(paramView.getVisibility());
    if (paramLayoutParams.j0) {
      parame.Z0(true);
      parame.p1(8);
    } 
    parame.H0(paramView);
    if (paramView instanceof ConstraintHelper)
      ((ConstraintHelper)paramView).q(parame, this.mLayoutWidget.W1()); 
    if (paramLayoutParams.h0) {
      h h = (h)parame;
      int j = paramLayoutParams.s0;
      int i = paramLayoutParams.t0;
      float f1 = paramLayoutParams.u0;
      if (f1 != -1.0F) {
        h.F1(f1);
      } else if (j != -1) {
        h.D1(j);
      } else if (i != -1) {
        h.E1(i);
      } 
    } else {
      int m = paramLayoutParams.l0;
      int k = paramLayoutParams.m0;
      int i1 = paramLayoutParams.n0;
      int j = paramLayoutParams.o0;
      int n = paramLayoutParams.p0;
      int i2 = paramLayoutParams.q0;
      float f1 = paramLayoutParams.r0;
      int i = paramLayoutParams.p;
      if (i != -1) {
        e e1 = (e)paramSparseArray.get(i);
        if (e1 != null)
          parame.m(e1, paramLayoutParams.r, paramLayoutParams.q); 
      } else {
        if (m != -1) {
          e e1 = (e)paramSparseArray.get(m);
          if (e1 != null) {
            d.b b1 = d.b.LEFT;
            parame.i0(b1, e1, b1, paramLayoutParams.leftMargin, n);
          } 
        } else if (k != -1) {
          e e1 = (e)paramSparseArray.get(k);
          if (e1 != null)
            parame.i0(d.b.LEFT, e1, d.b.RIGHT, paramLayoutParams.leftMargin, n); 
        } 
        if (i1 != -1) {
          e e1 = (e)paramSparseArray.get(i1);
          if (e1 != null)
            parame.i0(d.b.RIGHT, e1, d.b.LEFT, paramLayoutParams.rightMargin, i2); 
        } else if (j != -1) {
          e e1 = (e)paramSparseArray.get(j);
          if (e1 != null) {
            d.b b1 = d.b.RIGHT;
            parame.i0(b1, e1, b1, paramLayoutParams.rightMargin, i2);
          } 
        } 
        i = paramLayoutParams.i;
        if (i != -1) {
          e e1 = (e)paramSparseArray.get(i);
          if (e1 != null) {
            d.b b1 = d.b.TOP;
            parame.i0(b1, e1, b1, paramLayoutParams.topMargin, paramLayoutParams.x);
          } 
        } else {
          i = paramLayoutParams.j;
          if (i != -1) {
            e e1 = (e)paramSparseArray.get(i);
            if (e1 != null)
              parame.i0(d.b.TOP, e1, d.b.BOTTOM, paramLayoutParams.topMargin, paramLayoutParams.x); 
          } 
        } 
        i = paramLayoutParams.k;
        if (i != -1) {
          e e1 = (e)paramSparseArray.get(i);
          if (e1 != null)
            parame.i0(d.b.BOTTOM, e1, d.b.TOP, paramLayoutParams.bottomMargin, paramLayoutParams.z); 
        } else {
          i = paramLayoutParams.l;
          if (i != -1) {
            e e1 = (e)paramSparseArray.get(i);
            if (e1 != null) {
              d.b b1 = d.b.BOTTOM;
              parame.i0(b1, e1, b1, paramLayoutParams.bottomMargin, paramLayoutParams.z);
            } 
          } 
        } 
        i = paramLayoutParams.m;
        if (i != -1) {
          setWidgetBaseline(parame, paramLayoutParams, paramSparseArray, i, d.b.BASELINE);
        } else {
          i = paramLayoutParams.n;
          if (i != -1) {
            setWidgetBaseline(parame, paramLayoutParams, paramSparseArray, i, d.b.TOP);
          } else {
            i = paramLayoutParams.o;
            if (i != -1)
              setWidgetBaseline(parame, paramLayoutParams, paramSparseArray, i, d.b.BOTTOM); 
          } 
        } 
        if (f1 >= 0.0F)
          parame.S0(f1); 
        f1 = paramLayoutParams.H;
        if (f1 >= 0.0F)
          parame.j1(f1); 
      } 
      if (paramBoolean) {
        i = paramLayoutParams.X;
        if (i != -1 || paramLayoutParams.Y != -1)
          parame.h1(i, paramLayoutParams.Y); 
      } 
      if (!paramLayoutParams.e0) {
        if (paramLayoutParams.width == -1) {
          if (paramLayoutParams.a0) {
            parame.V0(e.b.MATCH_CONSTRAINT);
          } else {
            parame.V0(e.b.MATCH_PARENT);
          } 
          (parame.q(d.b.LEFT)).g = paramLayoutParams.leftMargin;
          (parame.q(d.b.RIGHT)).g = paramLayoutParams.rightMargin;
        } else {
          parame.V0(e.b.MATCH_CONSTRAINT);
          parame.q1(0);
        } 
      } else {
        parame.V0(e.b.FIXED);
        parame.q1(paramLayoutParams.width);
        if (paramLayoutParams.width == -2)
          parame.V0(e.b.WRAP_CONTENT); 
      } 
      if (!paramLayoutParams.f0) {
        if (paramLayoutParams.height == -1) {
          if (paramLayoutParams.b0) {
            parame.m1(e.b.MATCH_CONSTRAINT);
          } else {
            parame.m1(e.b.MATCH_PARENT);
          } 
          (parame.q(d.b.TOP)).g = paramLayoutParams.topMargin;
          (parame.q(d.b.BOTTOM)).g = paramLayoutParams.bottomMargin;
        } else {
          parame.m1(e.b.MATCH_CONSTRAINT);
          parame.R0(0);
        } 
      } else {
        parame.m1(e.b.FIXED);
        parame.R0(paramLayoutParams.height);
        if (paramLayoutParams.height == -2)
          parame.m1(e.b.WRAP_CONTENT); 
      } 
      parame.J0(paramLayoutParams.I);
      parame.X0(paramLayoutParams.L);
      parame.o1(paramLayoutParams.M);
      parame.T0(paramLayoutParams.N);
      parame.k1(paramLayoutParams.O);
      parame.r1(paramLayoutParams.d0);
      parame.W0(paramLayoutParams.P, paramLayoutParams.R, paramLayoutParams.T, paramLayoutParams.V);
      parame.n1(paramLayoutParams.Q, paramLayoutParams.S, paramLayoutParams.U, paramLayoutParams.W);
    } 
  }
  
  public boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return paramLayoutParams instanceof LayoutParams;
  }
  
  public void dispatchDraw(Canvas paramCanvas) {
    ArrayList<ConstraintHelper> arrayList = this.mConstraintHelpers;
    if (arrayList != null) {
      int i = arrayList.size();
      if (i > 0)
        for (byte b1 = 0; b1 < i; b1++)
          ((ConstraintHelper)this.mConstraintHelpers.get(b1)).t(this);  
    } 
    super.dispatchDraw(paramCanvas);
    if (isInEditMode()) {
      float f2 = getWidth();
      float f1 = getHeight();
      int i = getChildCount();
      for (byte b1 = 0; b1 < i; b1++) {
        View view = getChildAt(b1);
        if (view.getVisibility() != 8) {
          Object object = view.getTag();
          if (object != null && object instanceof String) {
            object = ((String)object).split(",");
            if (object.length == 4) {
              int j = Integer.parseInt((String)object[0]);
              int n = Integer.parseInt((String)object[1]);
              int m = Integer.parseInt((String)object[2]);
              int k = Integer.parseInt((String)object[3]);
              j = (int)(j / 1080.0F * f2);
              n = (int)(n / 1920.0F * f1);
              m = (int)(m / 1080.0F * f2);
              k = (int)(k / 1920.0F * f1);
              object = new Paint();
              object.setColor(-65536);
              float f3 = j;
              float f6 = n;
              float f4 = (j + m);
              paramCanvas.drawLine(f3, f6, f4, f6, (Paint)object);
              float f5 = (n + k);
              paramCanvas.drawLine(f4, f6, f4, f5, (Paint)object);
              paramCanvas.drawLine(f4, f5, f3, f5, (Paint)object);
              paramCanvas.drawLine(f3, f5, f3, f6, (Paint)object);
              object.setColor(-16711936);
              paramCanvas.drawLine(f3, f6, f4, f5, (Paint)object);
              paramCanvas.drawLine(f3, f5, f4, f6, (Paint)object);
            } 
          } 
        } 
      } 
    } 
  }
  
  public void fillMetrics(e parame) {
    this.mLayoutWidget.O1(parame);
  }
  
  public void forceLayout() {
    markHierarchyDirty();
    super.forceLayout();
  }
  
  public LayoutParams generateDefaultLayoutParams() {
    return new LayoutParams(-2, -2);
  }
  
  public ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (ViewGroup.LayoutParams)new LayoutParams(paramLayoutParams);
  }
  
  public LayoutParams generateLayoutParams(AttributeSet paramAttributeSet) {
    return new LayoutParams(getContext(), paramAttributeSet);
  }
  
  public Object getDesignInformation(int paramInt, Object paramObject) {
    if (paramInt == 0 && paramObject instanceof String) {
      paramObject = paramObject;
      HashMap<String, Integer> hashMap = this.mDesignIds;
      if (hashMap != null && hashMap.containsKey(paramObject))
        return this.mDesignIds.get(paramObject); 
    } 
    return null;
  }
  
  public int getMaxHeight() {
    return this.mMaxHeight;
  }
  
  public int getMaxWidth() {
    return this.mMaxWidth;
  }
  
  public int getMinHeight() {
    return this.mMinHeight;
  }
  
  public int getMinWidth() {
    return this.mMinWidth;
  }
  
  public int getOptimizationLevel() {
    return this.mLayoutWidget.Q1();
  }
  
  public String getSceneString() {
    StringBuilder stringBuilder = new StringBuilder();
    if (((e)this.mLayoutWidget).o == null) {
      int i = getId();
      if (i != -1) {
        String str = getContext().getResources().getResourceEntryName(i);
        ((e)this.mLayoutWidget).o = str;
      } else {
        ((e)this.mLayoutWidget).o = "parent";
      } 
    } 
    if (this.mLayoutWidget.v() == null) {
      f f1 = this.mLayoutWidget;
      f1.I0(((e)f1).o);
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append(" setDebugName ");
      stringBuilder1.append(this.mLayoutWidget.v());
      Log.v("ConstraintLayout", stringBuilder1.toString());
    } 
    for (e e1 : this.mLayoutWidget.x1()) {
      View view = (View)e1.u();
      if (view != null) {
        if (e1.o == null) {
          int i = view.getId();
          if (i != -1)
            e1.o = getContext().getResources().getResourceEntryName(i); 
        } 
        if (e1.v() == null) {
          e1.I0(e1.o);
          StringBuilder stringBuilder1 = new StringBuilder();
          stringBuilder1.append(" setDebugName ");
          stringBuilder1.append(e1.v());
          Log.v("ConstraintLayout", stringBuilder1.toString());
        } 
      } 
    } 
    this.mLayoutWidget.R(stringBuilder);
    return stringBuilder.toString();
  }
  
  public View getViewById(int paramInt) {
    return (View)this.mChildrenByIds.get(paramInt);
  }
  
  public final e getViewWidget(View paramView) {
    if (paramView == this)
      return (e)this.mLayoutWidget; 
    if (paramView != null) {
      if (paramView.getLayoutParams() instanceof LayoutParams)
        return ((LayoutParams)paramView.getLayoutParams()).v0; 
      paramView.setLayoutParams(generateLayoutParams(paramView.getLayoutParams()));
      if (paramView.getLayoutParams() instanceof LayoutParams)
        return ((LayoutParams)paramView.getLayoutParams()).v0; 
    } 
    return null;
  }
  
  public boolean isRtl() {
    if (((getContext().getApplicationInfo()).flags & 0x400000) != 0) {
      int i = getLayoutDirection();
      boolean bool = true;
      if (1 == i)
        return bool; 
    } 
    return false;
  }
  
  public void loadLayoutDescription(int paramInt) {
    if (paramInt != 0) {
      try {
        dbxyzptlk.P1.a a1 = new dbxyzptlk.P1.a();
        this(getContext(), this, paramInt);
        this.mConstraintLayoutSpec = a1;
      } catch (android.content.res.Resources.NotFoundException notFoundException) {
        this.mConstraintLayoutSpec = null;
      } 
    } else {
      this.mConstraintLayoutSpec = null;
    } 
  }
  
  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    paramInt3 = getChildCount();
    paramBoolean = isInEditMode();
    paramInt2 = 0;
    for (paramInt1 = 0; paramInt1 < paramInt3; paramInt1++) {
      View view = getChildAt(paramInt1);
      LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
      e e1 = layoutParams.v0;
      if ((view.getVisibility() != 8 || layoutParams.h0 || layoutParams.i0 || layoutParams.k0 || paramBoolean) && !layoutParams.j0) {
        int k = e1.b0();
        int j = e1.c0();
        int i = e1.a0() + k;
        paramInt4 = e1.z() + j;
        view.layout(k, j, i, paramInt4);
        if (view instanceof Placeholder) {
          View view1 = ((Placeholder)view).getContent();
          if (view1 != null) {
            view1.setVisibility(0);
            view1.layout(k, j, i, paramInt4);
          } 
        } 
      } 
    } 
    paramInt3 = this.mConstraintHelpers.size();
    if (paramInt3 > 0)
      for (paramInt1 = paramInt2; paramInt1 < paramInt3; paramInt1++)
        ((ConstraintHelper)this.mConstraintHelpers.get(paramInt1)).r(this);  
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    if (this.mOnMeasureWidthMeasureSpec == paramInt1)
      int i = this.mOnMeasureHeightMeasureSpec; 
    if (!this.mDirtyHierarchy) {
      int i = getChildCount();
      for (byte b1 = 0; b1 < i; b1++) {
        if (getChildAt(b1).isLayoutRequested()) {
          this.mDirtyHierarchy = true;
          break;
        } 
      } 
    } 
    this.mOnMeasureWidthMeasureSpec = paramInt1;
    this.mOnMeasureHeightMeasureSpec = paramInt2;
    this.mLayoutWidget.f2(isRtl());
    if (this.mDirtyHierarchy) {
      this.mDirtyHierarchy = false;
      if (updateHierarchy())
        this.mLayoutWidget.h2(); 
    } 
    resolveSystem(this.mLayoutWidget, this.mOptimizationLevel, paramInt1, paramInt2);
    resolveMeasuredDimension(paramInt1, paramInt2, this.mLayoutWidget.a0(), this.mLayoutWidget.z(), this.mLayoutWidget.X1(), this.mLayoutWidget.V1());
  }
  
  public void onViewAdded(View paramView) {
    super.onViewAdded(paramView);
    e e1 = getViewWidget(paramView);
    if (paramView instanceof Guideline && !(e1 instanceof h)) {
      LayoutParams layoutParams = (LayoutParams)paramView.getLayoutParams();
      h h = new h();
      layoutParams.v0 = (e)h;
      layoutParams.h0 = true;
      h.G1(layoutParams.Z);
    } 
    if (paramView instanceof ConstraintHelper) {
      ConstraintHelper constraintHelper = (ConstraintHelper)paramView;
      constraintHelper.w();
      ((LayoutParams)paramView.getLayoutParams()).i0 = true;
      if (!this.mConstraintHelpers.contains(constraintHelper))
        this.mConstraintHelpers.add(constraintHelper); 
    } 
    this.mChildrenByIds.put(paramView.getId(), paramView);
    this.mDirtyHierarchy = true;
  }
  
  public void onViewRemoved(View paramView) {
    super.onViewRemoved(paramView);
    this.mChildrenByIds.remove(paramView.getId());
    e e1 = getViewWidget(paramView);
    this.mLayoutWidget.z1(e1);
    this.mConstraintHelpers.remove(paramView);
    this.mDirtyHierarchy = true;
  }
  
  public void parseLayoutDescription(int paramInt) {
    this.mConstraintLayoutSpec = new dbxyzptlk.P1.a(getContext(), this, paramInt);
  }
  
  public void requestLayout() {
    markHierarchyDirty();
    super.requestLayout();
  }
  
  public void resolveMeasuredDimension(int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean1, boolean paramBoolean2) {
    b b1 = this.mMeasurer;
    int i = b1.e;
    paramInt1 = View.resolveSizeAndState(paramInt3 + b1.d, paramInt1, 0);
    paramInt3 = View.resolveSizeAndState(paramInt4 + i, paramInt2, 0);
    paramInt2 = Math.min(this.mMaxWidth, paramInt1 & 0xFFFFFF);
    paramInt3 = Math.min(this.mMaxHeight, paramInt3 & 0xFFFFFF);
    paramInt1 = paramInt2;
    if (paramBoolean1)
      paramInt1 = paramInt2 | 0x1000000; 
    paramInt2 = paramInt3;
    if (paramBoolean2)
      paramInt2 = paramInt3 | 0x1000000; 
    setMeasuredDimension(paramInt1, paramInt2);
    this.mLastMeasureWidth = paramInt1;
    this.mLastMeasureHeight = paramInt2;
  }
  
  public void resolveSystem(f paramf, int paramInt1, int paramInt2, int paramInt3) {
    int k = View.MeasureSpec.getMode(paramInt2);
    int i1 = View.MeasureSpec.getSize(paramInt2);
    int i = View.MeasureSpec.getMode(paramInt3);
    int m = View.MeasureSpec.getSize(paramInt3);
    int j = Math.max(0, getPaddingTop());
    int i3 = Math.max(0, getPaddingBottom());
    int n = j + i3;
    int i2 = getPaddingWidth();
    this.mMeasurer.c(paramInt2, paramInt3, j, i3, i2, n);
    paramInt2 = Math.max(0, getPaddingStart());
    paramInt3 = Math.max(0, getPaddingEnd());
    if (paramInt2 > 0 || paramInt3 > 0) {
      if (isRtl())
        paramInt2 = paramInt3; 
    } else {
      paramInt2 = Math.max(0, getPaddingLeft());
    } 
    paramInt3 = i1 - i2;
    m -= n;
    setSelfDimensionBehaviour(paramf, k, paramInt3, i, m);
    paramf.Y1(paramInt1, k, paramInt3, i, m, this.mLastMeasureWidth, this.mLastMeasureHeight, paramInt2, j);
  }
  
  public void setConstraintSet(b paramb) {
    this.mConstraintSet = paramb;
  }
  
  public void setDesignInformation(int paramInt, Object paramObject1, Object paramObject2) {
    if (paramInt == 0 && paramObject1 instanceof String && paramObject2 instanceof Integer) {
      if (this.mDesignIds == null)
        this.mDesignIds = new HashMap<>(); 
      String str = (String)paramObject1;
      paramInt = str.indexOf("/");
      paramObject1 = str;
      if (paramInt != -1)
        paramObject1 = str.substring(paramInt + 1); 
      paramObject2 = paramObject2;
      paramObject2.intValue();
      this.mDesignIds.put(paramObject1, paramObject2);
    } 
  }
  
  public void setId(int paramInt) {
    this.mChildrenByIds.remove(getId());
    super.setId(paramInt);
    this.mChildrenByIds.put(getId(), this);
  }
  
  public void setMaxHeight(int paramInt) {
    if (paramInt == this.mMaxHeight)
      return; 
    this.mMaxHeight = paramInt;
    requestLayout();
  }
  
  public void setMaxWidth(int paramInt) {
    if (paramInt == this.mMaxWidth)
      return; 
    this.mMaxWidth = paramInt;
    requestLayout();
  }
  
  public void setMinHeight(int paramInt) {
    if (paramInt == this.mMinHeight)
      return; 
    this.mMinHeight = paramInt;
    requestLayout();
  }
  
  public void setMinWidth(int paramInt) {
    if (paramInt == this.mMinWidth)
      return; 
    this.mMinWidth = paramInt;
    requestLayout();
  }
  
  public void setOnConstraintsChanged(dbxyzptlk.P1.b paramb) {
    dbxyzptlk.P1.a a1 = this.mConstraintLayoutSpec;
    if (a1 != null)
      a1.c(paramb); 
  }
  
  public void setOptimizationLevel(int paramInt) {
    this.mOptimizationLevel = paramInt;
    this.mLayoutWidget.d2(paramInt);
  }
  
  public void setSelfDimensionBehaviour(f paramf, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    // Byte code:
    //   0: aload_0
    //   1: getfield mMeasurer : Landroidx/constraintlayout/widget/ConstraintLayout$b;
    //   4: astore #9
    //   6: aload #9
    //   8: getfield e : I
    //   11: istore #6
    //   13: aload #9
    //   15: getfield d : I
    //   18: istore #7
    //   20: getstatic dbxyzptlk/L1/e$b.FIXED : Ldbxyzptlk/L1/e$b;
    //   23: astore #9
    //   25: aload_0
    //   26: invokevirtual getChildCount : ()I
    //   29: istore #8
    //   31: iload_2
    //   32: ldc_w -2147483648
    //   35: if_icmpeq -> 107
    //   38: iload_2
    //   39: ifeq -> 77
    //   42: iload_2
    //   43: ldc_w 1073741824
    //   46: if_icmpeq -> 58
    //   49: aload #9
    //   51: astore #10
    //   53: iconst_0
    //   54: istore_3
    //   55: goto -> 134
    //   58: aload_0
    //   59: getfield mMaxWidth : I
    //   62: iload #7
    //   64: isub
    //   65: iload_3
    //   66: invokestatic min : (II)I
    //   69: istore_3
    //   70: aload #9
    //   72: astore #10
    //   74: goto -> 134
    //   77: getstatic dbxyzptlk/L1/e$b.WRAP_CONTENT : Ldbxyzptlk/L1/e$b;
    //   80: astore #11
    //   82: aload #11
    //   84: astore #10
    //   86: iload #8
    //   88: ifne -> 53
    //   91: iconst_0
    //   92: aload_0
    //   93: getfield mMinWidth : I
    //   96: invokestatic max : (II)I
    //   99: istore_3
    //   100: aload #11
    //   102: astore #10
    //   104: goto -> 134
    //   107: getstatic dbxyzptlk/L1/e$b.WRAP_CONTENT : Ldbxyzptlk/L1/e$b;
    //   110: astore #11
    //   112: aload #11
    //   114: astore #10
    //   116: iload #8
    //   118: ifne -> 134
    //   121: iconst_0
    //   122: aload_0
    //   123: getfield mMinWidth : I
    //   126: invokestatic max : (II)I
    //   129: istore_3
    //   130: aload #11
    //   132: astore #10
    //   134: iload #4
    //   136: ldc_w -2147483648
    //   139: if_icmpeq -> 209
    //   142: iload #4
    //   144: ifeq -> 178
    //   147: iload #4
    //   149: ldc_w 1073741824
    //   152: if_icmpeq -> 161
    //   155: iconst_0
    //   156: istore #5
    //   158: goto -> 237
    //   161: aload_0
    //   162: getfield mMaxHeight : I
    //   165: iload #6
    //   167: isub
    //   168: iload #5
    //   170: invokestatic min : (II)I
    //   173: istore #5
    //   175: goto -> 237
    //   178: getstatic dbxyzptlk/L1/e$b.WRAP_CONTENT : Ldbxyzptlk/L1/e$b;
    //   181: astore #11
    //   183: aload #11
    //   185: astore #9
    //   187: iload #8
    //   189: ifne -> 155
    //   192: iconst_0
    //   193: aload_0
    //   194: getfield mMinHeight : I
    //   197: invokestatic max : (II)I
    //   200: istore #5
    //   202: aload #11
    //   204: astore #9
    //   206: goto -> 237
    //   209: getstatic dbxyzptlk/L1/e$b.WRAP_CONTENT : Ldbxyzptlk/L1/e$b;
    //   212: astore #11
    //   214: aload #11
    //   216: astore #9
    //   218: iload #8
    //   220: ifne -> 237
    //   223: iconst_0
    //   224: aload_0
    //   225: getfield mMinHeight : I
    //   228: invokestatic max : (II)I
    //   231: istore #5
    //   233: aload #11
    //   235: astore #9
    //   237: iload_3
    //   238: aload_1
    //   239: invokevirtual a0 : ()I
    //   242: if_icmpne -> 254
    //   245: iload #5
    //   247: aload_1
    //   248: invokevirtual z : ()I
    //   251: if_icmpeq -> 258
    //   254: aload_1
    //   255: invokevirtual U1 : ()V
    //   258: aload_1
    //   259: iconst_0
    //   260: invokevirtual s1 : (I)V
    //   263: aload_1
    //   264: iconst_0
    //   265: invokevirtual t1 : (I)V
    //   268: aload_1
    //   269: aload_0
    //   270: getfield mMaxWidth : I
    //   273: iload #7
    //   275: isub
    //   276: invokevirtual d1 : (I)V
    //   279: aload_1
    //   280: aload_0
    //   281: getfield mMaxHeight : I
    //   284: iload #6
    //   286: isub
    //   287: invokevirtual c1 : (I)V
    //   290: aload_1
    //   291: iconst_0
    //   292: invokevirtual g1 : (I)V
    //   295: aload_1
    //   296: iconst_0
    //   297: invokevirtual f1 : (I)V
    //   300: aload_1
    //   301: aload #10
    //   303: invokevirtual V0 : (Ldbxyzptlk/L1/e$b;)V
    //   306: aload_1
    //   307: iload_3
    //   308: invokevirtual q1 : (I)V
    //   311: aload_1
    //   312: aload #9
    //   314: invokevirtual m1 : (Ldbxyzptlk/L1/e$b;)V
    //   317: aload_1
    //   318: iload #5
    //   320: invokevirtual R0 : (I)V
    //   323: aload_1
    //   324: aload_0
    //   325: getfield mMinWidth : I
    //   328: iload #7
    //   330: isub
    //   331: invokevirtual g1 : (I)V
    //   334: aload_1
    //   335: aload_0
    //   336: getfield mMinHeight : I
    //   339: iload #6
    //   341: isub
    //   342: invokevirtual f1 : (I)V
    //   345: return
  }
  
  public void setState(int paramInt1, int paramInt2, int paramInt3) {
    dbxyzptlk.P1.a a1 = this.mConstraintLayoutSpec;
    if (a1 != null)
      a1.d(paramInt1, paramInt2, paramInt3); 
  }
  
  public boolean shouldDelayChildPressedState() {
    return false;
  }
  
  public static class LayoutParams extends ViewGroup.MarginLayoutParams {
    public int A = Integer.MIN_VALUE;
    
    public int B = Integer.MIN_VALUE;
    
    public int C = Integer.MIN_VALUE;
    
    public int D = 0;
    
    public boolean E = true;
    
    public boolean F = true;
    
    public float G = 0.5F;
    
    public float H = 0.5F;
    
    public String I = null;
    
    public float J = 0.0F;
    
    public int K = 1;
    
    public float L = -1.0F;
    
    public float M = -1.0F;
    
    public int N = 0;
    
    public int O = 0;
    
    public int P = 0;
    
    public int Q = 0;
    
    public int R = 0;
    
    public int S = 0;
    
    public int T = 0;
    
    public int U = 0;
    
    public float V = 1.0F;
    
    public float W = 1.0F;
    
    public int X = -1;
    
    public int Y = -1;
    
    public int Z = -1;
    
    public int a = -1;
    
    public boolean a0 = false;
    
    public int b = -1;
    
    public boolean b0 = false;
    
    public float c = -1.0F;
    
    public String c0 = null;
    
    public boolean d = true;
    
    public int d0 = 0;
    
    public int e = -1;
    
    public boolean e0 = true;
    
    public int f = -1;
    
    public boolean f0 = true;
    
    public int g = -1;
    
    public boolean g0 = false;
    
    public int h = -1;
    
    public boolean h0 = false;
    
    public int i = -1;
    
    public boolean i0 = false;
    
    public int j = -1;
    
    public boolean j0 = false;
    
    public int k = -1;
    
    public boolean k0 = false;
    
    public int l = -1;
    
    public int l0 = -1;
    
    public int m = -1;
    
    public int m0 = -1;
    
    public int n = -1;
    
    public int n0 = -1;
    
    public int o = -1;
    
    public int o0 = -1;
    
    public int p = -1;
    
    public int p0 = Integer.MIN_VALUE;
    
    public int q = 0;
    
    public int q0 = Integer.MIN_VALUE;
    
    public float r = 0.0F;
    
    public float r0 = 0.5F;
    
    public int s = -1;
    
    public int s0;
    
    public int t = -1;
    
    public int t0;
    
    public int u = -1;
    
    public float u0;
    
    public int v = -1;
    
    public e v0 = new e();
    
    public int w = Integer.MIN_VALUE;
    
    public boolean w0 = false;
    
    public int x = Integer.MIN_VALUE;
    
    public int y = Integer.MIN_VALUE;
    
    public int z = Integer.MIN_VALUE;
    
    public LayoutParams(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
    }
    
    public LayoutParams(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
      TypedArray typedArray = param1Context.obtainStyledAttributes(param1AttributeSet, d.ConstraintLayout_Layout);
      int i = typedArray.getIndexCount();
      for (byte b = 0; b < i; b++) {
        float f;
        int j = typedArray.getIndex(b);
        int k = a.a.get(j);
        switch (k) {
          default:
            switch (k) {
              default:
                switch (k) {
                  default:
                    break;
                  case 67:
                    this.d = typedArray.getBoolean(j, this.d);
                    break;
                  case 66:
                    this.d0 = typedArray.getInt(j, this.d0);
                    break;
                  case 65:
                    b.F(this, typedArray, j, 1);
                    this.F = true;
                    break;
                  case 64:
                    break;
                } 
                b.F(this, typedArray, j, 0);
                this.E = true;
                break;
              case 55:
                this.C = typedArray.getDimensionPixelSize(j, this.C);
                break;
              case 54:
                this.D = typedArray.getDimensionPixelSize(j, this.D);
                break;
              case 53:
                k = typedArray.getResourceId(j, this.o);
                this.o = k;
                if (k == -1)
                  this.o = typedArray.getInt(j, -1); 
                break;
              case 52:
                k = typedArray.getResourceId(j, this.n);
                this.n = k;
                if (k == -1)
                  this.n = typedArray.getInt(j, -1); 
                break;
              case 51:
                this.c0 = typedArray.getString(j);
                break;
              case 50:
                this.Y = typedArray.getDimensionPixelOffset(j, this.Y);
                break;
              case 49:
                this.X = typedArray.getDimensionPixelOffset(j, this.X);
                break;
              case 48:
                this.O = typedArray.getInt(j, 0);
                break;
              case 47:
                this.N = typedArray.getInt(j, 0);
                break;
              case 46:
                this.M = typedArray.getFloat(j, this.M);
                break;
              case 45:
                this.L = typedArray.getFloat(j, this.L);
                break;
              case 44:
                break;
            } 
            b.H(this, typedArray.getString(j));
            break;
          case 38:
            this.W = Math.max(0.0F, typedArray.getFloat(j, this.W));
            this.Q = 2;
            break;
          case 37:
            try {
              this.U = typedArray.getDimensionPixelSize(j, this.U);
            } catch (Exception exception) {
              if (typedArray.getInt(j, this.U) == -2)
                this.U = -2; 
            } 
            break;
          case 36:
            try {
              this.S = typedArray.getDimensionPixelSize(j, this.S);
            } catch (Exception exception) {
              if (typedArray.getInt(j, this.S) == -2)
                this.S = -2; 
            } 
            break;
          case 35:
            this.V = Math.max(0.0F, typedArray.getFloat(j, this.V));
            this.P = 2;
            break;
          case 34:
            try {
              this.T = typedArray.getDimensionPixelSize(j, this.T);
            } catch (Exception exception) {
              if (typedArray.getInt(j, this.T) == -2)
                this.T = -2; 
            } 
            break;
          case 33:
            try {
              this.R = typedArray.getDimensionPixelSize(j, this.R);
            } catch (Exception exception) {
              if (typedArray.getInt(j, this.R) == -2)
                this.R = -2; 
            } 
            break;
          case 32:
            j = typedArray.getInt(j, 0);
            this.Q = j;
            if (j == 1)
              r0.d("ConstraintLayout", "layout_constraintHeight_default=\"wrap\" is deprecated.\nUse layout_height=\"WRAP_CONTENT\" and layout_constrainedHeight=\"true\" instead."); 
            break;
          case 31:
            j = typedArray.getInt(j, 0);
            this.P = j;
            if (j == 1)
              r0.d("ConstraintLayout", "layout_constraintWidth_default=\"wrap\" is deprecated.\nUse layout_width=\"WRAP_CONTENT\" and layout_constrainedWidth=\"true\" instead."); 
            break;
          case 30:
            this.H = typedArray.getFloat(j, this.H);
            break;
          case 29:
            this.G = typedArray.getFloat(j, this.G);
            break;
          case 28:
            this.b0 = typedArray.getBoolean(j, this.b0);
            break;
          case 27:
            this.a0 = typedArray.getBoolean(j, this.a0);
            break;
          case 26:
            this.B = typedArray.getDimensionPixelSize(j, this.B);
            break;
          case 25:
            this.A = typedArray.getDimensionPixelSize(j, this.A);
            break;
          case 24:
            this.z = typedArray.getDimensionPixelSize(j, this.z);
            break;
          case 23:
            this.y = typedArray.getDimensionPixelSize(j, this.y);
            break;
          case 22:
            this.x = typedArray.getDimensionPixelSize(j, this.x);
            break;
          case 21:
            this.w = typedArray.getDimensionPixelSize(j, this.w);
            break;
          case 20:
            k = typedArray.getResourceId(j, this.v);
            this.v = k;
            if (k == -1)
              this.v = typedArray.getInt(j, -1); 
            break;
          case 19:
            k = typedArray.getResourceId(j, this.u);
            this.u = k;
            if (k == -1)
              this.u = typedArray.getInt(j, -1); 
            break;
          case 18:
            k = typedArray.getResourceId(j, this.t);
            this.t = k;
            if (k == -1)
              this.t = typedArray.getInt(j, -1); 
            break;
          case 17:
            k = typedArray.getResourceId(j, this.s);
            this.s = k;
            if (k == -1)
              this.s = typedArray.getInt(j, -1); 
            break;
          case 16:
            k = typedArray.getResourceId(j, this.m);
            this.m = k;
            if (k == -1)
              this.m = typedArray.getInt(j, -1); 
            break;
          case 15:
            k = typedArray.getResourceId(j, this.l);
            this.l = k;
            if (k == -1)
              this.l = typedArray.getInt(j, -1); 
            break;
          case 14:
            k = typedArray.getResourceId(j, this.k);
            this.k = k;
            if (k == -1)
              this.k = typedArray.getInt(j, -1); 
            break;
          case 13:
            k = typedArray.getResourceId(j, this.j);
            this.j = k;
            if (k == -1)
              this.j = typedArray.getInt(j, -1); 
            break;
          case 12:
            k = typedArray.getResourceId(j, this.i);
            this.i = k;
            if (k == -1)
              this.i = typedArray.getInt(j, -1); 
            break;
          case 11:
            k = typedArray.getResourceId(j, this.h);
            this.h = k;
            if (k == -1)
              this.h = typedArray.getInt(j, -1); 
            break;
          case 10:
            k = typedArray.getResourceId(j, this.g);
            this.g = k;
            if (k == -1)
              this.g = typedArray.getInt(j, -1); 
            break;
          case 9:
            k = typedArray.getResourceId(j, this.f);
            this.f = k;
            if (k == -1)
              this.f = typedArray.getInt(j, -1); 
            break;
          case 8:
            k = typedArray.getResourceId(j, this.e);
            this.e = k;
            if (k == -1)
              this.e = typedArray.getInt(j, -1); 
            break;
          case 7:
            this.c = typedArray.getFloat(j, this.c);
            break;
          case 6:
            this.b = typedArray.getDimensionPixelOffset(j, this.b);
            break;
          case 5:
            this.a = typedArray.getDimensionPixelOffset(j, this.a);
            break;
          case 4:
            f = typedArray.getFloat(j, this.r) % 360.0F;
            this.r = f;
            if (f < 0.0F)
              this.r = (360.0F - f) % 360.0F; 
            break;
          case 3:
            this.q = typedArray.getDimensionPixelSize(j, this.q);
            break;
          case 2:
            k = typedArray.getResourceId(j, this.p);
            this.p = k;
            if (k == -1)
              this.p = typedArray.getInt(j, -1); 
            break;
          case 1:
            this.Z = typedArray.getInt(j, this.Z);
            break;
        } 
      } 
      typedArray.recycle();
      c();
    }
    
    public LayoutParams(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public String a() {
      return this.c0;
    }
    
    public e b() {
      return this.v0;
    }
    
    public void c() {
      this.h0 = false;
      this.e0 = true;
      this.f0 = true;
      int i = this.width;
      if (i == -2 && this.a0) {
        this.e0 = false;
        if (this.P == 0)
          this.P = 1; 
      } 
      int j = this.height;
      if (j == -2 && this.b0) {
        this.f0 = false;
        if (this.Q == 0)
          this.Q = 1; 
      } 
      if (i == 0 || i == -1) {
        this.e0 = false;
        if (i == 0 && this.P == 1) {
          this.width = -2;
          this.a0 = true;
        } 
      } 
      if (j == 0 || j == -1) {
        this.f0 = false;
        if (j == 0 && this.Q == 1) {
          this.height = -2;
          this.b0 = true;
        } 
      } 
      if (this.c != -1.0F || this.a != -1 || this.b != -1) {
        this.h0 = true;
        this.e0 = true;
        this.f0 = true;
        if (!(this.v0 instanceof h))
          this.v0 = (e)new h(); 
        ((h)this.v0).G1(this.Z);
      } 
    }
    
    @TargetApi(17)
    public void resolveLayoutDirection(int param1Int) {
      // Byte code:
      //   0: aload_0
      //   1: getfield leftMargin : I
      //   4: istore #5
      //   6: aload_0
      //   7: getfield rightMargin : I
      //   10: istore #6
      //   12: aload_0
      //   13: iload_1
      //   14: invokespecial resolveLayoutDirection : (I)V
      //   17: aload_0
      //   18: invokevirtual getLayoutDirection : ()I
      //   21: istore_1
      //   22: iconst_0
      //   23: istore #4
      //   25: iconst_1
      //   26: iload_1
      //   27: if_icmpne -> 35
      //   30: iconst_1
      //   31: istore_1
      //   32: goto -> 37
      //   35: iconst_0
      //   36: istore_1
      //   37: aload_0
      //   38: iconst_m1
      //   39: putfield n0 : I
      //   42: aload_0
      //   43: iconst_m1
      //   44: putfield o0 : I
      //   47: aload_0
      //   48: iconst_m1
      //   49: putfield l0 : I
      //   52: aload_0
      //   53: iconst_m1
      //   54: putfield m0 : I
      //   57: aload_0
      //   58: aload_0
      //   59: getfield w : I
      //   62: putfield p0 : I
      //   65: aload_0
      //   66: aload_0
      //   67: getfield y : I
      //   70: putfield q0 : I
      //   73: aload_0
      //   74: getfield G : F
      //   77: fstore_2
      //   78: aload_0
      //   79: fload_2
      //   80: putfield r0 : F
      //   83: aload_0
      //   84: getfield a : I
      //   87: istore #8
      //   89: aload_0
      //   90: iload #8
      //   92: putfield s0 : I
      //   95: aload_0
      //   96: getfield b : I
      //   99: istore #7
      //   101: aload_0
      //   102: iload #7
      //   104: putfield t0 : I
      //   107: aload_0
      //   108: getfield c : F
      //   111: fstore_3
      //   112: aload_0
      //   113: fload_3
      //   114: putfield u0 : F
      //   117: iload_1
      //   118: ifeq -> 355
      //   121: aload_0
      //   122: getfield s : I
      //   125: istore_1
      //   126: iload_1
      //   127: iconst_m1
      //   128: if_icmpeq -> 141
      //   131: aload_0
      //   132: iload_1
      //   133: putfield n0 : I
      //   136: iconst_1
      //   137: istore_1
      //   138: goto -> 165
      //   141: aload_0
      //   142: getfield t : I
      //   145: istore #9
      //   147: iload #4
      //   149: istore_1
      //   150: iload #9
      //   152: iconst_m1
      //   153: if_icmpeq -> 165
      //   156: aload_0
      //   157: iload #9
      //   159: putfield o0 : I
      //   162: goto -> 136
      //   165: aload_0
      //   166: getfield u : I
      //   169: istore #4
      //   171: iload #4
      //   173: iconst_m1
      //   174: if_icmpeq -> 185
      //   177: aload_0
      //   178: iload #4
      //   180: putfield m0 : I
      //   183: iconst_1
      //   184: istore_1
      //   185: aload_0
      //   186: getfield v : I
      //   189: istore #4
      //   191: iload #4
      //   193: iconst_m1
      //   194: if_icmpeq -> 205
      //   197: aload_0
      //   198: iload #4
      //   200: putfield l0 : I
      //   203: iconst_1
      //   204: istore_1
      //   205: aload_0
      //   206: getfield A : I
      //   209: istore #4
      //   211: iload #4
      //   213: ldc -2147483648
      //   215: if_icmpeq -> 224
      //   218: aload_0
      //   219: iload #4
      //   221: putfield q0 : I
      //   224: aload_0
      //   225: getfield B : I
      //   228: istore #4
      //   230: iload #4
      //   232: ldc -2147483648
      //   234: if_icmpeq -> 243
      //   237: aload_0
      //   238: iload #4
      //   240: putfield p0 : I
      //   243: iload_1
      //   244: ifeq -> 254
      //   247: aload_0
      //   248: fconst_1
      //   249: fload_2
      //   250: fsub
      //   251: putfield r0 : F
      //   254: aload_0
      //   255: getfield h0 : Z
      //   258: ifeq -> 447
      //   261: aload_0
      //   262: getfield Z : I
      //   265: iconst_1
      //   266: if_icmpne -> 447
      //   269: aload_0
      //   270: getfield d : Z
      //   273: ifeq -> 447
      //   276: fload_3
      //   277: ldc -1.0
      //   279: fcmpl
      //   280: ifeq -> 303
      //   283: aload_0
      //   284: fconst_1
      //   285: fload_3
      //   286: fsub
      //   287: putfield u0 : F
      //   290: aload_0
      //   291: iconst_m1
      //   292: putfield s0 : I
      //   295: aload_0
      //   296: iconst_m1
      //   297: putfield t0 : I
      //   300: goto -> 447
      //   303: iload #8
      //   305: iconst_m1
      //   306: if_icmpeq -> 329
      //   309: aload_0
      //   310: iload #8
      //   312: putfield t0 : I
      //   315: aload_0
      //   316: iconst_m1
      //   317: putfield s0 : I
      //   320: aload_0
      //   321: ldc -1.0
      //   323: putfield u0 : F
      //   326: goto -> 447
      //   329: iload #7
      //   331: iconst_m1
      //   332: if_icmpeq -> 447
      //   335: aload_0
      //   336: iload #7
      //   338: putfield s0 : I
      //   341: aload_0
      //   342: iconst_m1
      //   343: putfield t0 : I
      //   346: aload_0
      //   347: ldc -1.0
      //   349: putfield u0 : F
      //   352: goto -> 447
      //   355: aload_0
      //   356: getfield s : I
      //   359: istore_1
      //   360: iload_1
      //   361: iconst_m1
      //   362: if_icmpeq -> 370
      //   365: aload_0
      //   366: iload_1
      //   367: putfield m0 : I
      //   370: aload_0
      //   371: getfield t : I
      //   374: istore_1
      //   375: iload_1
      //   376: iconst_m1
      //   377: if_icmpeq -> 385
      //   380: aload_0
      //   381: iload_1
      //   382: putfield l0 : I
      //   385: aload_0
      //   386: getfield u : I
      //   389: istore_1
      //   390: iload_1
      //   391: iconst_m1
      //   392: if_icmpeq -> 400
      //   395: aload_0
      //   396: iload_1
      //   397: putfield n0 : I
      //   400: aload_0
      //   401: getfield v : I
      //   404: istore_1
      //   405: iload_1
      //   406: iconst_m1
      //   407: if_icmpeq -> 415
      //   410: aload_0
      //   411: iload_1
      //   412: putfield o0 : I
      //   415: aload_0
      //   416: getfield A : I
      //   419: istore_1
      //   420: iload_1
      //   421: ldc -2147483648
      //   423: if_icmpeq -> 431
      //   426: aload_0
      //   427: iload_1
      //   428: putfield p0 : I
      //   431: aload_0
      //   432: getfield B : I
      //   435: istore_1
      //   436: iload_1
      //   437: ldc -2147483648
      //   439: if_icmpeq -> 447
      //   442: aload_0
      //   443: iload_1
      //   444: putfield q0 : I
      //   447: aload_0
      //   448: getfield u : I
      //   451: iconst_m1
      //   452: if_icmpne -> 617
      //   455: aload_0
      //   456: getfield v : I
      //   459: iconst_m1
      //   460: if_icmpne -> 617
      //   463: aload_0
      //   464: getfield t : I
      //   467: iconst_m1
      //   468: if_icmpne -> 617
      //   471: aload_0
      //   472: getfield s : I
      //   475: iconst_m1
      //   476: if_icmpne -> 617
      //   479: aload_0
      //   480: getfield g : I
      //   483: istore_1
      //   484: iload_1
      //   485: iconst_m1
      //   486: if_icmpeq -> 515
      //   489: aload_0
      //   490: iload_1
      //   491: putfield n0 : I
      //   494: aload_0
      //   495: getfield rightMargin : I
      //   498: ifgt -> 548
      //   501: iload #6
      //   503: ifle -> 548
      //   506: aload_0
      //   507: iload #6
      //   509: putfield rightMargin : I
      //   512: goto -> 548
      //   515: aload_0
      //   516: getfield h : I
      //   519: istore_1
      //   520: iload_1
      //   521: iconst_m1
      //   522: if_icmpeq -> 548
      //   525: aload_0
      //   526: iload_1
      //   527: putfield o0 : I
      //   530: aload_0
      //   531: getfield rightMargin : I
      //   534: ifgt -> 548
      //   537: iload #6
      //   539: ifle -> 548
      //   542: aload_0
      //   543: iload #6
      //   545: putfield rightMargin : I
      //   548: aload_0
      //   549: getfield e : I
      //   552: istore_1
      //   553: iload_1
      //   554: iconst_m1
      //   555: if_icmpeq -> 584
      //   558: aload_0
      //   559: iload_1
      //   560: putfield l0 : I
      //   563: aload_0
      //   564: getfield leftMargin : I
      //   567: ifgt -> 617
      //   570: iload #5
      //   572: ifle -> 617
      //   575: aload_0
      //   576: iload #5
      //   578: putfield leftMargin : I
      //   581: goto -> 617
      //   584: aload_0
      //   585: getfield f : I
      //   588: istore_1
      //   589: iload_1
      //   590: iconst_m1
      //   591: if_icmpeq -> 617
      //   594: aload_0
      //   595: iload_1
      //   596: putfield m0 : I
      //   599: aload_0
      //   600: getfield leftMargin : I
      //   603: ifgt -> 617
      //   606: iload #5
      //   608: ifle -> 617
      //   611: aload_0
      //   612: iload #5
      //   614: putfield leftMargin : I
      //   617: return
    }
    
    public static class a {
      public static final SparseIntArray a;
      
      static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        a = sparseIntArray;
        sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintWidth, 64);
        sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintHeight, 65);
        sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintLeft_toLeftOf, 8);
        sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintLeft_toRightOf, 9);
        sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintRight_toLeftOf, 10);
        sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintRight_toRightOf, 11);
        sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintTop_toTopOf, 12);
        sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintTop_toBottomOf, 13);
        sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintBottom_toTopOf, 14);
        sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintBottom_toBottomOf, 15);
        sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintBaseline_toBaselineOf, 16);
        sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintBaseline_toTopOf, 52);
        sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintBaseline_toBottomOf, 53);
        sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintCircle, 2);
        sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintCircleRadius, 3);
        sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintCircleAngle, 4);
        sparseIntArray.append(d.ConstraintLayout_Layout_layout_editor_absoluteX, 49);
        sparseIntArray.append(d.ConstraintLayout_Layout_layout_editor_absoluteY, 50);
        sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintGuide_begin, 5);
        sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintGuide_end, 6);
        sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintGuide_percent, 7);
        sparseIntArray.append(d.ConstraintLayout_Layout_guidelineUseRtl, 67);
        sparseIntArray.append(d.ConstraintLayout_Layout_android_orientation, 1);
        sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintStart_toEndOf, 17);
        sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintStart_toStartOf, 18);
        sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintEnd_toStartOf, 19);
        sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintEnd_toEndOf, 20);
        sparseIntArray.append(d.ConstraintLayout_Layout_layout_goneMarginLeft, 21);
        sparseIntArray.append(d.ConstraintLayout_Layout_layout_goneMarginTop, 22);
        sparseIntArray.append(d.ConstraintLayout_Layout_layout_goneMarginRight, 23);
        sparseIntArray.append(d.ConstraintLayout_Layout_layout_goneMarginBottom, 24);
        sparseIntArray.append(d.ConstraintLayout_Layout_layout_goneMarginStart, 25);
        sparseIntArray.append(d.ConstraintLayout_Layout_layout_goneMarginEnd, 26);
        sparseIntArray.append(d.ConstraintLayout_Layout_layout_goneMarginBaseline, 55);
        sparseIntArray.append(d.ConstraintLayout_Layout_layout_marginBaseline, 54);
        sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintHorizontal_bias, 29);
        sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintVertical_bias, 30);
        sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintDimensionRatio, 44);
        sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintHorizontal_weight, 45);
        sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintVertical_weight, 46);
        sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintHorizontal_chainStyle, 47);
        sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintVertical_chainStyle, 48);
        sparseIntArray.append(d.ConstraintLayout_Layout_layout_constrainedWidth, 27);
        sparseIntArray.append(d.ConstraintLayout_Layout_layout_constrainedHeight, 28);
        sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintWidth_default, 31);
        sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintHeight_default, 32);
        sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintWidth_min, 33);
        sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintWidth_max, 34);
        sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintWidth_percent, 35);
        sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintHeight_min, 36);
        sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintHeight_max, 37);
        sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintHeight_percent, 38);
        sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintLeft_creator, 39);
        sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintTop_creator, 40);
        sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintRight_creator, 41);
        sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintBottom_creator, 42);
        sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintBaseline_creator, 43);
        sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintTag, 51);
        sparseIntArray.append(d.ConstraintLayout_Layout_layout_wrapBehaviorInParent, 66);
      }
    }
  }
  
  public static class a {
    public static final SparseIntArray a;
    
    static {
      SparseIntArray sparseIntArray = new SparseIntArray();
      a = sparseIntArray;
      sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintWidth, 64);
      sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintHeight, 65);
      sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintLeft_toLeftOf, 8);
      sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintLeft_toRightOf, 9);
      sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintRight_toLeftOf, 10);
      sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintRight_toRightOf, 11);
      sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintTop_toTopOf, 12);
      sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintTop_toBottomOf, 13);
      sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintBottom_toTopOf, 14);
      sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintBottom_toBottomOf, 15);
      sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintBaseline_toBaselineOf, 16);
      sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintBaseline_toTopOf, 52);
      sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintBaseline_toBottomOf, 53);
      sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintCircle, 2);
      sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintCircleRadius, 3);
      sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintCircleAngle, 4);
      sparseIntArray.append(d.ConstraintLayout_Layout_layout_editor_absoluteX, 49);
      sparseIntArray.append(d.ConstraintLayout_Layout_layout_editor_absoluteY, 50);
      sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintGuide_begin, 5);
      sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintGuide_end, 6);
      sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintGuide_percent, 7);
      sparseIntArray.append(d.ConstraintLayout_Layout_guidelineUseRtl, 67);
      sparseIntArray.append(d.ConstraintLayout_Layout_android_orientation, 1);
      sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintStart_toEndOf, 17);
      sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintStart_toStartOf, 18);
      sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintEnd_toStartOf, 19);
      sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintEnd_toEndOf, 20);
      sparseIntArray.append(d.ConstraintLayout_Layout_layout_goneMarginLeft, 21);
      sparseIntArray.append(d.ConstraintLayout_Layout_layout_goneMarginTop, 22);
      sparseIntArray.append(d.ConstraintLayout_Layout_layout_goneMarginRight, 23);
      sparseIntArray.append(d.ConstraintLayout_Layout_layout_goneMarginBottom, 24);
      sparseIntArray.append(d.ConstraintLayout_Layout_layout_goneMarginStart, 25);
      sparseIntArray.append(d.ConstraintLayout_Layout_layout_goneMarginEnd, 26);
      sparseIntArray.append(d.ConstraintLayout_Layout_layout_goneMarginBaseline, 55);
      sparseIntArray.append(d.ConstraintLayout_Layout_layout_marginBaseline, 54);
      sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintHorizontal_bias, 29);
      sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintVertical_bias, 30);
      sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintDimensionRatio, 44);
      sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintHorizontal_weight, 45);
      sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintVertical_weight, 46);
      sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintHorizontal_chainStyle, 47);
      sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintVertical_chainStyle, 48);
      sparseIntArray.append(d.ConstraintLayout_Layout_layout_constrainedWidth, 27);
      sparseIntArray.append(d.ConstraintLayout_Layout_layout_constrainedHeight, 28);
      sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintWidth_default, 31);
      sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintHeight_default, 32);
      sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintWidth_min, 33);
      sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintWidth_max, 34);
      sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintWidth_percent, 35);
      sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintHeight_min, 36);
      sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintHeight_max, 37);
      sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintHeight_percent, 38);
      sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintLeft_creator, 39);
      sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintTop_creator, 40);
      sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintRight_creator, 41);
      sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintBottom_creator, 42);
      sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintBaseline_creator, 43);
      sparseIntArray.append(d.ConstraintLayout_Layout_layout_constraintTag, 51);
      sparseIntArray.append(d.ConstraintLayout_Layout_layout_wrapBehaviorInParent, 66);
    }
  }
  
  public class b implements dbxyzptlk.M1.b.b {
    public ConstraintLayout a;
    
    public int b;
    
    public int c;
    
    public int d;
    
    public int e;
    
    public int f;
    
    public int g;
    
    public final ConstraintLayout h;
    
    public b(ConstraintLayout this$0, ConstraintLayout param1ConstraintLayout1) {
      this.a = param1ConstraintLayout1;
    }
    
    @SuppressLint({"WrongCall"})
    public final void a(e param1e, dbxyzptlk.M1.b.a param1a) {
      // Byte code:
      //   0: aload_1
      //   1: ifnonnull -> 5
      //   4: return
      //   5: aload_1
      //   6: invokevirtual Z : ()I
      //   9: bipush #8
      //   11: if_icmpne -> 37
      //   14: aload_1
      //   15: invokevirtual n0 : ()Z
      //   18: ifne -> 37
      //   21: aload_2
      //   22: iconst_0
      //   23: putfield e : I
      //   26: aload_2
      //   27: iconst_0
      //   28: putfield f : I
      //   31: aload_2
      //   32: iconst_0
      //   33: putfield g : I
      //   36: return
      //   37: aload_1
      //   38: invokevirtual N : ()Ldbxyzptlk/L1/e;
      //   41: ifnonnull -> 45
      //   44: return
      //   45: aload_2
      //   46: getfield a : Ldbxyzptlk/L1/e$b;
      //   49: astore #21
      //   51: aload_2
      //   52: getfield b : Ldbxyzptlk/L1/e$b;
      //   55: astore #20
      //   57: aload_2
      //   58: getfield c : I
      //   61: istore #5
      //   63: aload_2
      //   64: getfield d : I
      //   67: istore #8
      //   69: aload_0
      //   70: getfield b : I
      //   73: aload_0
      //   74: getfield c : I
      //   77: iadd
      //   78: istore #7
      //   80: aload_0
      //   81: getfield d : I
      //   84: istore #6
      //   86: aload_1
      //   87: invokevirtual u : ()Ljava/lang/Object;
      //   90: checkcast android/view/View
      //   93: astore #19
      //   95: getstatic androidx/constraintlayout/widget/ConstraintLayout$a.a : [I
      //   98: astore #22
      //   100: aload #22
      //   102: aload #21
      //   104: invokevirtual ordinal : ()I
      //   107: iaload
      //   108: istore #4
      //   110: iload #4
      //   112: iconst_1
      //   113: if_icmpeq -> 311
      //   116: iload #4
      //   118: iconst_2
      //   119: if_icmpeq -> 295
      //   122: iload #4
      //   124: iconst_3
      //   125: if_icmpeq -> 275
      //   128: iload #4
      //   130: iconst_4
      //   131: if_icmpeq -> 140
      //   134: iconst_0
      //   135: istore #4
      //   137: goto -> 320
      //   140: aload_0
      //   141: getfield f : I
      //   144: iload #6
      //   146: bipush #-2
      //   148: invokestatic getChildMeasureSpec : (III)I
      //   151: istore #6
      //   153: aload_1
      //   154: getfield w : I
      //   157: iconst_1
      //   158: if_icmpne -> 167
      //   161: iconst_1
      //   162: istore #5
      //   164: goto -> 170
      //   167: iconst_0
      //   168: istore #5
      //   170: aload_2
      //   171: getfield j : I
      //   174: istore #9
      //   176: iload #9
      //   178: getstatic dbxyzptlk/M1/b$a.l : I
      //   181: if_icmpeq -> 196
      //   184: iload #6
      //   186: istore #4
      //   188: iload #9
      //   190: getstatic dbxyzptlk/M1/b$a.m : I
      //   193: if_icmpne -> 320
      //   196: aload #19
      //   198: invokevirtual getMeasuredHeight : ()I
      //   201: aload_1
      //   202: invokevirtual z : ()I
      //   205: if_icmpne -> 214
      //   208: iconst_1
      //   209: istore #4
      //   211: goto -> 217
      //   214: iconst_0
      //   215: istore #4
      //   217: aload_2
      //   218: getfield j : I
      //   221: getstatic dbxyzptlk/M1/b$a.m : I
      //   224: if_icmpeq -> 261
      //   227: iload #5
      //   229: ifeq -> 261
      //   232: iload #5
      //   234: ifeq -> 242
      //   237: iload #4
      //   239: ifne -> 261
      //   242: aload #19
      //   244: instanceof androidx/constraintlayout/widget/Placeholder
      //   247: ifne -> 261
      //   250: iload #6
      //   252: istore #4
      //   254: aload_1
      //   255: invokevirtual r0 : ()Z
      //   258: ifeq -> 320
      //   261: aload_1
      //   262: invokevirtual a0 : ()I
      //   265: ldc 1073741824
      //   267: invokestatic makeMeasureSpec : (II)I
      //   270: istore #4
      //   272: goto -> 320
      //   275: aload_0
      //   276: getfield f : I
      //   279: iload #6
      //   281: aload_1
      //   282: invokevirtual D : ()I
      //   285: iadd
      //   286: iconst_m1
      //   287: invokestatic getChildMeasureSpec : (III)I
      //   290: istore #4
      //   292: goto -> 320
      //   295: aload_0
      //   296: getfield f : I
      //   299: iload #6
      //   301: bipush #-2
      //   303: invokestatic getChildMeasureSpec : (III)I
      //   306: istore #4
      //   308: goto -> 320
      //   311: iload #5
      //   313: ldc 1073741824
      //   315: invokestatic makeMeasureSpec : (II)I
      //   318: istore #4
      //   320: aload #22
      //   322: aload #20
      //   324: invokevirtual ordinal : ()I
      //   327: iaload
      //   328: istore #5
      //   330: iload #5
      //   332: iconst_1
      //   333: if_icmpeq -> 531
      //   336: iload #5
      //   338: iconst_2
      //   339: if_icmpeq -> 515
      //   342: iload #5
      //   344: iconst_3
      //   345: if_icmpeq -> 495
      //   348: iload #5
      //   350: iconst_4
      //   351: if_icmpeq -> 360
      //   354: iconst_0
      //   355: istore #5
      //   357: goto -> 540
      //   360: aload_0
      //   361: getfield g : I
      //   364: iload #7
      //   366: bipush #-2
      //   368: invokestatic getChildMeasureSpec : (III)I
      //   371: istore #7
      //   373: aload_1
      //   374: getfield x : I
      //   377: iconst_1
      //   378: if_icmpne -> 387
      //   381: iconst_1
      //   382: istore #6
      //   384: goto -> 390
      //   387: iconst_0
      //   388: istore #6
      //   390: aload_2
      //   391: getfield j : I
      //   394: istore #8
      //   396: iload #8
      //   398: getstatic dbxyzptlk/M1/b$a.l : I
      //   401: if_icmpeq -> 416
      //   404: iload #7
      //   406: istore #5
      //   408: iload #8
      //   410: getstatic dbxyzptlk/M1/b$a.m : I
      //   413: if_icmpne -> 540
      //   416: aload #19
      //   418: invokevirtual getMeasuredWidth : ()I
      //   421: aload_1
      //   422: invokevirtual a0 : ()I
      //   425: if_icmpne -> 434
      //   428: iconst_1
      //   429: istore #5
      //   431: goto -> 437
      //   434: iconst_0
      //   435: istore #5
      //   437: aload_2
      //   438: getfield j : I
      //   441: getstatic dbxyzptlk/M1/b$a.m : I
      //   444: if_icmpeq -> 481
      //   447: iload #6
      //   449: ifeq -> 481
      //   452: iload #6
      //   454: ifeq -> 462
      //   457: iload #5
      //   459: ifne -> 481
      //   462: aload #19
      //   464: instanceof androidx/constraintlayout/widget/Placeholder
      //   467: ifne -> 481
      //   470: iload #7
      //   472: istore #5
      //   474: aload_1
      //   475: invokevirtual s0 : ()Z
      //   478: ifeq -> 540
      //   481: aload_1
      //   482: invokevirtual z : ()I
      //   485: ldc 1073741824
      //   487: invokestatic makeMeasureSpec : (II)I
      //   490: istore #5
      //   492: goto -> 540
      //   495: aload_0
      //   496: getfield g : I
      //   499: iload #7
      //   501: aload_1
      //   502: invokevirtual Y : ()I
      //   505: iadd
      //   506: iconst_m1
      //   507: invokestatic getChildMeasureSpec : (III)I
      //   510: istore #5
      //   512: goto -> 540
      //   515: aload_0
      //   516: getfield g : I
      //   519: iload #7
      //   521: bipush #-2
      //   523: invokestatic getChildMeasureSpec : (III)I
      //   526: istore #5
      //   528: goto -> 540
      //   531: iload #8
      //   533: ldc 1073741824
      //   535: invokestatic makeMeasureSpec : (II)I
      //   538: istore #5
      //   540: aload_1
      //   541: invokevirtual N : ()Ldbxyzptlk/L1/e;
      //   544: checkcast dbxyzptlk/L1/f
      //   547: astore #22
      //   549: aload #22
      //   551: ifnull -> 698
      //   554: aload_0
      //   555: getfield h : Landroidx/constraintlayout/widget/ConstraintLayout;
      //   558: invokestatic access$000 : (Landroidx/constraintlayout/widget/ConstraintLayout;)I
      //   561: sipush #256
      //   564: invokestatic b : (II)Z
      //   567: ifeq -> 698
      //   570: aload #19
      //   572: invokevirtual getMeasuredWidth : ()I
      //   575: aload_1
      //   576: invokevirtual a0 : ()I
      //   579: if_icmpne -> 698
      //   582: aload #19
      //   584: invokevirtual getMeasuredWidth : ()I
      //   587: aload #22
      //   589: invokevirtual a0 : ()I
      //   592: if_icmpge -> 698
      //   595: aload #19
      //   597: invokevirtual getMeasuredHeight : ()I
      //   600: aload_1
      //   601: invokevirtual z : ()I
      //   604: if_icmpne -> 698
      //   607: aload #19
      //   609: invokevirtual getMeasuredHeight : ()I
      //   612: aload #22
      //   614: invokevirtual z : ()I
      //   617: if_icmpge -> 698
      //   620: aload #19
      //   622: invokevirtual getBaseline : ()I
      //   625: aload_1
      //   626: invokevirtual r : ()I
      //   629: if_icmpne -> 698
      //   632: aload_1
      //   633: invokevirtual q0 : ()Z
      //   636: ifne -> 698
      //   639: aload_0
      //   640: aload_1
      //   641: invokevirtual E : ()I
      //   644: iload #4
      //   646: aload_1
      //   647: invokevirtual a0 : ()I
      //   650: invokevirtual d : (III)Z
      //   653: ifeq -> 698
      //   656: aload_0
      //   657: aload_1
      //   658: invokevirtual F : ()I
      //   661: iload #5
      //   663: aload_1
      //   664: invokevirtual z : ()I
      //   667: invokevirtual d : (III)Z
      //   670: ifeq -> 698
      //   673: aload_2
      //   674: aload_1
      //   675: invokevirtual a0 : ()I
      //   678: putfield e : I
      //   681: aload_2
      //   682: aload_1
      //   683: invokevirtual z : ()I
      //   686: putfield f : I
      //   689: aload_2
      //   690: aload_1
      //   691: invokevirtual r : ()I
      //   694: putfield g : I
      //   697: return
      //   698: getstatic dbxyzptlk/L1/e$b.MATCH_CONSTRAINT : Ldbxyzptlk/L1/e$b;
      //   701: astore #22
      //   703: aload #21
      //   705: aload #22
      //   707: if_acmpne -> 716
      //   710: iconst_1
      //   711: istore #6
      //   713: goto -> 719
      //   716: iconst_0
      //   717: istore #6
      //   719: aload #20
      //   721: aload #22
      //   723: if_acmpne -> 732
      //   726: iconst_1
      //   727: istore #7
      //   729: goto -> 735
      //   732: iconst_0
      //   733: istore #7
      //   735: getstatic dbxyzptlk/L1/e$b.MATCH_PARENT : Ldbxyzptlk/L1/e$b;
      //   738: astore #22
      //   740: aload #20
      //   742: aload #22
      //   744: if_acmpeq -> 764
      //   747: aload #20
      //   749: getstatic dbxyzptlk/L1/e$b.FIXED : Ldbxyzptlk/L1/e$b;
      //   752: if_acmpne -> 758
      //   755: goto -> 764
      //   758: iconst_0
      //   759: istore #10
      //   761: goto -> 767
      //   764: iconst_1
      //   765: istore #10
      //   767: aload #21
      //   769: aload #22
      //   771: if_acmpeq -> 791
      //   774: aload #21
      //   776: getstatic dbxyzptlk/L1/e$b.FIXED : Ldbxyzptlk/L1/e$b;
      //   779: if_acmpne -> 785
      //   782: goto -> 791
      //   785: iconst_0
      //   786: istore #11
      //   788: goto -> 794
      //   791: iconst_1
      //   792: istore #11
      //   794: iload #6
      //   796: ifeq -> 814
      //   799: aload_1
      //   800: getfield f0 : F
      //   803: fconst_0
      //   804: fcmpl
      //   805: ifle -> 814
      //   808: iconst_1
      //   809: istore #12
      //   811: goto -> 817
      //   814: iconst_0
      //   815: istore #12
      //   817: iload #7
      //   819: ifeq -> 837
      //   822: aload_1
      //   823: getfield f0 : F
      //   826: fconst_0
      //   827: fcmpl
      //   828: ifle -> 837
      //   831: iconst_1
      //   832: istore #13
      //   834: goto -> 840
      //   837: iconst_0
      //   838: istore #13
      //   840: aload #19
      //   842: ifnonnull -> 846
      //   845: return
      //   846: aload #19
      //   848: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
      //   851: checkcast androidx/constraintlayout/widget/ConstraintLayout$LayoutParams
      //   854: astore #21
      //   856: aload_2
      //   857: getfield j : I
      //   860: istore #8
      //   862: iload #8
      //   864: getstatic dbxyzptlk/M1/b$a.l : I
      //   867: if_icmpeq -> 917
      //   870: iload #8
      //   872: getstatic dbxyzptlk/M1/b$a.m : I
      //   875: if_icmpeq -> 917
      //   878: iload #6
      //   880: ifeq -> 917
      //   883: aload_1
      //   884: getfield w : I
      //   887: ifne -> 917
      //   890: iload #7
      //   892: ifeq -> 917
      //   895: aload_1
      //   896: getfield x : I
      //   899: ifeq -> 905
      //   902: goto -> 917
      //   905: iconst_0
      //   906: istore #6
      //   908: iconst_0
      //   909: istore #9
      //   911: iconst_0
      //   912: istore #10
      //   914: goto -> 1304
      //   917: aload #19
      //   919: instanceof androidx/constraintlayout/widget/VirtualLayout
      //   922: ifeq -> 955
      //   925: aload_1
      //   926: instanceof dbxyzptlk/L1/m
      //   929: ifeq -> 955
      //   932: aload_1
      //   933: checkcast dbxyzptlk/L1/m
      //   936: astore #20
      //   938: aload #19
      //   940: checkcast androidx/constraintlayout/widget/VirtualLayout
      //   943: aload #20
      //   945: iload #4
      //   947: iload #5
      //   949: invokevirtual x : (Ldbxyzptlk/L1/m;II)V
      //   952: goto -> 964
      //   955: aload #19
      //   957: iload #4
      //   959: iload #5
      //   961: invokevirtual measure : (II)V
      //   964: aload_1
      //   965: iload #4
      //   967: iload #5
      //   969: invokevirtual b1 : (II)V
      //   972: aload #19
      //   974: invokevirtual getMeasuredWidth : ()I
      //   977: istore #15
      //   979: aload #19
      //   981: invokevirtual getMeasuredHeight : ()I
      //   984: istore #14
      //   986: aload #19
      //   988: invokevirtual getBaseline : ()I
      //   991: istore #16
      //   993: aload_1
      //   994: getfield z : I
      //   997: istore #6
      //   999: iload #6
      //   1001: ifle -> 1016
      //   1004: iload #6
      //   1006: iload #15
      //   1008: invokestatic max : (II)I
      //   1011: istore #7
      //   1013: goto -> 1020
      //   1016: iload #15
      //   1018: istore #7
      //   1020: aload_1
      //   1021: getfield A : I
      //   1024: istore #8
      //   1026: iload #7
      //   1028: istore #6
      //   1030: iload #8
      //   1032: ifle -> 1044
      //   1035: iload #8
      //   1037: iload #7
      //   1039: invokestatic min : (II)I
      //   1042: istore #6
      //   1044: aload_1
      //   1045: getfield C : I
      //   1048: istore #7
      //   1050: iload #7
      //   1052: ifle -> 1067
      //   1055: iload #7
      //   1057: iload #14
      //   1059: invokestatic max : (II)I
      //   1062: istore #7
      //   1064: goto -> 1071
      //   1067: iload #14
      //   1069: istore #7
      //   1071: aload_1
      //   1072: getfield D : I
      //   1075: istore #8
      //   1077: iload #7
      //   1079: istore #9
      //   1081: iload #8
      //   1083: ifle -> 1095
      //   1086: iload #8
      //   1088: iload #7
      //   1090: invokestatic min : (II)I
      //   1093: istore #9
      //   1095: iload #9
      //   1097: istore #7
      //   1099: iload #6
      //   1101: istore #8
      //   1103: aload_0
      //   1104: getfield h : Landroidx/constraintlayout/widget/ConstraintLayout;
      //   1107: invokestatic access$000 : (Landroidx/constraintlayout/widget/ConstraintLayout;)I
      //   1110: iconst_1
      //   1111: invokestatic b : (II)Z
      //   1114: ifne -> 1196
      //   1117: iload #12
      //   1119: ifeq -> 1150
      //   1122: iload #10
      //   1124: ifeq -> 1150
      //   1127: aload_1
      //   1128: getfield f0 : F
      //   1131: fstore_3
      //   1132: iload #9
      //   1134: i2f
      //   1135: fload_3
      //   1136: fmul
      //   1137: ldc 0.5
      //   1139: fadd
      //   1140: f2i
      //   1141: istore #8
      //   1143: iload #9
      //   1145: istore #7
      //   1147: goto -> 1196
      //   1150: iload #9
      //   1152: istore #7
      //   1154: iload #6
      //   1156: istore #8
      //   1158: iload #13
      //   1160: ifeq -> 1196
      //   1163: iload #9
      //   1165: istore #7
      //   1167: iload #6
      //   1169: istore #8
      //   1171: iload #11
      //   1173: ifeq -> 1196
      //   1176: aload_1
      //   1177: getfield f0 : F
      //   1180: fstore_3
      //   1181: iload #6
      //   1183: i2f
      //   1184: fload_3
      //   1185: fdiv
      //   1186: ldc 0.5
      //   1188: fadd
      //   1189: f2i
      //   1190: istore #7
      //   1192: iload #6
      //   1194: istore #8
      //   1196: iload #15
      //   1198: iload #8
      //   1200: if_icmpne -> 1228
      //   1203: iload #7
      //   1205: istore #6
      //   1207: iload #16
      //   1209: istore #9
      //   1211: iload #8
      //   1213: istore #10
      //   1215: iload #14
      //   1217: iload #7
      //   1219: if_icmpeq -> 1225
      //   1222: goto -> 1228
      //   1225: goto -> 1304
      //   1228: iload #15
      //   1230: iload #8
      //   1232: if_icmpeq -> 1247
      //   1235: iload #8
      //   1237: ldc 1073741824
      //   1239: invokestatic makeMeasureSpec : (II)I
      //   1242: istore #4
      //   1244: goto -> 1247
      //   1247: iload #14
      //   1249: iload #7
      //   1251: if_icmpeq -> 1263
      //   1254: iload #7
      //   1256: ldc 1073741824
      //   1258: invokestatic makeMeasureSpec : (II)I
      //   1261: istore #5
      //   1263: aload #19
      //   1265: iload #4
      //   1267: iload #5
      //   1269: invokevirtual measure : (II)V
      //   1272: aload_1
      //   1273: iload #4
      //   1275: iload #5
      //   1277: invokevirtual b1 : (II)V
      //   1280: aload #19
      //   1282: invokevirtual getMeasuredWidth : ()I
      //   1285: istore #10
      //   1287: aload #19
      //   1289: invokevirtual getMeasuredHeight : ()I
      //   1292: istore #6
      //   1294: aload #19
      //   1296: invokevirtual getBaseline : ()I
      //   1299: istore #9
      //   1301: goto -> 1225
      //   1304: iload #9
      //   1306: iconst_m1
      //   1307: if_icmpeq -> 1316
      //   1310: iconst_1
      //   1311: istore #17
      //   1313: goto -> 1319
      //   1316: iconst_0
      //   1317: istore #17
      //   1319: iload #10
      //   1321: aload_2
      //   1322: getfield c : I
      //   1325: if_icmpne -> 1346
      //   1328: iload #6
      //   1330: aload_2
      //   1331: getfield d : I
      //   1334: if_icmpeq -> 1340
      //   1337: goto -> 1346
      //   1340: iconst_0
      //   1341: istore #18
      //   1343: goto -> 1349
      //   1346: iconst_1
      //   1347: istore #18
      //   1349: aload_2
      //   1350: iload #18
      //   1352: putfield i : Z
      //   1355: aload #21
      //   1357: getfield g0 : Z
      //   1360: ifeq -> 1366
      //   1363: iconst_1
      //   1364: istore #17
      //   1366: iload #17
      //   1368: ifeq -> 1391
      //   1371: iload #9
      //   1373: iconst_m1
      //   1374: if_icmpeq -> 1391
      //   1377: aload_1
      //   1378: invokevirtual r : ()I
      //   1381: iload #9
      //   1383: if_icmpeq -> 1391
      //   1386: aload_2
      //   1387: iconst_1
      //   1388: putfield i : Z
      //   1391: aload_2
      //   1392: iload #10
      //   1394: putfield e : I
      //   1397: aload_2
      //   1398: iload #6
      //   1400: putfield f : I
      //   1403: aload_2
      //   1404: iload #17
      //   1406: putfield h : Z
      //   1409: aload_2
      //   1410: iload #9
      //   1412: putfield g : I
      //   1415: return
    }
    
    public final void b() {
      int i = this.a.getChildCount();
      boolean bool = false;
      byte b1;
      for (b1 = 0; b1 < i; b1++) {
        View view = this.a.getChildAt(b1);
        if (view instanceof Placeholder)
          ((Placeholder)view).b(this.a); 
      } 
      i = this.a.mConstraintHelpers.size();
      if (i > 0)
        for (b1 = bool; b1 < i; b1++)
          ((ConstraintHelper)this.a.mConstraintHelpers.get(b1)).s(this.a);  
    }
    
    public void c(int param1Int1, int param1Int2, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
      this.b = param1Int3;
      this.c = param1Int4;
      this.d = param1Int5;
      this.e = param1Int6;
      this.f = param1Int1;
      this.g = param1Int2;
    }
    
    public final boolean d(int param1Int1, int param1Int2, int param1Int3) {
      if (param1Int1 == param1Int2)
        return true; 
      int i = View.MeasureSpec.getMode(param1Int1);
      View.MeasureSpec.getSize(param1Int1);
      param1Int1 = View.MeasureSpec.getMode(param1Int2);
      param1Int2 = View.MeasureSpec.getSize(param1Int2);
      return (param1Int1 == 1073741824 && (i == Integer.MIN_VALUE || i == 0) && param1Int3 == param1Int2);
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\constraintlayout\widget\ConstraintLayout.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */