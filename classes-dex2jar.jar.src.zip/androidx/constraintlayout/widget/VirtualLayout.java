package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewParent;
import dbxyzptlk.L1.m;
import dbxyzptlk.P1.d;

public abstract class VirtualLayout extends ConstraintHelper {
  public boolean j;
  
  public boolean k;
  
  public VirtualLayout(Context paramContext) {
    super(paramContext);
  }
  
  public VirtualLayout(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
  }
  
  public VirtualLayout(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
  }
  
  public void j(ConstraintLayout paramConstraintLayout) {
    i(paramConstraintLayout);
  }
  
  public void o(AttributeSet paramAttributeSet) {
    super.o(paramAttributeSet);
    if (paramAttributeSet != null) {
      TypedArray typedArray = getContext().obtainStyledAttributes(paramAttributeSet, d.ConstraintLayout_Layout);
      int i = typedArray.getIndexCount();
      for (byte b = 0; b < i; b++) {
        int j = typedArray.getIndex(b);
        if (j == d.ConstraintLayout_Layout_android_visibility) {
          this.j = true;
        } else if (j == d.ConstraintLayout_Layout_android_elevation) {
          this.k = true;
        } 
      } 
      typedArray.recycle();
    } 
  }
  
  public void onAttachedToWindow() {
    super.onAttachedToWindow();
    if (this.j || this.k) {
      ViewParent viewParent = getParent();
      if (viewParent instanceof ConstraintLayout) {
        ConstraintLayout constraintLayout = (ConstraintLayout)viewParent;
        int i = getVisibility();
        float f = getElevation();
        for (byte b = 0; b < this.b; b++) {
          View view = constraintLayout.getViewById(this.a[b]);
          if (view != null) {
            if (this.j)
              view.setVisibility(i); 
            if (this.k && f > 0.0F)
              view.setTranslationZ(view.getTranslationZ() + f); 
          } 
        } 
      } 
    } 
  }
  
  public void setElevation(float paramFloat) {
    super.setElevation(paramFloat);
    h();
  }
  
  public void setVisibility(int paramInt) {
    super.setVisibility(paramInt);
    h();
  }
  
  public void x(m paramm, int paramInt1, int paramInt2) {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\constraintlayout\widget\VirtualLayout.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */