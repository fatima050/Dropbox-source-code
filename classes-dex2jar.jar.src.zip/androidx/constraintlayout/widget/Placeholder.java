package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.view.View;
import dbxyzptlk.L1.e;
import dbxyzptlk.P1.d;

public class Placeholder extends View {
  public int a = -1;
  
  public View b = null;
  
  public int c = 4;
  
  public Placeholder(Context paramContext) {
    super(paramContext);
    a(null);
  }
  
  public Placeholder(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    a(paramAttributeSet);
  }
  
  public Placeholder(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    a(paramAttributeSet);
  }
  
  public final void a(AttributeSet paramAttributeSet) {
    setVisibility(this.c);
    this.a = -1;
    if (paramAttributeSet != null) {
      TypedArray typedArray = getContext().obtainStyledAttributes(paramAttributeSet, d.ConstraintLayout_placeholder);
      int i = typedArray.getIndexCount();
      for (byte b = 0; b < i; b++) {
        int j = typedArray.getIndex(b);
        if (j == d.ConstraintLayout_placeholder_content) {
          this.a = typedArray.getResourceId(j, this.a);
        } else if (j == d.ConstraintLayout_placeholder_placeholder_emptyVisibility) {
          this.c = typedArray.getInt(j, this.c);
        } 
      } 
      typedArray.recycle();
    } 
  }
  
  public void b(ConstraintLayout paramConstraintLayout) {
    if (this.b == null)
      return; 
    ConstraintLayout.LayoutParams layoutParams1 = (ConstraintLayout.LayoutParams)getLayoutParams();
    ConstraintLayout.LayoutParams layoutParams2 = (ConstraintLayout.LayoutParams)this.b.getLayoutParams();
    layoutParams2.v0.p1(0);
    e.b b2 = layoutParams1.v0.C();
    e.b b1 = e.b.FIXED;
    if (b2 != b1)
      layoutParams1.v0.q1(layoutParams2.v0.a0()); 
    if (layoutParams1.v0.X() != b1)
      layoutParams1.v0.R0(layoutParams2.v0.z()); 
    layoutParams2.v0.p1(8);
  }
  
  public void c(ConstraintLayout paramConstraintLayout) {
    if (this.a == -1 && !isInEditMode())
      setVisibility(this.c); 
    View view = paramConstraintLayout.findViewById(this.a);
    this.b = view;
    if (view != null) {
      ((ConstraintLayout.LayoutParams)view.getLayoutParams()).j0 = true;
      this.b.setVisibility(0);
      setVisibility(0);
    } 
  }
  
  public View getContent() {
    return this.b;
  }
  
  public int getEmptyVisibility() {
    return this.c;
  }
  
  public void onDraw(Canvas paramCanvas) {
    if (isInEditMode()) {
      paramCanvas.drawRGB(223, 223, 223);
      Paint paint = new Paint();
      paint.setARGB(255, 210, 210, 210);
      paint.setTextAlign(Paint.Align.CENTER);
      paint.setTypeface(Typeface.create(Typeface.DEFAULT, 0));
      Rect rect = new Rect();
      paramCanvas.getClipBounds(rect);
      paint.setTextSize(rect.height());
      int j = rect.height();
      int i = rect.width();
      paint.setTextAlign(Paint.Align.LEFT);
      paint.getTextBounds("?", 0, 1, rect);
      paramCanvas.drawText("?", i / 2.0F - rect.width() / 2.0F - rect.left, j / 2.0F + rect.height() / 2.0F - rect.bottom, paint);
    } 
  }
  
  public void setContentId(int paramInt) {
    if (this.a == paramInt)
      return; 
    View view = this.b;
    if (view != null) {
      view.setVisibility(0);
      ((ConstraintLayout.LayoutParams)this.b.getLayoutParams()).j0 = false;
      this.b = null;
    } 
    this.a = paramInt;
    if (paramInt != -1) {
      view = ((View)getParent()).findViewById(paramInt);
      if (view != null)
        view.setVisibility(8); 
    } 
  }
  
  public void setEmptyVisibility(int paramInt) {
    this.c = paramInt;
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\constraintlayout\widget\Placeholder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */