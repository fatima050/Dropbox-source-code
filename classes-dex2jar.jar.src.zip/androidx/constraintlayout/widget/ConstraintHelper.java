package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import dbxyzptlk.L1.e;
import dbxyzptlk.L1.f;
import dbxyzptlk.L1.i;
import dbxyzptlk.L1.j;
import dbxyzptlk.P1.c;
import dbxyzptlk.P1.d;
import io.sentry.android.core.r0;
import java.util.Arrays;
import java.util.HashMap;

public abstract class ConstraintHelper extends View {
  public int[] a = new int[32];
  
  public int b;
  
  public Context c;
  
  public i d;
  
  public boolean e = false;
  
  public String f;
  
  public String g;
  
  public View[] h = null;
  
  public HashMap<Integer, String> i = new HashMap<>();
  
  public ConstraintHelper(Context paramContext) {
    super(paramContext);
    this.c = paramContext;
    o(null);
  }
  
  public ConstraintHelper(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    this.c = paramContext;
    o(paramAttributeSet);
  }
  
  public ConstraintHelper(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    this.c = paramContext;
    o(paramAttributeSet);
  }
  
  public final void e(String paramString) {
    if (paramString != null && paramString.length() != 0) {
      if (this.c == null)
        return; 
      paramString = paramString.trim();
      if (getParent() instanceof ConstraintLayout)
        ConstraintLayout constraintLayout = (ConstraintLayout)getParent(); 
      int j = m(paramString);
      if (j != 0) {
        this.i.put(Integer.valueOf(j), paramString);
        f(j);
      } else {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Could not find id of \"");
        stringBuilder.append(paramString);
        stringBuilder.append("\"");
        r0.f("ConstraintHelper", stringBuilder.toString());
      } 
    } 
  }
  
  public final void f(int paramInt) {
    if (paramInt == getId())
      return; 
    int j = this.b;
    int[] arrayOfInt = this.a;
    if (j + 1 > arrayOfInt.length)
      this.a = Arrays.copyOf(arrayOfInt, arrayOfInt.length * 2); 
    arrayOfInt = this.a;
    j = this.b;
    arrayOfInt[j] = paramInt;
    this.b = j + 1;
  }
  
  public final void g(String paramString) {
    if (paramString != null && paramString.length() != 0) {
      if (this.c == null)
        return; 
      String str = paramString.trim();
      if (getParent() instanceof ConstraintLayout) {
        ConstraintLayout constraintLayout = (ConstraintLayout)getParent();
      } else {
        paramString = null;
      } 
      if (paramString == null) {
        r0.f("ConstraintHelper", "Parent not a ConstraintLayout");
        return;
      } 
      int j = paramString.getChildCount();
      for (byte b = 0; b < j; b++) {
        View view = paramString.getChildAt(b);
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        if (layoutParams instanceof ConstraintLayout.LayoutParams && str.equals(((ConstraintLayout.LayoutParams)layoutParams).c0))
          if (view.getId() == -1) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("to use ConstraintTag view ");
            stringBuilder.append(view.getClass().getSimpleName());
            stringBuilder.append(" must have an ID");
            r0.f("ConstraintHelper", stringBuilder.toString());
          } else {
            f(view.getId());
          }  
      } 
    } 
  }
  
  public int[] getReferencedIds() {
    return Arrays.copyOf(this.a, this.b);
  }
  
  public void h() {
    ViewParent viewParent = getParent();
    if (viewParent != null && viewParent instanceof ConstraintLayout)
      i((ConstraintLayout)viewParent); 
  }
  
  public void i(ConstraintLayout paramConstraintLayout) {
    int j = getVisibility();
    float f = getElevation();
    for (byte b = 0; b < this.b; b++) {
      View view = paramConstraintLayout.getViewById(this.a[b]);
      if (view != null) {
        view.setVisibility(j);
        if (f > 0.0F)
          view.setTranslationZ(view.getTranslationZ() + f); 
      } 
    } 
  }
  
  public void j(ConstraintLayout paramConstraintLayout) {}
  
  public final int[] k(View paramView, String paramString) {
    String[] arrayOfString = paramString.split(",");
    paramView.getContext();
    int[] arrayOfInt2 = new int[arrayOfString.length];
    byte b = 0;
    int j;
    for (j = 0; b < arrayOfString.length; j = k) {
      int m = m(arrayOfString[b].trim());
      int k = j;
      if (m != 0) {
        arrayOfInt2[j] = m;
        k = j + 1;
      } 
      b++;
    } 
    int[] arrayOfInt1 = arrayOfInt2;
    if (j != arrayOfString.length)
      arrayOfInt1 = Arrays.copyOf(arrayOfInt2, j); 
    return arrayOfInt1;
  }
  
  public final int l(ConstraintLayout paramConstraintLayout, String paramString) {
    if (paramString != null && paramConstraintLayout != null) {
      Resources resources = this.c.getResources();
      if (resources == null)
        return 0; 
      int j = paramConstraintLayout.getChildCount();
      for (byte b = 0; b < j; b++) {
        View view = paramConstraintLayout.getChildAt(b);
        if (view.getId() != -1) {
          try {
            String str = resources.getResourceEntryName(view.getId());
          } catch (android.content.res.Resources.NotFoundException notFoundException) {
            notFoundException = null;
          } 
          if (paramString.equals(notFoundException))
            return view.getId(); 
        } 
      } 
    } 
    return 0;
  }
  
  public final int m(String paramString) {
    ConstraintLayout constraintLayout;
    if (getParent() instanceof ConstraintLayout) {
      constraintLayout = (ConstraintLayout)getParent();
    } else {
      constraintLayout = null;
    } 
    boolean bool = isInEditMode();
    int j = 0;
    int k = j;
    if (bool) {
      k = j;
      if (constraintLayout != null) {
        Object object = constraintLayout.getDesignInformation(0, paramString);
        k = j;
        if (object instanceof Integer)
          k = ((Integer)object).intValue(); 
      } 
    } 
    j = k;
    if (k == 0) {
      j = k;
      if (constraintLayout != null)
        j = l(constraintLayout, paramString); 
    } 
    k = j;
    if (j == 0)
      try {
        k = c.class.getField(paramString).getInt(null);
      } catch (Exception exception) {
        k = j;
      }  
    j = k;
    if (k == 0)
      j = this.c.getResources().getIdentifier(paramString, "id", this.c.getPackageName()); 
    return j;
  }
  
  public View[] n(ConstraintLayout paramConstraintLayout) {
    View[] arrayOfView = this.h;
    if (arrayOfView == null || arrayOfView.length != this.b)
      this.h = new View[this.b]; 
    for (byte b = 0; b < this.b; b++) {
      int j = this.a[b];
      this.h[b] = paramConstraintLayout.getViewById(j);
    } 
    return this.h;
  }
  
  public void o(AttributeSet paramAttributeSet) {
    if (paramAttributeSet != null) {
      TypedArray typedArray = getContext().obtainStyledAttributes(paramAttributeSet, d.ConstraintLayout_Layout);
      int j = typedArray.getIndexCount();
      for (byte b = 0; b < j; b++) {
        int k = typedArray.getIndex(b);
        if (k == d.ConstraintLayout_Layout_constraint_referenced_ids) {
          String str = typedArray.getString(k);
          this.f = str;
          setIds(str);
        } else if (k == d.ConstraintLayout_Layout_constraint_referenced_tags) {
          String str = typedArray.getString(k);
          this.g = str;
          setReferenceTags(str);
        } 
      } 
      typedArray.recycle();
    } 
  }
  
  public void onAttachedToWindow() {
    super.onAttachedToWindow();
    String str = this.f;
    if (str != null)
      setIds(str); 
    str = this.g;
    if (str != null)
      setReferenceTags(str); 
  }
  
  public void onDraw(Canvas paramCanvas) {}
  
  public void onMeasure(int paramInt1, int paramInt2) {
    if (this.e) {
      super.onMeasure(paramInt1, paramInt2);
    } else {
      setMeasuredDimension(0, 0);
    } 
  }
  
  public void p(b.a parama, j paramj, ConstraintLayout.LayoutParams paramLayoutParams, SparseArray<e> paramSparseArray) {
    b.b b = parama.e;
    int[] arrayOfInt = b.k0;
    if (arrayOfInt != null) {
      setReferencedIds(arrayOfInt);
    } else {
      String str = b.l0;
      if (str != null)
        if (str.length() > 0) {
          b.b b1 = parama.e;
          b1.k0 = k(this, b1.l0);
        } else {
          parama.e.k0 = null;
        }  
    } 
    if (paramj != null) {
      paramj.c();
      if (parama.e.k0 != null) {
        byte b1 = 0;
        while (true) {
          arrayOfInt = parama.e.k0;
          if (b1 < arrayOfInt.length) {
            e e = (e)paramSparseArray.get(arrayOfInt[b1]);
            if (e != null)
              paramj.a(e); 
            b1++;
            continue;
          } 
          break;
        } 
      } 
    } 
  }
  
  public void q(e parame, boolean paramBoolean) {}
  
  public void r(ConstraintLayout paramConstraintLayout) {}
  
  public void s(ConstraintLayout paramConstraintLayout) {}
  
  public void setIds(String paramString) {
    this.f = paramString;
    if (paramString == null)
      return; 
    int j = 0;
    this.b = 0;
    while (true) {
      int k = paramString.indexOf(',', j);
      if (k == -1) {
        e(paramString.substring(j));
        return;
      } 
      e(paramString.substring(j, k));
      j = k + 1;
    } 
  }
  
  public void setReferenceTags(String paramString) {
    this.g = paramString;
    if (paramString == null)
      return; 
    int j = 0;
    this.b = 0;
    while (true) {
      int k = paramString.indexOf(',', j);
      if (k == -1) {
        g(paramString.substring(j));
        return;
      } 
      g(paramString.substring(j, k));
      j = k + 1;
    } 
  }
  
  public void setReferencedIds(int[] paramArrayOfint) {
    this.f = null;
    byte b = 0;
    this.b = 0;
    while (b < paramArrayOfint.length) {
      f(paramArrayOfint[b]);
      b++;
    } 
  }
  
  public void setTag(int paramInt, Object paramObject) {
    super.setTag(paramInt, paramObject);
    if (paramObject == null && this.f == null)
      f(paramInt); 
  }
  
  public void t(ConstraintLayout paramConstraintLayout) {}
  
  public void u(ConstraintLayout paramConstraintLayout) {
    if (isInEditMode())
      setIds(this.f); 
    i i1 = this.d;
    if (i1 == null)
      return; 
    i1.c();
    for (byte b = 0; b < this.b; b++) {
      int j = this.a[b];
      View view2 = paramConstraintLayout.getViewById(j);
      View view1 = view2;
      if (view2 == null) {
        String str = this.i.get(Integer.valueOf(j));
        j = l(paramConstraintLayout, str);
        view1 = view2;
        if (j != 0) {
          this.a[b] = j;
          this.i.put(Integer.valueOf(j), str);
          view1 = paramConstraintLayout.getViewById(j);
        } 
      } 
      if (view1 != null)
        this.d.a(paramConstraintLayout.getViewWidget(view1)); 
    } 
    this.d.b(paramConstraintLayout.mLayoutWidget);
  }
  
  public void v(f paramf, i parami, SparseArray<e> paramSparseArray) {
    parami.c();
    for (byte b = 0; b < this.b; b++)
      parami.a((e)paramSparseArray.get(this.a[b])); 
  }
  
  public void w() {
    if (this.d == null)
      return; 
    ViewGroup.LayoutParams layoutParams = getLayoutParams();
    if (layoutParams instanceof ConstraintLayout.LayoutParams)
      ((ConstraintLayout.LayoutParams)layoutParams).v0 = (e)this.d; 
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\constraintlayout\widget\ConstraintHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */