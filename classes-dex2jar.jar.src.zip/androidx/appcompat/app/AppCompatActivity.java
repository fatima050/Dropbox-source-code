package androidx.appcompat.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.LifecycleOwner;
import dbxyzptlk.J4.d;
import dbxyzptlk.J4.e;
import dbxyzptlk.T1.l;
import dbxyzptlk.T1.z;
import dbxyzptlk.U2.A;
import dbxyzptlk.U2.B;
import dbxyzptlk.U2.z;
import dbxyzptlk.d2.j;
import dbxyzptlk.e.H;
import dbxyzptlk.e.L;
import dbxyzptlk.k.b;
import dbxyzptlk.r.U;

public class AppCompatActivity extends FragmentActivity implements b, z.a {
  private static final String DELEGATE_TAG = "androidx:appcompat";
  
  private b mDelegate;
  
  private Resources mResources;
  
  public AppCompatActivity() {
    initDelegate();
  }
  
  public AppCompatActivity(int paramInt) {
    super(paramInt);
    initDelegate();
  }
  
  private void initDelegate() {
    getSavedStateRegistry().i("androidx:appcompat", new a(this));
    addOnContextAvailableListener(new b(this));
  }
  
  private void initViewTreeOwners() {
    A.b(getWindow().getDecorView(), (LifecycleOwner)this);
    B.b(getWindow().getDecorView(), (z)this);
    e.b(getWindow().getDecorView(), (d)this);
    L.b(getWindow().getDecorView(), (H)this);
  }
  
  private boolean performMenuItemShortcut(KeyEvent paramKeyEvent) {
    return false;
  }
  
  public void addContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    initViewTreeOwners();
    getDelegate().c(paramView, paramLayoutParams);
  }
  
  public void attachBaseContext(Context paramContext) {
    super.attachBaseContext(getDelegate().g(paramContext));
  }
  
  public void closeOptionsMenu() {
    ActionBar actionBar = getSupportActionBar();
    if (getWindow().hasFeature(0) && (actionBar == null || !actionBar.g()))
      super.closeOptionsMenu(); 
  }
  
  public boolean dispatchKeyEvent(KeyEvent paramKeyEvent) {
    int i = paramKeyEvent.getKeyCode();
    ActionBar actionBar = getSupportActionBar();
    return (i == 82 && actionBar != null && actionBar.q(paramKeyEvent)) ? true : super.dispatchKeyEvent(paramKeyEvent);
  }
  
  public <T extends View> T findViewById(int paramInt) {
    return getDelegate().j(paramInt);
  }
  
  public b getDelegate() {
    if (this.mDelegate == null)
      this.mDelegate = b.h((Activity)this, this); 
    return this.mDelegate;
  }
  
  public dbxyzptlk.k.a getDrawerToggleDelegate() {
    return getDelegate().n();
  }
  
  public MenuInflater getMenuInflater() {
    return getDelegate().q();
  }
  
  public Resources getResources() {
    if (this.mResources == null && U.c())
      this.mResources = (Resources)new U((Context)this, super.getResources()); 
    Resources resources2 = this.mResources;
    Resources resources1 = resources2;
    if (resources2 == null)
      resources1 = super.getResources(); 
    return resources1;
  }
  
  public ActionBar getSupportActionBar() {
    return getDelegate().s();
  }
  
  public Intent getSupportParentActivityIntent() {
    return l.a((Activity)this);
  }
  
  public void invalidateOptionsMenu() {
    getDelegate().u();
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    getDelegate().x(paramConfiguration);
    if (this.mResources != null) {
      paramConfiguration = super.getResources().getConfiguration();
      DisplayMetrics displayMetrics = super.getResources().getDisplayMetrics();
      this.mResources.updateConfiguration(paramConfiguration, displayMetrics);
    } 
  }
  
  public void onContentChanged() {
    onSupportContentChanged();
  }
  
  public void onCreateSupportNavigateUpTaskStack(z paramz) {
    paramz.j((Activity)this);
  }
  
  public void onDestroy() {
    super.onDestroy();
    getDelegate().z();
  }
  
  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent) {
    return performMenuItemShortcut(paramKeyEvent) ? true : super.onKeyDown(paramInt, paramKeyEvent);
  }
  
  public void onLocalesChanged(j paramj) {}
  
  public final boolean onMenuItemSelected(int paramInt, MenuItem paramMenuItem) {
    if (super.onMenuItemSelected(paramInt, paramMenuItem))
      return true; 
    ActionBar actionBar = getSupportActionBar();
    return (paramMenuItem.getItemId() == 16908332 && actionBar != null && (actionBar.j() & 0x4) != 0) ? onSupportNavigateUp() : false;
  }
  
  public boolean onMenuOpened(int paramInt, Menu paramMenu) {
    return super.onMenuOpened(paramInt, paramMenu);
  }
  
  public void onNightModeChanged(int paramInt) {}
  
  public void onPanelClosed(int paramInt, Menu paramMenu) {
    super.onPanelClosed(paramInt, paramMenu);
  }
  
  public void onPostCreate(Bundle paramBundle) {
    super.onPostCreate(paramBundle);
    getDelegate().A(paramBundle);
  }
  
  public void onPostResume() {
    super.onPostResume();
    getDelegate().B();
  }
  
  public void onPrepareSupportNavigateUpTaskStack(z paramz) {}
  
  public void onStart() {
    super.onStart();
    getDelegate().D();
  }
  
  public void onStop() {
    super.onStop();
    getDelegate().E();
  }
  
  public void onSupportActionModeFinished(dbxyzptlk.p.b paramb) {}
  
  public void onSupportActionModeStarted(dbxyzptlk.p.b paramb) {}
  
  @Deprecated
  public void onSupportContentChanged() {}
  
  public boolean onSupportNavigateUp() {
    Intent intent = getSupportParentActivityIntent();
    if (intent != null) {
      if (supportShouldUpRecreateTask(intent)) {
        z z = z.l((Context)this);
        onCreateSupportNavigateUpTaskStack(z);
        onPrepareSupportNavigateUpTaskStack(z);
        z.w();
        try {
          dbxyzptlk.T1.b.r((Activity)this);
        } catch (IllegalStateException illegalStateException) {
          finish();
        } 
      } else {
        supportNavigateUpTo((Intent)illegalStateException);
      } 
      return true;
    } 
    return false;
  }
  
  public void onTitleChanged(CharSequence paramCharSequence, int paramInt) {
    super.onTitleChanged(paramCharSequence, paramInt);
    getDelegate().Q(paramCharSequence);
  }
  
  public dbxyzptlk.p.b onWindowStartingSupportActionMode(dbxyzptlk.p.b.a parama) {
    return null;
  }
  
  public void openOptionsMenu() {
    ActionBar actionBar = getSupportActionBar();
    if (getWindow().hasFeature(0) && (actionBar == null || !actionBar.r()))
      super.openOptionsMenu(); 
  }
  
  public void setContentView(int paramInt) {
    initViewTreeOwners();
    getDelegate().I(paramInt);
  }
  
  public void setContentView(View paramView) {
    initViewTreeOwners();
    getDelegate().J(paramView);
  }
  
  public void setContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    initViewTreeOwners();
    getDelegate().K(paramView, paramLayoutParams);
  }
  
  public void setSupportActionBar(Toolbar paramToolbar) {
    getDelegate().O(paramToolbar);
  }
  
  @Deprecated
  public void setSupportProgress(int paramInt) {}
  
  @Deprecated
  public void setSupportProgressBarIndeterminate(boolean paramBoolean) {}
  
  @Deprecated
  public void setSupportProgressBarIndeterminateVisibility(boolean paramBoolean) {}
  
  @Deprecated
  public void setSupportProgressBarVisibility(boolean paramBoolean) {}
  
  public void setTheme(int paramInt) {
    super.setTheme(paramInt);
    getDelegate().P(paramInt);
  }
  
  public dbxyzptlk.p.b startSupportActionMode(dbxyzptlk.p.b.a parama) {
    return getDelegate().R(parama);
  }
  
  public void supportInvalidateOptionsMenu() {
    getDelegate().u();
  }
  
  public void supportNavigateUpTo(Intent paramIntent) {
    l.e((Activity)this, paramIntent);
  }
  
  public boolean supportRequestWindowFeature(int paramInt) {
    return getDelegate().H(paramInt);
  }
  
  public boolean supportShouldUpRecreateTask(Intent paramIntent) {
    return l.f((Activity)this, paramIntent);
  }
  
  public class a implements androidx.savedstate.a.c {
    public final AppCompatActivity a;
    
    public a(AppCompatActivity this$0) {}
    
    public Bundle e() {
      Bundle bundle = new Bundle();
      this.a.getDelegate().C(bundle);
      return bundle;
    }
  }
  
  public class b implements dbxyzptlk.g.b {
    public final AppCompatActivity a;
    
    public b(AppCompatActivity this$0) {}
    
    public void a(Context param1Context) {
      b b1 = this.a.getDelegate();
      b1.t();
      b1.y(this.a.getSavedStateRegistry().b("androidx:appcompat"));
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\appcompat\app\AppCompatActivity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */