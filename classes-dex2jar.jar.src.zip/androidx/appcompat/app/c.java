package androidx.appcompat.app;

import android.app.Activity;
import android.app.Dialog;
import android.app.UiModeManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.os.LocaleList;
import android.text.TextUtils;
import android.util.AndroidRuntimeException;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.ActionMode;
import android.view.ContextThemeWrapper;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.KeyboardShortcutGroup;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import androidx.appcompat.view.menu.e;
import androidx.appcompat.view.menu.i;
import androidx.appcompat.widget.ActionBarContextView;
import androidx.appcompat.widget.ContentFrameLayout;
import androidx.appcompat.widget.Toolbar;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.f;
import dbxyzptlk.V.E;
import dbxyzptlk.X1.h;
import dbxyzptlk.h2.J0;
import dbxyzptlk.h2.O;
import dbxyzptlk.h2.h0;
import dbxyzptlk.h2.r0;
import dbxyzptlk.h2.y;
import dbxyzptlk.h2.z;
import dbxyzptlk.j.f;
import dbxyzptlk.j.g;
import dbxyzptlk.j.i;
import dbxyzptlk.k.n;
import dbxyzptlk.k.q;
import dbxyzptlk.p.d;
import dbxyzptlk.p.f;
import dbxyzptlk.p.g;
import dbxyzptlk.p.i;
import dbxyzptlk.r.O;
import dbxyzptlk.r.U;
import dbxyzptlk.r.V;
import dbxyzptlk.r.g;
import dbxyzptlk.r.t;
import java.util.List;
import java.util.Locale;
import org.xmlpull.v1.XmlPullParser;

public class c extends b implements e.a, LayoutInflater.Factory2 {
  public static final E<String, Integer> j0 = new E();
  
  public static final boolean k0 = false;
  
  public static final int[] l0 = new int[] { 16842836 };
  
  public static final boolean m0 = "robolectric".equals(Build.FINGERPRINT) ^ true;
  
  public static final boolean n0 = true;
  
  public boolean A;
  
  public ViewGroup B;
  
  public TextView C;
  
  public View D;
  
  public boolean E;
  
  public boolean F;
  
  public boolean G;
  
  public boolean H;
  
  public boolean I;
  
  public boolean J;
  
  public boolean K;
  
  public boolean L;
  
  public u[] M;
  
  public u N;
  
  public boolean O;
  
  public boolean P;
  
  public boolean Q;
  
  public boolean R;
  
  public Configuration S;
  
  public int T = -100;
  
  public int U;
  
  public int V;
  
  public boolean W;
  
  public q X;
  
  public q Y;
  
  public boolean Z;
  
  public int a0;
  
  public final Runnable b0 = new a(this);
  
  public boolean c0;
  
  public Rect d0;
  
  public Rect e0;
  
  public dbxyzptlk.k.l f0;
  
  public n g0;
  
  public OnBackInvokedDispatcher h0;
  
  public OnBackInvokedCallback i0;
  
  public final Object j;
  
  public final Context k;
  
  public Window l;
  
  public o m;
  
  public final dbxyzptlk.k.b n;
  
  public ActionBar o;
  
  public MenuInflater p;
  
  public CharSequence q;
  
  public t r;
  
  public h s;
  
  public v t;
  
  public dbxyzptlk.p.b u;
  
  public ActionBarContextView v;
  
  public PopupWindow w;
  
  public Runnable x;
  
  public r0 y = null;
  
  public boolean z = true;
  
  public c(Activity paramActivity, dbxyzptlk.k.b paramb) {
    this((Context)paramActivity, null, paramb, paramActivity);
  }
  
  public c(Dialog paramDialog, dbxyzptlk.k.b paramb) {
    this(paramDialog.getContext(), paramDialog.getWindow(), paramb, paramDialog);
  }
  
  public c(Context paramContext, Window paramWindow, dbxyzptlk.k.b paramb, Object paramObject) {
    this.k = paramContext;
    this.n = paramb;
    this.j = paramObject;
    if (this.T == -100 && paramObject instanceof Dialog) {
      AppCompatActivity appCompatActivity = a1();
      if (appCompatActivity != null)
        this.T = appCompatActivity.getDelegate().o(); 
    } 
    if (this.T == -100) {
      E<String, Integer> e = j0;
      Integer integer = (Integer)e.get(paramObject.getClass().getName());
      if (integer != null) {
        this.T = integer.intValue();
        e.remove(paramObject.getClass().getName());
      } 
    } 
    if (paramWindow != null)
      W(paramWindow); 
    g.h();
  }
  
  public static Configuration o0(Configuration paramConfiguration1, Configuration paramConfiguration2) {
    Configuration configuration = new Configuration();
    configuration.fontScale = 0.0F;
    if (paramConfiguration2 != null && paramConfiguration1.diff(paramConfiguration2) != 0) {
      float f2 = paramConfiguration1.fontScale;
      float f1 = paramConfiguration2.fontScale;
      if (f2 != f1)
        configuration.fontScale = f1; 
      int i = paramConfiguration1.mcc;
      int j = paramConfiguration2.mcc;
      if (i != j)
        configuration.mcc = j; 
      i = paramConfiguration1.mnc;
      j = paramConfiguration2.mnc;
      if (i != j)
        configuration.mnc = j; 
      l.a(paramConfiguration1, paramConfiguration2, configuration);
      j = paramConfiguration1.touchscreen;
      i = paramConfiguration2.touchscreen;
      if (j != i)
        configuration.touchscreen = i; 
      j = paramConfiguration1.keyboard;
      i = paramConfiguration2.keyboard;
      if (j != i)
        configuration.keyboard = i; 
      i = paramConfiguration1.keyboardHidden;
      j = paramConfiguration2.keyboardHidden;
      if (i != j)
        configuration.keyboardHidden = j; 
      i = paramConfiguration1.navigation;
      j = paramConfiguration2.navigation;
      if (i != j)
        configuration.navigation = j; 
      i = paramConfiguration1.navigationHidden;
      j = paramConfiguration2.navigationHidden;
      if (i != j)
        configuration.navigationHidden = j; 
      j = paramConfiguration1.orientation;
      i = paramConfiguration2.orientation;
      if (j != i)
        configuration.orientation = i; 
      j = paramConfiguration1.screenLayout;
      i = paramConfiguration2.screenLayout;
      if ((j & 0xF) != (i & 0xF))
        configuration.screenLayout |= i & 0xF; 
      i = paramConfiguration1.screenLayout;
      j = paramConfiguration2.screenLayout;
      if ((i & 0xC0) != (j & 0xC0))
        configuration.screenLayout |= j & 0xC0; 
      i = paramConfiguration1.screenLayout;
      j = paramConfiguration2.screenLayout;
      if ((i & 0x30) != (j & 0x30))
        configuration.screenLayout |= j & 0x30; 
      i = paramConfiguration1.screenLayout;
      j = paramConfiguration2.screenLayout;
      if ((i & 0x300) != (j & 0x300))
        configuration.screenLayout |= j & 0x300; 
      m.a(paramConfiguration1, paramConfiguration2, configuration);
      j = paramConfiguration1.uiMode;
      i = paramConfiguration2.uiMode;
      if ((j & 0xF) != (i & 0xF))
        configuration.uiMode |= i & 0xF; 
      j = paramConfiguration1.uiMode;
      i = paramConfiguration2.uiMode;
      if ((j & 0x30) != (i & 0x30))
        configuration.uiMode |= i & 0x30; 
      j = paramConfiguration1.screenWidthDp;
      i = paramConfiguration2.screenWidthDp;
      if (j != i)
        configuration.screenWidthDp = i; 
      j = paramConfiguration1.screenHeightDp;
      i = paramConfiguration2.screenHeightDp;
      if (j != i)
        configuration.screenHeightDp = i; 
      i = paramConfiguration1.smallestScreenWidthDp;
      j = paramConfiguration2.smallestScreenWidthDp;
      if (i != j)
        configuration.smallestScreenWidthDp = j; 
      j.b(paramConfiguration1, paramConfiguration2, configuration);
    } 
    return configuration;
  }
  
  public void A(Bundle paramBundle) {
    l0();
  }
  
  public final boolean A0(u paramu) {
    // Byte code:
    //   0: aload_0
    //   1: getfield k : Landroid/content/Context;
    //   4: astore #5
    //   6: aload_1
    //   7: getfield a : I
    //   10: istore_2
    //   11: iload_2
    //   12: ifeq -> 24
    //   15: aload #5
    //   17: astore_3
    //   18: iload_2
    //   19: bipush #108
    //   21: if_icmpne -> 197
    //   24: aload #5
    //   26: astore_3
    //   27: aload_0
    //   28: getfield r : Ldbxyzptlk/r/t;
    //   31: ifnull -> 197
    //   34: new android/util/TypedValue
    //   37: dup
    //   38: invokespecial <init> : ()V
    //   41: astore #7
    //   43: aload #5
    //   45: invokevirtual getTheme : ()Landroid/content/res/Resources$Theme;
    //   48: astore #6
    //   50: aload #6
    //   52: getstatic dbxyzptlk/j/a.actionBarTheme : I
    //   55: aload #7
    //   57: iconst_1
    //   58: invokevirtual resolveAttribute : (ILandroid/util/TypedValue;Z)Z
    //   61: pop
    //   62: aload #7
    //   64: getfield resourceId : I
    //   67: ifeq -> 109
    //   70: aload #5
    //   72: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   75: invokevirtual newTheme : ()Landroid/content/res/Resources$Theme;
    //   78: astore_3
    //   79: aload_3
    //   80: aload #6
    //   82: invokevirtual setTo : (Landroid/content/res/Resources$Theme;)V
    //   85: aload_3
    //   86: aload #7
    //   88: getfield resourceId : I
    //   91: iconst_1
    //   92: invokevirtual applyStyle : (IZ)V
    //   95: aload_3
    //   96: getstatic dbxyzptlk/j/a.actionBarWidgetTheme : I
    //   99: aload #7
    //   101: iconst_1
    //   102: invokevirtual resolveAttribute : (ILandroid/util/TypedValue;Z)Z
    //   105: pop
    //   106: goto -> 123
    //   109: aload #6
    //   111: getstatic dbxyzptlk/j/a.actionBarWidgetTheme : I
    //   114: aload #7
    //   116: iconst_1
    //   117: invokevirtual resolveAttribute : (ILandroid/util/TypedValue;Z)Z
    //   120: pop
    //   121: aconst_null
    //   122: astore_3
    //   123: aload_3
    //   124: astore #4
    //   126: aload #7
    //   128: getfield resourceId : I
    //   131: ifeq -> 169
    //   134: aload_3
    //   135: astore #4
    //   137: aload_3
    //   138: ifnonnull -> 158
    //   141: aload #5
    //   143: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   146: invokevirtual newTheme : ()Landroid/content/res/Resources$Theme;
    //   149: astore #4
    //   151: aload #4
    //   153: aload #6
    //   155: invokevirtual setTo : (Landroid/content/res/Resources$Theme;)V
    //   158: aload #4
    //   160: aload #7
    //   162: getfield resourceId : I
    //   165: iconst_1
    //   166: invokevirtual applyStyle : (IZ)V
    //   169: aload #5
    //   171: astore_3
    //   172: aload #4
    //   174: ifnull -> 197
    //   177: new dbxyzptlk/p/d
    //   180: dup
    //   181: aload #5
    //   183: iconst_0
    //   184: invokespecial <init> : (Landroid/content/Context;I)V
    //   187: astore_3
    //   188: aload_3
    //   189: invokevirtual getTheme : ()Landroid/content/res/Resources$Theme;
    //   192: aload #4
    //   194: invokevirtual setTo : (Landroid/content/res/Resources$Theme;)V
    //   197: new androidx/appcompat/view/menu/e
    //   200: dup
    //   201: aload_3
    //   202: invokespecial <init> : (Landroid/content/Context;)V
    //   205: astore_3
    //   206: aload_3
    //   207: aload_0
    //   208: invokevirtual setCallback : (Landroidx/appcompat/view/menu/e$a;)V
    //   211: aload_1
    //   212: aload_3
    //   213: invokevirtual c : (Landroidx/appcompat/view/menu/e;)V
    //   216: iconst_1
    //   217: ireturn
  }
  
  public void B() {
    ActionBar actionBar = s();
    if (actionBar != null)
      actionBar.z(true); 
  }
  
  public final void B0(int paramInt) {
    this.a0 = 1 << paramInt | this.a0;
    if (!this.Z) {
      h0.i0(this.l.getDecorView(), this.b0);
      this.Z = true;
    } 
  }
  
  public void C(Bundle paramBundle) {}
  
  public boolean C0() {
    return this.z;
  }
  
  public void D() {
    U(true, false);
  }
  
  public int D0(Context paramContext, int paramInt) {
    if (paramInt != -100) {
      if (paramInt != -1)
        if (paramInt != 0) {
          if (paramInt != 1 && paramInt != 2) {
            if (paramInt == 3)
              return r0(paramContext).c(); 
            throw new IllegalStateException("Unknown value set for night mode. Please use one of the MODE_NIGHT values from AppCompatDelegate.");
          } 
        } else {
          return (((UiModeManager)paramContext.getApplicationContext().getSystemService("uimode")).getNightMode() == 0) ? -1 : s0(paramContext).c();
        }  
      return paramInt;
    } 
    return -1;
  }
  
  public void E() {
    ActionBar actionBar = s();
    if (actionBar != null)
      actionBar.z(false); 
  }
  
  public boolean E0() {
    boolean bool = this.O;
    this.O = false;
    u u1 = u0(0, false);
    if (u1 != null && u1.o) {
      if (!bool)
        d0(u1, true); 
      return true;
    } 
    dbxyzptlk.p.b b1 = this.u;
    if (b1 != null) {
      b1.a();
      return true;
    } 
    ActionBar actionBar = s();
    return (actionBar != null && actionBar.h());
  }
  
  public boolean F0(int paramInt, KeyEvent paramKeyEvent) {
    boolean bool = true;
    if (paramInt != 4) {
      if (paramInt == 82) {
        G0(0, paramKeyEvent);
        return true;
      } 
    } else {
      if ((paramKeyEvent.getFlags() & 0x80) == 0)
        bool = false; 
      this.O = bool;
    } 
    return false;
  }
  
  public final boolean G0(int paramInt, KeyEvent paramKeyEvent) {
    if (paramKeyEvent.getRepeatCount() == 0) {
      u u1 = u0(paramInt, true);
      if (!u1.o)
        return Q0(u1, paramKeyEvent); 
    } 
    return false;
  }
  
  public boolean H(int paramInt) {
    paramInt = S0(paramInt);
    if (this.K && paramInt == 108)
      return false; 
    if (this.G && paramInt == 1)
      this.G = false; 
    if (paramInt != 1) {
      if (paramInt != 2) {
        if (paramInt != 5) {
          if (paramInt != 10) {
            if (paramInt != 108) {
              if (paramInt != 109)
                return this.l.requestFeature(paramInt); 
              Z0();
              this.H = true;
              return true;
            } 
            Z0();
            this.G = true;
            return true;
          } 
          Z0();
          this.I = true;
          return true;
        } 
        Z0();
        this.F = true;
        return true;
      } 
      Z0();
      this.E = true;
      return true;
    } 
    Z0();
    this.K = true;
    return true;
  }
  
  public boolean H0(int paramInt, KeyEvent paramKeyEvent) {
    u u1;
    ActionBar actionBar = s();
    if (actionBar != null && actionBar.p(paramInt, paramKeyEvent))
      return true; 
    u u2 = this.N;
    if (u2 != null && P0(u2, paramKeyEvent.getKeyCode(), paramKeyEvent, 1)) {
      u1 = this.N;
      if (u1 != null)
        u1.n = true; 
      return true;
    } 
    if (this.N == null) {
      u2 = u0(0, true);
      Q0(u2, (KeyEvent)u1);
      boolean bool = P0(u2, u1.getKeyCode(), (KeyEvent)u1, 1);
      u2.m = false;
      if (bool)
        return true; 
    } 
    return false;
  }
  
  public void I(int paramInt) {
    l0();
    ViewGroup viewGroup = (ViewGroup)this.B.findViewById(16908290);
    viewGroup.removeAllViews();
    LayoutInflater.from(this.k).inflate(paramInt, viewGroup);
    this.m.c(this.l.getCallback());
  }
  
  public boolean I0(int paramInt, KeyEvent paramKeyEvent) {
    if (paramInt != 4) {
      if (paramInt == 82) {
        J0(0, paramKeyEvent);
        return true;
      } 
    } else if (E0()) {
      return true;
    } 
    return false;
  }
  
  public void J(View paramView) {
    l0();
    ViewGroup viewGroup = (ViewGroup)this.B.findViewById(16908290);
    viewGroup.removeAllViews();
    viewGroup.addView(paramView);
    this.m.c(this.l.getCallback());
  }
  
  public final boolean J0(int paramInt, KeyEvent paramKeyEvent) {
    // Byte code:
    //   0: aload_0
    //   1: getfield u : Ldbxyzptlk/p/b;
    //   4: ifnull -> 9
    //   7: iconst_0
    //   8: ireturn
    //   9: iconst_1
    //   10: istore #4
    //   12: aload_0
    //   13: iload_1
    //   14: iconst_1
    //   15: invokevirtual u0 : (IZ)Landroidx/appcompat/app/c$u;
    //   18: astore #6
    //   20: iload_1
    //   21: ifne -> 113
    //   24: aload_0
    //   25: getfield r : Ldbxyzptlk/r/t;
    //   28: astore #5
    //   30: aload #5
    //   32: ifnull -> 113
    //   35: aload #5
    //   37: invokeinterface a : ()Z
    //   42: ifeq -> 113
    //   45: aload_0
    //   46: getfield k : Landroid/content/Context;
    //   49: invokestatic get : (Landroid/content/Context;)Landroid/view/ViewConfiguration;
    //   52: invokevirtual hasPermanentMenuKey : ()Z
    //   55: ifne -> 113
    //   58: aload_0
    //   59: getfield r : Ldbxyzptlk/r/t;
    //   62: invokeinterface d : ()Z
    //   67: ifne -> 100
    //   70: aload_0
    //   71: getfield R : Z
    //   74: ifne -> 186
    //   77: aload_0
    //   78: aload #6
    //   80: aload_2
    //   81: invokevirtual Q0 : (Landroidx/appcompat/app/c$u;Landroid/view/KeyEvent;)Z
    //   84: ifeq -> 186
    //   87: aload_0
    //   88: getfield r : Ldbxyzptlk/r/t;
    //   91: invokeinterface b : ()Z
    //   96: istore_3
    //   97: goto -> 198
    //   100: aload_0
    //   101: getfield r : Ldbxyzptlk/r/t;
    //   104: invokeinterface e : ()Z
    //   109: istore_3
    //   110: goto -> 198
    //   113: aload #6
    //   115: getfield o : Z
    //   118: istore_3
    //   119: iload_3
    //   120: ifne -> 191
    //   123: aload #6
    //   125: getfield n : Z
    //   128: ifeq -> 134
    //   131: goto -> 191
    //   134: aload #6
    //   136: getfield m : Z
    //   139: ifeq -> 186
    //   142: aload #6
    //   144: getfield r : Z
    //   147: ifeq -> 167
    //   150: aload #6
    //   152: iconst_0
    //   153: putfield m : Z
    //   156: aload_0
    //   157: aload #6
    //   159: aload_2
    //   160: invokevirtual Q0 : (Landroidx/appcompat/app/c$u;Landroid/view/KeyEvent;)Z
    //   163: istore_3
    //   164: goto -> 169
    //   167: iconst_1
    //   168: istore_3
    //   169: iload_3
    //   170: ifeq -> 186
    //   173: aload_0
    //   174: aload #6
    //   176: aload_2
    //   177: invokevirtual N0 : (Landroidx/appcompat/app/c$u;Landroid/view/KeyEvent;)V
    //   180: iload #4
    //   182: istore_3
    //   183: goto -> 198
    //   186: iconst_0
    //   187: istore_3
    //   188: goto -> 198
    //   191: aload_0
    //   192: aload #6
    //   194: iconst_1
    //   195: invokevirtual d0 : (Landroidx/appcompat/app/c$u;Z)V
    //   198: iload_3
    //   199: ifeq -> 241
    //   202: aload_0
    //   203: getfield k : Landroid/content/Context;
    //   206: invokevirtual getApplicationContext : ()Landroid/content/Context;
    //   209: ldc_w 'audio'
    //   212: invokevirtual getSystemService : (Ljava/lang/String;)Ljava/lang/Object;
    //   215: checkcast android/media/AudioManager
    //   218: astore_2
    //   219: aload_2
    //   220: ifnull -> 231
    //   223: aload_2
    //   224: iconst_0
    //   225: invokevirtual playSoundEffect : (I)V
    //   228: goto -> 241
    //   231: ldc_w 'AppCompatDelegate'
    //   234: ldc_w 'Couldn't get audio manager'
    //   237: invokestatic f : (Ljava/lang/String;Ljava/lang/String;)I
    //   240: pop
    //   241: iload_3
    //   242: ireturn
  }
  
  public void K(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    l0();
    ViewGroup viewGroup = (ViewGroup)this.B.findViewById(16908290);
    viewGroup.removeAllViews();
    viewGroup.addView(paramView, paramLayoutParams);
    this.m.c(this.l.getCallback());
  }
  
  public void K0(int paramInt) {
    if (paramInt == 108) {
      ActionBar actionBar = s();
      if (actionBar != null)
        actionBar.i(true); 
    } 
  }
  
  public void L0(int paramInt) {
    if (paramInt == 108) {
      ActionBar actionBar = s();
      if (actionBar != null)
        actionBar.i(false); 
    } else if (paramInt == 0) {
      u u1 = u0(paramInt, true);
      if (u1.o)
        d0(u1, false); 
    } 
  }
  
  public void M(int paramInt) {
    if (this.T != paramInt) {
      this.T = paramInt;
      if (this.P)
        d(); 
    } 
  }
  
  public void M0(ViewGroup paramViewGroup) {}
  
  public void N(OnBackInvokedDispatcher paramOnBackInvokedDispatcher) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: invokespecial N : (Landroid/window/OnBackInvokedDispatcher;)V
    //   5: aload_0
    //   6: getfield h0 : Landroid/window/OnBackInvokedDispatcher;
    //   9: astore_2
    //   10: aload_2
    //   11: ifnull -> 33
    //   14: aload_0
    //   15: getfield i0 : Landroid/window/OnBackInvokedCallback;
    //   18: astore_3
    //   19: aload_3
    //   20: ifnull -> 33
    //   23: aload_2
    //   24: aload_3
    //   25: invokestatic c : (Ljava/lang/Object;Ljava/lang/Object;)V
    //   28: aload_0
    //   29: aconst_null
    //   30: putfield i0 : Landroid/window/OnBackInvokedCallback;
    //   33: aload_1
    //   34: ifnonnull -> 76
    //   37: aload_0
    //   38: getfield j : Ljava/lang/Object;
    //   41: astore_2
    //   42: aload_2
    //   43: instanceof android/app/Activity
    //   46: ifeq -> 76
    //   49: aload_2
    //   50: checkcast android/app/Activity
    //   53: invokevirtual getWindow : ()Landroid/view/Window;
    //   56: ifnull -> 76
    //   59: aload_0
    //   60: aload_0
    //   61: getfield j : Ljava/lang/Object;
    //   64: checkcast android/app/Activity
    //   67: invokestatic a : (Landroid/app/Activity;)Landroid/window/OnBackInvokedDispatcher;
    //   70: putfield h0 : Landroid/window/OnBackInvokedDispatcher;
    //   73: goto -> 81
    //   76: aload_0
    //   77: aload_1
    //   78: putfield h0 : Landroid/window/OnBackInvokedDispatcher;
    //   81: aload_0
    //   82: invokevirtual d1 : ()V
    //   85: return
  }
  
  public final void N0(u paramu, KeyEvent paramKeyEvent) {
    // Byte code:
    //   0: aload_1
    //   1: getfield o : Z
    //   4: ifne -> 407
    //   7: aload_0
    //   8: getfield R : Z
    //   11: ifeq -> 17
    //   14: goto -> 407
    //   17: aload_1
    //   18: getfield a : I
    //   21: ifne -> 45
    //   24: aload_0
    //   25: getfield k : Landroid/content/Context;
    //   28: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   31: invokevirtual getConfiguration : ()Landroid/content/res/Configuration;
    //   34: getfield screenLayout : I
    //   37: bipush #15
    //   39: iand
    //   40: iconst_4
    //   41: if_icmpne -> 45
    //   44: return
    //   45: aload_0
    //   46: invokevirtual w0 : ()Landroid/view/Window$Callback;
    //   49: astore #4
    //   51: aload #4
    //   53: ifnull -> 81
    //   56: aload #4
    //   58: aload_1
    //   59: getfield a : I
    //   62: aload_1
    //   63: getfield j : Landroidx/appcompat/view/menu/e;
    //   66: invokeinterface onMenuOpened : (ILandroid/view/Menu;)Z
    //   71: ifne -> 81
    //   74: aload_0
    //   75: aload_1
    //   76: iconst_1
    //   77: invokevirtual d0 : (Landroidx/appcompat/app/c$u;Z)V
    //   80: return
    //   81: aload_0
    //   82: getfield k : Landroid/content/Context;
    //   85: ldc_w 'window'
    //   88: invokevirtual getSystemService : (Ljava/lang/String;)Ljava/lang/Object;
    //   91: checkcast android/view/WindowManager
    //   94: astore #5
    //   96: aload #5
    //   98: ifnonnull -> 102
    //   101: return
    //   102: aload_0
    //   103: aload_1
    //   104: aload_2
    //   105: invokevirtual Q0 : (Landroidx/appcompat/app/c$u;Landroid/view/KeyEvent;)Z
    //   108: ifne -> 112
    //   111: return
    //   112: aload_1
    //   113: getfield g : Landroid/view/ViewGroup;
    //   116: astore_2
    //   117: aload_2
    //   118: ifnull -> 162
    //   121: aload_1
    //   122: getfield q : Z
    //   125: ifeq -> 131
    //   128: goto -> 162
    //   131: aload_1
    //   132: getfield i : Landroid/view/View;
    //   135: astore_2
    //   136: aload_2
    //   137: ifnull -> 322
    //   140: aload_2
    //   141: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   144: astore_2
    //   145: aload_2
    //   146: ifnull -> 322
    //   149: aload_2
    //   150: getfield width : I
    //   153: iconst_m1
    //   154: if_icmpne -> 322
    //   157: iconst_m1
    //   158: istore_3
    //   159: goto -> 325
    //   162: aload_2
    //   163: ifnonnull -> 182
    //   166: aload_0
    //   167: aload_1
    //   168: invokevirtual z0 : (Landroidx/appcompat/app/c$u;)Z
    //   171: ifeq -> 181
    //   174: aload_1
    //   175: getfield g : Landroid/view/ViewGroup;
    //   178: ifnonnull -> 203
    //   181: return
    //   182: aload_1
    //   183: getfield q : Z
    //   186: ifeq -> 203
    //   189: aload_2
    //   190: invokevirtual getChildCount : ()I
    //   193: ifle -> 203
    //   196: aload_1
    //   197: getfield g : Landroid/view/ViewGroup;
    //   200: invokevirtual removeAllViews : ()V
    //   203: aload_0
    //   204: aload_1
    //   205: invokevirtual y0 : (Landroidx/appcompat/app/c$u;)Z
    //   208: ifeq -> 402
    //   211: aload_1
    //   212: invokevirtual b : ()Z
    //   215: ifne -> 221
    //   218: goto -> 402
    //   221: aload_1
    //   222: getfield h : Landroid/view/View;
    //   225: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   228: astore #4
    //   230: aload #4
    //   232: astore_2
    //   233: aload #4
    //   235: ifnonnull -> 250
    //   238: new android/view/ViewGroup$LayoutParams
    //   241: dup
    //   242: bipush #-2
    //   244: bipush #-2
    //   246: invokespecial <init> : (II)V
    //   249: astore_2
    //   250: aload_1
    //   251: getfield b : I
    //   254: istore_3
    //   255: aload_1
    //   256: getfield g : Landroid/view/ViewGroup;
    //   259: iload_3
    //   260: invokevirtual setBackgroundResource : (I)V
    //   263: aload_1
    //   264: getfield h : Landroid/view/View;
    //   267: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   270: astore #4
    //   272: aload #4
    //   274: instanceof android/view/ViewGroup
    //   277: ifeq -> 292
    //   280: aload #4
    //   282: checkcast android/view/ViewGroup
    //   285: aload_1
    //   286: getfield h : Landroid/view/View;
    //   289: invokevirtual removeView : (Landroid/view/View;)V
    //   292: aload_1
    //   293: getfield g : Landroid/view/ViewGroup;
    //   296: aload_1
    //   297: getfield h : Landroid/view/View;
    //   300: aload_2
    //   301: invokevirtual addView : (Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    //   304: aload_1
    //   305: getfield h : Landroid/view/View;
    //   308: invokevirtual hasFocus : ()Z
    //   311: ifne -> 322
    //   314: aload_1
    //   315: getfield h : Landroid/view/View;
    //   318: invokevirtual requestFocus : ()Z
    //   321: pop
    //   322: bipush #-2
    //   324: istore_3
    //   325: aload_1
    //   326: iconst_0
    //   327: putfield n : Z
    //   330: new android/view/WindowManager$LayoutParams
    //   333: dup
    //   334: iload_3
    //   335: bipush #-2
    //   337: aload_1
    //   338: getfield d : I
    //   341: aload_1
    //   342: getfield e : I
    //   345: sipush #1002
    //   348: ldc_w 8519680
    //   351: bipush #-3
    //   353: invokespecial <init> : (IIIIIII)V
    //   356: astore_2
    //   357: aload_2
    //   358: aload_1
    //   359: getfield c : I
    //   362: putfield gravity : I
    //   365: aload_2
    //   366: aload_1
    //   367: getfield f : I
    //   370: putfield windowAnimations : I
    //   373: aload #5
    //   375: aload_1
    //   376: getfield g : Landroid/view/ViewGroup;
    //   379: aload_2
    //   380: invokeinterface addView : (Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    //   385: aload_1
    //   386: iconst_1
    //   387: putfield o : Z
    //   390: aload_1
    //   391: getfield a : I
    //   394: ifne -> 401
    //   397: aload_0
    //   398: invokevirtual d1 : ()V
    //   401: return
    //   402: aload_1
    //   403: iconst_1
    //   404: putfield q : Z
    //   407: return
  }
  
  public void O(Toolbar paramToolbar) {
    if (!(this.j instanceof Activity))
      return; 
    ActionBar actionBar = s();
    if (!(actionBar instanceof f)) {
      this.p = null;
      if (actionBar != null)
        actionBar.o(); 
      this.o = null;
      if (paramToolbar != null) {
        e e = new e(paramToolbar, v0(), (Window.Callback)this.m);
        this.o = (ActionBar)e;
        this.m.e(e.c);
        paramToolbar.setBackInvokedCallbackEnabled(true);
      } else {
        this.m.e(null);
      } 
      u();
      return;
    } 
    throw new IllegalStateException("This Activity already has an action bar supplied by the window decor. Do not request Window.FEATURE_SUPPORT_ACTION_BAR and set windowActionBar to false in your theme to use a Toolbar instead.");
  }
  
  public final ActionBar O0() {
    return this.o;
  }
  
  public void P(int paramInt) {
    this.U = paramInt;
  }
  
  public final boolean P0(u paramu, int paramInt1, KeyEvent paramKeyEvent, int paramInt2) {
    // Byte code:
    //   0: aload_3
    //   1: invokevirtual isSystem : ()Z
    //   4: istore #5
    //   6: iconst_0
    //   7: istore #6
    //   9: iload #5
    //   11: ifeq -> 16
    //   14: iconst_0
    //   15: ireturn
    //   16: aload_1
    //   17: getfield m : Z
    //   20: ifne -> 36
    //   23: iload #6
    //   25: istore #5
    //   27: aload_0
    //   28: aload_1
    //   29: aload_3
    //   30: invokevirtual Q0 : (Landroidx/appcompat/app/c$u;Landroid/view/KeyEvent;)Z
    //   33: ifeq -> 62
    //   36: aload_1
    //   37: getfield j : Landroidx/appcompat/view/menu/e;
    //   40: astore #7
    //   42: iload #6
    //   44: istore #5
    //   46: aload #7
    //   48: ifnull -> 62
    //   51: aload #7
    //   53: iload_2
    //   54: aload_3
    //   55: iload #4
    //   57: invokevirtual performShortcut : (ILandroid/view/KeyEvent;I)Z
    //   60: istore #5
    //   62: iload #5
    //   64: ifeq -> 87
    //   67: iload #4
    //   69: iconst_1
    //   70: iand
    //   71: ifne -> 87
    //   74: aload_0
    //   75: getfield r : Ldbxyzptlk/r/t;
    //   78: ifnonnull -> 87
    //   81: aload_0
    //   82: aload_1
    //   83: iconst_1
    //   84: invokevirtual d0 : (Landroidx/appcompat/app/c$u;Z)V
    //   87: iload #5
    //   89: ireturn
  }
  
  public final void Q(CharSequence paramCharSequence) {
    this.q = paramCharSequence;
    t t1 = this.r;
    if (t1 != null) {
      t1.setWindowTitle(paramCharSequence);
    } else if (O0() != null) {
      O0().B(paramCharSequence);
    } else {
      TextView textView = this.C;
      if (textView != null)
        textView.setText(paramCharSequence); 
    } 
  }
  
  public final boolean Q0(u paramu, KeyEvent paramKeyEvent) {
    t t1;
    if (this.R)
      return false; 
    if (paramu.m)
      return true; 
    u u1 = this.N;
    if (u1 != null && u1 != paramu)
      d0(u1, false); 
    Window.Callback callback = w0();
    if (callback != null)
      paramu.i = callback.onCreatePanelView(paramu.a); 
    int i = paramu.a;
    if (i == 0 || i == 108) {
      i = 1;
    } else {
      i = 0;
    } 
    if (i != 0) {
      t t2 = this.r;
      if (t2 != null)
        t2.setMenuPrepared(); 
    } 
    if (paramu.i == null && (i == 0 || !(O0() instanceof e))) {
      t t2;
      boolean bool;
      e e = paramu.j;
      if (e == null || paramu.r) {
        if (e == null && (!A0(paramu) || paramu.j == null))
          return false; 
        if (i != 0 && this.r != null) {
          if (this.s == null)
            this.s = new h(this); 
          this.r.setMenu((Menu)paramu.j, (i.a)this.s);
        } 
        paramu.j.stopDispatchingItemsChanged();
        if (!callback.onCreatePanelMenu(paramu.a, (Menu)paramu.j)) {
          paramu.c(null);
          if (i != 0) {
            t1 = this.r;
            if (t1 != null)
              t1.setMenu(null, (i.a)this.s); 
          } 
          return false;
        } 
        ((u)t1).r = false;
      } 
      ((u)t1).j.stopDispatchingItemsChanged();
      Bundle bundle = ((u)t1).s;
      if (bundle != null) {
        ((u)t1).j.restoreActionViewStates(bundle);
        ((u)t1).s = null;
      } 
      if (!callback.onPreparePanel(0, ((u)t1).i, (Menu)((u)t1).j)) {
        if (i != 0) {
          t2 = this.r;
          if (t2 != null)
            t2.setMenu(null, (i.a)this.s); 
        } 
        ((u)t1).j.startDispatchingItemsChanged();
        return false;
      } 
      if (t2 != null) {
        i = t2.getDeviceId();
      } else {
        i = -1;
      } 
      if (KeyCharacterMap.load(i).getKeyboardType() != 1) {
        bool = true;
      } else {
        bool = false;
      } 
      ((u)t1).p = bool;
      ((u)t1).j.setQwertyMode(bool);
      ((u)t1).j.startDispatchingItemsChanged();
    } 
    ((u)t1).m = true;
    ((u)t1).n = false;
    this.N = (u)t1;
    return true;
  }
  
  public dbxyzptlk.p.b R(dbxyzptlk.p.b.a parama) {
    if (parama != null) {
      dbxyzptlk.p.b b1 = this.u;
      if (b1 != null)
        b1.a(); 
      i i = new i(this, parama);
      ActionBar actionBar = s();
      if (actionBar != null) {
        dbxyzptlk.p.b b2 = actionBar.D((dbxyzptlk.p.b.a)i);
        this.u = b2;
        if (b2 != null) {
          dbxyzptlk.k.b b3 = this.n;
          if (b3 != null)
            b3.onSupportActionModeStarted(b2); 
        } 
      } 
      if (this.u == null)
        this.u = Y0((dbxyzptlk.p.b.a)i); 
      d1();
      return this.u;
    } 
    throw new IllegalArgumentException("ActionMode callback can not be null.");
  }
  
  public final void R0(boolean paramBoolean) {
    t t1 = this.r;
    if (t1 != null && t1.a() && (!ViewConfiguration.get(this.k).hasPermanentMenuKey() || this.r.f())) {
      Window.Callback callback = w0();
      if (!this.r.d() || !paramBoolean) {
        if (callback != null && !this.R) {
          if (this.Z && (this.a0 & 0x1) != 0) {
            this.l.getDecorView().removeCallbacks(this.b0);
            this.b0.run();
          } 
          u u2 = u0(0, true);
          e e = u2.j;
          if (e != null && !u2.r && callback.onPreparePanel(0, u2.i, (Menu)e)) {
            callback.onMenuOpened(108, (Menu)u2.j);
            this.r.b();
          } 
        } 
        return;
      } 
      this.r.e();
      if (!this.R)
        callback.onPanelClosed(108, (Menu)(u0(0, true)).j); 
      return;
    } 
    u u1 = u0(0, true);
    u1.q = true;
    d0(u1, false);
    N0(u1, null);
  }
  
  public final int S0(int paramInt) {
    if (paramInt == 8) {
      Log.i("AppCompatDelegate", "You should now use the AppCompatDelegate.FEATURE_SUPPORT_ACTION_BAR id when requesting this feature.");
      return 108;
    } 
    int i = paramInt;
    if (paramInt == 9) {
      Log.i("AppCompatDelegate", "You should now use the AppCompatDelegate.FEATURE_SUPPORT_ACTION_BAR_OVERLAY id when requesting this feature.");
      i = 109;
    } 
    return i;
  }
  
  public final boolean T(boolean paramBoolean) {
    return U(paramBoolean, true);
  }
  
  public void T0(Configuration paramConfiguration, dbxyzptlk.d2.j paramj) {
    l.d(paramConfiguration, paramj);
  }
  
  public final boolean U(boolean paramBoolean1, boolean paramBoolean2) {
    dbxyzptlk.d2.j j1;
    if (this.R)
      return false; 
    int i = Y();
    int j = D0(this.k, i);
    if (Build.VERSION.SDK_INT < 33) {
      j1 = X(this.k);
    } else {
      j1 = null;
    } 
    dbxyzptlk.d2.j j2 = j1;
    if (!paramBoolean2) {
      j2 = j1;
      if (j1 != null)
        j2 = t0(this.k.getResources().getConfiguration()); 
    } 
    paramBoolean1 = c1(j, j2, paramBoolean1);
    if (i == 0) {
      s0(this.k).e();
    } else {
      q q1 = this.X;
      if (q1 != null)
        q1.a(); 
    } 
    if (i == 3) {
      r0(this.k).e();
    } else {
      q q1 = this.Y;
      if (q1 != null)
        q1.a(); 
    } 
    return paramBoolean1;
  }
  
  public void U0(dbxyzptlk.d2.j paramj) {
    l.c(paramj);
  }
  
  public final void V() {
    ContentFrameLayout contentFrameLayout = (ContentFrameLayout)this.B.findViewById(16908290);
    View view = this.l.getDecorView();
    contentFrameLayout.setDecorPadding(view.getPaddingLeft(), view.getPaddingTop(), view.getPaddingRight(), view.getPaddingBottom());
    TypedArray typedArray = this.k.obtainStyledAttributes(dbxyzptlk.j.j.AppCompatTheme);
    typedArray.getValue(dbxyzptlk.j.j.AppCompatTheme_windowMinWidthMajor, contentFrameLayout.getMinWidthMajor());
    typedArray.getValue(dbxyzptlk.j.j.AppCompatTheme_windowMinWidthMinor, contentFrameLayout.getMinWidthMinor());
    if (typedArray.hasValue(dbxyzptlk.j.j.AppCompatTheme_windowFixedWidthMajor))
      typedArray.getValue(dbxyzptlk.j.j.AppCompatTheme_windowFixedWidthMajor, contentFrameLayout.getFixedWidthMajor()); 
    if (typedArray.hasValue(dbxyzptlk.j.j.AppCompatTheme_windowFixedWidthMinor))
      typedArray.getValue(dbxyzptlk.j.j.AppCompatTheme_windowFixedWidthMinor, contentFrameLayout.getFixedWidthMinor()); 
    if (typedArray.hasValue(dbxyzptlk.j.j.AppCompatTheme_windowFixedHeightMajor))
      typedArray.getValue(dbxyzptlk.j.j.AppCompatTheme_windowFixedHeightMajor, contentFrameLayout.getFixedHeightMajor()); 
    if (typedArray.hasValue(dbxyzptlk.j.j.AppCompatTheme_windowFixedHeightMinor))
      typedArray.getValue(dbxyzptlk.j.j.AppCompatTheme_windowFixedHeightMinor, contentFrameLayout.getFixedHeightMinor()); 
    typedArray.recycle();
    contentFrameLayout.requestLayout();
  }
  
  public final boolean V0() {
    if (this.A) {
      ViewGroup viewGroup = this.B;
      if (viewGroup != null && h0.U((View)viewGroup))
        return true; 
    } 
    return false;
  }
  
  public final void W(Window paramWindow) {
    if (this.l == null) {
      Window.Callback callback = paramWindow.getCallback();
      if (!(callback instanceof o)) {
        o o1 = new o(this, callback);
        this.m = o1;
        paramWindow.setCallback((Window.Callback)o1);
        O o2 = O.u(this.k, null, l0);
        Drawable drawable = o2.h(0);
        if (drawable != null)
          paramWindow.setBackgroundDrawable(drawable); 
        o2.w();
        this.l = paramWindow;
        if (Build.VERSION.SDK_INT >= 33 && this.h0 == null)
          N(null); 
        return;
      } 
      throw new IllegalStateException("AppCompat has already installed itself into the Window");
    } 
    throw new IllegalStateException("AppCompat has already installed itself into the Window");
  }
  
  public final boolean W0(ViewParent paramViewParent) {
    if (paramViewParent == null)
      return false; 
    View view = this.l.getDecorView();
    while (true) {
      if (paramViewParent == null)
        return true; 
      if (paramViewParent == view || !(paramViewParent instanceof View) || h0.T((View)paramViewParent))
        break; 
      paramViewParent = paramViewParent.getParent();
    } 
    return false;
  }
  
  public dbxyzptlk.d2.j X(Context paramContext) {
    if (Build.VERSION.SDK_INT >= 33)
      return null; 
    dbxyzptlk.d2.j j2 = b.r();
    if (j2 == null)
      return null; 
    dbxyzptlk.d2.j j1 = t0(paramContext.getApplicationContext().getResources().getConfiguration());
    j2 = dbxyzptlk.k.o.b(j2, j1);
    if (!j2.f())
      j1 = j2; 
    return j1;
  }
  
  public boolean X0() {
    if (this.h0 == null)
      return false; 
    u u1 = u0(0, false);
    return (u1 != null && u1.o) ? true : ((this.u != null));
  }
  
  public final int Y() {
    int i = this.T;
    if (i == -100)
      i = b.m(); 
    return i;
  }
  
  public dbxyzptlk.p.b Y0(dbxyzptlk.p.b.a parama) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual k0 : ()V
    //   4: aload_0
    //   5: getfield u : Ldbxyzptlk/p/b;
    //   8: astore #4
    //   10: aload #4
    //   12: ifnull -> 20
    //   15: aload #4
    //   17: invokevirtual a : ()V
    //   20: aload_1
    //   21: astore #4
    //   23: aload_1
    //   24: instanceof androidx/appcompat/app/c$i
    //   27: ifne -> 41
    //   30: new androidx/appcompat/app/c$i
    //   33: dup
    //   34: aload_0
    //   35: aload_1
    //   36: invokespecial <init> : (Landroidx/appcompat/app/c;Ldbxyzptlk/p/b$a;)V
    //   39: astore #4
    //   41: aload_0
    //   42: getfield n : Ldbxyzptlk/k/b;
    //   45: astore_1
    //   46: aload_1
    //   47: ifnull -> 69
    //   50: aload_0
    //   51: getfield R : Z
    //   54: ifne -> 69
    //   57: aload_1
    //   58: aload #4
    //   60: invokeinterface onWindowStartingSupportActionMode : (Ldbxyzptlk/p/b$a;)Ldbxyzptlk/p/b;
    //   65: astore_1
    //   66: goto -> 71
    //   69: aconst_null
    //   70: astore_1
    //   71: aload_1
    //   72: ifnull -> 83
    //   75: aload_0
    //   76: aload_1
    //   77: putfield u : Ldbxyzptlk/p/b;
    //   80: goto -> 565
    //   83: aload_0
    //   84: getfield v : Landroidx/appcompat/widget/ActionBarContextView;
    //   87: astore_1
    //   88: iconst_1
    //   89: istore_3
    //   90: aload_1
    //   91: ifnonnull -> 355
    //   94: aload_0
    //   95: getfield J : Z
    //   98: ifeq -> 315
    //   101: new android/util/TypedValue
    //   104: dup
    //   105: invokespecial <init> : ()V
    //   108: astore #5
    //   110: aload_0
    //   111: getfield k : Landroid/content/Context;
    //   114: invokevirtual getTheme : ()Landroid/content/res/Resources$Theme;
    //   117: astore_1
    //   118: aload_1
    //   119: getstatic dbxyzptlk/j/a.actionBarTheme : I
    //   122: aload #5
    //   124: iconst_1
    //   125: invokevirtual resolveAttribute : (ILandroid/util/TypedValue;Z)Z
    //   128: pop
    //   129: aload #5
    //   131: getfield resourceId : I
    //   134: ifeq -> 191
    //   137: aload_0
    //   138: getfield k : Landroid/content/Context;
    //   141: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   144: invokevirtual newTheme : ()Landroid/content/res/Resources$Theme;
    //   147: astore #6
    //   149: aload #6
    //   151: aload_1
    //   152: invokevirtual setTo : (Landroid/content/res/Resources$Theme;)V
    //   155: aload #6
    //   157: aload #5
    //   159: getfield resourceId : I
    //   162: iconst_1
    //   163: invokevirtual applyStyle : (IZ)V
    //   166: new dbxyzptlk/p/d
    //   169: dup
    //   170: aload_0
    //   171: getfield k : Landroid/content/Context;
    //   174: iconst_0
    //   175: invokespecial <init> : (Landroid/content/Context;I)V
    //   178: astore_1
    //   179: aload_1
    //   180: invokevirtual getTheme : ()Landroid/content/res/Resources$Theme;
    //   183: aload #6
    //   185: invokevirtual setTo : (Landroid/content/res/Resources$Theme;)V
    //   188: goto -> 196
    //   191: aload_0
    //   192: getfield k : Landroid/content/Context;
    //   195: astore_1
    //   196: aload_0
    //   197: new androidx/appcompat/widget/ActionBarContextView
    //   200: dup
    //   201: aload_1
    //   202: invokespecial <init> : (Landroid/content/Context;)V
    //   205: putfield v : Landroidx/appcompat/widget/ActionBarContextView;
    //   208: new android/widget/PopupWindow
    //   211: dup
    //   212: aload_1
    //   213: aconst_null
    //   214: getstatic dbxyzptlk/j/a.actionModePopupWindowStyle : I
    //   217: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;I)V
    //   220: astore #6
    //   222: aload_0
    //   223: aload #6
    //   225: putfield w : Landroid/widget/PopupWindow;
    //   228: aload #6
    //   230: iconst_2
    //   231: invokestatic b : (Landroid/widget/PopupWindow;I)V
    //   234: aload_0
    //   235: getfield w : Landroid/widget/PopupWindow;
    //   238: aload_0
    //   239: getfield v : Landroidx/appcompat/widget/ActionBarContextView;
    //   242: invokevirtual setContentView : (Landroid/view/View;)V
    //   245: aload_0
    //   246: getfield w : Landroid/widget/PopupWindow;
    //   249: iconst_m1
    //   250: invokevirtual setWidth : (I)V
    //   253: aload_1
    //   254: invokevirtual getTheme : ()Landroid/content/res/Resources$Theme;
    //   257: getstatic dbxyzptlk/j/a.actionBarSize : I
    //   260: aload #5
    //   262: iconst_1
    //   263: invokevirtual resolveAttribute : (ILandroid/util/TypedValue;Z)Z
    //   266: pop
    //   267: aload #5
    //   269: getfield data : I
    //   272: aload_1
    //   273: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   276: invokevirtual getDisplayMetrics : ()Landroid/util/DisplayMetrics;
    //   279: invokestatic complexToDimensionPixelSize : (ILandroid/util/DisplayMetrics;)I
    //   282: istore_2
    //   283: aload_0
    //   284: getfield v : Landroidx/appcompat/widget/ActionBarContextView;
    //   287: iload_2
    //   288: invokevirtual setContentHeight : (I)V
    //   291: aload_0
    //   292: getfield w : Landroid/widget/PopupWindow;
    //   295: bipush #-2
    //   297: invokevirtual setHeight : (I)V
    //   300: aload_0
    //   301: new androidx/appcompat/app/c$d
    //   304: dup
    //   305: aload_0
    //   306: invokespecial <init> : (Landroidx/appcompat/app/c;)V
    //   309: putfield x : Ljava/lang/Runnable;
    //   312: goto -> 355
    //   315: aload_0
    //   316: getfield B : Landroid/view/ViewGroup;
    //   319: getstatic dbxyzptlk/j/f.action_mode_bar_stub : I
    //   322: invokevirtual findViewById : (I)Landroid/view/View;
    //   325: checkcast androidx/appcompat/widget/ViewStubCompat
    //   328: astore_1
    //   329: aload_1
    //   330: ifnull -> 355
    //   333: aload_1
    //   334: aload_0
    //   335: invokevirtual p0 : ()Landroid/content/Context;
    //   338: invokestatic from : (Landroid/content/Context;)Landroid/view/LayoutInflater;
    //   341: invokevirtual setLayoutInflater : (Landroid/view/LayoutInflater;)V
    //   344: aload_0
    //   345: aload_1
    //   346: invokevirtual a : ()Landroid/view/View;
    //   349: checkcast androidx/appcompat/widget/ActionBarContextView
    //   352: putfield v : Landroidx/appcompat/widget/ActionBarContextView;
    //   355: aload_0
    //   356: getfield v : Landroidx/appcompat/widget/ActionBarContextView;
    //   359: ifnull -> 565
    //   362: aload_0
    //   363: invokevirtual k0 : ()V
    //   366: aload_0
    //   367: getfield v : Landroidx/appcompat/widget/ActionBarContextView;
    //   370: invokevirtual k : ()V
    //   373: aload_0
    //   374: getfield v : Landroidx/appcompat/widget/ActionBarContextView;
    //   377: invokevirtual getContext : ()Landroid/content/Context;
    //   380: astore #5
    //   382: aload_0
    //   383: getfield v : Landroidx/appcompat/widget/ActionBarContextView;
    //   386: astore_1
    //   387: aload_0
    //   388: getfield w : Landroid/widget/PopupWindow;
    //   391: ifnonnull -> 397
    //   394: goto -> 399
    //   397: iconst_0
    //   398: istore_3
    //   399: new dbxyzptlk/p/e
    //   402: dup
    //   403: aload #5
    //   405: aload_1
    //   406: aload #4
    //   408: iload_3
    //   409: invokespecial <init> : (Landroid/content/Context;Landroidx/appcompat/widget/ActionBarContextView;Ldbxyzptlk/p/b$a;Z)V
    //   412: astore_1
    //   413: aload #4
    //   415: aload_1
    //   416: aload_1
    //   417: invokevirtual c : ()Landroid/view/Menu;
    //   420: invokeinterface b : (Ldbxyzptlk/p/b;Landroid/view/Menu;)Z
    //   425: ifeq -> 560
    //   428: aload_1
    //   429: invokevirtual i : ()V
    //   432: aload_0
    //   433: getfield v : Landroidx/appcompat/widget/ActionBarContextView;
    //   436: aload_1
    //   437: invokevirtual h : (Ldbxyzptlk/p/b;)V
    //   440: aload_0
    //   441: aload_1
    //   442: putfield u : Ldbxyzptlk/p/b;
    //   445: aload_0
    //   446: invokevirtual V0 : ()Z
    //   449: ifeq -> 493
    //   452: aload_0
    //   453: getfield v : Landroidx/appcompat/widget/ActionBarContextView;
    //   456: fconst_0
    //   457: invokevirtual setAlpha : (F)V
    //   460: aload_0
    //   461: getfield v : Landroidx/appcompat/widget/ActionBarContextView;
    //   464: invokestatic e : (Landroid/view/View;)Ldbxyzptlk/h2/r0;
    //   467: fconst_1
    //   468: invokevirtual b : (F)Ldbxyzptlk/h2/r0;
    //   471: astore_1
    //   472: aload_0
    //   473: aload_1
    //   474: putfield y : Ldbxyzptlk/h2/r0;
    //   477: aload_1
    //   478: new androidx/appcompat/app/c$e
    //   481: dup
    //   482: aload_0
    //   483: invokespecial <init> : (Landroidx/appcompat/app/c;)V
    //   486: invokevirtual k : (Ldbxyzptlk/h2/s0;)Ldbxyzptlk/h2/r0;
    //   489: pop
    //   490: goto -> 535
    //   493: aload_0
    //   494: getfield v : Landroidx/appcompat/widget/ActionBarContextView;
    //   497: fconst_1
    //   498: invokevirtual setAlpha : (F)V
    //   501: aload_0
    //   502: getfield v : Landroidx/appcompat/widget/ActionBarContextView;
    //   505: iconst_0
    //   506: invokevirtual setVisibility : (I)V
    //   509: aload_0
    //   510: getfield v : Landroidx/appcompat/widget/ActionBarContextView;
    //   513: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   516: instanceof android/view/View
    //   519: ifeq -> 535
    //   522: aload_0
    //   523: getfield v : Landroidx/appcompat/widget/ActionBarContextView;
    //   526: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   529: checkcast android/view/View
    //   532: invokestatic n0 : (Landroid/view/View;)V
    //   535: aload_0
    //   536: getfield w : Landroid/widget/PopupWindow;
    //   539: ifnull -> 565
    //   542: aload_0
    //   543: getfield l : Landroid/view/Window;
    //   546: invokevirtual getDecorView : ()Landroid/view/View;
    //   549: aload_0
    //   550: getfield x : Ljava/lang/Runnable;
    //   553: invokevirtual post : (Ljava/lang/Runnable;)Z
    //   556: pop
    //   557: goto -> 565
    //   560: aload_0
    //   561: aconst_null
    //   562: putfield u : Ldbxyzptlk/p/b;
    //   565: aload_0
    //   566: getfield u : Ldbxyzptlk/p/b;
    //   569: astore #4
    //   571: aload #4
    //   573: ifnull -> 593
    //   576: aload_0
    //   577: getfield n : Ldbxyzptlk/k/b;
    //   580: astore_1
    //   581: aload_1
    //   582: ifnull -> 593
    //   585: aload_1
    //   586: aload #4
    //   588: invokeinterface onSupportActionModeStarted : (Ldbxyzptlk/p/b;)V
    //   593: aload_0
    //   594: invokevirtual d1 : ()V
    //   597: aload_0
    //   598: getfield u : Ldbxyzptlk/p/b;
    //   601: areturn
    //   602: astore_1
    //   603: goto -> 69
    // Exception table:
    //   from	to	target	type
    //   57	66	602	java/lang/AbstractMethodError
  }
  
  public void Z(int paramInt, u paramu, Menu paramMenu) {
    e e;
    u u1 = paramu;
    Menu menu = paramMenu;
    if (paramMenu == null) {
      u u2 = paramu;
      if (paramu == null) {
        u2 = paramu;
        if (paramInt >= 0) {
          u[] arrayOfU = this.M;
          u2 = paramu;
          if (paramInt < arrayOfU.length)
            u2 = arrayOfU[paramInt]; 
        } 
      } 
      u1 = u2;
      menu = paramMenu;
      if (u2 != null) {
        e = u2.j;
        u1 = u2;
      } 
    } 
    if (u1 != null && !u1.o)
      return; 
    if (!this.R)
      this.m.d(this.l.getCallback(), paramInt, (Menu)e); 
  }
  
  public final void Z0() {
    if (!this.A)
      return; 
    throw new AndroidRuntimeException("Window feature must be requested before adding content");
  }
  
  public void a0(e parame) {
    if (this.L)
      return; 
    this.L = true;
    this.r.h();
    Window.Callback callback = w0();
    if (callback != null && !this.R)
      callback.onPanelClosed(108, (Menu)parame); 
    this.L = false;
  }
  
  public final AppCompatActivity a1() {
    Context context = this.k;
    while (context != null) {
      if (context instanceof AppCompatActivity)
        return (AppCompatActivity)context; 
      if (context instanceof ContextWrapper)
        context = ((ContextWrapper)context).getBaseContext(); 
    } 
    return null;
  }
  
  public final void b0() {
    q q1 = this.X;
    if (q1 != null)
      q1.a(); 
    q1 = this.Y;
    if (q1 != null)
      q1.a(); 
  }
  
  public final void b1(Configuration paramConfiguration) {
    Activity activity = (Activity)this.j;
    if (activity instanceof LifecycleOwner) {
      if (((LifecycleOwner)activity).getLifecycle().b().isAtLeast(f.b.CREATED))
        activity.onConfigurationChanged(paramConfiguration); 
    } else if (this.Q && !this.R) {
      activity.onConfigurationChanged(paramConfiguration);
    } 
  }
  
  public void c(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    l0();
    ((ViewGroup)this.B.findViewById(16908290)).addView(paramView, paramLayoutParams);
    this.m.c(this.l.getCallback());
  }
  
  public void c0(int paramInt) {
    d0(u0(paramInt, true), true);
  }
  
  public final boolean c1(int paramInt, dbxyzptlk.d2.j paramj, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: aload_0
    //   2: getfield k : Landroid/content/Context;
    //   5: iload_1
    //   6: aload_2
    //   7: aconst_null
    //   8: iconst_0
    //   9: invokevirtual e0 : (Landroid/content/Context;ILdbxyzptlk/d2/j;Landroid/content/res/Configuration;Z)Landroid/content/res/Configuration;
    //   12: astore #12
    //   14: aload_0
    //   15: aload_0
    //   16: getfield k : Landroid/content/Context;
    //   19: invokevirtual q0 : (Landroid/content/Context;)I
    //   22: istore #7
    //   24: aload_0
    //   25: getfield S : Landroid/content/res/Configuration;
    //   28: astore #11
    //   30: aload #11
    //   32: astore #10
    //   34: aload #11
    //   36: ifnonnull -> 51
    //   39: aload_0
    //   40: getfield k : Landroid/content/Context;
    //   43: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   46: invokevirtual getConfiguration : ()Landroid/content/res/Configuration;
    //   49: astore #10
    //   51: aload #10
    //   53: getfield uiMode : I
    //   56: istore #4
    //   58: aload #12
    //   60: getfield uiMode : I
    //   63: bipush #48
    //   65: iand
    //   66: istore #6
    //   68: aload_0
    //   69: aload #10
    //   71: invokevirtual t0 : (Landroid/content/res/Configuration;)Ldbxyzptlk/d2/j;
    //   74: astore #11
    //   76: aload_2
    //   77: ifnonnull -> 86
    //   80: aconst_null
    //   81: astore #10
    //   83: goto -> 94
    //   86: aload_0
    //   87: aload #12
    //   89: invokevirtual t0 : (Landroid/content/res/Configuration;)Ldbxyzptlk/d2/j;
    //   92: astore #10
    //   94: iconst_0
    //   95: istore #9
    //   97: iload #4
    //   99: bipush #48
    //   101: iand
    //   102: iload #6
    //   104: if_icmpeq -> 115
    //   107: sipush #512
    //   110: istore #4
    //   112: goto -> 118
    //   115: iconst_0
    //   116: istore #4
    //   118: iload #4
    //   120: istore #5
    //   122: aload #10
    //   124: ifnull -> 149
    //   127: iload #4
    //   129: istore #5
    //   131: aload #11
    //   133: aload #10
    //   135: invokevirtual equals : (Ljava/lang/Object;)Z
    //   138: ifne -> 149
    //   141: iload #4
    //   143: sipush #8196
    //   146: ior
    //   147: istore #5
    //   149: iconst_1
    //   150: istore #8
    //   152: iload #7
    //   154: iconst_m1
    //   155: ixor
    //   156: iload #5
    //   158: iand
    //   159: ifeq -> 226
    //   162: iload_3
    //   163: ifeq -> 226
    //   166: aload_0
    //   167: getfield P : Z
    //   170: ifeq -> 226
    //   173: getstatic androidx/appcompat/app/c.m0 : Z
    //   176: ifne -> 186
    //   179: aload_0
    //   180: getfield Q : Z
    //   183: ifeq -> 226
    //   186: aload_0
    //   187: getfield j : Ljava/lang/Object;
    //   190: astore #11
    //   192: aload #11
    //   194: instanceof android/app/Activity
    //   197: ifeq -> 226
    //   200: aload #11
    //   202: checkcast android/app/Activity
    //   205: invokevirtual isChild : ()Z
    //   208: ifne -> 226
    //   211: aload_0
    //   212: getfield j : Ljava/lang/Object;
    //   215: checkcast android/app/Activity
    //   218: invokestatic v : (Landroid/app/Activity;)V
    //   221: iconst_1
    //   222: istore_3
    //   223: goto -> 228
    //   226: iconst_0
    //   227: istore_3
    //   228: iload_3
    //   229: ifne -> 268
    //   232: iload #5
    //   234: ifeq -> 268
    //   237: iload #9
    //   239: istore_3
    //   240: iload #5
    //   242: iload #7
    //   244: iand
    //   245: iload #5
    //   247: if_icmpne -> 252
    //   250: iconst_1
    //   251: istore_3
    //   252: aload_0
    //   253: iload #6
    //   255: aload #10
    //   257: iload_3
    //   258: aconst_null
    //   259: invokevirtual e1 : (ILdbxyzptlk/d2/j;ZLandroid/content/res/Configuration;)V
    //   262: iload #8
    //   264: istore_3
    //   265: goto -> 268
    //   268: iload_3
    //   269: ifeq -> 322
    //   272: aload_0
    //   273: getfield j : Ljava/lang/Object;
    //   276: astore #11
    //   278: aload #11
    //   280: instanceof androidx/appcompat/app/AppCompatActivity
    //   283: ifeq -> 322
    //   286: iload #5
    //   288: sipush #512
    //   291: iand
    //   292: ifeq -> 304
    //   295: aload #11
    //   297: checkcast androidx/appcompat/app/AppCompatActivity
    //   300: iload_1
    //   301: invokevirtual onNightModeChanged : (I)V
    //   304: iload #5
    //   306: iconst_4
    //   307: iand
    //   308: ifeq -> 322
    //   311: aload_0
    //   312: getfield j : Ljava/lang/Object;
    //   315: checkcast androidx/appcompat/app/AppCompatActivity
    //   318: aload_2
    //   319: invokevirtual onLocalesChanged : (Ldbxyzptlk/d2/j;)V
    //   322: iload_3
    //   323: ifeq -> 349
    //   326: aload #10
    //   328: ifnull -> 349
    //   331: aload_0
    //   332: aload_0
    //   333: aload_0
    //   334: getfield k : Landroid/content/Context;
    //   337: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   340: invokevirtual getConfiguration : ()Landroid/content/res/Configuration;
    //   343: invokevirtual t0 : (Landroid/content/res/Configuration;)Ldbxyzptlk/d2/j;
    //   346: invokevirtual U0 : (Ldbxyzptlk/d2/j;)V
    //   349: iload_3
    //   350: ireturn
  }
  
  public boolean d() {
    return T(true);
  }
  
  public void d0(u paramu, boolean paramBoolean) {
    if (paramBoolean && paramu.a == 0) {
      t t1 = this.r;
      if (t1 != null && t1.d()) {
        a0(paramu.j);
        return;
      } 
    } 
    WindowManager windowManager = (WindowManager)this.k.getSystemService("window");
    if (windowManager != null && paramu.o) {
      ViewGroup viewGroup = paramu.g;
      if (viewGroup != null) {
        windowManager.removeView((View)viewGroup);
        if (paramBoolean)
          Z(paramu.a, paramu, null); 
      } 
    } 
    paramu.m = false;
    paramu.n = false;
    paramu.o = false;
    paramu.h = null;
    paramu.q = true;
    if (this.N == paramu)
      this.N = null; 
    if (paramu.a == 0)
      d1(); 
  }
  
  public void d1() {
    if (Build.VERSION.SDK_INT >= 33) {
      boolean bool = X0();
      if (bool && this.i0 == null) {
        this.i0 = n.b(this.h0, this);
      } else if (!bool) {
        OnBackInvokedCallback onBackInvokedCallback = this.i0;
        if (onBackInvokedCallback != null)
          n.c(this.h0, onBackInvokedCallback); 
      } 
    } 
  }
  
  public final Configuration e0(Context paramContext, int paramInt, dbxyzptlk.d2.j paramj, Configuration paramConfiguration, boolean paramBoolean) {
    if (paramInt != 1) {
      if (paramInt != 2) {
        if (paramBoolean) {
          paramInt = 0;
        } else {
          paramInt = (paramContext.getApplicationContext().getResources().getConfiguration()).uiMode & 0x30;
        } 
      } else {
        paramInt = 32;
      } 
    } else {
      paramInt = 16;
    } 
    Configuration configuration = new Configuration();
    configuration.fontScale = 0.0F;
    if (paramConfiguration != null)
      configuration.setTo(paramConfiguration); 
    configuration.uiMode = paramInt | configuration.uiMode & 0xFFFFFFCF;
    if (paramj != null)
      T0(configuration, paramj); 
    return configuration;
  }
  
  public final void e1(int paramInt, dbxyzptlk.d2.j paramj, boolean paramBoolean, Configuration paramConfiguration) {
    Resources resources = this.k.getResources();
    Configuration configuration = new Configuration(resources.getConfiguration());
    if (paramConfiguration != null)
      configuration.updateFrom(paramConfiguration); 
    configuration.uiMode = paramInt | (resources.getConfiguration()).uiMode & 0xFFFFFFCF;
    if (paramj != null)
      T0(configuration, paramj); 
    resources.updateConfiguration(configuration, null);
    paramInt = this.U;
    if (paramInt != 0) {
      this.k.setTheme(paramInt);
      this.k.getTheme().applyStyle(this.U, true);
    } 
    if (paramBoolean && this.j instanceof Activity)
      b1(configuration); 
  }
  
  public final ViewGroup f0() {
    StringBuilder stringBuilder;
    TypedArray typedArray = this.k.obtainStyledAttributes(dbxyzptlk.j.j.AppCompatTheme);
    if (typedArray.hasValue(dbxyzptlk.j.j.AppCompatTheme_windowActionBar)) {
      ViewGroup viewGroup;
      if (typedArray.getBoolean(dbxyzptlk.j.j.AppCompatTheme_windowNoTitle, false)) {
        H(1);
      } else if (typedArray.getBoolean(dbxyzptlk.j.j.AppCompatTheme_windowActionBar, false)) {
        H(108);
      } 
      if (typedArray.getBoolean(dbxyzptlk.j.j.AppCompatTheme_windowActionBarOverlay, false))
        H(109); 
      if (typedArray.getBoolean(dbxyzptlk.j.j.AppCompatTheme_windowActionModeOverlay, false))
        H(10); 
      this.J = typedArray.getBoolean(dbxyzptlk.j.j.AppCompatTheme_android_windowIsFloating, false);
      typedArray.recycle();
      m0();
      this.l.getDecorView();
      LayoutInflater layoutInflater = LayoutInflater.from(this.k);
      if (!this.K) {
        if (this.J) {
          viewGroup = (ViewGroup)layoutInflater.inflate(g.abc_dialog_title_material, null);
          this.H = false;
          this.G = false;
        } else if (this.G) {
          Context context;
          TypedValue typedValue = new TypedValue();
          this.k.getTheme().resolveAttribute(dbxyzptlk.j.a.actionBarTheme, typedValue, true);
          if (typedValue.resourceId != 0) {
            d d = new d(this.k, typedValue.resourceId);
          } else {
            context = this.k;
          } 
          ViewGroup viewGroup1 = (ViewGroup)LayoutInflater.from(context).inflate(g.abc_screen_toolbar, null);
          t t1 = (t)viewGroup1.findViewById(f.decor_content_parent);
          this.r = t1;
          t1.setWindowCallback(w0());
          if (this.H)
            this.r.g(109); 
          if (this.E)
            this.r.g(2); 
          viewGroup = viewGroup1;
          if (this.F) {
            this.r.g(5);
            viewGroup = viewGroup1;
          } 
        } else {
          layoutInflater = null;
        } 
      } else if (this.I) {
        viewGroup = (ViewGroup)layoutInflater.inflate(g.abc_screen_simple_overlay_action_mode, null);
      } else {
        viewGroup = (ViewGroup)viewGroup.inflate(g.abc_screen_simple, null);
      } 
      if (viewGroup != null) {
        h0.G0((View)viewGroup, new b(this));
        if (this.r == null)
          this.C = (TextView)viewGroup.findViewById(f.title); 
        V.c((View)viewGroup);
        ContentFrameLayout contentFrameLayout = (ContentFrameLayout)viewGroup.findViewById(f.action_bar_activity_content);
        ViewGroup viewGroup1 = (ViewGroup)this.l.findViewById(16908290);
        if (viewGroup1 != null) {
          while (viewGroup1.getChildCount() > 0) {
            View view = viewGroup1.getChildAt(0);
            viewGroup1.removeViewAt(0);
            contentFrameLayout.addView(view);
          } 
          viewGroup1.setId(-1);
          contentFrameLayout.setId(16908290);
          if (viewGroup1 instanceof FrameLayout)
            ((FrameLayout)viewGroup1).setForeground(null); 
        } 
        this.l.setContentView((View)viewGroup);
        contentFrameLayout.setAttachListener(new c(this));
        return viewGroup;
      } 
      stringBuilder = new StringBuilder();
      stringBuilder.append("AppCompat does not support the current theme features: { windowActionBar: ");
      stringBuilder.append(this.G);
      stringBuilder.append(", windowActionBarOverlay: ");
      stringBuilder.append(this.H);
      stringBuilder.append(", android:windowIsFloating: ");
      stringBuilder.append(this.J);
      stringBuilder.append(", windowActionModeOverlay: ");
      stringBuilder.append(this.I);
      stringBuilder.append(", windowNoTitle: ");
      stringBuilder.append(this.K);
      stringBuilder.append(" }");
      throw new IllegalArgumentException(stringBuilder.toString());
    } 
    stringBuilder.recycle();
    throw new IllegalStateException("You need to use a Theme.AppCompat theme (or descendant) with this activity.");
  }
  
  public final int f1(J0 paramJ0, Rect paramRect) {
    int i;
    int j;
    boolean bool1;
    boolean bool2 = false;
    if (paramJ0 != null) {
      i = paramJ0.m();
    } else if (paramRect != null) {
      i = paramRect.top;
    } else {
      i = 0;
    } 
    ActionBarContextView actionBarContextView = this.v;
    if (actionBarContextView != null && actionBarContextView.getLayoutParams() instanceof ViewGroup.MarginLayoutParams) {
      boolean bool;
      ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)this.v.getLayoutParams();
      boolean bool3 = this.v.isShown();
      int k = 1;
      bool1 = true;
      if (bool3) {
        int m;
        if (this.d0 == null) {
          this.d0 = new Rect();
          this.e0 = new Rect();
        } 
        Rect rect2 = this.d0;
        Rect rect1 = this.e0;
        if (paramJ0 == null) {
          rect2.set(paramRect);
        } else {
          rect2.set(paramJ0.k(), paramJ0.m(), paramJ0.l(), paramJ0.j());
        } 
        V.a((View)this.B, rect2, rect1);
        int i1 = rect2.top;
        bool = rect2.left;
        int i2 = rect2.right;
        paramJ0 = h0.H((View)this.B);
        if (paramJ0 == null) {
          k = 0;
        } else {
          k = paramJ0.k();
        } 
        if (paramJ0 == null) {
          m = 0;
        } else {
          m = paramJ0.l();
        } 
        if (marginLayoutParams.topMargin != i1 || marginLayoutParams.leftMargin != bool || marginLayoutParams.rightMargin != i2) {
          marginLayoutParams.topMargin = i1;
          marginLayoutParams.leftMargin = bool;
          marginLayoutParams.rightMargin = i2;
          bool = true;
        } else {
          bool = false;
        } 
        if (i1 > 0 && this.D == null) {
          View view2 = new View(this.k);
          this.D = view2;
          view2.setVisibility(8);
          FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(-1, marginLayoutParams.topMargin, 51);
          layoutParams.leftMargin = k;
          layoutParams.rightMargin = m;
          this.B.addView(this.D, -1, (ViewGroup.LayoutParams)layoutParams);
        } else {
          View view2 = this.D;
          if (view2 != null) {
            ViewGroup.MarginLayoutParams marginLayoutParams1 = (ViewGroup.MarginLayoutParams)view2.getLayoutParams();
            i1 = marginLayoutParams1.height;
            i2 = marginLayoutParams.topMargin;
            if (i1 != i2 || marginLayoutParams1.leftMargin != k || marginLayoutParams1.rightMargin != m) {
              marginLayoutParams1.height = i2;
              marginLayoutParams1.leftMargin = k;
              marginLayoutParams1.rightMargin = m;
              this.D.setLayoutParams((ViewGroup.LayoutParams)marginLayoutParams1);
            } 
          } 
        } 
        View view1 = this.D;
        if (view1 != null) {
          m = bool1;
        } else {
          m = 0;
        } 
        if (m != 0 && view1.getVisibility() != 0)
          g1(this.D); 
        k = i;
        if (!this.I) {
          k = i;
          if (m != 0)
            k = 0; 
        } 
        i = k;
        k = bool;
        bool = m;
      } else if (marginLayoutParams.topMargin != 0) {
        marginLayoutParams.topMargin = 0;
        bool = false;
      } else {
        bool = false;
        k = 0;
      } 
      j = i;
      bool1 = bool;
      if (k != 0) {
        this.v.setLayoutParams((ViewGroup.LayoutParams)marginLayoutParams);
        j = i;
        bool1 = bool;
      } 
    } else {
      bool1 = false;
      j = i;
    } 
    View view = this.D;
    if (view != null) {
      if (bool1) {
        i = bool2;
      } else {
        i = 8;
      } 
      view.setVisibility(i);
    } 
    return j;
  }
  
  public Context g(Context paramContext) {
    this.P = true;
    int i = D0(paramContext, Y());
    if (b.v(paramContext))
      b.S(paramContext); 
    dbxyzptlk.d2.j j = X(paramContext);
    if (n0 && paramContext instanceof ContextThemeWrapper) {
      Configuration configuration = e0(paramContext, i, j, null, false);
      try {
        s.a((ContextThemeWrapper)paramContext, configuration);
        return paramContext;
      } catch (IllegalStateException illegalStateException) {}
    } 
    if (paramContext instanceof d) {
      Configuration configuration = e0(paramContext, i, j, null, false);
      try {
        ((d)paramContext).a(configuration);
        return paramContext;
      } catch (IllegalStateException illegalStateException) {}
    } 
    if (!m0)
      return super.g(paramContext); 
    Configuration configuration1 = new Configuration();
    configuration1.uiMode = -1;
    configuration1.fontScale = 0.0F;
    Configuration configuration3 = j.a(paramContext, configuration1).getResources().getConfiguration();
    configuration1 = paramContext.getResources().getConfiguration();
    configuration3.uiMode = configuration1.uiMode;
    if (!configuration3.equals(configuration1)) {
      configuration1 = o0(configuration3, configuration1);
    } else {
      configuration1 = null;
    } 
    Configuration configuration2 = e0(paramContext, i, j, configuration1, true);
    d d = new d(paramContext, i.Theme_AppCompat_Empty);
    d.a(configuration2);
    try {
      Resources.Theme theme = paramContext.getTheme();
      if (theme != null)
        h.f.a(d.getTheme()); 
    } catch (NullPointerException nullPointerException) {}
    return super.g((Context)d);
  }
  
  public View g0(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    if (this.f0 == null) {
      String str = this.k.obtainStyledAttributes(dbxyzptlk.j.j.AppCompatTheme).getString(dbxyzptlk.j.j.AppCompatTheme_viewInflaterClass);
      if (str == null) {
        this.f0 = new dbxyzptlk.k.l();
      } else {
        try {
          this.f0 = this.k.getClassLoader().loadClass(str).getDeclaredConstructor(null).newInstance(null);
        } finally {
          Exception exception = null;
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Failed to instantiate custom view inflater ");
          stringBuilder.append(str);
          stringBuilder.append(". Falling back to default.");
          Log.i("AppCompatDelegate", stringBuilder.toString(), exception);
        } 
      } 
    } 
    boolean bool3 = k0;
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (bool3) {
      if (this.g0 == null)
        this.g0 = new n(); 
      if (this.g0.a(paramAttributeSet)) {
        bool1 = true;
      } else if (paramAttributeSet instanceof XmlPullParser) {
        bool1 = bool2;
        if (((XmlPullParser)paramAttributeSet).getDepth() > 1)
          bool1 = true; 
      } else {
        bool1 = W0((ViewParent)paramView);
      } 
    } 
    return this.f0.createView(paramView, paramString, paramContext, paramAttributeSet, bool1, bool3, true, U.c());
  }
  
  public final void g1(View paramView) {
    int i;
    if ((h0.N(paramView) & 0x2000) != 0) {
      i = dbxyzptlk.V1.b.c(this.k, dbxyzptlk.j.c.abc_decor_view_status_guard_light);
    } else {
      i = dbxyzptlk.V1.b.c(this.k, dbxyzptlk.j.c.abc_decor_view_status_guard);
    } 
    paramView.setBackgroundColor(i);
  }
  
  public void h0() {
    t t1 = this.r;
    if (t1 != null)
      t1.h(); 
    if (this.w != null) {
      this.l.getDecorView().removeCallbacks(this.x);
      if (this.w.isShowing())
        try {
          this.w.dismiss();
        } catch (IllegalArgumentException illegalArgumentException) {} 
      this.w = null;
    } 
    k0();
    u u1 = u0(0, false);
    if (u1 != null) {
      e e = u1.j;
      if (e != null)
        e.close(); 
    } 
  }
  
  public boolean i0(KeyEvent paramKeyEvent) {
    boolean bool;
    Object object = this.j;
    if (object instanceof y.a || object instanceof dbxyzptlk.k.k) {
      object = this.l.getDecorView();
      if (object != null && y.d((View)object, paramKeyEvent))
        return true; 
    } 
    if (paramKeyEvent.getKeyCode() == 82 && this.m.b(this.l.getCallback(), paramKeyEvent))
      return true; 
    int i = paramKeyEvent.getKeyCode();
    if (paramKeyEvent.getAction() == 0) {
      bool = F0(i, paramKeyEvent);
    } else {
      bool = I0(i, paramKeyEvent);
    } 
    return bool;
  }
  
  public <T extends View> T j(int paramInt) {
    l0();
    return (T)this.l.findViewById(paramInt);
  }
  
  public void j0(int paramInt) {
    u u1 = u0(paramInt, true);
    if (u1.j != null) {
      Bundle bundle = new Bundle();
      u1.j.saveActionViewStates(bundle);
      if (bundle.size() > 0)
        u1.s = bundle; 
      u1.j.stopDispatchingItemsChanged();
      u1.j.clear();
    } 
    u1.r = true;
    u1.q = true;
    if ((paramInt == 108 || paramInt == 0) && this.r != null) {
      u1 = u0(0, false);
      if (u1 != null) {
        u1.m = false;
        Q0(u1, null);
      } 
    } 
  }
  
  public void k0() {
    r0 r01 = this.y;
    if (r01 != null)
      r01.c(); 
  }
  
  public Context l() {
    return this.k;
  }
  
  public final void l0() {
    if (!this.A) {
      this.B = f0();
      CharSequence charSequence = v0();
      if (!TextUtils.isEmpty(charSequence)) {
        t t1 = this.r;
        if (t1 != null) {
          t1.setWindowTitle(charSequence);
        } else if (O0() != null) {
          O0().B(charSequence);
        } else {
          TextView textView = this.C;
          if (textView != null)
            textView.setText(charSequence); 
        } 
      } 
      V();
      M0(this.B);
      this.A = true;
      u u1 = u0(0, false);
      if (!this.R && (u1 == null || u1.j == null))
        B0(108); 
    } 
  }
  
  public final void m0() {
    if (this.l == null) {
      Object object = this.j;
      if (object instanceof Activity)
        W(((Activity)object).getWindow()); 
    } 
    if (this.l != null)
      return; 
    throw new IllegalStateException("We have not been given a Window");
  }
  
  public final dbxyzptlk.k.a n() {
    return (dbxyzptlk.k.a)new f(this);
  }
  
  public u n0(Menu paramMenu) {
    byte b1;
    u[] arrayOfU = this.M;
    byte b2 = 0;
    if (arrayOfU != null) {
      b1 = arrayOfU.length;
    } else {
      b1 = 0;
    } 
    while (b2 < b1) {
      u u1 = arrayOfU[b2];
      if (u1 != null && u1.j == paramMenu)
        return u1; 
      b2++;
    } 
    return null;
  }
  
  public int o() {
    return this.T;
  }
  
  public final View onCreateView(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    return g0(paramView, paramString, paramContext, paramAttributeSet);
  }
  
  public View onCreateView(String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    return onCreateView(null, paramString, paramContext, paramAttributeSet);
  }
  
  public boolean onMenuItemSelected(e parame, MenuItem paramMenuItem) {
    Window.Callback callback = w0();
    if (callback != null && !this.R) {
      u u1 = n0((Menu)parame.getRootMenu());
      if (u1 != null)
        return callback.onMenuItemSelected(u1.a, paramMenuItem); 
    } 
    return false;
  }
  
  public void onMenuModeChange(e parame) {
    R0(true);
  }
  
  public final Context p0() {
    Context context;
    ActionBar actionBar1 = s();
    if (actionBar1 != null) {
      Context context1 = actionBar1.k();
    } else {
      actionBar1 = null;
    } 
    ActionBar actionBar2 = actionBar1;
    if (actionBar1 == null)
      context = this.k; 
    return context;
  }
  
  public MenuInflater q() {
    if (this.p == null) {
      Context context;
      x0();
      ActionBar actionBar = this.o;
      if (actionBar != null) {
        context = actionBar.k();
      } else {
        context = this.k;
      } 
      this.p = (MenuInflater)new g(context);
    } 
    return this.p;
  }
  
  public final int q0(Context paramContext) {
    if (!this.W && this.j instanceof Activity) {
      PackageManager packageManager = paramContext.getPackageManager();
      if (packageManager == null)
        return 0; 
      try {
        int i;
        if (Build.VERSION.SDK_INT >= 29) {
          i = 269221888;
        } else {
          i = 786432;
        } 
        ComponentName componentName = new ComponentName();
        this(paramContext, this.j.getClass());
        ActivityInfo activityInfo = packageManager.getActivityInfo(componentName, i);
        if (activityInfo != null)
          this.V = activityInfo.configChanges; 
      } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
        Log.d("AppCompatDelegate", "Exception while getting ActivityInfo", (Throwable)nameNotFoundException);
        this.V = 0;
      } 
    } 
    this.W = true;
    return this.V;
  }
  
  public final q r0(Context paramContext) {
    if (this.Y == null)
      this.Y = (q)new p(this, paramContext); 
    return this.Y;
  }
  
  public ActionBar s() {
    x0();
    return this.o;
  }
  
  public final q s0(Context paramContext) {
    if (this.X == null)
      this.X = (q)new r(this, q.a(paramContext)); 
    return this.X;
  }
  
  public void t() {
    LayoutInflater layoutInflater = LayoutInflater.from(this.k);
    if (layoutInflater.getFactory() == null) {
      z.a(layoutInflater, (LayoutInflater.Factory2)this);
    } else if (!(layoutInflater.getFactory2() instanceof c)) {
      Log.i("AppCompatDelegate", "The Activity's LayoutInflater already has a Factory installed so we can not install AppCompat's");
    } 
  }
  
  public dbxyzptlk.d2.j t0(Configuration paramConfiguration) {
    return l.b(paramConfiguration);
  }
  
  public void u() {
    if (O0() != null && !s().m())
      B0(0); 
  }
  
  public u u0(int paramInt, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: getfield M : [Landroidx/appcompat/app/c$u;
    //   4: astore #4
    //   6: aload #4
    //   8: ifnull -> 21
    //   11: aload #4
    //   13: astore_3
    //   14: aload #4
    //   16: arraylength
    //   17: iload_1
    //   18: if_icmpgt -> 49
    //   21: iload_1
    //   22: iconst_1
    //   23: iadd
    //   24: anewarray androidx/appcompat/app/c$u
    //   27: astore_3
    //   28: aload #4
    //   30: ifnull -> 44
    //   33: aload #4
    //   35: iconst_0
    //   36: aload_3
    //   37: iconst_0
    //   38: aload #4
    //   40: arraylength
    //   41: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   44: aload_0
    //   45: aload_3
    //   46: putfield M : [Landroidx/appcompat/app/c$u;
    //   49: aload_3
    //   50: iload_1
    //   51: aaload
    //   52: astore #5
    //   54: aload #5
    //   56: astore #4
    //   58: aload #5
    //   60: ifnonnull -> 78
    //   63: new androidx/appcompat/app/c$u
    //   66: dup
    //   67: iload_1
    //   68: invokespecial <init> : (I)V
    //   71: astore #4
    //   73: aload_3
    //   74: iload_1
    //   75: aload #4
    //   77: aastore
    //   78: aload #4
    //   80: areturn
  }
  
  public final CharSequence v0() {
    Object object = this.j;
    return (object instanceof Activity) ? ((Activity)object).getTitle() : this.q;
  }
  
  public final Window.Callback w0() {
    return this.l.getCallback();
  }
  
  public void x(Configuration paramConfiguration) {
    if (this.G && this.A) {
      ActionBar actionBar = s();
      if (actionBar != null)
        actionBar.n(paramConfiguration); 
    } 
    g.b().g(this.k);
    this.S = new Configuration(this.k.getResources().getConfiguration());
    U(false, false);
  }
  
  public final void x0() {
    l0();
    if (this.G && this.o == null) {
      Object object = this.j;
      if (object instanceof Activity) {
        this.o = (ActionBar)new f((Activity)this.j, this.H);
      } else if (object instanceof Dialog) {
        this.o = (ActionBar)new f((Dialog)this.j);
      } 
      object = this.o;
      if (object != null)
        object.t(this.c0); 
    } 
  }
  
  public void y(Bundle paramBundle) {
    this.P = true;
    T(false);
    m0();
    Object object = this.j;
    if (object instanceof Activity) {
      try {
        object = dbxyzptlk.T1.l.c((Activity)object);
      } catch (IllegalArgumentException illegalArgumentException) {
        illegalArgumentException = null;
      } 
      if (illegalArgumentException != null) {
        ActionBar actionBar = O0();
        if (actionBar == null) {
          this.c0 = true;
        } else {
          actionBar.t(true);
        } 
      } 
      b.b((b)this);
    } 
    this.S = new Configuration(this.k.getResources().getConfiguration());
    this.Q = true;
  }
  
  public final boolean y0(u paramu) {
    View view = paramu.i;
    boolean bool = true;
    if (view != null) {
      paramu.h = view;
      return true;
    } 
    if (paramu.j == null)
      return false; 
    if (this.t == null)
      this.t = new v(this); 
    view = (View)paramu.a((i.a)this.t);
    paramu.h = view;
    if (view == null)
      bool = false; 
    return bool;
  }
  
  public void z() {
    // Byte code:
    //   0: aload_0
    //   1: getfield j : Ljava/lang/Object;
    //   4: instanceof android/app/Activity
    //   7: ifeq -> 14
    //   10: aload_0
    //   11: invokestatic F : (Landroidx/appcompat/app/b;)V
    //   14: aload_0
    //   15: getfield Z : Z
    //   18: ifeq -> 36
    //   21: aload_0
    //   22: getfield l : Landroid/view/Window;
    //   25: invokevirtual getDecorView : ()Landroid/view/View;
    //   28: aload_0
    //   29: getfield b0 : Ljava/lang/Runnable;
    //   32: invokevirtual removeCallbacks : (Ljava/lang/Runnable;)Z
    //   35: pop
    //   36: aload_0
    //   37: iconst_1
    //   38: putfield R : Z
    //   41: aload_0
    //   42: getfield T : I
    //   45: bipush #-100
    //   47: if_icmpeq -> 99
    //   50: aload_0
    //   51: getfield j : Ljava/lang/Object;
    //   54: astore_1
    //   55: aload_1
    //   56: instanceof android/app/Activity
    //   59: ifeq -> 99
    //   62: aload_1
    //   63: checkcast android/app/Activity
    //   66: invokevirtual isChangingConfigurations : ()Z
    //   69: ifeq -> 99
    //   72: getstatic androidx/appcompat/app/c.j0 : Ldbxyzptlk/V/E;
    //   75: aload_0
    //   76: getfield j : Ljava/lang/Object;
    //   79: invokevirtual getClass : ()Ljava/lang/Class;
    //   82: invokevirtual getName : ()Ljava/lang/String;
    //   85: aload_0
    //   86: getfield T : I
    //   89: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   92: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   95: pop
    //   96: goto -> 116
    //   99: getstatic androidx/appcompat/app/c.j0 : Ldbxyzptlk/V/E;
    //   102: aload_0
    //   103: getfield j : Ljava/lang/Object;
    //   106: invokevirtual getClass : ()Ljava/lang/Class;
    //   109: invokevirtual getName : ()Ljava/lang/String;
    //   112: invokevirtual remove : (Ljava/lang/Object;)Ljava/lang/Object;
    //   115: pop
    //   116: aload_0
    //   117: getfield o : Landroidx/appcompat/app/ActionBar;
    //   120: astore_1
    //   121: aload_1
    //   122: ifnull -> 129
    //   125: aload_1
    //   126: invokevirtual o : ()V
    //   129: aload_0
    //   130: invokevirtual b0 : ()V
    //   133: return
  }
  
  public final boolean z0(u paramu) {
    paramu.d(p0());
    paramu.g = (ViewGroup)new t(this, paramu.l);
    paramu.c = 81;
    return true;
  }
  
  public class a implements Runnable {
    public final c a;
    
    public a(c this$0) {}
    
    public void run() {
      c c1 = this.a;
      if ((c1.a0 & 0x1) != 0)
        c1.j0(0); 
      c1 = this.a;
      if ((c1.a0 & 0x1000) != 0)
        c1.j0(108); 
      c1 = this.a;
      c1.Z = false;
      c1.a0 = 0;
    }
  }
  
  public class b implements O {
    public final c a;
    
    public b(c this$0) {}
    
    public J0 onApplyWindowInsets(View param1View, J0 param1J0) {
      int j = param1J0.m();
      int i = this.a.f1(param1J0, null);
      J0 j0 = param1J0;
      if (j != i)
        j0 = param1J0.t(param1J0.k(), i, param1J0.l(), param1J0.j()); 
      return h0.c0(param1View, j0);
    }
  }
  
  public class c implements ContentFrameLayout.a {
    public final c a;
    
    public c(c this$0) {}
    
    public void a() {}
    
    public void onDetachedFromWindow() {
      this.a.h0();
    }
  }
  
  class c {}
  
  class c {}
  
  class c {}
  
  class c {}
  
  public static class j {
    public static Context a(Context param1Context, Configuration param1Configuration) {
      return param1Context.createConfigurationContext(param1Configuration);
    }
    
    public static void b(Configuration param1Configuration1, Configuration param1Configuration2, Configuration param1Configuration3) {
      int k = param1Configuration1.densityDpi;
      int i = param1Configuration2.densityDpi;
      if (k != i)
        param1Configuration3.densityDpi = i; 
    }
    
    public static void c(Configuration param1Configuration, Locale param1Locale) {
      param1Configuration.setLayoutDirection(param1Locale);
    }
    
    public static void d(Configuration param1Configuration, Locale param1Locale) {
      param1Configuration.setLocale(param1Locale);
    }
  }
  
  class c {}
  
  public static class l {
    public static void a(Configuration param1Configuration1, Configuration param1Configuration2, Configuration param1Configuration3) {
      LocaleList localeList2 = param1Configuration1.getLocales();
      LocaleList localeList1 = param1Configuration2.getLocales();
      if (!localeList2.equals(localeList1)) {
        param1Configuration3.setLocales(localeList1);
        param1Configuration3.locale = param1Configuration2.locale;
      } 
    }
    
    public static dbxyzptlk.d2.j b(Configuration param1Configuration) {
      return dbxyzptlk.d2.j.b(param1Configuration.getLocales().toLanguageTags());
    }
    
    public static void c(dbxyzptlk.d2.j param1j) {
      LocaleList.setDefault(LocaleList.forLanguageTags(param1j.h()));
    }
    
    public static void d(Configuration param1Configuration, dbxyzptlk.d2.j param1j) {
      param1Configuration.setLocales(LocaleList.forLanguageTags(param1j.h()));
    }
  }
  
  class c {}
  
  class c {}
  
  public class o extends i {
    public c.g b;
    
    public boolean c;
    
    public boolean d;
    
    public boolean e;
    
    public final c f;
    
    public o(c this$0, Window.Callback param1Callback) {
      super(param1Callback);
    }
    
    public boolean b(Window.Callback param1Callback, KeyEvent param1KeyEvent) {
      try {
        this.d = true;
        return param1Callback.dispatchKeyEvent(param1KeyEvent);
      } finally {
        this.d = false;
      } 
    }
    
    public void c(Window.Callback param1Callback) {
      try {
        this.c = true;
        param1Callback.onContentChanged();
        return;
      } finally {
        this.c = false;
      } 
    }
    
    public void d(Window.Callback param1Callback, int param1Int, Menu param1Menu) {
      try {
        this.e = true;
        param1Callback.onPanelClosed(param1Int, param1Menu);
        return;
      } finally {
        this.e = false;
      } 
    }
    
    public boolean dispatchKeyEvent(KeyEvent param1KeyEvent) {
      return this.d ? a().dispatchKeyEvent(param1KeyEvent) : ((this.f.i0(param1KeyEvent) || super.dispatchKeyEvent(param1KeyEvent)));
    }
    
    public boolean dispatchKeyShortcutEvent(KeyEvent param1KeyEvent) {
      return (super.dispatchKeyShortcutEvent(param1KeyEvent) || this.f.H0(param1KeyEvent.getKeyCode(), param1KeyEvent));
    }
    
    public void e(c.g param1g) {
      this.b = param1g;
    }
    
    public final ActionMode f(ActionMode.Callback param1Callback) {
      f.a a = new f.a(this.f.k, param1Callback);
      dbxyzptlk.p.b b = this.f.R((dbxyzptlk.p.b.a)a);
      return (b != null) ? a.e(b) : null;
    }
    
    public void onContentChanged() {
      if (this.c)
        a().onContentChanged(); 
    }
    
    public boolean onCreatePanelMenu(int param1Int, Menu param1Menu) {
      return (param1Int == 0 && !(param1Menu instanceof e)) ? false : super.onCreatePanelMenu(param1Int, param1Menu);
    }
    
    public View onCreatePanelView(int param1Int) {
      c.g g1 = this.b;
      if (g1 != null) {
        View view = g1.onCreatePanelView(param1Int);
        if (view != null)
          return view; 
      } 
      return super.onCreatePanelView(param1Int);
    }
    
    public boolean onMenuOpened(int param1Int, Menu param1Menu) {
      super.onMenuOpened(param1Int, param1Menu);
      this.f.K0(param1Int);
      return true;
    }
    
    public void onPanelClosed(int param1Int, Menu param1Menu) {
      if (this.e) {
        a().onPanelClosed(param1Int, param1Menu);
        return;
      } 
      super.onPanelClosed(param1Int, param1Menu);
      this.f.L0(param1Int);
    }
    
    public boolean onPreparePanel(int param1Int, View param1View, Menu param1Menu) {
      e e;
      if (param1Menu instanceof e) {
        e = (e)param1Menu;
      } else {
        e = null;
      } 
      if (param1Int == 0 && e == null)
        return false; 
      boolean bool1 = true;
      if (e != null)
        e.setOverrideVisibleItems(true); 
      c.g g1 = this.b;
      if (g1 == null || !g1.a(param1Int))
        bool1 = false; 
      boolean bool2 = bool1;
      if (!bool1)
        bool2 = super.onPreparePanel(param1Int, param1View, param1Menu); 
      if (e != null)
        e.setOverrideVisibleItems(false); 
      return bool2;
    }
    
    public void onProvideKeyboardShortcuts(List<KeyboardShortcutGroup> param1List, Menu param1Menu, int param1Int) {
      c.u u = this.f.u0(0, true);
      if (u != null) {
        e e = u.j;
        if (e != null) {
          super.onProvideKeyboardShortcuts(param1List, (Menu)e, param1Int);
          return;
        } 
      } 
      super.onProvideKeyboardShortcuts(param1List, param1Menu, param1Int);
    }
    
    public ActionMode onWindowStartingActionMode(ActionMode.Callback param1Callback) {
      return null;
    }
    
    public ActionMode onWindowStartingActionMode(ActionMode.Callback param1Callback, int param1Int) {
      return (!this.f.C0() || param1Int != 0) ? super.onWindowStartingActionMode(param1Callback, param1Int) : f(param1Callback);
    }
  }
  
  class c {}
  
  class c {}
  
  class c {}
  
  class c {}
  
  class c {}
  
  public static final class u {
    public int a;
    
    public int b;
    
    public int c;
    
    public int d;
    
    public int e;
    
    public int f;
    
    public ViewGroup g;
    
    public View h;
    
    public View i;
    
    public e j;
    
    public androidx.appcompat.view.menu.c k;
    
    public Context l;
    
    public boolean m;
    
    public boolean n;
    
    public boolean o;
    
    public boolean p;
    
    public boolean q;
    
    public boolean r;
    
    public Bundle s;
    
    public u(int param1Int) {
      this.a = param1Int;
      this.q = false;
    }
    
    public androidx.appcompat.view.menu.j a(i.a param1a) {
      if (this.j == null)
        return null; 
      if (this.k == null) {
        androidx.appcompat.view.menu.c c1 = new androidx.appcompat.view.menu.c(this.l, g.abc_list_menu_item_layout);
        this.k = c1;
        c1.setCallback(param1a);
        this.j.addMenuPresenter((i)this.k);
      } 
      return this.k.b(this.g);
    }
    
    public boolean b() {
      View view = this.h;
      boolean bool = false;
      if (view == null)
        return false; 
      if (this.i != null)
        return true; 
      if (this.k.a().getCount() > 0)
        bool = true; 
      return bool;
    }
    
    public void c(e param1e) {
      e e1 = this.j;
      if (param1e == e1)
        return; 
      if (e1 != null)
        e1.removeMenuPresenter((i)this.k); 
      this.j = param1e;
      if (param1e != null) {
        androidx.appcompat.view.menu.c c1 = this.k;
        if (c1 != null)
          param1e.addMenuPresenter((i)c1); 
      } 
    }
    
    public void d(Context param1Context) {
      TypedValue typedValue = new TypedValue();
      Resources.Theme theme = param1Context.getResources().newTheme();
      theme.setTo(param1Context.getTheme());
      theme.resolveAttribute(dbxyzptlk.j.a.actionBarPopupTheme, typedValue, true);
      int i = typedValue.resourceId;
      if (i != 0)
        theme.applyStyle(i, true); 
      theme.resolveAttribute(dbxyzptlk.j.a.panelMenuListTheme, typedValue, true);
      i = typedValue.resourceId;
      if (i != 0) {
        theme.applyStyle(i, true);
      } else {
        theme.applyStyle(i.Theme_AppCompat_CompactMenu, true);
      } 
      d d = new d(param1Context, 0);
      d.getTheme().setTo(theme);
      this.l = (Context)d;
      TypedArray typedArray = d.obtainStyledAttributes(dbxyzptlk.j.j.AppCompatTheme);
      this.b = typedArray.getResourceId(dbxyzptlk.j.j.AppCompatTheme_panelBackground, 0);
      this.f = typedArray.getResourceId(dbxyzptlk.j.j.AppCompatTheme_android_windowAnimationStyle, 0);
      typedArray.recycle();
    }
  }
  
  class c {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\appcompat\app\c.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */