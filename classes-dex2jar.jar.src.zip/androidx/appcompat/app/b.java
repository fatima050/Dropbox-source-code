package androidx.appcompat.app;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.window.OnBackInvokedDispatcher;
import androidx.appcompat.widget.Toolbar;
import dbxyzptlk.d2.a;
import dbxyzptlk.d2.j;
import dbxyzptlk.k.a;
import dbxyzptlk.k.c;
import java.lang.ref.WeakReference;
import java.util.Iterator;

public abstract class b {
  public static d$a a = new d$a(new d.b());
  
  public static int b = -100;
  
  public static j c = null;
  
  public static j d = null;
  
  public static Boolean e = null;
  
  public static boolean f = false;
  
  public static final dbxyzptlk.V.b<WeakReference<b>> g = new dbxyzptlk.V.b();
  
  public static final Object h = new Object();
  
  public static final Object i = new Object();
  
  public static void F(b paramb) {
    synchronized (h) {
      G(paramb);
      return;
    } 
  }
  
  public static void G(b paramb) {
    Object object = h;
    /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
    try {
      Iterator<WeakReference<b>> iterator = g.iterator();
      while (iterator.hasNext()) {
        b b1 = ((WeakReference<b>)iterator.next()).get();
        if (b1 == paramb || b1 == null)
          iterator.remove(); 
      } 
    } finally {}
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
  }
  
  public static void L(int paramInt) {
    if (paramInt != -1 && paramInt != 0 && paramInt != 1 && paramInt != 2 && paramInt != 3) {
      Log.d("AppCompatDelegate", "setDefaultNightMode() called with an unknown mode");
    } else if (b != paramInt) {
      b = paramInt;
      e();
    } 
  }
  
  public static void S(Context paramContext) {
    if (!v(paramContext))
      return; 
    if (a.b()) {
      if (!f)
        a.execute((Runnable)new c(paramContext)); 
    } else {
      Object object = i;
      /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
      try {
        j j1 = c;
        if (j1 == null) {
          if (d == null)
            d = j.b(d.b(paramContext)); 
          if (d.f()) {
            /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
            return;
          } 
          c = d;
        } else if (!j1.equals(d)) {
          j1 = c;
          d = j1;
          d.a(paramContext, j1.h());
        } 
      } finally {}
      /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
    } 
  }
  
  public static void b(b paramb) {
    synchronized (h) {
      G(paramb);
      dbxyzptlk.V.b<WeakReference<b>> b1 = g;
      WeakReference weakReference = new WeakReference();
      this((T)paramb);
      b1.add(weakReference);
      return;
    } 
  }
  
  public static void e() {
    Object object = h;
    /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
    try {
      Iterator<WeakReference<b>> iterator = g.iterator();
      while (iterator.hasNext()) {
        b b1 = ((WeakReference<b>)iterator.next()).get();
        if (b1 != null)
          b1.d(); 
      } 
    } finally {
      Exception exception;
    } 
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
  }
  
  public static b h(Activity paramActivity, dbxyzptlk.k.b paramb) {
    return new c(paramActivity, paramb);
  }
  
  public static b i(Dialog paramDialog, dbxyzptlk.k.b paramb) {
    return new c(paramDialog, paramb);
  }
  
  public static j k() {
    if (a.b()) {
      Object object = p();
      if (object != null)
        return j.j(b.a(object)); 
    } else {
      j j1 = c;
      if (j1 != null)
        return j1; 
    } 
    return j.e();
  }
  
  public static int m() {
    return b;
  }
  
  public static Object p() {
    Iterator<WeakReference<b>> iterator = g.iterator();
    while (iterator.hasNext()) {
      b b1 = ((WeakReference<b>)iterator.next()).get();
      if (b1 != null) {
        Context context = b1.l();
        if (context != null)
          return context.getSystemService("locale"); 
      } 
    } 
    return null;
  }
  
  public static j r() {
    return c;
  }
  
  public static boolean v(Context paramContext) {
    if (e == null)
      try {
        Bundle bundle = (AppLocalesMetadataHolderService.a(paramContext)).metaData;
        if (bundle != null)
          e = Boolean.valueOf(bundle.getBoolean("autoStoreLocales")); 
      } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
        Log.d("AppCompatDelegate", "Checking for metadata for AppLocalesMetadataHolderService : Service not found");
        e = Boolean.FALSE;
      }  
    return e.booleanValue();
  }
  
  public abstract void A(Bundle paramBundle);
  
  public abstract void B();
  
  public abstract void C(Bundle paramBundle);
  
  public abstract void D();
  
  public abstract void E();
  
  public abstract boolean H(int paramInt);
  
  public abstract void I(int paramInt);
  
  public abstract void J(View paramView);
  
  public abstract void K(View paramView, ViewGroup.LayoutParams paramLayoutParams);
  
  public abstract void M(int paramInt);
  
  public void N(OnBackInvokedDispatcher paramOnBackInvokedDispatcher) {}
  
  public abstract void O(Toolbar paramToolbar);
  
  public void P(int paramInt) {}
  
  public abstract void Q(CharSequence paramCharSequence);
  
  public abstract dbxyzptlk.p.b R(dbxyzptlk.p.b.a parama);
  
  public abstract void c(View paramView, ViewGroup.LayoutParams paramLayoutParams);
  
  public abstract boolean d();
  
  @Deprecated
  public void f(Context paramContext) {}
  
  public Context g(Context paramContext) {
    f(paramContext);
    return paramContext;
  }
  
  public abstract <T extends View> T j(int paramInt);
  
  public Context l() {
    return null;
  }
  
  public abstract a n();
  
  public int o() {
    return -100;
  }
  
  public abstract MenuInflater q();
  
  public abstract ActionBar s();
  
  public abstract void t();
  
  public abstract void u();
  
  public abstract void x(Configuration paramConfiguration);
  
  public abstract void y(Bundle paramBundle);
  
  public abstract void z();
  
  class b {}
  
  class b {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\appcompat\app\b.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */