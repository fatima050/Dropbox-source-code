package androidx.appcompat.app;

import android.content.Context;
import android.content.DialogInterface;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.database.Cursor;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewStub;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import androidx.core.widget.NestedScrollView;
import dbxyzptlk.h2.h0;
import dbxyzptlk.j.f;
import dbxyzptlk.j.j;
import dbxyzptlk.k.k;
import java.lang.ref.WeakReference;

public class AlertController {
  public NestedScrollView A;
  
  public int B = 0;
  
  public Drawable C;
  
  public ImageView D;
  
  public TextView E;
  
  public TextView F;
  
  public View G;
  
  public ListAdapter H;
  
  public int I = -1;
  
  public int J;
  
  public int K;
  
  public int L;
  
  public int M;
  
  public int N;
  
  public int O;
  
  public boolean P;
  
  public int Q = 0;
  
  public Handler R;
  
  public final View.OnClickListener S = new a(this);
  
  public final Context a;
  
  public final k b;
  
  public final Window c;
  
  public final int d;
  
  public CharSequence e;
  
  public CharSequence f;
  
  public ListView g;
  
  public View h;
  
  public int i;
  
  public int j;
  
  public int k;
  
  public int l;
  
  public int m;
  
  public boolean n = false;
  
  public Button o;
  
  public CharSequence p;
  
  public Message q;
  
  public Drawable r;
  
  public Button s;
  
  public CharSequence t;
  
  public Message u;
  
  public Drawable v;
  
  public Button w;
  
  public CharSequence x;
  
  public Message y;
  
  public Drawable z;
  
  public AlertController(Context paramContext, k paramk, Window paramWindow) {
    this.a = paramContext;
    this.b = paramk;
    this.c = paramWindow;
    this.R = new c((DialogInterface)paramk);
    TypedArray typedArray = paramContext.obtainStyledAttributes(null, j.AlertDialog, dbxyzptlk.j.a.alertDialogStyle, 0);
    this.J = typedArray.getResourceId(j.AlertDialog_android_layout, 0);
    this.K = typedArray.getResourceId(j.AlertDialog_buttonPanelSideLayout, 0);
    this.L = typedArray.getResourceId(j.AlertDialog_listLayout, 0);
    this.M = typedArray.getResourceId(j.AlertDialog_multiChoiceItemLayout, 0);
    this.N = typedArray.getResourceId(j.AlertDialog_singleChoiceItemLayout, 0);
    this.O = typedArray.getResourceId(j.AlertDialog_listItemLayout, 0);
    this.P = typedArray.getBoolean(j.AlertDialog_showTitle, true);
    this.d = typedArray.getDimensionPixelSize(j.AlertDialog_buttonIconDimen, 0);
    typedArray.recycle();
    paramk.supportRequestWindowFeature(1);
  }
  
  public static boolean A(Context paramContext) {
    TypedValue typedValue = new TypedValue();
    Resources.Theme theme = paramContext.getTheme();
    int i = dbxyzptlk.j.a.alertDialogCenterButtons;
    boolean bool = true;
    theme.resolveAttribute(i, typedValue, true);
    if (typedValue.data == 0)
      bool = false; 
    return bool;
  }
  
  public static boolean a(View paramView) {
    if (paramView.onCheckIsTextEditor())
      return true; 
    if (!(paramView instanceof ViewGroup))
      return false; 
    ViewGroup viewGroup = (ViewGroup)paramView;
    int i = viewGroup.getChildCount();
    while (i > 0) {
      int j = i - 1;
      i = j;
      if (a(viewGroup.getChildAt(j)))
        return true; 
    } 
    return false;
  }
  
  public final void b(Button paramButton) {
    LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams)paramButton.getLayoutParams();
    layoutParams.gravity = 1;
    layoutParams.weight = 0.5F;
    paramButton.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
  }
  
  public Button c(int paramInt) {
    return (paramInt != -3) ? ((paramInt != -2) ? ((paramInt != -1) ? null : this.o) : this.s) : this.w;
  }
  
  public int d(int paramInt) {
    TypedValue typedValue = new TypedValue();
    this.a.getTheme().resolveAttribute(paramInt, typedValue, true);
    return typedValue.resourceId;
  }
  
  public ListView e() {
    return this.g;
  }
  
  public void f() {
    int i = j();
    this.b.setContentView(i);
    z();
  }
  
  public boolean g(int paramInt, KeyEvent paramKeyEvent) {
    boolean bool;
    NestedScrollView nestedScrollView = this.A;
    if (nestedScrollView != null && nestedScrollView.n(paramKeyEvent)) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public boolean h(int paramInt, KeyEvent paramKeyEvent) {
    boolean bool;
    NestedScrollView nestedScrollView = this.A;
    if (nestedScrollView != null && nestedScrollView.n(paramKeyEvent)) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public final ViewGroup i(View paramView1, View paramView2) {
    if (paramView1 == null) {
      paramView1 = paramView2;
      if (paramView2 instanceof ViewStub)
        paramView1 = ((ViewStub)paramView2).inflate(); 
      return (ViewGroup)paramView1;
    } 
    if (paramView2 != null) {
      ViewParent viewParent = paramView2.getParent();
      if (viewParent instanceof ViewGroup)
        ((ViewGroup)viewParent).removeView(paramView2); 
    } 
    paramView2 = paramView1;
    if (paramView1 instanceof ViewStub)
      paramView2 = ((ViewStub)paramView1).inflate(); 
    return (ViewGroup)paramView2;
  }
  
  public final int j() {
    int i = this.K;
    return (i == 0) ? this.J : ((this.Q == 1) ? i : this.J);
  }
  
  public void k(int paramInt, CharSequence paramCharSequence, DialogInterface.OnClickListener paramOnClickListener, Message paramMessage, Drawable paramDrawable) {
    Message message = paramMessage;
    if (paramMessage == null) {
      message = paramMessage;
      if (paramOnClickListener != null)
        message = this.R.obtainMessage(paramInt, paramOnClickListener); 
    } 
    if (paramInt != -3) {
      if (paramInt != -2) {
        if (paramInt == -1) {
          this.p = paramCharSequence;
          this.q = message;
          this.r = paramDrawable;
        } else {
          throw new IllegalArgumentException("Button does not exist");
        } 
      } else {
        this.t = paramCharSequence;
        this.u = message;
        this.v = paramDrawable;
      } 
    } else {
      this.x = paramCharSequence;
      this.y = message;
      this.z = paramDrawable;
    } 
  }
  
  public void l(int paramInt) {
    this.Q = paramInt;
  }
  
  public void m(View paramView) {
    this.G = paramView;
  }
  
  public void n(int paramInt) {
    this.C = null;
    this.B = paramInt;
    ImageView imageView = this.D;
    if (imageView != null)
      if (paramInt != 0) {
        imageView.setVisibility(0);
        this.D.setImageResource(this.B);
      } else {
        imageView.setVisibility(8);
      }  
  }
  
  public void o(Drawable paramDrawable) {
    this.C = paramDrawable;
    this.B = 0;
    ImageView imageView = this.D;
    if (imageView != null)
      if (paramDrawable != null) {
        imageView.setVisibility(0);
        this.D.setImageDrawable(paramDrawable);
      } else {
        imageView.setVisibility(8);
      }  
  }
  
  public void p(CharSequence paramCharSequence) {
    this.f = paramCharSequence;
    TextView textView = this.F;
    if (textView != null)
      textView.setText(paramCharSequence); 
  }
  
  public final void q(ViewGroup paramViewGroup, View paramView, int paramInt1, int paramInt2) {
    View view2 = this.c.findViewById(f.scrollIndicatorUp);
    View view1 = this.c.findViewById(f.scrollIndicatorDown);
    h0.L0(paramView, paramInt1, paramInt2);
    if (view2 != null)
      paramViewGroup.removeView(view2); 
    if (view1 != null)
      paramViewGroup.removeView(view1); 
  }
  
  public void r(CharSequence paramCharSequence) {
    this.e = paramCharSequence;
    TextView textView = this.E;
    if (textView != null)
      textView.setText(paramCharSequence); 
  }
  
  public void s(int paramInt) {
    this.h = null;
    this.i = paramInt;
    this.n = false;
  }
  
  public void t(View paramView) {
    this.h = paramView;
    this.i = 0;
    this.n = false;
  }
  
  public void u(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this.h = paramView;
    this.i = 0;
    this.n = true;
    this.j = paramInt1;
    this.k = paramInt2;
    this.l = paramInt3;
    this.m = paramInt4;
  }
  
  public final void v(ViewGroup paramViewGroup) {
    int i;
    Button button = (Button)paramViewGroup.findViewById(16908313);
    this.o = button;
    button.setOnClickListener(this.S);
    if (TextUtils.isEmpty(this.p) && this.r == null) {
      this.o.setVisibility(8);
      i = 0;
    } else {
      this.o.setText(this.p);
      Drawable drawable = this.r;
      if (drawable != null) {
        int j = this.d;
        drawable.setBounds(0, 0, j, j);
        this.o.setCompoundDrawables(this.r, null, null, null);
      } 
      this.o.setVisibility(0);
      i = 1;
    } 
    button = (Button)paramViewGroup.findViewById(16908314);
    this.s = button;
    button.setOnClickListener(this.S);
    if (TextUtils.isEmpty(this.t) && this.v == null) {
      this.s.setVisibility(8);
    } else {
      this.s.setText(this.t);
      Drawable drawable = this.v;
      if (drawable != null) {
        int j = this.d;
        drawable.setBounds(0, 0, j, j);
        this.s.setCompoundDrawables(this.v, null, null, null);
      } 
      this.s.setVisibility(0);
      i |= 0x2;
    } 
    button = (Button)paramViewGroup.findViewById(16908315);
    this.w = button;
    button.setOnClickListener(this.S);
    if (TextUtils.isEmpty(this.x) && this.z == null) {
      this.w.setVisibility(8);
    } else {
      this.w.setText(this.x);
      Drawable drawable = this.z;
      if (drawable != null) {
        int j = this.d;
        drawable.setBounds(0, 0, j, j);
        this.w.setCompoundDrawables(this.z, null, null, null);
      } 
      this.w.setVisibility(0);
      i |= 0x4;
    } 
    if (A(this.a))
      if (i == 1) {
        b(this.o);
      } else if (i == 2) {
        b(this.s);
      } else if (i == 4) {
        b(this.w);
      }  
    if (i == 0)
      paramViewGroup.setVisibility(8); 
  }
  
  public final void w(ViewGroup paramViewGroup) {
    NestedScrollView nestedScrollView = (NestedScrollView)this.c.findViewById(f.scrollView);
    this.A = nestedScrollView;
    nestedScrollView.setFocusable(false);
    this.A.setNestedScrollingEnabled(false);
    TextView textView = (TextView)paramViewGroup.findViewById(16908299);
    this.F = textView;
    if (textView == null)
      return; 
    CharSequence charSequence = this.f;
    if (charSequence != null) {
      textView.setText(charSequence);
    } else {
      textView.setVisibility(8);
      this.A.removeView((View)this.F);
      if (this.g != null) {
        paramViewGroup = (ViewGroup)this.A.getParent();
        int i = paramViewGroup.indexOfChild((View)this.A);
        paramViewGroup.removeViewAt(i);
        paramViewGroup.addView((View)this.g, i, new ViewGroup.LayoutParams(-1, -1));
      } else {
        paramViewGroup.setVisibility(8);
      } 
    } 
  }
  
  public final void x(ViewGroup paramViewGroup) {
    View view = this.h;
    boolean bool = false;
    if (view == null)
      if (this.i != 0) {
        view = LayoutInflater.from(this.a).inflate(this.i, paramViewGroup, false);
      } else {
        view = null;
      }  
    if (view != null)
      bool = true; 
    if (!bool || !a(view))
      this.c.setFlags(131072, 131072); 
    if (bool) {
      FrameLayout frameLayout = (FrameLayout)this.c.findViewById(f.custom);
      frameLayout.addView(view, new ViewGroup.LayoutParams(-1, -1));
      if (this.n)
        frameLayout.setPadding(this.j, this.k, this.l, this.m); 
      if (this.g != null)
        ((LinearLayout.LayoutParams)paramViewGroup.getLayoutParams()).weight = 0.0F; 
    } else {
      paramViewGroup.setVisibility(8);
    } 
  }
  
  public final void y(ViewGroup paramViewGroup) {
    if (this.G != null) {
      ViewGroup.LayoutParams layoutParams = new ViewGroup.LayoutParams(-1, -2);
      paramViewGroup.addView(this.G, 0, layoutParams);
      this.c.findViewById(f.title_template).setVisibility(8);
    } else {
      Drawable drawable;
      this.D = (ImageView)this.c.findViewById(16908294);
      if (!TextUtils.isEmpty(this.e) && this.P) {
        TextView textView = (TextView)this.c.findViewById(f.alertTitle);
        this.E = textView;
        textView.setText(this.e);
        int i = this.B;
        if (i != 0) {
          this.D.setImageResource(i);
        } else {
          drawable = this.C;
          if (drawable != null) {
            this.D.setImageDrawable(drawable);
          } else {
            this.E.setPadding(this.D.getPaddingLeft(), this.D.getPaddingTop(), this.D.getPaddingRight(), this.D.getPaddingBottom());
            this.D.setVisibility(8);
          } 
        } 
      } else {
        this.c.findViewById(f.title_template).setVisibility(8);
        this.D.setVisibility(8);
        drawable.setVisibility(8);
      } 
    } 
  }
  
  public final void z() {
    int j;
    boolean bool2;
    View view4 = this.c.findViewById(f.parentPanel);
    View view3 = view4.findViewById(f.topPanel);
    View view2 = view4.findViewById(f.contentPanel);
    View view1 = view4.findViewById(f.buttonPanel);
    ViewGroup viewGroup4 = (ViewGroup)view4.findViewById(f.customPanel);
    x(viewGroup4);
    View view7 = viewGroup4.findViewById(f.topPanel);
    View view6 = viewGroup4.findViewById(f.contentPanel);
    View view5 = viewGroup4.findViewById(f.buttonPanel);
    ViewGroup viewGroup3 = i(view7, view3);
    ViewGroup viewGroup2 = i(view6, view2);
    ViewGroup viewGroup1 = i(view5, view1);
    w(viewGroup2);
    v(viewGroup1);
    y(viewGroup3);
    int i = viewGroup4.getVisibility();
    boolean bool1 = false;
    if (i != 8) {
      i = 1;
    } else {
      i = 0;
    } 
    if (viewGroup3 != null && viewGroup3.getVisibility() != 8) {
      j = 1;
    } else {
      j = 0;
    } 
    if (viewGroup1 != null && viewGroup1.getVisibility() != 8) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    if (!bool2 && viewGroup2 != null) {
      View view = viewGroup2.findViewById(f.textSpacerNoButtons);
      if (view != null)
        view.setVisibility(0); 
    } 
    if (j) {
      NestedScrollView nestedScrollView = this.A;
      if (nestedScrollView != null)
        nestedScrollView.setClipToPadding(true); 
      if (this.f != null || this.g != null) {
        View view = viewGroup3.findViewById(f.titleDividerNoCustom);
      } else {
        nestedScrollView = null;
      } 
      if (nestedScrollView != null)
        nestedScrollView.setVisibility(0); 
    } else if (viewGroup2 != null) {
      View view = viewGroup2.findViewById(f.textSpacerNoTitle);
      if (view != null)
        view.setVisibility(0); 
    } 
    ListView listView1 = this.g;
    if (listView1 instanceof RecycleListView)
      ((RecycleListView)listView1).setHasDecor(j, bool2); 
    if (i == 0) {
      NestedScrollView nestedScrollView;
      listView1 = this.g;
      if (listView1 == null)
        nestedScrollView = this.A; 
      if (nestedScrollView != null) {
        i = bool1;
        if (bool2)
          i = 2; 
        q(viewGroup2, (View)nestedScrollView, j | i, 3);
      } 
    } 
    ListView listView2 = this.g;
    if (listView2 != null) {
      ListAdapter listAdapter = this.H;
      if (listAdapter != null) {
        listView2.setAdapter(listAdapter);
        i = this.I;
        if (i > -1) {
          listView2.setItemChecked(i, true);
          listView2.setSelection(i);
        } 
      } 
    } 
  }
  
  public static class RecycleListView extends ListView {
    public final int a;
    
    public final int b;
    
    public RecycleListView(Context param1Context) {
      this(param1Context, null);
    }
    
    public RecycleListView(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
      TypedArray typedArray = param1Context.obtainStyledAttributes(param1AttributeSet, j.RecycleListView);
      this.b = typedArray.getDimensionPixelOffset(j.RecycleListView_paddingBottomNoButtons, -1);
      this.a = typedArray.getDimensionPixelOffset(j.RecycleListView_paddingTopNoTitle, -1);
    }
    
    public void setHasDecor(boolean param1Boolean1, boolean param1Boolean2) {
      if (!param1Boolean2 || !param1Boolean1) {
        int i;
        int j;
        int k = getPaddingLeft();
        if (param1Boolean1) {
          i = getPaddingTop();
        } else {
          i = this.a;
        } 
        int m = getPaddingRight();
        if (param1Boolean2) {
          j = getPaddingBottom();
        } else {
          j = this.b;
        } 
        setPadding(k, i, m, j);
      } 
    }
  }
  
  public class a implements View.OnClickListener {
    public final AlertController a;
    
    public a(AlertController this$0) {}
    
    public void onClick(View param1View) {
      // Byte code:
      //   0: aload_0
      //   1: getfield a : Landroidx/appcompat/app/AlertController;
      //   4: astore_2
      //   5: aload_1
      //   6: aload_2
      //   7: getfield o : Landroid/widget/Button;
      //   10: if_acmpne -> 30
      //   13: aload_2
      //   14: getfield q : Landroid/os/Message;
      //   17: astore_3
      //   18: aload_3
      //   19: ifnull -> 30
      //   22: aload_3
      //   23: invokestatic obtain : (Landroid/os/Message;)Landroid/os/Message;
      //   26: astore_1
      //   27: goto -> 82
      //   30: aload_1
      //   31: aload_2
      //   32: getfield s : Landroid/widget/Button;
      //   35: if_acmpne -> 55
      //   38: aload_2
      //   39: getfield u : Landroid/os/Message;
      //   42: astore_3
      //   43: aload_3
      //   44: ifnull -> 55
      //   47: aload_3
      //   48: invokestatic obtain : (Landroid/os/Message;)Landroid/os/Message;
      //   51: astore_1
      //   52: goto -> 82
      //   55: aload_1
      //   56: aload_2
      //   57: getfield w : Landroid/widget/Button;
      //   60: if_acmpne -> 80
      //   63: aload_2
      //   64: getfield y : Landroid/os/Message;
      //   67: astore_1
      //   68: aload_1
      //   69: ifnull -> 80
      //   72: aload_1
      //   73: invokestatic obtain : (Landroid/os/Message;)Landroid/os/Message;
      //   76: astore_1
      //   77: goto -> 82
      //   80: aconst_null
      //   81: astore_1
      //   82: aload_1
      //   83: ifnull -> 90
      //   86: aload_1
      //   87: invokevirtual sendToTarget : ()V
      //   90: aload_0
      //   91: getfield a : Landroidx/appcompat/app/AlertController;
      //   94: astore_1
      //   95: aload_1
      //   96: getfield R : Landroid/os/Handler;
      //   99: iconst_1
      //   100: aload_1
      //   101: getfield b : Ldbxyzptlk/k/k;
      //   104: invokevirtual obtainMessage : (ILjava/lang/Object;)Landroid/os/Message;
      //   107: invokevirtual sendToTarget : ()V
      //   110: return
    }
  }
  
  public static class b {
    public int A;
    
    public int B;
    
    public int C;
    
    public int D;
    
    public boolean E = false;
    
    public boolean[] F;
    
    public boolean G;
    
    public boolean H;
    
    public int I = -1;
    
    public DialogInterface.OnMultiChoiceClickListener J;
    
    public Cursor K;
    
    public String L;
    
    public String M;
    
    public boolean N;
    
    public AdapterView.OnItemSelectedListener O;
    
    public boolean P = true;
    
    public final Context a;
    
    public final LayoutInflater b;
    
    public int c = 0;
    
    public Drawable d;
    
    public int e = 0;
    
    public CharSequence f;
    
    public View g;
    
    public CharSequence h;
    
    public CharSequence i;
    
    public Drawable j;
    
    public DialogInterface.OnClickListener k;
    
    public CharSequence l;
    
    public Drawable m;
    
    public DialogInterface.OnClickListener n;
    
    public CharSequence o;
    
    public Drawable p;
    
    public DialogInterface.OnClickListener q;
    
    public boolean r;
    
    public DialogInterface.OnCancelListener s;
    
    public DialogInterface.OnDismissListener t;
    
    public DialogInterface.OnKeyListener u;
    
    public CharSequence[] v;
    
    public ListAdapter w;
    
    public DialogInterface.OnClickListener x;
    
    public int y;
    
    public View z;
    
    public b(Context param1Context) {
      this.a = param1Context;
      this.r = true;
      this.b = (LayoutInflater)param1Context.getSystemService("layout_inflater");
    }
    
    public void a(AlertController param1AlertController) {
      View view2 = this.g;
      if (view2 != null) {
        param1AlertController.m(view2);
      } else {
        CharSequence charSequence1 = this.f;
        if (charSequence1 != null)
          param1AlertController.r(charSequence1); 
        Drawable drawable = this.d;
        if (drawable != null)
          param1AlertController.o(drawable); 
        int i = this.c;
        if (i != 0)
          param1AlertController.n(i); 
        i = this.e;
        if (i != 0)
          param1AlertController.n(param1AlertController.d(i)); 
      } 
      CharSequence charSequence = this.h;
      if (charSequence != null)
        param1AlertController.p(charSequence); 
      charSequence = this.i;
      if (charSequence != null || this.j != null)
        param1AlertController.k(-1, charSequence, this.k, null, this.j); 
      charSequence = this.l;
      if (charSequence != null || this.m != null)
        param1AlertController.k(-2, charSequence, this.n, null, this.m); 
      charSequence = this.o;
      if (charSequence != null || this.p != null)
        param1AlertController.k(-3, charSequence, this.q, null, this.p); 
      if (this.v != null || this.K != null || this.w != null)
        b(param1AlertController); 
      View view1 = this.z;
      if (view1 != null) {
        if (this.E) {
          param1AlertController.u(view1, this.A, this.B, this.C, this.D);
        } else {
          param1AlertController.t(view1);
        } 
      } else {
        int i = this.y;
        if (i != 0)
          param1AlertController.s(i); 
      } 
    }
    
    public final void b(AlertController param1AlertController) {
      AlertController.d d;
      AlertController.RecycleListView recycleListView = (AlertController.RecycleListView)this.b.inflate(param1AlertController.L, null);
      if (this.G) {
        if (this.K == null) {
          a a = new a(this, this.a, param1AlertController.M, 16908308, this.v, recycleListView);
        } else {
          b b1 = new b(this, this.a, this.K, false, recycleListView, param1AlertController);
        } 
      } else {
        int i;
        if (this.H) {
          i = param1AlertController.N;
        } else {
          i = param1AlertController.O;
        } 
        if (this.K != null) {
          SimpleCursorAdapter simpleCursorAdapter = new SimpleCursorAdapter(this.a, i, this.K, new String[] { this.L }, new int[] { 16908308 });
        } else {
          ListAdapter listAdapter = this.w;
          if (listAdapter == null)
            d = new AlertController.d(this.a, i, 16908308, this.v); 
        } 
      } 
      param1AlertController.H = (ListAdapter)d;
      param1AlertController.I = this.I;
      if (this.x != null) {
        recycleListView.setOnItemClickListener((AdapterView.OnItemClickListener)new c(this, param1AlertController));
      } else if (this.J != null) {
        recycleListView.setOnItemClickListener((AdapterView.OnItemClickListener)new d(this, recycleListView, param1AlertController));
      } 
      AdapterView.OnItemSelectedListener onItemSelectedListener = this.O;
      if (onItemSelectedListener != null)
        recycleListView.setOnItemSelectedListener(onItemSelectedListener); 
      if (this.H) {
        recycleListView.setChoiceMode(1);
      } else if (this.G) {
        recycleListView.setChoiceMode(2);
      } 
      param1AlertController.g = recycleListView;
    }
  }
  
  public static final class c extends Handler {
    public WeakReference<DialogInterface> a;
    
    public c(DialogInterface param1DialogInterface) {
      this.a = new WeakReference<>(param1DialogInterface);
    }
    
    public void handleMessage(Message param1Message) {
      int i = param1Message.what;
      if (i != -3 && i != -2 && i != -1) {
        if (i == 1)
          ((DialogInterface)param1Message.obj).dismiss(); 
      } else {
        ((DialogInterface.OnClickListener)param1Message.obj).onClick(this.a.get(), param1Message.what);
      } 
    }
  }
  
  class AlertController {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\appcompat\app\AlertController.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */