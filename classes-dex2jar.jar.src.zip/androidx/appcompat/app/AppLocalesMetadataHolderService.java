package androidx.appcompat.app;

import android.app.Service;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.os.IBinder;

public final class AppLocalesMetadataHolderService extends Service {
  public static ServiceInfo a(Context paramContext) throws PackageManager.NameNotFoundException {
    int i = a.a();
    return paramContext.getPackageManager().getServiceInfo(new ComponentName(paramContext, AppLocalesMetadataHolderService.class), i | 0x80);
  }
  
  public IBinder onBind(Intent paramIntent) {
    throw new UnsupportedOperationException();
  }
  
  public static class a {
    public static int a() {
      return 512;
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\appcompat\app\AppLocalesMetadataHolderService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */