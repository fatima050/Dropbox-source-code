package androidx.appcompat.app;

import android.content.Context;
import android.content.DialogInterface;
import android.database.Cursor;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Message;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.KeyEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import dbxyzptlk.k.k;

public class a extends k implements DialogInterface {
  static final int LAYOUT_HINT_NONE = 0;
  
  static final int LAYOUT_HINT_SIDE = 1;
  
  final AlertController mAlert = new AlertController(getContext(), this, getWindow());
  
  public a(Context paramContext) {
    this(paramContext, 0);
  }
  
  public a(Context paramContext, int paramInt) {
    super(paramContext, resolveDialogTheme(paramContext, paramInt));
  }
  
  public a(Context paramContext, boolean paramBoolean, DialogInterface.OnCancelListener paramOnCancelListener) {
    this(paramContext, 0);
    setCancelable(paramBoolean);
    setOnCancelListener(paramOnCancelListener);
  }
  
  public static int resolveDialogTheme(Context paramContext, int paramInt) {
    if ((paramInt >>> 24 & 0xFF) >= 1)
      return paramInt; 
    TypedValue typedValue = new TypedValue();
    paramContext.getTheme().resolveAttribute(dbxyzptlk.j.a.alertDialogTheme, typedValue, true);
    return typedValue.resourceId;
  }
  
  public Button getButton(int paramInt) {
    return this.mAlert.c(paramInt);
  }
  
  public ListView getListView() {
    return this.mAlert.e();
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    this.mAlert.f();
  }
  
  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent) {
    return this.mAlert.g(paramInt, paramKeyEvent) ? true : super.onKeyDown(paramInt, paramKeyEvent);
  }
  
  public boolean onKeyUp(int paramInt, KeyEvent paramKeyEvent) {
    return this.mAlert.h(paramInt, paramKeyEvent) ? true : super.onKeyUp(paramInt, paramKeyEvent);
  }
  
  public void setButton(int paramInt, CharSequence paramCharSequence, DialogInterface.OnClickListener paramOnClickListener) {
    this.mAlert.k(paramInt, paramCharSequence, paramOnClickListener, null, null);
  }
  
  public void setButton(int paramInt, CharSequence paramCharSequence, Drawable paramDrawable, DialogInterface.OnClickListener paramOnClickListener) {
    this.mAlert.k(paramInt, paramCharSequence, paramOnClickListener, null, paramDrawable);
  }
  
  public void setButton(int paramInt, CharSequence paramCharSequence, Message paramMessage) {
    this.mAlert.k(paramInt, paramCharSequence, null, paramMessage, null);
  }
  
  public void setButtonPanelLayoutHint(int paramInt) {
    this.mAlert.l(paramInt);
  }
  
  public void setCustomTitle(View paramView) {
    this.mAlert.m(paramView);
  }
  
  public void setIcon(int paramInt) {
    this.mAlert.n(paramInt);
  }
  
  public void setIcon(Drawable paramDrawable) {
    this.mAlert.o(paramDrawable);
  }
  
  public void setIconAttribute(int paramInt) {
    TypedValue typedValue = new TypedValue();
    getContext().getTheme().resolveAttribute(paramInt, typedValue, true);
    this.mAlert.n(typedValue.resourceId);
  }
  
  public void setMessage(CharSequence paramCharSequence) {
    this.mAlert.p(paramCharSequence);
  }
  
  public void setTitle(CharSequence paramCharSequence) {
    super.setTitle(paramCharSequence);
    this.mAlert.r(paramCharSequence);
  }
  
  public void setView(View paramView) {
    this.mAlert.t(paramView);
  }
  
  public void setView(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this.mAlert.u(paramView, paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public static class a {
    private final AlertController.b P;
    
    private final int mTheme;
    
    public a(Context param1Context) {
      this(param1Context, a.resolveDialogTheme(param1Context, 0));
    }
    
    public a(Context param1Context, int param1Int) {
      this.P = new AlertController.b((Context)new ContextThemeWrapper(param1Context, a.resolveDialogTheme(param1Context, param1Int)));
      this.mTheme = param1Int;
    }
    
    public a create() {
      a a1 = new a(this.P.a, this.mTheme);
      this.P.a(a1.mAlert);
      a1.setCancelable(this.P.r);
      if (this.P.r)
        a1.setCanceledOnTouchOutside(true); 
      a1.setOnCancelListener(this.P.s);
      a1.setOnDismissListener(this.P.t);
      DialogInterface.OnKeyListener onKeyListener = this.P.u;
      if (onKeyListener != null)
        a1.setOnKeyListener(onKeyListener); 
      return a1;
    }
    
    public Context getContext() {
      return this.P.a;
    }
    
    public a setAdapter(ListAdapter param1ListAdapter, DialogInterface.OnClickListener param1OnClickListener) {
      AlertController.b b1 = this.P;
      b1.w = param1ListAdapter;
      b1.x = param1OnClickListener;
      return this;
    }
    
    public a setCancelable(boolean param1Boolean) {
      this.P.r = param1Boolean;
      return this;
    }
    
    public a setCursor(Cursor param1Cursor, DialogInterface.OnClickListener param1OnClickListener, String param1String) {
      AlertController.b b1 = this.P;
      b1.K = param1Cursor;
      b1.L = param1String;
      b1.x = param1OnClickListener;
      return this;
    }
    
    public a setCustomTitle(View param1View) {
      this.P.g = param1View;
      return this;
    }
    
    public a setIcon(int param1Int) {
      this.P.c = param1Int;
      return this;
    }
    
    public a setIcon(Drawable param1Drawable) {
      this.P.d = param1Drawable;
      return this;
    }
    
    public a setIconAttribute(int param1Int) {
      TypedValue typedValue = new TypedValue();
      this.P.a.getTheme().resolveAttribute(param1Int, typedValue, true);
      this.P.c = typedValue.resourceId;
      return this;
    }
    
    @Deprecated
    public a setInverseBackgroundForced(boolean param1Boolean) {
      this.P.N = param1Boolean;
      return this;
    }
    
    public a setItems(int param1Int, DialogInterface.OnClickListener param1OnClickListener) {
      AlertController.b b1 = this.P;
      b1.v = b1.a.getResources().getTextArray(param1Int);
      this.P.x = param1OnClickListener;
      return this;
    }
    
    public a setItems(CharSequence[] param1ArrayOfCharSequence, DialogInterface.OnClickListener param1OnClickListener) {
      AlertController.b b1 = this.P;
      b1.v = param1ArrayOfCharSequence;
      b1.x = param1OnClickListener;
      return this;
    }
    
    public a setMessage(int param1Int) {
      AlertController.b b1 = this.P;
      b1.h = b1.a.getText(param1Int);
      return this;
    }
    
    public a setMessage(CharSequence param1CharSequence) {
      this.P.h = param1CharSequence;
      return this;
    }
    
    public a setMultiChoiceItems(int param1Int, boolean[] param1ArrayOfboolean, DialogInterface.OnMultiChoiceClickListener param1OnMultiChoiceClickListener) {
      AlertController.b b1 = this.P;
      b1.v = b1.a.getResources().getTextArray(param1Int);
      b1 = this.P;
      b1.J = param1OnMultiChoiceClickListener;
      b1.F = param1ArrayOfboolean;
      b1.G = true;
      return this;
    }
    
    public a setMultiChoiceItems(Cursor param1Cursor, String param1String1, String param1String2, DialogInterface.OnMultiChoiceClickListener param1OnMultiChoiceClickListener) {
      AlertController.b b1 = this.P;
      b1.K = param1Cursor;
      b1.J = param1OnMultiChoiceClickListener;
      b1.M = param1String1;
      b1.L = param1String2;
      b1.G = true;
      return this;
    }
    
    public a setMultiChoiceItems(CharSequence[] param1ArrayOfCharSequence, boolean[] param1ArrayOfboolean, DialogInterface.OnMultiChoiceClickListener param1OnMultiChoiceClickListener) {
      AlertController.b b1 = this.P;
      b1.v = param1ArrayOfCharSequence;
      b1.J = param1OnMultiChoiceClickListener;
      b1.F = param1ArrayOfboolean;
      b1.G = true;
      return this;
    }
    
    public a setNegativeButton(int param1Int, DialogInterface.OnClickListener param1OnClickListener) {
      AlertController.b b1 = this.P;
      b1.l = b1.a.getText(param1Int);
      this.P.n = param1OnClickListener;
      return this;
    }
    
    public a setNegativeButton(CharSequence param1CharSequence, DialogInterface.OnClickListener param1OnClickListener) {
      AlertController.b b1 = this.P;
      b1.l = param1CharSequence;
      b1.n = param1OnClickListener;
      return this;
    }
    
    public a setNegativeButtonIcon(Drawable param1Drawable) {
      this.P.m = param1Drawable;
      return this;
    }
    
    public a setNeutralButton(int param1Int, DialogInterface.OnClickListener param1OnClickListener) {
      AlertController.b b1 = this.P;
      b1.o = b1.a.getText(param1Int);
      this.P.q = param1OnClickListener;
      return this;
    }
    
    public a setNeutralButton(CharSequence param1CharSequence, DialogInterface.OnClickListener param1OnClickListener) {
      AlertController.b b1 = this.P;
      b1.o = param1CharSequence;
      b1.q = param1OnClickListener;
      return this;
    }
    
    public a setNeutralButtonIcon(Drawable param1Drawable) {
      this.P.p = param1Drawable;
      return this;
    }
    
    public a setOnCancelListener(DialogInterface.OnCancelListener param1OnCancelListener) {
      this.P.s = param1OnCancelListener;
      return this;
    }
    
    public a setOnDismissListener(DialogInterface.OnDismissListener param1OnDismissListener) {
      this.P.t = param1OnDismissListener;
      return this;
    }
    
    public a setOnItemSelectedListener(AdapterView.OnItemSelectedListener param1OnItemSelectedListener) {
      this.P.O = param1OnItemSelectedListener;
      return this;
    }
    
    public a setOnKeyListener(DialogInterface.OnKeyListener param1OnKeyListener) {
      this.P.u = param1OnKeyListener;
      return this;
    }
    
    public a setPositiveButton(int param1Int, DialogInterface.OnClickListener param1OnClickListener) {
      AlertController.b b1 = this.P;
      b1.i = b1.a.getText(param1Int);
      this.P.k = param1OnClickListener;
      return this;
    }
    
    public a setPositiveButton(CharSequence param1CharSequence, DialogInterface.OnClickListener param1OnClickListener) {
      AlertController.b b1 = this.P;
      b1.i = param1CharSequence;
      b1.k = param1OnClickListener;
      return this;
    }
    
    public a setPositiveButtonIcon(Drawable param1Drawable) {
      this.P.j = param1Drawable;
      return this;
    }
    
    public a setRecycleOnMeasureEnabled(boolean param1Boolean) {
      this.P.P = param1Boolean;
      return this;
    }
    
    public a setSingleChoiceItems(int param1Int1, int param1Int2, DialogInterface.OnClickListener param1OnClickListener) {
      AlertController.b b1 = this.P;
      b1.v = b1.a.getResources().getTextArray(param1Int1);
      b1 = this.P;
      b1.x = param1OnClickListener;
      b1.I = param1Int2;
      b1.H = true;
      return this;
    }
    
    public a setSingleChoiceItems(Cursor param1Cursor, int param1Int, String param1String, DialogInterface.OnClickListener param1OnClickListener) {
      AlertController.b b1 = this.P;
      b1.K = param1Cursor;
      b1.x = param1OnClickListener;
      b1.I = param1Int;
      b1.L = param1String;
      b1.H = true;
      return this;
    }
    
    public a setSingleChoiceItems(ListAdapter param1ListAdapter, int param1Int, DialogInterface.OnClickListener param1OnClickListener) {
      AlertController.b b1 = this.P;
      b1.w = param1ListAdapter;
      b1.x = param1OnClickListener;
      b1.I = param1Int;
      b1.H = true;
      return this;
    }
    
    public a setSingleChoiceItems(CharSequence[] param1ArrayOfCharSequence, int param1Int, DialogInterface.OnClickListener param1OnClickListener) {
      AlertController.b b1 = this.P;
      b1.v = param1ArrayOfCharSequence;
      b1.x = param1OnClickListener;
      b1.I = param1Int;
      b1.H = true;
      return this;
    }
    
    public a setTitle(int param1Int) {
      AlertController.b b1 = this.P;
      b1.f = b1.a.getText(param1Int);
      return this;
    }
    
    public a setTitle(CharSequence param1CharSequence) {
      this.P.f = param1CharSequence;
      return this;
    }
    
    public a setView(int param1Int) {
      AlertController.b b1 = this.P;
      b1.z = null;
      b1.y = param1Int;
      b1.E = false;
      return this;
    }
    
    public a setView(View param1View) {
      AlertController.b b1 = this.P;
      b1.z = param1View;
      b1.y = 0;
      b1.E = false;
      return this;
    }
    
    @Deprecated
    public a setView(View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      AlertController.b b1 = this.P;
      b1.z = param1View;
      b1.y = 0;
      b1.E = true;
      b1.A = param1Int1;
      b1.B = param1Int2;
      b1.C = param1Int3;
      b1.D = param1Int4;
      return this;
    }
    
    public a show() {
      a a1 = create();
      a1.show();
      return a1;
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\appcompat\app\a.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */