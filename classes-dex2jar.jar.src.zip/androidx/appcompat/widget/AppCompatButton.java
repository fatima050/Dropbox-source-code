package androidx.appcompat.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.text.InputFilter;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;
import android.widget.TextView;
import dbxyzptlk.j.a;
import dbxyzptlk.n2.b;
import dbxyzptlk.n2.l;
import dbxyzptlk.r.J;
import dbxyzptlk.r.L;
import dbxyzptlk.r.V;
import dbxyzptlk.r.d;
import dbxyzptlk.r.i;
import dbxyzptlk.r.p;

public class AppCompatButton extends Button implements b {
  private i mAppCompatEmojiTextHelper;
  
  private final d mBackgroundTintHelper;
  
  private final p mTextHelper;
  
  public AppCompatButton(Context paramContext) {
    this(paramContext, null);
  }
  
  public AppCompatButton(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, a.buttonStyle);
  }
  
  public AppCompatButton(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(L.b(paramContext), paramAttributeSet, paramInt);
    J.a((View)this, getContext());
    d d1 = new d((View)this);
    this.mBackgroundTintHelper = d1;
    d1.e(paramAttributeSet, paramInt);
    p p1 = new p((TextView)this);
    this.mTextHelper = p1;
    p1.m(paramAttributeSet, paramInt);
    p1.b();
    getEmojiTextViewHelper().c(paramAttributeSet, paramInt);
  }
  
  private i getEmojiTextViewHelper() {
    if (this.mAppCompatEmojiTextHelper == null)
      this.mAppCompatEmojiTextHelper = new i((TextView)this); 
    return this.mAppCompatEmojiTextHelper;
  }
  
  public void drawableStateChanged() {
    super.drawableStateChanged();
    d d1 = this.mBackgroundTintHelper;
    if (d1 != null)
      d1.b(); 
    p p1 = this.mTextHelper;
    if (p1 != null)
      p1.b(); 
  }
  
  public int getAutoSizeMaxTextSize() {
    if (V.b)
      return super.getAutoSizeMaxTextSize(); 
    p p1 = this.mTextHelper;
    return (p1 != null) ? p1.e() : -1;
  }
  
  public int getAutoSizeMinTextSize() {
    if (V.b)
      return super.getAutoSizeMinTextSize(); 
    p p1 = this.mTextHelper;
    return (p1 != null) ? p1.f() : -1;
  }
  
  public int getAutoSizeStepGranularity() {
    if (V.b)
      return super.getAutoSizeStepGranularity(); 
    p p1 = this.mTextHelper;
    return (p1 != null) ? p1.g() : -1;
  }
  
  public int[] getAutoSizeTextAvailableSizes() {
    if (V.b)
      return super.getAutoSizeTextAvailableSizes(); 
    p p1 = this.mTextHelper;
    return (p1 != null) ? p1.h() : new int[0];
  }
  
  @SuppressLint({"WrongConstant"})
  public int getAutoSizeTextType() {
    boolean bool1 = V.b;
    boolean bool = false;
    if (bool1) {
      if (super.getAutoSizeTextType() == 1)
        bool = true; 
      return bool;
    } 
    p p1 = this.mTextHelper;
    return (p1 != null) ? p1.i() : 0;
  }
  
  public ActionMode.Callback getCustomSelectionActionModeCallback() {
    return l.s(super.getCustomSelectionActionModeCallback());
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    d d1 = this.mBackgroundTintHelper;
    if (d1 != null) {
      ColorStateList colorStateList = d1.c();
    } else {
      d1 = null;
    } 
    return (ColorStateList)d1;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    d d1 = this.mBackgroundTintHelper;
    if (d1 != null) {
      PorterDuff.Mode mode = d1.d();
    } else {
      d1 = null;
    } 
    return (PorterDuff.Mode)d1;
  }
  
  public ColorStateList getSupportCompoundDrawablesTintList() {
    return this.mTextHelper.j();
  }
  
  public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
    return this.mTextHelper.k();
  }
  
  public boolean isEmojiCompatEnabled() {
    return getEmojiTextViewHelper().b();
  }
  
  public void onInitializeAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent) {
    super.onInitializeAccessibilityEvent(paramAccessibilityEvent);
    paramAccessibilityEvent.setClassName(Button.class.getName());
  }
  
  public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo paramAccessibilityNodeInfo) {
    super.onInitializeAccessibilityNodeInfo(paramAccessibilityNodeInfo);
    paramAccessibilityNodeInfo.setClassName(Button.class.getName());
  }
  
  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
    p p1 = this.mTextHelper;
    if (p1 != null)
      p1.o(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4); 
  }
  
  public void onTextChanged(CharSequence paramCharSequence, int paramInt1, int paramInt2, int paramInt3) {
    super.onTextChanged(paramCharSequence, paramInt1, paramInt2, paramInt3);
    p p1 = this.mTextHelper;
    if (p1 != null && !V.b && p1.l())
      this.mTextHelper.c(); 
  }
  
  public void setAllCaps(boolean paramBoolean) {
    super.setAllCaps(paramBoolean);
    getEmojiTextViewHelper().d(paramBoolean);
  }
  
  public void setAutoSizeTextTypeUniformWithConfiguration(int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws IllegalArgumentException {
    if (V.b) {
      super.setAutoSizeTextTypeUniformWithConfiguration(paramInt1, paramInt2, paramInt3, paramInt4);
    } else {
      p p1 = this.mTextHelper;
      if (p1 != null)
        p1.t(paramInt1, paramInt2, paramInt3, paramInt4); 
    } 
  }
  
  public void setAutoSizeTextTypeUniformWithPresetSizes(int[] paramArrayOfint, int paramInt) throws IllegalArgumentException {
    if (V.b) {
      super.setAutoSizeTextTypeUniformWithPresetSizes(paramArrayOfint, paramInt);
    } else {
      p p1 = this.mTextHelper;
      if (p1 != null)
        p1.u(paramArrayOfint, paramInt); 
    } 
  }
  
  public void setAutoSizeTextTypeWithDefaults(int paramInt) {
    if (V.b) {
      super.setAutoSizeTextTypeWithDefaults(paramInt);
    } else {
      p p1 = this.mTextHelper;
      if (p1 != null)
        p1.v(paramInt); 
    } 
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
    d d1 = this.mBackgroundTintHelper;
    if (d1 != null)
      d1.f(paramDrawable); 
  }
  
  public void setBackgroundResource(int paramInt) {
    super.setBackgroundResource(paramInt);
    d d1 = this.mBackgroundTintHelper;
    if (d1 != null)
      d1.g(paramInt); 
  }
  
  public void setCustomSelectionActionModeCallback(ActionMode.Callback paramCallback) {
    super.setCustomSelectionActionModeCallback(l.t((TextView)this, paramCallback));
  }
  
  public void setEmojiCompatEnabled(boolean paramBoolean) {
    getEmojiTextViewHelper().e(paramBoolean);
  }
  
  public void setFilters(InputFilter[] paramArrayOfInputFilter) {
    super.setFilters(getEmojiTextViewHelper().a(paramArrayOfInputFilter));
  }
  
  public void setSupportAllCaps(boolean paramBoolean) {
    p p1 = this.mTextHelper;
    if (p1 != null)
      p1.s(paramBoolean); 
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    d d1 = this.mBackgroundTintHelper;
    if (d1 != null)
      d1.i(paramColorStateList); 
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    d d1 = this.mBackgroundTintHelper;
    if (d1 != null)
      d1.j(paramMode); 
  }
  
  public void setSupportCompoundDrawablesTintList(ColorStateList paramColorStateList) {
    this.mTextHelper.w(paramColorStateList);
    this.mTextHelper.b();
  }
  
  public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode paramMode) {
    this.mTextHelper.x(paramMode);
    this.mTextHelper.b();
  }
  
  public void setTextAppearance(Context paramContext, int paramInt) {
    super.setTextAppearance(paramContext, paramInt);
    p p1 = this.mTextHelper;
    if (p1 != null)
      p1.q(paramContext, paramInt); 
  }
  
  public void setTextSize(int paramInt, float paramFloat) {
    if (V.b) {
      super.setTextSize(paramInt, paramFloat);
    } else {
      p p1 = this.mTextHelper;
      if (p1 != null)
        p1.A(paramInt, paramFloat); 
    } 
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\appcompat\widget\AppCompatButton.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */