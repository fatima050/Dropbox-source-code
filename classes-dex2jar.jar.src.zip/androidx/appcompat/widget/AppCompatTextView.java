package androidx.appcompat.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.InputFilter;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.textclassifier.TextClassifier;
import android.widget.TextView;
import dbxyzptlk.Y1.h;
import dbxyzptlk.f2.r;
import dbxyzptlk.l.a;
import dbxyzptlk.n2.b;
import dbxyzptlk.n2.l;
import dbxyzptlk.r.J;
import dbxyzptlk.r.L;
import dbxyzptlk.r.V;
import dbxyzptlk.r.d;
import dbxyzptlk.r.i;
import dbxyzptlk.r.j;
import dbxyzptlk.r.o;
import dbxyzptlk.r.p;
import java.util.concurrent.Future;

public class AppCompatTextView extends TextView implements b {
  private final d mBackgroundTintHelper;
  
  private i mEmojiTextViewHelper;
  
  private boolean mIsSetTypefaceProcessing = false;
  
  private Future<r> mPrecomputedTextFuture;
  
  private a mSuperCaller = null;
  
  private final o mTextClassifierHelper;
  
  private final p mTextHelper;
  
  public AppCompatTextView(Context paramContext) {
    this(paramContext, null);
  }
  
  public AppCompatTextView(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 16842884);
  }
  
  public AppCompatTextView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(L.b(paramContext), paramAttributeSet, paramInt);
    J.a((View)this, getContext());
    d d1 = new d((View)this);
    this.mBackgroundTintHelper = d1;
    d1.e(paramAttributeSet, paramInt);
    p p1 = new p((TextView)this);
    this.mTextHelper = p1;
    p1.m(paramAttributeSet, paramInt);
    p1.b();
    this.mTextClassifierHelper = new o((TextView)this);
    getEmojiTextViewHelper().c(paramAttributeSet, paramInt);
  }
  
  private void consumeTextFutureAndSetBlocking() {
    Future<r> future = this.mPrecomputedTextFuture;
    if (future != null)
      try {
        this.mPrecomputedTextFuture = null;
        l.p((TextView)this, future.get());
      } catch (InterruptedException|java.util.concurrent.ExecutionException interruptedException) {} 
  }
  
  private i getEmojiTextViewHelper() {
    if (this.mEmojiTextViewHelper == null)
      this.mEmojiTextViewHelper = new i((TextView)this); 
    return this.mEmojiTextViewHelper;
  }
  
  public void drawableStateChanged() {
    super.drawableStateChanged();
    d d1 = this.mBackgroundTintHelper;
    if (d1 != null)
      d1.b(); 
    p p1 = this.mTextHelper;
    if (p1 != null)
      p1.b(); 
  }
  
  public int getAutoSizeMaxTextSize() {
    if (V.b)
      return getSuperCaller().c(); 
    p p1 = this.mTextHelper;
    return (p1 != null) ? p1.e() : -1;
  }
  
  public int getAutoSizeMinTextSize() {
    if (V.b)
      return getSuperCaller().a(); 
    p p1 = this.mTextHelper;
    return (p1 != null) ? p1.f() : -1;
  }
  
  public int getAutoSizeStepGranularity() {
    if (V.b)
      return getSuperCaller().e(); 
    p p1 = this.mTextHelper;
    return (p1 != null) ? p1.g() : -1;
  }
  
  public int[] getAutoSizeTextAvailableSizes() {
    if (V.b)
      return getSuperCaller().j(); 
    p p1 = this.mTextHelper;
    return (p1 != null) ? p1.h() : new int[0];
  }
  
  @SuppressLint({"WrongConstant"})
  public int getAutoSizeTextType() {
    boolean bool1 = V.b;
    boolean bool = false;
    if (bool1) {
      if (getSuperCaller().i() == 1)
        bool = true; 
      return bool;
    } 
    p p1 = this.mTextHelper;
    return (p1 != null) ? p1.i() : 0;
  }
  
  public ActionMode.Callback getCustomSelectionActionModeCallback() {
    return l.s(super.getCustomSelectionActionModeCallback());
  }
  
  public int getFirstBaselineToTopHeight() {
    return l.b((TextView)this);
  }
  
  public int getLastBaselineToBottomHeight() {
    return l.c((TextView)this);
  }
  
  public a getSuperCaller() {
    if (this.mSuperCaller == null)
      if (Build.VERSION.SDK_INT >= 28) {
        this.mSuperCaller = (a)new c(this);
      } else {
        this.mSuperCaller = (a)new b(this);
      }  
    return this.mSuperCaller;
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    d d1 = this.mBackgroundTintHelper;
    if (d1 != null) {
      ColorStateList colorStateList = d1.c();
    } else {
      d1 = null;
    } 
    return (ColorStateList)d1;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    d d1 = this.mBackgroundTintHelper;
    if (d1 != null) {
      PorterDuff.Mode mode = d1.d();
    } else {
      d1 = null;
    } 
    return (PorterDuff.Mode)d1;
  }
  
  public ColorStateList getSupportCompoundDrawablesTintList() {
    return this.mTextHelper.j();
  }
  
  public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
    return this.mTextHelper.k();
  }
  
  public CharSequence getText() {
    consumeTextFutureAndSetBlocking();
    return super.getText();
  }
  
  public TextClassifier getTextClassifier() {
    if (Build.VERSION.SDK_INT < 28) {
      o o1 = this.mTextClassifierHelper;
      if (o1 != null)
        return o1.a(); 
    } 
    return getSuperCaller().b();
  }
  
  public r.a getTextMetricsParamsCompat() {
    return l.g((TextView)this);
  }
  
  public boolean isEmojiCompatEnabled() {
    return getEmojiTextViewHelper().b();
  }
  
  public InputConnection onCreateInputConnection(EditorInfo paramEditorInfo) {
    InputConnection inputConnection = super.onCreateInputConnection(paramEditorInfo);
    this.mTextHelper.r((TextView)this, inputConnection, paramEditorInfo);
    return j.a(inputConnection, paramEditorInfo, (View)this);
  }
  
  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
    p p1 = this.mTextHelper;
    if (p1 != null)
      p1.o(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4); 
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    consumeTextFutureAndSetBlocking();
    super.onMeasure(paramInt1, paramInt2);
  }
  
  public void onTextChanged(CharSequence paramCharSequence, int paramInt1, int paramInt2, int paramInt3) {
    super.onTextChanged(paramCharSequence, paramInt1, paramInt2, paramInt3);
    p p1 = this.mTextHelper;
    if (p1 != null && !V.b && p1.l())
      this.mTextHelper.c(); 
  }
  
  public void setAllCaps(boolean paramBoolean) {
    super.setAllCaps(paramBoolean);
    getEmojiTextViewHelper().d(paramBoolean);
  }
  
  public void setAutoSizeTextTypeUniformWithConfiguration(int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws IllegalArgumentException {
    if (V.b) {
      getSuperCaller().setAutoSizeTextTypeUniformWithConfiguration(paramInt1, paramInt2, paramInt3, paramInt4);
    } else {
      p p1 = this.mTextHelper;
      if (p1 != null)
        p1.t(paramInt1, paramInt2, paramInt3, paramInt4); 
    } 
  }
  
  public void setAutoSizeTextTypeUniformWithPresetSizes(int[] paramArrayOfint, int paramInt) throws IllegalArgumentException {
    if (V.b) {
      getSuperCaller().g(paramArrayOfint, paramInt);
    } else {
      p p1 = this.mTextHelper;
      if (p1 != null)
        p1.u(paramArrayOfint, paramInt); 
    } 
  }
  
  public void setAutoSizeTextTypeWithDefaults(int paramInt) {
    if (V.b) {
      getSuperCaller().f(paramInt);
    } else {
      p p1 = this.mTextHelper;
      if (p1 != null)
        p1.v(paramInt); 
    } 
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
    d d1 = this.mBackgroundTintHelper;
    if (d1 != null)
      d1.f(paramDrawable); 
  }
  
  public void setBackgroundResource(int paramInt) {
    super.setBackgroundResource(paramInt);
    d d1 = this.mBackgroundTintHelper;
    if (d1 != null)
      d1.g(paramInt); 
  }
  
  public void setCompoundDrawables(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4) {
    super.setCompoundDrawables(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
    p p1 = this.mTextHelper;
    if (p1 != null)
      p1.p(); 
  }
  
  public void setCompoundDrawablesRelative(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4) {
    super.setCompoundDrawablesRelative(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
    p p1 = this.mTextHelper;
    if (p1 != null)
      p1.p(); 
  }
  
  public void setCompoundDrawablesRelativeWithIntrinsicBounds(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    Drawable drawable1;
    Drawable drawable2;
    Drawable drawable3;
    Context context = getContext();
    Drawable drawable4 = null;
    if (paramInt1 != 0) {
      drawable1 = a.b(context, paramInt1);
    } else {
      drawable1 = null;
    } 
    if (paramInt2 != 0) {
      drawable2 = a.b(context, paramInt2);
    } else {
      drawable2 = null;
    } 
    if (paramInt3 != 0) {
      drawable3 = a.b(context, paramInt3);
    } else {
      drawable3 = null;
    } 
    if (paramInt4 != 0)
      drawable4 = a.b(context, paramInt4); 
    setCompoundDrawablesRelativeWithIntrinsicBounds(drawable1, drawable2, drawable3, drawable4);
    p p1 = this.mTextHelper;
    if (p1 != null)
      p1.p(); 
  }
  
  public void setCompoundDrawablesRelativeWithIntrinsicBounds(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4) {
    super.setCompoundDrawablesRelativeWithIntrinsicBounds(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
    p p1 = this.mTextHelper;
    if (p1 != null)
      p1.p(); 
  }
  
  public void setCompoundDrawablesWithIntrinsicBounds(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    Drawable drawable1;
    Drawable drawable2;
    Drawable drawable3;
    Context context = getContext();
    Drawable drawable4 = null;
    if (paramInt1 != 0) {
      drawable1 = a.b(context, paramInt1);
    } else {
      drawable1 = null;
    } 
    if (paramInt2 != 0) {
      drawable2 = a.b(context, paramInt2);
    } else {
      drawable2 = null;
    } 
    if (paramInt3 != 0) {
      drawable3 = a.b(context, paramInt3);
    } else {
      drawable3 = null;
    } 
    if (paramInt4 != 0)
      drawable4 = a.b(context, paramInt4); 
    setCompoundDrawablesWithIntrinsicBounds(drawable1, drawable2, drawable3, drawable4);
    p p1 = this.mTextHelper;
    if (p1 != null)
      p1.p(); 
  }
  
  public void setCompoundDrawablesWithIntrinsicBounds(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4) {
    super.setCompoundDrawablesWithIntrinsicBounds(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
    p p1 = this.mTextHelper;
    if (p1 != null)
      p1.p(); 
  }
  
  public void setCustomSelectionActionModeCallback(ActionMode.Callback paramCallback) {
    super.setCustomSelectionActionModeCallback(l.t((TextView)this, paramCallback));
  }
  
  public void setEmojiCompatEnabled(boolean paramBoolean) {
    getEmojiTextViewHelper().e(paramBoolean);
  }
  
  public void setFilters(InputFilter[] paramArrayOfInputFilter) {
    super.setFilters(getEmojiTextViewHelper().a(paramArrayOfInputFilter));
  }
  
  public void setFirstBaselineToTopHeight(int paramInt) {
    if (Build.VERSION.SDK_INT >= 28) {
      getSuperCaller().d(paramInt);
    } else {
      l.m((TextView)this, paramInt);
    } 
  }
  
  public void setLastBaselineToBottomHeight(int paramInt) {
    if (Build.VERSION.SDK_INT >= 28) {
      getSuperCaller().h(paramInt);
    } else {
      l.n((TextView)this, paramInt);
    } 
  }
  
  public void setLineHeight(int paramInt) {
    l.o((TextView)this, paramInt);
  }
  
  public void setPrecomputedText(r paramr) {
    l.p((TextView)this, paramr);
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    d d1 = this.mBackgroundTintHelper;
    if (d1 != null)
      d1.i(paramColorStateList); 
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    d d1 = this.mBackgroundTintHelper;
    if (d1 != null)
      d1.j(paramMode); 
  }
  
  public void setSupportCompoundDrawablesTintList(ColorStateList paramColorStateList) {
    this.mTextHelper.w(paramColorStateList);
    this.mTextHelper.b();
  }
  
  public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode paramMode) {
    this.mTextHelper.x(paramMode);
    this.mTextHelper.b();
  }
  
  public void setTextAppearance(Context paramContext, int paramInt) {
    super.setTextAppearance(paramContext, paramInt);
    p p1 = this.mTextHelper;
    if (p1 != null)
      p1.q(paramContext, paramInt); 
  }
  
  public void setTextClassifier(TextClassifier paramTextClassifier) {
    if (Build.VERSION.SDK_INT < 28) {
      o o1 = this.mTextClassifierHelper;
      if (o1 != null) {
        o1.b(paramTextClassifier);
        return;
      } 
    } 
    getSuperCaller().k(paramTextClassifier);
  }
  
  public void setTextFuture(Future<r> paramFuture) {
    this.mPrecomputedTextFuture = paramFuture;
    if (paramFuture != null)
      requestLayout(); 
  }
  
  public void setTextMetricsParamsCompat(r.a parama) {
    l.r((TextView)this, parama);
  }
  
  public void setTextSize(int paramInt, float paramFloat) {
    if (V.b) {
      super.setTextSize(paramInt, paramFloat);
    } else {
      p p1 = this.mTextHelper;
      if (p1 != null)
        p1.A(paramInt, paramFloat); 
    } 
  }
  
  public void setTypeface(Typeface paramTypeface, int paramInt) {
    Typeface typeface;
    if (this.mIsSetTypefaceProcessing)
      return; 
    if (paramTypeface != null && paramInt > 0) {
      typeface = h.a(getContext(), paramTypeface, paramInt);
    } else {
      typeface = null;
    } 
    this.mIsSetTypefaceProcessing = true;
    if (typeface != null)
      paramTypeface = typeface; 
    try {
      super.setTypeface(paramTypeface, paramInt);
      return;
    } finally {
      this.mIsSetTypefaceProcessing = false;
    } 
  }
  
  class AppCompatTextView {}
  
  class AppCompatTextView {}
  
  class AppCompatTextView {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\appcompat\widget\AppCompatTextView.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */