package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.Editable;
import android.text.method.KeyListener;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.DragEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.textclassifier.TextClassifier;
import android.widget.EditText;
import android.widget.TextView;
import dbxyzptlk.h2.Q;
import dbxyzptlk.h2.d;
import dbxyzptlk.h2.h0;
import dbxyzptlk.j.a;
import dbxyzptlk.m2.a;
import dbxyzptlk.m2.c;
import dbxyzptlk.n2.l;
import dbxyzptlk.n2.m;
import dbxyzptlk.r.J;
import dbxyzptlk.r.L;
import dbxyzptlk.r.d;
import dbxyzptlk.r.h;
import dbxyzptlk.r.j;
import dbxyzptlk.r.m;
import dbxyzptlk.r.o;
import dbxyzptlk.r.p;

public class AppCompatEditText extends EditText implements Q {
  private final h mAppCompatEmojiEditTextHelper;
  
  private final d mBackgroundTintHelper;
  
  private final m mDefaultOnReceiveContentListener;
  
  private a mSuperCaller;
  
  private final o mTextClassifierHelper;
  
  private final p mTextHelper;
  
  public AppCompatEditText(Context paramContext) {
    this(paramContext, null);
  }
  
  public AppCompatEditText(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, a.editTextStyle);
  }
  
  public AppCompatEditText(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(L.b(paramContext), paramAttributeSet, paramInt);
    J.a((View)this, getContext());
    d d1 = new d((View)this);
    this.mBackgroundTintHelper = d1;
    d1.e(paramAttributeSet, paramInt);
    p p1 = new p((TextView)this);
    this.mTextHelper = p1;
    p1.m(paramAttributeSet, paramInt);
    p1.b();
    this.mTextClassifierHelper = new o((TextView)this);
    this.mDefaultOnReceiveContentListener = new m();
    h h1 = new h((EditText)this);
    this.mAppCompatEmojiEditTextHelper = h1;
    h1.d(paramAttributeSet, paramInt);
    initEmojiKeyListener(h1);
  }
  
  private a getSuperCaller() {
    if (this.mSuperCaller == null)
      this.mSuperCaller = new a(this); 
    return this.mSuperCaller;
  }
  
  public void drawableStateChanged() {
    super.drawableStateChanged();
    d d1 = this.mBackgroundTintHelper;
    if (d1 != null)
      d1.b(); 
    p p1 = this.mTextHelper;
    if (p1 != null)
      p1.b(); 
  }
  
  public ActionMode.Callback getCustomSelectionActionModeCallback() {
    return l.s(super.getCustomSelectionActionModeCallback());
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    d d1 = this.mBackgroundTintHelper;
    if (d1 != null) {
      ColorStateList colorStateList = d1.c();
    } else {
      d1 = null;
    } 
    return (ColorStateList)d1;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    d d1 = this.mBackgroundTintHelper;
    if (d1 != null) {
      PorterDuff.Mode mode = d1.d();
    } else {
      d1 = null;
    } 
    return (PorterDuff.Mode)d1;
  }
  
  public ColorStateList getSupportCompoundDrawablesTintList() {
    return this.mTextHelper.j();
  }
  
  public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
    return this.mTextHelper.k();
  }
  
  public Editable getText() {
    return (Build.VERSION.SDK_INT >= 28) ? super.getText() : getEditableText();
  }
  
  public TextClassifier getTextClassifier() {
    if (Build.VERSION.SDK_INT < 28) {
      o o1 = this.mTextClassifierHelper;
      if (o1 != null)
        return o1.a(); 
    } 
    return getSuperCaller().a();
  }
  
  public void initEmojiKeyListener(h paramh) {
    KeyListener keyListener = getKeyListener();
    if (paramh.b(keyListener)) {
      boolean bool3 = isFocusable();
      boolean bool2 = isClickable();
      boolean bool1 = isLongClickable();
      int i = getInputType();
      KeyListener keyListener1 = paramh.a(keyListener);
      if (keyListener1 == keyListener)
        return; 
      super.setKeyListener(keyListener1);
      setRawInputType(i);
      setFocusable(bool3);
      setClickable(bool2);
      setLongClickable(bool1);
    } 
  }
  
  public boolean isEmojiCompatEnabled() {
    return this.mAppCompatEmojiEditTextHelper.c();
  }
  
  public InputConnection onCreateInputConnection(EditorInfo paramEditorInfo) {
    InputConnection inputConnection1 = super.onCreateInputConnection(paramEditorInfo);
    this.mTextHelper.r((TextView)this, inputConnection1, paramEditorInfo);
    InputConnection inputConnection2 = j.a(inputConnection1, paramEditorInfo, (View)this);
    inputConnection1 = inputConnection2;
    if (inputConnection2 != null) {
      inputConnection1 = inputConnection2;
      if (Build.VERSION.SDK_INT <= 30) {
        String[] arrayOfString = h0.D((View)this);
        inputConnection1 = inputConnection2;
        if (arrayOfString != null) {
          a.c(paramEditorInfo, arrayOfString);
          inputConnection1 = c.c((View)this, inputConnection2, paramEditorInfo);
        } 
      } 
    } 
    return this.mAppCompatEmojiEditTextHelper.e(inputConnection1, paramEditorInfo);
  }
  
  public boolean onDragEvent(DragEvent paramDragEvent) {
    return m.a((View)this, paramDragEvent) ? true : super.onDragEvent(paramDragEvent);
  }
  
  public d onReceiveContent(d paramd) {
    return this.mDefaultOnReceiveContentListener.onReceiveContent((View)this, paramd);
  }
  
  public boolean onTextContextMenuItem(int paramInt) {
    return m.b((TextView)this, paramInt) ? true : super.onTextContextMenuItem(paramInt);
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
    d d1 = this.mBackgroundTintHelper;
    if (d1 != null)
      d1.f(paramDrawable); 
  }
  
  public void setBackgroundResource(int paramInt) {
    super.setBackgroundResource(paramInt);
    d d1 = this.mBackgroundTintHelper;
    if (d1 != null)
      d1.g(paramInt); 
  }
  
  public void setCompoundDrawables(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4) {
    super.setCompoundDrawables(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
    p p1 = this.mTextHelper;
    if (p1 != null)
      p1.p(); 
  }
  
  public void setCompoundDrawablesRelative(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4) {
    super.setCompoundDrawablesRelative(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
    p p1 = this.mTextHelper;
    if (p1 != null)
      p1.p(); 
  }
  
  public void setCustomSelectionActionModeCallback(ActionMode.Callback paramCallback) {
    super.setCustomSelectionActionModeCallback(l.t((TextView)this, paramCallback));
  }
  
  public void setEmojiCompatEnabled(boolean paramBoolean) {
    this.mAppCompatEmojiEditTextHelper.f(paramBoolean);
  }
  
  public void setKeyListener(KeyListener paramKeyListener) {
    super.setKeyListener(this.mAppCompatEmojiEditTextHelper.a(paramKeyListener));
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    d d1 = this.mBackgroundTintHelper;
    if (d1 != null)
      d1.i(paramColorStateList); 
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    d d1 = this.mBackgroundTintHelper;
    if (d1 != null)
      d1.j(paramMode); 
  }
  
  public void setSupportCompoundDrawablesTintList(ColorStateList paramColorStateList) {
    this.mTextHelper.w(paramColorStateList);
    this.mTextHelper.b();
  }
  
  public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode paramMode) {
    this.mTextHelper.x(paramMode);
    this.mTextHelper.b();
  }
  
  public void setTextAppearance(Context paramContext, int paramInt) {
    super.setTextAppearance(paramContext, paramInt);
    p p1 = this.mTextHelper;
    if (p1 != null)
      p1.q(paramContext, paramInt); 
  }
  
  public void setTextClassifier(TextClassifier paramTextClassifier) {
    if (Build.VERSION.SDK_INT < 28) {
      o o1 = this.mTextClassifierHelper;
      if (o1 != null) {
        o1.b(paramTextClassifier);
        return;
      } 
    } 
    getSuperCaller().b(paramTextClassifier);
  }
  
  class AppCompatEditText {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\appcompat\widget\AppCompatEditText.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */