package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import android.widget.LinearLayout;
import dbxyzptlk.h2.h0;
import dbxyzptlk.j.f;
import dbxyzptlk.j.j;

public class ButtonBarLayout extends LinearLayout {
  public boolean a;
  
  public boolean b;
  
  public int c = -1;
  
  public ButtonBarLayout(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, j.ButtonBarLayout);
    h0.o0((View)this, paramContext, j.ButtonBarLayout, paramAttributeSet, typedArray, 0, 0);
    this.a = typedArray.getBoolean(j.ButtonBarLayout_allowStacking, true);
    typedArray.recycle();
    if (getOrientation() == 1)
      setStacked(this.a); 
  }
  
  private void setStacked(boolean paramBoolean) {
    if (this.b != paramBoolean && (!paramBoolean || this.a)) {
      byte b;
      this.b = paramBoolean;
      setOrientation(paramBoolean);
      if (paramBoolean) {
        b = 8388613;
      } else {
        b = 80;
      } 
      setGravity(b);
      View view = findViewById(f.spacer);
      if (view != null) {
        byte b1;
        if (paramBoolean) {
          b1 = 8;
        } else {
          b1 = 4;
        } 
        view.setVisibility(b1);
      } 
      for (int i = getChildCount() - 2; i >= 0; i--)
        bringChildToFront(getChildAt(i)); 
    } 
  }
  
  public final int a(int paramInt) {
    int i = getChildCount();
    while (paramInt < i) {
      if (getChildAt(paramInt).getVisibility() == 0)
        return paramInt; 
      paramInt++;
    } 
    return -1;
  }
  
  public final boolean b() {
    return this.b;
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    int i = View.MeasureSpec.getSize(paramInt1);
    boolean bool = this.a;
    int k = 0;
    if (bool) {
      if (i > this.c && b())
        setStacked(false); 
      this.c = i;
    } 
    if (!b() && View.MeasureSpec.getMode(paramInt1) == 1073741824) {
      j = View.MeasureSpec.makeMeasureSpec(i, -2147483648);
      i = 1;
    } else {
      j = paramInt1;
      i = 0;
    } 
    super.onMeasure(j, paramInt2);
    int j = i;
    if (this.a) {
      j = i;
      if (!b()) {
        j = i;
        if ((getMeasuredWidthAndState() & 0xFF000000) == 16777216) {
          setStacked(true);
          j = 1;
        } 
      } 
    } 
    if (j != 0)
      super.onMeasure(paramInt1, paramInt2); 
    int m = a(0);
    i = k;
    if (m >= 0) {
      View view = getChildAt(m);
      LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams)view.getLayoutParams();
      j = getPaddingTop() + view.getMeasuredHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
      if (b()) {
        k = a(m + 1);
        i = j;
        if (k >= 0)
          i = j + getChildAt(k).getPaddingTop() + (int)((getResources().getDisplayMetrics()).density * 16.0F); 
      } else {
        i = j + getPaddingBottom();
      } 
    } 
    if (h0.B((View)this) != i) {
      setMinimumHeight(i);
      if (paramInt2 == 0)
        super.onMeasure(paramInt1, paramInt2); 
    } 
  }
  
  public void setAllowStacking(boolean paramBoolean) {
    if (this.a != paramBoolean) {
      this.a = paramBoolean;
      if (!paramBoolean && b())
        setStacked(false); 
      requestLayout();
    } 
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\appcompat\widget\ButtonBarLayout.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */