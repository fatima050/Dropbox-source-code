package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageView;
import dbxyzptlk.r.J;
import dbxyzptlk.r.L;
import dbxyzptlk.r.d;
import dbxyzptlk.r.k;

public class AppCompatImageView extends ImageView {
  private final d mBackgroundTintHelper;
  
  private boolean mHasLevel = false;
  
  private final k mImageHelper;
  
  public AppCompatImageView(Context paramContext) {
    this(paramContext, null);
  }
  
  public AppCompatImageView(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 0);
  }
  
  public AppCompatImageView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(L.b(paramContext), paramAttributeSet, paramInt);
    J.a((View)this, getContext());
    d d1 = new d((View)this);
    this.mBackgroundTintHelper = d1;
    d1.e(paramAttributeSet, paramInt);
    k k1 = new k(this);
    this.mImageHelper = k1;
    k1.g(paramAttributeSet, paramInt);
  }
  
  public void drawableStateChanged() {
    super.drawableStateChanged();
    d d1 = this.mBackgroundTintHelper;
    if (d1 != null)
      d1.b(); 
    k k1 = this.mImageHelper;
    if (k1 != null)
      k1.c(); 
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    d d1 = this.mBackgroundTintHelper;
    if (d1 != null) {
      ColorStateList colorStateList = d1.c();
    } else {
      d1 = null;
    } 
    return (ColorStateList)d1;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    d d1 = this.mBackgroundTintHelper;
    if (d1 != null) {
      PorterDuff.Mode mode = d1.d();
    } else {
      d1 = null;
    } 
    return (PorterDuff.Mode)d1;
  }
  
  public ColorStateList getSupportImageTintList() {
    k k1 = this.mImageHelper;
    if (k1 != null) {
      ColorStateList colorStateList = k1.d();
    } else {
      k1 = null;
    } 
    return (ColorStateList)k1;
  }
  
  public PorterDuff.Mode getSupportImageTintMode() {
    k k1 = this.mImageHelper;
    if (k1 != null) {
      PorterDuff.Mode mode = k1.e();
    } else {
      k1 = null;
    } 
    return (PorterDuff.Mode)k1;
  }
  
  public boolean hasOverlappingRendering() {
    boolean bool;
    if (this.mImageHelper.f() && super.hasOverlappingRendering()) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
    d d1 = this.mBackgroundTintHelper;
    if (d1 != null)
      d1.f(paramDrawable); 
  }
  
  public void setBackgroundResource(int paramInt) {
    super.setBackgroundResource(paramInt);
    d d1 = this.mBackgroundTintHelper;
    if (d1 != null)
      d1.g(paramInt); 
  }
  
  public void setImageBitmap(Bitmap paramBitmap) {
    super.setImageBitmap(paramBitmap);
    k k1 = this.mImageHelper;
    if (k1 != null)
      k1.c(); 
  }
  
  public void setImageDrawable(Drawable paramDrawable) {
    k k2 = this.mImageHelper;
    if (k2 != null && paramDrawable != null && !this.mHasLevel)
      k2.h(paramDrawable); 
    super.setImageDrawable(paramDrawable);
    k k1 = this.mImageHelper;
    if (k1 != null) {
      k1.c();
      if (!this.mHasLevel)
        this.mImageHelper.b(); 
    } 
  }
  
  public void setImageLevel(int paramInt) {
    super.setImageLevel(paramInt);
    this.mHasLevel = true;
  }
  
  public void setImageResource(int paramInt) {
    k k1 = this.mImageHelper;
    if (k1 != null)
      k1.i(paramInt); 
  }
  
  public void setImageURI(Uri paramUri) {
    super.setImageURI(paramUri);
    k k1 = this.mImageHelper;
    if (k1 != null)
      k1.c(); 
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    d d1 = this.mBackgroundTintHelper;
    if (d1 != null)
      d1.i(paramColorStateList); 
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    d d1 = this.mBackgroundTintHelper;
    if (d1 != null)
      d1.j(paramMode); 
  }
  
  public void setSupportImageTintList(ColorStateList paramColorStateList) {
    k k1 = this.mImageHelper;
    if (k1 != null)
      k1.j(paramColorStateList); 
  }
  
  public void setSupportImageTintMode(PorterDuff.Mode paramMode) {
    k k1 = this.mImageHelper;
    if (k1 != null)
      k1.k(paramMode); 
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\appcompat\widget\AppCompatImageView.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */