package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.LinearLayout;
import dbxyzptlk.h2.h0;
import dbxyzptlk.h2.x;
import dbxyzptlk.j.j;
import dbxyzptlk.r.O;
import dbxyzptlk.r.V;

public class LinearLayoutCompat extends ViewGroup {
  private static final String ACCESSIBILITY_CLASS_NAME = "androidx.appcompat.widget.LinearLayoutCompat";
  
  public static final int HORIZONTAL = 0;
  
  private static final int INDEX_BOTTOM = 2;
  
  private static final int INDEX_CENTER_VERTICAL = 0;
  
  private static final int INDEX_FILL = 3;
  
  private static final int INDEX_TOP = 1;
  
  public static final int SHOW_DIVIDER_BEGINNING = 1;
  
  public static final int SHOW_DIVIDER_END = 4;
  
  public static final int SHOW_DIVIDER_MIDDLE = 2;
  
  public static final int SHOW_DIVIDER_NONE = 0;
  
  public static final int VERTICAL = 1;
  
  private static final int VERTICAL_GRAVITY_COUNT = 4;
  
  private boolean mBaselineAligned = true;
  
  private int mBaselineAlignedChildIndex = -1;
  
  private int mBaselineChildTop = 0;
  
  private Drawable mDivider;
  
  private int mDividerHeight;
  
  private int mDividerPadding;
  
  private int mDividerWidth;
  
  private int mGravity = 8388659;
  
  private int[] mMaxAscent;
  
  private int[] mMaxDescent;
  
  private int mOrientation;
  
  private int mShowDividers;
  
  private int mTotalLength;
  
  private boolean mUseLargestChild;
  
  private float mWeightSum;
  
  public LinearLayoutCompat(Context paramContext) {
    this(paramContext, null);
  }
  
  public LinearLayoutCompat(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 0);
  }
  
  public LinearLayoutCompat(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    O o = O.v(paramContext, paramAttributeSet, j.LinearLayoutCompat, paramInt, 0);
    h0.o0((View)this, paramContext, j.LinearLayoutCompat, paramAttributeSet, o.r(), paramInt, 0);
    paramInt = o.k(j.LinearLayoutCompat_android_orientation, -1);
    if (paramInt >= 0)
      setOrientation(paramInt); 
    paramInt = o.k(j.LinearLayoutCompat_android_gravity, -1);
    if (paramInt >= 0)
      setGravity(paramInt); 
    boolean bool = o.a(j.LinearLayoutCompat_android_baselineAligned, true);
    if (!bool)
      setBaselineAligned(bool); 
    this.mWeightSum = o.i(j.LinearLayoutCompat_android_weightSum, -1.0F);
    this.mBaselineAlignedChildIndex = o.k(j.LinearLayoutCompat_android_baselineAlignedChildIndex, -1);
    this.mUseLargestChild = o.a(j.LinearLayoutCompat_measureWithLargestChild, false);
    setDividerDrawable(o.g(j.LinearLayoutCompat_divider));
    this.mShowDividers = o.k(j.LinearLayoutCompat_showDividers, 0);
    this.mDividerPadding = o.f(j.LinearLayoutCompat_dividerPadding, 0);
    o.w();
  }
  
  private void forceUniformHeight(int paramInt1, int paramInt2) {
    int i = View.MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 1073741824);
    for (byte b = 0; b < paramInt1; b++) {
      View view = getVirtualChildAt(b);
      if (view.getVisibility() != 8) {
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        if (layoutParams.height == -1) {
          int j = layoutParams.width;
          layoutParams.width = view.getMeasuredWidth();
          measureChildWithMargins(view, paramInt2, 0, i, 0);
          layoutParams.width = j;
        } 
      } 
    } 
  }
  
  private void forceUniformWidth(int paramInt1, int paramInt2) {
    int i = View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 1073741824);
    for (byte b = 0; b < paramInt1; b++) {
      View view = getVirtualChildAt(b);
      if (view.getVisibility() != 8) {
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        if (layoutParams.width == -1) {
          int j = layoutParams.height;
          layoutParams.height = view.getMeasuredHeight();
          measureChildWithMargins(view, i, 0, paramInt2, 0);
          layoutParams.height = j;
        } 
      } 
    } 
  }
  
  private void setChildFrame(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    paramView.layout(paramInt1, paramInt2, paramInt3 + paramInt1, paramInt4 + paramInt2);
  }
  
  public boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return paramLayoutParams instanceof LayoutParams;
  }
  
  public void drawDividersHorizontal(Canvas paramCanvas) {
    int j = getVirtualChildCount();
    boolean bool = V.b((View)this);
    int i;
    for (i = 0; i < j; i++) {
      View view = getVirtualChildAt(i);
      if (view != null && view.getVisibility() != 8 && hasDividerBeforeChildAt(i)) {
        int k;
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        if (bool) {
          k = view.getRight() + layoutParams.rightMargin;
        } else {
          k = view.getLeft() - layoutParams.leftMargin - this.mDividerWidth;
        } 
        drawVerticalDivider(paramCanvas, k);
      } 
    } 
    if (hasDividerBeforeChildAt(j)) {
      View view = getVirtualChildAt(j - 1);
      if (view == null) {
        if (bool) {
          i = getPaddingLeft();
        } else {
          i = getWidth() - getPaddingRight();
          int k = this.mDividerWidth;
          i -= k;
        } 
      } else {
        int k;
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        if (bool) {
          i = view.getLeft() - layoutParams.leftMargin;
          k = this.mDividerWidth;
        } else {
          i = view.getRight() + layoutParams.rightMargin;
          drawVerticalDivider(paramCanvas, i);
        } 
        i -= k;
      } 
    } else {
      return;
    } 
    drawVerticalDivider(paramCanvas, i);
  }
  
  public void drawDividersVertical(Canvas paramCanvas) {
    int j = getVirtualChildCount();
    int i;
    for (i = 0; i < j; i++) {
      View view = getVirtualChildAt(i);
      if (view != null && view.getVisibility() != 8 && hasDividerBeforeChildAt(i)) {
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        drawHorizontalDivider(paramCanvas, view.getTop() - layoutParams.topMargin - this.mDividerHeight);
      } 
    } 
    if (hasDividerBeforeChildAt(j)) {
      View view = getVirtualChildAt(j - 1);
      if (view == null) {
        i = getHeight() - getPaddingBottom() - this.mDividerHeight;
      } else {
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        i = view.getBottom() + layoutParams.bottomMargin;
      } 
      drawHorizontalDivider(paramCanvas, i);
    } 
  }
  
  public void drawHorizontalDivider(Canvas paramCanvas, int paramInt) {
    this.mDivider.setBounds(getPaddingLeft() + this.mDividerPadding, paramInt, getWidth() - getPaddingRight() - this.mDividerPadding, this.mDividerHeight + paramInt);
    this.mDivider.draw(paramCanvas);
  }
  
  public void drawVerticalDivider(Canvas paramCanvas, int paramInt) {
    this.mDivider.setBounds(paramInt, getPaddingTop() + this.mDividerPadding, this.mDividerWidth + paramInt, getHeight() - getPaddingBottom() - this.mDividerPadding);
    this.mDivider.draw(paramCanvas);
  }
  
  public LayoutParams generateDefaultLayoutParams() {
    int i = this.mOrientation;
    return (i == 0) ? new LayoutParams(-2, -2) : ((i == 1) ? new LayoutParams(-1, -2) : null);
  }
  
  public LayoutParams generateLayoutParams(AttributeSet paramAttributeSet) {
    return new LayoutParams(getContext(), paramAttributeSet);
  }
  
  public LayoutParams generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return new LayoutParams(paramLayoutParams);
  }
  
  public int getBaseline() {
    if (this.mBaselineAlignedChildIndex < 0)
      return super.getBaseline(); 
    int j = getChildCount();
    int i = this.mBaselineAlignedChildIndex;
    if (j > i) {
      View view = getChildAt(i);
      int k = view.getBaseline();
      if (k == -1) {
        if (this.mBaselineAlignedChildIndex == 0)
          return -1; 
        throw new RuntimeException("mBaselineAlignedChildIndex of LinearLayout points to a View that doesn't know how to get its baseline.");
      } 
      j = this.mBaselineChildTop;
      i = j;
      if (this.mOrientation == 1) {
        int m = this.mGravity & 0x70;
        i = j;
        if (m != 48)
          if (m != 16) {
            if (m != 80) {
              i = j;
            } else {
              i = getBottom() - getTop() - getPaddingBottom() - this.mTotalLength;
            } 
          } else {
            i = j + (getBottom() - getTop() - getPaddingTop() - getPaddingBottom() - this.mTotalLength) / 2;
          }  
      } 
      return i + ((LayoutParams)view.getLayoutParams()).topMargin + k;
    } 
    throw new RuntimeException("mBaselineAlignedChildIndex of LinearLayout set to an index that is out of bounds.");
  }
  
  public int getBaselineAlignedChildIndex() {
    return this.mBaselineAlignedChildIndex;
  }
  
  public int getChildrenSkipCount(View paramView, int paramInt) {
    return 0;
  }
  
  public Drawable getDividerDrawable() {
    return this.mDivider;
  }
  
  public int getDividerPadding() {
    return this.mDividerPadding;
  }
  
  public int getDividerWidth() {
    return this.mDividerWidth;
  }
  
  public int getGravity() {
    return this.mGravity;
  }
  
  public int getLocationOffset(View paramView) {
    return 0;
  }
  
  public int getNextLocationOffset(View paramView) {
    return 0;
  }
  
  public int getOrientation() {
    return this.mOrientation;
  }
  
  public int getShowDividers() {
    return this.mShowDividers;
  }
  
  public View getVirtualChildAt(int paramInt) {
    return getChildAt(paramInt);
  }
  
  public int getVirtualChildCount() {
    return getChildCount();
  }
  
  public float getWeightSum() {
    return this.mWeightSum;
  }
  
  public boolean hasDividerBeforeChildAt(int paramInt) {
    boolean bool1 = false;
    boolean bool2 = false;
    boolean bool3 = false;
    if (paramInt == 0) {
      bool1 = bool3;
      if ((this.mShowDividers & 0x1) != 0)
        bool1 = true; 
      return bool1;
    } 
    if (paramInt == getChildCount()) {
      if ((this.mShowDividers & 0x4) != 0)
        bool1 = true; 
      return bool1;
    } 
    bool1 = bool2;
    if ((this.mShowDividers & 0x2) != 0) {
      paramInt--;
      while (true) {
        bool1 = bool2;
        if (paramInt >= 0) {
          if (getChildAt(paramInt).getVisibility() != 8) {
            bool1 = true;
            break;
          } 
          paramInt--;
          continue;
        } 
        break;
      } 
    } 
    return bool1;
  }
  
  public boolean isBaselineAligned() {
    return this.mBaselineAligned;
  }
  
  public boolean isMeasureWithLargestChildEnabled() {
    return this.mUseLargestChild;
  }
  
  public void layoutHorizontal(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    byte b1;
    byte b2;
    boolean bool2 = V.b((View)this);
    int k = getPaddingTop();
    int i1 = paramInt4 - paramInt2;
    int n = getPaddingBottom();
    int m = getPaddingBottom();
    int j = getVirtualChildCount();
    paramInt2 = this.mGravity;
    paramInt4 = paramInt2 & 0x70;
    boolean bool1 = this.mBaselineAligned;
    int[] arrayOfInt1 = this.mMaxAscent;
    int[] arrayOfInt2 = this.mMaxDescent;
    paramInt2 = x.b(0x800007 & paramInt2, h0.A((View)this));
    boolean bool = true;
    if (paramInt2 != 1) {
      if (paramInt2 != 5) {
        paramInt2 = getPaddingLeft();
      } else {
        paramInt2 = getPaddingLeft() + paramInt3 - paramInt1 - this.mTotalLength;
      } 
    } else {
      paramInt2 = getPaddingLeft() + (paramInt3 - paramInt1 - this.mTotalLength) / 2;
    } 
    if (bool2) {
      b2 = j - 1;
      b1 = -1;
    } else {
      b2 = 0;
      b1 = 1;
    } 
    int i = 0;
    paramInt3 = paramInt4;
    paramInt4 = k;
    while (i < j) {
      int i2 = b2 + b1 * i;
      View view = getVirtualChildAt(i2);
      if (view == null) {
        paramInt2 += measureNullChild(i2);
      } else if (view.getVisibility() != 8) {
        int i5 = view.getMeasuredWidth();
        int i6 = view.getMeasuredHeight();
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        if (bool1 && layoutParams.height != -1) {
          i3 = view.getBaseline();
        } else {
          i3 = -1;
        } 
        int i4 = layoutParams.gravity;
        paramInt1 = i4;
        if (i4 < 0)
          paramInt1 = paramInt3; 
        paramInt1 &= 0x70;
        if (paramInt1 != 16) {
          if (paramInt1 != 48) {
            if (paramInt1 != 80) {
              paramInt1 = paramInt4;
            } else {
              i4 = i1 - n - i6 - layoutParams.bottomMargin;
              paramInt1 = i4;
              if (i3 != -1) {
                paramInt1 = view.getMeasuredHeight();
                paramInt1 = i4 - arrayOfInt2[2] - paramInt1 - i3;
              } 
            } 
          } else {
            i4 = layoutParams.topMargin + paramInt4;
            paramInt1 = i4;
            if (i3 != -1)
              paramInt1 = i4 + arrayOfInt1[1] - i3; 
          } 
        } else {
          paramInt1 = (i1 - k - m - i6) / 2 + paramInt4 + layoutParams.topMargin - layoutParams.bottomMargin;
        } 
        bool = true;
        int i3 = paramInt2;
        if (hasDividerBeforeChildAt(i2))
          i3 = paramInt2 + this.mDividerWidth; 
        paramInt2 = layoutParams.leftMargin + i3;
        setChildFrame(view, paramInt2 + getLocationOffset(view), paramInt1, i5, i6);
        paramInt1 = layoutParams.rightMargin;
        i3 = getNextLocationOffset(view);
        i += getChildrenSkipCount(view, i2);
        paramInt2 += i5 + paramInt1 + i3;
      } else {
        bool = true;
      } 
      i++;
    } 
  }
  
  public void layoutVertical(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    int i = getPaddingLeft();
    int i1 = paramInt3 - paramInt1;
    int m = getPaddingRight();
    int j = getPaddingRight();
    int n = getVirtualChildCount();
    int k = this.mGravity;
    paramInt1 = k & 0x70;
    if (paramInt1 != 16) {
      if (paramInt1 != 80) {
        paramInt1 = getPaddingTop();
      } else {
        paramInt1 = getPaddingTop() + paramInt4 - paramInt2 - this.mTotalLength;
      } 
    } else {
      paramInt1 = getPaddingTop() + (paramInt4 - paramInt2 - this.mTotalLength) / 2;
    } 
    for (paramInt2 = 0; paramInt2 < n; paramInt2++) {
      View view = getVirtualChildAt(paramInt2);
      if (view == null) {
        paramInt3 = paramInt1 + measureNullChild(paramInt2);
      } else {
        paramInt3 = paramInt1;
        if (view.getVisibility() != 8) {
          int i3 = view.getMeasuredWidth();
          int i2 = view.getMeasuredHeight();
          LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
          paramInt4 = layoutParams.gravity;
          paramInt3 = paramInt4;
          if (paramInt4 < 0)
            paramInt3 = k & 0x800007; 
          paramInt3 = x.b(paramInt3, h0.A((View)this)) & 0x7;
          if (paramInt3 != 1) {
            if (paramInt3 != 5) {
              paramInt3 = layoutParams.leftMargin + i;
            } else {
              paramInt3 = i1 - m - i3;
              paramInt4 = layoutParams.rightMargin;
              paramInt3 -= paramInt4;
            } 
          } else {
            paramInt3 = (i1 - i - j - i3) / 2 + i + layoutParams.leftMargin;
            paramInt4 = layoutParams.rightMargin;
            paramInt3 -= paramInt4;
          } 
          paramInt4 = paramInt1;
          if (hasDividerBeforeChildAt(paramInt2))
            paramInt4 = paramInt1 + this.mDividerHeight; 
          paramInt1 = paramInt4 + layoutParams.topMargin;
          setChildFrame(view, paramInt3, paramInt1 + getLocationOffset(view), i3, i2);
          paramInt3 = layoutParams.bottomMargin;
          paramInt4 = getNextLocationOffset(view);
          paramInt2 += getChildrenSkipCount(view, paramInt2);
          paramInt1 += i2 + paramInt3 + paramInt4;
          continue;
        } 
      } 
      paramInt1 = paramInt3;
      continue;
    } 
  }
  
  public void measureChildBeforeLayout(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    measureChildWithMargins(paramView, paramInt2, paramInt3, paramInt4, paramInt5);
  }
  
  public void measureHorizontal(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: iconst_0
    //   2: putfield mTotalLength : I
    //   5: aload_0
    //   6: invokevirtual getVirtualChildCount : ()I
    //   9: istore #16
    //   11: iload_1
    //   12: invokestatic getMode : (I)I
    //   15: istore #23
    //   17: iload_2
    //   18: invokestatic getMode : (I)I
    //   21: istore #22
    //   23: aload_0
    //   24: getfield mMaxAscent : [I
    //   27: ifnull -> 37
    //   30: aload_0
    //   31: getfield mMaxDescent : [I
    //   34: ifnonnull -> 51
    //   37: aload_0
    //   38: iconst_4
    //   39: newarray int
    //   41: putfield mMaxAscent : [I
    //   44: aload_0
    //   45: iconst_4
    //   46: newarray int
    //   48: putfield mMaxDescent : [I
    //   51: aload_0
    //   52: getfield mMaxAscent : [I
    //   55: astore #28
    //   57: aload_0
    //   58: getfield mMaxDescent : [I
    //   61: astore #27
    //   63: aload #28
    //   65: iconst_3
    //   66: iconst_m1
    //   67: iastore
    //   68: aload #28
    //   70: iconst_2
    //   71: iconst_m1
    //   72: iastore
    //   73: aload #28
    //   75: iconst_1
    //   76: iconst_m1
    //   77: iastore
    //   78: aload #28
    //   80: iconst_0
    //   81: iconst_m1
    //   82: iastore
    //   83: aload #27
    //   85: iconst_3
    //   86: iconst_m1
    //   87: iastore
    //   88: aload #27
    //   90: iconst_2
    //   91: iconst_m1
    //   92: iastore
    //   93: aload #27
    //   95: iconst_1
    //   96: iconst_m1
    //   97: iastore
    //   98: aload #27
    //   100: iconst_0
    //   101: iconst_m1
    //   102: iastore
    //   103: aload_0
    //   104: getfield mBaselineAligned : Z
    //   107: istore #25
    //   109: aload_0
    //   110: getfield mUseLargestChild : Z
    //   113: istore #26
    //   115: ldc 1073741824
    //   117: istore #14
    //   119: iload #23
    //   121: ldc 1073741824
    //   123: if_icmpne -> 132
    //   126: iconst_1
    //   127: istore #15
    //   129: goto -> 135
    //   132: iconst_0
    //   133: istore #15
    //   135: iconst_0
    //   136: istore #9
    //   138: iconst_0
    //   139: istore #8
    //   141: iload #8
    //   143: istore #10
    //   145: iload #10
    //   147: istore #6
    //   149: iload #6
    //   151: istore #12
    //   153: iload #12
    //   155: istore #13
    //   157: iload #13
    //   159: istore #7
    //   161: iload #7
    //   163: istore #11
    //   165: iconst_1
    //   166: istore #5
    //   168: fconst_0
    //   169: fstore_3
    //   170: iload #9
    //   172: iload #16
    //   174: if_icmpge -> 892
    //   177: aload_0
    //   178: iload #9
    //   180: invokevirtual getVirtualChildAt : (I)Landroid/view/View;
    //   183: astore #30
    //   185: aload #30
    //   187: ifnonnull -> 224
    //   190: aload_0
    //   191: aload_0
    //   192: getfield mTotalLength : I
    //   195: aload_0
    //   196: iload #9
    //   198: invokevirtual measureNullChild : (I)I
    //   201: iadd
    //   202: putfield mTotalLength : I
    //   205: iload #9
    //   207: istore #17
    //   209: iload #14
    //   211: istore #9
    //   213: iload #17
    //   215: istore #14
    //   217: iload #7
    //   219: istore #17
    //   221: goto -> 871
    //   224: aload #30
    //   226: invokevirtual getVisibility : ()I
    //   229: bipush #8
    //   231: if_icmpne -> 250
    //   234: iload #9
    //   236: aload_0
    //   237: aload #30
    //   239: iload #9
    //   241: invokevirtual getChildrenSkipCount : (Landroid/view/View;I)I
    //   244: iadd
    //   245: istore #9
    //   247: goto -> 205
    //   250: aload_0
    //   251: iload #9
    //   253: invokevirtual hasDividerBeforeChildAt : (I)Z
    //   256: ifeq -> 272
    //   259: aload_0
    //   260: aload_0
    //   261: getfield mTotalLength : I
    //   264: aload_0
    //   265: getfield mDividerWidth : I
    //   268: iadd
    //   269: putfield mTotalLength : I
    //   272: aload #30
    //   274: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   277: checkcast androidx/appcompat/widget/LinearLayoutCompat$LayoutParams
    //   280: astore #29
    //   282: aload #29
    //   284: getfield weight : F
    //   287: fstore #4
    //   289: fload_3
    //   290: fload #4
    //   292: fadd
    //   293: fstore_3
    //   294: iload #23
    //   296: iload #14
    //   298: if_icmpne -> 407
    //   301: aload #29
    //   303: getfield width : I
    //   306: ifne -> 407
    //   309: fload #4
    //   311: fconst_0
    //   312: fcmpl
    //   313: ifle -> 407
    //   316: iload #15
    //   318: ifeq -> 344
    //   321: aload_0
    //   322: aload_0
    //   323: getfield mTotalLength : I
    //   326: aload #29
    //   328: getfield leftMargin : I
    //   331: aload #29
    //   333: getfield rightMargin : I
    //   336: iadd
    //   337: iadd
    //   338: putfield mTotalLength : I
    //   341: goto -> 373
    //   344: aload_0
    //   345: getfield mTotalLength : I
    //   348: istore #14
    //   350: aload_0
    //   351: iload #14
    //   353: aload #29
    //   355: getfield leftMargin : I
    //   358: iload #14
    //   360: iadd
    //   361: aload #29
    //   363: getfield rightMargin : I
    //   366: iadd
    //   367: invokestatic max : (II)I
    //   370: putfield mTotalLength : I
    //   373: iload #25
    //   375: ifeq -> 401
    //   378: iconst_0
    //   379: iconst_0
    //   380: invokestatic makeMeasureSpec : (II)I
    //   383: istore #14
    //   385: aload #30
    //   387: iload #14
    //   389: iload #14
    //   391: invokevirtual measure : (II)V
    //   394: iload #8
    //   396: istore #14
    //   398: goto -> 588
    //   401: iconst_1
    //   402: istore #13
    //   404: goto -> 592
    //   407: aload #29
    //   409: getfield width : I
    //   412: ifne -> 435
    //   415: fload #4
    //   417: fconst_0
    //   418: fcmpl
    //   419: ifle -> 435
    //   422: aload #29
    //   424: bipush #-2
    //   426: putfield width : I
    //   429: iconst_0
    //   430: istore #14
    //   432: goto -> 440
    //   435: ldc_w -2147483648
    //   438: istore #14
    //   440: fload_3
    //   441: fconst_0
    //   442: fcmpl
    //   443: ifne -> 455
    //   446: aload_0
    //   447: getfield mTotalLength : I
    //   450: istore #17
    //   452: goto -> 458
    //   455: iconst_0
    //   456: istore #17
    //   458: aload_0
    //   459: aload #30
    //   461: iload #9
    //   463: iload_1
    //   464: iload #17
    //   466: iload_2
    //   467: iconst_0
    //   468: invokevirtual measureChildBeforeLayout : (Landroid/view/View;IIIII)V
    //   471: iload #14
    //   473: ldc_w -2147483648
    //   476: if_icmpeq -> 486
    //   479: aload #29
    //   481: iload #14
    //   483: putfield width : I
    //   486: aload #30
    //   488: invokevirtual getMeasuredWidth : ()I
    //   491: istore #17
    //   493: iload #15
    //   495: ifeq -> 531
    //   498: aload_0
    //   499: aload_0
    //   500: getfield mTotalLength : I
    //   503: aload #29
    //   505: getfield leftMargin : I
    //   508: iload #17
    //   510: iadd
    //   511: aload #29
    //   513: getfield rightMargin : I
    //   516: iadd
    //   517: aload_0
    //   518: aload #30
    //   520: invokevirtual getNextLocationOffset : (Landroid/view/View;)I
    //   523: iadd
    //   524: iadd
    //   525: putfield mTotalLength : I
    //   528: goto -> 570
    //   531: aload_0
    //   532: getfield mTotalLength : I
    //   535: istore #14
    //   537: aload_0
    //   538: iload #14
    //   540: iload #14
    //   542: iload #17
    //   544: iadd
    //   545: aload #29
    //   547: getfield leftMargin : I
    //   550: iadd
    //   551: aload #29
    //   553: getfield rightMargin : I
    //   556: iadd
    //   557: aload_0
    //   558: aload #30
    //   560: invokevirtual getNextLocationOffset : (Landroid/view/View;)I
    //   563: iadd
    //   564: invokestatic max : (II)I
    //   567: putfield mTotalLength : I
    //   570: iload #8
    //   572: istore #14
    //   574: iload #26
    //   576: ifeq -> 588
    //   579: iload #17
    //   581: iload #8
    //   583: invokestatic max : (II)I
    //   586: istore #14
    //   588: iload #14
    //   590: istore #8
    //   592: ldc 1073741824
    //   594: istore #19
    //   596: iload #22
    //   598: ldc 1073741824
    //   600: if_icmpeq -> 621
    //   603: aload #29
    //   605: getfield height : I
    //   608: iconst_m1
    //   609: if_icmpne -> 621
    //   612: iconst_1
    //   613: istore #14
    //   615: iconst_1
    //   616: istore #11
    //   618: goto -> 624
    //   621: iconst_0
    //   622: istore #14
    //   624: aload #29
    //   626: getfield topMargin : I
    //   629: aload #29
    //   631: getfield bottomMargin : I
    //   634: iadd
    //   635: istore #17
    //   637: aload #30
    //   639: invokevirtual getMeasuredHeight : ()I
    //   642: iload #17
    //   644: iadd
    //   645: istore #18
    //   647: iload #7
    //   649: aload #30
    //   651: invokevirtual getMeasuredState : ()I
    //   654: invokestatic combineMeasuredStates : (II)I
    //   657: istore #20
    //   659: iload #25
    //   661: ifeq -> 746
    //   664: aload #30
    //   666: invokevirtual getBaseline : ()I
    //   669: istore #24
    //   671: iload #24
    //   673: iconst_m1
    //   674: if_icmpeq -> 746
    //   677: aload #29
    //   679: getfield gravity : I
    //   682: istore #21
    //   684: iload #21
    //   686: istore #7
    //   688: iload #21
    //   690: ifge -> 699
    //   693: aload_0
    //   694: getfield mGravity : I
    //   697: istore #7
    //   699: iload #7
    //   701: bipush #112
    //   703: iand
    //   704: iconst_4
    //   705: ishr
    //   706: bipush #-2
    //   708: iand
    //   709: iconst_1
    //   710: ishr
    //   711: istore #7
    //   713: aload #28
    //   715: iload #7
    //   717: aload #28
    //   719: iload #7
    //   721: iaload
    //   722: iload #24
    //   724: invokestatic max : (II)I
    //   727: iastore
    //   728: aload #27
    //   730: iload #7
    //   732: aload #27
    //   734: iload #7
    //   736: iaload
    //   737: iload #18
    //   739: iload #24
    //   741: isub
    //   742: invokestatic max : (II)I
    //   745: iastore
    //   746: iload #10
    //   748: iload #18
    //   750: invokestatic max : (II)I
    //   753: istore #10
    //   755: iload #5
    //   757: ifeq -> 775
    //   760: aload #29
    //   762: getfield height : I
    //   765: iconst_m1
    //   766: if_icmpne -> 775
    //   769: iconst_1
    //   770: istore #5
    //   772: goto -> 778
    //   775: iconst_0
    //   776: istore #5
    //   778: aload #29
    //   780: getfield weight : F
    //   783: fconst_0
    //   784: fcmpl
    //   785: ifle -> 815
    //   788: iload #14
    //   790: ifeq -> 796
    //   793: goto -> 803
    //   796: iload #18
    //   798: istore #17
    //   800: goto -> 793
    //   803: iload #12
    //   805: iload #17
    //   807: invokestatic max : (II)I
    //   810: istore #7
    //   812: goto -> 846
    //   815: iload #14
    //   817: ifeq -> 823
    //   820: goto -> 830
    //   823: iload #18
    //   825: istore #17
    //   827: goto -> 820
    //   830: iload #6
    //   832: iload #17
    //   834: invokestatic max : (II)I
    //   837: istore #6
    //   839: iload #12
    //   841: istore #7
    //   843: goto -> 812
    //   846: aload_0
    //   847: aload #30
    //   849: iload #9
    //   851: invokevirtual getChildrenSkipCount : (Landroid/view/View;I)I
    //   854: iload #9
    //   856: iadd
    //   857: istore #14
    //   859: iload #20
    //   861: istore #17
    //   863: iload #7
    //   865: istore #12
    //   867: iload #19
    //   869: istore #9
    //   871: iload #9
    //   873: istore #7
    //   875: iload #14
    //   877: iconst_1
    //   878: iadd
    //   879: istore #9
    //   881: iload #7
    //   883: istore #14
    //   885: iload #17
    //   887: istore #7
    //   889: goto -> 170
    //   892: aload_0
    //   893: getfield mTotalLength : I
    //   896: ifle -> 921
    //   899: aload_0
    //   900: iload #16
    //   902: invokevirtual hasDividerBeforeChildAt : (I)Z
    //   905: ifeq -> 921
    //   908: aload_0
    //   909: aload_0
    //   910: getfield mTotalLength : I
    //   913: aload_0
    //   914: getfield mDividerWidth : I
    //   917: iadd
    //   918: putfield mTotalLength : I
    //   921: aload #28
    //   923: iconst_1
    //   924: iaload
    //   925: istore #9
    //   927: iload #9
    //   929: iconst_m1
    //   930: if_icmpne -> 963
    //   933: aload #28
    //   935: iconst_0
    //   936: iaload
    //   937: iconst_m1
    //   938: if_icmpne -> 963
    //   941: aload #28
    //   943: iconst_2
    //   944: iaload
    //   945: iconst_m1
    //   946: if_icmpne -> 963
    //   949: aload #28
    //   951: iconst_3
    //   952: iaload
    //   953: iconst_m1
    //   954: if_icmpeq -> 960
    //   957: goto -> 963
    //   960: goto -> 1019
    //   963: iload #10
    //   965: aload #28
    //   967: iconst_3
    //   968: iaload
    //   969: aload #28
    //   971: iconst_0
    //   972: iaload
    //   973: iload #9
    //   975: aload #28
    //   977: iconst_2
    //   978: iaload
    //   979: invokestatic max : (II)I
    //   982: invokestatic max : (II)I
    //   985: invokestatic max : (II)I
    //   988: aload #27
    //   990: iconst_3
    //   991: iaload
    //   992: aload #27
    //   994: iconst_0
    //   995: iaload
    //   996: aload #27
    //   998: iconst_1
    //   999: iaload
    //   1000: aload #27
    //   1002: iconst_2
    //   1003: iaload
    //   1004: invokestatic max : (II)I
    //   1007: invokestatic max : (II)I
    //   1010: invokestatic max : (II)I
    //   1013: iadd
    //   1014: invokestatic max : (II)I
    //   1017: istore #10
    //   1019: iload #10
    //   1021: istore #14
    //   1023: iload #26
    //   1025: ifeq -> 1048
    //   1028: iload #23
    //   1030: ldc_w -2147483648
    //   1033: if_icmpeq -> 1045
    //   1036: iload #10
    //   1038: istore #14
    //   1040: iload #23
    //   1042: ifne -> 1048
    //   1045: goto -> 1051
    //   1048: goto -> 1220
    //   1051: aload_0
    //   1052: iconst_0
    //   1053: putfield mTotalLength : I
    //   1056: iconst_0
    //   1057: istore #9
    //   1059: iload #10
    //   1061: istore #14
    //   1063: iload #9
    //   1065: iload #16
    //   1067: if_icmpge -> 1048
    //   1070: aload_0
    //   1071: iload #9
    //   1073: invokevirtual getVirtualChildAt : (I)Landroid/view/View;
    //   1076: astore #29
    //   1078: aload #29
    //   1080: ifnonnull -> 1101
    //   1083: aload_0
    //   1084: aload_0
    //   1085: getfield mTotalLength : I
    //   1088: aload_0
    //   1089: iload #9
    //   1091: invokevirtual measureNullChild : (I)I
    //   1094: iadd
    //   1095: putfield mTotalLength : I
    //   1098: goto -> 1124
    //   1101: aload #29
    //   1103: invokevirtual getVisibility : ()I
    //   1106: bipush #8
    //   1108: if_icmpne -> 1127
    //   1111: iload #9
    //   1113: aload_0
    //   1114: aload #29
    //   1116: iload #9
    //   1118: invokevirtual getChildrenSkipCount : (Landroid/view/View;I)I
    //   1121: iadd
    //   1122: istore #9
    //   1124: goto -> 1214
    //   1127: aload #29
    //   1129: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1132: checkcast androidx/appcompat/widget/LinearLayoutCompat$LayoutParams
    //   1135: astore #30
    //   1137: iload #15
    //   1139: ifeq -> 1175
    //   1142: aload_0
    //   1143: aload_0
    //   1144: getfield mTotalLength : I
    //   1147: aload #30
    //   1149: getfield leftMargin : I
    //   1152: iload #8
    //   1154: iadd
    //   1155: aload #30
    //   1157: getfield rightMargin : I
    //   1160: iadd
    //   1161: aload_0
    //   1162: aload #29
    //   1164: invokevirtual getNextLocationOffset : (Landroid/view/View;)I
    //   1167: iadd
    //   1168: iadd
    //   1169: putfield mTotalLength : I
    //   1172: goto -> 1124
    //   1175: aload_0
    //   1176: getfield mTotalLength : I
    //   1179: istore #14
    //   1181: aload_0
    //   1182: iload #14
    //   1184: iload #14
    //   1186: iload #8
    //   1188: iadd
    //   1189: aload #30
    //   1191: getfield leftMargin : I
    //   1194: iadd
    //   1195: aload #30
    //   1197: getfield rightMargin : I
    //   1200: iadd
    //   1201: aload_0
    //   1202: aload #29
    //   1204: invokevirtual getNextLocationOffset : (Landroid/view/View;)I
    //   1207: iadd
    //   1208: invokestatic max : (II)I
    //   1211: putfield mTotalLength : I
    //   1214: iinc #9, 1
    //   1217: goto -> 1059
    //   1220: aload_0
    //   1221: getfield mTotalLength : I
    //   1224: aload_0
    //   1225: invokevirtual getPaddingLeft : ()I
    //   1228: aload_0
    //   1229: invokevirtual getPaddingRight : ()I
    //   1232: iadd
    //   1233: iadd
    //   1234: istore #9
    //   1236: aload_0
    //   1237: iload #9
    //   1239: putfield mTotalLength : I
    //   1242: iload #9
    //   1244: aload_0
    //   1245: invokevirtual getSuggestedMinimumWidth : ()I
    //   1248: invokestatic max : (II)I
    //   1251: iload_1
    //   1252: iconst_0
    //   1253: invokestatic resolveSizeAndState : (III)I
    //   1256: istore #18
    //   1258: ldc_w 16777215
    //   1261: iload #18
    //   1263: iand
    //   1264: aload_0
    //   1265: getfield mTotalLength : I
    //   1268: isub
    //   1269: istore #17
    //   1271: iload #13
    //   1273: ifne -> 1414
    //   1276: iload #17
    //   1278: ifeq -> 1290
    //   1281: fload_3
    //   1282: fconst_0
    //   1283: fcmpl
    //   1284: ifle -> 1290
    //   1287: goto -> 1414
    //   1290: iload #6
    //   1292: iload #12
    //   1294: invokestatic max : (II)I
    //   1297: istore #10
    //   1299: iload #26
    //   1301: ifeq -> 1391
    //   1304: iload #23
    //   1306: ldc 1073741824
    //   1308: if_icmpeq -> 1391
    //   1311: iconst_0
    //   1312: istore #6
    //   1314: iload #6
    //   1316: iload #16
    //   1318: if_icmpge -> 1391
    //   1321: aload_0
    //   1322: iload #6
    //   1324: invokevirtual getVirtualChildAt : (I)Landroid/view/View;
    //   1327: astore #27
    //   1329: aload #27
    //   1331: ifnull -> 1385
    //   1334: aload #27
    //   1336: invokevirtual getVisibility : ()I
    //   1339: bipush #8
    //   1341: if_icmpne -> 1347
    //   1344: goto -> 1385
    //   1347: aload #27
    //   1349: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1352: checkcast androidx/appcompat/widget/LinearLayoutCompat$LayoutParams
    //   1355: getfield weight : F
    //   1358: fconst_0
    //   1359: fcmpl
    //   1360: ifle -> 1385
    //   1363: aload #27
    //   1365: iload #8
    //   1367: ldc 1073741824
    //   1369: invokestatic makeMeasureSpec : (II)I
    //   1372: aload #27
    //   1374: invokevirtual getMeasuredHeight : ()I
    //   1377: ldc 1073741824
    //   1379: invokestatic makeMeasureSpec : (II)I
    //   1382: invokevirtual measure : (II)V
    //   1385: iinc #6, 1
    //   1388: goto -> 1314
    //   1391: iload #16
    //   1393: istore #9
    //   1395: iload #10
    //   1397: istore #6
    //   1399: iload #7
    //   1401: istore #8
    //   1403: iload #14
    //   1405: istore #7
    //   1407: iload #5
    //   1409: istore #10
    //   1411: goto -> 2190
    //   1414: aload_0
    //   1415: getfield mWeightSum : F
    //   1418: fstore #4
    //   1420: fload #4
    //   1422: fconst_0
    //   1423: fcmpl
    //   1424: ifle -> 1430
    //   1427: fload #4
    //   1429: fstore_3
    //   1430: aload #28
    //   1432: iconst_3
    //   1433: iconst_m1
    //   1434: iastore
    //   1435: aload #28
    //   1437: iconst_2
    //   1438: iconst_m1
    //   1439: iastore
    //   1440: aload #28
    //   1442: iconst_1
    //   1443: iconst_m1
    //   1444: iastore
    //   1445: aload #28
    //   1447: iconst_0
    //   1448: iconst_m1
    //   1449: iastore
    //   1450: aload #27
    //   1452: iconst_3
    //   1453: iconst_m1
    //   1454: iastore
    //   1455: aload #27
    //   1457: iconst_2
    //   1458: iconst_m1
    //   1459: iastore
    //   1460: aload #27
    //   1462: iconst_1
    //   1463: iconst_m1
    //   1464: iastore
    //   1465: aload #27
    //   1467: iconst_0
    //   1468: iconst_m1
    //   1469: iastore
    //   1470: aload_0
    //   1471: iconst_0
    //   1472: putfield mTotalLength : I
    //   1475: iconst_m1
    //   1476: istore #10
    //   1478: iload #7
    //   1480: istore #9
    //   1482: iconst_0
    //   1483: istore #13
    //   1485: iload #5
    //   1487: istore #8
    //   1489: iload #16
    //   1491: istore #7
    //   1493: iload #9
    //   1495: istore #5
    //   1497: iload #6
    //   1499: istore #9
    //   1501: iload #17
    //   1503: istore #6
    //   1505: iload #13
    //   1507: iload #7
    //   1509: if_icmpge -> 2046
    //   1512: aload_0
    //   1513: iload #13
    //   1515: invokevirtual getVirtualChildAt : (I)Landroid/view/View;
    //   1518: astore #30
    //   1520: aload #30
    //   1522: ifnull -> 1535
    //   1525: aload #30
    //   1527: invokevirtual getVisibility : ()I
    //   1530: bipush #8
    //   1532: if_icmpne -> 1542
    //   1535: iload #5
    //   1537: istore #12
    //   1539: goto -> 2036
    //   1542: aload #30
    //   1544: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1547: checkcast androidx/appcompat/widget/LinearLayoutCompat$LayoutParams
    //   1550: astore #29
    //   1552: aload #29
    //   1554: getfield weight : F
    //   1557: fstore #4
    //   1559: fload #4
    //   1561: fconst_0
    //   1562: fcmpl
    //   1563: ifle -> 1730
    //   1566: iload #6
    //   1568: i2f
    //   1569: fload #4
    //   1571: fmul
    //   1572: fload_3
    //   1573: fdiv
    //   1574: f2i
    //   1575: istore #14
    //   1577: iload_2
    //   1578: aload_0
    //   1579: invokevirtual getPaddingTop : ()I
    //   1582: aload_0
    //   1583: invokevirtual getPaddingBottom : ()I
    //   1586: iadd
    //   1587: aload #29
    //   1589: getfield topMargin : I
    //   1592: iadd
    //   1593: aload #29
    //   1595: getfield bottomMargin : I
    //   1598: iadd
    //   1599: aload #29
    //   1601: getfield height : I
    //   1604: invokestatic getChildMeasureSpec : (III)I
    //   1607: istore #17
    //   1609: aload #29
    //   1611: getfield width : I
    //   1614: ifne -> 1659
    //   1617: iload #23
    //   1619: ldc 1073741824
    //   1621: if_icmpeq -> 1627
    //   1624: goto -> 1659
    //   1627: iload #14
    //   1629: ifle -> 1639
    //   1632: iload #14
    //   1634: istore #12
    //   1636: goto -> 1642
    //   1639: iconst_0
    //   1640: istore #12
    //   1642: aload #30
    //   1644: iload #12
    //   1646: ldc 1073741824
    //   1648: invokestatic makeMeasureSpec : (II)I
    //   1651: iload #17
    //   1653: invokevirtual measure : (II)V
    //   1656: goto -> 1695
    //   1659: aload #30
    //   1661: invokevirtual getMeasuredWidth : ()I
    //   1664: iload #14
    //   1666: iadd
    //   1667: istore #16
    //   1669: iload #16
    //   1671: istore #12
    //   1673: iload #16
    //   1675: ifge -> 1681
    //   1678: iconst_0
    //   1679: istore #12
    //   1681: aload #30
    //   1683: iload #12
    //   1685: ldc 1073741824
    //   1687: invokestatic makeMeasureSpec : (II)I
    //   1690: iload #17
    //   1692: invokevirtual measure : (II)V
    //   1695: iload #5
    //   1697: aload #30
    //   1699: invokevirtual getMeasuredState : ()I
    //   1702: ldc_w -16777216
    //   1705: iand
    //   1706: invokestatic combineMeasuredStates : (II)I
    //   1709: istore #12
    //   1711: fload_3
    //   1712: fload #4
    //   1714: fsub
    //   1715: fstore_3
    //   1716: iload #6
    //   1718: iload #14
    //   1720: isub
    //   1721: istore #5
    //   1723: iload #12
    //   1725: istore #6
    //   1727: goto -> 1742
    //   1730: iload #6
    //   1732: istore #12
    //   1734: iload #5
    //   1736: istore #6
    //   1738: iload #12
    //   1740: istore #5
    //   1742: iload #15
    //   1744: ifeq -> 1783
    //   1747: aload_0
    //   1748: aload_0
    //   1749: getfield mTotalLength : I
    //   1752: aload #30
    //   1754: invokevirtual getMeasuredWidth : ()I
    //   1757: aload #29
    //   1759: getfield leftMargin : I
    //   1762: iadd
    //   1763: aload #29
    //   1765: getfield rightMargin : I
    //   1768: iadd
    //   1769: aload_0
    //   1770: aload #30
    //   1772: invokevirtual getNextLocationOffset : (Landroid/view/View;)I
    //   1775: iadd
    //   1776: iadd
    //   1777: putfield mTotalLength : I
    //   1780: goto -> 1828
    //   1783: aload_0
    //   1784: getfield mTotalLength : I
    //   1787: istore #12
    //   1789: aload_0
    //   1790: iload #12
    //   1792: aload #30
    //   1794: invokevirtual getMeasuredWidth : ()I
    //   1797: iload #12
    //   1799: iadd
    //   1800: aload #29
    //   1802: getfield leftMargin : I
    //   1805: iadd
    //   1806: aload #29
    //   1808: getfield rightMargin : I
    //   1811: iadd
    //   1812: aload_0
    //   1813: aload #30
    //   1815: invokevirtual getNextLocationOffset : (Landroid/view/View;)I
    //   1818: iadd
    //   1819: invokestatic max : (II)I
    //   1822: putfield mTotalLength : I
    //   1825: goto -> 1780
    //   1828: iload #22
    //   1830: ldc 1073741824
    //   1832: if_icmpeq -> 1850
    //   1835: aload #29
    //   1837: getfield height : I
    //   1840: iconst_m1
    //   1841: if_icmpne -> 1850
    //   1844: iconst_1
    //   1845: istore #12
    //   1847: goto -> 1853
    //   1850: iconst_0
    //   1851: istore #12
    //   1853: aload #29
    //   1855: getfield topMargin : I
    //   1858: aload #29
    //   1860: getfield bottomMargin : I
    //   1863: iadd
    //   1864: istore #17
    //   1866: aload #30
    //   1868: invokevirtual getMeasuredHeight : ()I
    //   1871: iload #17
    //   1873: iadd
    //   1874: istore #16
    //   1876: iload #10
    //   1878: iload #16
    //   1880: invokestatic max : (II)I
    //   1883: istore #14
    //   1885: iload #12
    //   1887: ifeq -> 1897
    //   1890: iload #17
    //   1892: istore #10
    //   1894: goto -> 1901
    //   1897: iload #16
    //   1899: istore #10
    //   1901: iload #9
    //   1903: iload #10
    //   1905: invokestatic max : (II)I
    //   1908: istore #10
    //   1910: iload #8
    //   1912: ifeq -> 1930
    //   1915: aload #29
    //   1917: getfield height : I
    //   1920: iconst_m1
    //   1921: if_icmpne -> 1930
    //   1924: iconst_1
    //   1925: istore #8
    //   1927: goto -> 1933
    //   1930: iconst_0
    //   1931: istore #8
    //   1933: iload #25
    //   1935: ifeq -> 2020
    //   1938: aload #30
    //   1940: invokevirtual getBaseline : ()I
    //   1943: istore #17
    //   1945: iload #17
    //   1947: iconst_m1
    //   1948: if_icmpeq -> 2020
    //   1951: aload #29
    //   1953: getfield gravity : I
    //   1956: istore #12
    //   1958: iload #12
    //   1960: istore #9
    //   1962: iload #12
    //   1964: ifge -> 1973
    //   1967: aload_0
    //   1968: getfield mGravity : I
    //   1971: istore #9
    //   1973: iload #9
    //   1975: bipush #112
    //   1977: iand
    //   1978: iconst_4
    //   1979: ishr
    //   1980: bipush #-2
    //   1982: iand
    //   1983: iconst_1
    //   1984: ishr
    //   1985: istore #9
    //   1987: aload #28
    //   1989: iload #9
    //   1991: aload #28
    //   1993: iload #9
    //   1995: iaload
    //   1996: iload #17
    //   1998: invokestatic max : (II)I
    //   2001: iastore
    //   2002: aload #27
    //   2004: iload #9
    //   2006: aload #27
    //   2008: iload #9
    //   2010: iaload
    //   2011: iload #16
    //   2013: iload #17
    //   2015: isub
    //   2016: invokestatic max : (II)I
    //   2019: iastore
    //   2020: iload #10
    //   2022: istore #9
    //   2024: iload #6
    //   2026: istore #12
    //   2028: iload #14
    //   2030: istore #10
    //   2032: iload #5
    //   2034: istore #6
    //   2036: iinc #13, 1
    //   2039: iload #12
    //   2041: istore #5
    //   2043: goto -> 1505
    //   2046: aload_0
    //   2047: aload_0
    //   2048: getfield mTotalLength : I
    //   2051: aload_0
    //   2052: invokevirtual getPaddingLeft : ()I
    //   2055: aload_0
    //   2056: invokevirtual getPaddingRight : ()I
    //   2059: iadd
    //   2060: iadd
    //   2061: putfield mTotalLength : I
    //   2064: aload #28
    //   2066: iconst_1
    //   2067: iaload
    //   2068: istore #6
    //   2070: iload #6
    //   2072: iconst_m1
    //   2073: if_icmpne -> 2110
    //   2076: aload #28
    //   2078: iconst_0
    //   2079: iaload
    //   2080: iconst_m1
    //   2081: if_icmpne -> 2110
    //   2084: aload #28
    //   2086: iconst_2
    //   2087: iaload
    //   2088: iconst_m1
    //   2089: if_icmpne -> 2110
    //   2092: aload #28
    //   2094: iconst_3
    //   2095: iaload
    //   2096: iconst_m1
    //   2097: if_icmpeq -> 2103
    //   2100: goto -> 2110
    //   2103: iload #10
    //   2105: istore #6
    //   2107: goto -> 2166
    //   2110: iload #10
    //   2112: aload #28
    //   2114: iconst_3
    //   2115: iaload
    //   2116: aload #28
    //   2118: iconst_0
    //   2119: iaload
    //   2120: iload #6
    //   2122: aload #28
    //   2124: iconst_2
    //   2125: iaload
    //   2126: invokestatic max : (II)I
    //   2129: invokestatic max : (II)I
    //   2132: invokestatic max : (II)I
    //   2135: aload #27
    //   2137: iconst_3
    //   2138: iaload
    //   2139: aload #27
    //   2141: iconst_0
    //   2142: iaload
    //   2143: aload #27
    //   2145: iconst_1
    //   2146: iaload
    //   2147: aload #27
    //   2149: iconst_2
    //   2150: iaload
    //   2151: invokestatic max : (II)I
    //   2154: invokestatic max : (II)I
    //   2157: invokestatic max : (II)I
    //   2160: iadd
    //   2161: invokestatic max : (II)I
    //   2164: istore #6
    //   2166: iload #6
    //   2168: istore #12
    //   2170: iload #9
    //   2172: istore #6
    //   2174: iload #8
    //   2176: istore #10
    //   2178: iload #7
    //   2180: istore #9
    //   2182: iload #12
    //   2184: istore #7
    //   2186: iload #5
    //   2188: istore #8
    //   2190: iload #10
    //   2192: ifne -> 2205
    //   2195: iload #22
    //   2197: ldc 1073741824
    //   2199: if_icmpeq -> 2205
    //   2202: goto -> 2209
    //   2205: iload #7
    //   2207: istore #6
    //   2209: aload_0
    //   2210: iload #18
    //   2212: ldc_w -16777216
    //   2215: iload #8
    //   2217: iand
    //   2218: ior
    //   2219: iload #6
    //   2221: aload_0
    //   2222: invokevirtual getPaddingTop : ()I
    //   2225: aload_0
    //   2226: invokevirtual getPaddingBottom : ()I
    //   2229: iadd
    //   2230: iadd
    //   2231: aload_0
    //   2232: invokevirtual getSuggestedMinimumHeight : ()I
    //   2235: invokestatic max : (II)I
    //   2238: iload_2
    //   2239: iload #8
    //   2241: bipush #16
    //   2243: ishl
    //   2244: invokestatic resolveSizeAndState : (III)I
    //   2247: invokevirtual setMeasuredDimension : (II)V
    //   2250: iload #11
    //   2252: ifeq -> 2262
    //   2255: aload_0
    //   2256: iload #9
    //   2258: iload_1
    //   2259: invokespecial forceUniformHeight : (II)V
    //   2262: return
  }
  
  public int measureNullChild(int paramInt) {
    return 0;
  }
  
  public void measureVertical(int paramInt1, int paramInt2) {
    this.mTotalLength = 0;
    int i5 = getVirtualChildCount();
    int i8 = View.MeasureSpec.getMode(paramInt1);
    int i6 = View.MeasureSpec.getMode(paramInt2);
    int i9 = this.mBaselineAlignedChildIndex;
    boolean bool = this.mUseLargestChild;
    int j = 0;
    int i4 = 0;
    int n = i4;
    int i = n;
    int m = i;
    int i2 = m;
    int i3 = i2;
    int i1 = i3;
    int k = 1;
    float f = 0.0F;
    while (i2 < i5) {
      View view = getVirtualChildAt(i2);
      if (view == null) {
        this.mTotalLength += measureNullChild(i2);
      } else if (view.getVisibility() == 8) {
        i2 += getChildrenSkipCount(view, i2);
      } else {
        if (hasDividerBeforeChildAt(i2))
          this.mTotalLength += this.mDividerHeight; 
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        float f1 = layoutParams.weight;
        f += f1;
        if (i6 == 1073741824 && layoutParams.height == 0 && f1 > 0.0F) {
          i3 = this.mTotalLength;
          this.mTotalLength = Math.max(i3, layoutParams.topMargin + i3 + layoutParams.bottomMargin);
          i3 = 1;
        } else {
          if (layoutParams.height == 0 && f1 > 0.0F) {
            layoutParams.height = -2;
            i10 = 0;
          } else {
            i10 = Integer.MIN_VALUE;
          } 
          if (f == 0.0F) {
            i11 = this.mTotalLength;
          } else {
            i11 = 0;
          } 
          measureChildBeforeLayout(view, i2, paramInt1, 0, paramInt2, i11);
          if (i10 != Integer.MIN_VALUE)
            layoutParams.height = i10; 
          int i11 = view.getMeasuredHeight();
          int i10 = this.mTotalLength;
          this.mTotalLength = Math.max(i10, i10 + i11 + layoutParams.topMargin + layoutParams.bottomMargin + getNextLocationOffset(view));
          if (bool)
            n = Math.max(i11, n); 
        } 
        if (i9 >= 0 && i9 == i2 + 1)
          this.mBaselineChildTop = this.mTotalLength; 
        if (i2 >= i9 || layoutParams.weight <= 0.0F) {
          if (i8 != 1073741824 && layoutParams.width == -1) {
            i10 = 1;
            i1 = 1;
          } else {
            i10 = 0;
          } 
          int i12 = layoutParams.leftMargin + layoutParams.rightMargin;
          int i11 = view.getMeasuredWidth() + i12;
          i4 = Math.max(i4, i11);
          int i13 = View.combineMeasuredStates(j, view.getMeasuredState());
          if (k && layoutParams.width == -1) {
            j = 1;
          } else {
            j = 0;
          } 
          if (layoutParams.weight > 0.0F) {
            if (!i10)
              i12 = i11; 
            i = Math.max(i, i12);
            k = m;
          } else {
            if (i10)
              i11 = i12; 
            k = Math.max(m, i11);
          } 
          int i10 = getChildrenSkipCount(view, i2);
          m = k;
          i2 = i10 + i2;
          i10 = i13;
          k = j;
          j = i10;
        } else {
          throw new RuntimeException("A child of LinearLayout with index less than mBaselineAlignedChildIndex has weight > 0, which won't work.  Either remove the weight, or don't set mBaselineAlignedChildIndex.");
        } 
      } 
      i2++;
    } 
    if (this.mTotalLength > 0 && hasDividerBeforeChildAt(i5))
      this.mTotalLength += this.mDividerHeight; 
    if (bool && (i6 == Integer.MIN_VALUE || i6 == 0)) {
      this.mTotalLength = 0;
      for (i2 = 0; i2 < i5; i2++) {
        View view = getVirtualChildAt(i2);
        if (view == null) {
          this.mTotalLength += measureNullChild(i2);
        } else if (view.getVisibility() == 8) {
          i2 += getChildrenSkipCount(view, i2);
        } else {
          LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
          int i10 = this.mTotalLength;
          this.mTotalLength = Math.max(i10, i10 + n + layoutParams.topMargin + layoutParams.bottomMargin + getNextLocationOffset(view));
        } 
      } 
    } 
    i2 = this.mTotalLength + getPaddingTop() + getPaddingBottom();
    this.mTotalLength = i2;
    int i7 = View.resolveSizeAndState(Math.max(i2, getSuggestedMinimumHeight()), paramInt2, 0);
    i2 = (0xFFFFFF & i7) - this.mTotalLength;
    if (i3 != 0 || (i2 != 0 && f > 0.0F)) {
      float f1 = this.mWeightSum;
      if (f1 > 0.0F)
        f = f1; 
      this.mTotalLength = 0;
      n = i2;
      i = j;
      i2 = 0;
      j = n;
      n = i4;
      while (i2 < i5) {
        View view = getVirtualChildAt(i2);
        if (view.getVisibility() != 8) {
          LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
          f1 = layoutParams.weight;
          if (f1 > 0.0F) {
            i4 = (int)(j * f1 / f);
            int i14 = getPaddingLeft();
            int i11 = getPaddingRight();
            i9 = layoutParams.leftMargin;
            int i13 = layoutParams.rightMargin;
            int i12 = layoutParams.width;
            i3 = j - i4;
            i11 = ViewGroup.getChildMeasureSpec(paramInt1, i14 + i11 + i9 + i13, i12);
            if (layoutParams.height != 0 || i6 != 1073741824) {
              i4 = view.getMeasuredHeight() + i4;
              j = i4;
              if (i4 < 0)
                j = 0; 
              view.measure(i11, View.MeasureSpec.makeMeasureSpec(j, 1073741824));
            } else {
              if (i4 > 0) {
                j = i4;
              } else {
                j = 0;
              } 
              view.measure(i11, View.MeasureSpec.makeMeasureSpec(j, 1073741824));
            } 
            i = View.combineMeasuredStates(i, view.getMeasuredState() & 0xFFFFFF00);
            f -= f1;
            j = i3;
          } 
          i4 = layoutParams.leftMargin + layoutParams.rightMargin;
          int i10 = view.getMeasuredWidth() + i4;
          i3 = Math.max(n, i10);
          if (i8 != 1073741824 && layoutParams.width == -1) {
            n = i4;
          } else {
            n = i10;
          } 
          m = Math.max(m, n);
          if (k != 0 && layoutParams.width == -1) {
            k = 1;
          } else {
            k = 0;
          } 
          n = this.mTotalLength;
          this.mTotalLength = Math.max(n, view.getMeasuredHeight() + n + layoutParams.topMargin + layoutParams.bottomMargin + getNextLocationOffset(view));
          n = i3;
        } 
        i2++;
      } 
      this.mTotalLength += getPaddingTop() + getPaddingBottom();
      j = i;
      i = m;
    } else {
      m = Math.max(m, i);
      if (bool && i6 != 1073741824)
        for (i = 0; i < i5; i++) {
          View view = getVirtualChildAt(i);
          if (view != null && view.getVisibility() != 8 && ((LayoutParams)view.getLayoutParams()).weight > 0.0F)
            view.measure(View.MeasureSpec.makeMeasureSpec(view.getMeasuredWidth(), 1073741824), View.MeasureSpec.makeMeasureSpec(n, 1073741824)); 
        }  
      i = m;
      n = i4;
    } 
    if (k != 0 || i8 == 1073741824)
      i = n; 
    setMeasuredDimension(View.resolveSizeAndState(Math.max(i + getPaddingLeft() + getPaddingRight(), getSuggestedMinimumWidth()), paramInt1, j), i7);
    if (i1 != 0)
      forceUniformWidth(i5, paramInt2); 
  }
  
  public void onDraw(Canvas paramCanvas) {
    if (this.mDivider == null)
      return; 
    if (this.mOrientation == 1) {
      drawDividersVertical(paramCanvas);
    } else {
      drawDividersHorizontal(paramCanvas);
    } 
  }
  
  public void onInitializeAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent) {
    super.onInitializeAccessibilityEvent(paramAccessibilityEvent);
    paramAccessibilityEvent.setClassName("androidx.appcompat.widget.LinearLayoutCompat");
  }
  
  public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo paramAccessibilityNodeInfo) {
    super.onInitializeAccessibilityNodeInfo(paramAccessibilityNodeInfo);
    paramAccessibilityNodeInfo.setClassName("androidx.appcompat.widget.LinearLayoutCompat");
  }
  
  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (this.mOrientation == 1) {
      layoutVertical(paramInt1, paramInt2, paramInt3, paramInt4);
    } else {
      layoutHorizontal(paramInt1, paramInt2, paramInt3, paramInt4);
    } 
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    if (this.mOrientation == 1) {
      measureVertical(paramInt1, paramInt2);
    } else {
      measureHorizontal(paramInt1, paramInt2);
    } 
  }
  
  public void setBaselineAligned(boolean paramBoolean) {
    this.mBaselineAligned = paramBoolean;
  }
  
  public void setBaselineAlignedChildIndex(int paramInt) {
    if (paramInt >= 0 && paramInt < getChildCount()) {
      this.mBaselineAlignedChildIndex = paramInt;
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("base aligned child index out of range (0, ");
    stringBuilder.append(getChildCount());
    stringBuilder.append(")");
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public void setDividerDrawable(Drawable paramDrawable) {
    if (paramDrawable == this.mDivider)
      return; 
    this.mDivider = paramDrawable;
    boolean bool = false;
    if (paramDrawable != null) {
      this.mDividerWidth = paramDrawable.getIntrinsicWidth();
      this.mDividerHeight = paramDrawable.getIntrinsicHeight();
    } else {
      this.mDividerWidth = 0;
      this.mDividerHeight = 0;
    } 
    if (paramDrawable == null)
      bool = true; 
    setWillNotDraw(bool);
    requestLayout();
  }
  
  public void setDividerPadding(int paramInt) {
    this.mDividerPadding = paramInt;
  }
  
  public void setGravity(int paramInt) {
    if (this.mGravity != paramInt) {
      int i = paramInt;
      if ((0x800007 & paramInt) == 0)
        i = paramInt | 0x800003; 
      paramInt = i;
      if ((i & 0x70) == 0)
        paramInt = i | 0x30; 
      this.mGravity = paramInt;
      requestLayout();
    } 
  }
  
  public void setHorizontalGravity(int paramInt) {
    paramInt &= 0x800007;
    int i = this.mGravity;
    if ((0x800007 & i) != paramInt) {
      this.mGravity = paramInt | 0xFF7FFFF8 & i;
      requestLayout();
    } 
  }
  
  public void setMeasureWithLargestChildEnabled(boolean paramBoolean) {
    this.mUseLargestChild = paramBoolean;
  }
  
  public void setOrientation(int paramInt) {
    if (this.mOrientation != paramInt) {
      this.mOrientation = paramInt;
      requestLayout();
    } 
  }
  
  public void setShowDividers(int paramInt) {
    if (paramInt != this.mShowDividers)
      requestLayout(); 
    this.mShowDividers = paramInt;
  }
  
  public void setVerticalGravity(int paramInt) {
    paramInt &= 0x70;
    int i = this.mGravity;
    if ((i & 0x70) != paramInt) {
      this.mGravity = paramInt | i & 0xFFFFFF8F;
      requestLayout();
    } 
  }
  
  public void setWeightSum(float paramFloat) {
    this.mWeightSum = Math.max(0.0F, paramFloat);
  }
  
  public boolean shouldDelayChildPressedState() {
    return false;
  }
  
  public static class LayoutParams extends LinearLayout.LayoutParams {
    public LayoutParams(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
    }
    
    public LayoutParams(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
    }
    
    public LayoutParams(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\androidx\appcompat\widget\LinearLayoutCompat.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */