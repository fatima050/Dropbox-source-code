package com.dbx.base.util;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import dbxyzptlk.CC.p;

public final class AndroidUtil {
  public static PackageInfo a(Context paramContext) throws PackageManagerOperationFailedException {
    try {
      boolean bool1;
      PackageManager packageManager = paramContext.getPackageManager();
      boolean bool2 = true;
      if (packageManager != null) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      p.e(bool1, "Assert failed.");
      PackageInfo packageInfo = packageManager.getPackageInfo(paramContext.getPackageName(), 0);
      if (packageInfo != null) {
        bool1 = bool2;
      } else {
        bool1 = false;
      } 
      p.e(bool1, "Assert failed.");
      return packageInfo;
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
    
    } catch (RuntimeException runtimeException) {}
    if ("Package manager has died".equals(runtimeException.getMessage()))
      throw new PackageManagerOperationFailedException("Unable to get package info for app package: package manager died", runtimeException); 
    throw runtimeException;
  }
  
  class AndroidUtil {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dbx\bas\\util\AndroidUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */