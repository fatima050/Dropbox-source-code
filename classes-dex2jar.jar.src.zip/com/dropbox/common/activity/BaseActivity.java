package com.dropbox.common.activity;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.MotionEvent;
import androidx.appcompat.app.AppCompatActivity;
import dbxyzptlk.DI.s;
import dbxyzptlk.af.a;
import dbxyzptlk.af.c;
import dbxyzptlk.af.d;
import dbxyzptlk.qI.t;
import dbxyzptlk.vc.b;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Set;
import kotlin.Metadata;

@Metadata(d1 = {"\000t\n\002\030\002\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\n\n\002\020\b\n\000\n\002\030\002\n\000\n\002\020\013\n\002\b\002\n\002\030\002\n\002\b\004\n\002\020\021\n\002\020\016\n\000\n\002\020\025\n\002\b\004\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\n\b&\030\0002\0020\0012\0020\002B\007¢\006\004\b\003\020\004J\031\020\b\032\0020\0072\b\020\006\032\004\030\0010\005H\024¢\006\004\b\b\020\tJ\017\020\n\032\0020\007H\024¢\006\004\b\n\020\004J\017\020\013\032\0020\007H\004¢\006\004\b\013\020\004J\017\020\f\032\0020\007H\024¢\006\004\b\f\020\004J\017\020\r\032\0020\007H\024¢\006\004\b\r\020\004J\027\020\017\032\0020\0072\006\020\016\032\0020\005H\024¢\006\004\b\017\020\tJ\017\020\020\032\0020\007H\024¢\006\004\b\020\020\004J\017\020\021\032\0020\007H\024¢\006\004\b\021\020\004J!\020\027\032\0020\0262\006\020\023\032\0020\0222\b\020\025\032\004\030\0010\024H\026¢\006\004\b\027\020\030J\027\020\032\032\0020\0262\006\020\025\032\0020\031H\026¢\006\004\b\032\020\033J\025\020\034\032\0020\0262\006\020\025\032\0020\031¢\006\004\b\034\020\033J+\020#\032\0020\0072\006\020\035\032\0020\0222\f\020 \032\b\022\004\022\0020\0370\0362\006\020\"\032\0020!¢\006\004\b#\020$J)\020(\032\0020\0072\006\020\035\032\0020\0222\006\020%\032\0020\0222\b\020'\032\004\030\0010&H\024¢\006\004\b(\020)J\017\020*\032\0020\007H\027¢\006\004\b*\020\004J\027\020-\032\0020\0262\006\020,\032\0020+H\026¢\006\004\b-\020.J\021\0200\032\004\030\0010/H\027¢\006\004\b0\0201J\037\0205\032\0020\0072\006\0202\032\0020\0372\006\0204\032\00203H\026¢\006\004\b5\0206J\017\0207\032\0020\007H\002¢\006\004\b7\020\004R\034\020;\032\b\022\004\022\002080\0368\002@\002X.¢\006\006\n\004\b9\020:R$\020A\032\0020\0262\006\020<\032\0020\0268\006@BX\016¢\006\f\n\004\b=\020>\032\004\b?\020@¨\006B"}, d2 = {"Lcom/dropbox/common/activity/BaseActivity;", "Landroidx/appcompat/app/AppCompatActivity;", "", "<init>", "()V", "Landroid/os/Bundle;", "savedInstanceState", "Ldbxyzptlk/pI/D;", "onCreate", "(Landroid/os/Bundle;)V", "onStart", "onResume", "onResumeFragments", "onPause", "outState", "onSaveInstanceState", "onStop", "onDestroy", "", "keyCode", "Landroid/view/KeyEvent;", "event", "", "onKeyDown", "(ILandroid/view/KeyEvent;)Z", "Landroid/view/MotionEvent;", "dispatchTouchEvent", "(Landroid/view/MotionEvent;)Z", "v4", "requestCode", "", "", "permissions", "", "grantResults", "onRequestPermissionsResult", "(I[Ljava/lang/String;[I)V", "resultCode", "Landroid/content/Intent;", "data", "onActivityResult", "(IILandroid/content/Intent;)V", "onBackPressed", "Landroid/view/MenuItem;", "item", "onOptionsItemSelected", "(Landroid/view/MenuItem;)Z", "Landroid/content/pm/PackageManager;", "getPackageManager", "()Landroid/content/pm/PackageManager;", "tag", "Ldbxyzptlk/vc/b;", "listener", "u4", "(Ljava/lang/String;Ldbxyzptlk/vc/b;)V", "t4", "Ldbxyzptlk/af/a;", "a", "[Ldbxyzptlk/af/a;", "callbacks", "<set-?>", "b", "Z", "s4", "()Z", "fragmentCommitAllowed", "common_activity_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
public abstract class BaseActivity extends AppCompatActivity {
  public a[] a;
  
  public boolean b;
  
  public boolean dispatchTouchEvent(MotionEvent paramMotionEvent) {
    s.h(paramMotionEvent, "event");
    return v4(paramMotionEvent);
  }
  
  public PackageManager getPackageManager() {
    return super.getPackageManager();
  }
  
  public void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent) {
    super.onActivityResult(paramInt1, paramInt2, paramIntent);
    a[] arrayOfA2 = this.a;
    a[] arrayOfA1 = arrayOfA2;
    if (arrayOfA2 == null) {
      s.u("callbacks");
      arrayOfA1 = null;
    } 
    int i = arrayOfA1.length;
    for (byte b = 0; b < i; b++)
      arrayOfA1[b].l(paramInt1, paramInt2, paramIntent); 
  }
  
  public void onBackPressed() {
    // Byte code:
    //   0: aload_0
    //   1: getfield a : [Ldbxyzptlk/af/a;
    //   4: astore #4
    //   6: aload #4
    //   8: astore_3
    //   9: aload #4
    //   11: ifnonnull -> 21
    //   14: ldc 'callbacks'
    //   16: invokestatic u : (Ljava/lang/String;)V
    //   19: aconst_null
    //   20: astore_3
    //   21: aload_3
    //   22: arraylength
    //   23: istore_2
    //   24: iconst_0
    //   25: istore_1
    //   26: iload_1
    //   27: iload_2
    //   28: if_icmpge -> 51
    //   31: aload_3
    //   32: iload_1
    //   33: aaload
    //   34: invokeinterface v : ()Z
    //   39: ifeq -> 45
    //   42: goto -> 55
    //   45: iinc #1, 1
    //   48: goto -> 26
    //   51: aload_0
    //   52: invokespecial onBackPressed : ()V
    //   55: return
  }
  
  public void onCreate(Bundle paramBundle) {
    this.b = true;
    super.onCreate(paramBundle);
    t4();
    a[] arrayOfA2 = this.a;
    a[] arrayOfA1 = arrayOfA2;
    if (arrayOfA2 == null) {
      s.u("callbacks");
      arrayOfA1 = null;
    } 
    int i = arrayOfA1.length;
    for (byte b = 0; b < i; b++)
      arrayOfA1[b].g(paramBundle); 
  }
  
  public void onDestroy() {
    super.onDestroy();
    a[] arrayOfA2 = this.a;
    a[] arrayOfA1 = arrayOfA2;
    if (arrayOfA2 == null) {
      s.u("callbacks");
      arrayOfA1 = null;
    } 
    int i = arrayOfA1.length;
    for (byte b = 0; b < i; b++)
      arrayOfA1[b].d(); 
  }
  
  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent) {
    boolean bool;
    if (!super.onKeyDown(paramInt, paramKeyEvent)) {
      a[] arrayOfA2 = this.a;
      a[] arrayOfA1 = arrayOfA2;
      if (arrayOfA2 == null) {
        s.u("callbacks");
        arrayOfA1 = null;
      } 
      int i = arrayOfA1.length;
      boolean bool1 = false;
      byte b = 0;
      while (true) {
        bool = bool1;
        if (b < i) {
          if (arrayOfA1[b].f(paramInt, paramKeyEvent))
            // Byte code: goto -> 75 
          b++;
          continue;
        } 
        break;
      } 
    } else {
      bool = true;
    } 
    return bool;
  }
  
  public boolean onOptionsItemSelected(MenuItem paramMenuItem) {
    // Byte code:
    //   0: aload_1
    //   1: ldc 'item'
    //   3: invokestatic h : (Ljava/lang/Object;Ljava/lang/String;)V
    //   6: aload_0
    //   7: getfield a : [Ldbxyzptlk/af/a;
    //   10: astore #6
    //   12: aload #6
    //   14: astore #5
    //   16: aload #6
    //   18: ifnonnull -> 29
    //   21: ldc 'callbacks'
    //   23: invokestatic u : (Ljava/lang/String;)V
    //   26: aconst_null
    //   27: astore #5
    //   29: aload #5
    //   31: arraylength
    //   32: istore_3
    //   33: iconst_0
    //   34: istore #4
    //   36: iconst_0
    //   37: istore_2
    //   38: iload_2
    //   39: iload_3
    //   40: if_icmpge -> 65
    //   43: aload #5
    //   45: iload_2
    //   46: aaload
    //   47: aload_1
    //   48: invokeinterface onOptionsItemSelected : (Landroid/view/MenuItem;)Z
    //   53: ifeq -> 59
    //   56: goto -> 73
    //   59: iinc #2, 1
    //   62: goto -> 38
    //   65: aload_0
    //   66: aload_1
    //   67: invokespecial onOptionsItemSelected : (Landroid/view/MenuItem;)Z
    //   70: ifeq -> 76
    //   73: iconst_1
    //   74: istore #4
    //   76: iload #4
    //   78: ireturn
  }
  
  public void onPause() {
    super.onPause();
    a[] arrayOfA2 = this.a;
    a[] arrayOfA1 = arrayOfA2;
    if (arrayOfA2 == null) {
      s.u("callbacks");
      arrayOfA1 = null;
    } 
    int i = arrayOfA1.length;
    for (byte b = 0; b < i; b++)
      arrayOfA1[b].c(); 
  }
  
  public final void onRequestPermissionsResult(int paramInt, String[] paramArrayOfString, int[] paramArrayOfint) {
    s.h(paramArrayOfString, "permissions");
    s.h(paramArrayOfint, "grantResults");
    super.onRequestPermissionsResult(paramInt, paramArrayOfString, paramArrayOfint);
    a[] arrayOfA2 = this.a;
    a[] arrayOfA1 = arrayOfA2;
    if (arrayOfA2 == null) {
      s.u("callbacks");
      arrayOfA1 = null;
    } 
    int i = arrayOfA1.length;
    for (byte b = 0; b < i && !arrayOfA1[b].a(paramInt, paramArrayOfString, paramArrayOfint); b++);
  }
  
  public final void onResume() {
    super.onResume();
    a[] arrayOfA2 = this.a;
    a[] arrayOfA1 = arrayOfA2;
    if (arrayOfA2 == null) {
      s.u("callbacks");
      arrayOfA1 = null;
    } 
    int i = arrayOfA1.length;
    for (byte b = 0; b < i; b++)
      arrayOfA1[b].h(); 
  }
  
  public void onResumeFragments() {
    this.b = true;
    super.onResumeFragments();
    a[] arrayOfA2 = this.a;
    a[] arrayOfA1 = arrayOfA2;
    if (arrayOfA2 == null) {
      s.u("callbacks");
      arrayOfA1 = null;
    } 
    int i = arrayOfA1.length;
    for (byte b = 0; b < i; b++)
      arrayOfA1[b].k(); 
  }
  
  public void onSaveInstanceState(Bundle paramBundle) {
    s.h(paramBundle, "outState");
    byte b = 0;
    this.b = false;
    super.onSaveInstanceState(paramBundle);
    a[] arrayOfA2 = this.a;
    a[] arrayOfA1 = arrayOfA2;
    if (arrayOfA2 == null) {
      s.u("callbacks");
      arrayOfA1 = null;
    } 
    int i = arrayOfA1.length;
    while (b < i) {
      arrayOfA1[b].i(paramBundle);
      b++;
    } 
  }
  
  public void onStart() {
    super.onStart();
    a[] arrayOfA2 = this.a;
    a[] arrayOfA1 = arrayOfA2;
    if (arrayOfA2 == null) {
      s.u("callbacks");
      arrayOfA1 = null;
    } 
    int i = arrayOfA1.length;
    for (byte b = 0; b < i; b++)
      arrayOfA1[b].e(); 
  }
  
  public void onStop() {
    super.onStop();
    a[] arrayOfA2 = this.a;
    a[] arrayOfA1 = arrayOfA2;
    if (arrayOfA2 == null) {
      s.u("callbacks");
      arrayOfA1 = null;
    } 
    int i = arrayOfA1.length;
    for (byte b = 0; b < i; b++)
      arrayOfA1[b].j(); 
  }
  
  public final boolean s4() {
    return this.b;
  }
  
  public final void t4() {
    d d = d.a;
    Context context = getApplicationContext();
    s.g(context, "getApplicationContext(...)");
    Set set = d.a(context).k();
    ArrayList<a> arrayList = new ArrayList(t.x(set, 10));
    Iterator<c> iterator = set.iterator();
    while (iterator.hasNext())
      arrayList.add(((c)iterator.next()).a(this)); 
    this.a = arrayList.<a>toArray(new a[0]);
  }
  
  public void u4(String paramString, b paramb) {
    s.h(paramString, "tag");
    s.h(paramb, "listener");
    a[] arrayOfA2 = this.a;
    a[] arrayOfA1 = arrayOfA2;
    if (arrayOfA2 == null) {
      s.u("callbacks");
      arrayOfA1 = null;
    } 
    int i = arrayOfA1.length;
    for (byte b1 = 0; b1 < i; b1++)
      arrayOfA1[b1].b(paramString, paramb); 
  }
  
  public final boolean v4(MotionEvent paramMotionEvent) {
    s.h(paramMotionEvent, "event");
    return super.dispatchTouchEvent(paramMotionEvent);
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\common\activity\BaseActivity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */