package com.dropbox.common.taskqueue;

import dbxyzptlk.CC.p;
import dbxyzptlk.CC.q;
import dbxyzptlk.Ge.c;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.PriorityQueue;
import java.util.concurrent.CopyOnWriteArraySet;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public abstract class TaskQueue<T extends TaskQueue.BaseTask> {
  public boolean a = false;
  
  public final HashSet<T> b;
  
  public final PriorityQueue<c<T>> c;
  
  public final HashMap<String, c<T>> d;
  
  public final CopyOnWriteArraySet<dbxyzptlk.Fj.b<T>> e;
  
  public final ExecutorService f;
  
  public int g = 0;
  
  public final Runnable h = new a(this);
  
  public TaskQueue(dbxyzptlk.t6.b paramb, int paramInt1, int paramInt2) {
    this.b = new HashSet<>(paramInt1);
    this.c = new PriorityQueue<>();
    this.d = new HashMap<>();
    this.f = k(paramb, paramInt1, paramInt2);
    this.e = new CopyOnWriteArraySet<>();
  }
  
  public static ExecutorService k(dbxyzptlk.t6.b paramb, int paramInt1, int paramInt2) {
    LinkedBlockingDeque linkedBlockingDeque = new LinkedBlockingDeque();
    ThreadPoolExecutor.DiscardPolicy discardPolicy = new ThreadPoolExecutor.DiscardPolicy();
    c c = c.a(TaskQueue.class).b(new b(paramInt2));
    return paramb.d(paramInt1, paramInt1, 10, TimeUnit.SECONDS, linkedBlockingDeque, true, (ThreadFactory)c, discardPolicy);
  }
  
  public boolean e(T paramT) {
    return f(paramT, false);
  }
  
  public boolean f(T paramT, boolean paramBoolean) {
    String str;
    /* monitor enter ThisExpression{ObjectType{com/dropbox/common/taskqueue/TaskQueue}} */
    try {
      p.o(paramT);
      str = paramT.o();
      boolean bool = j(str);
      if (bool) {
        /* monitor exit ThisExpression{ObjectType{com/dropbox/common/taskqueue/TaskQueue}} */
        return false;
      } 
      c<T> c = new c();
      int i = this.g;
      this.g = i + 1;
      this((BaseTask)paramT, paramBoolean, i);
      this.c.add(c);
      this.d.put(str, c);
      m(paramT);
      if (!this.a)
        y(); 
    } finally {}
    dbxyzptlk.sL.a.d("Added  %s", new Object[] { str });
    /* monitor exit ThisExpression{ObjectType{com/dropbox/common/taskqueue/TaskQueue}} */
    return true;
  }
  
  public final void g(c<T> paramc) {
    BaseTask baseTask = paramc.a;
    if (baseTask != null) {
      baseTask.c();
      paramc.a.g();
      String str = paramc.a.o();
      this.d.remove(str);
      dbxyzptlk.sL.a.d("Cancelled  %s", new Object[] { str });
      n((T)paramc.a, TaskResult.b.CANCELED);
      paramc.a = null;
    } 
  }
  
  public final void h(T paramT) {
    String str = paramT.o();
    paramT.c();
    this.d.remove(str);
    n(paramT, TaskResult.b.CANCELED);
    dbxyzptlk.sL.a.d("Cancelled  %s", new Object[] { str });
  }
  
  public void i() {
    /* monitor enter ThisExpression{ObjectType{com/dropbox/common/taskqueue/TaskQueue}} */
    try {
      Iterator<c<T>> iterator1 = this.c.iterator();
      while (iterator1.hasNext())
        g(iterator1.next()); 
    } finally {
      Exception exception;
    } 
    this.c.clear();
    Iterator<T> iterator = this.b.iterator();
    while (iterator.hasNext()) {
      h(iterator.next());
      iterator.remove();
    } 
    /* monitor exit ThisExpression{ObjectType{com/dropbox/common/taskqueue/TaskQueue}} */
  }
  
  public boolean j(String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield d : Ljava/util/HashMap;
    //   6: aload_1
    //   7: invokevirtual containsKey : (Ljava/lang/Object;)Z
    //   10: istore_2
    //   11: aload_0
    //   12: monitorexit
    //   13: iload_2
    //   14: ireturn
    //   15: astore_1
    //   16: aload_0
    //   17: monitorexit
    //   18: aload_1
    //   19: athrow
    // Exception table:
    //   from	to	target	type
    //   2	11	15	finally
    //   16	18	15	finally
  }
  
  public void l() {
    i();
    this.f.shutdownNow();
    try {
      this.f.awaitTermination(30L, TimeUnit.SECONDS);
    } catch (InterruptedException interruptedException) {}
  }
  
  public final void m(T paramT) {
    Iterator<dbxyzptlk.Fj.b<T>> iterator = this.e.iterator();
    while (iterator.hasNext())
      ((dbxyzptlk.Fj.b)iterator.next()).b((c)paramT); 
  }
  
  public final void n(T paramT, TaskResult.b paramb) {
    o(paramT, new TaskResult(paramb));
  }
  
  public final void o(T paramT, TaskResult paramTaskResult) {
    Iterator<dbxyzptlk.Fj.b<T>> iterator = this.e.iterator();
    while (iterator.hasNext())
      ((dbxyzptlk.Fj.b)iterator.next()).a((c)paramT, paramTaskResult); 
  }
  
  public final void p(T paramT, boolean paramBoolean) {
    if (z(paramT)) {
      w(paramT, paramBoolean, paramT.e().a());
    } else {
      w(paramT, paramBoolean, TaskResult.b.CANCELED);
    } 
  }
  
  public abstract void q(T paramT, boolean paramBoolean, TaskResult.b paramb);
  
  public final void r(dbxyzptlk.Fj.b<T> paramb) {
    p.e(this.e.add(paramb), "Assert failed.");
  }
  
  public void s(q<T> paramq) {
    /* monitor enter ThisExpression{ObjectType{com/dropbox/common/taskqueue/TaskQueue}} */
    try {
      u(paramq);
      Iterator<T> iterator = this.b.iterator();
      while (iterator.hasNext()) {
        BaseTask baseTask = (BaseTask)iterator.next();
        if (paramq.apply(baseTask)) {
          h((T)baseTask);
          iterator.remove();
        } 
      } 
    } finally {}
    /* monitor exit ThisExpression{ObjectType{com/dropbox/common/taskqueue/TaskQueue}} */
  }
  
  public boolean t(String paramString) {
    /* monitor enter ThisExpression{ObjectType{com/dropbox/common/taskqueue/TaskQueue}} */
    try {
      c<T> c = this.d.get(paramString);
      if (c != null) {
        BaseTask baseTask = c.a;
        if (baseTask != null) {
          if (this.b.contains(baseTask)) {
            h((T)c.a);
            this.b.remove(c.a);
          } else {
            g(c);
          } 
          /* monitor exit ThisExpression{ObjectType{com/dropbox/common/taskqueue/TaskQueue}} */
          return true;
        } 
      } 
    } finally {}
    /* monitor exit ThisExpression{ObjectType{com/dropbox/common/taskqueue/TaskQueue}} */
    return false;
  }
  
  public void u(q<T> paramq) {
    /* monitor enter ThisExpression{ObjectType{com/dropbox/common/taskqueue/TaskQueue}} */
    try {
      Iterator<c<T>> iterator = this.c.iterator();
      while (iterator.hasNext()) {
        c<T> c = iterator.next();
        BaseTask baseTask = c.a;
        if (baseTask == null || paramq.apply(baseTask)) {
          g(c);
          iterator.remove();
        } 
      } 
    } finally {}
    /* monitor exit ThisExpression{ObjectType{com/dropbox/common/taskqueue/TaskQueue}} */
  }
  
  public boolean v(String paramString) {
    /* monitor enter ThisExpression{ObjectType{com/dropbox/common/taskqueue/TaskQueue}} */
    try {
      c<T> c = this.d.get(paramString);
      if (c != null) {
        BaseTask baseTask = c.a;
        if (baseTask != null && !this.b.contains(baseTask)) {
          g(c);
          /* monitor exit ThisExpression{ObjectType{com/dropbox/common/taskqueue/TaskQueue}} */
          return true;
        } 
      } 
    } finally {}
    /* monitor exit ThisExpression{ObjectType{com/dropbox/common/taskqueue/TaskQueue}} */
    return false;
  }
  
  public final void w(T paramT, boolean paramBoolean, TaskResult.b paramb) {
    /* monitor enter ThisExpression{ObjectType{com/dropbox/common/taskqueue/TaskQueue}} */
    try {
      this.b.remove(paramT);
      this.d.remove(paramT.o());
      if (paramb.getState() != TaskResult.b.b.SUCCEEDED)
        q(paramT, paramBoolean, paramb); 
    } finally {}
    n(paramT, paramb);
    /* monitor exit ThisExpression{ObjectType{com/dropbox/common/taskqueue/TaskQueue}} */
  }
  
  public int x() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield d : Ljava/util/HashMap;
    //   6: invokevirtual size : ()I
    //   9: istore_1
    //   10: aload_0
    //   11: monitorexit
    //   12: iload_1
    //   13: ireturn
    //   14: astore_2
    //   15: aload_0
    //   16: monitorexit
    //   17: aload_2
    //   18: athrow
    // Exception table:
    //   from	to	target	type
    //   2	10	14	finally
    //   15	17	14	finally
  }
  
  public final void y() {
    this.f.execute(this.h);
  }
  
  public boolean z(T paramT) {
    return true;
  }
  
  class TaskQueue {}
  
  public class a implements Runnable {
    public final TaskQueue a;
    
    public a(TaskQueue this$0) {}
    
    public void run() {
      while (true) {
        Exception exception;
        TaskQueue.c c;
        TaskQueue taskQueue = this.a;
        /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{com/dropbox/common/taskqueue/TaskQueue}, name=null} */
        try {
          if (TaskQueue.b(this.a).isEmpty() || TaskQueue.a(this.a)) {
            /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{com/dropbox/common/taskqueue/TaskQueue}, name=null} */
            return;
          } 
          c = TaskQueue.b(this.a).poll();
          TaskQueue.BaseTask baseTask = c.a;
          if (baseTask == null) {
            /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{com/dropbox/common/taskqueue/TaskQueue}, name=null} */
            continue;
          } 
        } finally {}
        boolean bool = c.b;
        TaskQueue.c(this.a).add(exception);
        /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{com/dropbox/common/taskqueue/TaskQueue}, name=null} */
        TaskQueue.d(this.a, (TaskQueue.BaseTask)exception, bool);
      } 
    }
  }
  
  public class b implements ThreadFactory {
    public final int a;
    
    public b(TaskQueue this$0) {}
    
    public Thread newThread(Runnable param1Runnable) {
      param1Runnable = new Thread(param1Runnable);
      param1Runnable.setPriority(this.a);
      return (Thread)param1Runnable;
    }
  }
  
  class TaskQueue {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\common\taskqueue\TaskQueue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */