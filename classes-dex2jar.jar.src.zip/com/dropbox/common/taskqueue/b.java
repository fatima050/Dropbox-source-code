package com.dropbox.common.taskqueue;

import dbxyzptlk.CC.q;
import dbxyzptlk.pj.m;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;

public class b<T extends TaskQueue.BaseTask> extends TaskQueue<T> {
  public final Collection<b<T>> i = new LinkedList<>();
  
  public final a<T> j;
  
  public b(dbxyzptlk.t6.b paramb, int paramInt1, int paramInt2, m paramm) {
    this(paramb, paramInt1, paramInt2, paramm, 15000L, 86400000L);
  }
  
  public b(dbxyzptlk.t6.b paramb, int paramInt1, int paramInt2, m paramm, long paramLong1, long paramLong2) {
    super(paramb, paramInt1, paramInt2);
    this.j = (a)new a<>(paramm, new a(this), paramLong1, paramLong2);
  }
  
  public final void C(c paramc) {
    /* monitor enter ThisExpression{ObjectType{com/dropbox/common/taskqueue/b}} */
    try {
      Iterator<b<T>> iterator = this.i.iterator();
      while (iterator.hasNext()) {
        b b1 = iterator.next();
        if (b.b(b1).equals(paramc)) {
          iterator.remove();
          f((T)b.b(b1), b.a(b1));
          break;
        } 
      } 
    } finally {}
    this.j.b(this.i.size());
    /* monitor exit ThisExpression{ObjectType{com/dropbox/common/taskqueue/b}} */
  }
  
  public final void D() {
    /* monitor enter ThisExpression{ObjectType{com/dropbox/common/taskqueue/b}} */
    try {
      for (b<T> b1 : this.i)
        f((T)b.b(b1), b.a(b1)); 
    } finally {
      Exception exception;
    } 
    this.i.clear();
    this.j.b(0);
    /* monitor exit ThisExpression{ObjectType{com/dropbox/common/taskqueue/b}} */
  }
  
  public final boolean E(String paramString) {
    Iterator<b<T>> iterator = this.i.iterator();
    while (iterator.hasNext()) {
      TaskQueue.BaseTask baseTask = b.b(iterator.next());
      if (baseTask.o().equals(paramString)) {
        baseTask.c();
        baseTask.g();
        iterator.remove();
        return true;
      } 
    } 
    return false;
  }
  
  public void i() {
    /* monitor enter ThisExpression{ObjectType{com/dropbox/common/taskqueue/b}} */
    try {
      super.i();
      Iterator<b<T>> iterator = this.i.iterator();
      while (iterator.hasNext())
        b.b(iterator.next()).c(); 
    } finally {
      Exception exception;
    } 
    this.i.clear();
    this.j.b(0);
    /* monitor exit ThisExpression{ObjectType{com/dropbox/common/taskqueue/b}} */
  }
  
  public boolean j(String paramString) {
    /* monitor enter ThisExpression{ObjectType{com/dropbox/common/taskqueue/b}} */
    try {
      Iterator<b<T>> iterator = this.i.iterator();
      while (iterator.hasNext()) {
        boolean bool1 = b.b(iterator.next()).o().equals(paramString);
        if (bool1) {
          /* monitor exit ThisExpression{ObjectType{com/dropbox/common/taskqueue/b}} */
          return true;
        } 
      } 
    } finally {}
    boolean bool = super.j(paramString);
    /* monitor exit ThisExpression{ObjectType{com/dropbox/common/taskqueue/b}} */
    return bool;
  }
  
  public void q(T paramT, boolean paramBoolean, TaskResult.b paramb) {
    /* monitor enter ThisExpression{ObjectType{com/dropbox/common/taskqueue/b}} */
    try {
      if (paramb.canRetry() && (paramT.m() <= 0 || paramT.b() < paramT.m()) && paramb.getRetryScheme() == TaskResult.b.a.BLOCK_EXPONENTIAL_BACKOFF) {
        StringBuilder stringBuilder = new StringBuilder();
        this();
        stringBuilder.append("Temp error with task ");
        stringBuilder.append(dbxyzptlk.He.b.e(paramT.o()));
        stringBuilder.append(", setting aside.");
        dbxyzptlk.sL.a.j(stringBuilder.toString(), new Object[0]);
        Collection<b<T>> collection = this.i;
        b<T> b1 = new b();
        this((TaskQueue.BaseTask)paramT, paramBoolean);
        collection.add(b1);
        this.j.b(this.i.size());
        this.j.c(paramT);
      } 
    } finally {}
    /* monitor exit ThisExpression{ObjectType{com/dropbox/common/taskqueue/b}} */
  }
  
  public boolean t(String paramString) {
    /* monitor enter ThisExpression{ObjectType{com/dropbox/common/taskqueue/b}} */
    try {
      if (!E(paramString)) {
        boolean bool1 = super.t(paramString);
        if (bool1) {
          bool1 = true;
          /* monitor exit ThisExpression{ObjectType{com/dropbox/common/taskqueue/b}} */
          return bool1;
        } 
        bool1 = false;
        /* monitor exit ThisExpression{ObjectType{com/dropbox/common/taskqueue/b}} */
        return bool1;
      } 
    } finally {}
    boolean bool = true;
    /* monitor exit ThisExpression{ObjectType{com/dropbox/common/taskqueue/b}} */
    return bool;
  }
  
  public void u(q<T> paramq) {
    /* monitor enter ThisExpression{ObjectType{com/dropbox/common/taskqueue/b}} */
    try {
      super.u(paramq);
      Iterator<b<T>> iterator = this.i.iterator();
      while (iterator.hasNext()) {
        TaskQueue.BaseTask baseTask = b.b(iterator.next());
        if (paramq.apply(baseTask)) {
          baseTask.c();
          baseTask.g();
          iterator.remove();
        } 
      } 
    } finally {}
    /* monitor exit ThisExpression{ObjectType{com/dropbox/common/taskqueue/b}} */
  }
  
  public boolean v(String paramString) {
    /* monitor enter ThisExpression{ObjectType{com/dropbox/common/taskqueue/b}} */
    try {
      if (!E(paramString)) {
        boolean bool1 = super.v(paramString);
        if (bool1) {
          bool1 = true;
          /* monitor exit ThisExpression{ObjectType{com/dropbox/common/taskqueue/b}} */
          return bool1;
        } 
        bool1 = false;
        /* monitor exit ThisExpression{ObjectType{com/dropbox/common/taskqueue/b}} */
        return bool1;
      } 
    } finally {}
    boolean bool = true;
    /* monitor exit ThisExpression{ObjectType{com/dropbox/common/taskqueue/b}} */
    return bool;
  }
  
  public int x() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokespecial x : ()I
    //   6: istore_2
    //   7: aload_0
    //   8: getfield i : Ljava/util/Collection;
    //   11: invokeinterface size : ()I
    //   16: istore_1
    //   17: aload_0
    //   18: monitorexit
    //   19: iload_2
    //   20: iload_1
    //   21: iadd
    //   22: ireturn
    //   23: astore_3
    //   24: aload_0
    //   25: monitorexit
    //   26: aload_3
    //   27: athrow
    // Exception table:
    //   from	to	target	type
    //   2	17	23	finally
    //   24	26	23	finally
  }
  
  public class a implements a.c<T> {
    public final b a;
    
    public a(b this$0) {}
    
    public void a(T param1T) {
      b.A(this.a, (c)param1T);
    }
    
    public void c() {
      b.B(this.a);
    }
    
    public void d() {}
  }
  
  class b {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\common\taskqueue\b.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */