package com.dropbox.common.taskqueue;

import dbxyzptlk.t6.b;

public class SingleAttemptTaskQueue<T extends SingleAttemptTaskQueue.SingleAttemptTask> extends TaskQueue<T> {
  public SingleAttemptTaskQueue(b paramb, int paramInt1, int paramInt2) {
    super(paramb, paramInt1, paramInt2);
  }
  
  public void A(T paramT, boolean paramBoolean, TaskResult.b paramb) {}
  
  class SingleAttemptTaskQueue {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\common\taskqueue\SingleAttemptTaskQueue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */