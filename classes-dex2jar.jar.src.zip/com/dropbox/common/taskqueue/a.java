package com.dropbox.common.taskqueue;

import dbxyzptlk.Fj.d;
import dbxyzptlk.pj.k;
import dbxyzptlk.pj.m;
import dbxyzptlk.pj.t;

public class a<T extends c> {
  public final m a;
  
  public final long b;
  
  public final long c;
  
  public final k d = new a(this);
  
  public dbxyzptlk.Ee.a.f e = null;
  
  public final d f;
  
  public final c<T> g;
  
  public a(m paramm, c<T> paramc, long paramLong1, long paramLong2) {
    this(paramm, paramc, paramLong1, paramLong2, new d());
  }
  
  public a(m paramm, c<T> paramc, long paramLong1, long paramLong2, d paramd) {
    this.a = paramm;
    this.g = paramc;
    this.b = paramLong1;
    this.c = paramLong2;
    this.f = paramd;
  }
  
  public void b(int paramInt) {
    /* monitor enter ThisExpression{ObjectType{com/dropbox/common/taskqueue/a}} */
    if (paramInt > 0) {
      try {
        if (this.e == null)
          this.e = this.a.c(this.d); 
      } finally {
        Exception exception;
      } 
    } else {
      dbxyzptlk.Ee.a.f f1 = this.e;
      if (f1 != null) {
        f1.a();
        this.e = null;
      } 
      this.f.a();
    } 
    /* monitor exit ThisExpression{ObjectType{com/dropbox/common/taskqueue/a}} */
  }
  
  public long c(T paramT) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield b : J
    //   6: l2d
    //   7: dstore_2
    //   8: ldc2_w 2.0
    //   11: aload_1
    //   12: invokevirtual b : ()I
    //   15: iconst_1
    //   16: isub
    //   17: i2d
    //   18: invokestatic pow : (DD)D
    //   21: dstore #4
    //   23: aload_0
    //   24: getfield c : J
    //   27: l2d
    //   28: dload_2
    //   29: dload #4
    //   31: dmul
    //   32: invokestatic min : (DD)D
    //   35: d2l
    //   36: lstore #6
    //   38: new java/lang/StringBuilder
    //   41: astore #8
    //   43: aload #8
    //   45: invokespecial <init> : ()V
    //   48: aload #8
    //   50: ldc 'Task '
    //   52: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   55: pop
    //   56: aload #8
    //   58: aload_1
    //   59: invokevirtual o : ()Ljava/lang/String;
    //   62: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   65: pop
    //   66: aload #8
    //   68: ldc ' transiently failed. rescheduling for '
    //   70: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   73: pop
    //   74: aload #8
    //   76: lload #6
    //   78: invokevirtual append : (J)Ljava/lang/StringBuilder;
    //   81: pop
    //   82: aload #8
    //   84: ldc ' millis'
    //   86: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   89: pop
    //   90: aload #8
    //   92: invokevirtual toString : ()Ljava/lang/String;
    //   95: iconst_0
    //   96: anewarray java/lang/Object
    //   99: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   102: aload_0
    //   103: getfield f : Ldbxyzptlk/Fj/d;
    //   106: astore #8
    //   108: new com/dropbox/common/taskqueue/a$b
    //   111: astore #9
    //   113: aload #9
    //   115: aload_0
    //   116: getfield g : Lcom/dropbox/common/taskqueue/a$c;
    //   119: aload_1
    //   120: invokespecial <init> : (Lcom/dropbox/common/taskqueue/a$c;Lcom/dropbox/common/taskqueue/c;)V
    //   123: aload #8
    //   125: aload #9
    //   127: lload #6
    //   129: invokevirtual b : (Ljava/util/TimerTask;J)V
    //   132: aload_0
    //   133: monitorexit
    //   134: lload #6
    //   136: lreturn
    //   137: astore_1
    //   138: aload_0
    //   139: monitorexit
    //   140: aload_1
    //   141: athrow
    // Exception table:
    //   from	to	target	type
    //   2	132	137	finally
    //   138	140	137	finally
  }
  
  public class a implements k {
    public final a a;
    
    public a(a this$0) {}
    
    public void a(t param1t) {
      if (param1t.a()) {
        a.a(this.a).c();
      } else {
        a.a(this.a).d();
      } 
    }
  }
  
  class a {}
  
  public static interface c<T extends c> {
    void c();
    
    void d();
    
    void e(T param1T);
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\common\taskqueue\a.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */