package com.dropbox.common.lock_screen;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import com.dropbox.common.android.context.BaseBroadcastReceiver;
import dbxyzptlk.Oh.q;
import dbxyzptlk.Oh.t;
import dbxyzptlk.Oh.u;
import dbxyzptlk.Oh.v;
import dbxyzptlk.jf.u;
import dbxyzptlk.sL.a;
import dbxyzptlk.ye.C0;
import java.util.WeakHashMap;

public class LockReceiver extends BaseBroadcastReceiver {
  public final b a = new b(null);
  
  public final c b;
  
  public final u c;
  
  public final Context d;
  
  public C0 e;
  
  public final t f;
  
  public WeakHashMap<Activity, Boolean> g = new WeakHashMap<>();
  
  public LockReceiver(Context paramContext, u paramu, v paramv, C0 paramC0, t paramt) {
    this.d = paramContext;
    this.c = paramu;
    this.b = new c(paramv);
    this.e = paramC0;
    this.f = paramt;
  }
  
  public void b() {
    b.i(this.a, this.e.a());
  }
  
  public boolean c() {
    boolean bool;
    dbxyzptlk.Fe.b.a();
    if (this.b.b() && b.b(this.a)) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public final void d(Context paramContext) {
    if (b.a(this.a) && Math.abs(b.f(this.a) - b.e(this.a)) < 1000L) {
      a.j("Screen has turned off, locking", new Object[0]);
      b.h(this.a, true);
      m(paramContext);
    } 
  }
  
  public void e(Context paramContext) {
    if (!this.b.b())
      return; 
    long l = this.e.a();
    if (!b.b(this.a)) {
      long l1 = this.b.c();
      if (l > this.b.e() || l < l1) {
        a.j("Locking from activity timeout %s", new Object[] { Boolean.valueOf(b.b(this.a)) });
        b.h(this.a, true);
      } 
      b.k(this.a, l);
      d(paramContext);
    } 
    if (b.b(this.a)) {
      this.b.d(l);
    } else if (b.d(this.a)) {
      this.b.d(l + 60000L);
    } else {
      this.b.d(l + 1000L);
    } 
    b.j(this.a, false);
  }
  
  public void g() {
    b.j(this.a, true);
  }
  
  public void h(Activity paramActivity, boolean paramBoolean) {
    boolean bool;
    if (!this.b.b())
      return; 
    b.g(this.a, paramBoolean);
    long l2 = this.b.e();
    long l1 = this.e.a();
    Boolean bool1 = this.g.get(paramActivity);
    this.g.put(paramActivity, Boolean.FALSE);
    if (bool1 == null || bool1.booleanValue()) {
      bool = true;
    } else {
      bool = false;
    } 
    int i = l1 cmp l2;
    if (i > 0) {
      if (bool)
        b.h(this.a, true); 
    } else if (i < 0) {
      b.h(this.a, false);
    } 
    if (l1 - b.c(this.a) <= 500L) {
      b.i(this.a, l1);
      if (paramBoolean)
        paramActivity.finish(); 
    } else if (b.b(this.a) && b.a(this.a)) {
      m((Context)paramActivity);
    } 
    if (!b.b(this.a))
      this.b.d(l1 + 300000L); 
  }
  
  public void i(Activity paramActivity) {
    this.g.put(paramActivity, Boolean.TRUE);
  }
  
  public void j() {
    IntentFilter intentFilter = new IntentFilter("android.intent.action.SCREEN_OFF");
    this.d.registerReceiver((BroadcastReceiver)this, intentFilter);
  }
  
  public void k(Runnable paramRunnable) {
    if (c()) {
      this.c.a((BroadcastReceiver)new a(this, paramRunnable), new IntentFilter("ACTION_UNLOCK"));
    } else {
      paramRunnable.run();
    } 
  }
  
  public final void m(Context paramContext) {
    if (!this.b.b())
      return; 
    a.j("Activity is locked, redirecting to lock code", new Object[0]);
    Intent intent = new Intent(this.f.a(paramContext));
    intent.addFlags(67108864);
    if (paramContext instanceof Activity) {
      ((Activity)paramContext).startActivityForResult(intent, 64913);
    } else {
      intent.addFlags(268435456);
      paramContext.startActivity(intent);
    } 
  }
  
  public void o() {
    this.b.d(this.e.a() + 1000L);
    b.h(this.a, false);
    Intent intent = new Intent("ACTION_UNLOCK");
    this.c.b(intent);
  }
  
  public void onReceive(Context paramContext, Intent paramIntent) {
    super.onReceive(paramContext, paramIntent);
    if (paramIntent.getAction().equals("android.intent.action.SCREEN_OFF")) {
      b.l(this.a, this.e.a());
      d(paramContext);
    } 
  }
  
  public static class b {
    public long a = 0L;
    
    public long b = 0L;
    
    public long c = 0L;
    
    public boolean d = true;
    
    public boolean e = true;
    
    public boolean f = false;
    
    public b() {}
  }
  
  public static class c {
    public final v a;
    
    public c(v param1v) {
      this.a = param1v;
    }
    
    public final u a() {
      return this.a.a();
    }
    
    public boolean b() {
      boolean bool;
      u u = a();
      if (u != null && u.i()) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    public long c() {
      long l;
      u u = a();
      if (u != null) {
        l = u.d();
      } else {
        l = 0L;
      } 
      return l;
    }
    
    public void d(long param1Long) {
      u u = a();
      if (u != null)
        u.j(param1Long); 
    }
    
    public long e() {
      long l;
      u u = a();
      if (u != null) {
        l = u.a();
      } else {
        l = 0L;
      } 
      return l;
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\common\lock_screen\LockReceiver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */