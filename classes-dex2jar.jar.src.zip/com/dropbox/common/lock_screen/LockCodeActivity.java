package com.dropbox.common.lock_screen;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Vibrator;
import android.view.KeyEvent;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;
import com.dropbox.common.activity.BaseActivity;
import dbxyzptlk.Ah.a;
import dbxyzptlk.Df.x;
import dbxyzptlk.Ec.g;
import dbxyzptlk.Fc.e8;
import dbxyzptlk.Fc.f8;
import dbxyzptlk.Fc.g8;
import dbxyzptlk.Fq.f;
import dbxyzptlk.Oh.A;
import dbxyzptlk.Oh.B;
import dbxyzptlk.Oh.C;
import dbxyzptlk.Oh.D;
import dbxyzptlk.Oh.a;
import dbxyzptlk.Oh.b;
import dbxyzptlk.Oh.c;
import dbxyzptlk.Oh.d;
import dbxyzptlk.Oh.e;
import dbxyzptlk.Oh.f;
import dbxyzptlk.Oh.p;
import dbxyzptlk.Oh.s;
import dbxyzptlk.Oh.u;
import dbxyzptlk.Oh.x;
import dbxyzptlk.Oh.y;
import dbxyzptlk.Oh.z;
import dbxyzptlk.V1.b;
import dbxyzptlk.ci.a;
import dbxyzptlk.dk.q;
import dbxyzptlk.eH.D;
import dbxyzptlk.gh.e;
import dbxyzptlk.iH.b;
import dbxyzptlk.kI.a;
import dbxyzptlk.lH.g;
import dbxyzptlk.sL.a;
import io.reactivex.android.schedulers.AndroidSchedulers;
import java.util.concurrent.Callable;

public class LockCodeActivity extends BaseActivity implements c, s, a, f {
  public g c;
  
  public b d;
  
  public b e = new b();
  
  public a f;
  
  public boolean g;
  
  public ImageView h;
  
  public View i;
  
  public ImageView j;
  
  public ImageView k;
  
  public ImageView l;
  
  public ImageView m;
  
  public TextView n;
  
  public String o;
  
  public String p;
  
  public String q = "";
  
  public d r;
  
  public int s = 0;
  
  public int t = 0;
  
  public boolean u;
  
  public long v = 0L;
  
  public u w = null;
  
  public q x;
  
  public LockReceiver y = null;
  
  public Handler z = new Handler();
  
  private void R4() {
    this.q = "";
    k5();
  }
  
  public boolean O2() {
    return false;
  }
  
  public final void P4(int paramInt) {
    this.s = paramInt;
    R4();
    g5();
  }
  
  public final void Q4(String paramString) {
    d d1 = this.r;
    if (d1 != null)
      d1.checkText(this, paramString); 
  }
  
  public final void S4() {
    TextView textView = this.n;
    if (textView != null) {
      textView.setText(D.lock_code_error);
      this.n.setTextColor(b.c((Context)this, e.color__error__text));
      this.n.sendAccessibilityEvent(8);
    } 
    this.h.setImageResource(z.dropbox_passcode_red);
    this.j.setImageResource(z.passcode_bubble_fill_red);
    this.k.setImageResource(z.passcode_bubble_fill_red);
    this.l.setImageResource(z.passcode_bubble_fill_red);
    this.m.setImageResource(z.passcode_bubble_fill_red);
    this.i.startAnimation(AnimationUtils.loadAnimation((Context)this, y.horizontal_shake));
    ((Vibrator)getSystemService("vibrator")).vibrate(300L);
    this.z.postDelayed((Runnable)new b(this), 1000L);
  }
  
  public final void T4(int paramInt) {
    U4(getString(paramInt));
  }
  
  public final void U4(String paramString) {
    x.g((Context)this, paramString);
  }
  
  public void V3() {
    (new e8()).k("fingerprint-unlocked").l(f8.FINGERPRINT).g(this.c);
    i5(-1);
  }
  
  public final void V4(int paramInt) {
    W4(getString(paramInt));
  }
  
  public final void W4(String paramString) {
    x.i((Context)this, paramString);
  }
  
  public boolean X2() {
    return false;
  }
  
  public final boolean X4() {
    if (!this.y.c() && this.r == d.LOCK_SCREEN) {
      a.j("App has been unlocked in a different place, so finishing", new Object[0]);
      finish();
      return true;
    } 
    if (!this.w.i() && this.r == d.EXTERNAL_VERIFY_CODE) {
      a.j("App no longer has lock code so finishing with RESULT_OK", new Object[0]);
      setResult(-1);
      finish();
      return true;
    } 
    return false;
  }
  
  public final boolean Y4(String paramString) {
    if (paramString.equals(this.p)) {
      T4(D.lock_code_success);
      paramString = this.p;
      this.o = paramString;
      this.w.b(paramString);
      i5(-1);
      return true;
    } 
    V4(D.lock_code_error_different);
    if (this.r == d.CHANGE_CODE) {
      P4(1);
    } else {
      P4(0);
    } 
    return false;
  }
  
  public final void Z4() {
    if (!this.q.isEmpty()) {
      String str = this.q;
      this.q = str.substring(0, str.length() - 1);
      k5();
    } 
  }
  
  public boolean a0() {
    d d1 = this.r;
    return (d1 == d.CHANGE_CODE || d1 == d.REMOVE_CODE || d1 == d.REMOVE_ERASE_ON_FAILURE);
  }
  
  public final void a5(int paramInt) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(this.q);
    stringBuilder.append(String.valueOf(paramInt));
    this.q = stringBuilder.toString();
    k5();
    if (this.q.length() >= 4)
      Q4(this.q); 
  }
  
  public final void b5(String paramString) {
    if (paramString.length() == 4) {
      this.p = paramString;
      P4(2);
    } else {
      a.j("Got a non-4 character lock code", new Object[0]);
    } 
  }
  
  public final boolean c5(String paramString) {
    if (paramString.equals(this.o)) {
      (new e8()).k("password-unlocked").l(f8.PASSCODE).g(this.c);
      return true;
    } 
    if (this.g)
      return true; 
    R4();
    int i = this.t + 1;
    this.t = i;
    if (this.u) {
      if (i == 10) {
        V4(D.lock_code_error_unlinking);
        a.j("Unlinking from too many retries on lock code screen", new Object[0]);
        (new e8()).k("unlinked").g(this.c);
        this.e.a(D.u((Callable)new d(this)).J(a.c()).z(AndroidSchedulers.a()).H((g)new e(this), (g)new f(this)));
      } else if (i >= 7) {
        i = 10 - i;
        S4();
        W4(getResources().getQuantityString(C.lock_code_error_few_tries_left_before_unlink_v2, i, new Object[] { Integer.valueOf(i) }));
      } else {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Lock code screen now has ");
        stringBuilder.append(this.t);
        stringBuilder.append(" retries.");
        a.j(stringBuilder.toString(), new Object[0]);
        S4();
      } 
    } else if (i == 10) {
      long l = System.currentTimeMillis() + 600000L;
      this.v = l;
      this.w.c(l);
      LockedForNowDialog.j2(this);
      (new e8()).k("lockedout").g(this.c);
    } else if (i >= 7) {
      i = 10 - i;
      W4(getResources().getQuantityString(C.lock_code_error_few_tries_left_before_lock_out_v2, i, new Object[] { Integer.valueOf(i) }));
      S4();
    } else {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Lock code screen now has ");
      stringBuilder.append(this.t);
      stringBuilder.append(" retries.");
      a.j(stringBuilder.toString(), new Object[0]);
      S4();
    } 
    return false;
  }
  
  public final void g5() {
    int i = this.r.getPrompt(this);
    if (i != 0) {
      TextView textView = this.n;
      if (textView != null) {
        textView.setText(getString(i));
        this.n.sendAccessibilityEvent(8);
      } 
    } 
  }
  
  public void h5() {
    if (X4())
      return; 
    this.o = this.w.e();
    this.u = this.w.k();
    long l = this.w.d();
    this.v = l;
    if (l > System.currentTimeMillis()) {
      LockedForNowDialog.j2(this);
    } else {
      if (this.w.h() && this.x.a()) {
        d d1 = this.r;
        if (d1 == d.LOCK_SCREEN || d1 == d.EXTERNAL_VERIFY_CODE) {
          a a1 = (a)getSupportFragmentManager().m0("fingerprintDialog");
          (new g8()).k(f8.FINGERPRINT).g(this.c);
          if (a1 == null)
            this.d.c().f4((Context)this, getSupportFragmentManager(), "fingerprintDialog"); 
          return;
        } 
      } 
      (new g8()).k(f8.PASSCODE).g(this.c);
    } 
  }
  
  public void i5(int paramInt) {
    a.j("Unlocked Lock Code", new Object[0]);
    setResult(paramInt);
    if (paramInt == -1) {
      this.y.o();
    } else {
      this.y.b();
    } 
    finish();
  }
  
  public final void j5(ImageView paramImageView, boolean paramBoolean) {
    int i;
    if (paramBoolean) {
      i = z.passcode_bubble_fill_blue;
    } else {
      i = z.passcode_bubble_outline_blue;
    } 
    paramImageView.setImageResource(i);
  }
  
  public boolean k0() {
    return false;
  }
  
  public final void k5() {
    int i = this.q.length();
    ImageView imageView = this.j;
    boolean bool2 = false;
    if (i > 0) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    j5(imageView, bool1);
    imageView = this.k;
    if (i > 1) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    j5(imageView, bool1);
    imageView = this.l;
    if (i > 2) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    j5(imageView, bool1);
    imageView = this.m;
    boolean bool1 = bool2;
    if (i > 3)
      bool1 = true; 
    j5(imageView, bool1);
  }
  
  public final String l5(int paramInt1, int paramInt2) {
    return getResources().getQuantityString(C.lock_code_content_description, paramInt2, new Object[] { Integer.valueOf(paramInt2), Integer.valueOf(paramInt1) });
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    if (u())
      return; 
    p p = (p)s();
    this.c = p.d();
    this.w = p.l();
    this.f = p.s();
    this.y = p.b();
    this.g = p.i0();
    this.d = p.x();
    setContentView(B.lock_code_screen);
    this.h = (ImageView)findViewById(A.dbx_logo);
    this.n = (TextView)findViewById(A.lock_code_prompt);
    View view = findViewById(A.lock_digit_container);
    this.i = view;
    view.setFocusable(true);
    this.i.setContentDescription(l5(this.q.length(), 4));
    this.j = (ImageView)this.i.findViewById(A.lock_digit_1);
    this.k = (ImageView)this.i.findViewById(A.lock_digit_2);
    this.l = (ImageView)this.i.findViewById(A.lock_digit_3);
    this.m = (ImageView)this.i.findViewById(A.lock_digit_4);
    ((LockCodeKeyboardView)findViewById(A.pin_keyboard)).setKeyClickListener((x)new a(this));
    this.r = d.fromValue(getIntent().getIntExtra("PURPOSE", d.LOCK_SCREEN.value()));
    this.x = new q((Context)this);
    if (paramBundle != null) {
      this.q = paramBundle.getString("SIS_KEY_LOCK_DIGITS");
      k5();
      this.s = paramBundle.getInt("SIS_KEY_STATE");
      this.t = paramBundle.getInt("SIS_KEY_RETRIES");
      this.p = paramBundle.getString("SIS_KEY_NEW_LOCK_CODE");
    } 
    g5();
    h5();
  }
  
  public Dialog onCreateDialog(int paramInt) {
    return c.fromValue(paramInt).b(this);
  }
  
  public void onDestroy() {
    if (!this.e.isDisposed())
      this.e.dispose(); 
    super.onDestroy();
  }
  
  public boolean onKeyUp(int paramInt, KeyEvent paramKeyEvent) {
    if (paramKeyEvent.getRepeatCount() == 0 && paramInt == 4 && !paramKeyEvent.isCanceled()) {
      if (this.r != d.LOCK_SCREEN) {
        finish();
      } else {
        i5(1);
      } 
      return true;
    } 
    return super.onKeyUp(paramInt, paramKeyEvent);
  }
  
  public void onResumeFragments() {
    super.onResumeFragments();
    if (!isFinishing())
      X4(); 
  }
  
  public void onSaveInstanceState(Bundle paramBundle) {
    super.onSaveInstanceState(paramBundle);
    paramBundle.putString("SIS_KEY_LOCK_DIGITS", this.q);
    paramBundle.putInt("SIS_KEY_STATE", this.s);
    paramBundle.putInt("SIS_KEY_RETRIES", this.t);
    paramBundle.putString("SIS_KEY_NEW_LOCK_CODE", this.p);
  }
  
  class LockCodeActivity {}
  
  class LockCodeActivity {}
  
  class LockCodeActivity {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\common\lock_screen\LockCodeActivity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */