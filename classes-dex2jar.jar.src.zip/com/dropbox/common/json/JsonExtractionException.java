package com.dropbox.common.json;

import dbxyzptlk.XK.d;
import java.util.Iterator;
import java.util.Map;

public final class JsonExtractionException extends Exception {
  private static final long serialVersionUID = -5744582005002105505L;
  
  public JsonExtractionException(String paramString1, String paramString2, Object paramObject) {
    super(a(paramString1, paramString2, paramObject));
  }
  
  public static String a(String paramString1, String paramString2, Object paramObject) {
    StringBuilder stringBuilder = new StringBuilder();
    String str2 = "null";
    String str1 = paramString1;
    if (paramString1 == null)
      str1 = "null"; 
    stringBuilder.append(str1);
    stringBuilder.append(":");
    stringBuilder.append(paramString2);
    stringBuilder.append(":");
    if (paramObject == null) {
      paramString1 = str2;
    } else {
      paramString1 = b(paramObject);
    } 
    stringBuilder.append(paramString1);
    return stringBuilder.toString();
  }
  
  public static String b(Object paramObject) {
    if (paramObject instanceof Map) {
      StringBuilder stringBuilder = new StringBuilder();
      paramObject = paramObject;
      stringBuilder.append("{");
      Iterator<Map.Entry> iterator = paramObject.entrySet().iterator();
      for (paramObject = ""; iterator.hasNext(); paramObject = ", ") {
        Map.Entry entry = iterator.next();
        stringBuilder.append((String)paramObject);
        stringBuilder.append(d.e(entry.getKey()));
        stringBuilder.append(" = ");
        stringBuilder.append("...");
      } 
      stringBuilder.append("}");
      return stringBuilder.toString();
    } 
    if (paramObject instanceof java.util.List) {
      paramObject = paramObject;
      if (paramObject.isEmpty())
        return "[]"; 
      if (paramObject.size() == 1) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("[");
        stringBuilder1.append(b(paramObject.get(0)));
        stringBuilder1.append("]");
        return stringBuilder1.toString();
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("[");
      stringBuilder.append(b(paramObject.get(0)));
      stringBuilder.append(", ...] (");
      stringBuilder.append(paramObject.size());
      stringBuilder.append(" elements)");
      return stringBuilder.toString();
    } 
    return d.e(paramObject);
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\common\json\JsonExtractionException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */