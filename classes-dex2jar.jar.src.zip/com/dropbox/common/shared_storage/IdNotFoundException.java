package com.dropbox.common.shared_storage;

import kotlin.Metadata;

@Metadata(d1 = {"\000\020\n\002\030\002\n\002\030\002\n\002\020\016\n\002\b\b\030\0002\0020\001B\017\022\006\020\003\032\0020\002¢\006\004\b\004\020\005R\027\020\003\032\0020\0028\006¢\006\f\n\004\b\006\020\007\032\004\b\b\020\t¨\006\n"}, d2 = {"Lcom/dropbox/common/shared_storage/IdNotFoundException;", "Lcom/dropbox/common/shared_storage/SharedStoreException;", "", "id", "<init>", "(Ljava/lang/String;)V", "a", "Ljava/lang/String;", "getId", "()Ljava/lang/String;", "common_shared_storage_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class IdNotFoundException extends SharedStoreException {
  public final String a;
  
  public IdNotFoundException(String paramString) {
    super("ID not found.", null, 2, null);
    this.a = paramString;
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\common\shared_storage\IdNotFoundException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */