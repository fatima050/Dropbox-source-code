package com.dropbox.common.shared_storage;

import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

@Metadata(d1 = {"\0004\n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\020\016\n\000\n\002\020\003\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\000\b6\030\0002\0060\001j\002`\002B\037\b\004\022\n\b\002\020\003\032\004\030\0010\004\022\n\b\002\020\005\032\004\030\0010\006¢\006\002\020\007\001\006\b\t\n\013\f\r¨\006\016"}, d2 = {"Lcom/dropbox/common/shared_storage/SharedStoreException;", "Ljava/lang/Exception;", "Lkotlin/Exception;", "message", "", "cause", "", "(Ljava/lang/String;Ljava/lang/Throwable;)V", "Lcom/dropbox/common/shared_storage/DuplicateKeyException;", "Lcom/dropbox/common/shared_storage/EncoderThrewException;", "Lcom/dropbox/common/shared_storage/FrameworkException;", "Lcom/dropbox/common/shared_storage/IdNotFoundException;", "Lcom/dropbox/common/shared_storage/KeyNotFoundException;", "Lcom/dropbox/common/shared_storage/MigrationThrewException;", "common_shared_storage_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
public abstract class SharedStoreException extends Exception {
  public SharedStoreException(String paramString, Throwable paramThrowable) {
    super(paramString, paramThrowable);
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\common\shared_storage\SharedStoreException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */