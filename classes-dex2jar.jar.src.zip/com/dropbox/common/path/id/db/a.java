package com.dropbox.common.path.id.db;

import android.os.CancellationSignal;
import androidx.room.f;
import com.dropbox.product.dbapp.path.Path;
import dbxyzptlk.CI.l;
import dbxyzptlk.DI.s;
import dbxyzptlk.F4.i;
import dbxyzptlk.F4.j;
import dbxyzptlk.F4.s;
import dbxyzptlk.F4.v;
import dbxyzptlk.L4.k;
import dbxyzptlk.ki.b;
import dbxyzptlk.qI.s;
import java.util.List;
import java.util.concurrent.Callable;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

@Metadata(d1 = {"\000D\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\003\n\002\030\002\n\000\n\002\020\t\n\002\b\002\n\002\020\016\n\000\n\002\030\002\n\002\b\b\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\006\030\000 !2\0020\001:\001\021B\017\022\006\020\003\032\0020\002¢\006\004\b\004\020\005J\030\020\t\032\0020\b2\006\020\007\032\0020\006H@¢\006\004\b\t\020\nJ \020\017\032\0020\0062\006\020\f\032\0020\0132\006\020\016\032\0020\rH@¢\006\004\b\017\020\020J\"\020\021\032\004\030\0010\0062\006\020\f\032\0020\0132\006\020\016\032\0020\rH@¢\006\004\b\021\020\020J\032\020\023\032\004\030\0010\0062\006\020\022\032\0020\013H@¢\006\004\b\023\020\024R\024\020\003\032\0020\0028\002X\004¢\006\006\n\004\b\017\020\025R\032\020\030\032\b\022\004\022\0020\0060\0268\002X\004¢\006\006\n\004\b\t\020\027R\024\020\033\032\0020\0318\002X\004¢\006\006\n\004\b\023\020\032R\032\020\036\032\b\022\004\022\0020\0060\0348\002X\004¢\006\006\n\004\b\021\020\035R\032\020 \032\b\022\004\022\0020\0060\0348\002X\004¢\006\006\n\004\b\037\020\035¨\006\""}, d2 = {"Lcom/dropbox/common/path/id/db/a;", "Ldbxyzptlk/ki/b;", "Ldbxyzptlk/F4/s;", "__db", "<init>", "(Ldbxyzptlk/F4/s;)V", "Ldbxyzptlk/ki/a;", "localId", "", "b", "(Ldbxyzptlk/ki/a;Ldbxyzptlk/tI/d;)Ljava/lang/Object;", "", "userId", "Lcom/dropbox/product/dbapp/path/Path;", "path", "a", "(Ljava/lang/String;Lcom/dropbox/product/dbapp/path/Path;Ldbxyzptlk/tI/d;)Ljava/lang/Object;", "d", "id", "c", "(Ljava/lang/String;Ldbxyzptlk/tI/d;)Ljava/lang/Object;", "Ldbxyzptlk/F4/s;", "Ldbxyzptlk/F4/j;", "Ldbxyzptlk/F4/j;", "__insertionAdapterOfLocalId", "Ldbxyzptlk/ki/c;", "Ldbxyzptlk/ki/c;", "__pathTypeConverter", "Ldbxyzptlk/F4/i;", "Ldbxyzptlk/F4/i;", "__deletionAdapterOfLocalId", "e", "__updateAdapterOfLocalId", "f", "common_path_id_impl_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class a implements b {
  public static final d f = new d(null);
  
  public final s a;
  
  public final j<dbxyzptlk.ki.a> b;
  
  public final dbxyzptlk.ki.c c = new dbxyzptlk.ki.c();
  
  public final i<dbxyzptlk.ki.a> d;
  
  public final i<dbxyzptlk.ki.a> e;
  
  public a(s params) {
    this.a = params;
    this.b = new a(params, this);
    this.d = new b(params);
    this.e = new c(params, this);
  }
  
  public Object a(String paramString, Path paramPath, dbxyzptlk.tI.d<? super dbxyzptlk.ki.a> paramd) {
    return f.d(this.a, (l)new g(this, paramString, paramPath, null), paramd);
  }
  
  public Object b(dbxyzptlk.ki.a parama, dbxyzptlk.tI.d<? super Long> paramd) {
    return androidx.room.a.a.c(this.a, true, (Callable)new h(this, parama), paramd);
  }
  
  public Object c(String paramString, dbxyzptlk.tI.d<? super dbxyzptlk.ki.a> paramd) {
    v v = v.i.a("SELECT * FROM localid WHERE id = ?", 1);
    v.I0(1, paramString);
    CancellationSignal cancellationSignal = dbxyzptlk.I4.b.a();
    return androidx.room.a.a.b(this.a, false, cancellationSignal, (Callable)new f(this, v), paramd);
  }
  
  public Object d(String paramString, Path paramPath, dbxyzptlk.tI.d<? super dbxyzptlk.ki.a> paramd) {
    v v = v.i.a("SELECT * FROM localid WHERE userId = ? AND path = ?", 2);
    v.I0(1, paramString);
    v.I0(2, this.c.c(paramPath));
    CancellationSignal cancellationSignal = dbxyzptlk.I4.b.a();
    return androidx.room.a.a.b(this.a, false, cancellationSignal, (Callable)new e(this, v), paramd);
  }
  
  @Metadata(d1 = {"\000%\n\000\n\002\030\002\n\002\030\002\n\002\020\016\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\003*\001\000\b\n\030\0002\b\022\004\022\0020\0020\001J\017\020\004\032\0020\003H\024¢\006\004\b\004\020\005J\037\020\n\032\0020\t2\006\020\007\032\0020\0062\006\020\b\032\0020\002H\024¢\006\004\b\n\020\013¨\006\f"}, d2 = {"com/dropbox/common/path/id/db/a$a", "Ldbxyzptlk/F4/j;", "Ldbxyzptlk/ki/a;", "", "e", "()Ljava/lang/String;", "Ldbxyzptlk/L4/k;", "statement", "entity", "Ldbxyzptlk/pI/D;", "o", "(Ldbxyzptlk/L4/k;Ldbxyzptlk/ki/a;)V", "common_path_id_impl_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
  public static final class a extends j<dbxyzptlk.ki.a> {
    public final a d;
    
    public a(s param1s, a param1a) {
      super(param1s);
    }
    
    public String e() {
      return "INSERT OR IGNORE INTO `LocalId` (`id`,`userId`,`path`) VALUES (?,?,?)";
    }
    
    public void o(k param1k, dbxyzptlk.ki.a param1a) {
      s.h(param1k, "statement");
      s.h(param1a, "entity");
      param1k.I0(1, param1a.a());
      param1k.I0(2, param1a.c());
      param1k.I0(3, a.i(this.d).c(param1a.b()));
    }
  }
  
  @Metadata(d1 = {"\000%\n\000\n\002\030\002\n\002\030\002\n\002\020\016\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\003*\001\000\b\n\030\0002\b\022\004\022\0020\0020\001J\017\020\004\032\0020\003H\024¢\006\004\b\004\020\005J\037\020\n\032\0020\t2\006\020\007\032\0020\0062\006\020\b\032\0020\002H\024¢\006\004\b\n\020\013¨\006\f"}, d2 = {"com/dropbox/common/path/id/db/a$b", "Ldbxyzptlk/F4/i;", "Ldbxyzptlk/ki/a;", "", "e", "()Ljava/lang/String;", "Ldbxyzptlk/L4/k;", "statement", "entity", "Ldbxyzptlk/pI/D;", "m", "(Ldbxyzptlk/L4/k;Ldbxyzptlk/ki/a;)V", "common_path_id_impl_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
  public static final class b extends i<dbxyzptlk.ki.a> {
    public b(s param1s) {
      super(param1s);
    }
    
    public String e() {
      return "DELETE FROM `LocalId` WHERE `id` = ?";
    }
    
    public void m(k param1k, dbxyzptlk.ki.a param1a) {
      s.h(param1k, "statement");
      s.h(param1a, "entity");
      param1k.I0(1, param1a.a());
    }
  }
  
  @Metadata(d1 = {"\000%\n\000\n\002\030\002\n\002\030\002\n\002\020\016\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\003*\001\000\b\n\030\0002\b\022\004\022\0020\0020\001J\017\020\004\032\0020\003H\024¢\006\004\b\004\020\005J\037\020\n\032\0020\t2\006\020\007\032\0020\0062\006\020\b\032\0020\002H\024¢\006\004\b\n\020\013¨\006\f"}, d2 = {"com/dropbox/common/path/id/db/a$c", "Ldbxyzptlk/F4/i;", "Ldbxyzptlk/ki/a;", "", "e", "()Ljava/lang/String;", "Ldbxyzptlk/L4/k;", "statement", "entity", "Ldbxyzptlk/pI/D;", "m", "(Ldbxyzptlk/L4/k;Ldbxyzptlk/ki/a;)V", "common_path_id_impl_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
  public static final class c extends i<dbxyzptlk.ki.a> {
    public final a d;
    
    public c(s param1s, a param1a) {
      super(param1s);
    }
    
    public String e() {
      return "UPDATE OR ABORT `LocalId` SET `id` = ?,`userId` = ?,`path` = ? WHERE `id` = ?";
    }
    
    public void m(k param1k, dbxyzptlk.ki.a param1a) {
      s.h(param1k, "statement");
      s.h(param1a, "entity");
      param1k.I0(1, param1a.a());
      param1k.I0(2, param1a.c());
      param1k.I0(3, a.i(this.d).c(param1a.b()));
      param1k.I0(4, param1a.a());
    }
  }
  
  @Metadata(d1 = {"\000\030\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020 \n\002\030\002\n\002\b\003\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\031\020\006\032\f\022\b\022\006\022\002\b\0030\0050\004H\007¢\006\004\b\006\020\007¨\006\b"}, d2 = {"Lcom/dropbox/common/path/id/db/a$d;", "", "<init>", "()V", "", "Ljava/lang/Class;", "a", "()Ljava/util/List;", "common_path_id_impl_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
  public static final class d {
    public d() {}
    
    public final List<Class<?>> a() {
      return s.m();
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\common\path\id\db\a.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */