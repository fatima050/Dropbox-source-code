package com.dropbox.common.path.id.db;

import androidx.room.d;
import dbxyzptlk.DI.s;
import dbxyzptlk.DI.u;
import dbxyzptlk.F4.g;
import dbxyzptlk.F4.s;
import dbxyzptlk.F4.u;
import dbxyzptlk.I4.f;
import dbxyzptlk.L4.g;
import dbxyzptlk.L4.h;
import dbxyzptlk.pI.j;
import dbxyzptlk.pI.k;
import dbxyzptlk.qI.s;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import kotlin.Metadata;

@Metadata(d1 = {"\000Z\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\020$\n\002\030\002\n\002\020\000\n\002\020 \n\002\b\002\n\002\020\"\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\004\030\0002\0020\001B\007¢\006\004\b\002\020\003J\027\020\007\032\0020\0062\006\020\005\032\0020\004H\024¢\006\004\b\007\020\bJ\017\020\n\032\0020\tH\024¢\006\004\b\n\020\013J1\020\020\032$\022\f\022\n\022\006\b\001\022\0020\0160\r\022\022\022\020\022\f\022\n\022\006\b\001\022\0020\0160\r0\0170\fH\024¢\006\004\b\020\020\021J\035\020\024\032\020\022\f\022\n\022\006\b\001\022\0020\0230\r0\022H\026¢\006\004\b\024\020\025J1\020\030\032\b\022\004\022\0020\0270\0172\032\020\026\032\026\022\f\022\n\022\006\b\001\022\0020\0230\r\022\004\022\0020\0230\fH\026¢\006\004\b\030\020\031J\017\020\033\032\0020\032H\026¢\006\004\b\033\020\034R\032\020 \032\b\022\004\022\0020\0320\0358\002X\004¢\006\006\n\004\b\036\020\037¨\006!"}, d2 = {"Lcom/dropbox/common/path/id/db/LocalIdDatabase_Impl;", "Lcom/dropbox/common/path/id/db/LocalIdDatabase;", "<init>", "()V", "Ldbxyzptlk/F4/g;", "config", "Ldbxyzptlk/L4/h;", "i", "(Ldbxyzptlk/F4/g;)Ldbxyzptlk/L4/h;", "Landroidx/room/d;", "h", "()Landroidx/room/d;", "", "Ljava/lang/Class;", "", "", "r", "()Ljava/util/Map;", "", "Ldbxyzptlk/G4/a;", "q", "()Ljava/util/Set;", "autoMigrationSpecs", "Ldbxyzptlk/G4/b;", "k", "(Ljava/util/Map;)Ljava/util/List;", "Ldbxyzptlk/ki/b;", "J", "()Ldbxyzptlk/ki/b;", "Ldbxyzptlk/pI/j;", "p", "Ldbxyzptlk/pI/j;", "_localIdDao", "common_path_id_impl_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class LocalIdDatabase_Impl extends LocalIdDatabase {
  public final j<dbxyzptlk.ki.b> p = k.a(new a(this));
  
  public dbxyzptlk.ki.b J() {
    return (dbxyzptlk.ki.b)this.p.getValue();
  }
  
  public d h() {
    return new d(this, new HashMap<>(0), new HashMap<>(0), new String[] { "LocalId" });
  }
  
  public h i(g paramg) {
    s.h(paramg, "config");
    u u = new u(paramg, new b(this), "5b30254312a05bac9c497438b06611a8", "20988d303d7c73a734483e5f61cea739");
    h.b b = h.b.f.a(paramg.a).d(paramg.b).c((h.a)u).b();
    return paramg.c.a(b);
  }
  
  public List<dbxyzptlk.G4.b> k(Map<Class<? extends dbxyzptlk.G4.a>, ? extends dbxyzptlk.G4.a> paramMap) {
    s.h(paramMap, "autoMigrationSpecs");
    return new ArrayList<>();
  }
  
  public Set<Class<? extends dbxyzptlk.G4.a>> q() {
    return new HashSet<>();
  }
  
  public Map<Class<? extends Object>, List<Class<? extends Object>>> r() {
    HashMap<Object, Object> hashMap = new HashMap<>();
    hashMap.put(dbxyzptlk.ki.b.class, a.f.a());
    return (Map)hashMap;
  }
  
  @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"Lcom/dropbox/common/path/id/db/a;", "b", "()Lcom/dropbox/common/path/id/db/a;"}, k = 3, mv = {1, 9, 0})
  public static final class a extends u implements dbxyzptlk.CI.a<a> {
    public final LocalIdDatabase_Impl f;
    
    public a(LocalIdDatabase_Impl param1LocalIdDatabase_Impl) {
      super(0);
    }
    
    public final a b() {
      return new a(this.f);
    }
  }
  
  @Metadata(d1 = {"\000\037\n\000\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\007\n\002\030\002\n\002\b\003*\001\000\b\n\030\0002\0020\001J\027\020\005\032\0020\0042\006\020\003\032\0020\002H\026¢\006\004\b\005\020\006J\027\020\007\032\0020\0042\006\020\003\032\0020\002H\026¢\006\004\b\007\020\006J\027\020\b\032\0020\0042\006\020\003\032\0020\002H\026¢\006\004\b\b\020\006J\027\020\t\032\0020\0042\006\020\003\032\0020\002H\026¢\006\004\b\t\020\006J\027\020\n\032\0020\0042\006\020\003\032\0020\002H\026¢\006\004\b\n\020\006J\027\020\013\032\0020\0042\006\020\003\032\0020\002H\026¢\006\004\b\013\020\006J\027\020\r\032\0020\f2\006\020\003\032\0020\002H\026¢\006\004\b\r\020\016¨\006\017"}, d2 = {"com/dropbox/common/path/id/db/LocalIdDatabase_Impl$b", "Ldbxyzptlk/F4/u$b;", "Ldbxyzptlk/L4/g;", "db", "Ldbxyzptlk/pI/D;", "a", "(Ldbxyzptlk/L4/g;)V", "b", "c", "d", "f", "e", "Ldbxyzptlk/F4/u$c;", "g", "(Ldbxyzptlk/L4/g;)Ldbxyzptlk/F4/u$c;", "common_path_id_impl_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
  public static final class b extends u.b {
    public final LocalIdDatabase_Impl b;
    
    public b(LocalIdDatabase_Impl param1LocalIdDatabase_Impl) {
      super(1);
    }
    
    public void a(g param1g) {
      s.h(param1g, "db");
      param1g.B1("CREATE TABLE IF NOT EXISTS `LocalId` (`id` TEXT NOT NULL, `userId` TEXT NOT NULL, `path` TEXT NOT NULL, PRIMARY KEY(`id`))");
      param1g.B1("CREATE UNIQUE INDEX IF NOT EXISTS `index_LocalId_path_userId` ON `LocalId` (`path`, `userId`)");
      param1g.B1("CREATE TABLE IF NOT EXISTS room_master_table (id INTEGER PRIMARY KEY,identity_hash TEXT)");
      param1g.B1("INSERT OR REPLACE INTO room_master_table (id,identity_hash) VALUES(42, '5b30254312a05bac9c497438b06611a8')");
    }
    
    public void b(g param1g) {
      s.h(param1g, "db");
      param1g.B1("DROP TABLE IF EXISTS `LocalId`");
      List list = LocalIdDatabase_Impl.K(this.b);
      if (list != null) {
        Iterator<s.b> iterator = list.iterator();
        while (iterator.hasNext())
          ((s.b)iterator.next()).b(param1g); 
      } 
    }
    
    public void c(g param1g) {
      s.h(param1g, "db");
      List list = LocalIdDatabase_Impl.K(this.b);
      if (list != null) {
        Iterator<s.b> iterator = list.iterator();
        while (iterator.hasNext())
          ((s.b)iterator.next()).a(param1g); 
      } 
    }
    
    public void d(g param1g) {
      s.h(param1g, "db");
      LocalIdDatabase_Impl.M(this.b, param1g);
      LocalIdDatabase_Impl.L(this.b, param1g);
      List list = LocalIdDatabase_Impl.K(this.b);
      if (list != null) {
        Iterator<s.b> iterator = list.iterator();
        while (iterator.hasNext())
          ((s.b)iterator.next()).c(param1g); 
      } 
    }
    
    public void e(g param1g) {
      s.h(param1g, "db");
    }
    
    public void f(g param1g) {
      s.h(param1g, "db");
      dbxyzptlk.I4.b.b(param1g);
    }
    
    public u.c g(g param1g) {
      s.h(param1g, "db");
      HashMap<Object, Object> hashMap = new HashMap<>(3);
      hashMap.put("id", new f.a("id", "TEXT", true, 1, null, 1));
      hashMap.put("userId", new f.a("userId", "TEXT", true, 0, null, 1));
      hashMap.put("path", new f.a("path", "TEXT", true, 0, null, 1));
      HashSet hashSet = new HashSet(0);
      HashSet<f.e> hashSet1 = new HashSet(1);
      hashSet1.add(new f.e("index_LocalId_path_userId", true, s.p((Object[])new String[] { "path", "userId" }, ), s.p((Object[])new String[] { "ASC", "ASC" })));
      f f2 = new f("LocalId", hashMap, hashSet, hashSet1);
      f f1 = f.e.a(param1g, "LocalId");
      if (!f2.equals(f1)) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("LocalId(com.dropbox.common.path.id.db.LocalId).\n Expected:\n");
        stringBuilder.append(f2);
        stringBuilder.append("\n Found:\n");
        stringBuilder.append(f1);
        return new u.c(false, stringBuilder.toString());
      } 
      return new u.c(true, null);
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\common\path\id\db\LocalIdDatabase_Impl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */