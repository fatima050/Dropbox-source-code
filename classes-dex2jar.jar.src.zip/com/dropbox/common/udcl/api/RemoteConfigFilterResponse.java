package com.dropbox.common.udcl.api;

import androidx.annotation.Keep;
import dbxyzptlk.DI.s;
import dbxyzptlk.pK.h;
import dbxyzptlk.pK.i;
import dbxyzptlk.rK.f;
import dbxyzptlk.sK.c;
import dbxyzptlk.sK.d;
import dbxyzptlk.sK.e;
import dbxyzptlk.sK.f;
import dbxyzptlk.tK.I0;
import dbxyzptlk.tK.L;
import dbxyzptlk.tK.N0;
import dbxyzptlk.tK.c0;
import dbxyzptlk.tK.y0;
import java.util.Set;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlinx.serialization.UnknownFieldException;

@h
@Metadata(d1 = {"\000>\n\002\030\002\n\002\020\000\n\002\020\"\n\002\020\016\n\002\b\003\n\002\020\b\n\000\n\002\030\002\n\002\b\003\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\f\n\002\020\013\n\002\b\n\b\b\030\000 %2\0020\001:\002&'B\027\022\016\020\004\032\n\022\004\022\0020\003\030\0010\002¢\006\004\b\005\020\006B-\b\021\022\006\020\b\032\0020\007\022\020\b\001\020\004\032\n\022\004\022\0020\003\030\0010\002\022\b\020\n\032\004\030\0010\t¢\006\004\b\005\020\013J(\020\024\032\0020\0212\006\020\f\032\0020\0002\006\020\016\032\0020\r2\006\020\020\032\0020\017HÁ\001¢\006\004\b\022\020\023J\030\020\025\032\n\022\004\022\0020\003\030\0010\002HÆ\003¢\006\004\b\025\020\026J\"\020\027\032\0020\0002\020\b\002\020\004\032\n\022\004\022\0020\003\030\0010\002HÆ\001¢\006\004\b\027\020\030J\020\020\031\032\0020\003HÖ\001¢\006\004\b\031\020\032J\020\020\033\032\0020\007HÖ\001¢\006\004\b\033\020\034J\032\020\037\032\0020\0362\b\020\035\032\004\030\0010\001HÖ\003¢\006\004\b\037\020 R(\020\004\032\n\022\004\022\0020\003\030\0010\0028\006X\004¢\006\022\n\004\b\004\020!\022\004\b#\020$\032\004\b\"\020\026¨\006("}, d2 = {"Lcom/dropbox/common/udcl/api/RemoteConfigFilterResponse;", "", "", "", "blockedEventNames", "<init>", "(Ljava/util/Set;)V", "", "seen1", "Ldbxyzptlk/tK/I0;", "serializationConstructorMarker", "(ILjava/util/Set;Ldbxyzptlk/tK/I0;)V", "self", "Ldbxyzptlk/sK/d;", "output", "Ldbxyzptlk/rK/f;", "serialDesc", "Ldbxyzptlk/pI/D;", "write$Self$common_analytics_udcl_api_release", "(Lcom/dropbox/common/udcl/api/RemoteConfigFilterResponse;Ldbxyzptlk/sK/d;Ldbxyzptlk/rK/f;)V", "write$Self", "component1", "()Ljava/util/Set;", "copy", "(Ljava/util/Set;)Lcom/dropbox/common/udcl/api/RemoteConfigFilterResponse;", "toString", "()Ljava/lang/String;", "hashCode", "()I", "other", "", "equals", "(Ljava/lang/Object;)Z", "Ljava/util/Set;", "getBlockedEventNames", "getBlockedEventNames$annotations", "()V", "Companion", "a", "b", "common_analytics_udcl_api_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
@Keep
public final class RemoteConfigFilterResponse {
  private static final dbxyzptlk.pK.b<Object>[] $childSerializers;
  
  public static final b Companion = new b(null);
  
  private final Set<String> blockedEventNames;
  
  static {
    $childSerializers = (dbxyzptlk.pK.b<Object>[])new dbxyzptlk.pK.b[] { (dbxyzptlk.pK.b)new c0((dbxyzptlk.pK.b)N0.a) };
  }
  
  public RemoteConfigFilterResponse(Set<String> paramSet) {
    this.blockedEventNames = paramSet;
  }
  
  public final Set<String> component1() {
    return this.blockedEventNames;
  }
  
  public final RemoteConfigFilterResponse copy(Set<String> paramSet) {
    return new RemoteConfigFilterResponse(paramSet);
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof RemoteConfigFilterResponse))
      return false; 
    paramObject = paramObject;
    return !!s.c(this.blockedEventNames, ((RemoteConfigFilterResponse)paramObject).blockedEventNames);
  }
  
  public final Set<String> getBlockedEventNames() {
    return this.blockedEventNames;
  }
  
  public int hashCode() {
    int i;
    Set<String> set = this.blockedEventNames;
    if (set == null) {
      i = 0;
    } else {
      i = set.hashCode();
    } 
    return i;
  }
  
  public String toString() {
    Set<String> set = this.blockedEventNames;
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("RemoteConfigFilterResponse(blockedEventNames=");
    stringBuilder.append(set);
    stringBuilder.append(")");
    return stringBuilder.toString();
  }
  
  @Metadata(d1 = {"\000:\n\000\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\021\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\004\bÇ\002\030\0002\b\022\004\022\0020\0020\001B\t\b\002¢\006\004\b\003\020\004J\032\020\007\032\f\022\b\022\006\022\002\b\0030\0060\005HÖ\001¢\006\004\b\007\020\bJ\030\020\013\032\0020\0022\006\020\n\032\0020\tHÖ\001¢\006\004\b\013\020\fJ \020\021\032\0020\0202\006\020\016\032\0020\r2\006\020\017\032\0020\002HÖ\001¢\006\004\b\021\020\022R\024\020\026\032\0020\0238VXÖ\005¢\006\006\032\004\b\024\020\025¨\006\027"}, d2 = {"com/dropbox/common/udcl/api/RemoteConfigFilterResponse.$serializer", "Ldbxyzptlk/tK/L;", "Lcom/dropbox/common/udcl/api/RemoteConfigFilterResponse;", "<init>", "()V", "", "Ldbxyzptlk/pK/b;", "childSerializers", "()[Ldbxyzptlk/pK/b;", "Ldbxyzptlk/sK/e;", "decoder", "a", "(Ldbxyzptlk/sK/e;)Lcom/dropbox/common/udcl/api/RemoteConfigFilterResponse;", "Ldbxyzptlk/sK/f;", "encoder", "value", "Ldbxyzptlk/pI/D;", "b", "(Ldbxyzptlk/sK/f;Lcom/dropbox/common/udcl/api/RemoteConfigFilterResponse;)V", "Ldbxyzptlk/rK/f;", "getDescriptor", "()Ldbxyzptlk/rK/f;", "descriptor", "common_analytics_udcl_api_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
  public static final class a implements L<RemoteConfigFilterResponse> {
    public static final a a;
    
    public static final y0 b;
    
    static {
      a a1 = new a();
      a = a1;
      y0 y01 = new y0("com.dropbox.common.udcl.api.RemoteConfigFilterResponse", a1, 1);
      y01.m("blocked_event_names", false);
      b = y01;
    }
    
    public RemoteConfigFilterResponse a(e param1e) {
      Set set;
      s.h(param1e, "decoder");
      f f = getDescriptor();
      c c = param1e.c(f);
      dbxyzptlk.pK.b[] arrayOfB = (dbxyzptlk.pK.b[])RemoteConfigFilterResponse.$childSerializers;
      boolean bool1 = c.m();
      boolean bool = true;
      if (bool1) {
        set = (Set)c.y(f, 0, (dbxyzptlk.pK.a)arrayOfB[0], null);
      } else {
        boolean bool2 = true;
        bool = false;
        param1e = null;
        while (bool2) {
          int i = c.h(f);
          if (i != -1) {
            if (i == 0) {
              set = (Set)c.y(f, 0, (dbxyzptlk.pK.a)arrayOfB[0], param1e);
              bool = true;
              continue;
            } 
            throw new UnknownFieldException(i);
          } 
          bool2 = false;
        } 
      } 
      c.d(f);
      return new RemoteConfigFilterResponse(bool, set, null);
    }
    
    public void b(f param1f, RemoteConfigFilterResponse param1RemoteConfigFilterResponse) {
      s.h(param1f, "encoder");
      s.h(param1RemoteConfigFilterResponse, "value");
      f f1 = getDescriptor();
      d d = param1f.c(f1);
      RemoteConfigFilterResponse.write$Self$common_analytics_udcl_api_release(param1RemoteConfigFilterResponse, d, f1);
      d.d(f1);
    }
    
    public dbxyzptlk.pK.b<?>[] childSerializers() {
      return (dbxyzptlk.pK.b<?>[])new dbxyzptlk.pK.b[] { dbxyzptlk.qK.a.t(RemoteConfigFilterResponse.access$get$childSerializers$cp()[0]) };
    }
    
    public f getDescriptor() {
      return (f)b;
    }
    
    public dbxyzptlk.pK.b<?>[] typeParametersSerializers() {
      return (dbxyzptlk.pK.b<?>[])L.a.a(this);
    }
  }
  
  @Metadata(d1 = {"\000\030\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\030\002\n\002\b\003\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\026\020\006\032\b\022\004\022\0020\0050\004HÆ\001¢\006\004\b\006\020\007¨\006\b"}, d2 = {"Lcom/dropbox/common/udcl/api/RemoteConfigFilterResponse$b;", "", "<init>", "()V", "Ldbxyzptlk/pK/b;", "Lcom/dropbox/common/udcl/api/RemoteConfigFilterResponse;", "serializer", "()Ldbxyzptlk/pK/b;", "common_analytics_udcl_api_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
  public static final class b {
    public b() {}
    
    public final dbxyzptlk.pK.b<RemoteConfigFilterResponse> serializer() {
      return (dbxyzptlk.pK.b<RemoteConfigFilterResponse>)RemoteConfigFilterResponse.a.a;
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\commo\\udcl\api\RemoteConfigFilterResponse.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */