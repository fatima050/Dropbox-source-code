package com.dropbox.common.udcl.impl.internal.udcl_repository;

import androidx.lifecycle.DefaultLifecycleObserver;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.ProcessLifecycleOwner;
import com.dropbox.common.udcl.impl.internal.udcl_repository.db.UdclDatabase;
import com.squareup.anvil.annotations.ContributesBinding;
import dbxyzptlk.CI.p;
import dbxyzptlk.DI.s;
import dbxyzptlk.DI.u;
import dbxyzptlk.Ec.g;
import dbxyzptlk.Fc.Qh;
import dbxyzptlk.Fc.Rh;
import dbxyzptlk.Jh.d;
import dbxyzptlk.Tj.e;
import dbxyzptlk.bK.F;
import dbxyzptlk.bK.J;
import dbxyzptlk.bK.T;
import dbxyzptlk.bK.Z;
import dbxyzptlk.bK.w0;
import dbxyzptlk.pI.D;
import dbxyzptlk.pI.p;
import dbxyzptlk.tI.g;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import kotlin.Metadata;

@ContributesBinding(boundType = e.class, scope = d.class)
@Metadata(d1 = {"\000t\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\003\n\002\030\002\n\002\020\013\n\002\b\005\n\002\020!\n\002\b\002\n\002\020\003\n\002\020\b\n\002\b\f\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\006\n\002\030\002\n\002\b\006\b\007\030\0002\0020\0012\0020\002B-\b\007\022\b\b\001\020\004\032\0020\003\022\006\020\006\032\0020\005\022\006\020\b\032\0020\007\022\b\b\001\020\n\032\0020\t¢\006\004\b\013\020\fJ\030\020\020\032\0020\0172\006\020\016\032\0020\rH@¢\006\004\b\020\020\021J\027\020\024\032\0020\0172\006\020\023\032\0020\022H\026¢\006\004\b\024\020\025J\030\020\030\032\0020\0272\006\020\016\032\0020\026H@¢\006\004\b\030\020\031J\020\020\032\032\0020\017H@¢\006\004\b\032\020\033J\020\020\034\032\0020\017H@¢\006\004\b\034\020\033J\026\020\036\032\b\022\004\022\0020\0260\035H@¢\006\004\b\036\020\033J\020\020\037\032\0020\017H@¢\006\004\b\037\020\033J\033\020#\032\0020\017*\0020 2\006\020\"\032\0020!H\002¢\006\004\b#\020$J\025\020%\032\004\030\0010\026*\0020\rH\002¢\006\004\b%\020&J\023\020'\032\0020\027*\0020\rH\002¢\006\004\b'\020(R\024\020\004\032\0020\0038\002X\004¢\006\006\n\004\b\020\020)R\024\020\006\032\0020\0058\002X\004¢\006\006\n\004\b*\020+R\024\020\n\032\0020\t8\002X\004¢\006\006\n\004\b,\020-R\024\0201\032\0020.8\002X\004¢\006\006\n\004\b/\0200R\030\0205\032\004\030\001028\002@\002X\016¢\006\006\n\004\b3\0204R\034\0208\032\b\022\004\022\0020\0260\0358\002@\002X\016¢\006\006\n\004\b6\0207R\033\020>\032\002098BX\002¢\006\f\n\004\b:\020;\032\004\b<\020=¨\006?"}, d2 = {"Lcom/dropbox/common/udcl/impl/internal/udcl_repository/RealUdclDbWriter;", "Ldbxyzptlk/Tj/e;", "Landroidx/lifecycle/DefaultLifecycleObserver;", "Ldbxyzptlk/bK/J;", "coroutineScope", "Ldbxyzptlk/Ec/g;", "logger", "Lcom/dropbox/common/udcl/impl/internal/udcl_repository/db/UdclDatabase;", "udclDatabase", "Ldbxyzptlk/bK/F;", "ioDispatcher", "<init>", "(Ldbxyzptlk/bK/J;Ldbxyzptlk/Ec/g;Lcom/dropbox/common/udcl/impl/internal/udcl_repository/db/UdclDatabase;Ldbxyzptlk/bK/F;)V", "Ldbxyzptlk/Ij/k;", "measure", "Ldbxyzptlk/pI/D;", "a", "(Ldbxyzptlk/Ij/k;Ldbxyzptlk/tI/d;)Ljava/lang/Object;", "Landroidx/lifecycle/LifecycleOwner;", "owner", "onStop", "(Landroidx/lifecycle/LifecycleOwner;)V", "Ldbxyzptlk/Uj/d;", "", "k", "(Ldbxyzptlk/Uj/d;Ldbxyzptlk/tI/d;)Ljava/lang/Object;", "u", "(Ldbxyzptlk/tI/d;)Ljava/lang/Object;", "m", "", "p", "t", "", "", "size", "s", "(Ljava/lang/Throwable;I)V", "v", "(Ldbxyzptlk/Ij/k;)Ldbxyzptlk/Uj/d;", "q", "(Ldbxyzptlk/Ij/k;)Z", "Ldbxyzptlk/bK/J;", "b", "Ldbxyzptlk/Ec/g;", "c", "Ldbxyzptlk/bK/F;", "Ldbxyzptlk/mK/a;", "d", "Ldbxyzptlk/mK/a;", "lock", "Ldbxyzptlk/bK/w0;", "e", "Ldbxyzptlk/bK/w0;", "saveJob", "f", "Ljava/util/List;", "inMemQueue", "Ldbxyzptlk/Uj/a;", "g", "Ldbxyzptlk/pI/j;", "o", "()Ldbxyzptlk/Uj/a;", "db", "common_analytics_udcl_impl_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class RealUdclDbWriter implements e, DefaultLifecycleObserver {
  public final J a;
  
  public final g b;
  
  public final F c;
  
  public final dbxyzptlk.mK.a d;
  
  public volatile w0 e;
  
  public volatile List<dbxyzptlk.Uj.d> f;
  
  public final dbxyzptlk.pI.j g;
  
  public RealUdclDbWriter(J paramJ, g paramg, UdclDatabase paramUdclDatabase, F paramF) {
    this.a = paramJ;
    this.b = paramg;
    this.c = paramF;
    this.d = dbxyzptlk.mK.c.b(false, 1, null);
    this.f = new ArrayList<>();
    this.g = dbxyzptlk.pI.k.a(new c(paramUdclDatabase));
    dbxyzptlk.bK.h.d(paramJ, (g)Z.c(), null, new a(this, null), 2, null);
  }
  
  public Object a(dbxyzptlk.Ij.k paramk, dbxyzptlk.tI.d<? super D> paramd) {
    // Byte code:
    //   0: aload_2
    //   1: instanceof com/dropbox/common/udcl/impl/internal/udcl_repository/RealUdclDbWriter$h
    //   4: ifeq -> 41
    //   7: aload_2
    //   8: checkcast com/dropbox/common/udcl/impl/internal/udcl_repository/RealUdclDbWriter$h
    //   11: astore #4
    //   13: aload #4
    //   15: getfield w : I
    //   18: istore_3
    //   19: iload_3
    //   20: ldc -2147483648
    //   22: iand
    //   23: ifeq -> 41
    //   26: aload #4
    //   28: iload_3
    //   29: ldc -2147483648
    //   31: iadd
    //   32: putfield w : I
    //   35: aload #4
    //   37: astore_2
    //   38: goto -> 51
    //   41: new com/dropbox/common/udcl/impl/internal/udcl_repository/RealUdclDbWriter$h
    //   44: dup
    //   45: aload_0
    //   46: aload_2
    //   47: invokespecial <init> : (Lcom/dropbox/common/udcl/impl/internal/udcl_repository/RealUdclDbWriter;Ldbxyzptlk/tI/d;)V
    //   50: astore_2
    //   51: aload_2
    //   52: getfield u : Ljava/lang/Object;
    //   55: astore #5
    //   57: invokestatic g : ()Ljava/lang/Object;
    //   60: astore #4
    //   62: aload_2
    //   63: getfield w : I
    //   66: istore_3
    //   67: iload_3
    //   68: ifeq -> 115
    //   71: iload_3
    //   72: iconst_1
    //   73: if_icmpeq -> 99
    //   76: iload_3
    //   77: iconst_2
    //   78: if_icmpne -> 89
    //   81: aload #5
    //   83: invokestatic b : (Ljava/lang/Object;)V
    //   86: goto -> 179
    //   89: new java/lang/IllegalStateException
    //   92: dup
    //   93: ldc 'call to 'resume' before 'invoke' with coroutine'
    //   95: invokespecial <init> : (Ljava/lang/String;)V
    //   98: athrow
    //   99: aload_2
    //   100: getfield t : Ljava/lang/Object;
    //   103: checkcast com/dropbox/common/udcl/impl/internal/udcl_repository/RealUdclDbWriter
    //   106: astore_1
    //   107: aload #5
    //   109: invokestatic b : (Ljava/lang/Object;)V
    //   112: goto -> 156
    //   115: aload #5
    //   117: invokestatic b : (Ljava/lang/Object;)V
    //   120: aload_0
    //   121: aload_1
    //   122: invokevirtual v : (Ldbxyzptlk/Ij/k;)Ldbxyzptlk/Uj/d;
    //   125: astore_1
    //   126: aload_1
    //   127: ifnull -> 179
    //   130: aload_2
    //   131: aload_0
    //   132: putfield t : Ljava/lang/Object;
    //   135: aload_2
    //   136: iconst_1
    //   137: putfield w : I
    //   140: aload_0
    //   141: aload_1
    //   142: aload_2
    //   143: invokevirtual k : (Ldbxyzptlk/Uj/d;Ldbxyzptlk/tI/d;)Ljava/lang/Object;
    //   146: aload #4
    //   148: if_acmpne -> 154
    //   151: aload #4
    //   153: areturn
    //   154: aload_0
    //   155: astore_1
    //   156: aload_2
    //   157: aconst_null
    //   158: putfield t : Ljava/lang/Object;
    //   161: aload_2
    //   162: iconst_2
    //   163: putfield w : I
    //   166: aload_1
    //   167: aload_2
    //   168: invokevirtual u : (Ldbxyzptlk/tI/d;)Ljava/lang/Object;
    //   171: aload #4
    //   173: if_acmpne -> 179
    //   176: aload #4
    //   178: areturn
    //   179: getstatic dbxyzptlk/pI/D.a : Ldbxyzptlk/pI/D;
    //   182: areturn
  }
  
  public final Object k(dbxyzptlk.Uj.d paramd, dbxyzptlk.tI.d<? super Boolean> paramd1) {
    // Byte code:
    //   0: aload_2
    //   1: instanceof com/dropbox/common/udcl/impl/internal/udcl_repository/RealUdclDbWriter$b
    //   4: ifeq -> 41
    //   7: aload_2
    //   8: checkcast com/dropbox/common/udcl/impl/internal/udcl_repository/RealUdclDbWriter$b
    //   11: astore #4
    //   13: aload #4
    //   15: getfield y : I
    //   18: istore_3
    //   19: iload_3
    //   20: ldc -2147483648
    //   22: iand
    //   23: ifeq -> 41
    //   26: aload #4
    //   28: iload_3
    //   29: ldc -2147483648
    //   31: iadd
    //   32: putfield y : I
    //   35: aload #4
    //   37: astore_2
    //   38: goto -> 51
    //   41: new com/dropbox/common/udcl/impl/internal/udcl_repository/RealUdclDbWriter$b
    //   44: dup
    //   45: aload_0
    //   46: aload_2
    //   47: invokespecial <init> : (Lcom/dropbox/common/udcl/impl/internal/udcl_repository/RealUdclDbWriter;Ldbxyzptlk/tI/d;)V
    //   50: astore_2
    //   51: aload_2
    //   52: getfield w : Ljava/lang/Object;
    //   55: astore #6
    //   57: invokestatic g : ()Ljava/lang/Object;
    //   60: astore #5
    //   62: aload_2
    //   63: getfield y : I
    //   66: istore_3
    //   67: iload_3
    //   68: ifeq -> 123
    //   71: iload_3
    //   72: iconst_1
    //   73: if_icmpne -> 113
    //   76: aload_2
    //   77: getfield v : Ljava/lang/Object;
    //   80: checkcast dbxyzptlk/mK/a
    //   83: astore #5
    //   85: aload_2
    //   86: getfield u : Ljava/lang/Object;
    //   89: checkcast dbxyzptlk/Uj/d
    //   92: astore #4
    //   94: aload_2
    //   95: getfield t : Ljava/lang/Object;
    //   98: checkcast com/dropbox/common/udcl/impl/internal/udcl_repository/RealUdclDbWriter
    //   101: astore_1
    //   102: aload #6
    //   104: invokestatic b : (Ljava/lang/Object;)V
    //   107: aload #5
    //   109: astore_2
    //   110: goto -> 184
    //   113: new java/lang/IllegalStateException
    //   116: dup
    //   117: ldc 'call to 'resume' before 'invoke' with coroutine'
    //   119: invokespecial <init> : (Ljava/lang/String;)V
    //   122: athrow
    //   123: aload #6
    //   125: invokestatic b : (Ljava/lang/Object;)V
    //   128: aload_0
    //   129: getfield d : Ldbxyzptlk/mK/a;
    //   132: astore #4
    //   134: aload_2
    //   135: aload_0
    //   136: putfield t : Ljava/lang/Object;
    //   139: aload_2
    //   140: aload_1
    //   141: putfield u : Ljava/lang/Object;
    //   144: aload_2
    //   145: aload #4
    //   147: putfield v : Ljava/lang/Object;
    //   150: aload_2
    //   151: iconst_1
    //   152: putfield y : I
    //   155: aload #4
    //   157: aconst_null
    //   158: aload_2
    //   159: invokeinterface a : (Ljava/lang/Object;Ldbxyzptlk/tI/d;)Ljava/lang/Object;
    //   164: aload #5
    //   166: if_acmpne -> 172
    //   169: aload #5
    //   171: areturn
    //   172: aload_0
    //   173: astore #5
    //   175: aload #4
    //   177: astore_2
    //   178: aload_1
    //   179: astore #4
    //   181: aload #5
    //   183: astore_1
    //   184: aload_1
    //   185: getfield f : Ljava/util/List;
    //   188: aload #4
    //   190: invokeinterface add : (Ljava/lang/Object;)Z
    //   195: invokestatic a : (Z)Ljava/lang/Boolean;
    //   198: astore_1
    //   199: aload_2
    //   200: aconst_null
    //   201: invokeinterface d : (Ljava/lang/Object;)V
    //   206: aload_1
    //   207: areturn
    //   208: astore_1
    //   209: aload_2
    //   210: aconst_null
    //   211: invokeinterface d : (Ljava/lang/Object;)V
    //   216: aload_1
    //   217: athrow
    // Exception table:
    //   from	to	target	type
    //   184	199	208	finally
  }
  
  public final Object m(dbxyzptlk.tI.d<? super D> paramd) {
    // Byte code:
    //   0: aload_1
    //   1: instanceof com/dropbox/common/udcl/impl/internal/udcl_repository/RealUdclDbWriter$d
    //   4: ifeq -> 37
    //   7: aload_1
    //   8: checkcast com/dropbox/common/udcl/impl/internal/udcl_repository/RealUdclDbWriter$d
    //   11: astore_3
    //   12: aload_3
    //   13: getfield w : I
    //   16: istore_2
    //   17: iload_2
    //   18: ldc -2147483648
    //   20: iand
    //   21: ifeq -> 37
    //   24: aload_3
    //   25: iload_2
    //   26: ldc -2147483648
    //   28: iadd
    //   29: putfield w : I
    //   32: aload_3
    //   33: astore_1
    //   34: goto -> 47
    //   37: new com/dropbox/common/udcl/impl/internal/udcl_repository/RealUdclDbWriter$d
    //   40: dup
    //   41: aload_0
    //   42: aload_1
    //   43: invokespecial <init> : (Lcom/dropbox/common/udcl/impl/internal/udcl_repository/RealUdclDbWriter;Ldbxyzptlk/tI/d;)V
    //   46: astore_1
    //   47: aload_1
    //   48: getfield u : Ljava/lang/Object;
    //   51: astore_3
    //   52: invokestatic g : ()Ljava/lang/Object;
    //   55: astore #5
    //   57: aload_1
    //   58: getfield w : I
    //   61: istore_2
    //   62: iload_2
    //   63: ifeq -> 109
    //   66: iload_2
    //   67: iconst_1
    //   68: if_icmpeq -> 93
    //   71: iload_2
    //   72: iconst_2
    //   73: if_icmpne -> 83
    //   76: aload_3
    //   77: invokestatic b : (Ljava/lang/Object;)V
    //   80: goto -> 179
    //   83: new java/lang/IllegalStateException
    //   86: dup
    //   87: ldc 'call to 'resume' before 'invoke' with coroutine'
    //   89: invokespecial <init> : (Ljava/lang/String;)V
    //   92: athrow
    //   93: aload_1
    //   94: getfield t : Ljava/lang/Object;
    //   97: checkcast com/dropbox/common/udcl/impl/internal/udcl_repository/RealUdclDbWriter
    //   100: astore #4
    //   102: aload_3
    //   103: invokestatic b : (Ljava/lang/Object;)V
    //   106: goto -> 141
    //   109: aload_3
    //   110: invokestatic b : (Ljava/lang/Object;)V
    //   113: aload_1
    //   114: aload_0
    //   115: putfield t : Ljava/lang/Object;
    //   118: aload_1
    //   119: iconst_1
    //   120: putfield w : I
    //   123: aload_0
    //   124: aload_1
    //   125: invokevirtual p : (Ldbxyzptlk/tI/d;)Ljava/lang/Object;
    //   128: astore_3
    //   129: aload_3
    //   130: aload #5
    //   132: if_acmpne -> 138
    //   135: aload #5
    //   137: areturn
    //   138: aload_0
    //   139: astore #4
    //   141: new com/dropbox/common/udcl/impl/internal/udcl_repository/RealUdclDbWriter$e
    //   144: dup
    //   145: aload #4
    //   147: aload_3
    //   148: checkcast java/util/List
    //   151: aconst_null
    //   152: invokespecial <init> : (Lcom/dropbox/common/udcl/impl/internal/udcl_repository/RealUdclDbWriter;Ljava/util/List;Ldbxyzptlk/tI/d;)V
    //   155: astore_3
    //   156: aload_1
    //   157: aconst_null
    //   158: putfield t : Ljava/lang/Object;
    //   161: aload_1
    //   162: iconst_2
    //   163: putfield w : I
    //   166: aload_3
    //   167: aload_1
    //   168: invokestatic a : (Ldbxyzptlk/CI/l;Ldbxyzptlk/tI/d;)Ljava/lang/Object;
    //   171: aload #5
    //   173: if_acmpne -> 179
    //   176: aload #5
    //   178: areturn
    //   179: getstatic dbxyzptlk/pI/D.a : Ldbxyzptlk/pI/D;
    //   182: areturn
  }
  
  public final dbxyzptlk.Uj.a o() {
    return (dbxyzptlk.Uj.a)this.g.getValue();
  }
  
  public void onStop(LifecycleOwner paramLifecycleOwner) {
    s.h(paramLifecycleOwner, "owner");
    dbxyzptlk.bK.h.d(this.a, (g)this.c, null, (p)new g(this, null), 2, null);
  }
  
  public final Object p(dbxyzptlk.tI.d<? super List<dbxyzptlk.Uj.d>> paramd) {
    // Byte code:
    //   0: aload_1
    //   1: instanceof com/dropbox/common/udcl/impl/internal/udcl_repository/RealUdclDbWriter$f
    //   4: ifeq -> 37
    //   7: aload_1
    //   8: checkcast com/dropbox/common/udcl/impl/internal/udcl_repository/RealUdclDbWriter$f
    //   11: astore_3
    //   12: aload_3
    //   13: getfield x : I
    //   16: istore_2
    //   17: iload_2
    //   18: ldc -2147483648
    //   20: iand
    //   21: ifeq -> 37
    //   24: aload_3
    //   25: iload_2
    //   26: ldc -2147483648
    //   28: iadd
    //   29: putfield x : I
    //   32: aload_3
    //   33: astore_1
    //   34: goto -> 47
    //   37: new com/dropbox/common/udcl/impl/internal/udcl_repository/RealUdclDbWriter$f
    //   40: dup
    //   41: aload_0
    //   42: aload_1
    //   43: invokespecial <init> : (Lcom/dropbox/common/udcl/impl/internal/udcl_repository/RealUdclDbWriter;Ldbxyzptlk/tI/d;)V
    //   46: astore_1
    //   47: aload_1
    //   48: getfield v : Ljava/lang/Object;
    //   51: astore #5
    //   53: invokestatic g : ()Ljava/lang/Object;
    //   56: astore_3
    //   57: aload_1
    //   58: getfield x : I
    //   61: istore_2
    //   62: iload_2
    //   63: ifeq -> 109
    //   66: iload_2
    //   67: iconst_1
    //   68: if_icmpne -> 99
    //   71: aload_1
    //   72: getfield u : Ljava/lang/Object;
    //   75: checkcast dbxyzptlk/mK/a
    //   78: astore #4
    //   80: aload_1
    //   81: getfield t : Ljava/lang/Object;
    //   84: checkcast com/dropbox/common/udcl/impl/internal/udcl_repository/RealUdclDbWriter
    //   87: astore_3
    //   88: aload #5
    //   90: invokestatic b : (Ljava/lang/Object;)V
    //   93: aload #4
    //   95: astore_1
    //   96: goto -> 156
    //   99: new java/lang/IllegalStateException
    //   102: dup
    //   103: ldc 'call to 'resume' before 'invoke' with coroutine'
    //   105: invokespecial <init> : (Ljava/lang/String;)V
    //   108: athrow
    //   109: aload #5
    //   111: invokestatic b : (Ljava/lang/Object;)V
    //   114: aload_0
    //   115: getfield d : Ldbxyzptlk/mK/a;
    //   118: astore #4
    //   120: aload_1
    //   121: aload_0
    //   122: putfield t : Ljava/lang/Object;
    //   125: aload_1
    //   126: aload #4
    //   128: putfield u : Ljava/lang/Object;
    //   131: aload_1
    //   132: iconst_1
    //   133: putfield x : I
    //   136: aload #4
    //   138: aconst_null
    //   139: aload_1
    //   140: invokeinterface a : (Ljava/lang/Object;Ldbxyzptlk/tI/d;)Ljava/lang/Object;
    //   145: aload_3
    //   146: if_acmpne -> 151
    //   149: aload_3
    //   150: areturn
    //   151: aload_0
    //   152: astore_3
    //   153: aload #4
    //   155: astore_1
    //   156: aload_3
    //   157: getfield f : Ljava/util/List;
    //   160: astore #4
    //   162: new java/util/ArrayList
    //   165: astore #5
    //   167: aload #5
    //   169: invokespecial <init> : ()V
    //   172: aload_3
    //   173: aload #5
    //   175: putfield f : Ljava/util/List;
    //   178: aload_1
    //   179: aconst_null
    //   180: invokeinterface d : (Ljava/lang/Object;)V
    //   185: aload #4
    //   187: areturn
    //   188: astore_3
    //   189: aload_1
    //   190: aconst_null
    //   191: invokeinterface d : (Ljava/lang/Object;)V
    //   196: aload_3
    //   197: athrow
    // Exception table:
    //   from	to	target	type
    //   156	178	188	finally
  }
  
  public final boolean q(dbxyzptlk.Ij.k paramk) {
    boolean bool;
    if (paramk.k() == dbxyzptlk.Ij.e.MEASURE && paramk.n() == null) {
      (new Qh()).l(Rh.MISSING_START).m(paramk.c()).k(1.0D).g(this.b);
      bool = false;
    } else {
      bool = true;
    } 
    return bool;
  }
  
  public final void s(Throwable paramThrowable, int paramInt) {
    (new Qh()).k(paramInt).m(paramThrowable.getClass().getSimpleName()).g(this.b);
  }
  
  public final Object t(dbxyzptlk.tI.d<? super D> paramd) {
    // Byte code:
    //   0: aload_1
    //   1: instanceof com/dropbox/common/udcl/impl/internal/udcl_repository/RealUdclDbWriter$i
    //   4: ifeq -> 37
    //   7: aload_1
    //   8: checkcast com/dropbox/common/udcl/impl/internal/udcl_repository/RealUdclDbWriter$i
    //   11: astore_3
    //   12: aload_3
    //   13: getfield x : I
    //   16: istore_2
    //   17: iload_2
    //   18: ldc -2147483648
    //   20: iand
    //   21: ifeq -> 37
    //   24: aload_3
    //   25: iload_2
    //   26: ldc -2147483648
    //   28: iadd
    //   29: putfield x : I
    //   32: aload_3
    //   33: astore_1
    //   34: goto -> 47
    //   37: new com/dropbox/common/udcl/impl/internal/udcl_repository/RealUdclDbWriter$i
    //   40: dup
    //   41: aload_0
    //   42: aload_1
    //   43: invokespecial <init> : (Lcom/dropbox/common/udcl/impl/internal/udcl_repository/RealUdclDbWriter;Ldbxyzptlk/tI/d;)V
    //   46: astore_1
    //   47: aload_1
    //   48: getfield v : Ljava/lang/Object;
    //   51: astore #5
    //   53: invokestatic g : ()Ljava/lang/Object;
    //   56: astore_3
    //   57: aload_1
    //   58: getfield x : I
    //   61: istore_2
    //   62: iload_2
    //   63: ifeq -> 109
    //   66: iload_2
    //   67: iconst_1
    //   68: if_icmpne -> 99
    //   71: aload_1
    //   72: getfield u : Ljava/lang/Object;
    //   75: checkcast dbxyzptlk/mK/a
    //   78: astore #4
    //   80: aload_1
    //   81: getfield t : Ljava/lang/Object;
    //   84: checkcast com/dropbox/common/udcl/impl/internal/udcl_repository/RealUdclDbWriter
    //   87: astore_3
    //   88: aload #5
    //   90: invokestatic b : (Ljava/lang/Object;)V
    //   93: aload #4
    //   95: astore_1
    //   96: goto -> 156
    //   99: new java/lang/IllegalStateException
    //   102: dup
    //   103: ldc 'call to 'resume' before 'invoke' with coroutine'
    //   105: invokespecial <init> : (Ljava/lang/String;)V
    //   108: athrow
    //   109: aload #5
    //   111: invokestatic b : (Ljava/lang/Object;)V
    //   114: aload_0
    //   115: getfield d : Ldbxyzptlk/mK/a;
    //   118: astore #4
    //   120: aload_1
    //   121: aload_0
    //   122: putfield t : Ljava/lang/Object;
    //   125: aload_1
    //   126: aload #4
    //   128: putfield u : Ljava/lang/Object;
    //   131: aload_1
    //   132: iconst_1
    //   133: putfield x : I
    //   136: aload #4
    //   138: aconst_null
    //   139: aload_1
    //   140: invokeinterface a : (Ljava/lang/Object;Ldbxyzptlk/tI/d;)Ljava/lang/Object;
    //   145: aload_3
    //   146: if_acmpne -> 151
    //   149: aload_3
    //   150: areturn
    //   151: aload_0
    //   152: astore_3
    //   153: aload #4
    //   155: astore_1
    //   156: aload_3
    //   157: aconst_null
    //   158: putfield e : Ldbxyzptlk/bK/w0;
    //   161: getstatic dbxyzptlk/pI/D.a : Ldbxyzptlk/pI/D;
    //   164: astore_3
    //   165: aload_1
    //   166: aconst_null
    //   167: invokeinterface d : (Ljava/lang/Object;)V
    //   172: aload_3
    //   173: areturn
    //   174: astore_3
    //   175: aload_1
    //   176: aconst_null
    //   177: invokeinterface d : (Ljava/lang/Object;)V
    //   182: aload_3
    //   183: athrow
    // Exception table:
    //   from	to	target	type
    //   156	165	174	finally
  }
  
  public final Object u(dbxyzptlk.tI.d<? super D> paramd) {
    // Byte code:
    //   0: aload_1
    //   1: instanceof com/dropbox/common/udcl/impl/internal/udcl_repository/RealUdclDbWriter$j
    //   4: ifeq -> 37
    //   7: aload_1
    //   8: checkcast com/dropbox/common/udcl/impl/internal/udcl_repository/RealUdclDbWriter$j
    //   11: astore_3
    //   12: aload_3
    //   13: getfield x : I
    //   16: istore_2
    //   17: iload_2
    //   18: ldc -2147483648
    //   20: iand
    //   21: ifeq -> 37
    //   24: aload_3
    //   25: iload_2
    //   26: ldc -2147483648
    //   28: iadd
    //   29: putfield x : I
    //   32: aload_3
    //   33: astore_1
    //   34: goto -> 47
    //   37: new com/dropbox/common/udcl/impl/internal/udcl_repository/RealUdclDbWriter$j
    //   40: dup
    //   41: aload_0
    //   42: aload_1
    //   43: invokespecial <init> : (Lcom/dropbox/common/udcl/impl/internal/udcl_repository/RealUdclDbWriter;Ldbxyzptlk/tI/d;)V
    //   46: astore_1
    //   47: aload_1
    //   48: getfield v : Ljava/lang/Object;
    //   51: astore #5
    //   53: invokestatic g : ()Ljava/lang/Object;
    //   56: astore_3
    //   57: aload_1
    //   58: getfield x : I
    //   61: istore_2
    //   62: iload_2
    //   63: ifeq -> 109
    //   66: iload_2
    //   67: iconst_1
    //   68: if_icmpne -> 99
    //   71: aload_1
    //   72: getfield u : Ljava/lang/Object;
    //   75: checkcast dbxyzptlk/mK/a
    //   78: astore #4
    //   80: aload_1
    //   81: getfield t : Ljava/lang/Object;
    //   84: checkcast com/dropbox/common/udcl/impl/internal/udcl_repository/RealUdclDbWriter
    //   87: astore_3
    //   88: aload #5
    //   90: invokestatic b : (Ljava/lang/Object;)V
    //   93: aload #4
    //   95: astore_1
    //   96: goto -> 156
    //   99: new java/lang/IllegalStateException
    //   102: dup
    //   103: ldc 'call to 'resume' before 'invoke' with coroutine'
    //   105: invokespecial <init> : (Ljava/lang/String;)V
    //   108: athrow
    //   109: aload #5
    //   111: invokestatic b : (Ljava/lang/Object;)V
    //   114: aload_0
    //   115: getfield d : Ldbxyzptlk/mK/a;
    //   118: astore #4
    //   120: aload_1
    //   121: aload_0
    //   122: putfield t : Ljava/lang/Object;
    //   125: aload_1
    //   126: aload #4
    //   128: putfield u : Ljava/lang/Object;
    //   131: aload_1
    //   132: iconst_1
    //   133: putfield x : I
    //   136: aload #4
    //   138: aconst_null
    //   139: aload_1
    //   140: invokeinterface a : (Ljava/lang/Object;Ldbxyzptlk/tI/d;)Ljava/lang/Object;
    //   145: aload_3
    //   146: if_acmpne -> 151
    //   149: aload_3
    //   150: areturn
    //   151: aload_0
    //   152: astore_3
    //   153: aload #4
    //   155: astore_1
    //   156: aload_3
    //   157: getfield f : Ljava/util/List;
    //   160: checkcast java/util/Collection
    //   163: invokeinterface isEmpty : ()Z
    //   168: ifne -> 250
    //   171: aload_3
    //   172: getfield e : Ldbxyzptlk/bK/w0;
    //   175: ifnonnull -> 250
    //   178: aload_3
    //   179: getfield a : Ldbxyzptlk/bK/J;
    //   182: astore #4
    //   184: aload_3
    //   185: getfield c : Ldbxyzptlk/bK/F;
    //   188: astore #6
    //   190: new com/dropbox/common/udcl/impl/internal/udcl_repository/RealUdclDbWriter$k
    //   193: astore #5
    //   195: aload #5
    //   197: aload_3
    //   198: aconst_null
    //   199: invokespecial <init> : (Lcom/dropbox/common/udcl/impl/internal/udcl_repository/RealUdclDbWriter;Ldbxyzptlk/tI/d;)V
    //   202: aload #4
    //   204: aload #6
    //   206: aconst_null
    //   207: aload #5
    //   209: iconst_2
    //   210: aconst_null
    //   211: invokestatic d : (Ldbxyzptlk/bK/J;Ldbxyzptlk/tI/g;Ldbxyzptlk/bK/L;Ldbxyzptlk/CI/p;ILjava/lang/Object;)Ldbxyzptlk/bK/w0;
    //   214: astore #5
    //   216: new com/dropbox/common/udcl/impl/internal/udcl_repository/RealUdclDbWriter$l
    //   219: astore #4
    //   221: aload #4
    //   223: aload_3
    //   224: invokespecial <init> : (Lcom/dropbox/common/udcl/impl/internal/udcl_repository/RealUdclDbWriter;)V
    //   227: aload #5
    //   229: aload #4
    //   231: invokeinterface y : (Ldbxyzptlk/CI/l;)Ldbxyzptlk/bK/b0;
    //   236: pop
    //   237: aload_3
    //   238: aload #5
    //   240: putfield e : Ldbxyzptlk/bK/w0;
    //   243: goto -> 250
    //   246: astore_3
    //   247: goto -> 263
    //   250: getstatic dbxyzptlk/pI/D.a : Ldbxyzptlk/pI/D;
    //   253: astore_3
    //   254: aload_1
    //   255: aconst_null
    //   256: invokeinterface d : (Ljava/lang/Object;)V
    //   261: aload_3
    //   262: areturn
    //   263: aload_1
    //   264: aconst_null
    //   265: invokeinterface d : (Ljava/lang/Object;)V
    //   270: aload_3
    //   271: athrow
    // Exception table:
    //   from	to	target	type
    //   156	243	246	finally
    //   250	254	246	finally
  }
  
  public final dbxyzptlk.Uj.d v(dbxyzptlk.Ij.k paramk) {
    dbxyzptlk.Uj.d d;
    boolean bool = q(paramk);
    String str = null;
    Map map = null;
    if (bool) {
      String str1 = paramk.h();
      String str2 = paramk.l();
      str = paramk.n();
      if (str == null)
        str = null; 
      String str4 = paramk.c();
      String str3 = paramk.l();
      Long long_1 = paramk.o();
      if (long_1 != null) {
        Double double_ = Double.valueOf(long_1.longValue());
      } else {
        long_1 = null;
      } 
      Long long_2 = paramk.g();
      if (long_2 != null) {
        Double double_ = Double.valueOf(long_2.longValue());
      } else {
        long_2 = null;
      } 
      dbxyzptlk.Ij.d d1 = paramk.j();
      dbxyzptlk.Ij.e e1 = paramk.k();
      Map map1 = paramk.p();
      if (map1 != null)
        map = dbxyzptlk.Tj.f.a(map1); 
      d = new dbxyzptlk.Uj.d(0L, str4, e1, str2, str1, str, str3, (Double)long_1, (Double)long_2, d1, map, paramk.e(), paramk.m(), 1, null);
    } 
    return d;
  }
  
  @dbxyzptlk.vI.f(c = "com.dropbox.common.udcl.impl.internal.udcl_repository.RealUdclDbWriter$1", f = "UdclDbWriter.kt", l = {}, m = "invokeSuspend")
  @Metadata(d1 = {"\000\f\n\002\030\002\n\002\030\002\n\002\b\002\020\002\032\0020\001*\0020\000H@¢\006\004\b\002\020\003"}, d2 = {"Ldbxyzptlk/bK/J;", "Ldbxyzptlk/pI/D;", "<anonymous>", "(Ldbxyzptlk/bK/J;)V"}, k = 3, mv = {1, 9, 0})
  public static final class a extends dbxyzptlk.vI.l implements p<J, dbxyzptlk.tI.d<? super D>, Object> {
    public int t;
    
    public final RealUdclDbWriter u;
    
    public a(RealUdclDbWriter param1RealUdclDbWriter, dbxyzptlk.tI.d<? super a> param1d) {
      super(2, param1d);
    }
    
    public final dbxyzptlk.tI.d<D> create(Object param1Object, dbxyzptlk.tI.d<?> param1d) {
      return (dbxyzptlk.tI.d<D>)new a(this.u, (dbxyzptlk.tI.d)param1d);
    }
    
    public final Object invoke(J param1J, dbxyzptlk.tI.d<? super D> param1d) {
      return ((a)create(param1J, param1d)).invokeSuspend(D.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      dbxyzptlk.uI.c.g();
      if (this.t == 0) {
        p.b(param1Object);
        ProcessLifecycleOwner.i.a().getLifecycle().a((dbxyzptlk.U2.h)this.u);
        return D.a;
      } 
      throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }
  }
  
  @dbxyzptlk.vI.f(c = "com.dropbox.common.udcl.impl.internal.udcl_repository.RealUdclDbWriter", f = "UdclDbWriter.kt", l = {156}, m = "addEvent")
  @Metadata(k = 3, mv = {1, 9, 0}, xi = 48)
  public static final class b extends dbxyzptlk.vI.d {
    public Object t;
    
    public Object u;
    
    public Object v;
    
    public Object w;
    
    public final RealUdclDbWriter x;
    
    public int y;
    
    public b(RealUdclDbWriter param1RealUdclDbWriter, dbxyzptlk.tI.d<? super b> param1d) {
      super(param1d);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      this.w = param1Object;
      this.y |= Integer.MIN_VALUE;
      return RealUdclDbWriter.b(this.x, null, (dbxyzptlk.tI.d)this);
    }
  }
  
  @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"Ldbxyzptlk/Uj/a;", "b", "()Ldbxyzptlk/Uj/a;"}, k = 3, mv = {1, 9, 0})
  public static final class c extends u implements dbxyzptlk.CI.a<dbxyzptlk.Uj.a> {
    public final UdclDatabase f;
    
    public c(UdclDatabase param1UdclDatabase) {
      super(0);
    }
    
    public final dbxyzptlk.Uj.a b() {
      return this.f.J();
    }
  }
  
  @dbxyzptlk.vI.f(c = "com.dropbox.common.udcl.impl.internal.udcl_repository.RealUdclDbWriter", f = "UdclDbWriter.kt", l = {85, 86}, m = "flushToDisk")
  @Metadata(k = 3, mv = {1, 9, 0}, xi = 48)
  public static final class d extends dbxyzptlk.vI.d {
    public Object t;
    
    public Object u;
    
    public final RealUdclDbWriter v;
    
    public int w;
    
    public d(RealUdclDbWriter param1RealUdclDbWriter, dbxyzptlk.tI.d<? super d> param1d) {
      super(param1d);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      this.u = param1Object;
      this.w |= Integer.MIN_VALUE;
      return RealUdclDbWriter.c(this.v, (dbxyzptlk.tI.d)this);
    }
  }
  
  @dbxyzptlk.vI.f(c = "com.dropbox.common.udcl.impl.internal.udcl_repository.RealUdclDbWriter$flushToDisk$2", f = "UdclDbWriter.kt", l = {}, m = "invokeSuspend")
  @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H@¢\006\004\b\001\020\002"}, d2 = {"Ldbxyzptlk/pI/D;", "<anonymous>", "()V"}, k = 3, mv = {1, 9, 0})
  public static final class e extends dbxyzptlk.vI.l implements dbxyzptlk.CI.l<dbxyzptlk.tI.d<? super D>, Object> {
    public int t;
    
    public final RealUdclDbWriter u;
    
    public final List<dbxyzptlk.Uj.d> v;
    
    public e(RealUdclDbWriter param1RealUdclDbWriter, List<dbxyzptlk.Uj.d> param1List, dbxyzptlk.tI.d<? super e> param1d) {
      super(1, param1d);
    }
    
    public final Object a(dbxyzptlk.tI.d<? super D> param1d) {
      return ((e)create(param1d)).invokeSuspend(D.a);
    }
    
    public final dbxyzptlk.tI.d<D> create(dbxyzptlk.tI.d<?> param1d) {
      return (dbxyzptlk.tI.d<D>)new e(this.u, this.v, (dbxyzptlk.tI.d)param1d);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      dbxyzptlk.uI.c.g();
      if (this.t == 0) {
        p.b(param1Object);
        try {
          return D.a;
        } finally {
          RealUdclDbWriter.h(this.u, (Throwable)param1Object, this.v.size());
        } 
      } 
      throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }
  }
  
  @dbxyzptlk.vI.f(c = "com.dropbox.common.udcl.impl.internal.udcl_repository.RealUdclDbWriter", f = "UdclDbWriter.kt", l = {156}, m = "getEventsAndReset")
  @Metadata(k = 3, mv = {1, 9, 0}, xi = 48)
  public static final class f extends dbxyzptlk.vI.d {
    public Object t;
    
    public Object u;
    
    public Object v;
    
    public final RealUdclDbWriter w;
    
    public int x;
    
    public f(RealUdclDbWriter param1RealUdclDbWriter, dbxyzptlk.tI.d<? super f> param1d) {
      super(param1d);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      this.v = param1Object;
      this.x |= Integer.MIN_VALUE;
      return RealUdclDbWriter.g(this.w, (dbxyzptlk.tI.d)this);
    }
  }
  
  @dbxyzptlk.vI.f(c = "com.dropbox.common.udcl.impl.internal.udcl_repository.RealUdclDbWriter", f = "UdclDbWriter.kt", l = {58, 59}, m = "persistMeasure")
  @Metadata(k = 3, mv = {1, 9, 0}, xi = 48)
  public static final class h extends dbxyzptlk.vI.d {
    public Object t;
    
    public Object u;
    
    public final RealUdclDbWriter v;
    
    public int w;
    
    public h(RealUdclDbWriter param1RealUdclDbWriter, dbxyzptlk.tI.d<? super h> param1d) {
      super(param1d);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      this.u = param1Object;
      this.w |= Integer.MIN_VALUE;
      return this.v.a(null, (dbxyzptlk.tI.d<? super D>)this);
    }
  }
  
  @dbxyzptlk.vI.f(c = "com.dropbox.common.udcl.impl.internal.udcl_repository.RealUdclDbWriter", f = "UdclDbWriter.kt", l = {156}, m = "resetJob")
  @Metadata(k = 3, mv = {1, 9, 0}, xi = 48)
  public static final class i extends dbxyzptlk.vI.d {
    public Object t;
    
    public Object u;
    
    public Object v;
    
    public final RealUdclDbWriter w;
    
    public int x;
    
    public i(RealUdclDbWriter param1RealUdclDbWriter, dbxyzptlk.tI.d<? super i> param1d) {
      super(param1d);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      this.v = param1Object;
      this.x |= Integer.MIN_VALUE;
      return RealUdclDbWriter.i(this.w, (dbxyzptlk.tI.d)this);
    }
  }
  
  @dbxyzptlk.vI.f(c = "com.dropbox.common.udcl.impl.internal.udcl_repository.RealUdclDbWriter", f = "UdclDbWriter.kt", l = {156}, m = "scheduleBumpIfNeeded")
  @Metadata(k = 3, mv = {1, 9, 0}, xi = 48)
  public static final class j extends dbxyzptlk.vI.d {
    public Object t;
    
    public Object u;
    
    public Object v;
    
    public final RealUdclDbWriter w;
    
    public int x;
    
    public j(RealUdclDbWriter param1RealUdclDbWriter, dbxyzptlk.tI.d<? super j> param1d) {
      super(param1d);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      this.v = param1Object;
      this.x |= Integer.MIN_VALUE;
      return RealUdclDbWriter.j(this.w, (dbxyzptlk.tI.d)this);
    }
  }
  
  @dbxyzptlk.vI.f(c = "com.dropbox.common.udcl.impl.internal.udcl_repository.RealUdclDbWriter$scheduleBumpIfNeeded$2$1", f = "UdclDbWriter.kt", l = {70, 71}, m = "invokeSuspend")
  @Metadata(d1 = {"\000\f\n\002\030\002\n\002\030\002\n\002\b\002\020\002\032\0020\001*\0020\000H@¢\006\004\b\002\020\003"}, d2 = {"Ldbxyzptlk/bK/J;", "Ldbxyzptlk/pI/D;", "<anonymous>", "(Ldbxyzptlk/bK/J;)V"}, k = 3, mv = {1, 9, 0})
  public static final class k extends dbxyzptlk.vI.l implements p<J, dbxyzptlk.tI.d<? super D>, Object> {
    public int t;
    
    public final RealUdclDbWriter u;
    
    public k(RealUdclDbWriter param1RealUdclDbWriter, dbxyzptlk.tI.d<? super k> param1d) {
      super(2, param1d);
    }
    
    public final dbxyzptlk.tI.d<D> create(Object param1Object, dbxyzptlk.tI.d<?> param1d) {
      return (dbxyzptlk.tI.d<D>)new k(this.u, (dbxyzptlk.tI.d)param1d);
    }
    
    public final Object invoke(J param1J, dbxyzptlk.tI.d<? super D> param1d) {
      return ((k)create(param1J, param1d)).invokeSuspend(D.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = dbxyzptlk.uI.c.g();
      int i = this.t;
      if (i != 0) {
        if (i != 1) {
          if (i == 2) {
            p.b(param1Object);
          } else {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
          } 
        } else {
          p.b(param1Object);
          param1Object = this.u;
          this.t = 2;
        } 
      } else {
        p.b(param1Object);
        this.t = 1;
        if (T.a(1000L, (dbxyzptlk.tI.d)this) == object)
          return object; 
        param1Object = this.u;
        this.t = 2;
      } 
      return D.a;
    }
  }
  
  @Metadata(d1 = {"\000\016\n\002\020\003\n\000\n\002\030\002\n\002\b\002\020\003\032\0020\0022\b\020\001\032\004\030\0010\000H\n¢\006\004\b\003\020\004"}, d2 = {"", "exception", "Ldbxyzptlk/pI/D;", "a", "(Ljava/lang/Throwable;)V"}, k = 3, mv = {1, 9, 0})
  public static final class l extends u implements dbxyzptlk.CI.l<Throwable, D> {
    public final RealUdclDbWriter f;
    
    public l(RealUdclDbWriter param1RealUdclDbWriter) {
      super(1);
    }
    
    public final void a(Throwable param1Throwable) {
      dbxyzptlk.bK.h.d(RealUdclDbWriter.d(this.f), null, null, new a(this.f, param1Throwable, null), 3, null);
    }
    
    @dbxyzptlk.vI.f(c = "com.dropbox.common.udcl.impl.internal.udcl_repository.RealUdclDbWriter$scheduleBumpIfNeeded$2$2$1$1", f = "UdclDbWriter.kt", l = {75, 76}, m = "invokeSuspend")
    @Metadata(d1 = {"\000\f\n\002\030\002\n\002\030\002\n\002\b\002\020\002\032\0020\001*\0020\000H@¢\006\004\b\002\020\003"}, d2 = {"Ldbxyzptlk/bK/J;", "Ldbxyzptlk/pI/D;", "<anonymous>", "(Ldbxyzptlk/bK/J;)V"}, k = 3, mv = {1, 9, 0})
    public static final class a extends dbxyzptlk.vI.l implements p<J, dbxyzptlk.tI.d<? super D>, Object> {
      public int t;
      
      public final RealUdclDbWriter u;
      
      public final Throwable v;
      
      public a(RealUdclDbWriter param2RealUdclDbWriter, Throwable param2Throwable, dbxyzptlk.tI.d<? super a> param2d) {
        super(2, param2d);
      }
      
      public final dbxyzptlk.tI.d<D> create(Object param2Object, dbxyzptlk.tI.d<?> param2d) {
        return (dbxyzptlk.tI.d<D>)new a(this.u, this.v, (dbxyzptlk.tI.d)param2d);
      }
      
      public final Object invoke(J param2J, dbxyzptlk.tI.d<? super D> param2d) {
        return ((a)create(param2J, param2d)).invokeSuspend(D.a);
      }
      
      public final Object invokeSuspend(Object param2Object) {
        // Byte code:
        //   0: invokestatic g : ()Ljava/lang/Object;
        //   3: astore_3
        //   4: aload_0
        //   5: getfield t : I
        //   8: istore_2
        //   9: iload_2
        //   10: ifeq -> 47
        //   13: iload_2
        //   14: iconst_1
        //   15: if_icmpeq -> 40
        //   18: iload_2
        //   19: iconst_2
        //   20: if_icmpne -> 30
        //   23: aload_1
        //   24: invokestatic b : (Ljava/lang/Object;)V
        //   27: goto -> 100
        //   30: new java/lang/IllegalStateException
        //   33: dup
        //   34: ldc 'call to 'resume' before 'invoke' with coroutine'
        //   36: invokespecial <init> : (Ljava/lang/String;)V
        //   39: athrow
        //   40: aload_1
        //   41: invokestatic b : (Ljava/lang/Object;)V
        //   44: goto -> 72
        //   47: aload_1
        //   48: invokestatic b : (Ljava/lang/Object;)V
        //   51: aload_0
        //   52: getfield u : Lcom/dropbox/common/udcl/impl/internal/udcl_repository/RealUdclDbWriter;
        //   55: astore_1
        //   56: aload_0
        //   57: iconst_1
        //   58: putfield t : I
        //   61: aload_1
        //   62: aload_0
        //   63: invokestatic i : (Lcom/dropbox/common/udcl/impl/internal/udcl_repository/RealUdclDbWriter;Ldbxyzptlk/tI/d;)Ljava/lang/Object;
        //   66: aload_3
        //   67: if_acmpne -> 72
        //   70: aload_3
        //   71: areturn
        //   72: aload_0
        //   73: getfield v : Ljava/lang/Throwable;
        //   76: ifnonnull -> 100
        //   79: aload_0
        //   80: getfield u : Lcom/dropbox/common/udcl/impl/internal/udcl_repository/RealUdclDbWriter;
        //   83: astore_1
        //   84: aload_0
        //   85: iconst_2
        //   86: putfield t : I
        //   89: aload_1
        //   90: aload_0
        //   91: invokestatic j : (Lcom/dropbox/common/udcl/impl/internal/udcl_repository/RealUdclDbWriter;Ldbxyzptlk/tI/d;)Ljava/lang/Object;
        //   94: aload_3
        //   95: if_acmpne -> 100
        //   98: aload_3
        //   99: areturn
        //   100: getstatic dbxyzptlk/pI/D.a : Ldbxyzptlk/pI/D;
        //   103: areturn
      }
    }
  }
  
  @dbxyzptlk.vI.f(c = "com.dropbox.common.udcl.impl.internal.udcl_repository.RealUdclDbWriter$scheduleBumpIfNeeded$2$2$1$1", f = "UdclDbWriter.kt", l = {75, 76}, m = "invokeSuspend")
  @Metadata(d1 = {"\000\f\n\002\030\002\n\002\030\002\n\002\b\002\020\002\032\0020\001*\0020\000H@¢\006\004\b\002\020\003"}, d2 = {"Ldbxyzptlk/bK/J;", "Ldbxyzptlk/pI/D;", "<anonymous>", "(Ldbxyzptlk/bK/J;)V"}, k = 3, mv = {1, 9, 0})
  public static final class a extends dbxyzptlk.vI.l implements p<J, dbxyzptlk.tI.d<? super D>, Object> {
    public int t;
    
    public final RealUdclDbWriter u;
    
    public final Throwable v;
    
    public a(RealUdclDbWriter param1RealUdclDbWriter, Throwable param1Throwable, dbxyzptlk.tI.d<? super a> param1d) {
      super(2, param1d);
    }
    
    public final dbxyzptlk.tI.d<D> create(Object param1Object, dbxyzptlk.tI.d<?> param1d) {
      return (dbxyzptlk.tI.d<D>)new a(this.u, this.v, (dbxyzptlk.tI.d)param1d);
    }
    
    public final Object invoke(J param1J, dbxyzptlk.tI.d<? super D> param1d) {
      return ((a)create(param1J, param1d)).invokeSuspend(D.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      // Byte code:
      //   0: invokestatic g : ()Ljava/lang/Object;
      //   3: astore_3
      //   4: aload_0
      //   5: getfield t : I
      //   8: istore_2
      //   9: iload_2
      //   10: ifeq -> 47
      //   13: iload_2
      //   14: iconst_1
      //   15: if_icmpeq -> 40
      //   18: iload_2
      //   19: iconst_2
      //   20: if_icmpne -> 30
      //   23: aload_1
      //   24: invokestatic b : (Ljava/lang/Object;)V
      //   27: goto -> 100
      //   30: new java/lang/IllegalStateException
      //   33: dup
      //   34: ldc 'call to 'resume' before 'invoke' with coroutine'
      //   36: invokespecial <init> : (Ljava/lang/String;)V
      //   39: athrow
      //   40: aload_1
      //   41: invokestatic b : (Ljava/lang/Object;)V
      //   44: goto -> 72
      //   47: aload_1
      //   48: invokestatic b : (Ljava/lang/Object;)V
      //   51: aload_0
      //   52: getfield u : Lcom/dropbox/common/udcl/impl/internal/udcl_repository/RealUdclDbWriter;
      //   55: astore_1
      //   56: aload_0
      //   57: iconst_1
      //   58: putfield t : I
      //   61: aload_1
      //   62: aload_0
      //   63: invokestatic i : (Lcom/dropbox/common/udcl/impl/internal/udcl_repository/RealUdclDbWriter;Ldbxyzptlk/tI/d;)Ljava/lang/Object;
      //   66: aload_3
      //   67: if_acmpne -> 72
      //   70: aload_3
      //   71: areturn
      //   72: aload_0
      //   73: getfield v : Ljava/lang/Throwable;
      //   76: ifnonnull -> 100
      //   79: aload_0
      //   80: getfield u : Lcom/dropbox/common/udcl/impl/internal/udcl_repository/RealUdclDbWriter;
      //   83: astore_1
      //   84: aload_0
      //   85: iconst_2
      //   86: putfield t : I
      //   89: aload_1
      //   90: aload_0
      //   91: invokestatic j : (Lcom/dropbox/common/udcl/impl/internal/udcl_repository/RealUdclDbWriter;Ldbxyzptlk/tI/d;)Ljava/lang/Object;
      //   94: aload_3
      //   95: if_acmpne -> 100
      //   98: aload_3
      //   99: areturn
      //   100: getstatic dbxyzptlk/pI/D.a : Ldbxyzptlk/pI/D;
      //   103: areturn
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\commo\\udcl\impl\interna\\udcl_repository\RealUdclDbWriter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */