package com.dropbox.common.udcl.impl.internal.udcl_repository.db;

import androidx.room.d;
import dbxyzptlk.F4.g;
import dbxyzptlk.F4.s;
import dbxyzptlk.F4.u;
import dbxyzptlk.G4.b;
import dbxyzptlk.I4.b;
import dbxyzptlk.I4.f;
import dbxyzptlk.L4.g;
import dbxyzptlk.L4.h;
import dbxyzptlk.Uj.b;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public final class UdclDatabase_Impl extends UdclDatabase {
  public volatile dbxyzptlk.Uj.a q;
  
  public dbxyzptlk.Uj.a J() {
    if (this.q != null)
      return this.q; 
    /* monitor enter ThisExpression{ObjectType{com/dropbox/common/udcl/impl/internal/udcl_repository/db/UdclDatabase_Impl}} */
    try {
      if (this.q == null) {
        b b = new b();
        this(this);
        this.q = (dbxyzptlk.Uj.a)b;
      } 
    } finally {
      Exception exception;
    } 
    dbxyzptlk.Uj.a a1 = this.q;
    /* monitor exit ThisExpression{ObjectType{com/dropbox/common/udcl/impl/internal/udcl_repository/db/UdclDatabase_Impl}} */
    return a1;
  }
  
  public d h() {
    return new d(this, new HashMap<>(0), new HashMap<>(0), new String[] { "udcl_events" });
  }
  
  public h i(g paramg) {
    u u = new u(paramg, new a(this, 1), "0c0d8e3d4c670d36c02a2a56b8c49f35", "f55ac6017812b7cf8cd359f0ad5e49d3");
    h.b b = h.b.a(paramg.a).d(paramg.b).c((h.a)u).b();
    return paramg.c.a(b);
  }
  
  public List<b> k(Map<Class<? extends dbxyzptlk.G4.a>, dbxyzptlk.G4.a> paramMap) {
    return new ArrayList<>();
  }
  
  public Set<Class<? extends dbxyzptlk.G4.a>> q() {
    return new HashSet<>();
  }
  
  public Map<Class<?>, List<Class<?>>> r() {
    HashMap<Object, Object> hashMap = new HashMap<>();
    hashMap.put(dbxyzptlk.Uj.a.class, b.h());
    return (Map)hashMap;
  }
  
  public class a extends u.b {
    public final UdclDatabase_Impl b;
    
    public a(UdclDatabase_Impl this$0, int param1Int) {
      super(param1Int);
    }
    
    public void a(g param1g) {
      param1g.B1("CREATE TABLE IF NOT EXISTS `udcl_events` (`row_id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `name` TEXT NOT NULL, `event_type` TEXT NOT NULL, `local_id` TEXT, `event_id` TEXT, `measure_id` TEXT, `key` TEXT, `start_time_ms` REAL, `end_time_ms` REAL, `event_state` TEXT, `tags` TEXT, `count` INTEGER, `log_type` TEXT)");
      param1g.B1("CREATE TABLE IF NOT EXISTS room_master_table (id INTEGER PRIMARY KEY,identity_hash TEXT)");
      param1g.B1("INSERT OR REPLACE INTO room_master_table (id,identity_hash) VALUES(42, '0c0d8e3d4c670d36c02a2a56b8c49f35')");
    }
    
    public void b(g param1g) {
      param1g.B1("DROP TABLE IF EXISTS `udcl_events`");
      List list = UdclDatabase_Impl.K(this.b);
      if (list != null) {
        Iterator<s.b> iterator = list.iterator();
        while (iterator.hasNext())
          ((s.b)iterator.next()).b(param1g); 
      } 
    }
    
    public void c(g param1g) {
      List list = UdclDatabase_Impl.L(this.b);
      if (list != null) {
        Iterator<s.b> iterator = list.iterator();
        while (iterator.hasNext())
          ((s.b)iterator.next()).a(param1g); 
      } 
    }
    
    public void d(g param1g) {
      UdclDatabase_Impl.M(this.b, param1g);
      UdclDatabase_Impl.N(this.b, param1g);
      List list = UdclDatabase_Impl.O(this.b);
      if (list != null) {
        Iterator<s.b> iterator = list.iterator();
        while (iterator.hasNext())
          ((s.b)iterator.next()).c(param1g); 
      } 
    }
    
    public void e(g param1g) {}
    
    public void f(g param1g) {
      b.b(param1g);
    }
    
    public u.c g(g param1g) {
      HashMap<Object, Object> hashMap = new HashMap<>(13);
      hashMap.put("row_id", new f.a("row_id", "INTEGER", true, 1, null, 1));
      hashMap.put("name", new f.a("name", "TEXT", true, 0, null, 1));
      hashMap.put("event_type", new f.a("event_type", "TEXT", true, 0, null, 1));
      hashMap.put("local_id", new f.a("local_id", "TEXT", false, 0, null, 1));
      hashMap.put("event_id", new f.a("event_id", "TEXT", false, 0, null, 1));
      hashMap.put("measure_id", new f.a("measure_id", "TEXT", false, 0, null, 1));
      hashMap.put("key", new f.a("key", "TEXT", false, 0, null, 1));
      hashMap.put("start_time_ms", new f.a("start_time_ms", "REAL", false, 0, null, 1));
      hashMap.put("end_time_ms", new f.a("end_time_ms", "REAL", false, 0, null, 1));
      hashMap.put("event_state", new f.a("event_state", "TEXT", false, 0, null, 1));
      hashMap.put("tags", new f.a("tags", "TEXT", false, 0, null, 1));
      hashMap.put("count", new f.a("count", "INTEGER", false, 0, null, 1));
      hashMap.put("log_type", new f.a("log_type", "TEXT", false, 0, null, 1));
      f f2 = new f("udcl_events", hashMap, new HashSet(0), new HashSet(0));
      f f1 = f.a(param1g, "udcl_events");
      if (!f2.equals(f1)) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("udcl_events(com.dropbox.common.udcl.impl.internal.udcl_repository.db.UdclMeasureEntity).\n Expected:\n");
        stringBuilder.append(f2);
        stringBuilder.append("\n Found:\n");
        stringBuilder.append(f1);
        return new u.c(false, stringBuilder.toString());
      } 
      return new u.c(true, null);
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\commo\\udcl\impl\interna\\udcl_repository\db\UdclDatabase_Impl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */