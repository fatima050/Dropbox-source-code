package com.dropbox.common.udcl.impl.internal.udcl_repository;

import androidx.lifecycle.DefaultLifecycleObserver;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.ProcessLifecycleOwner;
import com.dropbox.common.udcl.impl.internal.udcl_repository.db.UdclDatabase;
import com.squareup.anvil.annotations.ContributesMultibinding;
import dbxyzptlk.Aj.b;
import dbxyzptlk.CI.l;
import dbxyzptlk.CI.p;
import dbxyzptlk.CI.q;
import dbxyzptlk.CI.r;
import dbxyzptlk.DI.J;
import dbxyzptlk.DI.s;
import dbxyzptlk.DI.u;
import dbxyzptlk.Fc.Oh;
import dbxyzptlk.Fc.Ph;
import dbxyzptlk.Fc.Qh;
import dbxyzptlk.Ij.i;
import dbxyzptlk.Jh.d;
import dbxyzptlk.Tj.i;
import dbxyzptlk.Vj.n;
import dbxyzptlk.Vj.t;
import dbxyzptlk.bK.J;
import dbxyzptlk.bK.T;
import dbxyzptlk.bK.w0;
import dbxyzptlk.ch.m;
import dbxyzptlk.eK.i;
import dbxyzptlk.eK.k;
import dbxyzptlk.pI.D;
import dbxyzptlk.pI.k;
import dbxyzptlk.pI.n;
import dbxyzptlk.pI.p;
import dbxyzptlk.pI.t;
import dbxyzptlk.vI.l;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

@ContributesMultibinding(boundType = b.class, scope = d.class)
@Metadata(d1 = {"\000²\001\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\003\n\002\020\013\n\002\b\003\n\002\030\002\n\002\b\003\n\002\020 \n\002\030\002\n\002\030\002\n\002\020!\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020$\n\002\020\016\n\002\b\006\n\002\020\003\n\002\020\b\n\002\b\003\n\002\030\002\n\002\b\017\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\b\n\002\020\t\n\002\b\003\b\007\030\000 #2\0020\0012\0020\002:\001=BK\b\007\022\b\b\001\020\004\032\0020\003\022\006\020\006\032\0020\005\022\006\020\b\032\0020\007\022\006\020\n\032\0020\t\022\006\020\f\032\0020\013\022\006\020\016\032\0020\r\022\006\020\020\032\0020\017\022\006\020\022\032\0020\021¢\006\004\b\023\020\024J\017\020\026\032\0020\025H\026¢\006\004\b\026\020\027J\027\020\032\032\0020\0252\006\020\031\032\0020\030H\026¢\006\004\b\032\020\033J\030\020\036\032\0020\0252\006\020\035\032\0020\034H@¢\006\004\b\036\020\037J\017\020!\032\0020 H\002¢\006\004\b!\020\"J\017\020#\032\0020\025H\002¢\006\004\b#\020\027J1\020*\032\032\022\n\022\b\022\004\022\0020(0'\022\n\022\b\022\004\022\0020)0'0&*\b\022\004\022\0020%0$H\002¢\006\004\b*\020+J\037\020.\032\016\022\004\022\0020-\022\004\022\0020-0,*\0020%H\002¢\006\004\b.\020/J\023\0200\032\0020-*\0020%H\002¢\006\004\b0\0201J,\0202\032\0020\034*\032\022\n\022\b\022\004\022\0020(0'\022\n\022\b\022\004\022\0020)0'0&H@¢\006\004\b2\0203J\033\0207\032\0020\025*\002042\006\0206\032\00205H\002¢\006\004\b7\0208J\033\020;\032\00209*\002092\006\020:\032\00205H\002¢\006\004\b;\020<R\024\020\004\032\0020\0038\002X\004¢\006\006\n\004\b=\020>R\024\020\006\032\0020\0058\002X\004¢\006\006\n\004\b?\020@R\024\020\b\032\0020\0078\002X\004¢\006\006\n\004\bA\020BR\024\020\n\032\0020\t8\002X\004¢\006\006\n\004\bC\020DR\024\020\f\032\0020\0138\002X\004¢\006\006\n\004\bE\020FR\024\020\016\032\0020\r8\002X\004¢\006\006\n\004\bG\020HR\024\020L\032\0020I8\002X\004¢\006\006\n\004\bJ\020KR\033\020R\032\0020M8BX\002¢\006\f\n\004\bN\020O\032\004\bP\020QR\026\020U\032\0020\0348\002@\002X\016¢\006\006\n\004\bS\020TR\024\020X\032\0020V8\002X\004¢\006\006\n\004\b\036\020W¨\006Y"}, d2 = {"Lcom/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader;", "Ldbxyzptlk/Aj/b;", "Landroidx/lifecycle/DefaultLifecycleObserver;", "Ldbxyzptlk/bK/J;", "coroutineScope", "Ldbxyzptlk/ch/m;", "dispatchers", "Ldbxyzptlk/Tj/i;", "udclService", "Ldbxyzptlk/Ec/g;", "logger", "Ldbxyzptlk/Vj/n;", "udclGate", "Ldbxyzptlk/Vj/t;", "udclRetryGate", "Ldbxyzptlk/rk/b;", "buildInfo", "Lcom/dropbox/common/udcl/impl/internal/udcl_repository/db/UdclDatabase;", "udclDatabase", "<init>", "(Ldbxyzptlk/bK/J;Ldbxyzptlk/ch/m;Ldbxyzptlk/Tj/i;Ldbxyzptlk/Ec/g;Ldbxyzptlk/Vj/n;Ldbxyzptlk/Vj/t;Ldbxyzptlk/rk/b;Lcom/dropbox/common/udcl/impl/internal/udcl_repository/db/UdclDatabase;)V", "Ldbxyzptlk/pI/D;", "run", "()V", "Landroidx/lifecycle/LifecycleOwner;", "owner", "onStop", "(Landroidx/lifecycle/LifecycleOwner;)V", "", "wait", "j", "(ZLdbxyzptlk/tI/d;)Ljava/lang/Object;", "Ldbxyzptlk/bK/w0;", "o", "()Ldbxyzptlk/bK/w0;", "k", "", "Ldbxyzptlk/Uj/d;", "Ldbxyzptlk/pI/n;", "", "Ldbxyzptlk/vm/g;", "Ldbxyzptlk/vm/h;", "t", "(Ljava/util/List;)Ldbxyzptlk/pI/n;", "", "", "v", "(Ldbxyzptlk/Uj/d;)Ljava/util/Map;", "u", "(Ldbxyzptlk/Uj/d;)Ljava/lang/String;", "s", "(Ldbxyzptlk/pI/n;Ldbxyzptlk/tI/d;)Ljava/lang/Object;", "", "", "size", "p", "(Ljava/lang/Throwable;I)V", "Ldbxyzptlk/vm/f;", "sent", "q", "(Ldbxyzptlk/vm/f;I)Ldbxyzptlk/vm/f;", "a", "Ldbxyzptlk/bK/J;", "b", "Ldbxyzptlk/ch/m;", "c", "Ldbxyzptlk/Tj/i;", "d", "Ldbxyzptlk/Ec/g;", "e", "Ldbxyzptlk/Vj/n;", "f", "Ldbxyzptlk/Vj/t;", "Ldbxyzptlk/mK/a;", "g", "Ldbxyzptlk/mK/a;", "lock", "Ldbxyzptlk/Uj/a;", "h", "Ldbxyzptlk/pI/j;", "m", "()Ldbxyzptlk/Uj/a;", "db", "i", "Z", "rowLimitEnforced", "", "J", "DRAIN_DELAY", "common_analytics_udcl_impl_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class UdclDbReader implements b, DefaultLifecycleObserver {
  public static final a k = new a(null);
  
  public final J a;
  
  public final m b;
  
  public final i c;
  
  public final dbxyzptlk.Ec.g d;
  
  public final n e;
  
  public final t f;
  
  public final dbxyzptlk.mK.a g;
  
  public final dbxyzptlk.pI.j h;
  
  public boolean i;
  
  public final long j;
  
  public UdclDbReader(J paramJ, m paramm, i parami, dbxyzptlk.Ec.g paramg, n paramn, t paramt, dbxyzptlk.rk.b paramb, UdclDatabase paramUdclDatabase) {
    long l;
    this.a = paramJ;
    this.b = paramm;
    this.c = parami;
    this.d = paramg;
    this.e = paramn;
    this.f = paramt;
    this.g = dbxyzptlk.mK.c.b(false, 1, null);
    this.h = k.a(new c(paramUdclDatabase));
    if (paramb.e()) {
      l = 2000L;
    } else {
      l = 30000L;
    } 
    this.j = l;
  }
  
  private final dbxyzptlk.Uj.a m() {
    return (dbxyzptlk.Uj.a)this.h.getValue();
  }
  
  public final Object j(boolean paramBoolean, dbxyzptlk.tI.d<? super D> paramd) {
    // Byte code:
    //   0: aload_2
    //   1: instanceof com/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader$d
    //   4: ifeq -> 38
    //   7: aload_2
    //   8: checkcast com/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader$d
    //   11: astore #4
    //   13: aload #4
    //   15: getfield y : I
    //   18: istore_3
    //   19: iload_3
    //   20: ldc -2147483648
    //   22: iand
    //   23: ifeq -> 38
    //   26: aload #4
    //   28: iload_3
    //   29: ldc -2147483648
    //   31: iadd
    //   32: putfield y : I
    //   35: goto -> 49
    //   38: new com/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader$d
    //   41: dup
    //   42: aload_0
    //   43: aload_2
    //   44: invokespecial <init> : (Lcom/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader;Ldbxyzptlk/tI/d;)V
    //   47: astore #4
    //   49: aload #4
    //   51: getfield w : Ljava/lang/Object;
    //   54: astore #9
    //   56: invokestatic g : ()Ljava/lang/Object;
    //   59: astore #10
    //   61: aload #4
    //   63: getfield y : I
    //   66: istore_3
    //   67: iload_3
    //   68: ifeq -> 176
    //   71: iload_3
    //   72: iconst_1
    //   73: if_icmpeq -> 149
    //   76: iload_3
    //   77: iconst_2
    //   78: if_icmpne -> 139
    //   81: aload #4
    //   83: getfield v : Ljava/lang/Object;
    //   86: checkcast dbxyzptlk/DI/K
    //   89: astore #8
    //   91: aload #4
    //   93: getfield u : Ljava/lang/Object;
    //   96: checkcast dbxyzptlk/mK/a
    //   99: astore #5
    //   101: aload #4
    //   103: getfield t : Ljava/lang/Object;
    //   106: checkcast com/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader
    //   109: astore #7
    //   111: aload #5
    //   113: astore_2
    //   114: aload #9
    //   116: invokestatic b : (Ljava/lang/Object;)V
    //   119: aload #4
    //   121: astore #6
    //   123: aload #5
    //   125: astore #4
    //   127: aload #9
    //   129: astore #5
    //   131: goto -> 396
    //   134: astore #4
    //   136: goto -> 521
    //   139: new java/lang/IllegalStateException
    //   142: dup
    //   143: ldc 'call to 'resume' before 'invoke' with coroutine'
    //   145: invokespecial <init> : (Ljava/lang/String;)V
    //   148: athrow
    //   149: aload #4
    //   151: getfield u : Ljava/lang/Object;
    //   154: checkcast dbxyzptlk/mK/a
    //   157: astore_2
    //   158: aload #4
    //   160: getfield t : Ljava/lang/Object;
    //   163: checkcast com/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader
    //   166: astore #5
    //   168: aload #9
    //   170: invokestatic b : (Ljava/lang/Object;)V
    //   173: goto -> 244
    //   176: aload #9
    //   178: invokestatic b : (Ljava/lang/Object;)V
    //   181: iload_1
    //   182: ifne -> 201
    //   185: aload_0
    //   186: getfield g : Ldbxyzptlk/mK/a;
    //   189: invokeinterface e : ()Z
    //   194: ifeq -> 201
    //   197: getstatic dbxyzptlk/pI/D.a : Ldbxyzptlk/pI/D;
    //   200: areturn
    //   201: aload_0
    //   202: getfield g : Ldbxyzptlk/mK/a;
    //   205: astore_2
    //   206: aload #4
    //   208: aload_0
    //   209: putfield t : Ljava/lang/Object;
    //   212: aload #4
    //   214: aload_2
    //   215: putfield u : Ljava/lang/Object;
    //   218: aload #4
    //   220: iconst_1
    //   221: putfield y : I
    //   224: aload_2
    //   225: aconst_null
    //   226: aload #4
    //   228: invokeinterface a : (Ljava/lang/Object;Ldbxyzptlk/tI/d;)Ljava/lang/Object;
    //   233: aload #10
    //   235: if_acmpne -> 241
    //   238: aload #10
    //   240: areturn
    //   241: aload_0
    //   242: astore #5
    //   244: aload #5
    //   246: invokevirtual k : ()V
    //   249: new dbxyzptlk/DI/K
    //   252: astore #8
    //   254: aload #8
    //   256: invokespecial <init> : ()V
    //   259: aload #8
    //   261: aload #5
    //   263: invokespecial m : ()Ldbxyzptlk/Uj/a;
    //   266: sipush #5000
    //   269: invokeinterface f : (I)Ljava/util/List;
    //   274: putfield a : Ljava/lang/Object;
    //   277: aload #5
    //   279: astore #7
    //   281: aload_2
    //   282: astore #5
    //   284: aload #4
    //   286: astore #6
    //   288: aload #5
    //   290: astore_2
    //   291: aload #8
    //   293: getfield a : Ljava/lang/Object;
    //   296: checkcast java/util/Collection
    //   299: invokeinterface isEmpty : ()Z
    //   304: ifne -> 499
    //   307: aload #5
    //   309: astore_2
    //   310: aload #7
    //   312: aload #8
    //   314: getfield a : Ljava/lang/Object;
    //   317: checkcast java/util/List
    //   320: invokevirtual t : (Ljava/util/List;)Ldbxyzptlk/pI/n;
    //   323: astore #4
    //   325: aload #5
    //   327: astore_2
    //   328: aload #6
    //   330: aload #7
    //   332: putfield t : Ljava/lang/Object;
    //   335: aload #5
    //   337: astore_2
    //   338: aload #6
    //   340: aload #5
    //   342: putfield u : Ljava/lang/Object;
    //   345: aload #5
    //   347: astore_2
    //   348: aload #6
    //   350: aload #8
    //   352: putfield v : Ljava/lang/Object;
    //   355: aload #5
    //   357: astore_2
    //   358: aload #6
    //   360: iconst_2
    //   361: putfield y : I
    //   364: aload #5
    //   366: astore_2
    //   367: aload #7
    //   369: aload #4
    //   371: aload #6
    //   373: invokevirtual s : (Ldbxyzptlk/pI/n;Ldbxyzptlk/tI/d;)Ljava/lang/Object;
    //   376: astore #9
    //   378: aload #5
    //   380: astore #4
    //   382: aload #9
    //   384: astore #5
    //   386: aload #9
    //   388: aload #10
    //   390: if_acmpne -> 396
    //   393: aload #10
    //   395: areturn
    //   396: aload #4
    //   398: astore_2
    //   399: aload #5
    //   401: checkcast java/lang/Boolean
    //   404: invokevirtual booleanValue : ()Z
    //   407: ifeq -> 431
    //   410: aload #4
    //   412: astore_2
    //   413: aload #7
    //   415: invokespecial m : ()Ldbxyzptlk/Uj/a;
    //   418: aload #8
    //   420: getfield a : Ljava/lang/Object;
    //   423: checkcast java/util/List
    //   426: invokeinterface c : (Ljava/util/List;)V
    //   431: aload #4
    //   433: astore_2
    //   434: aload #8
    //   436: getfield a : Ljava/lang/Object;
    //   439: checkcast java/util/List
    //   442: invokeinterface size : ()I
    //   447: sipush #5000
    //   450: if_icmpne -> 474
    //   453: aload #4
    //   455: astore_2
    //   456: aload #7
    //   458: invokespecial m : ()Ldbxyzptlk/Uj/a;
    //   461: sipush #5000
    //   464: invokeinterface f : (I)Ljava/util/List;
    //   469: astore #5
    //   471: goto -> 482
    //   474: aload #4
    //   476: astore_2
    //   477: invokestatic m : ()Ljava/util/List;
    //   480: astore #5
    //   482: aload #4
    //   484: astore_2
    //   485: aload #8
    //   487: aload #5
    //   489: putfield a : Ljava/lang/Object;
    //   492: aload #4
    //   494: astore #5
    //   496: goto -> 288
    //   499: aload #5
    //   501: astore_2
    //   502: getstatic dbxyzptlk/pI/D.a : Ldbxyzptlk/pI/D;
    //   505: astore #4
    //   507: aload #5
    //   509: aconst_null
    //   510: invokeinterface d : (Ljava/lang/Object;)V
    //   515: getstatic dbxyzptlk/pI/D.a : Ldbxyzptlk/pI/D;
    //   518: areturn
    //   519: astore #4
    //   521: aload_2
    //   522: aconst_null
    //   523: invokeinterface d : (Ljava/lang/Object;)V
    //   528: aload #4
    //   530: athrow
    // Exception table:
    //   from	to	target	type
    //   114	119	134	finally
    //   244	277	519	finally
    //   291	307	134	finally
    //   310	325	134	finally
    //   328	335	134	finally
    //   338	345	134	finally
    //   348	355	134	finally
    //   358	364	134	finally
    //   367	378	134	finally
    //   399	410	134	finally
    //   413	431	134	finally
    //   434	453	134	finally
    //   456	471	134	finally
    //   477	482	134	finally
    //   485	492	134	finally
    //   502	507	134	finally
  }
  
  public final void k() {
    if (this.i)
      return; 
    this.i = true;
    int k = m().d(100000);
    if (k > 0)
      (new Qh()).m("ROW_LIMIT_REACHED").k(k).g(this.d); 
  }
  
  public final w0 o() {
    return dbxyzptlk.bK.h.d(this.a, (dbxyzptlk.tI.g)this.b.b(), null, new e(this, null), 2, null);
  }
  
  public void onStop(LifecycleOwner paramLifecycleOwner) {
    s.h(paramLifecycleOwner, "owner");
    dbxyzptlk.bK.h.d(this.a, (dbxyzptlk.tI.g)this.b.b(), null, (p)new i(this, null), 2, null);
  }
  
  public final void p(Throwable paramThrowable, int paramInt) {
    (new Ph()).l(paramThrowable.getClass().getSimpleName()).k(paramInt).g(this.d);
  }
  
  public final dbxyzptlk.vm.f q(dbxyzptlk.vm.f paramf, int paramInt) {
    (new Oh()).l(paramf.a()).k(paramInt).g(this.d);
    return paramf;
  }
  
  public void run() {
    if (!this.e.a())
      return; 
    o();
    dbxyzptlk.bK.h.d(this.a, (dbxyzptlk.tI.g)this.b.a(), null, new j(this, null), 2, null);
  }
  
  public final Object s(n<? extends List<dbxyzptlk.vm.g>, ? extends List<dbxyzptlk.vm.h>> paramn, dbxyzptlk.tI.d<? super Boolean> paramd) {
    // Byte code:
    //   0: aload_2
    //   1: instanceof com/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader$f
    //   4: ifeq -> 41
    //   7: aload_2
    //   8: checkcast com/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader$f
    //   11: astore #5
    //   13: aload #5
    //   15: getfield x : I
    //   18: istore_3
    //   19: iload_3
    //   20: ldc -2147483648
    //   22: iand
    //   23: ifeq -> 41
    //   26: aload #5
    //   28: iload_3
    //   29: ldc -2147483648
    //   31: iadd
    //   32: putfield x : I
    //   35: aload #5
    //   37: astore_2
    //   38: goto -> 51
    //   41: new com/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader$f
    //   44: dup
    //   45: aload_0
    //   46: aload_2
    //   47: invokespecial <init> : (Lcom/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader;Ldbxyzptlk/tI/d;)V
    //   50: astore_2
    //   51: aload_2
    //   52: getfield v : Ljava/lang/Object;
    //   55: astore #6
    //   57: invokestatic g : ()Ljava/lang/Object;
    //   60: astore #7
    //   62: aload_2
    //   63: getfield x : I
    //   66: istore_3
    //   67: aconst_null
    //   68: astore #5
    //   70: iconst_1
    //   71: istore #4
    //   73: iload_3
    //   74: ifeq -> 116
    //   77: iload_3
    //   78: iconst_1
    //   79: if_icmpne -> 106
    //   82: aload_2
    //   83: getfield u : I
    //   86: istore_3
    //   87: aload_2
    //   88: getfield t : Ljava/lang/Object;
    //   91: checkcast com/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader
    //   94: astore_1
    //   95: aload #6
    //   97: invokestatic b : (Ljava/lang/Object;)V
    //   100: aload #6
    //   102: astore_2
    //   103: goto -> 247
    //   106: new java/lang/IllegalStateException
    //   109: dup
    //   110: ldc 'call to 'resume' before 'invoke' with coroutine'
    //   112: invokespecial <init> : (Ljava/lang/String;)V
    //   115: athrow
    //   116: aload #6
    //   118: invokestatic b : (Ljava/lang/Object;)V
    //   121: new dbxyzptlk/DI/J
    //   124: dup
    //   125: invokespecial <init> : ()V
    //   128: astore #6
    //   130: aload #6
    //   132: ldc2_w 1000
    //   135: putfield a : J
    //   138: aload_1
    //   139: invokevirtual c : ()Ljava/lang/Object;
    //   142: checkcast java/util/List
    //   145: invokeinterface size : ()I
    //   150: aload_1
    //   151: invokevirtual d : ()Ljava/lang/Object;
    //   154: checkcast java/util/List
    //   157: invokeinterface size : ()I
    //   162: iadd
    //   163: istore_3
    //   164: aload_0
    //   165: getfield c : Ldbxyzptlk/Tj/i;
    //   168: aload_1
    //   169: invokevirtual c : ()Ljava/lang/Object;
    //   172: checkcast java/util/List
    //   175: aload_1
    //   176: invokevirtual d : ()Ljava/lang/Object;
    //   179: checkcast java/util/List
    //   182: invokeinterface a : (Ljava/util/List;Ljava/util/List;)Ldbxyzptlk/eK/i;
    //   187: new com/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader$g
    //   190: dup
    //   191: aload_0
    //   192: aload #6
    //   194: aconst_null
    //   195: invokespecial <init> : (Lcom/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader;Ldbxyzptlk/DI/J;Ldbxyzptlk/tI/d;)V
    //   198: invokestatic g0 : (Ldbxyzptlk/eK/i;Ldbxyzptlk/CI/r;)Ldbxyzptlk/eK/i;
    //   201: new com/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader$h
    //   204: dup
    //   205: aload_0
    //   206: iload_3
    //   207: aconst_null
    //   208: invokespecial <init> : (Lcom/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader;ILdbxyzptlk/tI/d;)V
    //   211: invokestatic i : (Ldbxyzptlk/eK/i;Ldbxyzptlk/CI/q;)Ldbxyzptlk/eK/i;
    //   214: astore_1
    //   215: aload_2
    //   216: aload_0
    //   217: putfield t : Ljava/lang/Object;
    //   220: aload_2
    //   221: iload_3
    //   222: putfield u : I
    //   225: aload_2
    //   226: iconst_1
    //   227: putfield x : I
    //   230: aload_1
    //   231: aload_2
    //   232: invokestatic I : (Ldbxyzptlk/eK/i;Ldbxyzptlk/tI/d;)Ljava/lang/Object;
    //   235: astore_2
    //   236: aload_2
    //   237: aload #7
    //   239: if_acmpne -> 245
    //   242: aload #7
    //   244: areturn
    //   245: aload_0
    //   246: astore_1
    //   247: aload_2
    //   248: checkcast dbxyzptlk/vm/f
    //   251: astore #6
    //   253: aload #5
    //   255: astore_2
    //   256: aload #6
    //   258: ifnull -> 269
    //   261: aload_1
    //   262: aload #6
    //   264: iload_3
    //   265: invokevirtual q : (Ldbxyzptlk/vm/f;I)Ldbxyzptlk/vm/f;
    //   268: astore_2
    //   269: aload_2
    //   270: ifnull -> 276
    //   273: goto -> 279
    //   276: iconst_0
    //   277: istore #4
    //   279: iload #4
    //   281: invokestatic a : (Z)Ljava/lang/Boolean;
    //   284: areturn
  }
  
  public final n<List<dbxyzptlk.vm.g>, List<dbxyzptlk.vm.h>> t(List<dbxyzptlk.Uj.d> paramList) {
    ArrayList<dbxyzptlk.vm.g> arrayList1 = new ArrayList();
    ArrayList<dbxyzptlk.vm.h> arrayList = new ArrayList();
    for (dbxyzptlk.Uj.d d : paramList) {
      dbxyzptlk.Ij.e e = d.g();
      int k = b.a[e.ordinal()];
      if (k != 1 && k != 2) {
        if (k != 3)
          continue; 
        String str = d.k();
        if (str == null)
          str = ""; 
        arrayList.add(new dbxyzptlk.vm.h(str, d.l(), d.b(), d.a(), u(d), v(d)));
        continue;
      } 
      String str1 = d.e();
      if (str1 == null)
        str1 = ""; 
      String str2 = d.k();
      if (str2 == null)
        str2 = ""; 
      arrayList1.add(new dbxyzptlk.vm.g(str1, str2, d.l(), d.b(), u(d), v(d)));
    } 
    return t.a(arrayList1, arrayList);
  }
  
  public final String u(dbxyzptlk.Uj.d paramd) {
    LinkedHashMap<Object, Object> linkedHashMap = new LinkedHashMap<>();
    i i1 = paramd.j();
    if (i1 != null)
      linkedHashMap.put("metric_type", i1.c()); 
    String str = (new dbxyzptlk.XK.c(linkedHashMap)).toString();
    s.g(str, "toString(...)");
    return str;
  }
  
  public final Map<String, String> v(dbxyzptlk.Uj.d paramd) {
    LinkedHashMap<Object, Object> linkedHashMap = new LinkedHashMap<>();
    Map map = paramd.o();
    if (map != null)
      for (Map.Entry entry : map.entrySet()) {
        String str2 = (String)entry.getKey();
        Locale locale = Locale.ROOT;
        str2 = str2.toLowerCase(locale);
        s.g(str2, "toLowerCase(...)");
        String str1 = ((String)entry.getValue()).toLowerCase(locale);
        s.g(str1, "toLowerCase(...)");
        linkedHashMap.put(str2, str1);
      }  
    dbxyzptlk.Ij.d d1 = paramd.f();
    if (d1 != null) {
      String str = d1.name().toLowerCase(Locale.ROOT);
      s.g(str, "toLowerCase(...)");
      linkedHashMap.put("event_state", str);
    } 
    return (Map)linkedHashMap;
  }
  
  @Metadata(d1 = {"\000\034\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\b\n\002\b\002\n\002\020\016\n\002\b\005\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003R\024\020\005\032\0020\0048\002XT¢\006\006\n\004\b\005\020\006R\024\020\b\032\0020\0078\002XT¢\006\006\n\004\b\b\020\tR\024\020\n\032\0020\0048\002XT¢\006\006\n\004\b\n\020\006R\024\020\013\032\0020\0078\002XT¢\006\006\n\004\b\013\020\t¨\006\f"}, d2 = {"Lcom/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader$a;", "", "<init>", "()V", "", "BATCH_LIMIT", "I", "", "METRIC_TYPE", "Ljava/lang/String;", "ROW_LIMIT", "TAG_EVENT_STATE", "common_analytics_udcl_impl_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
  public static final class a {
    public a() {}
  }
  
  @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"Ldbxyzptlk/Uj/a;", "b", "()Ldbxyzptlk/Uj/a;"}, k = 3, mv = {1, 9, 0})
  public static final class c extends u implements dbxyzptlk.CI.a<dbxyzptlk.Uj.a> {
    public final UdclDatabase f;
    
    public c(UdclDatabase param1UdclDatabase) {
      super(0);
    }
    
    public final dbxyzptlk.Uj.a b() {
      return this.f.J();
    }
  }
  
  @dbxyzptlk.vI.f(c = "com.dropbox.common.udcl.impl.internal.udcl_repository.UdclDbReader", f = "UdclDbReader.kt", l = {248, 102}, m = "drainAll")
  @Metadata(k = 3, mv = {1, 9, 0}, xi = 48)
  public static final class d extends dbxyzptlk.vI.d {
    public Object t;
    
    public Object u;
    
    public Object v;
    
    public Object w;
    
    public final UdclDbReader x;
    
    public int y;
    
    public d(UdclDbReader param1UdclDbReader, dbxyzptlk.tI.d<? super d> param1d) {
      super(param1d);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      this.w = param1Object;
      this.y |= Integer.MIN_VALUE;
      return this.x.j(false, (dbxyzptlk.tI.d<? super D>)this);
    }
  }
  
  @dbxyzptlk.vI.f(c = "com.dropbox.common.udcl.impl.internal.udcl_repository.UdclDbReader$listenForDbChangesAndDrain$1", f = "UdclDbReader.kt", l = {80}, m = "invokeSuspend")
  @Metadata(d1 = {"\000\f\n\002\030\002\n\002\030\002\n\002\b\002\020\002\032\0020\001*\0020\000H@¢\006\004\b\002\020\003"}, d2 = {"Ldbxyzptlk/bK/J;", "Ldbxyzptlk/pI/D;", "<anonymous>", "(Ldbxyzptlk/bK/J;)V"}, k = 3, mv = {1, 9, 0})
  public static final class e extends l implements p<J, dbxyzptlk.tI.d<? super D>, Object> {
    public int t;
    
    public final UdclDbReader u;
    
    public e(UdclDbReader param1UdclDbReader, dbxyzptlk.tI.d<? super e> param1d) {
      super(2, param1d);
    }
    
    public final dbxyzptlk.tI.d<D> create(Object param1Object, dbxyzptlk.tI.d<?> param1d) {
      return (dbxyzptlk.tI.d<D>)new e(this.u, (dbxyzptlk.tI.d)param1d);
    }
    
    public final Object invoke(J param1J, dbxyzptlk.tI.d<? super D> param1d) {
      return ((e)create(param1J, param1d)).invokeSuspend(D.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = dbxyzptlk.uI.c.g();
      int i = this.t;
      if (i != 0) {
        if (i == 1) {
          p.b(param1Object);
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        p.b(param1Object);
        param1Object = new a(this.u, null);
        this.t = 1;
        if (dbxyzptlk.Tj.j.a((l)param1Object, (dbxyzptlk.tI.d)this) == object)
          return object; 
      } 
      return D.a;
    }
    
    @dbxyzptlk.vI.f(c = "com.dropbox.common.udcl.impl.internal.udcl_repository.UdclDbReader$listenForDbChangesAndDrain$1$1", f = "UdclDbReader.kt", l = {85}, m = "invokeSuspend")
    @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H@¢\006\004\b\001\020\002"}, d2 = {"Ldbxyzptlk/pI/D;", "<anonymous>", "()V"}, k = 3, mv = {1, 9, 0})
    public static final class a extends l implements l<dbxyzptlk.tI.d<? super D>, Object> {
      public int t;
      
      public final UdclDbReader u;
      
      public a(UdclDbReader param2UdclDbReader, dbxyzptlk.tI.d<? super a> param2d) {
        super(1, param2d);
      }
      
      public final Object a(dbxyzptlk.tI.d<? super D> param2d) {
        return ((a)create(param2d)).invokeSuspend(D.a);
      }
      
      public final dbxyzptlk.tI.d<D> create(dbxyzptlk.tI.d<?> param2d) {
        return (dbxyzptlk.tI.d<D>)new a(this.u, (dbxyzptlk.tI.d)param2d);
      }
      
      public final Object invokeSuspend(Object param2Object) {
        Object object = dbxyzptlk.uI.c.g();
        int i = this.t;
        if (i != 0) {
          if (i == 1) {
            p.b(param2Object);
          } else {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
          } 
        } else {
          p.b(param2Object);
          i i1 = k.v(k.r(new b(UdclDbReader.e(this.u).e(1))));
          param2Object = new a(this.u);
          this.t = 1;
          if (i1.a((dbxyzptlk.eK.j)param2Object, (dbxyzptlk.tI.d)this) == object)
            return object; 
        } 
        return D.a;
      }
      
      @Metadata(d1 = {"\000\022\n\002\020 \n\002\030\002\n\000\n\002\030\002\n\002\b\002\020\004\032\0020\0032\f\020\002\032\b\022\004\022\0020\0010\000H@¢\006\004\b\004\020\005"}, d2 = {"", "Ldbxyzptlk/Uj/d;", "it", "Ldbxyzptlk/pI/D;", "a", "(Ljava/util/List;Ldbxyzptlk/tI/d;)Ljava/lang/Object;"}, k = 3, mv = {1, 9, 0})
      public static final class a<T> implements dbxyzptlk.eK.j {
        public final UdclDbReader a;
        
        public a(UdclDbReader param3UdclDbReader) {}
        
        public final Object a(List<dbxyzptlk.Uj.d> param3List, dbxyzptlk.tI.d<? super D> param3d) {
          // Byte code:
          //   0: aload_2
          //   1: instanceof com/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader$e$a$a$a
          //   4: ifeq -> 35
          //   7: aload_2
          //   8: checkcast com/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader$e$a$a$a
          //   11: astore_1
          //   12: aload_1
          //   13: getfield w : I
          //   16: istore_3
          //   17: iload_3
          //   18: ldc -2147483648
          //   20: iand
          //   21: ifeq -> 35
          //   24: aload_1
          //   25: iload_3
          //   26: ldc -2147483648
          //   28: iadd
          //   29: putfield w : I
          //   32: goto -> 45
          //   35: new com/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader$e$a$a$a
          //   38: dup
          //   39: aload_0
          //   40: aload_2
          //   41: invokespecial <init> : (Lcom/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader$e$a$a;Ldbxyzptlk/tI/d;)V
          //   44: astore_1
          //   45: aload_1
          //   46: getfield u : Ljava/lang/Object;
          //   49: astore #7
          //   51: invokestatic g : ()Ljava/lang/Object;
          //   54: astore #6
          //   56: aload_1
          //   57: getfield w : I
          //   60: istore_3
          //   61: iload_3
          //   62: ifeq -> 109
          //   65: iload_3
          //   66: iconst_1
          //   67: if_icmpeq -> 93
          //   70: iload_3
          //   71: iconst_2
          //   72: if_icmpne -> 83
          //   75: aload #7
          //   77: invokestatic b : (Ljava/lang/Object;)V
          //   80: goto -> 178
          //   83: new java/lang/IllegalStateException
          //   86: dup
          //   87: ldc 'call to 'resume' before 'invoke' with coroutine'
          //   89: invokespecial <init> : (Ljava/lang/String;)V
          //   92: athrow
          //   93: aload_1
          //   94: getfield t : Ljava/lang/Object;
          //   97: checkcast com/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader$e$a$a
          //   100: astore_2
          //   101: aload #7
          //   103: invokestatic b : (Ljava/lang/Object;)V
          //   106: goto -> 145
          //   109: aload #7
          //   111: invokestatic b : (Ljava/lang/Object;)V
          //   114: aload_0
          //   115: getfield a : Lcom/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader;
          //   118: astore_2
          //   119: aload_1
          //   120: aload_0
          //   121: putfield t : Ljava/lang/Object;
          //   124: aload_1
          //   125: iconst_1
          //   126: putfield w : I
          //   129: aload_2
          //   130: iconst_1
          //   131: aload_1
          //   132: invokevirtual j : (ZLdbxyzptlk/tI/d;)Ljava/lang/Object;
          //   135: aload #6
          //   137: if_acmpne -> 143
          //   140: aload #6
          //   142: areturn
          //   143: aload_0
          //   144: astore_2
          //   145: aload_2
          //   146: getfield a : Lcom/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader;
          //   149: invokestatic d : (Lcom/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader;)J
          //   152: lstore #4
          //   154: aload_1
          //   155: aconst_null
          //   156: putfield t : Ljava/lang/Object;
          //   159: aload_1
          //   160: iconst_2
          //   161: putfield w : I
          //   164: lload #4
          //   166: aload_1
          //   167: invokestatic a : (JLdbxyzptlk/tI/d;)Ljava/lang/Object;
          //   170: aload #6
          //   172: if_acmpne -> 178
          //   175: aload #6
          //   177: areturn
          //   178: getstatic dbxyzptlk/pI/D.a : Ldbxyzptlk/pI/D;
          //   181: areturn
        }
        
        @dbxyzptlk.vI.f(c = "com.dropbox.common.udcl.impl.internal.udcl_repository.UdclDbReader$listenForDbChangesAndDrain$1$1$2", f = "UdclDbReader.kt", l = {86, 87}, m = "emit")
        @Metadata(k = 3, mv = {1, 9, 0}, xi = 48)
        public static final class a extends dbxyzptlk.vI.d {
          public Object t;
          
          public Object u;
          
          public final UdclDbReader.e.a.a<T> v;
          
          public int w;
          
          public a(UdclDbReader.e.a.a<? super T> param4a, dbxyzptlk.tI.d<? super a> param4d) {
            super(param4d);
          }
          
          public final Object invokeSuspend(Object param4Object) {
            this.u = param4Object;
            this.w |= Integer.MIN_VALUE;
            return this.v.a(null, (dbxyzptlk.tI.d<? super D>)this);
          }
        }
      }
      
      @dbxyzptlk.vI.f(c = "com.dropbox.common.udcl.impl.internal.udcl_repository.UdclDbReader$listenForDbChangesAndDrain$1$1$2", f = "UdclDbReader.kt", l = {86, 87}, m = "emit")
      @Metadata(k = 3, mv = {1, 9, 0}, xi = 48)
      public static final class a extends dbxyzptlk.vI.d {
        public Object t;
        
        public Object u;
        
        public final UdclDbReader.e.a.a<T> v;
        
        public int w;
        
        public a(UdclDbReader.e.a.a<? super T> param3a, dbxyzptlk.tI.d<? super a> param3d) {
          super(param3d);
        }
        
        public final Object invokeSuspend(Object param3Object) {
          this.u = param3Object;
          this.w |= Integer.MIN_VALUE;
          return this.v.a(null, (dbxyzptlk.tI.d<? super D>)this);
        }
      }
      
      @Metadata(d1 = {"\000\027\n\000\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\003*\001\000\b\n\030\0002\b\022\004\022\0028\0000\001J\036\020\005\032\0020\0042\f\020\003\032\b\022\004\022\0028\0000\002H@¢\006\004\b\005\020\006¨\006\007"}, d2 = {"kotlinx/coroutines/flow/internal/SafeCollector_commonKt$unsafeFlow$1", "Ldbxyzptlk/eK/i;", "Ldbxyzptlk/eK/j;", "collector", "Ldbxyzptlk/pI/D;", "a", "(Ldbxyzptlk/eK/j;Ldbxyzptlk/tI/d;)Ljava/lang/Object;", "kotlinx-coroutines-core"}, k = 1, mv = {1, 9, 0}, xi = 48)
      public static final class b implements i<List<? extends dbxyzptlk.Uj.d>> {
        public final i a;
        
        public b(i param3i) {}
        
        public Object a(dbxyzptlk.eK.j param3j, dbxyzptlk.tI.d param3d) {
          Object object = this.a.a(new a(param3j), param3d);
          return (object == dbxyzptlk.uI.c.g()) ? object : D.a;
        }
        
        @Metadata(d1 = {"\000\f\n\002\b\003\n\002\030\002\n\002\b\002\020\004\032\0020\003\"\004\b\000\020\000\"\004\b\001\020\0012\006\020\002\032\0028\000H@¢\006\004\b\004\020\005"}, d2 = {"T", "R", "value", "Ldbxyzptlk/pI/D;", "c", "(Ljava/lang/Object;Ldbxyzptlk/tI/d;)Ljava/lang/Object;"}, k = 3, mv = {1, 9, 0})
        public static final class a<T> implements dbxyzptlk.eK.j {
          public final dbxyzptlk.eK.j a;
          
          public a(dbxyzptlk.eK.j param4j) {}
          
          public final Object c(Object param4Object, dbxyzptlk.tI.d param4d) {
            // Byte code:
            //   0: aload_2
            //   1: instanceof com/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader$e$a$b$a$a
            //   4: ifeq -> 41
            //   7: aload_2
            //   8: checkcast com/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader$e$a$b$a$a
            //   11: astore #4
            //   13: aload #4
            //   15: getfield u : I
            //   18: istore_3
            //   19: iload_3
            //   20: ldc -2147483648
            //   22: iand
            //   23: ifeq -> 41
            //   26: aload #4
            //   28: iload_3
            //   29: ldc -2147483648
            //   31: iadd
            //   32: putfield u : I
            //   35: aload #4
            //   37: astore_2
            //   38: goto -> 51
            //   41: new com/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader$e$a$b$a$a
            //   44: dup
            //   45: aload_0
            //   46: aload_2
            //   47: invokespecial <init> : (Lcom/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader$e$a$b$a;Ldbxyzptlk/tI/d;)V
            //   50: astore_2
            //   51: aload_2
            //   52: getfield t : Ljava/lang/Object;
            //   55: astore #5
            //   57: invokestatic g : ()Ljava/lang/Object;
            //   60: astore #4
            //   62: aload_2
            //   63: getfield u : I
            //   66: istore_3
            //   67: iload_3
            //   68: ifeq -> 94
            //   71: iload_3
            //   72: iconst_1
            //   73: if_icmpne -> 84
            //   76: aload #5
            //   78: invokestatic b : (Ljava/lang/Object;)V
            //   81: goto -> 142
            //   84: new java/lang/IllegalStateException
            //   87: dup
            //   88: ldc 'call to 'resume' before 'invoke' with coroutine'
            //   90: invokespecial <init> : (Ljava/lang/String;)V
            //   93: athrow
            //   94: aload #5
            //   96: invokestatic b : (Ljava/lang/Object;)V
            //   99: aload_0
            //   100: getfield a : Ldbxyzptlk/eK/j;
            //   103: astore #5
            //   105: aload_1
            //   106: checkcast java/util/List
            //   109: checkcast java/util/Collection
            //   112: invokeinterface isEmpty : ()Z
            //   117: ifne -> 142
            //   120: aload_2
            //   121: iconst_1
            //   122: putfield u : I
            //   125: aload #5
            //   127: aload_1
            //   128: aload_2
            //   129: invokeinterface c : (Ljava/lang/Object;Ldbxyzptlk/tI/d;)Ljava/lang/Object;
            //   134: aload #4
            //   136: if_acmpne -> 142
            //   139: aload #4
            //   141: areturn
            //   142: getstatic dbxyzptlk/pI/D.a : Ldbxyzptlk/pI/D;
            //   145: areturn
          }
          
          @dbxyzptlk.vI.f(c = "com.dropbox.common.udcl.impl.internal.udcl_repository.UdclDbReader$listenForDbChangesAndDrain$1$1$invokeSuspend$$inlined$filter$1$2", f = "UdclDbReader.kt", l = {219}, m = "emit")
          @Metadata(k = 3, mv = {1, 9, 0}, xi = 48)
          public static final class a extends dbxyzptlk.vI.d {
            public Object t;
            
            public int u;
            
            public final UdclDbReader.e.a.b.a v;
            
            public a(UdclDbReader.e.a.b.a param5a, dbxyzptlk.tI.d param5d) {
              super(param5d);
            }
            
            public final Object invokeSuspend(Object param5Object) {
              this.t = param5Object;
              this.u |= Integer.MIN_VALUE;
              return this.v.c(null, (dbxyzptlk.tI.d)this);
            }
          }
        }
        
        @dbxyzptlk.vI.f(c = "com.dropbox.common.udcl.impl.internal.udcl_repository.UdclDbReader$listenForDbChangesAndDrain$1$1$invokeSuspend$$inlined$filter$1$2", f = "UdclDbReader.kt", l = {219}, m = "emit")
        @Metadata(k = 3, mv = {1, 9, 0}, xi = 48)
        public static final class a extends dbxyzptlk.vI.d {
          public Object t;
          
          public int u;
          
          public final UdclDbReader.e.a.b.a v;
          
          public a(UdclDbReader.e.a.b.a param4a, dbxyzptlk.tI.d param4d) {
            super(param4d);
          }
          
          public final Object invokeSuspend(Object param4Object) {
            this.t = param4Object;
            this.u |= Integer.MIN_VALUE;
            return this.v.c(null, (dbxyzptlk.tI.d)this);
          }
        }
      }
      
      @Metadata(d1 = {"\000\f\n\002\b\003\n\002\030\002\n\002\b\002\020\004\032\0020\003\"\004\b\000\020\000\"\004\b\001\020\0012\006\020\002\032\0028\000H@¢\006\004\b\004\020\005"}, d2 = {"T", "R", "value", "Ldbxyzptlk/pI/D;", "c", "(Ljava/lang/Object;Ldbxyzptlk/tI/d;)Ljava/lang/Object;"}, k = 3, mv = {1, 9, 0})
      public static final class a<T> implements dbxyzptlk.eK.j {
        public final dbxyzptlk.eK.j a;
        
        public a(dbxyzptlk.eK.j param3j) {}
        
        public final Object c(Object param3Object, dbxyzptlk.tI.d param3d) {
          // Byte code:
          //   0: aload_2
          //   1: instanceof com/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader$e$a$b$a$a
          //   4: ifeq -> 41
          //   7: aload_2
          //   8: checkcast com/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader$e$a$b$a$a
          //   11: astore #4
          //   13: aload #4
          //   15: getfield u : I
          //   18: istore_3
          //   19: iload_3
          //   20: ldc -2147483648
          //   22: iand
          //   23: ifeq -> 41
          //   26: aload #4
          //   28: iload_3
          //   29: ldc -2147483648
          //   31: iadd
          //   32: putfield u : I
          //   35: aload #4
          //   37: astore_2
          //   38: goto -> 51
          //   41: new com/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader$e$a$b$a$a
          //   44: dup
          //   45: aload_0
          //   46: aload_2
          //   47: invokespecial <init> : (Lcom/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader$e$a$b$a;Ldbxyzptlk/tI/d;)V
          //   50: astore_2
          //   51: aload_2
          //   52: getfield t : Ljava/lang/Object;
          //   55: astore #5
          //   57: invokestatic g : ()Ljava/lang/Object;
          //   60: astore #4
          //   62: aload_2
          //   63: getfield u : I
          //   66: istore_3
          //   67: iload_3
          //   68: ifeq -> 94
          //   71: iload_3
          //   72: iconst_1
          //   73: if_icmpne -> 84
          //   76: aload #5
          //   78: invokestatic b : (Ljava/lang/Object;)V
          //   81: goto -> 142
          //   84: new java/lang/IllegalStateException
          //   87: dup
          //   88: ldc 'call to 'resume' before 'invoke' with coroutine'
          //   90: invokespecial <init> : (Ljava/lang/String;)V
          //   93: athrow
          //   94: aload #5
          //   96: invokestatic b : (Ljava/lang/Object;)V
          //   99: aload_0
          //   100: getfield a : Ldbxyzptlk/eK/j;
          //   103: astore #5
          //   105: aload_1
          //   106: checkcast java/util/List
          //   109: checkcast java/util/Collection
          //   112: invokeinterface isEmpty : ()Z
          //   117: ifne -> 142
          //   120: aload_2
          //   121: iconst_1
          //   122: putfield u : I
          //   125: aload #5
          //   127: aload_1
          //   128: aload_2
          //   129: invokeinterface c : (Ljava/lang/Object;Ldbxyzptlk/tI/d;)Ljava/lang/Object;
          //   134: aload #4
          //   136: if_acmpne -> 142
          //   139: aload #4
          //   141: areturn
          //   142: getstatic dbxyzptlk/pI/D.a : Ldbxyzptlk/pI/D;
          //   145: areturn
        }
        
        @dbxyzptlk.vI.f(c = "com.dropbox.common.udcl.impl.internal.udcl_repository.UdclDbReader$listenForDbChangesAndDrain$1$1$invokeSuspend$$inlined$filter$1$2", f = "UdclDbReader.kt", l = {219}, m = "emit")
        @Metadata(k = 3, mv = {1, 9, 0}, xi = 48)
        public static final class a extends dbxyzptlk.vI.d {
          public Object t;
          
          public int u;
          
          public final UdclDbReader.e.a.b.a v;
          
          public a(UdclDbReader.e.a.b.a param5a, dbxyzptlk.tI.d param5d) {
            super(param5d);
          }
          
          public final Object invokeSuspend(Object param5Object) {
            this.t = param5Object;
            this.u |= Integer.MIN_VALUE;
            return this.v.c(null, (dbxyzptlk.tI.d)this);
          }
        }
      }
      
      @dbxyzptlk.vI.f(c = "com.dropbox.common.udcl.impl.internal.udcl_repository.UdclDbReader$listenForDbChangesAndDrain$1$1$invokeSuspend$$inlined$filter$1$2", f = "UdclDbReader.kt", l = {219}, m = "emit")
      @Metadata(k = 3, mv = {1, 9, 0}, xi = 48)
      public static final class a extends dbxyzptlk.vI.d {
        public Object t;
        
        public int u;
        
        public final UdclDbReader.e.a.b.a v;
        
        public a(UdclDbReader.e.a.b.a param3a, dbxyzptlk.tI.d param3d) {
          super(param3d);
        }
        
        public final Object invokeSuspend(Object param3Object) {
          this.t = param3Object;
          this.u |= Integer.MIN_VALUE;
          return this.v.c(null, (dbxyzptlk.tI.d)this);
        }
      }
    }
    
    @Metadata(d1 = {"\000\022\n\002\020 \n\002\030\002\n\000\n\002\030\002\n\002\b\002\020\004\032\0020\0032\f\020\002\032\b\022\004\022\0020\0010\000H@¢\006\004\b\004\020\005"}, d2 = {"", "Ldbxyzptlk/Uj/d;", "it", "Ldbxyzptlk/pI/D;", "a", "(Ljava/util/List;Ldbxyzptlk/tI/d;)Ljava/lang/Object;"}, k = 3, mv = {1, 9, 0})
    public static final class a<T> implements dbxyzptlk.eK.j {
      public final UdclDbReader a;
      
      public a(UdclDbReader param2UdclDbReader) {}
      
      public final Object a(List<dbxyzptlk.Uj.d> param2List, dbxyzptlk.tI.d<? super D> param2d) {
        // Byte code:
        //   0: aload_2
        //   1: instanceof com/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader$e$a$a$a
        //   4: ifeq -> 35
        //   7: aload_2
        //   8: checkcast com/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader$e$a$a$a
        //   11: astore_1
        //   12: aload_1
        //   13: getfield w : I
        //   16: istore_3
        //   17: iload_3
        //   18: ldc -2147483648
        //   20: iand
        //   21: ifeq -> 35
        //   24: aload_1
        //   25: iload_3
        //   26: ldc -2147483648
        //   28: iadd
        //   29: putfield w : I
        //   32: goto -> 45
        //   35: new com/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader$e$a$a$a
        //   38: dup
        //   39: aload_0
        //   40: aload_2
        //   41: invokespecial <init> : (Lcom/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader$e$a$a;Ldbxyzptlk/tI/d;)V
        //   44: astore_1
        //   45: aload_1
        //   46: getfield u : Ljava/lang/Object;
        //   49: astore #7
        //   51: invokestatic g : ()Ljava/lang/Object;
        //   54: astore #6
        //   56: aload_1
        //   57: getfield w : I
        //   60: istore_3
        //   61: iload_3
        //   62: ifeq -> 109
        //   65: iload_3
        //   66: iconst_1
        //   67: if_icmpeq -> 93
        //   70: iload_3
        //   71: iconst_2
        //   72: if_icmpne -> 83
        //   75: aload #7
        //   77: invokestatic b : (Ljava/lang/Object;)V
        //   80: goto -> 178
        //   83: new java/lang/IllegalStateException
        //   86: dup
        //   87: ldc 'call to 'resume' before 'invoke' with coroutine'
        //   89: invokespecial <init> : (Ljava/lang/String;)V
        //   92: athrow
        //   93: aload_1
        //   94: getfield t : Ljava/lang/Object;
        //   97: checkcast com/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader$e$a$a
        //   100: astore_2
        //   101: aload #7
        //   103: invokestatic b : (Ljava/lang/Object;)V
        //   106: goto -> 145
        //   109: aload #7
        //   111: invokestatic b : (Ljava/lang/Object;)V
        //   114: aload_0
        //   115: getfield a : Lcom/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader;
        //   118: astore_2
        //   119: aload_1
        //   120: aload_0
        //   121: putfield t : Ljava/lang/Object;
        //   124: aload_1
        //   125: iconst_1
        //   126: putfield w : I
        //   129: aload_2
        //   130: iconst_1
        //   131: aload_1
        //   132: invokevirtual j : (ZLdbxyzptlk/tI/d;)Ljava/lang/Object;
        //   135: aload #6
        //   137: if_acmpne -> 143
        //   140: aload #6
        //   142: areturn
        //   143: aload_0
        //   144: astore_2
        //   145: aload_2
        //   146: getfield a : Lcom/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader;
        //   149: invokestatic d : (Lcom/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader;)J
        //   152: lstore #4
        //   154: aload_1
        //   155: aconst_null
        //   156: putfield t : Ljava/lang/Object;
        //   159: aload_1
        //   160: iconst_2
        //   161: putfield w : I
        //   164: lload #4
        //   166: aload_1
        //   167: invokestatic a : (JLdbxyzptlk/tI/d;)Ljava/lang/Object;
        //   170: aload #6
        //   172: if_acmpne -> 178
        //   175: aload #6
        //   177: areturn
        //   178: getstatic dbxyzptlk/pI/D.a : Ldbxyzptlk/pI/D;
        //   181: areturn
      }
      
      @dbxyzptlk.vI.f(c = "com.dropbox.common.udcl.impl.internal.udcl_repository.UdclDbReader$listenForDbChangesAndDrain$1$1$2", f = "UdclDbReader.kt", l = {86, 87}, m = "emit")
      @Metadata(k = 3, mv = {1, 9, 0}, xi = 48)
      public static final class a extends dbxyzptlk.vI.d {
        public Object t;
        
        public Object u;
        
        public final UdclDbReader.e.a.a<T> v;
        
        public int w;
        
        public a(UdclDbReader.e.a.a<? super T> param4a, dbxyzptlk.tI.d<? super a> param4d) {
          super(param4d);
        }
        
        public final Object invokeSuspend(Object param4Object) {
          this.u = param4Object;
          this.w |= Integer.MIN_VALUE;
          return this.v.a(null, (dbxyzptlk.tI.d<? super D>)this);
        }
      }
    }
    
    @dbxyzptlk.vI.f(c = "com.dropbox.common.udcl.impl.internal.udcl_repository.UdclDbReader$listenForDbChangesAndDrain$1$1$2", f = "UdclDbReader.kt", l = {86, 87}, m = "emit")
    @Metadata(k = 3, mv = {1, 9, 0}, xi = 48)
    public static final class a extends dbxyzptlk.vI.d {
      public Object t;
      
      public Object u;
      
      public final UdclDbReader.e.a.a<T> v;
      
      public int w;
      
      public a(UdclDbReader.e.a.a<? super T> param2a, dbxyzptlk.tI.d<? super a> param2d) {
        super(param2d);
      }
      
      public final Object invokeSuspend(Object param2Object) {
        this.u = param2Object;
        this.w |= Integer.MIN_VALUE;
        return this.v.a(null, (dbxyzptlk.tI.d<? super D>)this);
      }
    }
    
    @Metadata(d1 = {"\000\027\n\000\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\003*\001\000\b\n\030\0002\b\022\004\022\0028\0000\001J\036\020\005\032\0020\0042\f\020\003\032\b\022\004\022\0028\0000\002H@¢\006\004\b\005\020\006¨\006\007"}, d2 = {"kotlinx/coroutines/flow/internal/SafeCollector_commonKt$unsafeFlow$1", "Ldbxyzptlk/eK/i;", "Ldbxyzptlk/eK/j;", "collector", "Ldbxyzptlk/pI/D;", "a", "(Ldbxyzptlk/eK/j;Ldbxyzptlk/tI/d;)Ljava/lang/Object;", "kotlinx-coroutines-core"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class b implements i<List<? extends dbxyzptlk.Uj.d>> {
      public final i a;
      
      public b(i param2i) {}
      
      public Object a(dbxyzptlk.eK.j param2j, dbxyzptlk.tI.d param2d) {
        Object object = this.a.a(new a(param2j), param2d);
        return (object == dbxyzptlk.uI.c.g()) ? object : D.a;
      }
      
      @Metadata(d1 = {"\000\f\n\002\b\003\n\002\030\002\n\002\b\002\020\004\032\0020\003\"\004\b\000\020\000\"\004\b\001\020\0012\006\020\002\032\0028\000H@¢\006\004\b\004\020\005"}, d2 = {"T", "R", "value", "Ldbxyzptlk/pI/D;", "c", "(Ljava/lang/Object;Ldbxyzptlk/tI/d;)Ljava/lang/Object;"}, k = 3, mv = {1, 9, 0})
      public static final class a<T> implements dbxyzptlk.eK.j {
        public final dbxyzptlk.eK.j a;
        
        public a(dbxyzptlk.eK.j param4j) {}
        
        public final Object c(Object param4Object, dbxyzptlk.tI.d param4d) {
          // Byte code:
          //   0: aload_2
          //   1: instanceof com/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader$e$a$b$a$a
          //   4: ifeq -> 41
          //   7: aload_2
          //   8: checkcast com/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader$e$a$b$a$a
          //   11: astore #4
          //   13: aload #4
          //   15: getfield u : I
          //   18: istore_3
          //   19: iload_3
          //   20: ldc -2147483648
          //   22: iand
          //   23: ifeq -> 41
          //   26: aload #4
          //   28: iload_3
          //   29: ldc -2147483648
          //   31: iadd
          //   32: putfield u : I
          //   35: aload #4
          //   37: astore_2
          //   38: goto -> 51
          //   41: new com/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader$e$a$b$a$a
          //   44: dup
          //   45: aload_0
          //   46: aload_2
          //   47: invokespecial <init> : (Lcom/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader$e$a$b$a;Ldbxyzptlk/tI/d;)V
          //   50: astore_2
          //   51: aload_2
          //   52: getfield t : Ljava/lang/Object;
          //   55: astore #5
          //   57: invokestatic g : ()Ljava/lang/Object;
          //   60: astore #4
          //   62: aload_2
          //   63: getfield u : I
          //   66: istore_3
          //   67: iload_3
          //   68: ifeq -> 94
          //   71: iload_3
          //   72: iconst_1
          //   73: if_icmpne -> 84
          //   76: aload #5
          //   78: invokestatic b : (Ljava/lang/Object;)V
          //   81: goto -> 142
          //   84: new java/lang/IllegalStateException
          //   87: dup
          //   88: ldc 'call to 'resume' before 'invoke' with coroutine'
          //   90: invokespecial <init> : (Ljava/lang/String;)V
          //   93: athrow
          //   94: aload #5
          //   96: invokestatic b : (Ljava/lang/Object;)V
          //   99: aload_0
          //   100: getfield a : Ldbxyzptlk/eK/j;
          //   103: astore #5
          //   105: aload_1
          //   106: checkcast java/util/List
          //   109: checkcast java/util/Collection
          //   112: invokeinterface isEmpty : ()Z
          //   117: ifne -> 142
          //   120: aload_2
          //   121: iconst_1
          //   122: putfield u : I
          //   125: aload #5
          //   127: aload_1
          //   128: aload_2
          //   129: invokeinterface c : (Ljava/lang/Object;Ldbxyzptlk/tI/d;)Ljava/lang/Object;
          //   134: aload #4
          //   136: if_acmpne -> 142
          //   139: aload #4
          //   141: areturn
          //   142: getstatic dbxyzptlk/pI/D.a : Ldbxyzptlk/pI/D;
          //   145: areturn
        }
        
        @dbxyzptlk.vI.f(c = "com.dropbox.common.udcl.impl.internal.udcl_repository.UdclDbReader$listenForDbChangesAndDrain$1$1$invokeSuspend$$inlined$filter$1$2", f = "UdclDbReader.kt", l = {219}, m = "emit")
        @Metadata(k = 3, mv = {1, 9, 0}, xi = 48)
        public static final class a extends dbxyzptlk.vI.d {
          public Object t;
          
          public int u;
          
          public final UdclDbReader.e.a.b.a v;
          
          public a(UdclDbReader.e.a.b.a param5a, dbxyzptlk.tI.d param5d) {
            super(param5d);
          }
          
          public final Object invokeSuspend(Object param5Object) {
            this.t = param5Object;
            this.u |= Integer.MIN_VALUE;
            return this.v.c(null, (dbxyzptlk.tI.d)this);
          }
        }
      }
      
      @dbxyzptlk.vI.f(c = "com.dropbox.common.udcl.impl.internal.udcl_repository.UdclDbReader$listenForDbChangesAndDrain$1$1$invokeSuspend$$inlined$filter$1$2", f = "UdclDbReader.kt", l = {219}, m = "emit")
      @Metadata(k = 3, mv = {1, 9, 0}, xi = 48)
      public static final class a extends dbxyzptlk.vI.d {
        public Object t;
        
        public int u;
        
        public final UdclDbReader.e.a.b.a v;
        
        public a(UdclDbReader.e.a.b.a param4a, dbxyzptlk.tI.d param4d) {
          super(param4d);
        }
        
        public final Object invokeSuspend(Object param4Object) {
          this.t = param4Object;
          this.u |= Integer.MIN_VALUE;
          return this.v.c(null, (dbxyzptlk.tI.d)this);
        }
      }
    }
    
    @Metadata(d1 = {"\000\f\n\002\b\003\n\002\030\002\n\002\b\002\020\004\032\0020\003\"\004\b\000\020\000\"\004\b\001\020\0012\006\020\002\032\0028\000H@¢\006\004\b\004\020\005"}, d2 = {"T", "R", "value", "Ldbxyzptlk/pI/D;", "c", "(Ljava/lang/Object;Ldbxyzptlk/tI/d;)Ljava/lang/Object;"}, k = 3, mv = {1, 9, 0})
    public static final class a<T> implements dbxyzptlk.eK.j {
      public final dbxyzptlk.eK.j a;
      
      public a(dbxyzptlk.eK.j param2j) {}
      
      public final Object c(Object param2Object, dbxyzptlk.tI.d param2d) {
        // Byte code:
        //   0: aload_2
        //   1: instanceof com/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader$e$a$b$a$a
        //   4: ifeq -> 41
        //   7: aload_2
        //   8: checkcast com/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader$e$a$b$a$a
        //   11: astore #4
        //   13: aload #4
        //   15: getfield u : I
        //   18: istore_3
        //   19: iload_3
        //   20: ldc -2147483648
        //   22: iand
        //   23: ifeq -> 41
        //   26: aload #4
        //   28: iload_3
        //   29: ldc -2147483648
        //   31: iadd
        //   32: putfield u : I
        //   35: aload #4
        //   37: astore_2
        //   38: goto -> 51
        //   41: new com/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader$e$a$b$a$a
        //   44: dup
        //   45: aload_0
        //   46: aload_2
        //   47: invokespecial <init> : (Lcom/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader$e$a$b$a;Ldbxyzptlk/tI/d;)V
        //   50: astore_2
        //   51: aload_2
        //   52: getfield t : Ljava/lang/Object;
        //   55: astore #5
        //   57: invokestatic g : ()Ljava/lang/Object;
        //   60: astore #4
        //   62: aload_2
        //   63: getfield u : I
        //   66: istore_3
        //   67: iload_3
        //   68: ifeq -> 94
        //   71: iload_3
        //   72: iconst_1
        //   73: if_icmpne -> 84
        //   76: aload #5
        //   78: invokestatic b : (Ljava/lang/Object;)V
        //   81: goto -> 142
        //   84: new java/lang/IllegalStateException
        //   87: dup
        //   88: ldc 'call to 'resume' before 'invoke' with coroutine'
        //   90: invokespecial <init> : (Ljava/lang/String;)V
        //   93: athrow
        //   94: aload #5
        //   96: invokestatic b : (Ljava/lang/Object;)V
        //   99: aload_0
        //   100: getfield a : Ldbxyzptlk/eK/j;
        //   103: astore #5
        //   105: aload_1
        //   106: checkcast java/util/List
        //   109: checkcast java/util/Collection
        //   112: invokeinterface isEmpty : ()Z
        //   117: ifne -> 142
        //   120: aload_2
        //   121: iconst_1
        //   122: putfield u : I
        //   125: aload #5
        //   127: aload_1
        //   128: aload_2
        //   129: invokeinterface c : (Ljava/lang/Object;Ldbxyzptlk/tI/d;)Ljava/lang/Object;
        //   134: aload #4
        //   136: if_acmpne -> 142
        //   139: aload #4
        //   141: areturn
        //   142: getstatic dbxyzptlk/pI/D.a : Ldbxyzptlk/pI/D;
        //   145: areturn
      }
      
      @dbxyzptlk.vI.f(c = "com.dropbox.common.udcl.impl.internal.udcl_repository.UdclDbReader$listenForDbChangesAndDrain$1$1$invokeSuspend$$inlined$filter$1$2", f = "UdclDbReader.kt", l = {219}, m = "emit")
      @Metadata(k = 3, mv = {1, 9, 0}, xi = 48)
      public static final class a extends dbxyzptlk.vI.d {
        public Object t;
        
        public int u;
        
        public final UdclDbReader.e.a.b.a v;
        
        public a(UdclDbReader.e.a.b.a param5a, dbxyzptlk.tI.d param5d) {
          super(param5d);
        }
        
        public final Object invokeSuspend(Object param5Object) {
          this.t = param5Object;
          this.u |= Integer.MIN_VALUE;
          return this.v.c(null, (dbxyzptlk.tI.d)this);
        }
      }
    }
    
    @dbxyzptlk.vI.f(c = "com.dropbox.common.udcl.impl.internal.udcl_repository.UdclDbReader$listenForDbChangesAndDrain$1$1$invokeSuspend$$inlined$filter$1$2", f = "UdclDbReader.kt", l = {219}, m = "emit")
    @Metadata(k = 3, mv = {1, 9, 0}, xi = 48)
    public static final class a extends dbxyzptlk.vI.d {
      public Object t;
      
      public int u;
      
      public final UdclDbReader.e.a.b.a v;
      
      public a(UdclDbReader.e.a.b.a param2a, dbxyzptlk.tI.d param2d) {
        super(param2d);
      }
      
      public final Object invokeSuspend(Object param2Object) {
        this.t = param2Object;
        this.u |= Integer.MIN_VALUE;
        return this.v.c(null, (dbxyzptlk.tI.d)this);
      }
    }
  }
  
  @dbxyzptlk.vI.f(c = "com.dropbox.common.udcl.impl.internal.udcl_repository.UdclDbReader$listenForDbChangesAndDrain$1$1", f = "UdclDbReader.kt", l = {85}, m = "invokeSuspend")
  @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H@¢\006\004\b\001\020\002"}, d2 = {"Ldbxyzptlk/pI/D;", "<anonymous>", "()V"}, k = 3, mv = {1, 9, 0})
  public static final class a extends l implements l<dbxyzptlk.tI.d<? super D>, Object> {
    public int t;
    
    public final UdclDbReader u;
    
    public a(UdclDbReader param1UdclDbReader, dbxyzptlk.tI.d<? super a> param1d) {
      super(1, param1d);
    }
    
    public final Object a(dbxyzptlk.tI.d<? super D> param1d) {
      return ((a)create(param1d)).invokeSuspend(D.a);
    }
    
    public final dbxyzptlk.tI.d<D> create(dbxyzptlk.tI.d<?> param1d) {
      return (dbxyzptlk.tI.d<D>)new a(this.u, (dbxyzptlk.tI.d)param1d);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = dbxyzptlk.uI.c.g();
      int i = this.t;
      if (i != 0) {
        if (i == 1) {
          p.b(param1Object);
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        p.b(param1Object);
        i i1 = k.v(k.r(new b(UdclDbReader.e(this.u).e(1))));
        param1Object = new a(this.u);
        this.t = 1;
        if (i1.a((dbxyzptlk.eK.j)param1Object, (dbxyzptlk.tI.d)this) == object)
          return object; 
      } 
      return D.a;
    }
    
    @Metadata(d1 = {"\000\022\n\002\020 \n\002\030\002\n\000\n\002\030\002\n\002\b\002\020\004\032\0020\0032\f\020\002\032\b\022\004\022\0020\0010\000H@¢\006\004\b\004\020\005"}, d2 = {"", "Ldbxyzptlk/Uj/d;", "it", "Ldbxyzptlk/pI/D;", "a", "(Ljava/util/List;Ldbxyzptlk/tI/d;)Ljava/lang/Object;"}, k = 3, mv = {1, 9, 0})
    public static final class a<T> implements dbxyzptlk.eK.j {
      public final UdclDbReader a;
      
      public a(UdclDbReader param3UdclDbReader) {}
      
      public final Object a(List<dbxyzptlk.Uj.d> param3List, dbxyzptlk.tI.d<? super D> param3d) {
        // Byte code:
        //   0: aload_2
        //   1: instanceof com/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader$e$a$a$a
        //   4: ifeq -> 35
        //   7: aload_2
        //   8: checkcast com/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader$e$a$a$a
        //   11: astore_1
        //   12: aload_1
        //   13: getfield w : I
        //   16: istore_3
        //   17: iload_3
        //   18: ldc -2147483648
        //   20: iand
        //   21: ifeq -> 35
        //   24: aload_1
        //   25: iload_3
        //   26: ldc -2147483648
        //   28: iadd
        //   29: putfield w : I
        //   32: goto -> 45
        //   35: new com/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader$e$a$a$a
        //   38: dup
        //   39: aload_0
        //   40: aload_2
        //   41: invokespecial <init> : (Lcom/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader$e$a$a;Ldbxyzptlk/tI/d;)V
        //   44: astore_1
        //   45: aload_1
        //   46: getfield u : Ljava/lang/Object;
        //   49: astore #7
        //   51: invokestatic g : ()Ljava/lang/Object;
        //   54: astore #6
        //   56: aload_1
        //   57: getfield w : I
        //   60: istore_3
        //   61: iload_3
        //   62: ifeq -> 109
        //   65: iload_3
        //   66: iconst_1
        //   67: if_icmpeq -> 93
        //   70: iload_3
        //   71: iconst_2
        //   72: if_icmpne -> 83
        //   75: aload #7
        //   77: invokestatic b : (Ljava/lang/Object;)V
        //   80: goto -> 178
        //   83: new java/lang/IllegalStateException
        //   86: dup
        //   87: ldc 'call to 'resume' before 'invoke' with coroutine'
        //   89: invokespecial <init> : (Ljava/lang/String;)V
        //   92: athrow
        //   93: aload_1
        //   94: getfield t : Ljava/lang/Object;
        //   97: checkcast com/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader$e$a$a
        //   100: astore_2
        //   101: aload #7
        //   103: invokestatic b : (Ljava/lang/Object;)V
        //   106: goto -> 145
        //   109: aload #7
        //   111: invokestatic b : (Ljava/lang/Object;)V
        //   114: aload_0
        //   115: getfield a : Lcom/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader;
        //   118: astore_2
        //   119: aload_1
        //   120: aload_0
        //   121: putfield t : Ljava/lang/Object;
        //   124: aload_1
        //   125: iconst_1
        //   126: putfield w : I
        //   129: aload_2
        //   130: iconst_1
        //   131: aload_1
        //   132: invokevirtual j : (ZLdbxyzptlk/tI/d;)Ljava/lang/Object;
        //   135: aload #6
        //   137: if_acmpne -> 143
        //   140: aload #6
        //   142: areturn
        //   143: aload_0
        //   144: astore_2
        //   145: aload_2
        //   146: getfield a : Lcom/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader;
        //   149: invokestatic d : (Lcom/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader;)J
        //   152: lstore #4
        //   154: aload_1
        //   155: aconst_null
        //   156: putfield t : Ljava/lang/Object;
        //   159: aload_1
        //   160: iconst_2
        //   161: putfield w : I
        //   164: lload #4
        //   166: aload_1
        //   167: invokestatic a : (JLdbxyzptlk/tI/d;)Ljava/lang/Object;
        //   170: aload #6
        //   172: if_acmpne -> 178
        //   175: aload #6
        //   177: areturn
        //   178: getstatic dbxyzptlk/pI/D.a : Ldbxyzptlk/pI/D;
        //   181: areturn
      }
      
      @dbxyzptlk.vI.f(c = "com.dropbox.common.udcl.impl.internal.udcl_repository.UdclDbReader$listenForDbChangesAndDrain$1$1$2", f = "UdclDbReader.kt", l = {86, 87}, m = "emit")
      @Metadata(k = 3, mv = {1, 9, 0}, xi = 48)
      public static final class a extends dbxyzptlk.vI.d {
        public Object t;
        
        public Object u;
        
        public final UdclDbReader.e.a.a<T> v;
        
        public int w;
        
        public a(UdclDbReader.e.a.a<? super T> param4a, dbxyzptlk.tI.d<? super a> param4d) {
          super(param4d);
        }
        
        public final Object invokeSuspend(Object param4Object) {
          this.u = param4Object;
          this.w |= Integer.MIN_VALUE;
          return this.v.a(null, (dbxyzptlk.tI.d<? super D>)this);
        }
      }
    }
    
    @dbxyzptlk.vI.f(c = "com.dropbox.common.udcl.impl.internal.udcl_repository.UdclDbReader$listenForDbChangesAndDrain$1$1$2", f = "UdclDbReader.kt", l = {86, 87}, m = "emit")
    @Metadata(k = 3, mv = {1, 9, 0}, xi = 48)
    public static final class a extends dbxyzptlk.vI.d {
      public Object t;
      
      public Object u;
      
      public final UdclDbReader.e.a.a<T> v;
      
      public int w;
      
      public a(UdclDbReader.e.a.a<? super T> param3a, dbxyzptlk.tI.d<? super a> param3d) {
        super(param3d);
      }
      
      public final Object invokeSuspend(Object param3Object) {
        this.u = param3Object;
        this.w |= Integer.MIN_VALUE;
        return this.v.a(null, (dbxyzptlk.tI.d<? super D>)this);
      }
    }
    
    @Metadata(d1 = {"\000\027\n\000\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\003*\001\000\b\n\030\0002\b\022\004\022\0028\0000\001J\036\020\005\032\0020\0042\f\020\003\032\b\022\004\022\0028\0000\002H@¢\006\004\b\005\020\006¨\006\007"}, d2 = {"kotlinx/coroutines/flow/internal/SafeCollector_commonKt$unsafeFlow$1", "Ldbxyzptlk/eK/i;", "Ldbxyzptlk/eK/j;", "collector", "Ldbxyzptlk/pI/D;", "a", "(Ldbxyzptlk/eK/j;Ldbxyzptlk/tI/d;)Ljava/lang/Object;", "kotlinx-coroutines-core"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class b implements i<List<? extends dbxyzptlk.Uj.d>> {
      public final i a;
      
      public b(i param3i) {}
      
      public Object a(dbxyzptlk.eK.j param3j, dbxyzptlk.tI.d param3d) {
        Object object = this.a.a(new a(param3j), param3d);
        return (object == dbxyzptlk.uI.c.g()) ? object : D.a;
      }
      
      @Metadata(d1 = {"\000\f\n\002\b\003\n\002\030\002\n\002\b\002\020\004\032\0020\003\"\004\b\000\020\000\"\004\b\001\020\0012\006\020\002\032\0028\000H@¢\006\004\b\004\020\005"}, d2 = {"T", "R", "value", "Ldbxyzptlk/pI/D;", "c", "(Ljava/lang/Object;Ldbxyzptlk/tI/d;)Ljava/lang/Object;"}, k = 3, mv = {1, 9, 0})
      public static final class a<T> implements dbxyzptlk.eK.j {
        public final dbxyzptlk.eK.j a;
        
        public a(dbxyzptlk.eK.j param4j) {}
        
        public final Object c(Object param4Object, dbxyzptlk.tI.d param4d) {
          // Byte code:
          //   0: aload_2
          //   1: instanceof com/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader$e$a$b$a$a
          //   4: ifeq -> 41
          //   7: aload_2
          //   8: checkcast com/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader$e$a$b$a$a
          //   11: astore #4
          //   13: aload #4
          //   15: getfield u : I
          //   18: istore_3
          //   19: iload_3
          //   20: ldc -2147483648
          //   22: iand
          //   23: ifeq -> 41
          //   26: aload #4
          //   28: iload_3
          //   29: ldc -2147483648
          //   31: iadd
          //   32: putfield u : I
          //   35: aload #4
          //   37: astore_2
          //   38: goto -> 51
          //   41: new com/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader$e$a$b$a$a
          //   44: dup
          //   45: aload_0
          //   46: aload_2
          //   47: invokespecial <init> : (Lcom/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader$e$a$b$a;Ldbxyzptlk/tI/d;)V
          //   50: astore_2
          //   51: aload_2
          //   52: getfield t : Ljava/lang/Object;
          //   55: astore #5
          //   57: invokestatic g : ()Ljava/lang/Object;
          //   60: astore #4
          //   62: aload_2
          //   63: getfield u : I
          //   66: istore_3
          //   67: iload_3
          //   68: ifeq -> 94
          //   71: iload_3
          //   72: iconst_1
          //   73: if_icmpne -> 84
          //   76: aload #5
          //   78: invokestatic b : (Ljava/lang/Object;)V
          //   81: goto -> 142
          //   84: new java/lang/IllegalStateException
          //   87: dup
          //   88: ldc 'call to 'resume' before 'invoke' with coroutine'
          //   90: invokespecial <init> : (Ljava/lang/String;)V
          //   93: athrow
          //   94: aload #5
          //   96: invokestatic b : (Ljava/lang/Object;)V
          //   99: aload_0
          //   100: getfield a : Ldbxyzptlk/eK/j;
          //   103: astore #5
          //   105: aload_1
          //   106: checkcast java/util/List
          //   109: checkcast java/util/Collection
          //   112: invokeinterface isEmpty : ()Z
          //   117: ifne -> 142
          //   120: aload_2
          //   121: iconst_1
          //   122: putfield u : I
          //   125: aload #5
          //   127: aload_1
          //   128: aload_2
          //   129: invokeinterface c : (Ljava/lang/Object;Ldbxyzptlk/tI/d;)Ljava/lang/Object;
          //   134: aload #4
          //   136: if_acmpne -> 142
          //   139: aload #4
          //   141: areturn
          //   142: getstatic dbxyzptlk/pI/D.a : Ldbxyzptlk/pI/D;
          //   145: areturn
        }
        
        @dbxyzptlk.vI.f(c = "com.dropbox.common.udcl.impl.internal.udcl_repository.UdclDbReader$listenForDbChangesAndDrain$1$1$invokeSuspend$$inlined$filter$1$2", f = "UdclDbReader.kt", l = {219}, m = "emit")
        @Metadata(k = 3, mv = {1, 9, 0}, xi = 48)
        public static final class a extends dbxyzptlk.vI.d {
          public Object t;
          
          public int u;
          
          public final UdclDbReader.e.a.b.a v;
          
          public a(UdclDbReader.e.a.b.a param5a, dbxyzptlk.tI.d param5d) {
            super(param5d);
          }
          
          public final Object invokeSuspend(Object param5Object) {
            this.t = param5Object;
            this.u |= Integer.MIN_VALUE;
            return this.v.c(null, (dbxyzptlk.tI.d)this);
          }
        }
      }
      
      @dbxyzptlk.vI.f(c = "com.dropbox.common.udcl.impl.internal.udcl_repository.UdclDbReader$listenForDbChangesAndDrain$1$1$invokeSuspend$$inlined$filter$1$2", f = "UdclDbReader.kt", l = {219}, m = "emit")
      @Metadata(k = 3, mv = {1, 9, 0}, xi = 48)
      public static final class a extends dbxyzptlk.vI.d {
        public Object t;
        
        public int u;
        
        public final UdclDbReader.e.a.b.a v;
        
        public a(UdclDbReader.e.a.b.a param4a, dbxyzptlk.tI.d param4d) {
          super(param4d);
        }
        
        public final Object invokeSuspend(Object param4Object) {
          this.t = param4Object;
          this.u |= Integer.MIN_VALUE;
          return this.v.c(null, (dbxyzptlk.tI.d)this);
        }
      }
    }
    
    @Metadata(d1 = {"\000\f\n\002\b\003\n\002\030\002\n\002\b\002\020\004\032\0020\003\"\004\b\000\020\000\"\004\b\001\020\0012\006\020\002\032\0028\000H@¢\006\004\b\004\020\005"}, d2 = {"T", "R", "value", "Ldbxyzptlk/pI/D;", "c", "(Ljava/lang/Object;Ldbxyzptlk/tI/d;)Ljava/lang/Object;"}, k = 3, mv = {1, 9, 0})
    public static final class a<T> implements dbxyzptlk.eK.j {
      public final dbxyzptlk.eK.j a;
      
      public a(dbxyzptlk.eK.j param3j) {}
      
      public final Object c(Object param3Object, dbxyzptlk.tI.d param3d) {
        // Byte code:
        //   0: aload_2
        //   1: instanceof com/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader$e$a$b$a$a
        //   4: ifeq -> 41
        //   7: aload_2
        //   8: checkcast com/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader$e$a$b$a$a
        //   11: astore #4
        //   13: aload #4
        //   15: getfield u : I
        //   18: istore_3
        //   19: iload_3
        //   20: ldc -2147483648
        //   22: iand
        //   23: ifeq -> 41
        //   26: aload #4
        //   28: iload_3
        //   29: ldc -2147483648
        //   31: iadd
        //   32: putfield u : I
        //   35: aload #4
        //   37: astore_2
        //   38: goto -> 51
        //   41: new com/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader$e$a$b$a$a
        //   44: dup
        //   45: aload_0
        //   46: aload_2
        //   47: invokespecial <init> : (Lcom/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader$e$a$b$a;Ldbxyzptlk/tI/d;)V
        //   50: astore_2
        //   51: aload_2
        //   52: getfield t : Ljava/lang/Object;
        //   55: astore #5
        //   57: invokestatic g : ()Ljava/lang/Object;
        //   60: astore #4
        //   62: aload_2
        //   63: getfield u : I
        //   66: istore_3
        //   67: iload_3
        //   68: ifeq -> 94
        //   71: iload_3
        //   72: iconst_1
        //   73: if_icmpne -> 84
        //   76: aload #5
        //   78: invokestatic b : (Ljava/lang/Object;)V
        //   81: goto -> 142
        //   84: new java/lang/IllegalStateException
        //   87: dup
        //   88: ldc 'call to 'resume' before 'invoke' with coroutine'
        //   90: invokespecial <init> : (Ljava/lang/String;)V
        //   93: athrow
        //   94: aload #5
        //   96: invokestatic b : (Ljava/lang/Object;)V
        //   99: aload_0
        //   100: getfield a : Ldbxyzptlk/eK/j;
        //   103: astore #5
        //   105: aload_1
        //   106: checkcast java/util/List
        //   109: checkcast java/util/Collection
        //   112: invokeinterface isEmpty : ()Z
        //   117: ifne -> 142
        //   120: aload_2
        //   121: iconst_1
        //   122: putfield u : I
        //   125: aload #5
        //   127: aload_1
        //   128: aload_2
        //   129: invokeinterface c : (Ljava/lang/Object;Ldbxyzptlk/tI/d;)Ljava/lang/Object;
        //   134: aload #4
        //   136: if_acmpne -> 142
        //   139: aload #4
        //   141: areturn
        //   142: getstatic dbxyzptlk/pI/D.a : Ldbxyzptlk/pI/D;
        //   145: areturn
      }
      
      @dbxyzptlk.vI.f(c = "com.dropbox.common.udcl.impl.internal.udcl_repository.UdclDbReader$listenForDbChangesAndDrain$1$1$invokeSuspend$$inlined$filter$1$2", f = "UdclDbReader.kt", l = {219}, m = "emit")
      @Metadata(k = 3, mv = {1, 9, 0}, xi = 48)
      public static final class a extends dbxyzptlk.vI.d {
        public Object t;
        
        public int u;
        
        public final UdclDbReader.e.a.b.a v;
        
        public a(UdclDbReader.e.a.b.a param5a, dbxyzptlk.tI.d param5d) {
          super(param5d);
        }
        
        public final Object invokeSuspend(Object param5Object) {
          this.t = param5Object;
          this.u |= Integer.MIN_VALUE;
          return this.v.c(null, (dbxyzptlk.tI.d)this);
        }
      }
    }
    
    @dbxyzptlk.vI.f(c = "com.dropbox.common.udcl.impl.internal.udcl_repository.UdclDbReader$listenForDbChangesAndDrain$1$1$invokeSuspend$$inlined$filter$1$2", f = "UdclDbReader.kt", l = {219}, m = "emit")
    @Metadata(k = 3, mv = {1, 9, 0}, xi = 48)
    public static final class a extends dbxyzptlk.vI.d {
      public Object t;
      
      public int u;
      
      public final UdclDbReader.e.a.b.a v;
      
      public a(UdclDbReader.e.a.b.a param3a, dbxyzptlk.tI.d param3d) {
        super(param3d);
      }
      
      public final Object invokeSuspend(Object param3Object) {
        this.t = param3Object;
        this.u |= Integer.MIN_VALUE;
        return this.v.c(null, (dbxyzptlk.tI.d)this);
      }
    }
  }
  
  @Metadata(d1 = {"\000\022\n\002\020 \n\002\030\002\n\000\n\002\030\002\n\002\b\002\020\004\032\0020\0032\f\020\002\032\b\022\004\022\0020\0010\000H@¢\006\004\b\004\020\005"}, d2 = {"", "Ldbxyzptlk/Uj/d;", "it", "Ldbxyzptlk/pI/D;", "a", "(Ljava/util/List;Ldbxyzptlk/tI/d;)Ljava/lang/Object;"}, k = 3, mv = {1, 9, 0})
  public static final class a<T> implements dbxyzptlk.eK.j {
    public final UdclDbReader a;
    
    public a(UdclDbReader param1UdclDbReader) {}
    
    public final Object a(List<dbxyzptlk.Uj.d> param1List, dbxyzptlk.tI.d<? super D> param1d) {
      // Byte code:
      //   0: aload_2
      //   1: instanceof com/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader$e$a$a$a
      //   4: ifeq -> 35
      //   7: aload_2
      //   8: checkcast com/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader$e$a$a$a
      //   11: astore_1
      //   12: aload_1
      //   13: getfield w : I
      //   16: istore_3
      //   17: iload_3
      //   18: ldc -2147483648
      //   20: iand
      //   21: ifeq -> 35
      //   24: aload_1
      //   25: iload_3
      //   26: ldc -2147483648
      //   28: iadd
      //   29: putfield w : I
      //   32: goto -> 45
      //   35: new com/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader$e$a$a$a
      //   38: dup
      //   39: aload_0
      //   40: aload_2
      //   41: invokespecial <init> : (Lcom/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader$e$a$a;Ldbxyzptlk/tI/d;)V
      //   44: astore_1
      //   45: aload_1
      //   46: getfield u : Ljava/lang/Object;
      //   49: astore #7
      //   51: invokestatic g : ()Ljava/lang/Object;
      //   54: astore #6
      //   56: aload_1
      //   57: getfield w : I
      //   60: istore_3
      //   61: iload_3
      //   62: ifeq -> 109
      //   65: iload_3
      //   66: iconst_1
      //   67: if_icmpeq -> 93
      //   70: iload_3
      //   71: iconst_2
      //   72: if_icmpne -> 83
      //   75: aload #7
      //   77: invokestatic b : (Ljava/lang/Object;)V
      //   80: goto -> 178
      //   83: new java/lang/IllegalStateException
      //   86: dup
      //   87: ldc 'call to 'resume' before 'invoke' with coroutine'
      //   89: invokespecial <init> : (Ljava/lang/String;)V
      //   92: athrow
      //   93: aload_1
      //   94: getfield t : Ljava/lang/Object;
      //   97: checkcast com/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader$e$a$a
      //   100: astore_2
      //   101: aload #7
      //   103: invokestatic b : (Ljava/lang/Object;)V
      //   106: goto -> 145
      //   109: aload #7
      //   111: invokestatic b : (Ljava/lang/Object;)V
      //   114: aload_0
      //   115: getfield a : Lcom/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader;
      //   118: astore_2
      //   119: aload_1
      //   120: aload_0
      //   121: putfield t : Ljava/lang/Object;
      //   124: aload_1
      //   125: iconst_1
      //   126: putfield w : I
      //   129: aload_2
      //   130: iconst_1
      //   131: aload_1
      //   132: invokevirtual j : (ZLdbxyzptlk/tI/d;)Ljava/lang/Object;
      //   135: aload #6
      //   137: if_acmpne -> 143
      //   140: aload #6
      //   142: areturn
      //   143: aload_0
      //   144: astore_2
      //   145: aload_2
      //   146: getfield a : Lcom/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader;
      //   149: invokestatic d : (Lcom/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader;)J
      //   152: lstore #4
      //   154: aload_1
      //   155: aconst_null
      //   156: putfield t : Ljava/lang/Object;
      //   159: aload_1
      //   160: iconst_2
      //   161: putfield w : I
      //   164: lload #4
      //   166: aload_1
      //   167: invokestatic a : (JLdbxyzptlk/tI/d;)Ljava/lang/Object;
      //   170: aload #6
      //   172: if_acmpne -> 178
      //   175: aload #6
      //   177: areturn
      //   178: getstatic dbxyzptlk/pI/D.a : Ldbxyzptlk/pI/D;
      //   181: areturn
    }
    
    @dbxyzptlk.vI.f(c = "com.dropbox.common.udcl.impl.internal.udcl_repository.UdclDbReader$listenForDbChangesAndDrain$1$1$2", f = "UdclDbReader.kt", l = {86, 87}, m = "emit")
    @Metadata(k = 3, mv = {1, 9, 0}, xi = 48)
    public static final class a extends dbxyzptlk.vI.d {
      public Object t;
      
      public Object u;
      
      public final UdclDbReader.e.a.a<T> v;
      
      public int w;
      
      public a(UdclDbReader.e.a.a<? super T> param4a, dbxyzptlk.tI.d<? super a> param4d) {
        super(param4d);
      }
      
      public final Object invokeSuspend(Object param4Object) {
        this.u = param4Object;
        this.w |= Integer.MIN_VALUE;
        return this.v.a(null, (dbxyzptlk.tI.d<? super D>)this);
      }
    }
  }
  
  @dbxyzptlk.vI.f(c = "com.dropbox.common.udcl.impl.internal.udcl_repository.UdclDbReader$listenForDbChangesAndDrain$1$1$2", f = "UdclDbReader.kt", l = {86, 87}, m = "emit")
  @Metadata(k = 3, mv = {1, 9, 0}, xi = 48)
  public static final class a extends dbxyzptlk.vI.d {
    public Object t;
    
    public Object u;
    
    public final UdclDbReader.e.a.a<T> v;
    
    public int w;
    
    public a(UdclDbReader.e.a.a<? super T> param1a, dbxyzptlk.tI.d<? super a> param1d) {
      super(param1d);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      this.u = param1Object;
      this.w |= Integer.MIN_VALUE;
      return this.v.a(null, (dbxyzptlk.tI.d<? super D>)this);
    }
  }
  
  @Metadata(d1 = {"\000\027\n\000\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\003*\001\000\b\n\030\0002\b\022\004\022\0028\0000\001J\036\020\005\032\0020\0042\f\020\003\032\b\022\004\022\0028\0000\002H@¢\006\004\b\005\020\006¨\006\007"}, d2 = {"kotlinx/coroutines/flow/internal/SafeCollector_commonKt$unsafeFlow$1", "Ldbxyzptlk/eK/i;", "Ldbxyzptlk/eK/j;", "collector", "Ldbxyzptlk/pI/D;", "a", "(Ldbxyzptlk/eK/j;Ldbxyzptlk/tI/d;)Ljava/lang/Object;", "kotlinx-coroutines-core"}, k = 1, mv = {1, 9, 0}, xi = 48)
  public static final class b implements i<List<? extends dbxyzptlk.Uj.d>> {
    public final i a;
    
    public b(i param1i) {}
    
    public Object a(dbxyzptlk.eK.j param1j, dbxyzptlk.tI.d param1d) {
      Object object = this.a.a(new a(param1j), param1d);
      return (object == dbxyzptlk.uI.c.g()) ? object : D.a;
    }
    
    @Metadata(d1 = {"\000\f\n\002\b\003\n\002\030\002\n\002\b\002\020\004\032\0020\003\"\004\b\000\020\000\"\004\b\001\020\0012\006\020\002\032\0028\000H@¢\006\004\b\004\020\005"}, d2 = {"T", "R", "value", "Ldbxyzptlk/pI/D;", "c", "(Ljava/lang/Object;Ldbxyzptlk/tI/d;)Ljava/lang/Object;"}, k = 3, mv = {1, 9, 0})
    public static final class a<T> implements dbxyzptlk.eK.j {
      public final dbxyzptlk.eK.j a;
      
      public a(dbxyzptlk.eK.j param4j) {}
      
      public final Object c(Object param4Object, dbxyzptlk.tI.d param4d) {
        // Byte code:
        //   0: aload_2
        //   1: instanceof com/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader$e$a$b$a$a
        //   4: ifeq -> 41
        //   7: aload_2
        //   8: checkcast com/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader$e$a$b$a$a
        //   11: astore #4
        //   13: aload #4
        //   15: getfield u : I
        //   18: istore_3
        //   19: iload_3
        //   20: ldc -2147483648
        //   22: iand
        //   23: ifeq -> 41
        //   26: aload #4
        //   28: iload_3
        //   29: ldc -2147483648
        //   31: iadd
        //   32: putfield u : I
        //   35: aload #4
        //   37: astore_2
        //   38: goto -> 51
        //   41: new com/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader$e$a$b$a$a
        //   44: dup
        //   45: aload_0
        //   46: aload_2
        //   47: invokespecial <init> : (Lcom/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader$e$a$b$a;Ldbxyzptlk/tI/d;)V
        //   50: astore_2
        //   51: aload_2
        //   52: getfield t : Ljava/lang/Object;
        //   55: astore #5
        //   57: invokestatic g : ()Ljava/lang/Object;
        //   60: astore #4
        //   62: aload_2
        //   63: getfield u : I
        //   66: istore_3
        //   67: iload_3
        //   68: ifeq -> 94
        //   71: iload_3
        //   72: iconst_1
        //   73: if_icmpne -> 84
        //   76: aload #5
        //   78: invokestatic b : (Ljava/lang/Object;)V
        //   81: goto -> 142
        //   84: new java/lang/IllegalStateException
        //   87: dup
        //   88: ldc 'call to 'resume' before 'invoke' with coroutine'
        //   90: invokespecial <init> : (Ljava/lang/String;)V
        //   93: athrow
        //   94: aload #5
        //   96: invokestatic b : (Ljava/lang/Object;)V
        //   99: aload_0
        //   100: getfield a : Ldbxyzptlk/eK/j;
        //   103: astore #5
        //   105: aload_1
        //   106: checkcast java/util/List
        //   109: checkcast java/util/Collection
        //   112: invokeinterface isEmpty : ()Z
        //   117: ifne -> 142
        //   120: aload_2
        //   121: iconst_1
        //   122: putfield u : I
        //   125: aload #5
        //   127: aload_1
        //   128: aload_2
        //   129: invokeinterface c : (Ljava/lang/Object;Ldbxyzptlk/tI/d;)Ljava/lang/Object;
        //   134: aload #4
        //   136: if_acmpne -> 142
        //   139: aload #4
        //   141: areturn
        //   142: getstatic dbxyzptlk/pI/D.a : Ldbxyzptlk/pI/D;
        //   145: areturn
      }
      
      @dbxyzptlk.vI.f(c = "com.dropbox.common.udcl.impl.internal.udcl_repository.UdclDbReader$listenForDbChangesAndDrain$1$1$invokeSuspend$$inlined$filter$1$2", f = "UdclDbReader.kt", l = {219}, m = "emit")
      @Metadata(k = 3, mv = {1, 9, 0}, xi = 48)
      public static final class a extends dbxyzptlk.vI.d {
        public Object t;
        
        public int u;
        
        public final UdclDbReader.e.a.b.a v;
        
        public a(UdclDbReader.e.a.b.a param5a, dbxyzptlk.tI.d param5d) {
          super(param5d);
        }
        
        public final Object invokeSuspend(Object param5Object) {
          this.t = param5Object;
          this.u |= Integer.MIN_VALUE;
          return this.v.c(null, (dbxyzptlk.tI.d)this);
        }
      }
    }
    
    @dbxyzptlk.vI.f(c = "com.dropbox.common.udcl.impl.internal.udcl_repository.UdclDbReader$listenForDbChangesAndDrain$1$1$invokeSuspend$$inlined$filter$1$2", f = "UdclDbReader.kt", l = {219}, m = "emit")
    @Metadata(k = 3, mv = {1, 9, 0}, xi = 48)
    public static final class a extends dbxyzptlk.vI.d {
      public Object t;
      
      public int u;
      
      public final UdclDbReader.e.a.b.a v;
      
      public a(UdclDbReader.e.a.b.a param4a, dbxyzptlk.tI.d param4d) {
        super(param4d);
      }
      
      public final Object invokeSuspend(Object param4Object) {
        this.t = param4Object;
        this.u |= Integer.MIN_VALUE;
        return this.v.c(null, (dbxyzptlk.tI.d)this);
      }
    }
  }
  
  @Metadata(d1 = {"\000\f\n\002\b\003\n\002\030\002\n\002\b\002\020\004\032\0020\003\"\004\b\000\020\000\"\004\b\001\020\0012\006\020\002\032\0028\000H@¢\006\004\b\004\020\005"}, d2 = {"T", "R", "value", "Ldbxyzptlk/pI/D;", "c", "(Ljava/lang/Object;Ldbxyzptlk/tI/d;)Ljava/lang/Object;"}, k = 3, mv = {1, 9, 0})
  public static final class a<T> implements dbxyzptlk.eK.j {
    public final dbxyzptlk.eK.j a;
    
    public a(dbxyzptlk.eK.j param1j) {}
    
    public final Object c(Object param1Object, dbxyzptlk.tI.d param1d) {
      // Byte code:
      //   0: aload_2
      //   1: instanceof com/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader$e$a$b$a$a
      //   4: ifeq -> 41
      //   7: aload_2
      //   8: checkcast com/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader$e$a$b$a$a
      //   11: astore #4
      //   13: aload #4
      //   15: getfield u : I
      //   18: istore_3
      //   19: iload_3
      //   20: ldc -2147483648
      //   22: iand
      //   23: ifeq -> 41
      //   26: aload #4
      //   28: iload_3
      //   29: ldc -2147483648
      //   31: iadd
      //   32: putfield u : I
      //   35: aload #4
      //   37: astore_2
      //   38: goto -> 51
      //   41: new com/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader$e$a$b$a$a
      //   44: dup
      //   45: aload_0
      //   46: aload_2
      //   47: invokespecial <init> : (Lcom/dropbox/common/udcl/impl/internal/udcl_repository/UdclDbReader$e$a$b$a;Ldbxyzptlk/tI/d;)V
      //   50: astore_2
      //   51: aload_2
      //   52: getfield t : Ljava/lang/Object;
      //   55: astore #5
      //   57: invokestatic g : ()Ljava/lang/Object;
      //   60: astore #4
      //   62: aload_2
      //   63: getfield u : I
      //   66: istore_3
      //   67: iload_3
      //   68: ifeq -> 94
      //   71: iload_3
      //   72: iconst_1
      //   73: if_icmpne -> 84
      //   76: aload #5
      //   78: invokestatic b : (Ljava/lang/Object;)V
      //   81: goto -> 142
      //   84: new java/lang/IllegalStateException
      //   87: dup
      //   88: ldc 'call to 'resume' before 'invoke' with coroutine'
      //   90: invokespecial <init> : (Ljava/lang/String;)V
      //   93: athrow
      //   94: aload #5
      //   96: invokestatic b : (Ljava/lang/Object;)V
      //   99: aload_0
      //   100: getfield a : Ldbxyzptlk/eK/j;
      //   103: astore #5
      //   105: aload_1
      //   106: checkcast java/util/List
      //   109: checkcast java/util/Collection
      //   112: invokeinterface isEmpty : ()Z
      //   117: ifne -> 142
      //   120: aload_2
      //   121: iconst_1
      //   122: putfield u : I
      //   125: aload #5
      //   127: aload_1
      //   128: aload_2
      //   129: invokeinterface c : (Ljava/lang/Object;Ldbxyzptlk/tI/d;)Ljava/lang/Object;
      //   134: aload #4
      //   136: if_acmpne -> 142
      //   139: aload #4
      //   141: areturn
      //   142: getstatic dbxyzptlk/pI/D.a : Ldbxyzptlk/pI/D;
      //   145: areturn
    }
    
    @dbxyzptlk.vI.f(c = "com.dropbox.common.udcl.impl.internal.udcl_repository.UdclDbReader$listenForDbChangesAndDrain$1$1$invokeSuspend$$inlined$filter$1$2", f = "UdclDbReader.kt", l = {219}, m = "emit")
    @Metadata(k = 3, mv = {1, 9, 0}, xi = 48)
    public static final class a extends dbxyzptlk.vI.d {
      public Object t;
      
      public int u;
      
      public final UdclDbReader.e.a.b.a v;
      
      public a(UdclDbReader.e.a.b.a param5a, dbxyzptlk.tI.d param5d) {
        super(param5d);
      }
      
      public final Object invokeSuspend(Object param5Object) {
        this.t = param5Object;
        this.u |= Integer.MIN_VALUE;
        return this.v.c(null, (dbxyzptlk.tI.d)this);
      }
    }
  }
  
  @dbxyzptlk.vI.f(c = "com.dropbox.common.udcl.impl.internal.udcl_repository.UdclDbReader$listenForDbChangesAndDrain$1$1$invokeSuspend$$inlined$filter$1$2", f = "UdclDbReader.kt", l = {219}, m = "emit")
  @Metadata(k = 3, mv = {1, 9, 0}, xi = 48)
  public static final class a extends dbxyzptlk.vI.d {
    public Object t;
    
    public int u;
    
    public final UdclDbReader.e.a.b.a v;
    
    public a(UdclDbReader.e.a.b.a param1a, dbxyzptlk.tI.d param1d) {
      super(param1d);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      this.t = param1Object;
      this.u |= Integer.MIN_VALUE;
      return this.v.c(null, (dbxyzptlk.tI.d)this);
    }
  }
  
  @dbxyzptlk.vI.f(c = "com.dropbox.common.udcl.impl.internal.udcl_repository.UdclDbReader", f = "UdclDbReader.kt", l = {209}, m = "logUdclMeasure")
  @Metadata(k = 3, mv = {1, 9, 0}, xi = 48)
  public static final class f extends dbxyzptlk.vI.d {
    public Object t;
    
    public int u;
    
    public Object v;
    
    public final UdclDbReader w;
    
    public int x;
    
    public f(UdclDbReader param1UdclDbReader, dbxyzptlk.tI.d<? super f> param1d) {
      super(param1d);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      this.v = param1Object;
      this.x |= Integer.MIN_VALUE;
      return UdclDbReader.i(this.w, null, (dbxyzptlk.tI.d)this);
    }
  }
  
  @dbxyzptlk.vI.f(c = "com.dropbox.common.udcl.impl.internal.udcl_repository.UdclDbReader$logUdclMeasure$2", f = "UdclDbReader.kt", l = {203}, m = "invokeSuspend")
  @Metadata(d1 = {"\000\034\n\002\030\002\n\002\030\002\n\002\020\003\n\000\n\002\020\t\n\000\n\002\020\013\n\002\b\002\020\007\032\0020\006*\b\022\004\022\0020\0010\0002\006\020\003\032\0020\0022\006\020\005\032\0020\004H@¢\006\004\b\007\020\b"}, d2 = {"Ldbxyzptlk/eK/j;", "Ldbxyzptlk/vm/f;", "", "<anonymous parameter 0>", "", "attempt", "", "<anonymous>", "(Ldbxyzptlk/eK/j;Ljava/lang/Throwable;J)Z"}, k = 3, mv = {1, 9, 0})
  public static final class g extends l implements r<dbxyzptlk.eK.j<? super dbxyzptlk.vm.f>, Throwable, Long, dbxyzptlk.tI.d<? super Boolean>, Object> {
    public int t;
    
    public long u;
    
    public final UdclDbReader v;
    
    public final J w;
    
    public g(UdclDbReader param1UdclDbReader, J param1J, dbxyzptlk.tI.d<? super g> param1d) {
      super(4, param1d);
    }
    
    public final Object a(dbxyzptlk.eK.j<? super dbxyzptlk.vm.f> param1j, Throwable param1Throwable, long param1Long, dbxyzptlk.tI.d<? super Boolean> param1d) {
      g g1 = new g(this.v, this.w, (dbxyzptlk.tI.d)param1d);
      g1.u = param1Long;
      return g1.invokeSuspend(D.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = dbxyzptlk.uI.c.g();
      int i = this.t;
      boolean bool = true;
      if (i != 0) {
        if (i == 1) {
          p.b(param1Object);
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        p.b(param1Object);
        long l1 = this.u;
        if (UdclDbReader.g(this.v).a() || l1 > 3L) {
          bool = false;
        } else {
          param1Object = this.w;
          ((J)param1Object).a = Math.min(((J)param1Object).a * 2L, 30000L);
          l1 = this.w.a;
          this.t = 1;
          if (T.a(l1, (dbxyzptlk.tI.d)this) == object)
            return object; 
        } 
      } 
      return dbxyzptlk.vI.b.a(bool);
    }
  }
  
  @dbxyzptlk.vI.f(c = "com.dropbox.common.udcl.impl.internal.udcl_repository.UdclDbReader$logUdclMeasure$3", f = "UdclDbReader.kt", l = {}, m = "invokeSuspend")
  @Metadata(d1 = {"\000\026\n\002\030\002\n\002\030\002\n\002\020\003\n\000\n\002\030\002\n\002\b\002\020\005\032\0020\004*\b\022\004\022\0020\0010\0002\006\020\003\032\0020\002H@¢\006\004\b\005\020\006"}, d2 = {"Ldbxyzptlk/eK/j;", "Ldbxyzptlk/vm/f;", "", "it", "Ldbxyzptlk/pI/D;", "<anonymous>", "(Ldbxyzptlk/eK/j;Ljava/lang/Throwable;)V"}, k = 3, mv = {1, 9, 0})
  public static final class h extends l implements q<dbxyzptlk.eK.j<? super dbxyzptlk.vm.f>, Throwable, dbxyzptlk.tI.d<? super D>, Object> {
    public int t;
    
    public Object u;
    
    public final UdclDbReader v;
    
    public final int w;
    
    public h(UdclDbReader param1UdclDbReader, int param1Int, dbxyzptlk.tI.d<? super h> param1d) {
      super(3, param1d);
    }
    
    public final Object a(dbxyzptlk.eK.j<? super dbxyzptlk.vm.f> param1j, Throwable param1Throwable, dbxyzptlk.tI.d<? super D> param1d) {
      h h1 = new h(this.v, this.w, (dbxyzptlk.tI.d)param1d);
      h1.u = param1Throwable;
      return h1.invokeSuspend(D.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      dbxyzptlk.uI.c.g();
      if (this.t == 0) {
        p.b(param1Object);
        param1Object = this.u;
        UdclDbReader.h(this.v, (Throwable)param1Object, this.w);
        return D.a;
      } 
      throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }
  }
  
  @dbxyzptlk.vI.f(c = "com.dropbox.common.udcl.impl.internal.udcl_repository.UdclDbReader$run$1", f = "UdclDbReader.kt", l = {}, m = "invokeSuspend")
  @Metadata(d1 = {"\000\f\n\002\030\002\n\002\030\002\n\002\b\002\020\002\032\0020\001*\0020\000H@¢\006\004\b\002\020\003"}, d2 = {"Ldbxyzptlk/bK/J;", "Ldbxyzptlk/pI/D;", "<anonymous>", "(Ldbxyzptlk/bK/J;)V"}, k = 3, mv = {1, 9, 0})
  public static final class j extends l implements p<J, dbxyzptlk.tI.d<? super D>, Object> {
    public int t;
    
    public final UdclDbReader u;
    
    public j(UdclDbReader param1UdclDbReader, dbxyzptlk.tI.d<? super j> param1d) {
      super(2, param1d);
    }
    
    public final dbxyzptlk.tI.d<D> create(Object param1Object, dbxyzptlk.tI.d<?> param1d) {
      return (dbxyzptlk.tI.d<D>)new j(this.u, (dbxyzptlk.tI.d)param1d);
    }
    
    public final Object invoke(J param1J, dbxyzptlk.tI.d<? super D> param1d) {
      return ((j)create(param1J, param1d)).invokeSuspend(D.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      dbxyzptlk.uI.c.g();
      if (this.t == 0) {
        p.b(param1Object);
        ProcessLifecycleOwner.i.a().getLifecycle().a((dbxyzptlk.U2.h)this.u);
        return D.a;
      } 
      throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\commo\\udcl\impl\interna\\udcl_repository\UdclDbReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */