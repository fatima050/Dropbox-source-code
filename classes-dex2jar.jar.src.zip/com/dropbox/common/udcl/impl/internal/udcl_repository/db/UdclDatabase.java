package com.dropbox.common.udcl.impl.internal.udcl_repository.db;

import android.content.Context;
import dbxyzptlk.DI.s;
import dbxyzptlk.F4.r;
import dbxyzptlk.F4.s;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

@Metadata(d1 = {"\000\024\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\005\b'\030\000 \0072\0020\001:\001\bB\007¢\006\004\b\002\020\003J\017\020\005\032\0020\004H&¢\006\004\b\005\020\006¨\006\t"}, d2 = {"Lcom/dropbox/common/udcl/impl/internal/udcl_repository/db/UdclDatabase;", "Ldbxyzptlk/F4/s;", "<init>", "()V", "Ldbxyzptlk/Uj/a;", "J", "()Ldbxyzptlk/Uj/a;", "p", "a", "common_analytics_udcl_impl_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
public abstract class UdclDatabase extends s {
  public static final a p = new a(null);
  
  public abstract dbxyzptlk.Uj.a J();
  
  @Metadata(d1 = {"\000\"\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\020\b\n\002\b\003\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\025\020\007\032\0020\0062\006\020\005\032\0020\004¢\006\004\b\007\020\bR\024\020\n\032\0020\t8\006XT¢\006\006\n\004\b\n\020\013¨\006\f"}, d2 = {"Lcom/dropbox/common/udcl/impl/internal/udcl_repository/db/UdclDatabase$a;", "", "<init>", "()V", "Landroid/content/Context;", "context", "Lcom/dropbox/common/udcl/impl/internal/udcl_repository/db/UdclDatabase;", "a", "(Landroid/content/Context;)Lcom/dropbox/common/udcl/impl/internal/udcl_repository/db/UdclDatabase;", "", "SCHEMA_VERSION", "I", "common_analytics_udcl_impl_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
  public static final class a {
    public a() {}
    
    public final UdclDatabase a(Context param1Context) {
      s.h(param1Context, "context");
      return (UdclDatabase)r.a(param1Context, UdclDatabase.class, "udcl_db").d();
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\commo\\udcl\impl\interna\\udcl_repository\db\UdclDatabase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */