package com.dropbox.common.udcl.impl.internal.instrumentation.appstartup;

import android.app.ActivityManager;
import android.app.Application;
import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import com.squareup.anvil.annotations.ContributesMultibinding;
import dbxyzptlk.Aj.b;
import dbxyzptlk.DI.G;
import dbxyzptlk.DI.s;
import dbxyzptlk.Ij.s;
import dbxyzptlk.Jh.d;
import dbxyzptlk.Mj.d;
import dbxyzptlk.kL.m;
import dbxyzptlk.sh.g;
import kotlin.Metadata;

@ContributesMultibinding(scope = d.class)
@Metadata(d1 = {"\000F\n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\004\n\002\020\t\n\002\b\002\n\002\020\013\n\002\b\b\n\002\030\002\n\002\b\004\b\007\030\0002\0020\001B1\b\007\022\b\b\001\020\003\032\0020\002\022\006\020\005\032\0020\004\022\006\020\007\032\0020\006\022\f\020\n\032\b\022\004\022\0020\t0\b¢\006\004\b\013\020\fJ\017\020\016\032\0020\rH\026¢\006\004\b\016\020\017J\017\020\020\032\0020\rH\002¢\006\004\b\020\020\017J\017\020\021\032\0020\rH\002¢\006\004\b\021\020\017J\017\020\023\032\0020\022H\002¢\006\004\b\023\020\024J\017\020\026\032\0020\025H\002¢\006\004\b\026\020\027R\024\020\005\032\0020\0048\002X\004¢\006\006\n\004\b\030\020\031R\024\020\007\032\0020\0068\002X\004¢\006\006\n\004\b\032\020\033R\032\020\n\032\b\022\004\022\0020\t0\b8\002X\004¢\006\006\n\004\b\034\020\035R\024\020!\032\0020\0368\002X\004¢\006\006\n\004\b\037\020 ¨\006\""}, d2 = {"Lcom/dropbox/common/udcl/impl/internal/instrumentation/appstartup/a;", "Ldbxyzptlk/Aj/b;", "Landroid/content/Context;", "context", "Ldbxyzptlk/Ij/s;", "udcl", "Ldbxyzptlk/sh/g;", "noAuthFeatureGatingInteractor", "Ldbxyzptlk/oI/a;", "Ldbxyzptlk/kL/m;", "papaEventListener", "<init>", "(Landroid/content/Context;Ldbxyzptlk/Ij/s;Ldbxyzptlk/sh/g;Ldbxyzptlk/oI/a;)V", "Ldbxyzptlk/pI/D;", "run", "()V", "j", "h", "", "k", "()J", "", "l", "()Z", "a", "Ldbxyzptlk/Ij/s;", "b", "Ldbxyzptlk/sh/g;", "c", "Ldbxyzptlk/oI/a;", "Landroid/app/Application;", "d", "Landroid/app/Application;", "application", "common_analytics_udcl_impl_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class a implements b {
  public final s a;
  
  public final g b;
  
  public final dbxyzptlk.oI.a<m> c;
  
  public final Application d;
  
  public a(Context paramContext, s params, g paramg, dbxyzptlk.oI.a<m> parama) {
    this.a = params;
    this.b = paramg;
    this.c = parama;
    paramContext = paramContext.getApplicationContext();
    s.f(paramContext, "null cannot be cast to non-null type android.app.Application");
    this.d = (Application)paramContext;
  }
  
  public static final void i(G paramG) {
    s.h(paramG, "$firstPostEnqueued");
    paramG.a = false;
  }
  
  public final void h() {
    if (!d.a(this.b))
      return; 
    if (l()) {
      G g1 = new G();
      g1.a = true;
      (new Handler(Looper.getMainLooper())).post((Runnable)new dbxyzptlk.Nj.a(g1));
      this.d.registerActivityLifecycleCallbacks((Application.ActivityLifecycleCallbacks)new a(this, g1));
    } 
  }
  
  public final void j() {
    m.a a1 = m.a;
    Object object = this.c.get();
    s.g(object, "get(...)");
    a1.b((m)object);
  }
  
  public final long k() {
    long l;
    if (Build.VERSION.SDK_INT >= 28) {
      l = RealAppStartupTimeFactory.b.a();
    } else {
      l = AppStartupInitializer.a.a();
    } 
    return l;
  }
  
  public final boolean l() {
    boolean bool;
    ActivityManager.RunningAppProcessInfo runningAppProcessInfo = new ActivityManager.RunningAppProcessInfo();
    ActivityManager.getMyMemoryState(runningAppProcessInfo);
    if (runningAppProcessInfo.importance == 100) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public void run() {
    h();
    j();
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\commo\\udcl\impl\internal\instrumentation\appstartup\a.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */