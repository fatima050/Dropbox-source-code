package com.dropbox.common.udcl.impl.internal.instrumentation.appstartup;

import android.app.Activity;
import android.app.AppComponentFactory;
import android.app.Application;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.ContentProvider;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.os.SystemClock;
import dbxyzptlk.DI.s;
import dbxyzptlk.kL.u;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

@Metadata(d1 = {"\000R\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\003\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\020\016\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\006\b\007\030\000 !2\0020\001:\001\037B\021\022\b\b\002\020\003\032\0020\002¢\006\004\b\004\020\005J\037\020\n\032\0020\0062\006\020\007\032\0020\0062\006\020\t\032\0020\bH\027¢\006\004\b\n\020\013J\037\020\017\032\0020\0162\006\020\007\032\0020\0062\006\020\r\032\0020\fH\026¢\006\004\b\017\020\020J)\020\024\032\0020\0232\006\020\007\032\0020\0062\006\020\r\032\0020\f2\b\020\022\032\004\030\0010\021H\026¢\006\004\b\024\020\025J)\020\027\032\0020\0262\006\020\007\032\0020\0062\006\020\r\032\0020\f2\b\020\022\032\004\030\0010\021H\026¢\006\004\b\027\020\030J)\020\032\032\0020\0312\006\020\007\032\0020\0062\006\020\r\032\0020\f2\b\020\022\032\004\030\0010\021H\026¢\006\004\b\032\020\033J\037\020\035\032\0020\0342\006\020\007\032\0020\0062\006\020\r\032\0020\fH\026¢\006\004\b\035\020\036R\024\020\003\032\0020\0028\002X\004¢\006\006\n\004\b\037\020 ¨\006\""}, d2 = {"Lcom/dropbox/common/udcl/impl/internal/instrumentation/appstartup/RealAppStartupTimeFactory;", "Landroid/app/AppComponentFactory;", "Ldbxyzptlk/kL/u;", "delegate", "<init>", "(Ldbxyzptlk/kL/u;)V", "Ljava/lang/ClassLoader;", "cl", "Landroid/content/pm/ApplicationInfo;", "aInfo", "instantiateClassLoader", "(Ljava/lang/ClassLoader;Landroid/content/pm/ApplicationInfo;)Ljava/lang/ClassLoader;", "", "className", "Landroid/app/Application;", "instantiateApplication", "(Ljava/lang/ClassLoader;Ljava/lang/String;)Landroid/app/Application;", "Landroid/content/Intent;", "intent", "Landroid/app/Activity;", "instantiateActivity", "(Ljava/lang/ClassLoader;Ljava/lang/String;Landroid/content/Intent;)Landroid/app/Activity;", "Landroid/content/BroadcastReceiver;", "instantiateReceiver", "(Ljava/lang/ClassLoader;Ljava/lang/String;Landroid/content/Intent;)Landroid/content/BroadcastReceiver;", "Landroid/app/Service;", "instantiateService", "(Ljava/lang/ClassLoader;Ljava/lang/String;Landroid/content/Intent;)Landroid/app/Service;", "Landroid/content/ContentProvider;", "instantiateProvider", "(Ljava/lang/ClassLoader;Ljava/lang/String;)Landroid/content/ContentProvider;", "a", "Ldbxyzptlk/kL/u;", "b", "common_analytics_udcl_impl_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class RealAppStartupTimeFactory extends AppComponentFactory {
  public static final a b = new a(null);
  
  public static final long c = SystemClock.uptimeMillis();
  
  public final u a;
  
  public RealAppStartupTimeFactory() {
    this(null, 1, null);
  }
  
  public RealAppStartupTimeFactory(u paramu) {
    this.a = paramu;
  }
  
  public Activity instantiateActivity(ClassLoader paramClassLoader, String paramString, Intent paramIntent) {
    s.h(paramClassLoader, "cl");
    s.h(paramString, "className");
    return this.a.instantiateActivity(paramClassLoader, paramString, paramIntent);
  }
  
  public Application instantiateApplication(ClassLoader paramClassLoader, String paramString) {
    s.h(paramClassLoader, "cl");
    s.h(paramString, "className");
    return this.a.instantiateApplication(paramClassLoader, paramString);
  }
  
  public ClassLoader instantiateClassLoader(ClassLoader paramClassLoader, ApplicationInfo paramApplicationInfo) {
    s.h(paramClassLoader, "cl");
    s.h(paramApplicationInfo, "aInfo");
    return this.a.instantiateClassLoader(paramClassLoader, paramApplicationInfo);
  }
  
  public ContentProvider instantiateProvider(ClassLoader paramClassLoader, String paramString) {
    s.h(paramClassLoader, "cl");
    s.h(paramString, "className");
    return this.a.instantiateProvider(paramClassLoader, paramString);
  }
  
  public BroadcastReceiver instantiateReceiver(ClassLoader paramClassLoader, String paramString, Intent paramIntent) {
    s.h(paramClassLoader, "cl");
    s.h(paramString, "className");
    return this.a.instantiateReceiver(paramClassLoader, paramString, paramIntent);
  }
  
  public Service instantiateService(ClassLoader paramClassLoader, String paramString, Intent paramIntent) {
    s.h(paramClassLoader, "cl");
    s.h(paramString, "className");
    return this.a.instantiateService(paramClassLoader, paramString, paramIntent);
  }
  
  @Metadata(d1 = {"\000\024\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\t\n\002\b\005\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003R\027\020\005\032\0020\0048\006¢\006\f\n\004\b\005\020\006\032\004\b\007\020\b¨\006\t"}, d2 = {"Lcom/dropbox/common/udcl/impl/internal/instrumentation/appstartup/RealAppStartupTimeFactory$a;", "", "<init>", "()V", "", "factoryClassLoadMs", "J", "a", "()J", "common_analytics_udcl_impl_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
  public static final class a {
    public a() {}
    
    public final long a() {
      return RealAppStartupTimeFactory.a();
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\commo\\udcl\impl\internal\instrumentation\appstartup\RealAppStartupTimeFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */