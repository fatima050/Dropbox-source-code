package com.dropbox.common.udcl.impl.internal.instrumentation.appstartup;

import android.content.Context;
import android.os.SystemClock;
import dbxyzptlk.DI.s;
import dbxyzptlk.O4.b;
import dbxyzptlk.pI.D;
import dbxyzptlk.qI.s;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

@Metadata(d1 = {"\000$\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\003\n\002\020 \n\002\030\002\n\002\b\004\030\000 \r2\b\022\004\022\0020\0020\001:\001\rB\007¢\006\004\b\003\020\004J\027\020\007\032\0020\0022\006\020\006\032\0020\005H\026¢\006\004\b\007\020\bJ!\020\013\032\024\022\020\022\016\022\n\b\001\022\006\022\002\b\0030\0010\n0\tH\026¢\006\004\b\013\020\f¨\006\016"}, d2 = {"Lcom/dropbox/common/udcl/impl/internal/instrumentation/appstartup/AppStartupInitializer;", "Ldbxyzptlk/O4/b;", "Ldbxyzptlk/pI/D;", "<init>", "()V", "Landroid/content/Context;", "context", "c", "(Landroid/content/Context;)V", "", "Ljava/lang/Class;", "dependencies", "()Ljava/util/List;", "a", "common_analytics_udcl_impl_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class AppStartupInitializer implements b<D> {
  public static final a a = new a(null);
  
  public static final long b = SystemClock.uptimeMillis();
  
  public void c(Context paramContext) {
    s.h(paramContext, "context");
  }
  
  public List<Class<? extends b<?>>> dependencies() {
    return s.m();
  }
  
  @Metadata(d1 = {"\000\024\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\t\n\002\b\005\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003R\027\020\005\032\0020\0048\006¢\006\f\n\004\b\005\020\006\032\004\b\007\020\b¨\006\t"}, d2 = {"Lcom/dropbox/common/udcl/impl/internal/instrumentation/appstartup/AppStartupInitializer$a;", "", "<init>", "()V", "", "appStartupTime", "J", "a", "()J", "common_analytics_udcl_impl_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
  public static final class a {
    public a() {}
    
    public final long a() {
      return AppStartupInitializer.b();
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\commo\\udcl\impl\internal\instrumentation\appstartup\AppStartupInitializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */