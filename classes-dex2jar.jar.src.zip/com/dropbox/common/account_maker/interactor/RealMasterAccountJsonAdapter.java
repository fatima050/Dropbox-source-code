package com.dropbox.common.account_maker.interactor;

import com.squareup.moshi.JsonDataException;
import dbxyzptlk.Ce.a;
import dbxyzptlk.DI.s;
import dbxyzptlk.RG.f;
import dbxyzptlk.RG.i;
import dbxyzptlk.RG.n;
import dbxyzptlk.RG.q;
import dbxyzptlk.RG.t;
import dbxyzptlk.TG.c;
import dbxyzptlk.qI.Y;
import java.lang.reflect.Type;
import java.util.Map;
import kotlin.Metadata;

@Metadata(d1 = {"\000L\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\003\n\002\020\016\n\002\b\002\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\006\n\002\030\002\n\002\b\002\n\002\020$\n\002\b\003\030\0002\b\022\004\022\0020\0020\001B\017\022\006\020\004\032\0020\003¢\006\004\b\005\020\006J\017\020\b\032\0020\007H\026¢\006\004\b\b\020\tJ\027\020\f\032\0020\0022\006\020\013\032\0020\nH\026¢\006\004\b\f\020\rJ!\020\022\032\0020\0212\006\020\017\032\0020\0162\b\020\020\032\004\030\0010\002H\026¢\006\004\b\022\020\023R\024\020\027\032\0020\0248\002X\004¢\006\006\n\004\b\025\020\026R\032\020\032\032\b\022\004\022\0020\0070\0018\002X\004¢\006\006\n\004\b\030\020\031R\032\020\035\032\b\022\004\022\0020\0330\0018\002X\004¢\006\006\n\004\b\034\020\031R&\020 \032\024\022\020\022\016\022\004\022\0020\007\022\004\022\0020\0070\0360\0018\002X\004¢\006\006\n\004\b\037\020\031¨\006!"}, d2 = {"Lcom/dropbox/common/account_maker/interactor/RealMasterAccountJsonAdapter;", "Ldbxyzptlk/RG/f;", "Lcom/dropbox/common/account_maker/interactor/RealMasterAccount;", "Ldbxyzptlk/RG/q;", "moshi", "<init>", "(Ldbxyzptlk/RG/q;)V", "", "toString", "()Ljava/lang/String;", "Ldbxyzptlk/RG/i;", "reader", "j", "(Ldbxyzptlk/RG/i;)Lcom/dropbox/common/account_maker/interactor/RealMasterAccount;", "Ldbxyzptlk/RG/n;", "writer", "value_", "Ldbxyzptlk/pI/D;", "k", "(Ldbxyzptlk/RG/n;Lcom/dropbox/common/account_maker/interactor/RealMasterAccount;)V", "Ldbxyzptlk/RG/i$a;", "a", "Ldbxyzptlk/RG/i$a;", "options", "b", "Ldbxyzptlk/RG/f;", "stringAdapter", "Ldbxyzptlk/Ce/a;", "c", "accessTokenAdapter", "", "d", "mapOfStringStringAdapter", "common_auth_account_maker_impl_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class RealMasterAccountJsonAdapter extends f<RealMasterAccount> {
  public final i.a a;
  
  public final f<String> b;
  
  public final f<a> c;
  
  public final f<Map<String, String>> d;
  
  public RealMasterAccountJsonAdapter(q paramq) {
    i.a a1 = i.a.a(new String[] { "userId", "accessToken", "email", "displayName", "unknownFields" });
    s.g(a1, "of(...)");
    this.a = a1;
    f<String> f2 = paramq.f(String.class, Y.e(), "userId");
    s.g(f2, "adapter(...)");
    this.b = f2;
    f2 = paramq.f(a.class, Y.e(), "accessToken");
    s.g(f2, "adapter(...)");
    this.c = (f)f2;
    f<Map<String, String>> f1 = paramq.f(t.j(Map.class, new Type[] { String.class, String.class }), Y.e(), "unknownFields");
    s.g(f1, "adapter(...)");
    this.d = f1;
  }
  
  public RealMasterAccount j(i parami) {
    String str1;
    String str2;
    a a1;
    s.h(parami, "reader");
    parami.P();
    String str3 = null;
    Map<String, String> map4 = null;
    Map<String, String> map1 = map4;
    Map<String, String> map2 = map1;
    Map<String, String> map3 = map2;
    while (parami.c()) {
      int j = parami.o(this.a);
      if (j != -1) {
        if (j != 0) {
          if (j != 1) {
            if (j != 2) {
              if (j != 3) {
                if (j != 4)
                  continue; 
                map3 = (Map)this.d.b(parami);
                if (map3 != null)
                  continue; 
                jsonDataException = c.w("unknownFields", "unknownFields", parami);
                s.g(jsonDataException, "unexpectedNull(...)");
                throw jsonDataException;
              } 
              str2 = (String)this.b.b((i)jsonDataException);
              if (str2 != null)
                continue; 
              jsonDataException = c.w("displayName", "displayName", (i)jsonDataException);
              s.g(jsonDataException, "unexpectedNull(...)");
              throw jsonDataException;
            } 
            str1 = (String)this.b.b((i)jsonDataException);
            if (str1 != null)
              continue; 
            jsonDataException = c.w("email", "email", (i)jsonDataException);
            s.g(jsonDataException, "unexpectedNull(...)");
            throw jsonDataException;
          } 
          a1 = (a)this.c.b((i)jsonDataException);
          if (a1 != null)
            continue; 
          jsonDataException = c.w("accessToken", "accessToken", (i)jsonDataException);
          s.g(jsonDataException, "unexpectedNull(...)");
          throw jsonDataException;
        } 
        str3 = (String)this.b.b((i)jsonDataException);
        if (str3 != null)
          continue; 
        jsonDataException = c.w("userId", "userId", (i)jsonDataException);
        s.g(jsonDataException, "unexpectedNull(...)");
        throw jsonDataException;
      } 
      jsonDataException.s();
      jsonDataException.D1();
    } 
    jsonDataException.T();
    if (str3 != null) {
      if (a1 != null) {
        if (str1 != null) {
          if (str2 != null) {
            if (map3 != null)
              return new RealMasterAccount(str3, a1, str1, str2, map3); 
            jsonDataException = c.n("unknownFields", "unknownFields", (i)jsonDataException);
            s.g(jsonDataException, "missingProperty(...)");
            throw jsonDataException;
          } 
          jsonDataException = c.n("displayName", "displayName", (i)jsonDataException);
          s.g(jsonDataException, "missingProperty(...)");
          throw jsonDataException;
        } 
        jsonDataException = c.n("email", "email", (i)jsonDataException);
        s.g(jsonDataException, "missingProperty(...)");
        throw jsonDataException;
      } 
      jsonDataException = c.n("accessToken", "accessToken", (i)jsonDataException);
      s.g(jsonDataException, "missingProperty(...)");
      throw jsonDataException;
    } 
    JsonDataException jsonDataException = c.n("userId", "userId", (i)jsonDataException);
    s.g(jsonDataException, "missingProperty(...)");
    throw jsonDataException;
  }
  
  public void k(n paramn, RealMasterAccount paramRealMasterAccount) {
    s.h(paramn, "writer");
    if (paramRealMasterAccount != null) {
      paramn.c();
      paramn.h("userId");
      this.b.i(paramn, paramRealMasterAccount.l());
      paramn.h("accessToken");
      this.c.i(paramn, paramRealMasterAccount.b());
      paramn.h("email");
      this.b.i(paramn, paramRealMasterAccount.a());
      paramn.h("displayName");
      this.b.i(paramn, paramRealMasterAccount.r());
      paramn.h("unknownFields");
      this.d.i(paramn, paramRealMasterAccount.c());
      paramn.g();
      return;
    } 
    throw new NullPointerException("value_ was null! Wrap in .nullSafe() to write nullable values.");
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder(39);
    stringBuilder.append("GeneratedJsonAdapter(");
    stringBuilder.append("RealMasterAccount");
    stringBuilder.append(')');
    String str = stringBuilder.toString();
    s.g(str, "toString(...)");
    return str;
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\common\account_maker\interactor\RealMasterAccountJsonAdapter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */