package com.dropbox.common.account_maker.interactor;

import dbxyzptlk.Ce.a;
import dbxyzptlk.DI.s;
import dbxyzptlk.Pe.i;
import dbxyzptlk.RG.g;
import java.util.Map;
import kotlin.Metadata;

@g(generateAdapter = true)
@Metadata(d1 = {"\000B\n\002\030\002\n\002\030\002\n\002\020\016\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020$\n\002\b\005\n\002\020\b\n\002\b\002\n\002\020\000\n\000\n\002\020\013\n\002\b\017\b\b\030\0002\0020\001BG\022\n\020\004\032\0060\002j\002`\003\022\006\020\006\032\0020\005\022\n\020\b\032\0060\002j\002`\007\022\n\020\n\032\0060\002j\002`\t\022\022\020\f\032\016\022\004\022\0020\002\022\004\022\0020\0020\013¢\006\004\b\r\020\016J\020\020\017\032\0020\002HÖ\001¢\006\004\b\017\020\020J\020\020\022\032\0020\021HÖ\001¢\006\004\b\022\020\023J\032\020\027\032\0020\0262\b\020\025\032\004\030\0010\024HÖ\003¢\006\004\b\027\020\030R\036\020\004\032\0060\002j\002`\0038\026X\004¢\006\f\n\004\b\031\020\032\032\004\b\033\020\020R\032\020\006\032\0020\0058\026X\004¢\006\f\n\004\b\034\020\035\032\004\b\034\020\036R\036\020\b\032\0060\002j\002`\0078\026X\004¢\006\f\n\004\b\037\020\032\032\004\b\031\020\020R\036\020\n\032\0060\002j\002`\t8\026X\004¢\006\f\n\004\b \020\032\032\004\b!\020\020R&\020\f\032\016\022\004\022\0020\002\022\004\022\0020\0020\0138\026X\004¢\006\f\n\004\b\"\020#\032\004\b\037\020$¨\006%"}, d2 = {"Lcom/dropbox/common/account_maker/interactor/RealMasterAccount;", "Ldbxyzptlk/Pe/i;", "", "Lcom/dropbox/common/auth/account/UserId;", "userId", "Ldbxyzptlk/Ce/a;", "accessToken", "Lcom/dropbox/common/auth/account/EmailAddress;", "email", "Lcom/dropbox/common/auth/account/DisplayName;", "displayName", "", "unknownFields", "<init>", "(Ljava/lang/String;Ldbxyzptlk/Ce/a;Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;)V", "toString", "()Ljava/lang/String;", "", "hashCode", "()I", "", "other", "", "equals", "(Ljava/lang/Object;)Z", "a", "Ljava/lang/String;", "l", "b", "Ldbxyzptlk/Ce/a;", "()Ldbxyzptlk/Ce/a;", "c", "d", "r", "e", "Ljava/util/Map;", "()Ljava/util/Map;", "common_auth_account_maker_impl_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class RealMasterAccount implements i {
  public final String a;
  
  public final a b;
  
  public final String c;
  
  public final String d;
  
  public final Map<String, String> e;
  
  public RealMasterAccount(String paramString1, a parama, String paramString2, String paramString3, Map<String, String> paramMap) {
    this.a = paramString1;
    this.b = parama;
    this.c = paramString2;
    this.d = paramString3;
    this.e = paramMap;
  }
  
  public String a() {
    return this.c;
  }
  
  public a b() {
    return this.b;
  }
  
  public Map<String, String> c() {
    return this.e;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof RealMasterAccount))
      return false; 
    paramObject = paramObject;
    return !s.c(this.a, ((RealMasterAccount)paramObject).a) ? false : (!s.c(this.b, ((RealMasterAccount)paramObject).b) ? false : (!s.c(this.c, ((RealMasterAccount)paramObject).c) ? false : (!s.c(this.d, ((RealMasterAccount)paramObject).d) ? false : (!!s.c(this.e, ((RealMasterAccount)paramObject).e)))));
  }
  
  public int hashCode() {
    return (((this.a.hashCode() * 31 + this.b.hashCode()) * 31 + this.c.hashCode()) * 31 + this.d.hashCode()) * 31 + this.e.hashCode();
  }
  
  public String l() {
    return this.a;
  }
  
  public String r() {
    return this.d;
  }
  
  public String toString() {
    String str2 = this.a;
    a a1 = this.b;
    String str1 = this.c;
    String str3 = this.d;
    Map<String, String> map = this.e;
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("RealMasterAccount(userId=");
    stringBuilder.append(str2);
    stringBuilder.append(", accessToken=");
    stringBuilder.append(a1);
    stringBuilder.append(", email=");
    stringBuilder.append(str1);
    stringBuilder.append(", displayName=");
    stringBuilder.append(str3);
    stringBuilder.append(", unknownFields=");
    stringBuilder.append(map);
    stringBuilder.append(")");
    return stringBuilder.toString();
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\common\account_maker\interactor\RealMasterAccount.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */