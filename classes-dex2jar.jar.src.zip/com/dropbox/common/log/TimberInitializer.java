package com.dropbox.common.log;

import android.content.Context;
import com.dropbox.common.android.crash_reporting.CrashReportingStartup;
import dbxyzptlk.DI.s;
import dbxyzptlk.O4.b;
import dbxyzptlk.Ph.c;
import dbxyzptlk.kf.d;
import dbxyzptlk.pI.D;
import dbxyzptlk.qI.r;
import dbxyzptlk.sL.a;
import dbxyzptlk.yj.c;
import java.util.List;
import java.util.Set;
import kotlin.Metadata;

@Metadata(d1 = {"\0000\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\003\n\002\020 \n\002\030\002\n\002\b\002\n\002\020\"\n\002\030\002\n\002\b\b\030\0002\b\022\004\022\0020\0020\001B\007¢\006\004\b\003\020\004J\027\020\007\032\0020\0022\006\020\006\032\0020\005H\026¢\006\004\b\007\020\bJ!\020\013\032\024\022\020\022\016\022\n\b\001\022\006\022\002\b\0030\0010\n0\tH\026¢\006\004\b\013\020\fR(\020\025\032\b\022\004\022\0020\0160\r8\006@\006X.¢\006\022\n\004\b\017\020\020\032\004\b\021\020\022\"\004\b\023\020\024¨\006\026"}, d2 = {"Lcom/dropbox/common/log/TimberInitializer;", "Ldbxyzptlk/O4/b;", "Ldbxyzptlk/pI/D;", "<init>", "()V", "Landroid/content/Context;", "context", "b", "(Landroid/content/Context;)V", "", "Ljava/lang/Class;", "dependencies", "()Ljava/util/List;", "", "Ldbxyzptlk/sL/a$c;", "a", "Ljava/util/Set;", "c", "()Ljava/util/Set;", "d", "(Ljava/util/Set;)V", "timberTrees", "common_log_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class TimberInitializer implements b<D> {
  public Set<a.c> a;
  
  public void b(Context paramContext) {
    s.h(paramContext, "context");
    if (d.a(paramContext, this)) {
      a.a.t((a.c)new a.a());
    } else {
      ((c)c.b(paramContext, c.class, c.e(paramContext), false)).f0(this);
      for (a.c c : c())
        a.a.t(c); 
    } 
  }
  
  public final Set<a.c> c() {
    Set<a.c> set = this.a;
    if (set != null)
      return set; 
    s.u("timberTrees");
    return null;
  }
  
  public final void d(Set<a.c> paramSet) {
    s.h(paramSet, "<set-?>");
    this.a = paramSet;
  }
  
  public List<Class<? extends b<?>>> dependencies() {
    return r.e(CrashReportingStartup.class);
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\common\log\TimberInitializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */