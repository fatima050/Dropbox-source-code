package com.dropbox.common.legacy_api.exception;

import java.util.Locale;
import java.util.Map;
import okhttp3.Response;

public class DropboxHttpException extends DropboxException {
  private static final long serialVersionUID = 1L;
  
  public a a;
  
  public int b;
  
  public Integer c;
  
  public String d;
  
  public String e;
  
  public String f;
  
  public String g;
  
  public Map<String, Object> h;
  
  public DropboxHttpException(Response paramResponse) {
    if (paramResponse != null) {
      this.b = paramResponse.code();
      this.d = paramResponse.message();
      this.e = paramResponse.header("server");
      this.f = paramResponse.header("location");
      this.g = paramResponse.header("X-Dropbox-Request-Id");
      String str = paramResponse.header("Retry-After");
      if (str != null) {
        double d = Double.valueOf(str).doubleValue();
        if (d >= 0.0D && d <= 2.147483647E9D) {
          this.c = Integer.valueOf((int)d);
        } else {
          throw new NumberFormatException("Retry-After value out of int range.");
        } 
      } 
    } 
  }
  
  public DropboxHttpException(Response paramResponse, Object paramObject) {
    this(paramResponse);
    if (paramObject != null && paramObject instanceof Map) {
      Map<String, Object> map = (Map)paramObject;
      this.h = map;
      this.a = new a(map);
    } 
  }
  
  public static boolean e(int paramInt, String paramString) {
    if (paramInt == 302 && paramString != null) {
      paramInt = paramString.indexOf("://");
      if (paramInt > -1) {
        paramString = paramString.substring(paramInt + 3);
        paramInt = paramString.indexOf("/");
        if (paramInt > -1 && paramString.substring(0, paramInt).toLowerCase(Locale.US).contains("dropbox.com"))
          return true; 
      } 
    } else if (paramInt == 304) {
      return true;
    } 
    return false;
  }
  
  public static boolean f(Response paramResponse) {
    return e(paramResponse.code(), paramResponse.header("location"));
  }
  
  public int a() {
    return this.b;
  }
  
  public String b(String paramString) {
    a a1 = this.a;
    String str = paramString;
    if (a1 != null) {
      String str1 = a1.b;
      str = paramString;
      if (str1 != null) {
        str = paramString;
        if (str1.length() > 0)
          str = this.a.b; 
      } 
    } 
    return str;
  }
  
  public String c() {
    return b(null);
  }
  
  public String d() {
    a a1 = this.a;
    if (a1 != null) {
      String str = a1.c;
      if (str != null && str.length() > 0)
        return this.a.c; 
    } 
    return null;
  }
  
  public String getMessage() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(this.b);
    stringBuilder.append(" ");
    stringBuilder.append(this.d);
    String str2 = stringBuilder.toString();
    String str1 = str2;
    if (this.a != null) {
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append(str2);
      stringBuilder1.append(" (");
      stringBuilder1.append(this.a.a);
      stringBuilder1.append(")");
      str1 = stringBuilder1.toString();
    } 
    return str1;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(getClass().getSimpleName());
    stringBuilder.append(": ");
    stringBuilder.append(getMessage());
    return stringBuilder.toString();
  }
  
  class DropboxHttpException {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\common\legacy_api\exception\DropboxHttpException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */