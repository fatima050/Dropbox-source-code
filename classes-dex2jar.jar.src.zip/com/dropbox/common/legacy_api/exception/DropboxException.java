package com.dropbox.common.legacy_api.exception;

public class DropboxException extends Exception {
  private static final long serialVersionUID = 1L;
  
  public DropboxException() {}
  
  public DropboxException(String paramString) {
    super(paramString);
  }
  
  public DropboxException(String paramString, Throwable paramThrowable) {
    super(paramString, paramThrowable);
  }
  
  public DropboxException(Throwable paramThrowable) {
    super(paramThrowable);
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\common\legacy_api\exception\DropboxException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */