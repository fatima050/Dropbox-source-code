package com.dropbox.common.legacy_api.exception;

import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

@Metadata(d1 = {"\000\020\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\003\030\0002\0060\001j\002`\002B\027\022\020\b\002\020\003\032\n\030\0010\001j\004\030\001`\002¢\006\002\020\004¨\006\005"}, d2 = {"Lcom/dropbox/common/legacy_api/exception/ApiNetworkException;", "Ljava/lang/Exception;", "Lkotlin/Exception;", "e", "(Ljava/lang/Exception;)V", "common_legacy_api_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class ApiNetworkException extends Exception {
  public ApiNetworkException() {
    this(null, 1, null);
  }
  
  public ApiNetworkException(Exception paramException) {
    super(paramException);
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\common\legacy_api\exception\ApiNetworkException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */