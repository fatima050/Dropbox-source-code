package com.dropbox.common.legacy_api.exception;

import okhttp3.Response;

public class DropboxServerException extends DropboxHttpException {
  private static final long serialVersionUID = 1L;
  
  public DropboxServerException(Response paramResponse) {
    super(paramResponse);
  }
  
  public DropboxServerException(Response paramResponse, Object paramObject) {
    super(paramResponse, paramObject);
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\common\legacy_api\exception\DropboxServerException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */