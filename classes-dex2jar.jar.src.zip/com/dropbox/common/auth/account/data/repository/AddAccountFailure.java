package com.dropbox.common.auth.account.data.repository;

import kotlin.Metadata;

@Metadata(d1 = {"\000\020\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\002\030\0002\0060\001j\002`\002B\005¢\006\002\020\003¨\006\004"}, d2 = {"Lcom/dropbox/common/auth/account/data/repository/AddAccountFailure;", "Ljava/lang/Exception;", "Lkotlin/Exception;", "()V", "common_auth_account_impl_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class AddAccountFailure extends Exception {}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\common\auth\account\data\repository\AddAccountFailure.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */