package com.dropbox.common.skeleton.core;

import android.app.Application;
import android.content.Context;
import dbxyzptlk.Aj.f;
import dbxyzptlk.DI.s;
import dbxyzptlk.DI.u;
import dbxyzptlk.Fq.o;
import dbxyzptlk.af.c;
import dbxyzptlk.fh.d;
import dbxyzptlk.fh.e;
import dbxyzptlk.pI.j;
import dbxyzptlk.pI.k;
import dbxyzptlk.qI.A;
import dbxyzptlk.qI.o;
import dbxyzptlk.yj.c;
import dbxyzptlk.yj.i;
import dbxyzptlk.yj.o;
import dbxyzptlk.yj.t;
import dbxyzptlk.yj.u;
import dbxyzptlk.zj.s;
import io.sentry.android.core.performance.e;
import java.util.Set;
import kotlin.Metadata;

@Metadata(d1 = {"\000l\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\020\016\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\020\"\n\002\030\002\n\002\b\006\n\002\030\002\n\002\b\007\n\002\030\002\n\002\b\013\n\002\030\002\n\002\b\004\n\002\020\000\n\002\b\003\n\002\020\021\n\002\030\002\n\002\b\004\b&\030\0002\0020\0012\0020\002B\007¢\006\004\b\003\020\004J\017\020\006\032\0020\005H&¢\006\004\b\006\020\007J\r\020\t\032\0020\b¢\006\004\b\t\020\nJ\027\020\016\032\004\030\0010\r2\006\020\f\032\0020\013¢\006\004\b\016\020\017J\017\020\021\032\0020\020H\026¢\006\004\b\021\020\004R(\020\031\032\b\022\004\022\0020\0230\0228\026@\026X.¢\006\022\n\004\b\016\020\024\032\004\b\025\020\026\"\004\b\027\020\030R\"\020!\032\0020\0328\006@\006X.¢\006\022\n\004\b\033\020\034\032\004\b\035\020\036\"\004\b\037\020 R\"\020)\032\0020\"8\006@\006X.¢\006\022\n\004\b#\020$\032\004\b%\020&\"\004\b'\020(R\033\020-\032\0020\0058VX\002¢\006\f\n\004\b*\020+\032\004\b,\020\007R\033\0202\032\0020.8BX\002¢\006\f\n\004\b/\020+\032\004\b0\0201R\024\0206\032\002038VX\004¢\006\006\032\004\b4\0205R\032\020;\032\b\022\004\022\00208078BX\004¢\006\006\032\004\b9\020:¨\006<"}, d2 = {"Lcom/dropbox/common/skeleton/core/BaseSkeletonApplication;", "Ldbxyzptlk/yj/o;", "Landroid/app/Application;", "<init>", "()V", "Ldbxyzptlk/zj/s;", "B", "()Ldbxyzptlk/zj/s;", "Ldbxyzptlk/Fq/a;", "A", "()Ldbxyzptlk/Fq/a;", "", "userId", "Ldbxyzptlk/Fq/o;", "a", "(Ljava/lang/String;)Ldbxyzptlk/Fq/o;", "Ldbxyzptlk/pI/D;", "onCreate", "", "Ldbxyzptlk/af/c;", "Ljava/util/Set;", "k", "()Ljava/util/Set;", "setActivityCallbackFactories", "(Ljava/util/Set;)V", "activityCallbackFactories", "Ldbxyzptlk/yj/u;", "b", "Ldbxyzptlk/yj/u;", "F", "()Ldbxyzptlk/yj/u;", "setUserComponentManager", "(Ldbxyzptlk/yj/u;)V", "userComponentManager", "Ldbxyzptlk/fh/e;", "c", "Ldbxyzptlk/fh/e;", "D", "()Ldbxyzptlk/fh/e;", "setDevSettingComponent", "(Ldbxyzptlk/fh/e;)V", "devSettingComponent", "d", "Ldbxyzptlk/pI/j;", "E", "skeletonServices", "Lcom/dropbox/common/skeleton/core/a;", "e", "C", "()Lcom/dropbox/common/skeleton/core/a;", "appComponent", "", "D3", "()Ljava/lang/Object;", "daggerComponent", "", "Ldbxyzptlk/yj/t;", "G", "()[Ldbxyzptlk/yj/t;", "userComponents", "common_skeleton_core_impl_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
public abstract class BaseSkeletonApplication extends Application implements o {
  public Set<c> a;
  
  public u b;
  
  public e c;
  
  public final j d = k.a(new b(this));
  
  public final j e = k.a(new a(this));
  
  public final dbxyzptlk.Fq.a A() {
    return C();
  }
  
  public abstract s B();
  
  public final a C() {
    return (a)this.e.getValue();
  }
  
  public final e D() {
    e e1 = this.c;
    if (e1 != null)
      return e1; 
    s.u("devSettingComponent");
    return null;
  }
  
  public Object D3() {
    return A.P0(o.O0((Object[])G()), C());
  }
  
  public s E() {
    return (s)this.d.getValue();
  }
  
  public final u F() {
    u u1 = this.b;
    if (u1 != null)
      return u1; 
    s.u("userComponentManager");
    return null;
  }
  
  public final t[] G() {
    t[] arrayOfT;
    if (this.b != null) {
      arrayOfT = F().a();
    } else {
      arrayOfT = new t[0];
    } 
    return arrayOfT;
  }
  
  public final o a(String paramString) {
    s.h(paramString, "userId");
    return (o)F().b(paramString);
  }
  
  public Set<c> k() {
    Set<c> set = this.a;
    if (set != null)
      return set; 
    s.u("activityCallbackFactories");
    return null;
  }
  
  public void onCreate() {
    e.r(this);
    super.onCreate();
    a a = C();
    if (a != null) {
      f.a(((dbxyzptlk.Aj.a)a).R0());
      ((i)c.b((Context)this, i.class, c.e((Context)this), false)).h1(this);
      d.a().set(D().b());
      e.s(this);
      return;
    } 
    NullPointerException nullPointerException = new NullPointerException("null cannot be cast to non-null type com.dropbox.common.skeleton.initializers.AppInitializerProvider");
    e.s(this);
    throw nullPointerException;
  }
  
  @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"Lcom/dropbox/common/skeleton/core/a;", "b", "()Lcom/dropbox/common/skeleton/core/a;"}, k = 3, mv = {1, 9, 0})
  public static final class a extends u implements dbxyzptlk.CI.a<a> {
    public final BaseSkeletonApplication f;
    
    public a(BaseSkeletonApplication param1BaseSkeletonApplication) {
      super(0);
    }
    
    public final a b() {
      s s = this.f.E();
      if (s != null)
        return ((a.a)s).a(); 
      throw new NullPointerException("null cannot be cast to non-null type com.dropbox.common.skeleton.core.AppComponent.AppParentComponent");
    }
  }
  
  @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"Ldbxyzptlk/zj/s;", "b", "()Ldbxyzptlk/zj/s;"}, k = 3, mv = {1, 9, 0})
  public static final class b extends u implements dbxyzptlk.CI.a<s> {
    public final BaseSkeletonApplication f;
    
    public b(BaseSkeletonApplication param1BaseSkeletonApplication) {
      super(0);
    }
    
    public final s b() {
      return this.f.B();
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\common\skeleton\core\BaseSkeletonApplication.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */