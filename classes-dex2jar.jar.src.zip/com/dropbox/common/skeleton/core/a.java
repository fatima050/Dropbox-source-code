package com.dropbox.common.skeleton.core;

import com.squareup.anvil.annotations.ContributesSubcomponent;
import com.squareup.anvil.annotations.ContributesTo;
import dbxyzptlk.Cj.d;
import dbxyzptlk.Fq.a;
import dbxyzptlk.Jh.d;
import dbxyzptlk.Jh.h;
import dbxyzptlk.yj.u;
import kotlin.Metadata;

@ContributesSubcomponent(parentScope = h.class, scope = d.class)
@Metadata(d1 = {"\000\030\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\004\bg\030\0002\0020\001:\001\bJ\017\020\003\032\0020\002H&¢\006\004\b\003\020\004J\017\020\006\032\0020\005H&¢\006\004\b\006\020\007ø\001\000\002\006\n\004\b!0\001¨\006\tÀ\006\001"}, d2 = {"Lcom/dropbox/common/skeleton/core/a;", "Ldbxyzptlk/Fq/a;", "Ldbxyzptlk/Cj/d;", "Q0", "()Ldbxyzptlk/Cj/d;", "Ldbxyzptlk/yj/u;", "y", "()Ldbxyzptlk/yj/u;", "a", "common_skeleton_core_api_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
public interface a extends a {
  d Q0();
  
  u y();
  
  @ContributesTo(scope = h.class)
  @Metadata(d1 = {"\000\020\n\002\030\002\n\002\020\000\n\002\030\002\n\002\b\003\bg\030\0002\0020\001J\017\020\003\032\0020\002H&¢\006\004\b\003\020\004ø\001\000\002\006\n\004\b!0\001¨\006\005À\006\001"}, d2 = {"Lcom/dropbox/common/skeleton/core/a$a;", "", "Lcom/dropbox/common/skeleton/core/a;", "a", "()Lcom/dropbox/common/skeleton/core/a;", "common_skeleton_core_api_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
  public static interface a {
    a a();
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\common\skeleton\core\a.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */