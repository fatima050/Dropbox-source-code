package com.dropbox.common.stormcrow_gen;

import com.dropbox.base.oxygen.annotations.JniGen;

@JniGen
public class StormcrowNoauthVariantBase {
  final String mFeatureName;
  
  final String mVariantName;
  
  public StormcrowNoauthVariantBase(String paramString1, String paramString2) {
    this.mFeatureName = paramString1;
    this.mVariantName = paramString2;
  }
  
  public String getFeatureName() {
    return this.mFeatureName;
  }
  
  public String getVariantName() {
    return this.mVariantName;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("StormcrowNoauthVariantBase{mFeatureName=");
    stringBuilder.append(this.mFeatureName);
    stringBuilder.append(",mVariantName=");
    stringBuilder.append(this.mVariantName);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\common\stormcrow_gen\StormcrowNoauthVariantBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */