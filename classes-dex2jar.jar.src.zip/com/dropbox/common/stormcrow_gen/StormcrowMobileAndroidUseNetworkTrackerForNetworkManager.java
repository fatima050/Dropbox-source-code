package com.dropbox.common.stormcrow_gen;

import com.dropbox.base.oxygen.annotations.JniGen;
import dbxyzptlk.Ej.b;

@JniGen
public final class StormcrowMobileAndroidUseNetworkTrackerForNetworkManager {
  @JniGen
  public static final b VENABLED = new b("mobile_android_use_network_tracker_for_network_manager", "ENABLED");
  
  public String toString() {
    return "StormcrowMobileAndroidUseNetworkTrackerForNetworkManager{}";
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\common\stormcrow_gen\StormcrowMobileAndroidUseNetworkTrackerForNetworkManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */