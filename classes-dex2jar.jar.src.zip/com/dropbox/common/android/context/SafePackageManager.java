package com.dropbox.common.android.context;

import android.annotation.TargetApi;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.drawable.Drawable;
import dbxyzptlk.jf.D;
import java.util.List;

public class SafePackageManager {
  public final PackageManager a;
  
  public SafePackageManager(PackageManager paramPackageManager) {
    this.a = paramPackageManager;
  }
  
  public static boolean j(RuntimeException paramRuntimeException) {
    return "Package manager has died".equals(paramRuntimeException.getMessage());
  }
  
  public static <T> T m(a<T> parama) throws PackageManagerCrashedException {
    try {
      return (T)parama.call();
    } catch (RuntimeException runtimeException) {
      throw n(runtimeException);
    } 
  }
  
  public static RuntimeException n(RuntimeException paramRuntimeException) throws PackageManagerCrashedException {
    if (j(paramRuntimeException))
      throw new PackageManagerCrashedException(paramRuntimeException); 
    throw paramRuntimeException;
  }
  
  public int a(String paramString1, String paramString2) throws PackageManagerCrashedException {
    try {
      return this.a.checkSignatures(paramString1, paramString2);
    } catch (RuntimeException runtimeException) {
      throw n(runtimeException);
    } 
  }
  
  public Drawable b(ApplicationInfo paramApplicationInfo) throws PackageManagerCrashedException {
    try {
      return this.a.getApplicationIcon(paramApplicationInfo);
    } catch (RuntimeException runtimeException) {
      throw n(runtimeException);
    } 
  }
  
  public CharSequence c(ApplicationInfo paramApplicationInfo) throws PackageManagerCrashedException {
    try {
      return this.a.getApplicationLabel(paramApplicationInfo);
    } catch (RuntimeException runtimeException) {
      throw n(runtimeException);
    } 
  }
  
  public List<PackageInfo> d(int paramInt) throws PackageManagerCrashedException {
    try {
      return this.a.getInstalledPackages(paramInt);
    } catch (RuntimeException runtimeException) {
      throw n(runtimeException);
    } 
  }
  
  public String e(String paramString) throws PackageManagerCrashedException {
    try {
      return this.a.getInstallerPackageName(paramString);
    } catch (RuntimeException runtimeException) {
      throw n(runtimeException);
    } 
  }
  
  public Intent f(String paramString) throws PackageManagerCrashedException {
    try {
      return this.a.getLaunchIntentForPackage(paramString);
    } catch (RuntimeException runtimeException) {
      throw n(runtimeException);
    } 
  }
  
  public PackageInfo g(String paramString, int paramInt) throws PackageManagerCrashedException, PackageManager.NameNotFoundException {
    try {
      return this.a.getPackageInfo(paramString, paramInt);
    } catch (RuntimeException runtimeException) {
      throw n(runtimeException);
    } 
  }
  
  public String[] h(int paramInt) throws PackageManagerCrashedException {
    try {
      return this.a.getPackagesForUid(paramInt);
    } catch (RuntimeException runtimeException) {
      throw n(runtimeException);
    } 
  }
  
  @TargetApi(30)
  public boolean i() throws PackageManagerCrashedException {
    try {
      return D.a(this.a);
    } catch (RuntimeException runtimeException) {
      throw n(runtimeException);
    } 
  }
  
  public boolean k(String paramString1, String paramString2) throws PackageManagerCrashedException {
    try {
      return this.a.isPermissionRevokedByPolicy(paramString1, paramString2);
    } catch (RuntimeException runtimeException) {
      throw n(runtimeException);
    } 
  }
  
  public List<ResolveInfo> l(Intent paramIntent, int paramInt) throws PackageManagerCrashedException {
    try {
      return this.a.queryIntentActivities(paramIntent, paramInt);
    } catch (RuntimeException runtimeException) {
      throw n(runtimeException);
    } 
  }
  
  public static class PackageManagerCrashedException extends Exception {
    private static final long serialVersionUID = -1922930648047843593L;
    
    public PackageManagerCrashedException(RuntimeException param1RuntimeException) {
      super(param1RuntimeException);
    }
  }
  
  class SafePackageManager {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\common\android\context\SafePackageManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */