package com.dropbox.common.android.context;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import dbxyzptlk.DI.s;
import dbxyzptlk.Ec.e;
import dbxyzptlk.Ec.g;
import dbxyzptlk.jf.i;
import kotlin.Metadata;

@Metadata(d1 = {"\000 \n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\003\b&\030\0002\0020\001B\007¢\006\004\b\002\020\003J\037\020\t\032\0020\b2\006\020\005\032\0020\0042\006\020\007\032\0020\006H\027¢\006\004\b\t\020\n¨\006\013"}, d2 = {"Lcom/dropbox/common/android/context/BaseBroadcastReceiver;", "Landroid/content/BroadcastReceiver;", "<init>", "()V", "Landroid/content/Context;", "context", "Landroid/content/Intent;", "intent", "Ldbxyzptlk/pI/D;", "onReceive", "(Landroid/content/Context;Landroid/content/Intent;)V", "common_context_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
public abstract class BaseBroadcastReceiver extends BroadcastReceiver {
  public void onReceive(Context paramContext, Intent paramIntent) {
    s.h(paramContext, "context");
    s.h(paramIntent, "intent");
    g g = e.a(paramContext);
    (new i()).k(String.valueOf(paramIntent.getAction())).g(g);
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\common\android\context\BaseBroadcastReceiver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */