package com.dropbox.common.android.context;

import android.content.Context;
import dbxyzptlk.DI.s;
import dbxyzptlk.jf.w;
import dbxyzptlk.jf.z;
import dbxyzptlk.oB.c;
import dbxyzptlk.sL.a;
import kotlin.Metadata;

@Metadata(d1 = {"\000\036\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\003\n\002\020\b\n\000\n\002\020\013\n\002\b\005\b\007\030\0002\0020\001B\023\b\007\022\b\b\001\020\003\032\0020\002¢\006\004\b\004\020\005J\031\020\t\032\0020\b2\b\020\007\032\004\030\0010\006H\026¢\006\004\b\t\020\nR\024\020\003\032\0020\0028\002X\004¢\006\006\n\004\b\013\020\f¨\006\r"}, d2 = {"Lcom/dropbox/common/android/context/b;", "Ldbxyzptlk/jf/w;", "Landroid/content/Context;", "context", "<init>", "(Landroid/content/Context;)V", "", "minApkVersion", "", "b", "(Ljava/lang/Integer;)Z", "a", "Landroid/content/Context;", "common_context_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class b implements w {
  public final Context a;
  
  public b(Context paramContext) {
    this.a = paramContext;
  }
  
  public static final Boolean d(Integer paramInteger, b paramb) {
    s.h(paramb, "this$0");
    c c = c.p();
    if (c != null) {
      int i;
      boolean bool;
      s.g(c, "checkNotNull(...)");
      if (paramInteger == null) {
        i = c.i(paramb.a);
      } else {
        i = c.j(paramb.a, paramInteger.intValue());
      } 
      if (i == 0) {
        bool = true;
      } else {
        bool = false;
      } 
      return Boolean.valueOf(bool);
    } 
    throw new IllegalStateException("Required value was null.");
  }
  
  public boolean b(Integer paramInteger) {
    try {
      z z = new z();
      this(paramInteger, this);
      paramInteger = SafePackageManager.m((SafePackageManager.a<Integer>)z);
      s.g(paramInteger, "runCatchingPackageManagerDeath(...)");
      return ((Boolean)paramInteger).booleanValue();
    } catch (PackageManagerCrashedException|NullPointerException packageManagerCrashedException) {
    
    } catch (Exception exception) {
      if (!(exception.getCause() instanceof android.os.DeadObjectException))
        a.a.e(exception); 
    } 
    return false;
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\common\android\context\b.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */