package com.dropbox.common.android.context;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import dbxyzptlk.DI.s;
import dbxyzptlk.V1.b;
import dbxyzptlk.eH.C;
import dbxyzptlk.eH.w;
import dbxyzptlk.eH.x;
import dbxyzptlk.jf.A;
import dbxyzptlk.jf.B;
import dbxyzptlk.jf.C;
import dbxyzptlk.lH.f;
import io.reactivex.Observable;
import java.util.LinkedHashMap;
import java.util.Map;
import kotlin.Metadata;

@Metadata(d1 = {"\000:\n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\020\016\n\000\n\002\030\002\n\002\b\004\n\002\020%\n\002\b\004\030\0002\0020\001B\031\022\006\020\003\032\0020\002\022\b\b\001\020\005\032\0020\004¢\006\004\b\006\020\007J\027\020\013\032\0020\n2\006\020\t\032\0020\bH\026¢\006\004\b\013\020\fJ\035\020\020\032\b\022\004\022\0020\b0\0172\006\020\016\032\0020\rH\026¢\006\004\b\020\020\021R\024\020\003\032\0020\0028\002X\004¢\006\006\n\004\b\020\020\022R\024\020\005\032\0020\0048\002X\004¢\006\006\n\004\b\013\020\023R&\020\027\032\024\022\004\022\0020\r\022\n\022\b\022\004\022\0020\b0\0170\0248\002X\004¢\006\006\n\004\b\025\020\026¨\006\030"}, d2 = {"Lcom/dropbox/common/android/context/RealRemoteBroadcastManager;", "Ldbxyzptlk/jf/C;", "Landroid/content/Context;", "context", "Ldbxyzptlk/eH/C;", "mainThreadScheduler", "<init>", "(Landroid/content/Context;Ldbxyzptlk/eH/C;)V", "Landroid/content/Intent;", "intent", "Ldbxyzptlk/pI/D;", "b", "(Landroid/content/Intent;)V", "", "action", "Lio/reactivex/Observable;", "a", "(Ljava/lang/String;)Lio/reactivex/Observable;", "Landroid/content/Context;", "Ldbxyzptlk/eH/C;", "", "c", "Ljava/util/Map;", "activeObservers", "common_context_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class RealRemoteBroadcastManager implements C {
  public final Context a;
  
  public final C b;
  
  public final Map<String, Observable<Intent>> c;
  
  public RealRemoteBroadcastManager(Context paramContext, C paramC) {
    this.a = paramContext;
    this.b = paramC;
    this.c = new LinkedHashMap<>();
  }
  
  public static final void e(RealRemoteBroadcastManager paramRealRemoteBroadcastManager, String paramString, w<Intent> paramw) {
    s.h(paramRealRemoteBroadcastManager, "this$0");
    s.h(paramString, "$action");
    s.h(paramw, "emitter");
    RealRemoteBroadcastManager$observeBroadcast$1$1$receiver$1 realRemoteBroadcastManager$observeBroadcast$1$1$receiver$1 = new RealRemoteBroadcastManager$observeBroadcast$1$1$receiver$1(paramw);
    b.l(paramRealRemoteBroadcastManager.a, realRemoteBroadcastManager$observeBroadcast$1$1$receiver$1, new IntentFilter(paramString), 2);
    paramw.a((f)new B(paramRealRemoteBroadcastManager, paramString, realRemoteBroadcastManager$observeBroadcast$1$1$receiver$1));
  }
  
  public static final void f(RealRemoteBroadcastManager paramRealRemoteBroadcastManager, String paramString, RealRemoteBroadcastManager$observeBroadcast$1$1$receiver$1 paramRealRemoteBroadcastManager$observeBroadcast$1$1$receiver$1) {
    s.h(paramRealRemoteBroadcastManager, "this$0");
    s.h(paramString, "$action");
    s.h(paramRealRemoteBroadcastManager$observeBroadcast$1$1$receiver$1, "$receiver");
    paramRealRemoteBroadcastManager.c.remove(paramString);
    paramRealRemoteBroadcastManager.a.unregisterReceiver(paramRealRemoteBroadcastManager$observeBroadcast$1$1$receiver$1);
  }
  
  public Observable<Intent> a(String paramString) {
    s.h(paramString, "action");
    Map<String, Observable<Intent>> map = this.c;
    Observable<Intent> observable2 = (Observable<Intent>)map.get(paramString);
    Observable<Intent> observable1 = observable2;
    if (observable2 == null) {
      observable1 = Observable.create((x)new A(this, paramString)).share().subscribeOn(this.b).unsubscribeOn(this.b);
      s.g(observable1, "unsubscribeOn(...)");
      map.put(paramString, observable1);
    } 
    return observable1;
  }
  
  public void b(Intent paramIntent) {
    s.h(paramIntent, "intent");
    this.a.sendBroadcast(paramIntent);
  }
  
  @Metadata(d1 = {"\000\035\n\000\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\003*\001\000\b\n\030\0002\0020\001J\037\020\007\032\0020\0062\006\020\003\032\0020\0022\006\020\005\032\0020\004H\026¢\006\004\b\007\020\b¨\006\t"}, d2 = {"com/dropbox/common/android/context/RealRemoteBroadcastManager$observeBroadcast$1$1$receiver$1", "Landroid/content/BroadcastReceiver;", "Landroid/content/Context;", "context", "Landroid/content/Intent;", "intent", "Ldbxyzptlk/pI/D;", "onReceive", "(Landroid/content/Context;Landroid/content/Intent;)V", "common_context_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
  public static final class RealRemoteBroadcastManager$observeBroadcast$1$1$receiver$1 extends BroadcastReceiver {
    public final w<Intent> a;
    
    public RealRemoteBroadcastManager$observeBroadcast$1$1$receiver$1(w<Intent> param1w) {}
    
    public void onReceive(Context param1Context, Intent param1Intent) {
      s.h(param1Context, "context");
      s.h(param1Intent, "intent");
      this.a.onNext(param1Intent);
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\common\android\context\RealRemoteBroadcastManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */