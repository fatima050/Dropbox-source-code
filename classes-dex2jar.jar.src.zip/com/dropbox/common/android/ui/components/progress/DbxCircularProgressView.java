package com.dropbox.common.android.ui.components.progress;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ProgressBar;
import dbxyzptlk.sf.a;

public abstract class DbxCircularProgressView extends ProgressBar {
  public DbxCircularProgressView(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    setIndeterminateDrawable((Drawable)new a(paramContext, paramAttributeSet, (View)this));
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\common\androi\\ui\components\progress\DbxCircularProgressView.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */