package com.dropbox.common.android.ui.components.progress;

import android.content.Context;
import android.util.AttributeSet;
import dbxyzptlk.Df.f;
import dbxyzptlk.rf.k;

public final class DbxCircularProgressViewSmallBlue extends DbxCircularProgressView {
  public static final int a = k.DbxIndeterminantProgress_Small_Blue;
  
  public DbxCircularProgressViewSmallBlue(Context paramContext) {
    super(f.a(paramContext, new int[] { a }), null);
  }
  
  public DbxCircularProgressViewSmallBlue(Context paramContext, AttributeSet paramAttributeSet) {
    super(f.a(paramContext, new int[] { a }), paramAttributeSet);
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\common\androi\\ui\components\progress\DbxCircularProgressViewSmallBlue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */