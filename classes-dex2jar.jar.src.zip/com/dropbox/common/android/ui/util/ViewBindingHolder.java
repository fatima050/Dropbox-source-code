package com.dropbox.common.android.ui.util;

import androidx.fragment.app.Fragment;
import dbxyzptlk.CI.l;
import dbxyzptlk.DI.s;
import dbxyzptlk.U2.h;
import dbxyzptlk.pI.D;
import kotlin.Metadata;

@Metadata(d1 = {"\000&\n\002\030\002\n\002\030\002\n\000\n\002\020\000\n\002\b\002\n\002\030\002\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\007\bf\030\000*\b\b\000\020\002*\0020\0012\0020\003J\017\020\004\032\0028\000H\026¢\006\004\b\004\020\005J#\020\t\032\0020\0072\022\020\b\032\016\022\004\022\0028\000\022\004\022\0020\0070\006H\026¢\006\004\b\t\020\nJ\033\020\r\032\0020\007*\0020\0132\006\020\f\032\0028\000H\026¢\006\004\b\r\020\016R\036\020\f\032\004\030\0018\0008&@&X¦\016¢\006\f\032\004\b\017\020\005\"\004\b\020\020\021ø\001\000\002\006\n\004\b!0\001¨\006\022À\006\001"}, d2 = {"Lcom/dropbox/common/android/ui/util/ViewBindingHolder;", "Ldbxyzptlk/V4/a;", "B", "", "g3", "()Ldbxyzptlk/V4/a;", "Lkotlin/Function1;", "Ldbxyzptlk/pI/D;", "block", "C3", "(Ldbxyzptlk/CI/l;)V", "Landroidx/fragment/app/Fragment;", "binding", "n1", "(Landroidx/fragment/app/Fragment;Ldbxyzptlk/V4/a;)V", "s0", "I3", "(Ldbxyzptlk/V4/a;)V", "common_ui_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
public interface ViewBindingHolder<B extends dbxyzptlk.V4.a> {
  default void C3(l<? super B, D> paraml) {
    s.h(paraml, "block");
    B b = s0();
    if (b != null) {
      paraml.invoke(b);
      D d = D.a;
    } 
  }
  
  void I3(B paramB);
  
  default B g3() {
    B b = s0();
    if (b != null)
      return b; 
    throw new IllegalStateException("Required value was null.");
  }
  
  default void n1(Fragment paramFragment, B paramB) {
    s.h(paramFragment, "<this>");
    s.h(paramB, "binding");
    I3(paramB);
    paramFragment.getViewLifecycleOwner().getLifecycle().a((h)new Object(this));
  }
  
  B s0();
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\common\androi\\u\\util\ViewBindingHolder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */