package com.dropbox.common.android.ui.widgets;

import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.widget.TextView;
import androidx.annotation.Keep;
import androidx.appcompat.app.a;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import dbxyzptlk.DI.s;
import dbxyzptlk.Df.g;
import dbxyzptlk.rf.g;
import dbxyzptlk.rf.i;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

@Metadata(d1 = {"\000\032\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\005\030\000 \t2\0020\001:\001\nB\007¢\006\004\b\002\020\003J\031\020\007\032\0020\0062\b\020\005\032\004\030\0010\004H\026¢\006\004\b\007\020\b¨\006\013"}, d2 = {"Lcom/dropbox/common/android/ui/widgets/BasicProgressDialogFragment;", "Landroidx/fragment/app/DialogFragment;", "<init>", "()V", "Landroid/os/Bundle;", "savedInstanceState", "Landroid/app/Dialog;", "onCreateDialog", "(Landroid/os/Bundle;)Landroid/app/Dialog;", "s", "Companion", "common_ui_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class BasicProgressDialogFragment extends DialogFragment {
  public static final Companion s = new Companion(null);
  
  public Dialog onCreateDialog(Bundle paramBundle) {
    View view = LayoutInflater.from(getContext()).inflate(i.basic_progress_dialog, null, false);
    TextView textView = (TextView)view.findViewById(g.message);
    Bundle bundle = getArguments();
    if (bundle != null) {
      String str = bundle.getString("MESSAGE");
      if (str != null)
        textView.setText(str); 
    } 
    a a = (new g((Context)getActivity())).create();
    s.g(a, "create(...)");
    a.setView(view, 0, 0, 0, 0);
    Window window = a.getWindow();
    if (window != null)
      window.setBackgroundDrawable((Drawable)new ColorDrawable(0)); 
    return (Dialog)a;
  }
  
  @Metadata(d1 = {"\0002\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\016\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\004\n\002\020\013\n\002\b\005\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\025\020\007\032\0020\0062\006\020\005\032\0020\004¢\006\004\b\007\020\bJ\035\020\r\032\0020\f2\006\020\n\032\0020\t2\006\020\013\032\0020\006¢\006\004\b\r\020\016J\025\020\017\032\0020\f2\006\020\n\032\0020\t¢\006\004\b\017\020\020J\025\020\022\032\0020\0212\006\020\n\032\0020\t¢\006\004\b\022\020\023R\024\020\024\032\0020\0048\002XT¢\006\006\n\004\b\024\020\025¨\006\026"}, d2 = {"Lcom/dropbox/common/android/ui/widgets/BasicProgressDialogFragment$Companion;", "", "<init>", "()V", "", "message", "Lcom/dropbox/common/android/ui/widgets/BasicProgressDialogFragment;", "newInstance", "(Ljava/lang/String;)Lcom/dropbox/common/android/ui/widgets/BasicProgressDialogFragment;", "Landroidx/fragment/app/FragmentManager;", "manager", "fragment", "Ldbxyzptlk/pI/D;", "show", "(Landroidx/fragment/app/FragmentManager;Lcom/dropbox/common/android/ui/widgets/BasicProgressDialogFragment;)V", "dismiss", "(Landroidx/fragment/app/FragmentManager;)V", "", "isShowing", "(Landroidx/fragment/app/FragmentManager;)Z", "MESSAGE", "Ljava/lang/String;", "common_ui_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
  @Keep
  public static final class Companion {
    private Companion() {}
    
    public final void dismiss(FragmentManager param1FragmentManager) {
      s.h(param1FragmentManager, "manager");
      Fragment fragment = param1FragmentManager.m0(BasicProgressDialogFragment.class.getName());
      if (fragment != null)
        param1FragmentManager.q().t(fragment).l(); 
    }
    
    public final boolean isShowing(FragmentManager param1FragmentManager) {
      boolean bool;
      s.h(param1FragmentManager, "manager");
      if (param1FragmentManager.m0(BasicProgressDialogFragment.class.getName()) != null) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    public final BasicProgressDialogFragment newInstance(String param1String) {
      s.h(param1String, "message");
      BasicProgressDialogFragment basicProgressDialogFragment = new BasicProgressDialogFragment();
      Bundle bundle = new Bundle();
      bundle.putString("MESSAGE", param1String);
      basicProgressDialogFragment.setArguments(bundle);
      basicProgressDialogFragment.setCancelable(false);
      return basicProgressDialogFragment;
    }
    
    public final void show(FragmentManager param1FragmentManager, BasicProgressDialogFragment param1BasicProgressDialogFragment) {
      s.h(param1FragmentManager, "manager");
      s.h(param1BasicProgressDialogFragment, "fragment");
      param1BasicProgressDialogFragment.show(param1FragmentManager, BasicProgressDialogFragment.class.getName());
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\common\androi\\ui\widgets\BasicProgressDialogFragment.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */