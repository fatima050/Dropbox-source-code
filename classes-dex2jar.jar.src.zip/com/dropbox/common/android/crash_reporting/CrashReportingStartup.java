package com.dropbox.common.android.crash_reporting;

import android.content.Context;
import dbxyzptlk.DI.s;
import dbxyzptlk.O4.b;
import dbxyzptlk.kf.b;
import dbxyzptlk.kf.c;
import dbxyzptlk.kf.d;
import dbxyzptlk.pI.D;
import dbxyzptlk.qI.s;
import dbxyzptlk.yj.c;
import java.util.List;
import kotlin.Metadata;

@Metadata(d1 = {"\000,\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\003\n\002\020 \n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\b\030\0002\b\022\004\022\0020\0020\001B\007¢\006\004\b\003\020\004J\027\020\007\032\0020\0022\006\020\006\032\0020\005H\026¢\006\004\b\007\020\bJ!\020\013\032\024\022\020\022\016\022\n\b\001\022\006\022\002\b\0030\0010\n0\tH\026¢\006\004\b\013\020\fR\"\020\024\032\0020\r8\006@\006X.¢\006\022\n\004\b\016\020\017\032\004\b\020\020\021\"\004\b\022\020\023¨\006\025"}, d2 = {"Lcom/dropbox/common/android/crash_reporting/CrashReportingStartup;", "Ldbxyzptlk/O4/b;", "Ldbxyzptlk/pI/D;", "<init>", "()V", "Landroid/content/Context;", "context", "b", "(Landroid/content/Context;)V", "", "Ljava/lang/Class;", "dependencies", "()Ljava/util/List;", "Ldbxyzptlk/kf/c;", "a", "Ldbxyzptlk/kf/c;", "c", "()Ldbxyzptlk/kf/c;", "d", "(Ldbxyzptlk/kf/c;)V", "crashReportingSetup", "common_crash_reporting_core_impl_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class CrashReportingStartup implements b<D> {
  public c a;
  
  public void b(Context paramContext) {
    s.h(paramContext, "context");
    if (d.a(paramContext, this))
      return; 
    ((b)c.b(paramContext, b.class, c.e(paramContext), false)).N(this);
    c().a();
  }
  
  public final c c() {
    c c1 = this.a;
    if (c1 != null)
      return c1; 
    s.u("crashReportingSetup");
    return null;
  }
  
  public final void d(c paramc) {
    s.h(paramc, "<set-?>");
    this.a = paramc;
  }
  
  public List<Class<? extends b<?>>> dependencies() {
    return s.m();
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\common\android\crash_reporting\CrashReportingStartup.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */