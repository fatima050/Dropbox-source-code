package com.dropbox.common.android.crash_reporting;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.Application;
import android.os.Bundle;
import androidx.lifecycle.DefaultLifecycleObserver;
import androidx.lifecycle.LifecycleOwner;
import com.squareup.anvil.annotations.ContributesMultibinding;
import dbxyzptlk.Aj.b;
import dbxyzptlk.DI.s;
import dbxyzptlk.Jh.d;
import dbxyzptlk.U2.h;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

@ContributesMultibinding(boundType = b.class, scope = d.class)
@Metadata(d1 = {"\000B\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\020\n\002\020\b\n\002\b\t\b\007\030\000 #2\0020\0012\0020\0022\0020\003:\001%B#\b\007\022\006\020\005\032\0020\004\022\006\020\007\032\0020\006\022\b\b\001\020\t\032\0020\b¢\006\004\b\n\020\013J\017\020\r\032\0020\fH\026¢\006\004\b\r\020\016J!\020\023\032\0020\f2\006\020\020\032\0020\0172\b\020\022\032\004\030\0010\021H\026¢\006\004\b\023\020\024J\027\020\025\032\0020\f2\006\020\020\032\0020\017H\026¢\006\004\b\025\020\026J\027\020\027\032\0020\f2\006\020\020\032\0020\017H\026¢\006\004\b\027\020\026J\027\020\030\032\0020\f2\006\020\020\032\0020\017H\026¢\006\004\b\030\020\026J\027\020\031\032\0020\f2\006\020\020\032\0020\017H\026¢\006\004\b\031\020\026J\037\020\033\032\0020\f2\006\020\020\032\0020\0172\006\020\032\032\0020\021H\026¢\006\004\b\033\020\024J\037\020\034\032\0020\f2\006\020\020\032\0020\0172\006\020\032\032\0020\021H\026¢\006\004\b\034\020\024J\027\020\035\032\0020\f2\006\020\020\032\0020\017H\026¢\006\004\b\035\020\026J\027\020\037\032\0020\f2\006\020\036\032\0020\bH\026¢\006\004\b\037\020 J\027\020!\032\0020\f2\006\020\036\032\0020\bH\026¢\006\004\b!\020 J\017\020#\032\0020\"H\002¢\006\004\b#\020$R\024\020\005\032\0020\0048\002X\004¢\006\006\n\004\b%\020&R\024\020\007\032\0020\0068\002X\004¢\006\006\n\004\b'\020(R\024\020\t\032\0020\b8\002X\004¢\006\006\n\004\b)\020*¨\006+"}, d2 = {"Lcom/dropbox/common/android/crash_reporting/RealLifecycleTaggerInitializer;", "Ldbxyzptlk/Aj/b;", "Landroid/app/Application$ActivityLifecycleCallbacks;", "Landroidx/lifecycle/DefaultLifecycleObserver;", "Landroid/app/Application;", "application", "Ldbxyzptlk/kf/a;", "crashReporterManager", "Landroidx/lifecycle/LifecycleOwner;", "lifecycleOwner", "<init>", "(Landroid/app/Application;Ldbxyzptlk/kf/a;Landroidx/lifecycle/LifecycleOwner;)V", "Ldbxyzptlk/pI/D;", "run", "()V", "Landroid/app/Activity;", "activity", "Landroid/os/Bundle;", "savedInstanceState", "onActivityCreated", "(Landroid/app/Activity;Landroid/os/Bundle;)V", "onActivityStarted", "(Landroid/app/Activity;)V", "onActivityResumed", "onActivityPaused", "onActivityStopped", "outState", "onActivityPreSaveInstanceState", "onActivitySaveInstanceState", "onActivityDestroyed", "owner", "onStart", "(Landroidx/lifecycle/LifecycleOwner;)V", "onStop", "", "d", "()I", "a", "Landroid/app/Application;", "b", "Ldbxyzptlk/kf/a;", "c", "Landroidx/lifecycle/LifecycleOwner;", "common_crash_reporting_core_impl_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class RealLifecycleTaggerInitializer implements b, Application.ActivityLifecycleCallbacks, DefaultLifecycleObserver {
  public static final a d = new a(null);
  
  public final Application a;
  
  public final dbxyzptlk.kf.a b;
  
  public final LifecycleOwner c;
  
  public RealLifecycleTaggerInitializer(Application paramApplication, dbxyzptlk.kf.a parama, LifecycleOwner paramLifecycleOwner) {
    this.a = paramApplication;
    this.b = parama;
    this.c = paramLifecycleOwner;
  }
  
  public final int d() {
    byte b1;
    try {
      ActivityManager.RunningAppProcessInfo runningAppProcessInfo = new ActivityManager.RunningAppProcessInfo();
      this();
      ActivityManager.getMyMemoryState(runningAppProcessInfo);
      b1 = runningAppProcessInfo.importance;
    } catch (RuntimeException runtimeException) {
      dbxyzptlk.sL.a.a.b(runtimeException);
      b1 = -1;
    } 
    return b1;
  }
  
  public void onActivityCreated(Activity paramActivity, Bundle paramBundle) {
    s.h(paramActivity, "activity");
  }
  
  public void onActivityDestroyed(Activity paramActivity) {
    s.h(paramActivity, "activity");
  }
  
  public void onActivityPaused(Activity paramActivity) {
    s.h(paramActivity, "activity");
    dbxyzptlk.kf.a a1 = this.b;
    String str = paramActivity.getClass().getSimpleName();
    s.g(str, "getSimpleName(...)");
    a1.i("lifecycle.pausedActivity", str);
  }
  
  public void onActivityPreSaveInstanceState(Activity paramActivity, Bundle paramBundle) {
    s.h(paramActivity, "activity");
    s.h(paramBundle, "outState");
    dbxyzptlk.kf.a a1 = this.b;
    String str = paramActivity.getClass().getSimpleName();
    s.g(str, "getSimpleName(...)");
    a1.i("lifecycle.saveInstanceStateActivity", str);
  }
  
  public void onActivityResumed(Activity paramActivity) {
    s.h(paramActivity, "activity");
    dbxyzptlk.kf.a a1 = this.b;
    String str = paramActivity.getClass().getSimpleName();
    s.g(str, "getSimpleName(...)");
    a1.i("lifecycle.resumedActivity", str);
  }
  
  public void onActivitySaveInstanceState(Activity paramActivity, Bundle paramBundle) {
    s.h(paramActivity, "activity");
    s.h(paramBundle, "outState");
  }
  
  public void onActivityStarted(Activity paramActivity) {
    s.h(paramActivity, "activity");
  }
  
  public void onActivityStopped(Activity paramActivity) {
    s.h(paramActivity, "activity");
  }
  
  public void onStart(LifecycleOwner paramLifecycleOwner) {
    s.h(paramLifecycleOwner, "owner");
    this.b.i("lifecycle.isInForeground", "true");
  }
  
  public void onStop(LifecycleOwner paramLifecycleOwner) {
    s.h(paramLifecycleOwner, "owner");
    this.b.i("lifecycle.isInForeground", "false");
  }
  
  public void run() {
    this.a.registerActivityLifecycleCallbacks(this);
    this.c.getLifecycle().a((h)this);
    this.b.i("lifecycle.isInForeground", "false");
    this.b.i("lifecycle.processImportanceAtStart", String.valueOf(d()));
  }
  
  @Metadata(d1 = {"\000\024\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\016\n\002\b\004\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003R\024\020\005\032\0020\0048\000XT¢\006\006\n\004\b\005\020\006R\024\020\007\032\0020\0048\000XT¢\006\006\n\004\b\007\020\006¨\006\b"}, d2 = {"Lcom/dropbox/common/android/crash_reporting/RealLifecycleTaggerInitializer$a;", "", "<init>", "()V", "", "IS_IN_FOREGROUND", "Ljava/lang/String;", "PROCESS_IMPORTANCE_AT_START", "common_crash_reporting_core_impl_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
  public static final class a {
    public a() {}
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\common\android\crash_reporting\RealLifecycleTaggerInitializer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */