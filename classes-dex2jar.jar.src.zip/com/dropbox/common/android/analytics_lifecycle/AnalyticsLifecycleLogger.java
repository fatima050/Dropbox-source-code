package com.dropbox.common.android.analytics_lifecycle;

import androidx.lifecycle.DefaultLifecycleObserver;
import androidx.lifecycle.LifecycleOwner;
import dbxyzptlk.DI.s;
import dbxyzptlk.Ec.g;
import dbxyzptlk.Ec.m;
import dbxyzptlk.U2.h;
import dbxyzptlk.hf.e;
import dbxyzptlk.ye.C0;
import kotlin.Metadata;

@Metadata(d1 = {"\000B\n\002\030\002\n\002\030\002\n\002\020\016\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\n\n\002\030\002\n\002\b\003\b\020\030\0002\0020\001B'\022\006\020\003\032\0020\002\022\006\020\005\032\0020\004\022\006\020\007\032\0020\006\022\006\020\t\032\0020\b¢\006\004\b\n\020\013J\027\020\016\032\0020\r2\006\020\f\032\0020\004H\026¢\006\004\b\016\020\017J\027\020\020\032\0020\r2\006\020\f\032\0020\004H\026¢\006\004\b\020\020\017J\023\020\022\032\0020\r*\0020\021H\004¢\006\004\b\022\020\023J\027\020\024\032\0020\r2\006\020\f\032\0020\004H\026¢\006\004\b\024\020\017J#\020\030\032\0020\0212\006\020\025\032\0020\0022\n\b\002\020\027\032\004\030\0010\026H\004¢\006\004\b\030\020\031J\027\020\033\032\0020\0212\006\020\032\032\0020\021H\026¢\006\004\b\033\020\034R\024\020\003\032\0020\0028\002X\004¢\006\006\n\004\b\033\020\035R\024\020\005\032\0020\0048\002X\004¢\006\006\n\004\b\030\020\036R\024\020\007\032\0020\0068\002X\004¢\006\006\n\004\b\037\020 R\024\020#\032\0020!8\002X\004¢\006\006\n\004\b\022\020\"¨\006$"}, d2 = {"Lcom/dropbox/common/android/analytics_lifecycle/AnalyticsLifecycleLogger;", "Landroidx/lifecycle/DefaultLifecycleObserver;", "", "eventPrefix", "Landroidx/lifecycle/LifecycleOwner;", "lifecycleOwner", "Ldbxyzptlk/Ec/g;", "analyticsLogger", "Ldbxyzptlk/ye/C0;", "systemTimeSource", "<init>", "(Ljava/lang/String;Landroidx/lifecycle/LifecycleOwner;Ldbxyzptlk/Ec/g;Ldbxyzptlk/ye/C0;)V", "owner", "Ldbxyzptlk/pI/D;", "onStart", "(Landroidx/lifecycle/LifecycleOwner;)V", "onStop", "Ldbxyzptlk/Ec/m;", "d", "(Ldbxyzptlk/Ec/m;)V", "onDestroy", "eventName", "Ldbxyzptlk/Ec/m$b;", "tag", "b", "(Ljava/lang/String;Ldbxyzptlk/Ec/m$b;)Ldbxyzptlk/Ec/m;", "event", "a", "(Ldbxyzptlk/Ec/m;)Ldbxyzptlk/Ec/m;", "Ljava/lang/String;", "Landroidx/lifecycle/LifecycleOwner;", "c", "Ldbxyzptlk/Ec/g;", "Ldbxyzptlk/hf/e;", "Ldbxyzptlk/hf/e;", "screenViewTimer", "common_analytics_lifecycle_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
public class AnalyticsLifecycleLogger implements DefaultLifecycleObserver {
  public final String a;
  
  public final LifecycleOwner b;
  
  public final g c;
  
  public final e d;
  
  public AnalyticsLifecycleLogger(String paramString, LifecycleOwner paramLifecycleOwner, g paramg, C0 paramC0) {
    this.a = paramString;
    this.b = paramLifecycleOwner;
    this.c = paramg;
    this.d = new e(paramC0);
  }
  
  public m a(m paramm) {
    s.h(paramm, "event");
    return paramm;
  }
  
  public final m b(String paramString, m.b paramb) {
    m m;
    s.h(paramString, "eventName");
    if (paramb != null) {
      m = m.b(paramString, paramb);
    } else {
      m = m.a((String)m);
    } 
    s.e(m);
    return a(m);
  }
  
  public final void d(m paramm) {
    s.h(paramm, "<this>");
    paramm.r(this.b).m("id", this.b.hashCode()).i(this.c);
  }
  
  public void onDestroy(LifecycleOwner paramLifecycleOwner) {
    s.h(paramLifecycleOwner, "owner");
    this.b.getLifecycle().d((h)this);
  }
  
  public void onStart(LifecycleOwner paramLifecycleOwner) {
    s.h(paramLifecycleOwner, "owner");
    this.d.b();
    String str = this.a;
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(str);
    stringBuilder.append("screen.view");
    d(b(stringBuilder.toString(), m.b.ACTIVE));
  }
  
  public void onStop(LifecycleOwner paramLifecycleOwner) {
    s.h(paramLifecycleOwner, "owner");
    long l = this.d.a();
    String str = this.a;
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(str);
    stringBuilder.append("screen.hide");
    m m = c(this, stringBuilder.toString(), null, 2, null).m("duration_ms", l);
    s.g(m, "set(...)");
    d(m);
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\common\android\analytics_lifecycle\AnalyticsLifecycleLogger.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */