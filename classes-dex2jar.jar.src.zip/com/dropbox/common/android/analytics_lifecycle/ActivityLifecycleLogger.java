package com.dropbox.common.android.analytics_lifecycle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.LifecycleOwner;
import dbxyzptlk.CI.l;
import dbxyzptlk.DI.s;
import dbxyzptlk.DI.u;
import dbxyzptlk.Ec.g;
import dbxyzptlk.Ec.m;
import dbxyzptlk.hf.e;
import dbxyzptlk.qI.A;
import dbxyzptlk.ye.C0;
import java.util.ArrayList;
import java.util.List;
import kotlin.Metadata;

@Metadata(d1 = {"\000@\n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020\013\n\002\b\003\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\007\n\002\030\002\n\002\b\004\b\000\030\0002\0020\001B'\022\006\020\003\032\0020\002\022\006\020\005\032\0020\004\022\006\020\007\032\0020\006\022\006\020\t\032\0020\b¢\006\004\b\n\020\013J\027\020\017\032\0020\0162\006\020\r\032\0020\fH\026¢\006\004\b\017\020\020J\027\020\021\032\0020\0162\006\020\r\032\0020\fH\026¢\006\004\b\021\020\020J\027\020\024\032\0020\0222\006\020\023\032\0020\022H\026¢\006\004\b\024\020\025R\024\020\003\032\0020\0028\002X\004¢\006\006\n\004\b\026\020\027R\024\020\t\032\0020\b8\002X\004¢\006\006\n\004\b\030\020\031R\024\020\035\032\0020\0328\002X\004¢\006\006\n\004\b\033\020\034¨\006\036"}, d2 = {"Lcom/dropbox/common/android/analytics_lifecycle/ActivityLifecycleLogger;", "Lcom/dropbox/common/android/analytics_lifecycle/AnalyticsLifecycleLogger;", "Landroidx/fragment/app/FragmentActivity;", "activity", "Ldbxyzptlk/Ec/g;", "analyticsLogger", "Ldbxyzptlk/ye/C0;", "systemTimeSource", "", "isInEmmMode", "<init>", "(Landroidx/fragment/app/FragmentActivity;Ldbxyzptlk/Ec/g;Ldbxyzptlk/ye/C0;Z)V", "Landroidx/lifecycle/LifecycleOwner;", "owner", "Ldbxyzptlk/pI/D;", "onResume", "(Landroidx/lifecycle/LifecycleOwner;)V", "onPause", "Ldbxyzptlk/Ec/m;", "event", "a", "(Ldbxyzptlk/Ec/m;)Ldbxyzptlk/Ec/m;", "e", "Landroidx/fragment/app/FragmentActivity;", "f", "Z", "Ldbxyzptlk/hf/e;", "g", "Ldbxyzptlk/hf/e;", "resumeTimer", "common_analytics_lifecycle_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class ActivityLifecycleLogger extends AnalyticsLifecycleLogger {
  public final FragmentActivity e;
  
  public final boolean f;
  
  public final e g;
  
  public ActivityLifecycleLogger(FragmentActivity paramFragmentActivity, g paramg, C0 paramC0, boolean paramBoolean) {
    super("", (LifecycleOwner)paramFragmentActivity, paramg, paramC0);
    this.e = paramFragmentActivity;
    this.f = paramBoolean;
    this.g = new e(paramC0);
  }
  
  public m a(m paramm) {
    s.h(paramm, "event");
    List<Fragment> list1 = this.e.getSupportFragmentManager().C0();
    s.g(list1, "getFragments(...)");
    List<Fragment> list2 = list1;
    list1 = new ArrayList();
    for (Fragment fragment : list2) {
      if (((Fragment)fragment).isAdded())
        list1.add(fragment); 
    } 
    String str = A.z0(list1, null, null, null, 0, null, a.f, 31, null);
    paramm = paramm.n("is_emm", Boolean.valueOf(this.f)).o("screen_components", str);
    s.g(paramm, "set(...)");
    return paramm;
  }
  
  public void onPause(LifecycleOwner paramLifecycleOwner) {
    s.h(paramLifecycleOwner, "owner");
    long l = this.g.a();
    m m = b("act.pause", m.b.DEBUG).m("resumed_duration_millis", l).m("duration_ms", l);
    s.g(m, "set(...)");
    d(m);
  }
  
  public void onResume(LifecycleOwner paramLifecycleOwner) {
    s.h(paramLifecycleOwner, "owner");
    this.g.b();
    d(b("act.resume", m.b.ACTIVE));
  }
  
  @Metadata(d1 = {"\000\020\n\002\030\002\n\002\b\002\n\002\020\r\n\002\b\002\020\004\032\0020\0032\016\020\002\032\n \001*\004\030\0010\0000\000H\n¢\006\004\b\004\020\005"}, d2 = {"Landroidx/fragment/app/Fragment;", "kotlin.jvm.PlatformType", "it", "", "a", "(Landroidx/fragment/app/Fragment;)Ljava/lang/CharSequence;"}, k = 3, mv = {1, 9, 0})
  public static final class a extends u implements l<Fragment, CharSequence> {
    public static final a f = new a();
    
    public a() {
      super(1);
    }
    
    public final CharSequence a(Fragment param1Fragment) {
      String str = param1Fragment.getClass().getSimpleName();
      s.g(str, "getSimpleName(...)");
      return str;
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\common\android\analytics_lifecycle\ActivityLifecycleLogger.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */