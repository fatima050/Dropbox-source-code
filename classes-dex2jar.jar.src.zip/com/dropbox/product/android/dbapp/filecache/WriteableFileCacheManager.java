package com.dropbox.product.android.dbapp.filecache;

import dbxyzptlk.It.e;
import dbxyzptlk.It.g;
import java.io.File;
import java.io.IOException;
import kotlin.Metadata;

@Metadata(d1 = {"\000&\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\013\n\002\b\002\n\002\030\002\n\002\b\007\bf\030\000*\b\b\000\020\002*\0020\0012\b\022\004\022\0028\0000\003:\001\020J5\020\013\032\b\022\004\022\0028\0000\n2\006\020\005\032\0020\0042\006\020\006\032\0028\0002\006\020\b\032\0020\0072\006\020\t\032\0020\007H&¢\006\004\b\013\020\fJ\027\020\016\032\0020\0072\006\020\r\032\0028\000H&¢\006\004\b\016\020\017ø\001\000\002\006\n\004\b!0\001¨\006\021À\006\001"}, d2 = {"Lcom/dropbox/product/android/dbapp/filecache/WriteableFileCacheManager;", "Lcom/dropbox/product/dbapp/path/Path;", "P", "Ldbxyzptlk/It/e;", "Ljava/io/File;", "source", "destPath", "", "overwrite", "copy", "Ldbxyzptlk/It/g;", "d", "(Ljava/io/File;Lcom/dropbox/product/dbapp/path/Path;ZZ)Ldbxyzptlk/It/g;", "path", "b", "(Lcom/dropbox/product/dbapp/path/Path;)Z", "FileNotOverwritableException", "dbapp_filecache_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
public interface WriteableFileCacheManager<P extends com.dropbox.product.dbapp.path.Path> extends e<P> {
  boolean b(P paramP);
  
  g<P> d(File paramFile, P paramP, boolean paramBoolean1, boolean paramBoolean2) throws IOException;
  
  class WriteableFileCacheManager {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\product\android\dbapp\filecache\WriteableFileCacheManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */