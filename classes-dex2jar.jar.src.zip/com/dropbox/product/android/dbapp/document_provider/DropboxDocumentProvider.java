package com.dropbox.product.android.dbapp.document_provider;

import android.annotation.SuppressLint;
import android.content.ContentProvider;
import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.database.Cursor;
import android.graphics.Point;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.provider.DocumentsProvider;
import dbxyzptlk.CI.a;
import dbxyzptlk.DI.s;
import dbxyzptlk.DI.u;
import dbxyzptlk.Ec.g;
import dbxyzptlk.YJ.u;
import dbxyzptlk.Zs.a;
import dbxyzptlk.Zs.f;
import dbxyzptlk.Zs.j;
import dbxyzptlk.Zs.s;
import dbxyzptlk.pI.j;
import dbxyzptlk.pI.k;
import dbxyzptlk.sL.a;
import io.sentry.android.core.performance.e;
import kotlin.Metadata;

@Metadata(d1 = {"\000l\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\013\n\002\b\002\n\002\020\021\n\002\020\016\n\000\n\002\030\002\n\002\b\b\n\002\030\002\n\000\n\002\030\002\n\002\b\004\n\002\030\002\n\000\n\002\030\002\n\002\b\b\n\002\030\002\n\002\b\004\n\002\030\002\n\000\n\002\030\002\n\002\b\005\n\002\030\002\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\006\030\0002\0020\001B\007¢\006\004\b\002\020\003J\017\020\005\032\0020\004H\026¢\006\004\b\005\020\006J\037\020\013\032\0020\n2\016\020\t\032\n\022\004\022\0020\b\030\0010\007H\027¢\006\004\b\013\020\fJ1\020\017\032\0020\n2\006\020\r\032\0020\b2\016\020\t\032\n\022\004\022\0020\b\030\0010\0072\b\020\016\032\004\030\0010\bH\027¢\006\004\b\017\020\020J+\020\026\032\004\030\0010\0252\006\020\021\032\0020\b2\006\020\022\032\0020\b2\b\020\024\032\004\030\0010\023H\027¢\006\004\b\026\020\027J'\020\030\032\0020\n2\006\020\021\032\0020\b2\016\020\t\032\n\022\004\022\0020\b\030\0010\007H\027¢\006\004\b\030\020\031J-\020\035\032\004\030\0010\0342\006\020\021\032\0020\b2\b\020\033\032\004\030\0010\0322\b\020\024\032\004\030\0010\023H\027¢\006\004\b\035\020\036J)\020!\032\0020\b2\006\020\r\032\0020\b2\b\020\037\032\004\030\0010\b2\006\020 \032\0020\bH\027¢\006\004\b!\020\"J\037\020#\032\0020\b2\006\020\021\032\0020\b2\006\020 \032\0020\bH\027¢\006\004\b#\020$J\027\020&\032\0020%2\006\020\021\032\0020\bH\027¢\006\004\b&\020'JC\020.\032\0028\000\"\004\b\000\020(2\n\b\002\020\021\032\004\030\0010\b2\006\020)\032\0020\b2\n\b\002\020+\032\004\030\0010*2\f\020-\032\b\022\004\022\0028\0000,H\002¢\006\004\b.\020/J#\0200\032\0020%2\b\020+\032\004\030\0010*2\b\020\021\032\004\030\0010\bH\002¢\006\004\b0\0201J/\0205\032\0020%2\n\0204\032\00602j\002`32\b\020+\032\004\030\0010*2\b\020\021\032\004\030\0010\bH\002¢\006\004\b5\0206R\033\020<\032\002078BX\002¢\006\f\n\004\b8\0209\032\004\b:\020;¨\006="}, d2 = {"Lcom/dropbox/product/android/dbapp/document_provider/DropboxDocumentProvider;", "Landroid/provider/DocumentsProvider;", "<init>", "()V", "", "onCreate", "()Z", "", "", "projection", "Landroid/database/Cursor;", "queryRoots", "([Ljava/lang/String;)Landroid/database/Cursor;", "parentDocumentId", "sortOrder", "queryChildDocuments", "(Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;", "documentId", "mode", "Landroid/os/CancellationSignal;", "signal", "Landroid/os/ParcelFileDescriptor;", "openDocument", "(Ljava/lang/String;Ljava/lang/String;Landroid/os/CancellationSignal;)Landroid/os/ParcelFileDescriptor;", "queryDocument", "(Ljava/lang/String;[Ljava/lang/String;)Landroid/database/Cursor;", "Landroid/graphics/Point;", "sizeHint", "Landroid/content/res/AssetFileDescriptor;", "openDocumentThumbnail", "(Ljava/lang/String;Landroid/graphics/Point;Landroid/os/CancellationSignal;)Landroid/content/res/AssetFileDescriptor;", "mimeType", "displayName", "createDocument", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;", "renameDocument", "(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;", "Ldbxyzptlk/pI/D;", "deleteDocument", "(Ljava/lang/String;)V", "T", "msg", "Ldbxyzptlk/Zs/f;", "documentProviderEventType", "Lkotlin/Function0;", "wrappedFun", "b", "(Ljava/lang/String;Ljava/lang/String;Ldbxyzptlk/Zs/f;Ldbxyzptlk/CI/a;)Ljava/lang/Object;", "f", "(Ldbxyzptlk/Zs/f;Ljava/lang/String;)V", "Ljava/lang/Exception;", "Lkotlin/Exception;", "ex", "e", "(Ljava/lang/Exception;Ldbxyzptlk/Zs/f;Ljava/lang/String;)V", "Ldbxyzptlk/Zs/s;", "a", "Ldbxyzptlk/pI/j;", "d", "()Ldbxyzptlk/Zs/s;", "delegate", "dbapp_document_provider_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class DropboxDocumentProvider extends DocumentsProvider {
  public final j a = k.a(new b(this));
  
  public final <T> T b(String paramString1, String paramString2, f paramf, a<? extends T> parama) {
    try {
      Object object = parama.invoke();
      f(paramf, paramString1);
      return (T)object;
    } catch (Exception exception) {
      boolean bool;
      a.b b = a.a;
      b.c(exception, "Something went wrong in DocumentProvider", new Object[0]);
      e(exception, paramf, paramString1);
      if (exception instanceof java.io.FileNotFoundException) {
        bool = true;
      } else {
        bool = exception instanceof com.dropbox.product.dbapp.metadata.exceptions.PathDoesNotExistException;
      } 
      if (!bool) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("DropboxDocumentProvider.");
        stringBuilder.append(paramString2);
        b.f(exception, stringBuilder.toString(), new Object[0]);
      } 
      throw exception;
    } 
  }
  
  @SuppressLint({"VisibleForTests"})
  public String createDocument(String paramString1, String paramString2, String paramString3) {
    s.h(paramString1, "parentDocumentId");
    s.h(paramString3, "displayName");
    return b(null, "createDocument failed", f.CREATE_DOCUMENT_PLACEHOLDER, (a<? extends String>)new a(this, paramString1, paramString2, paramString3));
  }
  
  public final s d() {
    return (s)this.a.getValue();
  }
  
  public void deleteDocument(String paramString) {
    s.h(paramString, "documentId");
    c(this, null, "deleteDocument failed", null, (a)new c(this, paramString), 5, null);
  }
  
  public final void e(Exception paramException, f paramf, String paramString) {
    if (paramf != null && paramString != null) {
      g g = d().o(paramString);
      if (g != null)
        a.a(g, paramf, paramException, paramString); 
      d().a(paramString);
    } 
  }
  
  public final void f(f paramf, String paramString) {
    if (paramf != null && paramString != null) {
      g g = d().o(paramString);
      if (g != null)
        a.c(g, paramf, paramString); 
    } 
  }
  
  public boolean onCreate() {
    e.t((ContentProvider)this);
    e.u((ContentProvider)this);
    return true;
  }
  
  public ParcelFileDescriptor openDocument(String paramString1, String paramString2, CancellationSignal paramCancellationSignal) {
    String str;
    f f;
    s.h(paramString1, "documentId");
    s.h(paramString2, "mode");
    if (u.R(paramString2, 'w', true)) {
      f = f.OPEN_DOCUMENT_WRITE_MODE;
      str = paramString1;
    } else {
      str = null;
      f = null;
    } 
    return b(str, "openDocument failed", f, (a<? extends ParcelFileDescriptor>)new d(this, paramString1, paramString2, paramCancellationSignal));
  }
  
  public AssetFileDescriptor openDocumentThumbnail(String paramString, Point paramPoint, CancellationSignal paramCancellationSignal) {
    s.h(paramString, "documentId");
    return (AssetFileDescriptor)c(this, null, "openDocumentThumbnail failed", null, (a)new e(this, paramString, paramPoint), 5, null);
  }
  
  public Cursor queryChildDocuments(String paramString1, String[] paramArrayOfString, String paramString2) {
    s.h(paramString1, "parentDocumentId");
    return (Cursor)c(this, null, "queryChildDocuments failed", null, (a)new f(this, paramString1, paramArrayOfString, paramString2), 5, null);
  }
  
  public Cursor queryDocument(String paramString, String[] paramArrayOfString) {
    s.h(paramString, "documentId");
    return (Cursor)c(this, null, "queryDocument failed", null, (a)new g(this, paramString, paramArrayOfString), 5, null);
  }
  
  public Cursor queryRoots(String[] paramArrayOfString) {
    return (Cursor)c(this, null, "queryRoots failed", null, (a)new h(this, paramArrayOfString), 5, null);
  }
  
  public String renameDocument(String paramString1, String paramString2) {
    s.h(paramString1, "documentId");
    s.h(paramString2, "displayName");
    return (String)c(this, null, "renameDocument failed", null, (a)new i(this, paramString1, paramString2), 5, null);
  }
  
  @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"Ldbxyzptlk/Zs/s;", "b", "()Ldbxyzptlk/Zs/s;"}, k = 3, mv = {1, 9, 0})
  public static final class b extends u implements a<s> {
    public final DropboxDocumentProvider f;
    
    public b(DropboxDocumentProvider param1DropboxDocumentProvider) {
      super(0);
    }
    
    public final s b() {
      Context context = this.f.getContext();
      if (context != null) {
        s.g(context, "checkNotNull(...)");
        return j.b(context).b();
      } 
      throw new IllegalStateException("Required value was null.");
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\product\android\dbapp\document_provider\DropboxDocumentProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */