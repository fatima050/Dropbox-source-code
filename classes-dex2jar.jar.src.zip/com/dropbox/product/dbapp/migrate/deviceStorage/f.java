package com.dropbox.product.dbapp.migrate.deviceStorage;

import com.squareup.anvil.annotations.ContributesTo;
import dbxyzptlk.Jh.d;
import kotlin.Metadata;

@ContributesTo(scope = d.class)
@Metadata(d1 = {"\000\020\n\002\030\002\n\002\020\000\n\002\030\002\n\002\b\004\bg\030\0002\0020\001R\024\020\005\032\0020\0028&X¦\004¢\006\006\032\004\b\003\020\004ø\001\000\002\006\n\004\b!0\001¨\006\006À\006\001"}, d2 = {"Lcom/dropbox/product/dbapp/migrate/deviceStorage/f;", "", "Lcom/dropbox/product/dbapp/migrate/deviceStorage/n$b;", "p0", "()Lcom/dropbox/product/dbapp/migrate/deviceStorage/n$b;", "presenterFactory", "dbx_product_dbapp_migrate_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
public interface f {
  n.b p0();
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\product\dbapp\migrate\deviceStorage\f.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */