package com.dropbox.product.dbapp.migrate.deviceStorage;

import com.squareup.anvil.annotations.ContributesTo;
import dbxyzptlk.Jh.d;
import dbxyzptlk.oy.g;
import kotlin.Metadata;

@ContributesTo(scope = d.class)
@Metadata(d1 = {"\000\f\n\002\030\002\n\002\030\002\n\002\b\002\bg\030\0002\0020\001:\001\002ø\001\000\002\006\n\004\b!0\001¨\006\003À\006\001"}, d2 = {"Lcom/dropbox/product/dbapp/migrate/deviceStorage/e;", "Ldbxyzptlk/oy/g;", "a", "dbx_product_dbapp_migrate_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
public interface e extends g {
  class e {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\product\dbapp\migrate\deviceStorage\e.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */