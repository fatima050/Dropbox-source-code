package com.dropbox.product.dbapp.desktoplink;

import android.content.Context;
import com.squareup.anvil.annotations.ContributesBinding;
import dbxyzptlk.CI.p;
import dbxyzptlk.Ij.s;
import dbxyzptlk.Jh.d;
import dbxyzptlk.eK.C;
import dbxyzptlk.eK.U;
import dbxyzptlk.eK.i;
import dbxyzptlk.eK.j;
import dbxyzptlk.eK.k;
import dbxyzptlk.ox.B;
import dbxyzptlk.pI.D;
import dbxyzptlk.pI.p;
import dbxyzptlk.tI.d;
import dbxyzptlk.vI.d;
import dbxyzptlk.vI.f;
import dbxyzptlk.vI.l;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

@ContributesBinding(scope = d.class)
@Metadata(d1 = {"\000H\n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\002\n\002\020\013\n\002\b\006\n\002\030\002\n\002\b\003\n\002\030\002\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\005\b\007\030\000 !2\0020\001:\001\020B#\b\007\022\b\b\001\020\003\032\0020\002\022\006\020\005\032\0020\004\022\006\020\007\032\0020\006¢\006\004\b\b\020\tJ\020\020\013\032\0020\nH@¢\006\004\b\013\020\fJ\017\020\016\032\0020\rH\002¢\006\004\b\016\020\017R\024\020\003\032\0020\0028\002X\004¢\006\006\n\004\b\020\020\021R\024\020\005\032\0020\0048\002X\004¢\006\006\n\004\b\013\020\022R\024\020\007\032\0020\0068\002X\004¢\006\006\n\004\b\016\020\023R\024\020\027\032\0020\0248\002X\004¢\006\006\n\004\b\025\020\026R\032\020\034\032\b\022\004\022\0020\0310\0308\002X\004¢\006\006\n\004\b\032\020\033R\032\020 \032\b\022\004\022\0020\0310\0358VX\004¢\006\006\032\004\b\036\020\037¨\006\""}, d2 = {"Lcom/dropbox/product/dbapp/desktoplink/e;", "Lcom/dropbox/product/dbapp/desktoplink/b;", "Landroid/content/Context;", "context", "Ldbxyzptlk/ox/B;", "mlKitWrapper", "Ldbxyzptlk/Ij/s;", "udcl", "<init>", "(Landroid/content/Context;Ldbxyzptlk/ox/B;Ldbxyzptlk/Ij/s;)V", "Ldbxyzptlk/pI/D;", "b", "(Ldbxyzptlk/tI/d;)Ljava/lang/Object;", "", "c", "()Z", "a", "Landroid/content/Context;", "Ldbxyzptlk/ox/B;", "Ldbxyzptlk/Ij/s;", "Ldbxyzptlk/mK/a;", "d", "Ldbxyzptlk/mK/a;", "mutex", "Ldbxyzptlk/eK/C;", "Lcom/dropbox/product/dbapp/desktoplink/b$a;", "e", "Ldbxyzptlk/eK/C;", "_state", "Ldbxyzptlk/eK/i;", "getState", "()Ldbxyzptlk/eK/i;", "state", "f", "dbapp_desktoplink_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class e implements b {
  public static final a f = new a(null);
  
  public final Context a;
  
  public final B b;
  
  public final s c;
  
  public final dbxyzptlk.mK.a d;
  
  public final C<b.a> e;
  
  public e(Context paramContext, B paramB, s params) {
    this.a = paramContext;
    this.b = paramB;
    this.c = params;
    this.d = dbxyzptlk.mK.c.b(false, 1, null);
    this.e = U.a(b.a.NOT_INITIALIZED);
  }
  
  public final Object b(d<? super D> paramd) {
    // Byte code:
    //   0: aload_1
    //   1: instanceof com/dropbox/product/dbapp/desktoplink/e$b
    //   4: ifeq -> 38
    //   7: aload_1
    //   8: checkcast com/dropbox/product/dbapp/desktoplink/e$b
    //   11: astore #5
    //   13: aload #5
    //   15: getfield x : I
    //   18: istore_2
    //   19: iload_2
    //   20: ldc -2147483648
    //   22: iand
    //   23: ifeq -> 38
    //   26: aload #5
    //   28: iload_2
    //   29: ldc -2147483648
    //   31: iadd
    //   32: putfield x : I
    //   35: goto -> 49
    //   38: new com/dropbox/product/dbapp/desktoplink/e$b
    //   41: dup
    //   42: aload_0
    //   43: aload_1
    //   44: invokespecial <init> : (Lcom/dropbox/product/dbapp/desktoplink/e;Ldbxyzptlk/tI/d;)V
    //   47: astore #5
    //   49: aload #5
    //   51: getfield v : Ljava/lang/Object;
    //   54: astore #6
    //   56: invokestatic g : ()Ljava/lang/Object;
    //   59: astore #7
    //   61: aload #5
    //   63: getfield x : I
    //   66: istore_2
    //   67: iload_2
    //   68: ifeq -> 192
    //   71: iload_2
    //   72: iconst_1
    //   73: if_icmpeq -> 165
    //   76: iload_2
    //   77: iconst_2
    //   78: if_icmpeq -> 119
    //   81: iload_2
    //   82: iconst_3
    //   83: if_icmpne -> 109
    //   86: aload #5
    //   88: getfield t : Ljava/lang/Object;
    //   91: checkcast dbxyzptlk/mK/a
    //   94: astore_3
    //   95: aload_3
    //   96: astore_1
    //   97: aload #6
    //   99: invokestatic b : (Ljava/lang/Object;)V
    //   102: goto -> 517
    //   105: astore_3
    //   106: goto -> 535
    //   109: new java/lang/IllegalStateException
    //   112: dup
    //   113: ldc 'call to 'resume' before 'invoke' with coroutine'
    //   115: invokespecial <init> : (Ljava/lang/String;)V
    //   118: athrow
    //   119: aload #5
    //   121: getfield u : Ljava/lang/Object;
    //   124: checkcast dbxyzptlk/mK/a
    //   127: astore_1
    //   128: aload #5
    //   130: getfield t : Ljava/lang/Object;
    //   133: checkcast com/dropbox/product/dbapp/desktoplink/e
    //   136: astore #4
    //   138: aload_1
    //   139: astore_3
    //   140: aload #6
    //   142: invokestatic b : (Ljava/lang/Object;)V
    //   145: goto -> 402
    //   148: astore_1
    //   149: aload_3
    //   150: astore #4
    //   152: aload_1
    //   153: astore_3
    //   154: aload #4
    //   156: astore_1
    //   157: goto -> 535
    //   160: astore #6
    //   162: goto -> 411
    //   165: aload #5
    //   167: getfield u : Ljava/lang/Object;
    //   170: checkcast dbxyzptlk/mK/a
    //   173: astore_1
    //   174: aload #5
    //   176: getfield t : Ljava/lang/Object;
    //   179: checkcast com/dropbox/product/dbapp/desktoplink/e
    //   182: astore #4
    //   184: aload #6
    //   186: invokestatic b : (Ljava/lang/Object;)V
    //   189: goto -> 251
    //   192: aload #6
    //   194: invokestatic b : (Ljava/lang/Object;)V
    //   197: aload_0
    //   198: invokevirtual c : ()Z
    //   201: ifeq -> 208
    //   204: getstatic dbxyzptlk/pI/D.a : Ldbxyzptlk/pI/D;
    //   207: areturn
    //   208: aload_0
    //   209: getfield d : Ldbxyzptlk/mK/a;
    //   212: astore_1
    //   213: aload #5
    //   215: aload_0
    //   216: putfield t : Ljava/lang/Object;
    //   219: aload #5
    //   221: aload_1
    //   222: putfield u : Ljava/lang/Object;
    //   225: aload #5
    //   227: iconst_1
    //   228: putfield x : I
    //   231: aload_1
    //   232: aconst_null
    //   233: aload #5
    //   235: invokeinterface a : (Ljava/lang/Object;Ldbxyzptlk/tI/d;)Ljava/lang/Object;
    //   240: aload #7
    //   242: if_acmpne -> 248
    //   245: aload #7
    //   247: areturn
    //   248: aload_0
    //   249: astore #4
    //   251: aload_1
    //   252: astore_3
    //   253: aload #4
    //   255: invokevirtual c : ()Z
    //   258: ifeq -> 278
    //   261: aload_1
    //   262: astore_3
    //   263: getstatic dbxyzptlk/pI/D.a : Ldbxyzptlk/pI/D;
    //   266: astore #4
    //   268: aload_1
    //   269: aconst_null
    //   270: invokeinterface d : (Ljava/lang/Object;)V
    //   275: aload #4
    //   277: areturn
    //   278: aload_1
    //   279: astore_3
    //   280: aload #4
    //   282: getfield c : Ldbxyzptlk/Ij/s;
    //   285: ldc 'mlkit.init'
    //   287: aconst_null
    //   288: lconst_0
    //   289: aconst_null
    //   290: aconst_null
    //   291: bipush #30
    //   293: aconst_null
    //   294: invokestatic j : (Ldbxyzptlk/Ij/s;Ljava/lang/String;Ljava/lang/String;JLjava/util/Map;Ldbxyzptlk/Ij/m;ILjava/lang/Object;)V
    //   297: aload_1
    //   298: astore_3
    //   299: aload #4
    //   301: getfield b : Ldbxyzptlk/ox/B;
    //   304: aload #4
    //   306: getfield a : Landroid/content/Context;
    //   309: invokeinterface a : (Landroid/content/Context;)V
    //   314: aload_1
    //   315: astore_3
    //   316: aload #4
    //   318: getfield c : Ldbxyzptlk/Ij/s;
    //   321: ldc 'mlkit.init'
    //   323: getstatic dbxyzptlk/Ij/d.SUCCESS : Ldbxyzptlk/Ij/d;
    //   326: aconst_null
    //   327: lconst_0
    //   328: aconst_null
    //   329: aconst_null
    //   330: bipush #60
    //   332: aconst_null
    //   333: invokestatic f : (Ldbxyzptlk/Ij/s;Ljava/lang/String;Ldbxyzptlk/Ij/d;Ljava/lang/String;JLjava/util/Map;Ldbxyzptlk/Ij/m;ILjava/lang/Object;)V
    //   336: aload_1
    //   337: astore_3
    //   338: aload #4
    //   340: getfield e : Ldbxyzptlk/eK/C;
    //   343: astore #6
    //   345: aload_1
    //   346: astore_3
    //   347: getstatic com/dropbox/product/dbapp/desktoplink/b$a.INITIALIZED : Lcom/dropbox/product/dbapp/desktoplink/b$a;
    //   350: astore #8
    //   352: aload_1
    //   353: astore_3
    //   354: aload #5
    //   356: aload #4
    //   358: putfield t : Ljava/lang/Object;
    //   361: aload_1
    //   362: astore_3
    //   363: aload #5
    //   365: aload_1
    //   366: putfield u : Ljava/lang/Object;
    //   369: aload_1
    //   370: astore_3
    //   371: aload #5
    //   373: iconst_2
    //   374: putfield x : I
    //   377: aload_1
    //   378: astore_3
    //   379: aload #6
    //   381: aload #8
    //   383: aload #5
    //   385: invokeinterface c : (Ljava/lang/Object;Ldbxyzptlk/tI/d;)Ljava/lang/Object;
    //   390: astore #6
    //   392: aload #6
    //   394: aload #7
    //   396: if_acmpne -> 402
    //   399: aload #7
    //   401: areturn
    //   402: aload_1
    //   403: astore_3
    //   404: goto -> 517
    //   407: astore_3
    //   408: aload_3
    //   409: astore #6
    //   411: aload_1
    //   412: astore_3
    //   413: aload #4
    //   415: getfield c : Ldbxyzptlk/Ij/s;
    //   418: ldc 'mlkit.init'
    //   420: getstatic dbxyzptlk/Ij/d.FAILED : Ldbxyzptlk/Ij/d;
    //   423: aconst_null
    //   424: lconst_0
    //   425: aconst_null
    //   426: aconst_null
    //   427: bipush #60
    //   429: aconst_null
    //   430: invokestatic f : (Ldbxyzptlk/Ij/s;Ljava/lang/String;Ldbxyzptlk/Ij/d;Ljava/lang/String;JLjava/util/Map;Ldbxyzptlk/Ij/m;ILjava/lang/Object;)V
    //   433: aload_1
    //   434: astore_3
    //   435: getstatic dbxyzptlk/sL/a.a : Ldbxyzptlk/sL/a$b;
    //   438: ldc 'Unable to initialize MlKit'
    //   440: iconst_1
    //   441: anewarray java/lang/Object
    //   444: dup
    //   445: iconst_0
    //   446: aload #6
    //   448: aastore
    //   449: invokevirtual d : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   452: aload_1
    //   453: astore_3
    //   454: aload #4
    //   456: getfield e : Ldbxyzptlk/eK/C;
    //   459: astore #4
    //   461: aload_1
    //   462: astore_3
    //   463: getstatic com/dropbox/product/dbapp/desktoplink/b$a.FAILURE : Lcom/dropbox/product/dbapp/desktoplink/b$a;
    //   466: astore #6
    //   468: aload_1
    //   469: astore_3
    //   470: aload #5
    //   472: aload_1
    //   473: putfield t : Ljava/lang/Object;
    //   476: aload_1
    //   477: astore_3
    //   478: aload #5
    //   480: aconst_null
    //   481: putfield u : Ljava/lang/Object;
    //   484: aload_1
    //   485: astore_3
    //   486: aload #5
    //   488: iconst_3
    //   489: putfield x : I
    //   492: aload_1
    //   493: astore_3
    //   494: aload #4
    //   496: aload #6
    //   498: aload #5
    //   500: invokeinterface c : (Ljava/lang/Object;Ldbxyzptlk/tI/d;)Ljava/lang/Object;
    //   505: astore #4
    //   507: aload #4
    //   509: aload #7
    //   511: if_acmpne -> 402
    //   514: aload #7
    //   516: areturn
    //   517: aload_3
    //   518: astore_1
    //   519: getstatic dbxyzptlk/pI/D.a : Ldbxyzptlk/pI/D;
    //   522: astore #4
    //   524: aload_3
    //   525: aconst_null
    //   526: invokeinterface d : (Ljava/lang/Object;)V
    //   531: getstatic dbxyzptlk/pI/D.a : Ldbxyzptlk/pI/D;
    //   534: areturn
    //   535: aload_1
    //   536: aconst_null
    //   537: invokeinterface d : (Ljava/lang/Object;)V
    //   542: aload_3
    //   543: athrow
    // Exception table:
    //   from	to	target	type
    //   97	102	105	finally
    //   140	145	160	java/lang/Exception
    //   140	145	148	finally
    //   253	261	148	finally
    //   263	268	148	finally
    //   280	297	148	finally
    //   299	314	407	java/lang/Exception
    //   299	314	148	finally
    //   316	336	407	java/lang/Exception
    //   316	336	148	finally
    //   338	345	407	java/lang/Exception
    //   338	345	148	finally
    //   347	352	407	java/lang/Exception
    //   347	352	148	finally
    //   354	361	407	java/lang/Exception
    //   354	361	148	finally
    //   363	369	407	java/lang/Exception
    //   363	369	148	finally
    //   371	377	407	java/lang/Exception
    //   371	377	148	finally
    //   379	392	407	java/lang/Exception
    //   379	392	148	finally
    //   413	433	148	finally
    //   435	452	148	finally
    //   454	461	148	finally
    //   463	468	148	finally
    //   470	476	148	finally
    //   478	484	148	finally
    //   486	492	148	finally
    //   494	507	148	finally
    //   519	524	105	finally
  }
  
  public final boolean c() {
    boolean bool;
    if (this.e.getValue() != b.a.NOT_INITIALIZED) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public i<b.a> getState() {
    return k.c0((i)this.e, new c(this, null));
  }
  
  @Metadata(d1 = {"\000\024\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\016\n\002\b\003\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003R\024\020\005\032\0020\0048\002XT¢\006\006\n\004\b\005\020\006¨\006\007"}, d2 = {"Lcom/dropbox/product/dbapp/desktoplink/e$a;", "", "<init>", "()V", "", "MLKIT_METRIC_NAME", "Ljava/lang/String;", "dbapp_desktoplink_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
  public static final class a {
    public a() {}
  }
  
  @f(c = "com.dropbox.product.dbapp.desktoplink.RealMlKitInitializer", f = "MlKitInitializer.kt", l = {98, 69, 73}, m = "initIfNeeded")
  @Metadata(k = 3, mv = {1, 9, 0}, xi = 48)
  public static final class b extends d {
    public Object t;
    
    public Object u;
    
    public Object v;
    
    public final e w;
    
    public int x;
    
    public b(e param1e, d<? super b> param1d) {
      super(param1d);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      this.v = param1Object;
      this.x |= Integer.MIN_VALUE;
      return e.a(this.w, (d)this);
    }
  }
  
  @f(c = "com.dropbox.product.dbapp.desktoplink.RealMlKitInitializer$state$1", f = "MlKitInitializer.kt", l = {58}, m = "invokeSuspend")
  @Metadata(d1 = {"\000\020\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\002\020\003\032\0020\002*\b\022\004\022\0020\0010\000H@¢\006\004\b\003\020\004"}, d2 = {"Ldbxyzptlk/eK/j;", "Lcom/dropbox/product/dbapp/desktoplink/b$a;", "Ldbxyzptlk/pI/D;", "<anonymous>", "(Ldbxyzptlk/eK/j;)V"}, k = 3, mv = {1, 9, 0})
  public static final class c extends l implements p<j<? super b.a>, d<? super D>, Object> {
    public int t;
    
    public final e u;
    
    public c(e param1e, d<? super c> param1d) {
      super(2, param1d);
    }
    
    public final Object a(j<? super b.a> param1j, d<? super D> param1d) {
      return ((c)create(param1j, param1d)).invokeSuspend(D.a);
    }
    
    public final d<D> create(Object param1Object, d<?> param1d) {
      return (d<D>)new c(this.u, (d)param1d);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = dbxyzptlk.uI.c.g();
      int i = this.t;
      if (i != 0) {
        if (i == 1) {
          p.b(param1Object);
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        p.b(param1Object);
        param1Object = this.u;
        this.t = 1;
        if (e.a((e)param1Object, (d)this) == object)
          return object; 
      } 
      return D.a;
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\product\dbapp\desktoplink\e.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */