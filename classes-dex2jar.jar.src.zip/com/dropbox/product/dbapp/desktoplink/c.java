package com.dropbox.product.dbapp.desktoplink;

import dbxyzptlk.eK.i;
import dbxyzptlk.eK.j;
import dbxyzptlk.eK.k;
import dbxyzptlk.pI.D;
import dbxyzptlk.tI.d;
import dbxyzptlk.vI.d;
import dbxyzptlk.vI.f;
import kotlin.Metadata;

@Metadata(d1 = {"\000\f\n\002\030\002\n\002\030\002\n\002\b\003\032\032\020\002\032\0020\001*\b\022\004\022\0020\0010\000H@¢\006\004\b\002\020\003¨\006\004"}, d2 = {"Ldbxyzptlk/eK/i;", "Lcom/dropbox/product/dbapp/desktoplink/b$a;", "a", "(Ldbxyzptlk/eK/i;Ldbxyzptlk/tI/d;)Ljava/lang/Object;", "dbapp_desktoplink_release"}, k = 2, mv = {1, 9, 0}, xi = 48)
public final class c {
  public static final Object a(i<? extends b.a> parami, d<? super b.a> paramd) {
    return k.G(new a(parami), paramd);
  }
  
  @Metadata(d1 = {"\000\027\n\000\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\003*\001\000\b\n\030\0002\b\022\004\022\0028\0000\001J\036\020\005\032\0020\0042\f\020\003\032\b\022\004\022\0028\0000\002H@¢\006\004\b\005\020\006¨\006\007"}, d2 = {"kotlinx/coroutines/flow/internal/SafeCollector_commonKt$unsafeFlow$1", "Ldbxyzptlk/eK/i;", "Ldbxyzptlk/eK/j;", "collector", "Ldbxyzptlk/pI/D;", "a", "(Ldbxyzptlk/eK/j;Ldbxyzptlk/tI/d;)Ljava/lang/Object;", "kotlinx-coroutines-core"}, k = 1, mv = {1, 9, 0}, xi = 48)
  public static final class a implements i<b.a> {
    public final i a;
    
    public a(i param1i) {}
    
    public Object a(j param1j, d param1d) {
      Object object = this.a.a(new a(param1j), param1d);
      return (object == dbxyzptlk.uI.c.g()) ? object : D.a;
    }
    
    @Metadata(d1 = {"\000\f\n\002\b\003\n\002\030\002\n\002\b\002\020\004\032\0020\003\"\004\b\000\020\000\"\004\b\001\020\0012\006\020\002\032\0028\000H@¢\006\004\b\004\020\005"}, d2 = {"T", "R", "value", "Ldbxyzptlk/pI/D;", "c", "(Ljava/lang/Object;Ldbxyzptlk/tI/d;)Ljava/lang/Object;"}, k = 3, mv = {1, 9, 0})
    public static final class a<T> implements j {
      public final j a;
      
      public a(j param2j) {}
      
      public final Object c(Object param2Object, d param2d) {
        // Byte code:
        //   0: aload_2
        //   1: instanceof com/dropbox/product/dbapp/desktoplink/c$a$a$a
        //   4: ifeq -> 41
        //   7: aload_2
        //   8: checkcast com/dropbox/product/dbapp/desktoplink/c$a$a$a
        //   11: astore #4
        //   13: aload #4
        //   15: getfield u : I
        //   18: istore_3
        //   19: iload_3
        //   20: ldc -2147483648
        //   22: iand
        //   23: ifeq -> 41
        //   26: aload #4
        //   28: iload_3
        //   29: ldc -2147483648
        //   31: iadd
        //   32: putfield u : I
        //   35: aload #4
        //   37: astore_2
        //   38: goto -> 51
        //   41: new com/dropbox/product/dbapp/desktoplink/c$a$a$a
        //   44: dup
        //   45: aload_0
        //   46: aload_2
        //   47: invokespecial <init> : (Lcom/dropbox/product/dbapp/desktoplink/c$a$a;Ldbxyzptlk/tI/d;)V
        //   50: astore_2
        //   51: aload_2
        //   52: getfield t : Ljava/lang/Object;
        //   55: astore #5
        //   57: invokestatic g : ()Ljava/lang/Object;
        //   60: astore #4
        //   62: aload_2
        //   63: getfield u : I
        //   66: istore_3
        //   67: iload_3
        //   68: ifeq -> 94
        //   71: iload_3
        //   72: iconst_1
        //   73: if_icmpne -> 84
        //   76: aload #5
        //   78: invokestatic b : (Ljava/lang/Object;)V
        //   81: goto -> 137
        //   84: new java/lang/IllegalStateException
        //   87: dup
        //   88: ldc 'call to 'resume' before 'invoke' with coroutine'
        //   90: invokespecial <init> : (Ljava/lang/String;)V
        //   93: athrow
        //   94: aload #5
        //   96: invokestatic b : (Ljava/lang/Object;)V
        //   99: aload_0
        //   100: getfield a : Ldbxyzptlk/eK/j;
        //   103: astore #5
        //   105: aload_1
        //   106: checkcast com/dropbox/product/dbapp/desktoplink/b$a
        //   109: getstatic com/dropbox/product/dbapp/desktoplink/b$a.NOT_INITIALIZED : Lcom/dropbox/product/dbapp/desktoplink/b$a;
        //   112: if_acmpeq -> 137
        //   115: aload_2
        //   116: iconst_1
        //   117: putfield u : I
        //   120: aload #5
        //   122: aload_1
        //   123: aload_2
        //   124: invokeinterface c : (Ljava/lang/Object;Ldbxyzptlk/tI/d;)Ljava/lang/Object;
        //   129: aload #4
        //   131: if_acmpne -> 137
        //   134: aload #4
        //   136: areturn
        //   137: getstatic dbxyzptlk/pI/D.a : Ldbxyzptlk/pI/D;
        //   140: areturn
      }
      
      @f(c = "com.dropbox.product.dbapp.desktoplink.MlKitInitializerKt$firstTerminalState$$inlined$filter$1$2", f = "MlKitInitializer.kt", l = {219}, m = "emit")
      @Metadata(k = 3, mv = {1, 9, 0}, xi = 48)
      public static final class a extends d {
        public Object t;
        
        public int u;
        
        public final c.a.a v;
        
        public a(c.a.a param3a, d param3d) {
          super(param3d);
        }
        
        public final Object invokeSuspend(Object param3Object) {
          this.t = param3Object;
          this.u |= Integer.MIN_VALUE;
          return this.v.c(null, (d)this);
        }
      }
    }
    
    @f(c = "com.dropbox.product.dbapp.desktoplink.MlKitInitializerKt$firstTerminalState$$inlined$filter$1$2", f = "MlKitInitializer.kt", l = {219}, m = "emit")
    @Metadata(k = 3, mv = {1, 9, 0}, xi = 48)
    public static final class a extends d {
      public Object t;
      
      public int u;
      
      public final c.a.a v;
      
      public a(c.a.a param2a, d param2d) {
        super(param2d);
      }
      
      public final Object invokeSuspend(Object param2Object) {
        this.t = param2Object;
        this.u |= Integer.MIN_VALUE;
        return this.v.c(null, (d)this);
      }
    }
  }
  
  @Metadata(d1 = {"\000\f\n\002\b\003\n\002\030\002\n\002\b\002\020\004\032\0020\003\"\004\b\000\020\000\"\004\b\001\020\0012\006\020\002\032\0028\000H@¢\006\004\b\004\020\005"}, d2 = {"T", "R", "value", "Ldbxyzptlk/pI/D;", "c", "(Ljava/lang/Object;Ldbxyzptlk/tI/d;)Ljava/lang/Object;"}, k = 3, mv = {1, 9, 0})
  public static final class a<T> implements j {
    public final j a;
    
    public a(j param1j) {}
    
    public final Object c(Object param1Object, d param1d) {
      // Byte code:
      //   0: aload_2
      //   1: instanceof com/dropbox/product/dbapp/desktoplink/c$a$a$a
      //   4: ifeq -> 41
      //   7: aload_2
      //   8: checkcast com/dropbox/product/dbapp/desktoplink/c$a$a$a
      //   11: astore #4
      //   13: aload #4
      //   15: getfield u : I
      //   18: istore_3
      //   19: iload_3
      //   20: ldc -2147483648
      //   22: iand
      //   23: ifeq -> 41
      //   26: aload #4
      //   28: iload_3
      //   29: ldc -2147483648
      //   31: iadd
      //   32: putfield u : I
      //   35: aload #4
      //   37: astore_2
      //   38: goto -> 51
      //   41: new com/dropbox/product/dbapp/desktoplink/c$a$a$a
      //   44: dup
      //   45: aload_0
      //   46: aload_2
      //   47: invokespecial <init> : (Lcom/dropbox/product/dbapp/desktoplink/c$a$a;Ldbxyzptlk/tI/d;)V
      //   50: astore_2
      //   51: aload_2
      //   52: getfield t : Ljava/lang/Object;
      //   55: astore #5
      //   57: invokestatic g : ()Ljava/lang/Object;
      //   60: astore #4
      //   62: aload_2
      //   63: getfield u : I
      //   66: istore_3
      //   67: iload_3
      //   68: ifeq -> 94
      //   71: iload_3
      //   72: iconst_1
      //   73: if_icmpne -> 84
      //   76: aload #5
      //   78: invokestatic b : (Ljava/lang/Object;)V
      //   81: goto -> 137
      //   84: new java/lang/IllegalStateException
      //   87: dup
      //   88: ldc 'call to 'resume' before 'invoke' with coroutine'
      //   90: invokespecial <init> : (Ljava/lang/String;)V
      //   93: athrow
      //   94: aload #5
      //   96: invokestatic b : (Ljava/lang/Object;)V
      //   99: aload_0
      //   100: getfield a : Ldbxyzptlk/eK/j;
      //   103: astore #5
      //   105: aload_1
      //   106: checkcast com/dropbox/product/dbapp/desktoplink/b$a
      //   109: getstatic com/dropbox/product/dbapp/desktoplink/b$a.NOT_INITIALIZED : Lcom/dropbox/product/dbapp/desktoplink/b$a;
      //   112: if_acmpeq -> 137
      //   115: aload_2
      //   116: iconst_1
      //   117: putfield u : I
      //   120: aload #5
      //   122: aload_1
      //   123: aload_2
      //   124: invokeinterface c : (Ljava/lang/Object;Ldbxyzptlk/tI/d;)Ljava/lang/Object;
      //   129: aload #4
      //   131: if_acmpne -> 137
      //   134: aload #4
      //   136: areturn
      //   137: getstatic dbxyzptlk/pI/D.a : Ldbxyzptlk/pI/D;
      //   140: areturn
    }
    
    @f(c = "com.dropbox.product.dbapp.desktoplink.MlKitInitializerKt$firstTerminalState$$inlined$filter$1$2", f = "MlKitInitializer.kt", l = {219}, m = "emit")
    @Metadata(k = 3, mv = {1, 9, 0}, xi = 48)
    public static final class a extends d {
      public Object t;
      
      public int u;
      
      public final c.a.a v;
      
      public a(c.a.a param3a, d param3d) {
        super(param3d);
      }
      
      public final Object invokeSuspend(Object param3Object) {
        this.t = param3Object;
        this.u |= Integer.MIN_VALUE;
        return this.v.c(null, (d)this);
      }
    }
  }
  
  @f(c = "com.dropbox.product.dbapp.desktoplink.MlKitInitializerKt$firstTerminalState$$inlined$filter$1$2", f = "MlKitInitializer.kt", l = {219}, m = "emit")
  @Metadata(k = 3, mv = {1, 9, 0}, xi = 48)
  public static final class a extends d {
    public Object t;
    
    public int u;
    
    public final c.a.a v;
    
    public a(c.a.a param1a, d param1d) {
      super(param1d);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      this.t = param1Object;
      this.u |= Integer.MIN_VALUE;
      return this.v.c(null, (d)this);
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\product\dbapp\desktoplink\c.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */