package com.dropbox.product.dbapp.desktoplink;

import dbxyzptlk.eK.i;
import kotlin.Metadata;

@Metadata(d1 = {"\000\024\n\002\030\002\n\002\020\000\n\002\030\002\n\002\030\002\n\002\b\005\bf\030\0002\0020\001:\001\007R\032\020\006\032\b\022\004\022\0020\0030\0028&X¦\004¢\006\006\032\004\b\004\020\005ø\001\000\002\006\n\004\b!0\001¨\006\bÀ\006\001"}, d2 = {"Lcom/dropbox/product/dbapp/desktoplink/b;", "", "Ldbxyzptlk/eK/i;", "Lcom/dropbox/product/dbapp/desktoplink/b$a;", "getState", "()Ldbxyzptlk/eK/i;", "state", "a", "dbapp_desktoplink_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
public interface b {
  i<a> getState();
  
  @Metadata(d1 = {"\000\f\n\002\030\002\n\002\020\020\n\002\b\006\b\002\030\0002\b\022\004\022\0020\0000\001B\t\b\002¢\006\004\b\002\020\003j\002\b\004j\002\b\005j\002\b\006¨\006\007"}, d2 = {"Lcom/dropbox/product/dbapp/desktoplink/b$a;", "", "<init>", "(Ljava/lang/String;I)V", "NOT_INITIALIZED", "INITIALIZED", "FAILURE", "dbapp_desktoplink_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
  public enum a {
    FAILURE, INITIALIZED, NOT_INITIALIZED;
    
    private static final dbxyzptlk.wI.a $ENTRIES;
    
    private static final a[] $VALUES;
    
    static {
      FAILURE = new a("FAILURE", 2);
      a[] arrayOfA = a();
      $VALUES = arrayOfA;
      $ENTRIES = dbxyzptlk.wI.b.a((Enum[])arrayOfA);
    }
    
    public static dbxyzptlk.wI.a<a> getEntries() {
      return $ENTRIES;
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\product\dbapp\desktoplink\b.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */