package com.dropbox.product.dbapp.desktoplink;

import com.squareup.anvil.annotations.ContributesMultibinding;
import dbxyzptlk.Aj.b;
import dbxyzptlk.CI.p;
import dbxyzptlk.Jh.d;
import dbxyzptlk.bK.J;
import dbxyzptlk.bK.h;
import dbxyzptlk.eK.i;
import dbxyzptlk.ox.A;
import dbxyzptlk.pI.D;
import dbxyzptlk.pI.p;
import dbxyzptlk.uI.c;
import dbxyzptlk.vI.f;
import dbxyzptlk.vI.l;
import kotlin.Metadata;

@ContributesMultibinding(scope = d.class)
@Metadata(d1 = {"\000\036\n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\007\b\007\030\0002\0020\001B\031\b\007\022\006\020\003\032\0020\002\022\006\020\005\032\0020\004¢\006\004\b\006\020\007J\017\020\t\032\0020\bH\026¢\006\004\b\t\020\nR\024\020\003\032\0020\0028\002X\004¢\006\006\n\004\b\013\020\fR\024\020\005\032\0020\0048\002X\004¢\006\006\n\004\b\r\020\016¨\006\017"}, d2 = {"Lcom/dropbox/product/dbapp/desktoplink/d;", "Ldbxyzptlk/Aj/b;", "Ldbxyzptlk/ox/A;", "mlKitAppInitializationGate", "Lcom/dropbox/product/dbapp/desktoplink/b;", "mlKitInitializer", "<init>", "(Ldbxyzptlk/ox/A;Lcom/dropbox/product/dbapp/desktoplink/b;)V", "Ldbxyzptlk/pI/D;", "run", "()V", "a", "Ldbxyzptlk/ox/A;", "b", "Lcom/dropbox/product/dbapp/desktoplink/b;", "dbapp_desktoplink_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class d implements b {
  public final A a;
  
  public final b b;
  
  public d(A paramA, b paramb) {
    this.a = paramA;
    this.b = paramb;
  }
  
  public void run() {
    if (this.a.a())
      h.f(null, new a(this, null), 1, null); 
  }
  
  @f(c = "com.dropbox.product.dbapp.desktoplink.RealMlKitAppStartInitializer$run$1", f = "RealMlKitAppStartInitializer.kt", l = {21}, m = "invokeSuspend")
  @Metadata(d1 = {"\000\f\n\002\030\002\n\002\030\002\n\002\b\002\020\002\032\0020\001*\0020\000H@¢\006\004\b\002\020\003"}, d2 = {"Ldbxyzptlk/bK/J;", "Lcom/dropbox/product/dbapp/desktoplink/b$a;", "<anonymous>", "(Ldbxyzptlk/bK/J;)Lcom/dropbox/product/dbapp/desktoplink/b$a;"}, k = 3, mv = {1, 9, 0})
  public static final class a extends l implements p<J, dbxyzptlk.tI.d<? super b.a>, Object> {
    public int t;
    
    public final d u;
    
    public a(d param1d, dbxyzptlk.tI.d<? super a> param1d1) {
      super(2, param1d1);
    }
    
    public final dbxyzptlk.tI.d<D> create(Object param1Object, dbxyzptlk.tI.d<?> param1d) {
      return (dbxyzptlk.tI.d<D>)new a(this.u, (dbxyzptlk.tI.d)param1d);
    }
    
    public final Object invoke(J param1J, dbxyzptlk.tI.d<? super b.a> param1d) {
      return ((a)create(param1J, param1d)).invokeSuspend(D.a);
    }
    
    public final Object invokeSuspend(Object<b.a> param1Object) {
      Object object = c.g();
      int i = this.t;
      if (i != 0) {
        if (i == 1) {
          p.b(param1Object);
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        p.b(param1Object);
        param1Object = (Object<b.a>)d.d(this.u).getState();
        this.t = 1;
        Object object1 = c.a((i<? extends b.a>)param1Object, (dbxyzptlk.tI.d<? super b.a>)this);
        param1Object = (Object<b.a>)object1;
        if (object1 == object)
          return object; 
      } 
      return param1Object;
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\product\dbapp\desktoplink\d.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */