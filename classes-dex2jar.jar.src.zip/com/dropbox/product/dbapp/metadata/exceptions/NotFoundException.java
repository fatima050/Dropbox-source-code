package com.dropbox.product.dbapp.metadata.exceptions;

import kotlin.Metadata;

@Metadata(d1 = {"\000\f\n\002\030\002\n\002\030\002\n\002\b\002\030\0002\0020\001B\005¢\006\002\020\002¨\006\003"}, d2 = {"Lcom/dropbox/product/dbapp/metadata/exceptions/NotFoundException;", "Lcom/dropbox/product/dbapp/metadata/exceptions/MetadataException;", "()V", "dbx_product_dbapp_metadata_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class NotFoundException extends MetadataException {
  public NotFoundException() {
    super(null, null, 3, null);
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\product\dbapp\metadata\exceptions\NotFoundException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */