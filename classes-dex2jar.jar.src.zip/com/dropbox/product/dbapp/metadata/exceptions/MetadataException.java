package com.dropbox.product.dbapp.metadata.exceptions;

import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

@Metadata(d1 = {"\0000\n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\020\016\n\000\n\002\020\003\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\000\b6\030\0002\0060\001j\002`\002B\037\b\004\022\n\b\002\020\003\032\004\030\0010\004\022\n\b\002\020\005\032\004\030\0010\006¢\006\002\020\007\001\005\b\t\n\013\f¨\006\r"}, d2 = {"Lcom/dropbox/product/dbapp/metadata/exceptions/MetadataException;", "Ljava/lang/Exception;", "Lkotlin/Exception;", "message", "", "cause", "", "(Ljava/lang/String;Ljava/lang/Throwable;)V", "Lcom/dropbox/product/dbapp/metadata/exceptions/InDropboxException;", "Lcom/dropbox/product/dbapp/metadata/exceptions/NetworkException;", "Lcom/dropbox/product/dbapp/metadata/exceptions/NotFoundException;", "Lcom/dropbox/product/dbapp/metadata/exceptions/PathDoesNotExistException;", "Lcom/dropbox/product/dbapp/metadata/exceptions/RecursiveDeltaLimitExceededException;", "dbx_product_dbapp_metadata_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
public abstract class MetadataException extends Exception {
  public MetadataException(String paramString, Throwable paramThrowable) {
    super(paramString, paramThrowable);
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\product\dbapp\metadata\exceptions\MetadataException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */