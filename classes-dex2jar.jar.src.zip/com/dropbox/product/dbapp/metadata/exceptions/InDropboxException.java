package com.dropbox.product.dbapp.metadata.exceptions;

import com.dropbox.product.dbapp.path.DropboxPath;
import dbxyzptlk.CC.p;
import kotlin.Metadata;

@Metadata(d1 = {"\000\026\n\002\030\002\n\002\030\002\n\002\020\016\n\000\n\002\030\002\n\002\b\n\030\0002\0020\001B\031\022\b\020\003\032\004\030\0010\002\022\006\020\005\032\0020\004¢\006\004\b\006\020\007R\031\020\003\032\004\030\0010\0028\006¢\006\f\n\004\b\b\020\t\032\004\b\n\020\013R\027\020\005\032\0020\0048\006¢\006\f\n\004\b\n\020\f\032\004\b\b\020\r¨\006\016"}, d2 = {"Lcom/dropbox/product/dbapp/metadata/exceptions/InDropboxException;", "Lcom/dropbox/product/dbapp/metadata/exceptions/MetadataException;", "", "userId", "Lcom/dropbox/product/dbapp/path/DropboxPath;", "path", "<init>", "(Ljava/lang/String;Lcom/dropbox/product/dbapp/path/DropboxPath;)V", "a", "Ljava/lang/String;", "b", "()Ljava/lang/String;", "Lcom/dropbox/product/dbapp/path/DropboxPath;", "()Lcom/dropbox/product/dbapp/path/DropboxPath;", "dbx_product_dbapp_metadata_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class InDropboxException extends MetadataException {
  public final String a;
  
  public final DropboxPath b;
  
  public InDropboxException(String paramString, DropboxPath paramDropboxPath) {
    super(null, null, 3, null);
    this.a = paramString;
    this.b = paramDropboxPath;
    p.l(paramDropboxPath.q0(), "Assert failed.", new Object[0]);
  }
  
  public final DropboxPath a() {
    return this.b;
  }
  
  public final String b() {
    return this.a;
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\product\dbapp\metadata\exceptions\InDropboxException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */