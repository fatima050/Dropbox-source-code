package com.dropbox.product.dbapp.metadata;

import dbxyzptlk.iy.e;

public final class DirUnknownException extends Exception {
  private static final long serialVersionUID = 3772065220350964932L;
  
  public final e a;
  
  public DirUnknownException(e parame) {
    this.a = parame;
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\product\dbapp\metadata\DirUnknownException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */