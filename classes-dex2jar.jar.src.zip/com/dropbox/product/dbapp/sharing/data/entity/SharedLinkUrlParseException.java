package com.dropbox.product.dbapp.sharing.data.entity;

import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

@Metadata(d1 = {"\000.\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\f\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\000\b6\030\0002\0060\001j\002`\002:\006\n\013\f\r\016\017B\023\b\004\022\b\020\004\032\004\030\0010\003¢\006\004\b\005\020\006R\031\020\004\032\004\030\0010\0038\006¢\006\f\n\004\b\007\020\b\032\004\b\007\020\t\001\006\020\021\022\023\024\025¨\006\026"}, d2 = {"Lcom/dropbox/product/dbapp/sharing/data/entity/SharedLinkUrlParseException;", "Ljava/lang/RuntimeException;", "Lkotlin/RuntimeException;", "Lcom/dropbox/product/dbapp/sharing/data/entity/SharedLinkUrl$b;", "inputUrlType", "<init>", "(Lcom/dropbox/product/dbapp/sharing/data/entity/SharedLinkUrl$b;)V", "a", "Lcom/dropbox/product/dbapp/sharing/data/entity/SharedLinkUrl$b;", "()Lcom/dropbox/product/dbapp/sharing/data/entity/SharedLinkUrl$b;", "EmbeddedRelativeUrlException", "EmptyUrlException", "MissingTokenAfterPrefixException", "MissingUrlParamException", "RelativeUrlException", "UnsupportedPathPrefixException", "Lcom/dropbox/product/dbapp/sharing/data/entity/SharedLinkUrlParseException$EmbeddedRelativeUrlException;", "Lcom/dropbox/product/dbapp/sharing/data/entity/SharedLinkUrlParseException$EmptyUrlException;", "Lcom/dropbox/product/dbapp/sharing/data/entity/SharedLinkUrlParseException$MissingTokenAfterPrefixException;", "Lcom/dropbox/product/dbapp/sharing/data/entity/SharedLinkUrlParseException$MissingUrlParamException;", "Lcom/dropbox/product/dbapp/sharing/data/entity/SharedLinkUrlParseException$RelativeUrlException;", "Lcom/dropbox/product/dbapp/sharing/data/entity/SharedLinkUrlParseException$UnsupportedPathPrefixException;", "dbapp_sharing_data_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
public abstract class SharedLinkUrlParseException extends RuntimeException {
  public final SharedLinkUrl.b a;
  
  public SharedLinkUrlParseException(SharedLinkUrl.b paramb) {
    this.a = paramb;
  }
  
  public final SharedLinkUrl.b a() {
    return this.a;
  }
  
  class SharedLinkUrlParseException {}
  
  class SharedLinkUrlParseException {}
  
  class SharedLinkUrlParseException {}
  
  class SharedLinkUrlParseException {}
  
  class SharedLinkUrlParseException {}
  
  class SharedLinkUrlParseException {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\product\dbapp\sharing\data\entity\SharedLinkUrlParseException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */