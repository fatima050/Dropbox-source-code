package com.dropbox.product.dbapp.signature_requests.impl.data;

import dbxyzptlk.F4.s;
import dbxyzptlk.sz.e;
import kotlin.Metadata;

@Metadata(d1 = {"\000\024\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\003\b'\030\0002\0020\001B\007¢\006\004\b\002\020\003J\017\020\005\032\0020\004H&¢\006\004\b\005\020\006¨\006\007"}, d2 = {"Lcom/dropbox/product/dbapp/signature_requests/impl/data/SignatureRequestDatabase;", "Ldbxyzptlk/F4/s;", "<init>", "()V", "Ldbxyzptlk/sz/e;", "J", "()Ldbxyzptlk/sz/e;", "dbapp_signature-requests_impl_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
public abstract class SignatureRequestDatabase extends s {
  static {
  
  }
  
  public abstract e J();
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\product\dbapp\signature_requests\impl\data\SignatureRequestDatabase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */