package com.dropbox.product.dbapp.signature_requests.impl.data;

import androidx.room.f;
import dbxyzptlk.CI.l;
import dbxyzptlk.DI.s;
import dbxyzptlk.F4.A;
import dbxyzptlk.F4.j;
import dbxyzptlk.F4.s;
import dbxyzptlk.F4.v;
import dbxyzptlk.L4.k;
import dbxyzptlk.eK.i;
import dbxyzptlk.nI.X;
import dbxyzptlk.nI.g1;
import dbxyzptlk.pI.D;
import dbxyzptlk.qI.s;
import dbxyzptlk.sz.d;
import dbxyzptlk.sz.e;
import dbxyzptlk.tI.d;
import io.sentry.B;
import java.time.LocalDateTime;
import java.util.List;
import java.util.concurrent.Callable;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

@Metadata(d1 = {"\000B\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\003\n\002\020 \n\002\030\002\n\000\n\002\030\002\n\002\b\007\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\004\b\007\030\000 \0362\0020\001:\001\fB\017\022\006\020\003\032\0020\002¢\006\004\b\004\020\005J\036\020\n\032\0020\t2\f\020\b\032\b\022\004\022\0020\0070\006H@¢\006\004\b\n\020\013J\036\020\f\032\0020\t2\f\020\b\032\b\022\004\022\0020\0070\006H@¢\006\004\b\f\020\013J\020\020\r\032\0020\tH@¢\006\004\b\r\020\016J\017\020\017\032\0020\tH\026¢\006\004\b\017\020\020J\033\020\022\032\016\022\n\022\b\022\004\022\0020\0070\0060\021H\026¢\006\004\b\022\020\023R\024\020\003\032\0020\0028\002X\004¢\006\006\n\004\b\r\020\024R\032\020\027\032\b\022\004\022\0020\0070\0258\002X\004¢\006\006\n\004\b\017\020\026R\024\020\032\032\0020\0308\002X\004¢\006\006\n\004\b\f\020\031R\024\020\035\032\0020\0338\002X\004¢\006\006\n\004\b\n\020\034¨\006\037"}, d2 = {"Lcom/dropbox/product/dbapp/signature_requests/impl/data/a;", "Ldbxyzptlk/sz/e;", "Ldbxyzptlk/F4/s;", "__db", "<init>", "(Ldbxyzptlk/F4/s;)V", "", "Ldbxyzptlk/sz/a;", "signatureRequests", "Ldbxyzptlk/pI/D;", "d", "(Ljava/util/List;Ldbxyzptlk/tI/d;)Ljava/lang/Object;", "c", "a", "(Ldbxyzptlk/tI/d;)Ljava/lang/Object;", "b", "()V", "Ldbxyzptlk/eK/i;", "getAll", "()Ldbxyzptlk/eK/i;", "Ldbxyzptlk/F4/s;", "Ldbxyzptlk/F4/j;", "Ldbxyzptlk/F4/j;", "__insertionAdapterOfLocalSignatureRequest", "Ldbxyzptlk/sz/d;", "Ldbxyzptlk/sz/d;", "__signatureRequestConverters", "Ldbxyzptlk/F4/A;", "Ldbxyzptlk/F4/A;", "__preparedStmtOfDeleteAll", "e", "dbapp_signature-requests_impl_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class a implements e {
  public static final c e = new c(null);
  
  public static final int f = 8;
  
  public final s a;
  
  public final j<dbxyzptlk.sz.a> b;
  
  public final d c = new d();
  
  public final A d;
  
  public a(s params) {
    this.a = params;
    this.b = new a(params, this);
    this.d = new b(params);
  }
  
  public Object a(d<? super D> paramd) {
    Object object = androidx.room.a.a.c(this.a, true, (Callable)new d(this), paramd);
    return (object == dbxyzptlk.uI.c.g()) ? object : D.a;
  }
  
  public void b() {
    X x = g1.o();
    if (x != null) {
      x = x.z("db.sql.room", "com.dropbox.product.dbapp.signature_requests.impl.data.SignatureRequestDao");
    } else {
      x = null;
    } 
    this.a.d();
    k k = this.d.b();
    try {
      this.a.e();
      try {
        k.Z();
        this.a.H();
        if (x != null)
          x.a(B.OK); 
      } finally {
        Exception exception;
      } 
      this.a.j();
      if (x != null)
        x.finish(); 
    } finally {}
    this.d.h(k);
  }
  
  public Object c(List<dbxyzptlk.sz.a> paramList, d<? super D> paramd) {
    Object object = f.d(this.a, (l)new e(this, paramList, null), paramd);
    return (object == dbxyzptlk.uI.c.g()) ? object : D.a;
  }
  
  public Object d(List<dbxyzptlk.sz.a> paramList, d<? super D> paramd) {
    Object object = androidx.room.a.a.c(this.a, true, (Callable)new g(this, paramList), paramd);
    return (object == dbxyzptlk.uI.c.g()) ? object : D.a;
  }
  
  public i<List<dbxyzptlk.sz.a>> getAll() {
    v v = v.i.a("SELECT * FROM signature_request", 0);
    androidx.room.a.a a1 = androidx.room.a.a;
    s s1 = this.a;
    f f = new f(this, v);
    return a1.a(s1, false, new String[] { "signature_request" }, (Callable)f);
  }
  
  @Metadata(d1 = {"\000%\n\000\n\002\030\002\n\002\030\002\n\002\020\016\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\003*\001\000\b\n\030\0002\b\022\004\022\0020\0020\001J\017\020\004\032\0020\003H\024¢\006\004\b\004\020\005J\037\020\n\032\0020\t2\006\020\007\032\0020\0062\006\020\b\032\0020\002H\024¢\006\004\b\n\020\013¨\006\f"}, d2 = {"com/dropbox/product/dbapp/signature_requests/impl/data/a$a", "Ldbxyzptlk/F4/j;", "Ldbxyzptlk/sz/a;", "", "e", "()Ljava/lang/String;", "Ldbxyzptlk/L4/k;", "statement", "entity", "Ldbxyzptlk/pI/D;", "o", "(Ldbxyzptlk/L4/k;Ldbxyzptlk/sz/a;)V", "dbapp_signature-requests_impl_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
  public static final class a extends j<dbxyzptlk.sz.a> {
    public final a d;
    
    public a(s param1s, a param1a) {
      super(param1s);
    }
    
    public String e() {
      return "INSERT OR REPLACE INTO `signature_request` (`id`,`title`,`status`,`sentAt`,`recipients`,`requesterEmailAddress`,`message`) VALUES (?,?,?,?,?,?,?)";
    }
    
    public void o(k param1k, dbxyzptlk.sz.a param1a) {
      s.h(param1k, "statement");
      s.h(param1a, "entity");
      param1k.I0(1, param1a.a());
      param1k.I0(2, param1a.g());
      param1k.I0(3, a.j(this.d).b(param1a.f()));
      LocalDateTime localDateTime = param1a.e();
      String str = a.j(this.d).d(localDateTime);
      if (str == null) {
        param1k.j1(4);
      } else {
        param1k.I0(4, str);
      } 
      param1k.I0(5, a.j(this.d).a(param1a.c()));
      param1k.I0(6, param1a.d());
      param1k.I0(7, param1a.b());
    }
  }
  
  @Metadata(d1 = {"\000\021\n\000\n\002\030\002\n\002\020\016\n\002\b\003*\001\000\b\n\030\0002\0020\001J\017\020\003\032\0020\002H\026¢\006\004\b\003\020\004¨\006\005"}, d2 = {"com/dropbox/product/dbapp/signature_requests/impl/data/a$b", "Ldbxyzptlk/F4/A;", "", "e", "()Ljava/lang/String;", "dbapp_signature-requests_impl_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
  public static final class b extends A {
    public b(s param1s) {
      super(param1s);
    }
    
    public String e() {
      return "DELETE FROM signature_request";
    }
  }
  
  @Metadata(d1 = {"\000\030\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020 \n\002\030\002\n\002\b\003\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\031\020\006\032\f\022\b\022\006\022\002\b\0030\0050\004H\007¢\006\004\b\006\020\007¨\006\b"}, d2 = {"Lcom/dropbox/product/dbapp/signature_requests/impl/data/a$c;", "", "<init>", "()V", "", "Ljava/lang/Class;", "a", "()Ljava/util/List;", "dbapp_signature-requests_impl_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
  public static final class c {
    public c() {}
    
    public final List<Class<?>> a() {
      return s.m();
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\product\dbapp\signature_requests\impl\data\a.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */