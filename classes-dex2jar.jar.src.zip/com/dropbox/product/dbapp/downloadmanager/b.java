package com.dropbox.product.dbapp.downloadmanager;

import android.content.Context;
import com.dropbox.common.taskqueue.TaskQueue;
import com.dropbox.common.taskqueue.TaskResult;
import com.dropbox.common.taskqueue.c;
import com.dropbox.product.android.dbapp.filecache.WriteableFileCacheManager;
import com.dropbox.product.dbapp.entry.DropboxLocalEntry;
import com.dropbox.product.dbapp.entry.LocalEntry;
import com.dropbox.product.dbapp.file_manager.status.c;
import com.dropbox.product.dbapp.path.Path;
import dbxyzptlk.CC.p;
import dbxyzptlk.CC.q;
import dbxyzptlk.Ec.g;
import dbxyzptlk.Nq.W;
import dbxyzptlk.Ow.c;
import dbxyzptlk.Ow.g;
import dbxyzptlk.Pw.k;
import dbxyzptlk.Sq.k;
import dbxyzptlk.Xs.L;
import dbxyzptlk.iy.t;
import dbxyzptlk.pj.m;
import dbxyzptlk.rx.d;
import dbxyzptlk.rx.f;
import dbxyzptlk.rx.g;
import dbxyzptlk.vq.g;
import dbxyzptlk.xx.f;
import dbxyzptlk.xx.g;
import dbxyzptlk.ye.k0;
import java.util.List;

public class b<P extends Path> {
  public final Context a;
  
  public final g b;
  
  public final WriteableFileCacheManager<P> c;
  
  public final d<P> d;
  
  public final t<P> e;
  
  public final L f;
  
  public final g<P> g;
  
  public final dbxyzptlk.Fj.a<P> h;
  
  public final g i;
  
  public final m j;
  
  public final k0 k;
  
  public final k l;
  
  public final g m;
  
  public final W n;
  
  public final TaskQueue<AbstractDownloadTask<P>> o;
  
  public final TaskQueue<AbstractDownloadTask<P>> p;
  
  public b(Context paramContext, g paramg, WriteableFileCacheManager<P> paramWriteableFileCacheManager, d<P> paramd, t<P> paramt, L paramL, g<P> paramg1, dbxyzptlk.Fj.a<P> parama, dbxyzptlk.t6.b paramb, g paramg2, m paramm, k paramk, g paramg3, k0 paramk0, W paramW) {
    this.a = (Context)p.o(paramContext);
    this.b = (g)p.o(paramg);
    this.c = (WriteableFileCacheManager<P>)p.o(paramWriteableFileCacheManager);
    this.d = (d<P>)p.o(paramd);
    this.e = (t<P>)p.o(paramt);
    this.f = (L)p.o(paramL);
    this.g = (g<P>)p.o(paramg1);
    this.h = (dbxyzptlk.Fj.a<P>)p.o(parama);
    this.i = (g)p.o(paramg2);
    this.j = (m)p.o(paramm);
    this.l = (k)p.o(paramk);
    this.m = paramg3;
    this.k = (k0)p.o(paramk0);
    this.n = (W)p.o(paramW);
    p.o(paramb);
    e<AbstractDownloadTask<?>> e = new e<>(paramb, 1, 4);
    this.o = (TaskQueue)e;
    this.p = new e<>(paramb, 1, 4);
    e.r(new a(this));
  }
  
  public g<P> c(f<P> paramf, dbxyzptlk.rx.a parama) {
    dbxyzptlk.Fe.b.b();
    p.o(paramf.b());
    p.o(parama);
    d d1 = new d(parama);
    DownloadTask<P> downloadTask = h(paramf, (dbxyzptlk.rx.b<P>)d1);
    if (downloadTask == null)
      return g.d(TaskResult.b.DUPLICATE_DOWNLOAD); 
    try {
      d1.e.await();
      return (g<P>)p.o(d1.f);
    } catch (InterruptedException interruptedException) {
      Thread.interrupted();
      if (!d1.b)
        downloadTask.c(); 
      d1.e();
      return g.d(TaskResult.b.CANCELED);
    } 
  }
  
  public void d() {
    this.o.i();
    this.p.i();
  }
  
  public void e(P paramP) {
    p.o(paramP);
    f(paramP);
    g(paramP);
    if (paramP.q0()) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(paramP.q1());
      stringBuilder.append("/");
      String str = stringBuilder.toString();
      this.o.s((q)new c(this, str));
    } 
  }
  
  public void f(P paramP) {
    this.o.t(AbstractDownloadTask.v((Path)p.o(paramP)));
  }
  
  public void g(P paramP) {
    this.p.t(AbstractDownloadTask.v((Path)p.o(paramP)));
  }
  
  public final DownloadTask<P> h(f<P> paramf, dbxyzptlk.rx.b<P> paramb) {
    DownloadTask<P> downloadTask = i(paramf);
    downloadTask.a((c.a)new b(this, downloadTask, paramb));
    downloadTask.z(paramf.d());
    if (paramf.e()) {
      this.p.i();
      this.p.e((TaskQueue.BaseTask)downloadTask);
    } else {
      boolean bool;
      if (!this.o.e((TaskQueue.BaseTask)downloadTask))
        return null; 
      LocalEntry localEntry = paramf.b();
      if (localEntry instanceof DropboxLocalEntry && ((DropboxLocalEntry)localEntry).J2()) {
        bool = true;
      } else {
        bool = false;
      } 
      if (this.l.f(localEntry.s().getName()) && !bool) {
        c c;
        dbxyzptlk.Ow.e e2 = new dbxyzptlk.Ow.e(localEntry.s(), k.f());
        Path path = localEntry.s();
        if (this.n.isEnabled()) {
          c = k.d();
        } else {
          c = k.e(this.a);
        } 
        dbxyzptlk.Ow.e e1 = new dbxyzptlk.Ow.e(path, c);
        if (paramf.c()) {
          this.g.h(g.a.THUMB, e2, localEntry.t());
          this.g.h(g.a.GALLERY, e1, localEntry.t());
        } else {
          this.g.f(g.a.THUMB, e2, localEntry.t());
          this.g.f(g.a.GALLERY, e1, localEntry.t());
        } 
      } 
      if (this.l.g(localEntry.s().getName()))
        if (paramf.c()) {
          this.h.d(localEntry.s(), localEntry.t());
        } else {
          this.h.b(localEntry.s(), localEntry.t());
        }  
    } 
    return downloadTask;
  }
  
  public final DownloadTask<P> i(f<P> paramf) {
    p.o(paramf);
    return new DownloadTask(this.a, this.k, paramf.b().s(), paramf.b().n(), this.d, this.c, this.f, this.e, this.i, this.j, paramf.a(), this.m);
  }
  
  public class a implements dbxyzptlk.Fj.b<AbstractDownloadTask<P>> {
    public final b a;
    
    public a(b this$0) {}
    
    public void c(AbstractDownloadTask<P> param1AbstractDownloadTask) {
      try {
        p.o(param1AbstractDownloadTask);
        c c = param1AbstractDownloadTask.q().newInstance();
        f f = new f();
        this(b.b(this.a), c);
        param1AbstractDownloadTask.a((c.a)f);
        List list = param1AbstractDownloadTask.f();
        dbxyzptlk.Fj.e[] arrayOfE = (dbxyzptlk.Fj.e[])list.toArray((Object[])new dbxyzptlk.Fj.e[list.size()]);
        if (b.b(this.a).g((com.dropbox.product.dbapp.file_manager.status.b)c, arrayOfE))
          return; 
        b.b(this.a).h((com.dropbox.product.dbapp.file_manager.status.b)c, arrayOfE);
        RuntimeException runtimeException = new RuntimeException();
        this("Failed to set status");
        throw runtimeException;
      } catch (IllegalAccessException illegalAccessException) {
      
      } catch (InstantiationException instantiationException) {}
      dbxyzptlk.sL.a.h(instantiationException);
      throw new RuntimeException("Failed to set status", instantiationException);
    }
    
    public void d(AbstractDownloadTask<P> param1AbstractDownloadTask, TaskResult param1TaskResult) {}
  }
  
  class b {}
  
  public static class e<T extends AbstractDownloadTask<?>> extends TaskQueue<T> {
    public e(dbxyzptlk.t6.b param1b, int param1Int1, int param1Int2) {
      super((dbxyzptlk.t6.b)p.o(param1b), param1Int1, param1Int2);
    }
    
    public boolean A(T param1T, boolean param1Boolean) {
      // Byte code:
      //   0: aload_0
      //   1: monitorenter
      //   2: aload_1
      //   3: invokevirtual m : ()I
      //   6: istore_3
      //   7: iconst_1
      //   8: istore #4
      //   10: iload_3
      //   11: iconst_1
      //   12: if_icmpne -> 18
      //   15: goto -> 21
      //   18: iconst_0
      //   19: istore #4
      //   21: iload #4
      //   23: invokestatic d : (Z)V
      //   26: aload_0
      //   27: aload_1
      //   28: iload_2
      //   29: invokespecial f : (Lcom/dropbox/common/taskqueue/TaskQueue$BaseTask;Z)Z
      //   32: istore_2
      //   33: aload_0
      //   34: monitorexit
      //   35: iload_2
      //   36: ireturn
      //   37: astore_1
      //   38: aload_0
      //   39: monitorexit
      //   40: aload_1
      //   41: athrow
      // Exception table:
      //   from	to	target	type
      //   2	7	37	finally
      //   21	33	37	finally
      //   38	40	37	finally
    }
    
    public void B(T param1T, boolean param1Boolean, TaskResult.b param1b) {}
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\product\dbapp\downloadmanager\b.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */