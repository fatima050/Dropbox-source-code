package com.dropbox.product.dbapp.progressive_onboarding.view;

import dbxyzptlk.DI.s;
import dbxyzptlk.rh.b;
import dbxyzptlk.rh.i;
import dbxyzptlk.sh.b;
import dbxyzptlk.wI.b;
import kotlin.Metadata;
import kotlin.NoWhenBranchMatchedException;

@Metadata(d1 = {"\000 \n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\005\bÇ\002\030\0002\0020\001:\001\nB\t\b\002¢\006\004\b\002\020\003J\021\020\006\032\0020\005*\0020\004¢\006\004\b\006\020\007R \020\f\032\b\022\004\022\0020\0050\b8\006X\004¢\006\f\n\004\b\006\020\t\032\004\b\n\020\013¨\006\r"}, d2 = {"Lcom/dropbox/product/dbapp/progressive_onboarding/view/c;", "", "<init>", "()V", "Ldbxyzptlk/sh/b;", "Lcom/dropbox/product/dbapp/progressive_onboarding/view/c$a;", "b", "(Ldbxyzptlk/sh/b;)Lcom/dropbox/product/dbapp/progressive_onboarding/view/c$a;", "Ldbxyzptlk/rh/a;", "Ldbxyzptlk/rh/a;", "a", "()Ldbxyzptlk/rh/a;", "onboardingEmailVerificationFeatureGate", "dbapp_progressive_onboarding_impl_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class c {
  public static final c a = new c();
  
  public static final dbxyzptlk.rh.a<a> b = new dbxyzptlk.rh.a("mobile_mae_onboarding_email_verification", a.class);
  
  public static final int c = 8;
  
  public final dbxyzptlk.rh.a<a> a() {
    return b;
  }
  
  public final a b(b paramb) {
    a a1;
    boolean bool;
    s.h(paramb, "<this>");
    i i = paramb.k(b);
    if (i instanceof i.a) {
      bool = true;
    } else {
      bool = i instanceof i.c;
    } 
    if (bool) {
      a1 = a.OFF;
    } else {
      if (a1 instanceof i.b)
        return (a)((i.b)a1).a(); 
      throw new NoWhenBranchMatchedException();
    } 
    return a1;
  }
  
  @Metadata(d1 = {"\000\020\n\002\030\002\n\002\020\020\n\002\030\002\n\002\b\006\b\002\030\0002\b\022\004\022\0020\0000\0012\0020\002B\t\b\002¢\006\004\b\003\020\004j\002\b\005j\002\b\006j\002\b\007¨\006\b"}, d2 = {"Lcom/dropbox/product/dbapp/progressive_onboarding/view/c$a;", "", "Ldbxyzptlk/rh/b;", "<init>", "(Ljava/lang/String;I)V", "CONTROL", "OFF", "V1", "dbapp_progressive_onboarding_impl_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
  public enum a implements b {
    CONTROL, OFF, V1;
    
    private static final dbxyzptlk.wI.a $ENTRIES;
    
    private static final a[] $VALUES;
    
    static {
      a[] arrayOfA = a();
      $VALUES = arrayOfA;
      $ENTRIES = b.a((Enum[])arrayOfA);
    }
    
    public static dbxyzptlk.wI.a<a> getEntries() {
      return $ENTRIES;
    }
    
    public String getCaseSensitiveVariantName() {
      return b.a.a(this);
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\product\dbapp\progressive_onboarding\view\c.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */