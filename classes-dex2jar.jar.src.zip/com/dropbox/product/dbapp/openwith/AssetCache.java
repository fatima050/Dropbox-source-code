package com.dropbox.product.dbapp.openwith;

import com.google.common.collect.m;
import com.google.common.collect.q;
import dbxyzptlk.CC.p;
import java.io.File;
import java.io.InputStream;
import java.util.Map;
import java.util.Set;

public class AssetCache {
  public final File a;
  
  public final Map<String, a> b = q.g();
  
  public AssetCache(File paramFile) {
    this.a = paramFile;
  }
  
  public static boolean d(File paramFile) {
    boolean bool;
    dbxyzptlk.Fe.b.b();
    if (paramFile.exists() && paramFile.isFile()) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public boolean c(String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: new java/io/File
    //   5: astore_3
    //   6: aload_3
    //   7: aload_0
    //   8: getfield a : Ljava/io/File;
    //   11: aload_1
    //   12: invokespecial <init> : (Ljava/io/File;Ljava/lang/String;)V
    //   15: aload_3
    //   16: invokestatic d : (Ljava/io/File;)Z
    //   19: istore_2
    //   20: aload_0
    //   21: monitorexit
    //   22: iload_2
    //   23: ireturn
    //   24: astore_1
    //   25: aload_0
    //   26: monitorexit
    //   27: aload_1
    //   28: athrow
    // Exception table:
    //   from	to	target	type
    //   2	20	24	finally
    //   25	27	24	finally
  }
  
  public final File e(String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: invokestatic b : ()V
    //   5: new java/io/File
    //   8: astore_3
    //   9: aload_3
    //   10: aload_0
    //   11: getfield a : Ljava/io/File;
    //   14: aload_1
    //   15: invokespecial <init> : (Ljava/io/File;Ljava/lang/String;)V
    //   18: aload_3
    //   19: invokevirtual getParentFile : ()Ljava/io/File;
    //   22: invokestatic q : (Ljava/io/File;)Z
    //   25: istore_2
    //   26: iload_2
    //   27: ifne -> 34
    //   30: aload_0
    //   31: monitorexit
    //   32: aconst_null
    //   33: areturn
    //   34: aload_0
    //   35: monitorexit
    //   36: aload_3
    //   37: areturn
    //   38: astore_1
    //   39: aload_0
    //   40: monitorexit
    //   41: aload_1
    //   42: athrow
    // Exception table:
    //   from	to	target	type
    //   2	26	38	finally
    //   39	41	38	finally
  }
  
  public Set<String> f() {
    Exception exception;
    /* monitor enter ThisExpression{ObjectType{com/dropbox/product/dbapp/openwith/AssetCache}} */
    try {
      dbxyzptlk.Fe.b.b();
      m.a a = m.w();
      File[] arrayOfFile = this.a.listFiles();
      if (arrayOfFile != null) {
        int i = arrayOfFile.length;
        for (byte b = 0; b < i; b++)
          a.i(arrayOfFile[b].getName()); 
      } 
    } finally {}
    m m = exception.m();
    /* monitor exit ThisExpression{ObjectType{com/dropbox/product/dbapp/openwith/AssetCache}} */
    return (Set<String>)m;
  }
  
  public InputStream g(String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: invokestatic b : ()V
    //   5: new java/io/File
    //   8: astore_3
    //   9: aload_3
    //   10: aload_0
    //   11: getfield a : Ljava/io/File;
    //   14: aload_1
    //   15: invokespecial <init> : (Ljava/io/File;Ljava/lang/String;)V
    //   18: aload_3
    //   19: invokestatic d : (Ljava/io/File;)Z
    //   22: istore_2
    //   23: iload_2
    //   24: ifne -> 31
    //   27: aload_0
    //   28: monitorexit
    //   29: aconst_null
    //   30: areturn
    //   31: new java/io/FileInputStream
    //   34: astore_1
    //   35: aload_1
    //   36: aload_3
    //   37: invokespecial <init> : (Ljava/io/File;)V
    //   40: aload_1
    //   41: aload_3
    //   42: invokestatic a : (Ljava/io/FileInputStream;Ljava/io/File;)Ljava/io/FileInputStream;
    //   45: astore_1
    //   46: aload_0
    //   47: monitorexit
    //   48: aload_1
    //   49: areturn
    //   50: astore_1
    //   51: goto -> 59
    //   54: astore_1
    //   55: aload_0
    //   56: monitorexit
    //   57: aconst_null
    //   58: areturn
    //   59: aload_0
    //   60: monitorexit
    //   61: aload_1
    //   62: athrow
    // Exception table:
    //   from	to	target	type
    //   2	23	50	finally
    //   31	46	54	java/io/FileNotFoundException
    //   31	46	50	finally
    //   59	61	50	finally
  }
  
  public a h(String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_1
    //   3: invokestatic o : (Ljava/lang/Object;)Ljava/lang/Object;
    //   6: pop
    //   7: new com/dropbox/product/dbapp/openwith/AssetCache$a
    //   10: astore #4
    //   12: aload #4
    //   14: aload_0
    //   15: aload_1
    //   16: invokespecial <init> : (Lcom/dropbox/product/dbapp/openwith/AssetCache;Ljava/lang/String;)V
    //   19: aload_0
    //   20: getfield b : Ljava/util/Map;
    //   23: aload_1
    //   24: invokeinterface containsKey : (Ljava/lang/Object;)Z
    //   29: istore_2
    //   30: new java/lang/StringBuilder
    //   33: astore_3
    //   34: aload_3
    //   35: invokespecial <init> : ()V
    //   38: aload_3
    //   39: ldc 'Can't open a second writer for '
    //   41: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   44: pop
    //   45: aload_3
    //   46: aload_1
    //   47: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   50: pop
    //   51: iload_2
    //   52: iconst_1
    //   53: ixor
    //   54: ldc 'Assert failed: %1$s'
    //   56: aload_3
    //   57: invokevirtual toString : ()Ljava/lang/String;
    //   60: invokestatic j : (ZLjava/lang/String;Ljava/lang/Object;)V
    //   63: aload_0
    //   64: getfield b : Ljava/util/Map;
    //   67: aload_1
    //   68: aload #4
    //   70: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   75: pop
    //   76: aload_0
    //   77: monitorexit
    //   78: aload #4
    //   80: areturn
    //   81: astore_1
    //   82: goto -> 90
    //   85: astore_1
    //   86: aload_0
    //   87: monitorexit
    //   88: aconst_null
    //   89: areturn
    //   90: aload_0
    //   91: monitorexit
    //   92: aload_1
    //   93: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	81	finally
    //   7	19	85	com/dropbox/product/dbapp/openwith/AssetCache$b
    //   7	19	81	finally
    //   19	76	81	finally
    //   90	92	81	finally
  }
  
  public final void i(a parama) {
    /* monitor enter ThisExpression{ObjectType{com/dropbox/product/dbapp/openwith/AssetCache}} */
    try {
      p.o(parama);
      str = a.a(parama);
      a a1 = this.b.get(str);
      if (a1 != null) {
        boolean bool = a1.equals(parama);
        StringBuilder stringBuilder1 = new StringBuilder();
        this();
        stringBuilder1.append("Existing asset writer ");
        stringBuilder1.append(a1);
        stringBuilder1.append(" doesn't match released ");
        stringBuilder1.append(parama);
        p.j(bool, "Assert failed: %1$s", stringBuilder1.toString());
        this.b.remove(str);
        /* monitor exit ThisExpression{ObjectType{com/dropbox/product/dbapp/openwith/AssetCache}} */
        return;
      } 
    } finally {}
    IllegalStateException illegalStateException = new IllegalStateException();
    StringBuilder stringBuilder = new StringBuilder();
    this();
    String str;
    stringBuilder.append("No outstanding asset writer for ");
    stringBuilder.append(str);
    this(stringBuilder.toString());
    throw illegalStateException;
  }
  
  public void j(String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: invokestatic b : ()V
    //   5: new java/io/File
    //   8: astore_2
    //   9: aload_2
    //   10: aload_0
    //   11: getfield a : Ljava/io/File;
    //   14: aload_1
    //   15: invokespecial <init> : (Ljava/io/File;Ljava/lang/String;)V
    //   18: aload_2
    //   19: invokestatic e : (Ljava/io/File;)Z
    //   22: pop
    //   23: aload_0
    //   24: monitorexit
    //   25: return
    //   26: astore_1
    //   27: aload_0
    //   28: monitorexit
    //   29: aload_1
    //   30: athrow
    // Exception table:
    //   from	to	target	type
    //   2	23	26	finally
    //   27	29	26	finally
  }
  
  class AssetCache {}
  
  class AssetCache {}
  
  public static class b extends Exception {
    private static final long serialVersionUID = 2145613924141915991L;
    
    public b() {}
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\product\dbapp\openwith\AssetCache.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */