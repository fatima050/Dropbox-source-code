package com.dropbox.product.dbapp.openwith;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import com.dropbox.common.taskqueue.TaskQueue;
import com.dropbox.common.taskqueue.b;
import com.google.common.collect.q;
import com.google.common.collect.z;
import dbxyzptlk.CC.e;
import dbxyzptlk.CC.p;
import dbxyzptlk.EC.b0;
import dbxyzptlk.Fe.b;
import dbxyzptlk.GC.h;
import dbxyzptlk.HK.e;
import dbxyzptlk.pj.m;
import dbxyzptlk.sL.a;
import dbxyzptlk.t6.b;
import java.io.File;
import java.io.InputStream;
import java.util.Collection;
import java.util.HashMap;
import java.util.Set;
import okhttp3.OkHttpClient;

public class AssetStore {
  public final AssetCache a;
  
  public final OkHttpClient b;
  
  public final b<AssetDownloadTask> c;
  
  public AssetStore(File paramFile, OkHttpClient paramOkHttpClient, m paramm, b paramb) {
    this.a = new AssetCache(paramFile);
    this.b = paramOkHttpClient;
    this.c = new b(paramb, 1, 4, paramm);
  }
  
  public static String c(Uri paramUri) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("asset_cache_sha256_");
    stringBuilder.append(h.c().a(paramUri.toString(), e.c).toString());
    return stringBuilder.toString();
  }
  
  public static Bitmap f(InputStream paramInputStream) {
    p.o(paramInputStream);
    try {
      return BitmapFactory.decodeStream(paramInputStream);
    } finally {
      e.b(paramInputStream);
    } 
  }
  
  public final void a(Uri paramUri) {
    this.c.e((TaskQueue.BaseTask)new AssetDownloadTask(this.b, paramUri, this.a));
  }
  
  public Bitmap b(Uri paramUri) {
    b.b();
    InputStream inputStream = this.a.g(c(paramUri));
    return (inputStream != null) ? f(inputStream) : null;
  }
  
  public boolean d(Uri paramUri) {
    b.b();
    return this.a.c(c(paramUri));
  }
  
  public void e(Collection<Uri> paramCollection) {
    HashMap<String, Uri> hashMap;
    Set<String> set;
    /* monitor enter ThisExpression{ObjectType{com/dropbox/product/dbapp/openwith/AssetStore}} */
    try {
      b.b();
      hashMap = q.g();
      for (Uri uri : paramCollection)
        hashMap.put(c(uri), uri); 
    } finally {}
    AssetCache assetCache = this.a;
    /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{com/dropbox/product/dbapp/openwith/AssetCache}, name=null} */
    try {
      set = this.a.f();
      b0<String> b01 = z.a(set, hashMap.keySet()).b();
      while (b01.hasNext()) {
        String str = b01.next();
        this.a.j(str);
      } 
    } finally {}
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{com/dropbox/product/dbapp/openwith/AssetCache}, name=null} */
    b0<String> b0 = z.a(hashMap.keySet(), set).b();
    while (b0.hasNext()) {
      Uri uri = hashMap.get(b0.next());
      a.d("Queueing asset for download:  %s", new Object[] { uri });
      a(uri);
    } 
    /* monitor exit ThisExpression{ObjectType{com/dropbox/product/dbapp/openwith/AssetStore}} */
  }
  
  class AssetStore {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\product\dbapp\openwith\AssetStore.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */