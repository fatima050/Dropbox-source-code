package com.dropbox.product.dbapp.openwith;

import dbxyzptlk.Wa.d;
import dbxyzptlk.wI.b;
import kotlin.Metadata;

@Metadata(d1 = {"\000 \n\002\030\002\n\002\020\000\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\007\bf\030\0002\0020\001:\001\017J\021\020\003\032\004\030\0010\002H&¢\006\004\b\003\020\004J\027\020\007\032\0020\0062\006\020\005\032\0020\002H&¢\006\004\b\007\020\bR\034\020\016\032\0020\t8&@&X¦\016¢\006\f\032\004\b\n\020\013\"\004\b\f\020\rø\001\000\002\006\n\004\b!0\001¨\006\020À\006\001"}, d2 = {"Lcom/dropbox/product/dbapp/openwith/c;", "", "Ldbxyzptlk/Wa/d;", "h", "()Ldbxyzptlk/Wa/d;", "data", "Ldbxyzptlk/pI/D;", "j", "(Ldbxyzptlk/Wa/d;)V", "Lcom/dropbox/product/dbapp/openwith/c$a;", "i", "()Lcom/dropbox/product/dbapp/openwith/c$a;", "setWopiSetting", "(Lcom/dropbox/product/dbapp/openwith/c$a;)V", "wopiSetting", "a", "dbapp_openwith_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
public interface c {
  d h();
  
  a i();
  
  void j(d paramd);
  
  @Metadata(d1 = {"\000\f\n\002\030\002\n\002\020\020\n\002\b\006\b\002\030\0002\b\022\004\022\0020\0000\001B\t\b\002¢\006\004\b\002\020\003j\002\b\004j\002\b\005j\002\b\006¨\006\007"}, d2 = {"Lcom/dropbox/product/dbapp/openwith/c$a;", "", "<init>", "(Ljava/lang/String;I)V", "USE_WOPI_WHEN_AVAILABLE", "ALWAYS_USE_WOPI", "ALWAYS_USE_OPEN_WITH", "dbapp_openwith_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
  public enum a {
    ALWAYS_USE_OPEN_WITH, ALWAYS_USE_WOPI, USE_WOPI_WHEN_AVAILABLE;
    
    private static final dbxyzptlk.wI.a $ENTRIES;
    
    private static final a[] $VALUES;
    
    static {
      ALWAYS_USE_OPEN_WITH = new a("ALWAYS_USE_OPEN_WITH", 2);
      a[] arrayOfA = a();
      $VALUES = arrayOfA;
      $ENTRIES = b.a((Enum[])arrayOfA);
    }
    
    public static dbxyzptlk.wI.a<a> getEntries() {
      return $ENTRIES;
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\product\dbapp\openwith\c.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */