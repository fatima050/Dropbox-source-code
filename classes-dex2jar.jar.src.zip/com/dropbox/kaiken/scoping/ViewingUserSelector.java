package com.dropbox.kaiken.scoping;

import android.os.Parcel;
import android.os.Parcelable;
import dbxyzptlk.DI.s;
import kotlin.Metadata;

@Metadata(d1 = {"\0006\n\002\030\002\n\002\030\002\n\002\020\016\n\002\b\005\n\002\020\b\n\002\b\002\n\002\020\000\n\000\n\002\020\013\n\002\b\003\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\006\b\b\030\000 \0312\0020\001:\001\027B\017\022\006\020\003\032\0020\002¢\006\004\b\004\020\005J\020\020\006\032\0020\002HÖ\001¢\006\004\b\006\020\007J\020\020\t\032\0020\bHÖ\001¢\006\004\b\t\020\nJ\032\020\016\032\0020\r2\b\020\f\032\004\030\0010\013HÖ\003¢\006\004\b\016\020\017J\020\020\020\032\0020\bHÖ\001¢\006\004\b\020\020\nJ \020\025\032\0020\0242\006\020\022\032\0020\0212\006\020\023\032\0020\bHÖ\001¢\006\004\b\025\020\026R\032\020\003\032\0020\0028\000X\004¢\006\f\n\004\b\027\020\030\032\004\b\031\020\007¨\006\032"}, d2 = {"Lcom/dropbox/kaiken/scoping/ViewingUserSelector;", "Landroid/os/Parcelable;", "", "userId", "<init>", "(Ljava/lang/String;)V", "toString", "()Ljava/lang/String;", "", "hashCode", "()I", "", "other", "", "equals", "(Ljava/lang/Object;)Z", "describeContents", "Landroid/os/Parcel;", "parcel", "flags", "Ldbxyzptlk/pI/D;", "writeToParcel", "(Landroid/os/Parcel;I)V", "a", "Ljava/lang/String;", "b", "common_kaiken_scoping_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class ViewingUserSelector implements Parcelable {
  public static final Parcelable.Creator<ViewingUserSelector> CREATOR;
  
  public static final a b = new a(null);
  
  public final String a;
  
  static {
    CREATOR = (Parcelable.Creator<ViewingUserSelector>)new b();
  }
  
  public ViewingUserSelector(String paramString) {
    this.a = paramString;
  }
  
  public static final ViewingUserSelector a(String paramString) {
    return b.a(paramString);
  }
  
  public final String b() {
    return this.a;
  }
  
  public int describeContents() {
    return 0;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof ViewingUserSelector))
      return false; 
    paramObject = paramObject;
    return !!s.c(this.a, ((ViewingUserSelector)paramObject).a);
  }
  
  public int hashCode() {
    return this.a.hashCode();
  }
  
  public String toString() {
    String str = this.a;
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("ViewingUserSelector(userId=");
    stringBuilder.append(str);
    stringBuilder.append(")");
    return stringBuilder.toString();
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    s.h(paramParcel, "out");
    paramParcel.writeString(this.a);
  }
  
  class ViewingUserSelector {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\kaiken\scoping\ViewingUserSelector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */