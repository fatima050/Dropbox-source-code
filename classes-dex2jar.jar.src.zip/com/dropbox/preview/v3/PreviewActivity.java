package com.dropbox.preview.v3;

import android.app.Activity;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import androidx.activity.ComponentActivity;
import androidx.activity.result.ActivityResult;
import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.e;
import androidx.lifecycle.i;
import androidx.lifecycle.s;
import androidx.lifecycle.t;
import com.dropbox.common.activity.BaseActivity;
import com.google.android.material.snackbar.Snackbar;
import dbxyzptlk.Bf.c;
import dbxyzptlk.Bf.d;
import dbxyzptlk.CI.a;
import dbxyzptlk.CI.p;
import dbxyzptlk.DI.L;
import dbxyzptlk.DI.s;
import dbxyzptlk.Et.a;
import dbxyzptlk.F0.c;
import dbxyzptlk.Fq.f;
import dbxyzptlk.Ij.s;
import dbxyzptlk.Nq.X;
import dbxyzptlk.Nq.Y;
import dbxyzptlk.Nq.a;
import dbxyzptlk.Nq.a0;
import dbxyzptlk.Nq.b0;
import dbxyzptlk.Nq.c0;
import dbxyzptlk.Nq.d;
import dbxyzptlk.Sq.P;
import dbxyzptlk.U2.i;
import dbxyzptlk.U2.z;
import dbxyzptlk.V6.c;
import dbxyzptlk.Wq.j;
import dbxyzptlk.Wq.p;
import dbxyzptlk.bK.J;
import dbxyzptlk.bK.h;
import dbxyzptlk.eK.C;
import dbxyzptlk.eK.U;
import dbxyzptlk.f.e;
import dbxyzptlk.h.a;
import dbxyzptlk.h.b;
import dbxyzptlk.h2.v0;
import dbxyzptlk.i.a;
import dbxyzptlk.i.d;
import dbxyzptlk.pI.j;
import dbxyzptlk.pI.k;
import dbxyzptlk.rr.f;
import dbxyzptlk.rr.h;
import dbxyzptlk.rr.i;
import dbxyzptlk.rr.k;
import dbxyzptlk.s0.j1;
import dbxyzptlk.sL.a;
import dbxyzptlk.x0.J;
import dbxyzptlk.x0.K0;
import dbxyzptlk.x0.h1;
import dbxyzptlk.x0.k;
import dbxyzptlk.x0.n;
import dbxyzptlk.yj.c;
import dbxyzptlk.yj.e;
import kotlin.Metadata;

@Metadata(d1 = {"\000î\001\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\000\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\020\b\n\002\b\004\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\007\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\t\n\002\030\002\n\002\b\007\n\002\030\002\n\002\b\007\n\002\030\002\n\002\b\007\n\002\030\002\n\002\b\007\n\002\030\002\n\002\b\007\n\002\030\002\n\002\b\007\n\002\030\002\n\002\b\007\n\002\030\002\n\002\b\007\n\002\030\002\n\002\020\013\n\002\b\003\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\003\n\002\b\004\n\002\030\002\n\002\b\005\n\002\030\002\n\000\n\002\030\002\n\002\b\002*\002\001\b\007\030\000 \0012\0020\0012\0020\0022\0020\0032\0020\0042\0020\0052\0020\006:\002\001B\007¢\006\004\b\007\020\bJ!\020\016\032\0020\r2\b\020\n\032\004\030\0010\t2\006\020\f\032\0020\013H\003¢\006\004\b\016\020\017J\017\020\021\032\0020\020H\002¢\006\004\b\021\020\022J#\020\026\032\0020\r2\b\b\001\020\024\032\0020\0232\b\b\001\020\025\032\0020\023H\002¢\006\004\b\026\020\027J\031\020\032\032\0020\r2\b\020\031\032\004\030\0010\030H\024¢\006\004\b\032\020\033J\027\020\036\032\0020\r2\006\020\035\032\0020\034H\007¢\006\004\b\036\020\037J\017\020 \032\0020\rH\024¢\006\004\b \020\bJ\017\020!\032\0020\rH\027¢\006\004\b!\020\bJ\017\020\"\032\0020\rH\024¢\006\004\b\"\020\bJ\017\020#\032\0020\rH\024¢\006\004\b#\020\bJ\017\020%\032\0020$H\026¢\006\004\b%\020&J\031\020)\032\0020\r2\b\020(\032\004\030\0010'H\026¢\006\004\b)\020*J\017\020+\032\0020\rH\026¢\006\004\b+\020\bR\033\0200\032\0020\0058VX\002¢\006\f\n\004\b,\020-\032\004\b.\020/R\"\0208\032\002018\006@\006X.¢\006\022\n\004\b2\0203\032\004\b4\0205\"\004\b6\0207R\"\020@\032\002098\006@\006X.¢\006\022\n\004\b:\020;\032\004\b<\020=\"\004\b>\020?R\"\020H\032\0020A8\006@\006X.¢\006\022\n\004\bB\020C\032\004\bD\020E\"\004\bF\020GR\"\020P\032\0020I8\006@\006X.¢\006\022\n\004\bJ\020K\032\004\bL\020M\"\004\bN\020OR\"\020X\032\0020Q8\006@\006X.¢\006\022\n\004\bR\020S\032\004\bT\020U\"\004\bV\020WR\"\020`\032\0020Y8\006@\006X.¢\006\022\n\004\bZ\020[\032\004\b\\\020]\"\004\b^\020_R\"\020h\032\0020a8\006@\006X.¢\006\022\n\004\bb\020c\032\004\bd\020e\"\004\bf\020gR\"\020p\032\0020i8\006@\006X.¢\006\022\n\004\bj\020k\032\004\bl\020m\"\004\bn\020oR\032\020u\032\b\022\004\022\0020r0q8\002X\004¢\006\006\n\004\bs\020tR\024\020y\032\0020v8\002X\004¢\006\006\n\004\bw\020xR\033\020~\032\0020z8BX\002¢\006\f\n\004\b{\020-\032\004\b|\020}R\037\020\001\032\00208BX\002¢\006\017\n\005\b\001\020-\032\006\b\001\020\001R\034\020\001\032\005\030\0010\0018\002@\002X\016¢\006\b\n\006\b\001\020\001R\030\020\001\032\0030\0018\002X\004¢\006\b\n\006\b\001\020\001R\030\020\001\032\0030\0018VX\004¢\006\b\032\006\b\001\020\001¨\006\001²\006\016\020\001\032\0030\0018\nX\002²\006\r\020\035\032\0030\0018\nX\002²\006\r\020\001\032\0020r8\nX\002"}, d2 = {"Lcom/dropbox/preview/v3/PreviewActivity;", "Lcom/dropbox/common/activity/BaseActivity;", "Ldbxyzptlk/yj/e;", "Landroidx/lifecycle/e;", "Ldbxyzptlk/Fq/f;", "", "Ldbxyzptlk/Bf/d;", "<init>", "()V", "Lcom/dropbox/preview/v3/c$a;", "fileOperationState", "Ldbxyzptlk/s0/j1;", "snackbarHostState", "Ldbxyzptlk/pI/D;", "x4", "(Lcom/dropbox/preview/v3/c$a;Ldbxyzptlk/s0/j1;Ldbxyzptlk/x0/k;I)V", "Ldbxyzptlk/rr/f;", "J4", "()Ldbxyzptlk/rr/f;", "", "enterAnim", "exitAnim", "V4", "(II)V", "Landroid/os/Bundle;", "savedInstanceState", "onCreate", "(Landroid/os/Bundle;)V", "Lcom/dropbox/preview/v3/c$b;", "previewViewState", "y4", "(Lcom/dropbox/preview/v3/c$b;Ldbxyzptlk/x0/k;I)V", "onStart", "onBackPressed", "onDestroy", "onResumeFragments", "Landroid/view/View;", "C0", "()Landroid/view/View;", "Lcom/google/android/material/snackbar/Snackbar;", "snackbar", "f3", "(Lcom/google/android/material/snackbar/Snackbar;)V", "V2", "c", "Ldbxyzptlk/pI/j;", "D3", "()Ljava/lang/Object;", "daggerComponent", "Ldbxyzptlk/Sq/P;", "d", "Ldbxyzptlk/Sq/P;", "T4", "()Ldbxyzptlk/Sq/P;", "d5", "(Ldbxyzptlk/Sq/P;)V", "viewModelFactory", "Ldbxyzptlk/V6/c;", "e", "Ldbxyzptlk/V6/c;", "L4", "()Ldbxyzptlk/V6/c;", "X4", "(Ldbxyzptlk/V6/c;)V", "browserIntentProvider", "Ldbxyzptlk/Ij/s;", "f", "Ldbxyzptlk/Ij/s;", "R4", "()Ldbxyzptlk/Ij/s;", "c5", "(Ldbxyzptlk/Ij/s;)V", "udcl", "Ldbxyzptlk/Nq/a;", "g", "Ldbxyzptlk/Nq/a;", "K4", "()Ldbxyzptlk/Nq/a;", "W4", "(Ldbxyzptlk/Nq/a;)V", "backgroundAudioFeatureGate", "Ldbxyzptlk/Nq/Y;", "h", "Ldbxyzptlk/Nq/Y;", "Q4", "()Ldbxyzptlk/Nq/Y;", "b5", "(Ldbxyzptlk/Nq/Y;)V", "playbackServiceEnabler", "Ldbxyzptlk/Nq/X;", "i", "Ldbxyzptlk/Nq/X;", "P4", "()Ldbxyzptlk/Nq/X;", "a5", "(Ldbxyzptlk/Nq/X;)V", "partialScreenCommentsFeatureGate", "Ldbxyzptlk/Nq/d;", "j", "Ldbxyzptlk/Nq/d;", "N4", "()Ldbxyzptlk/Nq/d;", "Y4", "(Ldbxyzptlk/Nq/d;)V", "commentsActivityIntentProvider", "Ldbxyzptlk/Et/a;", "k", "Ldbxyzptlk/Et/a;", "O4", "()Ldbxyzptlk/Et/a;", "Z4", "(Ldbxyzptlk/Et/a;)V", "fileActivityActivityIntentProvider", "Ldbxyzptlk/eK/C;", "", "l", "Ldbxyzptlk/eK/C;", "swipingEnabled", "Ldbxyzptlk/Bf/c;", "m", "Ldbxyzptlk/Bf/c;", "snackbarHelper", "Lcom/dropbox/preview/v3/b;", "n", "S4", "()Lcom/dropbox/preview/v3/b;", "viewModel", "Ldbxyzptlk/rr/h;", "o", "M4", "()Ldbxyzptlk/rr/h;", "chromeViewModel", "Ldbxyzptlk/Wq/j;", "p", "Ldbxyzptlk/Wq/j;", "previewMediaSessionInteractor", "com/dropbox/preview/v3/PreviewActivity$o", "q", "Lcom/dropbox/preview/v3/PreviewActivity$o;", "pageChangeListener", "Landroidx/lifecycle/t$b;", "getDefaultViewModelProviderFactory", "()Landroidx/lifecycle/t$b;", "defaultViewModelProviderFactory", "r", "a", "Ldbxyzptlk/rr/l;", "viewState", "Lcom/dropbox/preview/v3/c;", "localSwipingEnabled", "dbapp_preview_v3_impl_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class PreviewActivity extends BaseActivity implements e, e, f, d {
  public static final a r = new a(null);
  
  public static final int s = 8;
  
  public final j c = k.a((a)new p((z)this, this));
  
  public P d;
  
  public c e;
  
  public s f;
  
  public a g;
  
  public Y h;
  
  public X i;
  
  public d j;
  
  public a k;
  
  public final C<Boolean> l = U.a(Boolean.TRUE);
  
  public final c m = new c();
  
  public final j n;
  
  public final j o;
  
  public j p;
  
  public final o q;
  
  public PreviewActivity() {
    u u = new u(this);
    this.n = (j)new s(L.b(b.class), (a)new q((ComponentActivity)this), (a)u, (a)new r(null, (ComponentActivity)this));
    h h = new h(this);
    this.o = (j)new s(L.b(h.class), (a)new s((ComponentActivity)this), (a)h, (a)new t(null, (ComponentActivity)this));
    this.q = new o(this);
  }
  
  public static final void U4(PreviewActivity paramPreviewActivity, ActivityResult paramActivityResult) {
    s.h(paramPreviewActivity, "this$0");
    s.h(paramActivityResult, "result");
    paramPreviewActivity.M4().S(paramActivityResult);
  }
  
  public static final boolean z4(h1<Boolean> paramh1) {
    return ((Boolean)paramh1.getValue()).booleanValue();
  }
  
  public View C0() {
    View view = findViewById(16908290);
    s.g(view, "findViewById(...)");
    return view;
  }
  
  public Object D3() {
    return this.c.getValue();
  }
  
  public final f J4() {
    return new f((k)new i(this), (i)new j(this));
  }
  
  public final a K4() {
    a a1 = this.g;
    if (a1 != null)
      return a1; 
    s.u("backgroundAudioFeatureGate");
    return null;
  }
  
  public final c L4() {
    c c1 = this.e;
    if (c1 != null)
      return c1; 
    s.u("browserIntentProvider");
    return null;
  }
  
  public final h M4() {
    return (h)this.o.getValue();
  }
  
  public final d N4() {
    d d1 = this.j;
    if (d1 != null)
      return d1; 
    s.u("commentsActivityIntentProvider");
    return null;
  }
  
  public final a O4() {
    a a1 = this.k;
    if (a1 != null)
      return a1; 
    s.u("fileActivityActivityIntentProvider");
    return null;
  }
  
  public final X P4() {
    X x = this.i;
    if (x != null)
      return x; 
    s.u("partialScreenCommentsFeatureGate");
    return null;
  }
  
  public final Y Q4() {
    Y y = this.h;
    if (y != null)
      return y; 
    s.u("playbackServiceEnabler");
    return null;
  }
  
  public final s R4() {
    s s1 = this.f;
    if (s1 != null)
      return s1; 
    s.u("udcl");
    return null;
  }
  
  public final b S4() {
    return (b)this.n.getValue();
  }
  
  public final P T4() {
    P p = this.d;
    if (p != null)
      return p; 
    s.u("viewModelFactory");
    return null;
  }
  
  public void V2() {
    this.m.a();
  }
  
  public final void V4(int paramInt1, int paramInt2) {
    if (Build.VERSION.SDK_INT >= 34) {
      a0.a(this, 0, paramInt1, paramInt2);
    } else {
      overridePendingTransition(paramInt1, paramInt2);
    } 
  }
  
  public final void W4(a parama) {
    s.h(parama, "<set-?>");
    this.g = parama;
  }
  
  public final void X4(c paramc) {
    s.h(paramc, "<set-?>");
    this.e = paramc;
  }
  
  public final void Y4(d paramd) {
    s.h(paramd, "<set-?>");
    this.j = paramd;
  }
  
  public final void Z4(a parama) {
    s.h(parama, "<set-?>");
    this.k = parama;
  }
  
  public final void a5(X paramX) {
    s.h(paramX, "<set-?>");
    this.i = paramX;
  }
  
  public final void b5(Y paramY) {
    s.h(paramY, "<set-?>");
    this.h = paramY;
  }
  
  public final void c5(s params) {
    s.h(params, "<set-?>");
    this.f = params;
  }
  
  public final void d5(P paramP) {
    s.h(paramP, "<set-?>");
    this.d = paramP;
  }
  
  public void f3(Snackbar paramSnackbar) {
    this.m.f(paramSnackbar);
  }
  
  public t.b getDefaultViewModelProviderFactory() {
    return (t.b)T4();
  }
  
  public void onBackPressed() {
    j j1 = this.p;
    if (j1 != null)
      j1.a(); 
    super.onBackPressed();
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    ((c0)c.b((Context)this, c0.class, c.d((Activity)this), false)).k(this);
    if (w() != null && !c.j((Activity)this, null, 1, null)) {
      a.a.q("onCreate: User is no longer logged in", new Object[0]);
      finish();
      return;
    } 
    if (!getIntent().hasExtra("sourceParam")) {
      if (!getIntent().hasExtra("intent_source"))
        s.l(R4(), "preview/events/invalid_intent", 0L, null, 6, null); 
      startActivity(L4().k());
      finish();
    } 
    if (P4().isEnabled()) {
      b b = registerForActivityResult((a)new d(), (a)new b0(this));
      h.d((J)i.a((LifecycleOwner)this), null, null, (p)new k(this, b, null), 3, null);
    } 
    v0.b(getWindow(), false);
    h.d((J)i.a((LifecycleOwner)this), null, null, (p)new l(this, null), 3, null);
    h.d((J)i.a(getLifecycle()), null, null, (p)new m(this, null), 3, null);
    this.m.c(findViewById(16908290));
    if (K4().isEnabled() && Q4().f()) {
      Context context = getApplicationContext();
      s.g(context, "getApplicationContext(...)");
      this.p = (j)new p(context);
    } 
    e.b((ComponentActivity)this, null, (p)c.c(941038650, true, new n(this)), 1, null);
  }
  
  public void onDestroy() {
    super.onDestroy();
    j j1 = this.p;
    if (j1 != null)
      j1.b(); 
    this.m.g();
  }
  
  public void onResumeFragments() {
    super.onResumeFragments();
    M4().W((FragmentActivity)this);
  }
  
  public void onStart() {
    super.onStart();
    if (w() != null && !c.j((Activity)this, null, 1, null)) {
      a.a.q("onStart: User is no longer logged in", new Object[0]);
      finish();
    } 
  }
  
  public final void x4(c.a parama, j1 paramj1, k paramk, int paramInt) {
    paramk = paramk.x(-1104859208);
    if (n.I())
      n.U(-1104859208, paramInt, -1, "com.dropbox.preview.v3.PreviewActivity.FileOperationSnackbar (PreviewActivity.kt:367)"); 
    J.e(paramj1, parama, (p)new b(parama, this, paramj1, null), paramk, paramInt >> 3 & 0xE | 0x200 | paramInt << 3 & 0x70);
    if (n.I())
      n.T(); 
    K0 k0 = paramk.z();
    if (k0 != null)
      k0.a((p)new c(this, parama, paramj1, paramInt)); 
  }
  
  public final void y4(c.b paramb, k paramk, int paramInt) {
    // Byte code:
    //   0: aload_1
    //   1: ldc_w 'previewViewState'
    //   4: invokestatic h : (Ljava/lang/Object;Ljava/lang/String;)V
    //   7: aload_2
    //   8: ldc_w 1361888179
    //   11: invokeinterface x : (I)Ldbxyzptlk/x0/k;
    //   16: astore #7
    //   18: invokestatic I : ()Z
    //   21: ifeq -> 35
    //   24: ldc_w 1361888179
    //   27: iload_3
    //   28: iconst_m1
    //   29: ldc_w 'com.dropbox.preview.v3.PreviewActivity.PreviewContent (PreviewActivity.kt:325)'
    //   32: invokestatic U : (IIILjava/lang/String;)V
    //   35: aload_0
    //   36: getfield l : Ldbxyzptlk/eK/C;
    //   39: aconst_null
    //   40: aload #7
    //   42: bipush #8
    //   44: iconst_1
    //   45: invokestatic b : (Ldbxyzptlk/eK/S;Ldbxyzptlk/tI/g;Ldbxyzptlk/x0/k;II)Ldbxyzptlk/x0/h1;
    //   48: astore #8
    //   50: aload_1
    //   51: invokevirtual a : ()Ldbxyzptlk/Sq/G;
    //   54: astore_2
    //   55: aload_1
    //   56: invokevirtual b : ()Ldbxyzptlk/yx/e;
    //   59: astore #6
    //   61: aload #7
    //   63: ldc_w -135189325
    //   66: invokeinterface I : (I)V
    //   71: aload #7
    //   73: aload_2
    //   74: invokeinterface q : (Ljava/lang/Object;)Z
    //   79: istore #4
    //   81: aload #7
    //   83: aload #6
    //   85: invokeinterface q : (Ljava/lang/Object;)Z
    //   90: istore #5
    //   92: aload #7
    //   94: invokeinterface J : ()Ljava/lang/Object;
    //   99: astore #6
    //   101: iload #4
    //   103: iload #5
    //   105: ior
    //   106: ifne -> 123
    //   109: aload #6
    //   111: astore_2
    //   112: aload #6
    //   114: getstatic dbxyzptlk/x0/k.a : Ldbxyzptlk/x0/k$a;
    //   117: invokevirtual a : ()Ljava/lang/Object;
    //   120: if_acmpne -> 180
    //   123: aload_0
    //   124: invokevirtual getSupportFragmentManager : ()Landroidx/fragment/app/FragmentManager;
    //   127: astore_2
    //   128: aload_2
    //   129: ldc_w 'getSupportFragmentManager(...)'
    //   132: invokestatic g : (Ljava/lang/Object;Ljava/lang/String;)V
    //   135: aload_0
    //   136: invokevirtual getIntent : ()Landroid/content/Intent;
    //   139: astore #6
    //   141: aload #6
    //   143: ldc_w 'getIntent(...)'
    //   146: invokestatic g : (Ljava/lang/Object;Ljava/lang/String;)V
    //   149: new com/dropbox/preview/v3/view/e
    //   152: dup
    //   153: aload_2
    //   154: aload_0
    //   155: aload #6
    //   157: invokestatic b : (Landroid/content/Intent;)Lcom/dropbox/kaiken/scoping/ViewingUserSelector;
    //   160: aload_1
    //   161: invokevirtual b : ()Ldbxyzptlk/yx/e;
    //   164: aload_1
    //   165: invokevirtual a : ()Ldbxyzptlk/Sq/G;
    //   168: invokespecial <init> : (Landroidx/fragment/app/FragmentManager;Landroidx/lifecycle/LifecycleOwner;Lcom/dropbox/kaiken/scoping/ViewingUserSelector;Ldbxyzptlk/yx/e;Ldbxyzptlk/Sq/G;)V
    //   171: astore_2
    //   172: aload #7
    //   174: aload_2
    //   175: invokeinterface D : (Ljava/lang/Object;)V
    //   180: aload_2
    //   181: checkcast com/dropbox/preview/v3/view/e
    //   184: astore_2
    //   185: aload #7
    //   187: invokeinterface R : ()V
    //   192: new com/dropbox/preview/v3/PreviewActivity$d
    //   195: dup
    //   196: aload_0
    //   197: aload_2
    //   198: aload_1
    //   199: invokespecial <init> : (Lcom/dropbox/preview/v3/PreviewActivity;Lcom/dropbox/preview/v3/view/e;Lcom/dropbox/preview/v3/c$b;)V
    //   202: astore #10
    //   204: getstatic androidx/compose/ui/d.a : Landroidx/compose/ui/d$a;
    //   207: ldc_w 'PreviewContent'
    //   210: invokestatic b : (Landroidx/compose/ui/d;Ljava/lang/String;)Landroidx/compose/ui/d;
    //   213: astore #11
    //   215: new com/dropbox/preview/v3/PreviewActivity$e
    //   218: dup
    //   219: aload_0
    //   220: invokespecial <init> : (Lcom/dropbox/preview/v3/PreviewActivity;)V
    //   223: astore #9
    //   225: aload #7
    //   227: ldc_w -135156705
    //   230: invokeinterface I : (I)V
    //   235: aload #7
    //   237: aload #8
    //   239: invokeinterface q : (Ljava/lang/Object;)Z
    //   244: istore #4
    //   246: aload #7
    //   248: invokeinterface J : ()Ljava/lang/Object;
    //   253: astore #6
    //   255: iload #4
    //   257: ifne -> 274
    //   260: aload #6
    //   262: astore_2
    //   263: aload #6
    //   265: getstatic dbxyzptlk/x0/k.a : Ldbxyzptlk/x0/k$a;
    //   268: invokevirtual a : ()Ljava/lang/Object;
    //   271: if_acmpne -> 292
    //   274: new com/dropbox/preview/v3/PreviewActivity$f
    //   277: dup
    //   278: aload #8
    //   280: invokespecial <init> : (Ldbxyzptlk/x0/h1;)V
    //   283: astore_2
    //   284: aload #7
    //   286: aload_2
    //   287: invokeinterface D : (Ljava/lang/Object;)V
    //   292: aload_2
    //   293: checkcast dbxyzptlk/CI/l
    //   296: astore_2
    //   297: aload #7
    //   299: invokeinterface R : ()V
    //   304: aload #10
    //   306: aload #11
    //   308: aconst_null
    //   309: aload #9
    //   311: aload_2
    //   312: aload #7
    //   314: iconst_0
    //   315: bipush #6
    //   317: invokestatic a : (Ldbxyzptlk/CI/l;Landroidx/compose/ui/d;Ldbxyzptlk/CI/l;Ldbxyzptlk/CI/l;Ldbxyzptlk/CI/l;Ldbxyzptlk/x0/k;II)V
    //   320: invokestatic I : ()Z
    //   323: ifeq -> 329
    //   326: invokestatic T : ()V
    //   329: aload #7
    //   331: invokeinterface z : ()Ldbxyzptlk/x0/K0;
    //   336: astore_2
    //   337: aload_2
    //   338: ifnull -> 357
    //   341: aload_2
    //   342: new com/dropbox/preview/v3/PreviewActivity$g
    //   345: dup
    //   346: aload_0
    //   347: aload_1
    //   348: iload_3
    //   349: invokespecial <init> : (Lcom/dropbox/preview/v3/PreviewActivity;Lcom/dropbox/preview/v3/c$b;I)V
    //   352: invokeinterface a : (Ldbxyzptlk/CI/p;)V
    //   357: return
  }
  
  class PreviewActivity {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\preview\v3\PreviewActivity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */