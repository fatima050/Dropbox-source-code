package com.dropbox.preview.v3;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import com.dropbox.common.activity.BaseActivity;
import dbxyzptlk.DI.s;
import dbxyzptlk.Nq.h;
import dbxyzptlk.Sq.C;
import dbxyzptlk.sL.a;
import dbxyzptlk.yj.c;
import dbxyzptlk.yx.e;
import kotlin.Metadata;

@Metadata(d1 = {"\000\"\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\b\b\007\030\0002\0020\001B\007¢\006\004\b\002\020\003J\031\020\007\032\0020\0062\b\020\005\032\004\030\0010\004H\024¢\006\004\b\007\020\bR\"\020\020\032\0020\t8\006@\006X.¢\006\022\n\004\b\n\020\013\032\004\b\f\020\r\"\004\b\016\020\017¨\006\021"}, d2 = {"Lcom/dropbox/preview/v3/ExternalPdfPreviewActivity;", "Lcom/dropbox/common/activity/BaseActivity;", "<init>", "()V", "Landroid/os/Bundle;", "savedInstanceState", "Ldbxyzptlk/pI/D;", "onCreate", "(Landroid/os/Bundle;)V", "Ldbxyzptlk/Sq/C;", "c", "Ldbxyzptlk/Sq/C;", "w4", "()Ldbxyzptlk/Sq/C;", "x4", "(Ldbxyzptlk/Sq/C;)V", "previewIntentFactory", "dbapp_preview_v3_impl_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class ExternalPdfPreviewActivity extends BaseActivity {
  public C c;
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    ((h)c.b((Context)this, h.class, c.d((Activity)this), false)).E0(this);
    Uri uri = getIntent().getData();
    String str = getIntent().getType();
    if (uri != null) {
      Intent intent = w4().g((Context)this, uri, str, c.d((Activity)this), e.EXTERNAL_PREVIEW);
      if (intent != null) {
        try {
          startActivity(intent);
          finish();
        } catch (Exception exception) {
          a.a.f(exception, "Unable to start PreviewV3 Activity", new Object[0]);
        } 
        return;
      } 
      finish();
    } 
  }
  
  public final C w4() {
    C c = this.c;
    if (c != null)
      return c; 
    s.u("previewIntentFactory");
    return null;
  }
  
  public final void x4(C paramC) {
    s.h(paramC, "<set-?>");
    this.c = paramC;
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\preview\v3\ExternalPdfPreviewActivity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */