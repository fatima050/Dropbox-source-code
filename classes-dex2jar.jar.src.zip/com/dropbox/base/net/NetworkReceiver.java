package com.dropbox.base.net;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import dbxyzptlk.CC.p;
import dbxyzptlk.De.d;

public class NetworkReceiver extends BroadcastReceiver {
  public String a;
  
  public Context b;
  
  public NetworkReceiver(String paramString) {
    this.a = paramString;
  }
  
  public final String a() {
    return this.a;
  }
  
  public void b(Context paramContext) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield b : Landroid/content/Context;
    //   6: astore_2
    //   7: aload_2
    //   8: ifnull -> 14
    //   11: aload_0
    //   12: monitorexit
    //   13: return
    //   14: new java/lang/StringBuilder
    //   17: astore_2
    //   18: aload_2
    //   19: invokespecial <init> : ()V
    //   22: aload_2
    //   23: ldc 'NetworkReceiver('
    //   25: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   28: pop
    //   29: aload_2
    //   30: aload_0
    //   31: invokevirtual a : ()Ljava/lang/String;
    //   34: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   37: pop
    //   38: aload_2
    //   39: ldc ') registered.'
    //   41: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   44: pop
    //   45: aload_2
    //   46: invokevirtual toString : ()Ljava/lang/String;
    //   49: iconst_0
    //   50: anewarray java/lang/Object
    //   53: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   56: aload_0
    //   57: aload_1
    //   58: invokevirtual getApplicationContext : ()Landroid/content/Context;
    //   61: putfield b : Landroid/content/Context;
    //   64: new android/content/IntentFilter
    //   67: astore_1
    //   68: aload_1
    //   69: invokespecial <init> : ()V
    //   72: aload_1
    //   73: ldc 'android.net.conn.CONNECTIVITY_CHANGE'
    //   75: invokevirtual addAction : (Ljava/lang/String;)V
    //   78: aload_1
    //   79: ldc 'android.intent.action.USER_PRESENT'
    //   81: invokevirtual addAction : (Ljava/lang/String;)V
    //   84: aload_0
    //   85: getfield b : Landroid/content/Context;
    //   88: aload_0
    //   89: aload_1
    //   90: invokevirtual registerReceiver : (Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;
    //   93: pop
    //   94: aload_0
    //   95: monitorexit
    //   96: return
    //   97: astore_1
    //   98: aload_0
    //   99: monitorexit
    //   100: aload_1
    //   101: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	97	finally
    //   14	94	97	finally
    //   98	100	97	finally
  }
  
  public void c() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield b : Landroid/content/Context;
    //   6: astore_1
    //   7: aload_1
    //   8: ifnonnull -> 14
    //   11: aload_0
    //   12: monitorexit
    //   13: return
    //   14: aload_1
    //   15: aload_0
    //   16: invokevirtual unregisterReceiver : (Landroid/content/BroadcastReceiver;)V
    //   19: aload_0
    //   20: aconst_null
    //   21: putfield b : Landroid/content/Context;
    //   24: new java/lang/StringBuilder
    //   27: astore_1
    //   28: aload_1
    //   29: invokespecial <init> : ()V
    //   32: aload_1
    //   33: ldc 'NetworkReceiver('
    //   35: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   38: pop
    //   39: aload_1
    //   40: aload_0
    //   41: invokevirtual a : ()Ljava/lang/String;
    //   44: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   47: pop
    //   48: aload_1
    //   49: ldc ') unregistered.'
    //   51: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   54: pop
    //   55: aload_1
    //   56: invokevirtual toString : ()Ljava/lang/String;
    //   59: iconst_0
    //   60: anewarray java/lang/Object
    //   63: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   66: aload_0
    //   67: monitorexit
    //   68: return
    //   69: astore_1
    //   70: aload_0
    //   71: monitorexit
    //   72: aload_1
    //   73: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	69	finally
    //   14	66	69	finally
    //   70	72	69	finally
  }
  
  public void finalize() throws Throwable {
    boolean bool;
    if (this.b == null) {
      bool = true;
    } else {
      bool = false;
    } 
    p.j(bool, "Object must be null: %1$s", "BroadcastReceiver not unregistered before destruction.");
    super.finalize();
  }
  
  public void onReceive(Context paramContext, Intent paramIntent) {
    String str = paramIntent.getAction();
    if ("android.net.conn.CONNECTIVITY_CHANGE".equals(str) || "android.intent.action.USER_PRESENT".equals(str))
      d.c().g(paramContext); 
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\base\net\NetworkReceiver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */