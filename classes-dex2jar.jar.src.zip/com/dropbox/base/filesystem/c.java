package com.dropbox.base.filesystem;

import android.content.Context;
import android.os.StatFs;
import com.google.common.collect.g;
import dbxyzptlk.Be.d;
import dbxyzptlk.CC.p;
import dbxyzptlk.CC.q;
import dbxyzptlk.EC.f;
import dbxyzptlk.Ec.g;
import dbxyzptlk.Fc.l6;
import dbxyzptlk.ye.C0;
import dbxyzptlk.ye.k0;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.FileAttribute;
import java.util.Collection;
import java.util.Iterator;
import java.util.UUID;

public final class c {
  public static final f<Character, Character> a = (f<Character, Character>)g.w().l(Character.valueOf(':'), Character.valueOf('∶')).l(Character.valueOf('*'), Character.valueOf('∗')).l(Character.valueOf('|'), Character.valueOf('❘')).l(Character.valueOf('<'), Character.valueOf('⋖')).l(Character.valueOf('>'), Character.valueOf('⋗')).l(Character.valueOf('"'), Character.valueOf('″')).l(Character.valueOf('?'), Character.valueOf('‽')).l(Character.valueOf('%'), Character.valueOf('٪')).j();
  
  public static void a(File paramFile, String paramString, long paramLong, C0 paramC0) {
    b(paramFile, paramString, paramLong, paramC0, null);
  }
  
  public static void b(File paramFile, String paramString, long paramLong, C0 paramC0, g paramg) {
    boolean bool;
    byte b = 0;
    if (paramLong >= 0L) {
      bool = true;
    } else {
      bool = false;
    } 
    p.e(bool, "Assert failed.");
    File[] arrayOfFile = u(paramFile);
    int i = arrayOfFile.length;
    while (b < i) {
      paramFile = arrayOfFile[b];
      if (paramFile.getName().startsWith(paramString) && paramC0.a() - paramFile.lastModified() > paramLong) {
        dbxyzptlk.sL.a.j("Deleting %d", new Object[] { Integer.valueOf(paramFile.hashCode()) });
        long l2 = paramC0.b();
        bool = dbxyzptlk.HK.c.e(paramFile);
        long l1 = paramC0.b();
        if (paramg != null)
          (new l6()).l(bool).m(l2).k(l1).g(paramg); 
      } 
      b++;
    } 
  }
  
  public static File c(File paramFile, String paramString, boolean paramBoolean, int paramInt) throws CannotCreateNewFileException {
    // Byte code:
    //   0: ldc com/dropbox/base/filesystem/c
    //   2: monitorenter
    //   3: aload_0
    //   4: aload_1
    //   5: iload_2
    //   6: iload_3
    //   7: ldc '.tmp'
    //   9: invokestatic d : (Ljava/io/File;Ljava/lang/String;ZILjava/lang/String;)Ljava/io/File;
    //   12: astore_0
    //   13: ldc com/dropbox/base/filesystem/c
    //   15: monitorexit
    //   16: aload_0
    //   17: areturn
    //   18: astore_0
    //   19: ldc com/dropbox/base/filesystem/c
    //   21: monitorexit
    //   22: aload_0
    //   23: athrow
    // Exception table:
    //   from	to	target	type
    //   3	13	18	finally
    //   19	22	18	finally
  }
  
  public static File d(File paramFile, String paramString1, boolean paramBoolean, int paramInt, String paramString2) throws CannotCreateNewFileException {
    // Byte code:
    //   0: ldc com/dropbox/base/filesystem/c
    //   2: monitorenter
    //   3: aload_0
    //   4: invokestatic o : (Ljava/lang/Object;)Ljava/lang/Object;
    //   7: pop
    //   8: aload_0
    //   9: invokestatic q : (Ljava/io/File;)Z
    //   12: ifeq -> 230
    //   15: aload_0
    //   16: invokestatic t : (Ljava/io/File;)[Ljava/lang/String;
    //   19: astore #10
    //   21: aload #10
    //   23: arraylength
    //   24: istore #8
    //   26: iconst_0
    //   27: istore #7
    //   29: iconst_0
    //   30: istore #6
    //   32: iload #7
    //   34: iload #8
    //   36: if_icmpge -> 97
    //   39: iload #6
    //   41: istore #5
    //   43: aload #10
    //   45: iload #7
    //   47: aaload
    //   48: aload_1
    //   49: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   52: ifeq -> 87
    //   55: iload #6
    //   57: iconst_1
    //   58: iadd
    //   59: istore #5
    //   61: iload #5
    //   63: iload_3
    //   64: if_icmpge -> 70
    //   67: goto -> 87
    //   70: new com/dropbox/base/filesystem/CannotCreateNewFileException
    //   73: astore_0
    //   74: aload_0
    //   75: getstatic com/dropbox/base/filesystem/CannotCreateNewFileException$a.TOO_MANY_TEMP_FILES : Lcom/dropbox/base/filesystem/CannotCreateNewFileException$a;
    //   78: invokespecial <init> : (Lcom/dropbox/base/filesystem/CannotCreateNewFileException$a;)V
    //   81: aload_0
    //   82: athrow
    //   83: astore_0
    //   84: goto -> 243
    //   87: iinc #7, 1
    //   90: iload #5
    //   92: istore #6
    //   94: goto -> 32
    //   97: new java/io/File
    //   100: astore #10
    //   102: new java/lang/StringBuilder
    //   105: astore #11
    //   107: aload #11
    //   109: invokespecial <init> : ()V
    //   112: aload #11
    //   114: aload_1
    //   115: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   118: pop
    //   119: aload #11
    //   121: invokestatic randomUUID : ()Ljava/util/UUID;
    //   124: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   127: pop
    //   128: aload #11
    //   130: aload #4
    //   132: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   135: pop
    //   136: aload #10
    //   138: aload_0
    //   139: aload #11
    //   141: invokevirtual toString : ()Ljava/lang/String;
    //   144: invokespecial <init> : (Ljava/io/File;Ljava/lang/String;)V
    //   147: aload #10
    //   149: invokevirtual exists : ()Z
    //   152: istore #9
    //   154: iload #9
    //   156: ifne -> 97
    //   159: iload_2
    //   160: ifeq -> 176
    //   163: aload #10
    //   165: invokestatic p : (Ljava/io/File;)Z
    //   168: istore_2
    //   169: goto -> 182
    //   172: astore_0
    //   173: goto -> 225
    //   176: aload #10
    //   178: invokevirtual createNewFile : ()Z
    //   181: istore_2
    //   182: iload_2
    //   183: ifeq -> 212
    //   186: ldc 'Creating %d'
    //   188: iconst_1
    //   189: anewarray java/lang/Object
    //   192: dup
    //   193: iconst_0
    //   194: aload #10
    //   196: invokevirtual hashCode : ()I
    //   199: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   202: aastore
    //   203: invokestatic j : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   206: ldc com/dropbox/base/filesystem/c
    //   208: monitorexit
    //   209: aload #10
    //   211: areturn
    //   212: new com/dropbox/base/filesystem/CannotCreateNewFileException
    //   215: astore_0
    //   216: aload_0
    //   217: getstatic com/dropbox/base/filesystem/CannotCreateNewFileException$a.UNKNOWN : Lcom/dropbox/base/filesystem/CannotCreateNewFileException$a;
    //   220: invokespecial <init> : (Lcom/dropbox/base/filesystem/CannotCreateNewFileException$a;)V
    //   223: aload_0
    //   224: athrow
    //   225: aload_0
    //   226: invokestatic a : (Ljava/io/IOException;)Lcom/dropbox/base/filesystem/CannotCreateNewFileException;
    //   229: athrow
    //   230: new com/dropbox/base/filesystem/CannotCreateNewFileException
    //   233: astore_0
    //   234: aload_0
    //   235: getstatic com/dropbox/base/filesystem/CannotCreateNewFileException$a.UNABLE_TO_MAKE_DIR_PATH : Lcom/dropbox/base/filesystem/CannotCreateNewFileException$a;
    //   238: invokespecial <init> : (Lcom/dropbox/base/filesystem/CannotCreateNewFileException$a;)V
    //   241: aload_0
    //   242: athrow
    //   243: ldc com/dropbox/base/filesystem/c
    //   245: monitorexit
    //   246: aload_0
    //   247: athrow
    // Exception table:
    //   from	to	target	type
    //   3	26	83	finally
    //   43	55	83	finally
    //   70	83	83	finally
    //   97	154	83	finally
    //   163	169	172	java/io/IOException
    //   163	169	83	finally
    //   176	182	172	java/io/IOException
    //   176	182	83	finally
    //   186	206	172	java/io/IOException
    //   186	206	83	finally
    //   212	225	83	finally
    //   225	230	83	finally
    //   230	243	83	finally
    //   243	246	83	finally
  }
  
  public static String e(String paramString) {
    Iterator<Character> iterator = a.keySet().iterator();
    String str = paramString;
    while (iterator.hasNext()) {
      Character character = iterator.next();
      str = paramString.replace(character.charValue(), ((Character)a.get(character)).charValue());
    } 
    return str;
  }
  
  public static File f() {
    return h().a();
  }
  
  public static long g(String paramString) {
    p.o(paramString);
    try {
      StatFs statFs = new StatFs();
      this(paramString);
      statFs.restat(paramString);
      return statFs.getAvailableBytes();
    } catch (Exception exception) {
      dbxyzptlk.sL.a.e(exception);
      return Long.MAX_VALUE;
    } 
  }
  
  public static dbxyzptlk.Be.c h() {
    return a.b;
  }
  
  public static long i(File paramFile, q<File> paramq) {
    p.o(paramFile);
    p.o(paramq);
    return h().b(paramFile, paramq);
  }
  
  public static long j(File paramFile, Collection<File> paramCollection) {
    p.o(paramFile);
    p.o(paramCollection);
    return h().c(paramFile, paramCollection);
  }
  
  public static boolean k(File paramFile1, File paramFile2) throws IOException {
    File file = paramFile1.getCanonicalFile();
    paramFile1 = paramFile2.getCanonicalFile();
    while (true) {
      paramFile2 = paramFile1.getParentFile();
      if (paramFile2 != null) {
        paramFile1 = paramFile2;
        if (paramFile2.equals(file))
          return true; 
        continue;
      } 
      return false;
    } 
  }
  
  public static boolean l(File paramFile1, File paramFile2) throws IOException {
    return (k(paramFile1, paramFile2) || paramFile1.getCanonicalFile().equals(paramFile2.getCanonicalFile()));
  }
  
  public static boolean m(k0 paramk0, Context paramContext) {
    return h().e(paramk0);
  }
  
  public static boolean n() {
    return h().f();
  }
  
  public static boolean o(File paramFile) {
    return h().g(paramFile);
  }
  
  public static boolean p(File paramFile) throws IOException {
    Path path = paramFile.toPath();
    boolean bool = false;
    if (Files.createDirectory(path, (FileAttribute<?>[])new FileAttribute[0]) != null)
      bool = true; 
    return bool;
  }
  
  public static boolean q(File paramFile) {
    /* monitor enter TypeReferenceDotClassExpression{ObjectType{com/dropbox/base/filesystem/c}} */
    try {
      if (!paramFile.exists()) {
        boolean bool = paramFile.mkdirs();
        /* monitor exit TypeReferenceDotClassExpression{ObjectType{com/dropbox/base/filesystem/c}} */
        return bool;
      } 
    } finally {}
    /* monitor exit TypeReferenceDotClassExpression{ObjectType{com/dropbox/base/filesystem/c}} */
    return true;
  }
  
  public static boolean r(File paramFile1, File paramFile2) {
    try {
      return k(paramFile1, paramFile2);
    } catch (IOException iOException) {
      return false;
    } 
  }
  
  public static boolean s(File paramFile) {
    if (paramFile.isDirectory())
      while (true) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(paramFile.getAbsolutePath());
        stringBuilder.append(UUID.randomUUID().toString());
        File file = new File(stringBuilder.toString());
        if (!file.exists())
          return paramFile.renameTo(file) ? file.delete() : paramFile.delete(); 
      }  
    return paramFile.delete();
  }
  
  public static String[] t(File paramFile) {
    return h().h(paramFile);
  }
  
  public static File[] u(File paramFile) {
    return d.a(paramFile);
  }
  
  public static File v() {
    return h().d();
  }
  
  public static class a {
    public static final b a;
    
    public static final dbxyzptlk.Be.c b;
    
    static {
      b b1 = a.a().create();
      a = b1;
      b = b1.a();
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\base\filesystem\c.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */