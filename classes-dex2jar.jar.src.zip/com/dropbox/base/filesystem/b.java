package com.dropbox.base.filesystem;

import dbxyzptlk.Be.c;
import kotlin.Metadata;

@Metadata(d1 = {"\000\020\n\002\030\002\n\002\020\000\n\002\030\002\n\002\b\004\bg\030\0002\0020\001:\001\003R\024\020\005\032\0020\0028&X¦\004¢\006\006\032\004\b\003\020\004ø\001\000\002\006\n\004\b!0\001¨\006\006À\006\001"}, d2 = {"Lcom/dropbox/base/filesystem/b;", "", "Ldbxyzptlk/Be/c;", "a", "()Ldbxyzptlk/Be/c;", "dbxFileUtils", "dbx_base_filesystem_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
public interface b {
  c a();
  
  @Metadata(d1 = {"\000\020\n\002\030\002\n\002\020\000\n\002\030\002\n\002\b\003\bg\030\0002\0020\001J\017\020\003\032\0020\002H&¢\006\004\b\003\020\004ø\001\000\002\006\n\004\b!0\001¨\006\005À\006\001"}, d2 = {"Lcom/dropbox/base/filesystem/b$a;", "", "Lcom/dropbox/base/filesystem/b;", "create", "()Lcom/dropbox/base/filesystem/b;", "dbx_base_filesystem_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
  public static interface a {
    b create();
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\base\filesystem\b.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */