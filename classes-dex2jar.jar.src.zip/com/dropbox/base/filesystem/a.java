package com.dropbox.base.filesystem;

import dbxyzptlk.Be.c;
import dbxyzptlk.Be.f;
import dbxyzptlk.Be.g;
import dbxyzptlk.Be.h;
import dbxyzptlk.Be.i;
import dbxyzptlk.Be.j;
import dbxyzptlk.bH.d;
import dbxyzptlk.bH.j;
import java.io.File;
import java.util.List;

public final class a {
  public static b.a a() {
    return new b(null);
  }
  
  public static final class a implements b {
    public final a a = this;
    
    public j<File> b;
    
    public j<List<String>> c;
    
    public j<File> d;
    
    public a() {
      b();
    }
    
    public c a() {
      return new c((File)this.b.get(), (File)this.d.get(), i.a(), g.a());
    }
    
    public final void b() {
      this.b = d.c((j)f.a());
      j<List<String>> j1 = d.c((j)j.a());
      this.c = j1;
      this.d = d.c((j)h.a((dbxyzptlk.oI.a)this.b, (dbxyzptlk.oI.a)j1));
    }
  }
  
  public static final class b implements b.a {
    public b() {}
    
    public b create() {
      return new a.a(null);
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\base\filesystem\a.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */