package com.dropbox.base.http;

import com.squareup.moshi.JsonDataException;
import dbxyzptlk.DI.s;
import dbxyzptlk.RG.f;
import dbxyzptlk.RG.i;
import dbxyzptlk.RG.n;
import dbxyzptlk.RG.q;
import dbxyzptlk.TG.c;
import dbxyzptlk.qI.Y;
import kotlin.Metadata;

@Metadata(d1 = {"\000<\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\003\n\002\020\016\n\002\b\002\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\007\030\0002\b\022\004\022\0020\0020\001B\017\022\006\020\004\032\0020\003¢\006\004\b\005\020\006J\017\020\b\032\0020\007H\026¢\006\004\b\b\020\tJ\027\020\f\032\0020\0022\006\020\013\032\0020\nH\026¢\006\004\b\f\020\rJ!\020\022\032\0020\0212\006\020\017\032\0020\0162\b\020\020\032\004\030\0010\002H\026¢\006\004\b\022\020\023R\024\020\027\032\0020\0248\002X\004¢\006\006\n\004\b\025\020\026R\032\020\032\032\b\022\004\022\0020\0070\0018\002X\004¢\006\006\n\004\b\030\020\031¨\006\033"}, d2 = {"Lcom/dropbox/base/http/AccessTokenPairJsonAdapter;", "Ldbxyzptlk/RG/f;", "Lcom/dropbox/base/http/AccessTokenPair;", "Ldbxyzptlk/RG/q;", "moshi", "<init>", "(Ldbxyzptlk/RG/q;)V", "", "toString", "()Ljava/lang/String;", "Ldbxyzptlk/RG/i;", "reader", "j", "(Ldbxyzptlk/RG/i;)Lcom/dropbox/base/http/AccessTokenPair;", "Ldbxyzptlk/RG/n;", "writer", "value_", "Ldbxyzptlk/pI/D;", "k", "(Ldbxyzptlk/RG/n;Lcom/dropbox/base/http/AccessTokenPair;)V", "Ldbxyzptlk/RG/i$a;", "a", "Ldbxyzptlk/RG/i$a;", "options", "b", "Ldbxyzptlk/RG/f;", "stringAdapter", "dbx_base_http_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class AccessTokenPairJsonAdapter extends f<AccessTokenPair> {
  public final i.a a;
  
  public final f<String> b;
  
  public AccessTokenPairJsonAdapter(q paramq) {
    i.a a1 = i.a.a(new String[] { "a", "b" });
    s.g(a1, "of(...)");
    this.a = a1;
    f<String> f1 = paramq.f(String.class, Y.e(), "key");
    s.g(f1, "adapter(...)");
    this.b = f1;
  }
  
  public AccessTokenPair j(i parami) {
    s.h(parami, "reader");
    parami.P();
    String str2 = null;
    String str1 = null;
    while (parami.c()) {
      int j = parami.o(this.a);
      if (j != -1) {
        if (j != 0) {
          if (j != 1)
            continue; 
          str1 = (String)this.b.b(parami);
          if (str1 != null)
            continue; 
          jsonDataException = c.w("secret", "b", parami);
          s.g(jsonDataException, "unexpectedNull(...)");
          throw jsonDataException;
        } 
        str2 = (String)this.b.b((i)jsonDataException);
        if (str2 != null)
          continue; 
        jsonDataException = c.w("key", "a", (i)jsonDataException);
        s.g(jsonDataException, "unexpectedNull(...)");
        throw jsonDataException;
      } 
      jsonDataException.s();
      jsonDataException.D1();
    } 
    jsonDataException.T();
    if (str2 != null) {
      if (str1 != null)
        return new AccessTokenPair(str2, str1); 
      jsonDataException = c.n("secret", "b", (i)jsonDataException);
      s.g(jsonDataException, "missingProperty(...)");
      throw jsonDataException;
    } 
    JsonDataException jsonDataException = c.n("key", "a", (i)jsonDataException);
    s.g(jsonDataException, "missingProperty(...)");
    throw jsonDataException;
  }
  
  public void k(n paramn, AccessTokenPair paramAccessTokenPair) {
    s.h(paramn, "writer");
    if (paramAccessTokenPair != null) {
      paramn.c();
      paramn.h("a");
      this.b.i(paramn, paramAccessTokenPair.key);
      paramn.h("b");
      this.b.i(paramn, paramAccessTokenPair.secret);
      paramn.g();
      return;
    } 
    throw new NullPointerException("value_ was null! Wrap in .nullSafe() to write nullable values.");
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder(37);
    stringBuilder.append("GeneratedJsonAdapter(");
    stringBuilder.append("AccessTokenPair");
    stringBuilder.append(')');
    String str = stringBuilder.toString();
    s.g(str, "toString(...)");
    return str;
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\base\http\AccessTokenPairJsonAdapter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */