package com.dropbox.base.http;

import dbxyzptlk.Ce.a;
import dbxyzptlk.Ce.c;
import dbxyzptlk.DI.s;
import dbxyzptlk.RG.e;
import dbxyzptlk.RG.g;
import kotlin.Metadata;

@g(generateAdapter = true)
@Metadata(d1 = {"\000.\n\002\030\002\n\002\030\002\n\002\020\016\n\002\b\004\n\002\020\000\n\000\n\002\020\013\n\002\b\002\n\002\020\b\n\002\b\004\n\002\030\002\n\002\b\b\b\007\030\0002\0020\001B\027\022\006\020\003\032\0020\002\022\006\020\004\032\0020\002¢\006\004\b\005\020\006J\032\020\n\032\0020\t2\b\020\b\032\004\030\0010\007H\002¢\006\004\b\n\020\013J\017\020\r\032\0020\fH\026¢\006\004\b\r\020\016J\017\020\017\032\0020\002H\026¢\006\004\b\017\020\020J\027\020\023\032\0020\0022\006\020\022\032\0020\021H\026¢\006\004\b\023\020\024R\032\020\003\032\0020\0028\006X\004¢\006\f\n\004\b\003\020\025\022\004\b\026\020\027R\032\020\004\032\0020\0028\006X\004¢\006\f\n\004\b\004\020\025\022\004\b\030\020\027¨\006\031"}, d2 = {"Lcom/dropbox/base/http/AccessTokenPair;", "Ldbxyzptlk/Ce/a;", "", "key", "secret", "<init>", "(Ljava/lang/String;Ljava/lang/String;)V", "", "other", "", "equals", "(Ljava/lang/Object;)Z", "", "hashCode", "()I", "toString", "()Ljava/lang/String;", "Ldbxyzptlk/Ce/c;", "appKeyPair", "buildApiV2AuthValue", "(Ldbxyzptlk/Ce/c;)Ljava/lang/String;", "Ljava/lang/String;", "getKey$annotations", "()V", "getSecret$annotations", "dbx_base_http_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class AccessTokenPair implements a {
  public final String key;
  
  public final String secret;
  
  public AccessTokenPair(String paramString1, String paramString2) {
    paramString1 = DbxToken.a(paramString1, "key");
    s.g(paramString1, "checkTokenArg(...)");
    this.key = paramString1;
    paramString1 = DbxToken.a(paramString2, "secret");
    s.g(paramString1, "checkTokenArg(...)");
    this.secret = paramString1;
  }
  
  public String buildApiV2AuthValue(c paramc) {
    s.h(paramc, "appKeyPair");
    String str2 = paramc.a;
    String str1 = paramc.b;
    String str3 = this.key;
    String str4 = this.secret;
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("oauth1.");
    stringBuilder.append(str2);
    stringBuilder.append(".");
    stringBuilder.append(str1);
    stringBuilder.append(".");
    stringBuilder.append(str3);
    stringBuilder.append(".");
    stringBuilder.append(str4);
    return stringBuilder.toString();
  }
  
  public boolean equals(Object paramObject) {
    boolean bool = true;
    if (this == paramObject)
      return true; 
    if (paramObject == null || !s.c(AccessTokenPair.class, paramObject.getClass()))
      return false; 
    paramObject = paramObject;
    if (!s.c(this.key, ((AccessTokenPair)paramObject).key) || !s.c(this.secret, ((AccessTokenPair)paramObject).secret))
      bool = false; 
    return bool;
  }
  
  public int hashCode() {
    return this.key.hashCode() * 31 + this.secret.hashCode();
  }
  
  public String toString() {
    String str = this.key;
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("AccessTokenPair{key='");
    stringBuilder.append(str);
    stringBuilder.append("'}");
    return stringBuilder.toString();
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\base\http\AccessTokenPair.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */