package com.dropbox.base.http;

import dbxyzptlk.Ce.a;
import dbxyzptlk.Ce.c;
import dbxyzptlk.DI.s;
import dbxyzptlk.RG.e;
import dbxyzptlk.RG.g;
import kotlin.Metadata;

@g(generateAdapter = true)
@Metadata(d1 = {"\000.\n\002\030\002\n\002\030\002\n\002\020\016\n\002\b\003\n\002\030\002\n\002\b\b\n\002\020\b\n\002\b\002\n\002\020\000\n\000\n\002\020\013\n\002\b\005\b\b\030\0002\0020\001B\021\022\b\b\001\020\003\032\0020\002¢\006\004\b\004\020\005J\027\020\b\032\0020\0022\006\020\007\032\0020\006H\026¢\006\004\b\b\020\tJ\020\020\n\032\0020\002HÆ\003¢\006\004\b\n\020\013J\032\020\f\032\0020\0002\b\b\003\020\003\032\0020\002HÆ\001¢\006\004\b\f\020\rJ\020\020\016\032\0020\002HÖ\001¢\006\004\b\016\020\013J\020\020\020\032\0020\017HÖ\001¢\006\004\b\020\020\021J\032\020\025\032\0020\0242\b\020\023\032\004\030\0010\022HÖ\003¢\006\004\b\025\020\026R\027\020\003\032\0020\0028\006¢\006\f\n\004\b\003\020\027\032\004\b\030\020\013¨\006\031"}, d2 = {"Lcom/dropbox/base/http/Oauth2AccessToken;", "Ldbxyzptlk/Ce/a;", "", "accessToken", "<init>", "(Ljava/lang/String;)V", "Ldbxyzptlk/Ce/c;", "appKeyPair", "buildApiV2AuthValue", "(Ldbxyzptlk/Ce/c;)Ljava/lang/String;", "component1", "()Ljava/lang/String;", "copy", "(Ljava/lang/String;)Lcom/dropbox/base/http/Oauth2AccessToken;", "toString", "", "hashCode", "()I", "", "other", "", "equals", "(Ljava/lang/Object;)Z", "Ljava/lang/String;", "getAccessToken", "dbx_base_http_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class Oauth2AccessToken implements a {
  private final String accessToken;
  
  public Oauth2AccessToken(@e(name = "accessToken") String paramString) {
    this.accessToken = paramString;
  }
  
  public String buildApiV2AuthValue(c paramc) {
    s.h(paramc, "appKeyPair");
    return this.accessToken;
  }
  
  public final String component1() {
    return this.accessToken;
  }
  
  public final Oauth2AccessToken copy(@e(name = "accessToken") String paramString) {
    s.h(paramString, "accessToken");
    return new Oauth2AccessToken(paramString);
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof Oauth2AccessToken))
      return false; 
    paramObject = paramObject;
    return !!s.c(this.accessToken, ((Oauth2AccessToken)paramObject).accessToken);
  }
  
  public final String getAccessToken() {
    return this.accessToken;
  }
  
  public int hashCode() {
    return this.accessToken.hashCode();
  }
  
  public String toString() {
    String str = this.accessToken;
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Oauth2AccessToken(accessToken=");
    stringBuilder.append(str);
    stringBuilder.append(")");
    return stringBuilder.toString();
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\base\http\Oauth2AccessToken.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */