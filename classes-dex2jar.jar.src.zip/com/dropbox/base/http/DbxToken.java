package com.dropbox.base.http;

public abstract class DbxToken {
  public static String a(String paramString1, String paramString2) {
    String str = b(paramString1);
    if (str == null)
      return paramString1; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Bad '");
    stringBuilder.append(paramString2);
    stringBuilder.append("': ");
    stringBuilder.append(str);
    throw new DbxTokenException(stringBuilder.toString());
  }
  
  public static String b(String paramString) {
    if (paramString == null)
      return "can't be null"; 
    if (paramString.length() == 0)
      return "can't be empty"; 
    if (paramString.contains(" ")) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("can't contain a space: ");
      stringBuilder.append(paramString);
      return stringBuilder.toString();
    } 
    if (paramString.contains("|")) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("can't contain a \"|\": ");
      stringBuilder.append(paramString);
      return stringBuilder.toString();
    } 
    return null;
  }
  
  public static class DbxTokenException extends RuntimeException {
    public static final long serialVersionUID = 0L;
    
    public DbxTokenException(String param1String) {
      super(param1String);
    }
  }
  
  class DbxToken {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\base\http\DbxToken.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */