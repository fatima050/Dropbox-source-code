package com.dropbox.base.http;

import com.squareup.moshi.JsonDataException;
import dbxyzptlk.DI.s;
import dbxyzptlk.RG.f;
import dbxyzptlk.RG.i;
import dbxyzptlk.RG.n;
import dbxyzptlk.RG.q;
import dbxyzptlk.TG.c;
import dbxyzptlk.qI.Y;
import kotlin.Metadata;

@Metadata(d1 = {"\000<\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\003\n\002\020\016\n\002\b\002\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\007\030\0002\b\022\004\022\0020\0020\001B\017\022\006\020\004\032\0020\003¢\006\004\b\005\020\006J\017\020\b\032\0020\007H\026¢\006\004\b\b\020\tJ\027\020\f\032\0020\0022\006\020\013\032\0020\nH\026¢\006\004\b\f\020\rJ!\020\022\032\0020\0212\006\020\017\032\0020\0162\b\020\020\032\004\030\0010\002H\026¢\006\004\b\022\020\023R\024\020\027\032\0020\0248\002X\004¢\006\006\n\004\b\025\020\026R\032\020\032\032\b\022\004\022\0020\0070\0018\002X\004¢\006\006\n\004\b\030\020\031¨\006\033"}, d2 = {"Lcom/dropbox/base/http/Oauth2AccessTokenJsonAdapter;", "Ldbxyzptlk/RG/f;", "Lcom/dropbox/base/http/Oauth2AccessToken;", "Ldbxyzptlk/RG/q;", "moshi", "<init>", "(Ldbxyzptlk/RG/q;)V", "", "toString", "()Ljava/lang/String;", "Ldbxyzptlk/RG/i;", "reader", "j", "(Ldbxyzptlk/RG/i;)Lcom/dropbox/base/http/Oauth2AccessToken;", "Ldbxyzptlk/RG/n;", "writer", "value_", "Ldbxyzptlk/pI/D;", "k", "(Ldbxyzptlk/RG/n;Lcom/dropbox/base/http/Oauth2AccessToken;)V", "Ldbxyzptlk/RG/i$a;", "a", "Ldbxyzptlk/RG/i$a;", "options", "b", "Ldbxyzptlk/RG/f;", "stringAdapter", "dbx_base_http_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class Oauth2AccessTokenJsonAdapter extends f<Oauth2AccessToken> {
  public final i.a a;
  
  public final f<String> b;
  
  public Oauth2AccessTokenJsonAdapter(q paramq) {
    i.a a1 = i.a.a(new String[] { "accessToken" });
    s.g(a1, "of(...)");
    this.a = a1;
    f<String> f1 = paramq.f(String.class, Y.e(), "accessToken");
    s.g(f1, "adapter(...)");
    this.b = f1;
  }
  
  public Oauth2AccessToken j(i parami) {
    s.h(parami, "reader");
    parami.P();
    String str = null;
    while (parami.c()) {
      int j = parami.o(this.a);
      if (j != -1) {
        if (j != 0)
          continue; 
        str = (String)this.b.b(parami);
        if (str != null)
          continue; 
        jsonDataException = c.w("accessToken", "accessToken", parami);
        s.g(jsonDataException, "unexpectedNull(...)");
        throw jsonDataException;
      } 
      jsonDataException.s();
      jsonDataException.D1();
    } 
    jsonDataException.T();
    if (str != null)
      return new Oauth2AccessToken(str); 
    JsonDataException jsonDataException = c.n("accessToken", "accessToken", (i)jsonDataException);
    s.g(jsonDataException, "missingProperty(...)");
    throw jsonDataException;
  }
  
  public void k(n paramn, Oauth2AccessToken paramOauth2AccessToken) {
    s.h(paramn, "writer");
    if (paramOauth2AccessToken != null) {
      paramn.c();
      paramn.h("accessToken");
      this.b.i(paramn, paramOauth2AccessToken.getAccessToken());
      paramn.g();
      return;
    } 
    throw new NullPointerException("value_ was null! Wrap in .nullSafe() to write nullable values.");
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder(39);
    stringBuilder.append("GeneratedJsonAdapter(");
    stringBuilder.append("Oauth2AccessToken");
    stringBuilder.append(')');
    String str = stringBuilder.toString();
    s.g(str, "toString(...)");
    return str;
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\base\http\Oauth2AccessTokenJsonAdapter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */