package com.dropbox.core;

import com.dropbox.core.json.JsonReadException;
import com.dropbox.core.json.JsonReader;
import com.dropbox.core.util.IOUtil;
import com.fasterxml.jackson.core.JsonParseException;
import dbxyzptlk.Ck.a;
import dbxyzptlk.Mk.d;
import dbxyzptlk.Vk.a;
import dbxyzptlk.fl.b;
import dbxyzptlk.kk.f;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URLEncoder;
import java.nio.charset.CharacterCodingException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;

public final class c {
  public static final Random a = new Random();
  
  public static a b;
  
  public static String[] A(Map<String, String> paramMap) {
    String[] arrayOfString = new String[paramMap.size() * 2];
    Iterator<Map.Entry> iterator = paramMap.entrySet().iterator();
    for (byte b = 0; iterator.hasNext(); b += 2) {
      Map.Entry entry = iterator.next();
      arrayOfString[b] = (String)entry.getKey();
      arrayOfString[b + 1] = (String)entry.getValue();
    } 
    return arrayOfString;
  }
  
  public static DbxException B(a.b paramb) throws NetworkIOException, BadResponseException {
    return C(paramb, null);
  }
  
  public static DbxException C(a.b paramb, String paramString) throws NetworkIOException, BadResponseException {
    // Byte code:
    //   0: aload_0
    //   1: invokestatic q : (Ldbxyzptlk/Ck/a$b;)Ljava/lang/String;
    //   4: astore #5
    //   6: aload_0
    //   7: invokevirtual d : ()I
    //   10: istore_2
    //   11: iload_2
    //   12: sipush #400
    //   15: if_icmpeq -> 613
    //   18: iload_2
    //   19: sipush #401
    //   22: if_icmpeq -> 503
    //   25: aconst_null
    //   26: astore_3
    //   27: aconst_null
    //   28: astore #4
    //   30: iload_2
    //   31: sipush #403
    //   34: if_icmpeq -> 376
    //   37: iload_2
    //   38: sipush #422
    //   41: if_icmpeq -> 255
    //   44: iload_2
    //   45: sipush #429
    //   48: if_icmpeq -> 212
    //   51: iload_2
    //   52: sipush #500
    //   55: if_icmpeq -> 198
    //   58: iload_2
    //   59: sipush #503
    //   62: if_icmpeq -> 123
    //   65: new java/lang/StringBuilder
    //   68: dup
    //   69: invokespecial <init> : ()V
    //   72: astore_3
    //   73: aload_3
    //   74: ldc 'unexpected HTTP status code: '
    //   76: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   79: pop
    //   80: aload_3
    //   81: aload_0
    //   82: invokevirtual d : ()I
    //   85: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   88: pop
    //   89: aload_3
    //   90: ldc ': '
    //   92: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   95: pop
    //   96: aload_3
    //   97: aconst_null
    //   98: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   101: pop
    //   102: new com/dropbox/core/BadResponseCodeException
    //   105: dup
    //   106: aload #5
    //   108: aload_3
    //   109: invokevirtual toString : ()Ljava/lang/String;
    //   112: aload_0
    //   113: invokevirtual d : ()I
    //   116: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;I)V
    //   119: astore_0
    //   120: goto -> 629
    //   123: aload_0
    //   124: ldc 'Retry-After'
    //   126: invokestatic p : (Ldbxyzptlk/Ck/a$b;Ljava/lang/String;)Ljava/lang/String;
    //   129: astore_0
    //   130: aload_0
    //   131: ifnull -> 168
    //   134: aload_0
    //   135: invokevirtual trim : ()Ljava/lang/String;
    //   138: invokevirtual isEmpty : ()Z
    //   141: ifne -> 168
    //   144: aload_0
    //   145: invokestatic parseInt : (Ljava/lang/String;)I
    //   148: istore_2
    //   149: new com/dropbox/core/RetryException
    //   152: astore_0
    //   153: aload_0
    //   154: aload #5
    //   156: aconst_null
    //   157: iload_2
    //   158: i2l
    //   159: getstatic java/util/concurrent/TimeUnit.SECONDS : Ljava/util/concurrent/TimeUnit;
    //   162: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;JLjava/util/concurrent/TimeUnit;)V
    //   165: goto -> 629
    //   168: new com/dropbox/core/RetryException
    //   171: dup
    //   172: aload #5
    //   174: aconst_null
    //   175: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;)V
    //   178: astore_0
    //   179: goto -> 629
    //   182: astore_0
    //   183: new com/dropbox/core/BadResponseException
    //   186: dup
    //   187: aload #5
    //   189: ldc 'Invalid value for HTTP header: "Retry-After"'
    //   191: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;)V
    //   194: astore_0
    //   195: goto -> 629
    //   198: new com/dropbox/core/ServerException
    //   201: dup
    //   202: aload #5
    //   204: aconst_null
    //   205: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;)V
    //   208: astore_0
    //   209: goto -> 629
    //   212: new com/dropbox/core/RateLimitException
    //   215: dup
    //   216: aload #5
    //   218: aconst_null
    //   219: aload_0
    //   220: ldc 'Retry-After'
    //   222: invokestatic o : (Ldbxyzptlk/Ck/a$b;Ljava/lang/String;)Ljava/lang/String;
    //   225: invokestatic parseInt : (Ljava/lang/String;)I
    //   228: i2l
    //   229: getstatic java/util/concurrent/TimeUnit.SECONDS : Ljava/util/concurrent/TimeUnit;
    //   232: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;JLjava/util/concurrent/TimeUnit;)V
    //   235: astore_0
    //   236: goto -> 165
    //   239: astore_0
    //   240: new com/dropbox/core/BadResponseException
    //   243: dup
    //   244: aload #5
    //   246: ldc 'Invalid value for HTTP header: "Retry-After"'
    //   248: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;)V
    //   251: astore_0
    //   252: goto -> 629
    //   255: new com/dropbox/core/a$a
    //   258: astore_3
    //   259: aload_3
    //   260: getstatic dbxyzptlk/fl/c$b.b : Ldbxyzptlk/fl/c$b;
    //   263: invokespecial <init> : (Ldbxyzptlk/Hk/c;)V
    //   266: aload_3
    //   267: aload_0
    //   268: invokevirtual b : ()Ljava/io/InputStream;
    //   271: invokevirtual b : (Ljava/io/InputStream;)Ljava/lang/Object;
    //   274: checkcast com/dropbox/core/a
    //   277: astore_3
    //   278: aload #4
    //   280: astore_0
    //   281: aload_3
    //   282: invokevirtual b : ()Ldbxyzptlk/kk/j;
    //   285: ifnull -> 307
    //   288: aload_3
    //   289: invokevirtual b : ()Ldbxyzptlk/kk/j;
    //   292: invokevirtual toString : ()Ljava/lang/String;
    //   295: astore_0
    //   296: goto -> 307
    //   299: astore_0
    //   300: goto -> 328
    //   303: astore_0
    //   304: goto -> 337
    //   307: new com/dropbox/core/PathRootErrorException
    //   310: dup
    //   311: aload #5
    //   313: aload_0
    //   314: aload_3
    //   315: invokevirtual a : ()Ljava/lang/Object;
    //   318: checkcast dbxyzptlk/fl/c
    //   321: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ldbxyzptlk/fl/c;)V
    //   324: astore_0
    //   325: goto -> 629
    //   328: new com/dropbox/core/NetworkIOException
    //   331: dup
    //   332: aload_0
    //   333: invokespecial <init> : (Ljava/io/IOException;)V
    //   336: athrow
    //   337: new java/lang/StringBuilder
    //   340: dup
    //   341: invokespecial <init> : ()V
    //   344: astore_1
    //   345: aload_1
    //   346: ldc 'Bad JSON: '
    //   348: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   351: pop
    //   352: aload_1
    //   353: aload_0
    //   354: invokevirtual getMessage : ()Ljava/lang/String;
    //   357: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   360: pop
    //   361: new com/dropbox/core/BadResponseException
    //   364: dup
    //   365: aload #5
    //   367: aload_1
    //   368: invokevirtual toString : ()Ljava/lang/String;
    //   371: aload_0
    //   372: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V
    //   375: athrow
    //   376: new com/dropbox/core/a$a
    //   379: astore #4
    //   381: aload #4
    //   383: getstatic dbxyzptlk/Tk/a$b.b : Ldbxyzptlk/Tk/a$b;
    //   386: invokespecial <init> : (Ldbxyzptlk/Hk/c;)V
    //   389: aload #4
    //   391: aload_0
    //   392: invokevirtual b : ()Ljava/io/InputStream;
    //   395: invokevirtual b : (Ljava/io/InputStream;)Ljava/lang/Object;
    //   398: checkcast com/dropbox/core/a
    //   401: astore #4
    //   403: aload_3
    //   404: astore_0
    //   405: aload #4
    //   407: invokevirtual b : ()Ldbxyzptlk/kk/j;
    //   410: ifnull -> 433
    //   413: aload #4
    //   415: invokevirtual b : ()Ldbxyzptlk/kk/j;
    //   418: invokevirtual toString : ()Ljava/lang/String;
    //   421: astore_0
    //   422: goto -> 433
    //   425: astore_0
    //   426: goto -> 455
    //   429: astore_1
    //   430: goto -> 464
    //   433: new com/dropbox/core/AccessErrorException
    //   436: dup
    //   437: aload #5
    //   439: aload_0
    //   440: aload #4
    //   442: invokevirtual a : ()Ljava/lang/Object;
    //   445: checkcast dbxyzptlk/Tk/a
    //   448: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ldbxyzptlk/Tk/a;)V
    //   451: astore_0
    //   452: goto -> 629
    //   455: new com/dropbox/core/NetworkIOException
    //   458: dup
    //   459: aload_0
    //   460: invokespecial <init> : (Ljava/io/IOException;)V
    //   463: athrow
    //   464: new java/lang/StringBuilder
    //   467: dup
    //   468: invokespecial <init> : ()V
    //   471: astore_0
    //   472: aload_0
    //   473: ldc 'Bad JSON: '
    //   475: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   478: pop
    //   479: aload_0
    //   480: aload_1
    //   481: invokevirtual getMessage : ()Ljava/lang/String;
    //   484: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   487: pop
    //   488: new com/dropbox/core/BadResponseException
    //   491: dup
    //   492: aload #5
    //   494: aload_0
    //   495: invokevirtual toString : ()Ljava/lang/String;
    //   498: aload_1
    //   499: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V
    //   502: athrow
    //   503: aload_0
    //   504: aload #5
    //   506: invokestatic s : (Ldbxyzptlk/Ck/a$b;Ljava/lang/String;)Ljava/lang/String;
    //   509: astore_0
    //   510: aload_0
    //   511: invokevirtual isEmpty : ()Z
    //   514: ifeq -> 534
    //   517: new com/dropbox/core/InvalidAccessTokenException
    //   520: dup
    //   521: aload #5
    //   523: aload_0
    //   524: getstatic dbxyzptlk/Tk/b.c : Ldbxyzptlk/Tk/b;
    //   527: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ldbxyzptlk/Tk/b;)V
    //   530: astore_0
    //   531: goto -> 629
    //   534: new com/dropbox/core/a$a
    //   537: astore_3
    //   538: aload_3
    //   539: getstatic dbxyzptlk/Tk/b$b.b : Ldbxyzptlk/Tk/b$b;
    //   542: invokespecial <init> : (Ldbxyzptlk/Hk/c;)V
    //   545: new com/dropbox/core/InvalidAccessTokenException
    //   548: dup
    //   549: aload #5
    //   551: aload_0
    //   552: aload_3
    //   553: aload_0
    //   554: invokevirtual c : (Ljava/lang/String;)Ljava/lang/Object;
    //   557: checkcast com/dropbox/core/a
    //   560: invokevirtual a : ()Ljava/lang/Object;
    //   563: checkcast dbxyzptlk/Tk/b
    //   566: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ldbxyzptlk/Tk/b;)V
    //   569: astore_0
    //   570: goto -> 629
    //   573: astore_1
    //   574: new java/lang/StringBuilder
    //   577: dup
    //   578: invokespecial <init> : ()V
    //   581: astore_0
    //   582: aload_0
    //   583: ldc 'Bad JSON: '
    //   585: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   588: pop
    //   589: aload_0
    //   590: aload_1
    //   591: invokevirtual getMessage : ()Ljava/lang/String;
    //   594: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   597: pop
    //   598: new com/dropbox/core/BadResponseException
    //   601: dup
    //   602: aload #5
    //   604: aload_0
    //   605: invokevirtual toString : ()Ljava/lang/String;
    //   608: aload_1
    //   609: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V
    //   612: athrow
    //   613: new com/dropbox/core/BadRequestException
    //   616: dup
    //   617: aload #5
    //   619: aload_0
    //   620: aload #5
    //   622: invokestatic s : (Ldbxyzptlk/Ck/a$b;Ljava/lang/String;)Ljava/lang/String;
    //   625: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;)V
    //   628: astore_0
    //   629: getstatic com/dropbox/core/c.b : Ldbxyzptlk/Vk/a;
    //   632: astore_3
    //   633: aload_3
    //   634: ifnull -> 648
    //   637: aload_3
    //   638: aload_1
    //   639: invokeinterface a : (Ljava/lang/String;)Ldbxyzptlk/Vk/b;
    //   644: aload_0
    //   645: invokevirtual a : (Lcom/dropbox/core/DbxException;)V
    //   648: aload_0
    //   649: areturn
    // Exception table:
    //   from	to	target	type
    //   134	165	182	java/lang/NumberFormatException
    //   168	179	182	java/lang/NumberFormatException
    //   212	236	239	java/lang/NumberFormatException
    //   255	278	303	com/fasterxml/jackson/core/JsonProcessingException
    //   255	278	299	java/io/IOException
    //   281	296	303	com/fasterxml/jackson/core/JsonProcessingException
    //   281	296	299	java/io/IOException
    //   307	325	303	com/fasterxml/jackson/core/JsonProcessingException
    //   307	325	299	java/io/IOException
    //   376	403	429	com/fasterxml/jackson/core/JsonProcessingException
    //   376	403	425	java/io/IOException
    //   405	422	429	com/fasterxml/jackson/core/JsonProcessingException
    //   405	422	425	java/io/IOException
    //   433	452	429	com/fasterxml/jackson/core/JsonProcessingException
    //   433	452	425	java/io/IOException
    //   534	570	573	com/fasterxml/jackson/core/JsonParseException
  }
  
  public static List<a.a> a(List<a.a> paramList, String paramString) {
    if (paramString != null) {
      List<a.a> list = paramList;
      if (paramList == null)
        list = new ArrayList<>(); 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Bearer ");
      stringBuilder.append(paramString);
      list.add(new a.a("Authorization", stringBuilder.toString()));
      return list;
    } 
    throw new NullPointerException("accessToken");
  }
  
  public static List<a.a> b(List<a.a> paramList, String paramString1, String paramString2) {
    if (paramString1 != null) {
      if (paramString2 != null) {
        List<a.a> list = paramList;
        if (paramList == null)
          list = new ArrayList<>(); 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(paramString1);
        stringBuilder.append(":");
        stringBuilder.append(paramString2);
        paramString1 = d.a(d.g(stringBuilder.toString()));
        stringBuilder = new StringBuilder();
        stringBuilder.append("Basic ");
        stringBuilder.append(paramString1);
        list.add(new a.a("Authorization", stringBuilder.toString()));
        return list;
      } 
      throw new NullPointerException("password");
    } 
    throw new NullPointerException("username");
  }
  
  public static List<a.a> c(List<a.a> paramList, b paramb) {
    return paramList;
  }
  
  public static List<a.a> d(List<a.a> paramList, f paramf, String paramString) {
    List<a.a> list = paramList;
    if (paramList == null)
      list = new ArrayList<>(); 
    list.add(h(paramf, paramString));
    return list;
  }
  
  public static List<a.a> e(List<a.a> paramList, f paramf) {
    if (paramf.e() == null)
      return paramList; 
    List<a.a> list = paramList;
    if (paramList == null)
      list = new ArrayList<>(); 
    list.add(new a.a("Dropbox-API-User-Locale", paramf.e()));
    return list;
  }
  
  public static String f(String paramString1, String paramString2) {
    try {
      URI uRI = new URI();
      StringBuilder stringBuilder = new StringBuilder();
      this();
      stringBuilder.append("/");
      stringBuilder.append(paramString2);
      this("https", paramString1, stringBuilder.toString(), null);
      return uRI.toASCIIString();
    } catch (URISyntaxException uRISyntaxException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("URI creation failed, host=");
      stringBuilder.append(d.f(paramString1));
      stringBuilder.append(", path=");
      stringBuilder.append(d.f(paramString2));
      throw dbxyzptlk.Mk.c.a(stringBuilder.toString(), uRISyntaxException);
    } 
  }
  
  public static String g(String paramString1, String paramString2, String paramString3, String[] paramArrayOfString) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(f(paramString2, paramString3));
    stringBuilder.append("?");
    stringBuilder.append(l(paramString1, paramArrayOfString));
    return stringBuilder.toString();
  }
  
  public static a.a h(f paramf, String paramString) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramf.b());
    stringBuilder.append(" ");
    stringBuilder.append(paramString);
    stringBuilder.append("/");
    stringBuilder.append("7.1.0-SNAPSHOT");
    return new a.a("User-Agent", stringBuilder.toString());
  }
  
  public static List<a.a> i(List<a.a> paramList) {
    return (paramList == null) ? new ArrayList<>() : new ArrayList<>(paramList);
  }
  
  public static <T> T j(f paramf, String paramString1, String paramString2, String paramString3, String[] paramArrayOfString, List<a.a> paramList, c<T> paramc) throws DbxException {
    return x(paramf.d(), (b<T, Throwable>)new a(paramf, paramString1, paramString2, paramString3, paramArrayOfString, paramList, paramc));
  }
  
  public static String k(String paramString) {
    try {
      return URLEncoder.encode(paramString, "UTF-8");
    } catch (UnsupportedEncodingException unsupportedEncodingException) {
      throw dbxyzptlk.Mk.c.a("UTF-8 should always be supported", unsupportedEncodingException);
    } 
  }
  
  public static String l(String paramString, String[] paramArrayOfString) {
    StringBuilder stringBuilder = new StringBuilder();
    if (paramString != null) {
      stringBuilder.append("locale=");
      stringBuilder.append(k(paramString));
      paramString = "&";
    } else {
      paramString = "";
    } 
    if (paramArrayOfString != null)
      if (paramArrayOfString.length % 2 == 0) {
        byte b = 0;
        String str = paramString;
        while (b < paramArrayOfString.length) {
          String str1 = paramArrayOfString[b];
          String str2 = paramArrayOfString[b + 1];
          if (str1 != null) {
            paramString = str;
            if (str2 != null) {
              stringBuilder.append(str);
              stringBuilder.append(k(str1));
              stringBuilder.append("=");
              stringBuilder.append(k(str2));
              paramString = "&";
            } 
            b += 2;
            str = paramString;
            continue;
          } 
          StringBuilder stringBuilder1 = new StringBuilder();
          stringBuilder1.append("params[");
          stringBuilder1.append(b);
          stringBuilder1.append("] is null");
          throw new IllegalArgumentException(stringBuilder1.toString());
        } 
      } else {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("'params.length' is ");
        stringBuilder1.append(paramArrayOfString.length);
        stringBuilder1.append("; expecting a multiple of two");
        throw new IllegalArgumentException(stringBuilder1.toString());
      }  
    return stringBuilder.toString();
  }
  
  public static <T> T m(a.b paramb, c<T> paramc) throws DbxException {
    try {
      return (T)paramc.a(paramb);
    } finally {
      if (paramb != null)
        IOUtil.a(paramb.b()); 
    } 
  }
  
  public static String n(a.b paramb) {
    return p(paramb, "Content-Type");
  }
  
  public static String o(a.b paramb, String paramString) throws BadResponseException {
    List<String> list = (List)paramb.c().get(paramString);
    if (list != null && !list.isEmpty())
      return list.get(0); 
    String str = q(paramb);
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("missing HTTP header \"");
    stringBuilder.append(paramString);
    stringBuilder.append("\"");
    throw new BadResponseException(str, stringBuilder.toString());
  }
  
  public static String p(a.b paramb, String paramString) {
    List<String> list = (List)paramb.c().get(paramString);
    return (list == null || list.isEmpty()) ? null : list.get(0);
  }
  
  public static String q(a.b paramb) {
    return p(paramb, "X-Dropbox-Request-Id");
  }
  
  public static byte[] r(a.b paramb) throws NetworkIOException {
    if (paramb.b() == null)
      return new byte[0]; 
    try {
      return IOUtil.f(paramb.b(), 4096);
    } catch (IOException iOException) {
      throw new NetworkIOException(iOException);
    } 
  }
  
  public static String s(a.b paramb, String paramString) throws NetworkIOException, BadResponseException {
    byte[] arrayOfByte = r(paramb);
    return t(paramString, paramb.d(), arrayOfByte);
  }
  
  public static String t(String paramString, int paramInt, byte[] paramArrayOfbyte) throws BadResponseException {
    try {
      return d.i(paramArrayOfbyte);
    } catch (CharacterCodingException characterCodingException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Got non-UTF8 response body: ");
      stringBuilder.append(paramInt);
      stringBuilder.append(": ");
      stringBuilder.append(characterCodingException.getMessage());
      throw new BadResponseException(paramString, stringBuilder.toString());
    } 
  }
  
  public static <T> T u(dbxyzptlk.Hk.c<T> paramc, String paramString1, String paramString2) throws JsonParseException {
    return (T)((a)(new a.a(paramc)).c(paramString1)).a();
  }
  
  public static <T> T v(JsonReader<T> paramJsonReader, a.b paramb) throws BadResponseException, NetworkIOException {
    try {
      return (T)paramJsonReader.h(paramb.b());
    } catch (JsonReadException jsonReadException) {
    
    } catch (IOException iOException) {}
    throw new NetworkIOException(iOException);
  }
  
  public static List<a.a> w(List<a.a> paramList) {
    if (paramList == null)
      return new ArrayList<>(); 
    ArrayList<a.a> arrayList = new ArrayList();
    for (a.a a1 : paramList) {
      if ("Authorization".equals(a1.a()))
        arrayList.add(a1); 
    } 
    paramList.removeAll(arrayList);
    return paramList;
  }
  
  public static <T, E extends Throwable> T x(int paramInt, b<T, E> paramb) throws DbxException, E {
    byte b1 = 0;
    while (true) {
      long l;
      try {
        return (T)paramb.a();
      } catch (RetryException retryException) {
        l = retryException.b();
      } catch (ServerException serverException) {
        l = 0L;
      } 
      if (b1 < paramInt) {
        l += a.nextInt(1000);
        if (l > 0L)
          try {
            Thread.sleep(l);
          } catch (InterruptedException interruptedException) {
            Thread.currentThread().interrupt();
          }  
        b1++;
        continue;
      } 
      throw interruptedException;
    } 
  }
  
  public static a.b y(f paramf, String paramString1, String paramString2, String paramString3, String[] paramArrayOfString, List<a.a> paramList) throws NetworkIOException {
    byte[] arrayOfByte = d.g(l(paramf.e(), paramArrayOfString));
    paramList = i(paramList);
    paramList.add(new a.a("Content-Type", "application/x-www-form-urlencoded; charset=utf-8"));
    return z(paramf, paramString1, paramString2, paramString3, arrayOfByte, paramList);
  }
  
  public static a.b z(f paramf, String paramString1, String paramString2, String paramString3, byte[] paramArrayOfbyte, List<a.a> paramList) throws NetworkIOException {
    paramString2 = f(paramString2, paramString3);
    List<a.a> list = d(i(paramList), paramf, paramString1);
    list.add(new a.a("Content-Length", Integer.toString(paramArrayOfbyte.length)));
    try {
      a.c c1 = paramf.c().a(paramString2, list);
      try {
        c1.g(paramArrayOfbyte);
        a.b b = c1.c();
        c1.b();
        return b;
      } finally {}
    } catch (IOException iOException) {}
    iOException.b();
    throw list;
  }
  
  class c {}
  
  class c {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\core\c.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */