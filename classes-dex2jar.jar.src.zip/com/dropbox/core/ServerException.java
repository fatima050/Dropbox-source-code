package com.dropbox.core;

public class ServerException extends DbxException {
  private static final long serialVersionUID = 0L;
  
  public ServerException(String paramString1, String paramString2) {
    super(paramString1, paramString2);
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\core\ServerException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */