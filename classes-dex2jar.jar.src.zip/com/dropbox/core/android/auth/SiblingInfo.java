package com.dropbox.core.android.auth;

import android.os.Parcel;
import android.os.Parcelable;
import dbxyzptlk.CC.p;
import dbxyzptlk.YJ.t;
import dbxyzptlk.mk.s0;
import dbxyzptlk.mk.z0;
import java.util.Objects;

public class SiblingInfo implements Parcelable {
  public static final Parcelable.Creator<SiblingInfo> CREATOR = (Parcelable.Creator<SiblingInfo>)new a();
  
  public final String a;
  
  public final String b;
  
  public final s0 c;
  
  public SiblingInfo(Parcel paramParcel) {
    this.a = paramParcel.readString();
    this.b = paramParcel.readString();
    this.c = s0.valueOf(paramParcel.readString());
  }
  
  public SiblingInfo(String paramString1, String paramString2, s0 params0) {
    p.d(t.C(paramString1) ^ true);
    p.d(t.C(paramString2) ^ true);
    p.o(params0);
    this.a = paramString1;
    this.b = paramString2;
    this.c = params0;
  }
  
  public int describeContents() {
    return 0;
  }
  
  public boolean equals(Object paramObject) {
    boolean bool = true;
    if (this == paramObject)
      return true; 
    if (paramObject == null || getClass() != paramObject.getClass())
      return false; 
    paramObject = paramObject;
    if (!Objects.equals(this.a, ((SiblingInfo)paramObject).a) || !Objects.equals(this.b, ((SiblingInfo)paramObject).b) || this.c != ((SiblingInfo)paramObject).c)
      bool = false; 
    return bool;
  }
  
  public int hashCode() {
    return Objects.hash(new Object[] { this.a, this.b, this.c });
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    paramParcel.writeString(this.a);
    paramParcel.writeString(this.b);
    paramParcel.writeString(this.c.name());
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\core\android\auth\SiblingInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */