package com.dropbox.core;

public abstract class ProtocolException extends DbxException {
  private static final long serialVersionUID = 0L;
  
  public ProtocolException(String paramString1, String paramString2) {
    super(paramString1, paramString2);
  }
  
  public ProtocolException(String paramString1, String paramString2, Throwable paramThrowable) {
    super(paramString1, paramString2, paramThrowable);
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\core\ProtocolException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */