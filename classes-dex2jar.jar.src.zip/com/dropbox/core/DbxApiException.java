package com.dropbox.core;

import dbxyzptlk.kk.j;

public class DbxApiException extends DbxException {
  private static final long serialVersionUID = 0L;
  
  public final j b;
  
  public DbxApiException(String paramString1, j paramj, String paramString2) {
    super(paramString1, paramString2);
    this.b = paramj;
  }
  
  public static String b(String paramString, j paramj, Object paramObject) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Exception in ");
    stringBuilder.append(paramString);
    if (paramObject != null) {
      stringBuilder.append(": ");
      stringBuilder.append(paramObject);
    } 
    if (paramj != null) {
      stringBuilder.append(" (user message: ");
      stringBuilder.append(paramj);
      stringBuilder.append(")");
    } 
    return stringBuilder.toString();
  }
  
  public j c() {
    return this.b;
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\core\DbxApiException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */