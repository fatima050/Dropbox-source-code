package com.dropbox.core.json;

import com.fasterxml.jackson.core.JsonProcessingException;
import dbxyzptlk.wA.f;
import java.io.File;

public final class JsonReadException extends Exception {
  public static final long serialVersionUID = 0L;
  
  public final String a;
  
  public final f b;
  
  public a c;
  
  public JsonReadException(String paramString, f paramf) {
    this.a = paramString;
    this.b = paramf;
    this.c = null;
  }
  
  public static JsonReadException b(JsonProcessingException paramJsonProcessingException) {
    String str2 = paramJsonProcessingException.getMessage();
    int i = str2.lastIndexOf(" at [Source");
    String str1 = str2;
    if (i >= 0)
      str1 = str2.substring(0, i); 
    return new JsonReadException(str1, paramJsonProcessingException.a());
  }
  
  public static void c(StringBuilder paramStringBuilder, f paramf) {
    Object object = paramf.d();
    if (object instanceof File) {
      paramStringBuilder.append(((File)object).getPath());
      paramStringBuilder.append(": ");
    } 
    paramStringBuilder.append(paramf.c());
    paramStringBuilder.append(".");
    paramStringBuilder.append(paramf.b());
  }
  
  public JsonReadException a(String paramString) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append('"');
    stringBuilder.append(paramString);
    stringBuilder.append('"');
    this.c = new a(stringBuilder.toString(), this.c);
    return this;
  }
  
  public String getMessage() {
    StringBuilder stringBuilder = new StringBuilder();
    c(stringBuilder, this.b);
    stringBuilder.append(": ");
    a a1 = this.c;
    if (a1 != null) {
      stringBuilder.append(a1.a);
      while (true) {
        a1 = a1.b;
        if (a1 != null) {
          stringBuilder.append(".");
          stringBuilder.append(a1.a);
          continue;
        } 
        stringBuilder.append(": ");
        break;
      } 
    } 
    stringBuilder.append(this.a);
    return stringBuilder.toString();
  }
  
  class JsonReadException {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\core\json\JsonReadException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */