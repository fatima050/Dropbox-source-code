package com.dropbox.core.json;

import com.fasterxml.jackson.core.JsonParseException;
import java.io.IOException;
import java.io.InputStream;

public abstract class JsonReader<T> {
  public static final JsonReader<Long> a = new c();
  
  public static final JsonReader<Long> b = new d();
  
  public static final JsonReader<Integer> c = new e();
  
  public static final JsonReader<Long> d = new f();
  
  public static final JsonReader<Long> e = new g();
  
  public static final JsonReader<Double> f = new h();
  
  public static final JsonReader<Float> g = new i();
  
  public static final JsonReader<String> h = new j();
  
  public static final JsonReader<byte[]> i = new k();
  
  public static final JsonReader<Boolean> j = new a();
  
  public static final JsonReader<Object> k = new b();
  
  public static final dbxyzptlk.wA.d l = new dbxyzptlk.wA.d();
  
  public static void a(dbxyzptlk.wA.g paramg) throws IOException, JsonReadException {
    if (paramg.h() == dbxyzptlk.wA.i.END_OBJECT) {
      c(paramg);
      return;
    } 
    throw new JsonReadException("expecting the end of an object (\"}\")", paramg.r());
  }
  
  public static dbxyzptlk.wA.f b(dbxyzptlk.wA.g paramg) throws IOException, JsonReadException {
    if (paramg.h() == dbxyzptlk.wA.i.START_OBJECT) {
      dbxyzptlk.wA.f f = paramg.r();
      c(paramg);
      return f;
    } 
    throw new JsonReadException("expecting the start of an object (\"{\")", paramg.r());
  }
  
  public static dbxyzptlk.wA.i c(dbxyzptlk.wA.g paramg) throws IOException, JsonReadException {
    try {
      return paramg.u();
    } catch (JsonParseException jsonParseException) {
      throw JsonReadException.b(jsonParseException);
    } 
  }
  
  public static boolean e(dbxyzptlk.wA.g paramg) throws IOException, JsonReadException {
    try {
      boolean bool = paramg.e();
      paramg.u();
      return bool;
    } catch (JsonParseException jsonParseException) {
      throw JsonReadException.b(jsonParseException);
    } 
  }
  
  public static long i(dbxyzptlk.wA.g paramg) throws IOException, JsonReadException {
    try {
      l = paramg.o();
      if (l >= 0L) {
        paramg.u();
        return l;
      } 
    } catch (JsonParseException jsonParseException) {}
    JsonReadException jsonReadException = new JsonReadException();
    StringBuilder stringBuilder = new StringBuilder();
    this();
    long l;
    stringBuilder.append("expecting a non-negative number, got: ");
    stringBuilder.append(l);
    this(stringBuilder.toString(), jsonParseException.r());
    throw jsonReadException;
  }
  
  public static void j(dbxyzptlk.wA.g paramg) throws IOException, JsonReadException {
    try {
      paramg.x();
      paramg.u();
      return;
    } catch (JsonParseException jsonParseException) {
      throw JsonReadException.b(jsonParseException);
    } 
  }
  
  public abstract T d(dbxyzptlk.wA.g paramg) throws IOException, JsonReadException;
  
  public final T f(dbxyzptlk.wA.g paramg, String paramString, Object paramObject) throws IOException, JsonReadException {
    if (paramObject == null)
      return d(paramg); 
    paramObject = new StringBuilder();
    paramObject.append("duplicate field \"");
    paramObject.append(paramString);
    paramObject.append("\"");
    throw new JsonReadException(paramObject.toString(), paramg.r());
  }
  
  public T g(dbxyzptlk.wA.g paramg) throws IOException, JsonReadException {
    paramg.u();
    T t = d(paramg);
    if (paramg.h() == null) {
      k(t);
      return t;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("The JSON library should ensure there's no tokens after the main value: ");
    stringBuilder.append(paramg.h());
    stringBuilder.append("@");
    stringBuilder.append(paramg.f());
    throw new AssertionError(stringBuilder.toString());
  }
  
  public T h(InputStream paramInputStream) throws IOException, JsonReadException {
    try {
      return g(l.s(paramInputStream));
    } catch (JsonParseException jsonParseException) {
      throw JsonReadException.b(jsonParseException);
    } 
  }
  
  public void k(T paramT) {}
  
  class JsonReader {}
  
  public class a extends JsonReader<Boolean> {
    public Boolean l(dbxyzptlk.wA.g param1g) throws IOException, JsonReadException {
      return Boolean.valueOf(JsonReader.e(param1g));
    }
  }
  
  public class b extends JsonReader<Object> {
    public Object d(dbxyzptlk.wA.g param1g) throws IOException, JsonReadException {
      JsonReader.j(param1g);
      return null;
    }
  }
  
  public class c extends JsonReader<Long> {
    public Long l(dbxyzptlk.wA.g param1g) throws IOException, JsonReadException {
      return Long.valueOf(JsonReader.i(param1g));
    }
  }
  
  public class d extends JsonReader<Long> {
    public Long l(dbxyzptlk.wA.g param1g) throws IOException, JsonReadException {
      long l = param1g.o();
      param1g.u();
      return Long.valueOf(l);
    }
  }
  
  public class e extends JsonReader<Integer> {
    public Integer l(dbxyzptlk.wA.g param1g) throws IOException, JsonReadException {
      int i = param1g.n();
      param1g.u();
      return Integer.valueOf(i);
    }
  }
  
  public class f extends JsonReader<Long> {
    public Long l(dbxyzptlk.wA.g param1g) throws IOException, JsonReadException {
      return Long.valueOf(JsonReader.i(param1g));
    }
  }
  
  public class g extends JsonReader<Long> {
    public Long l(dbxyzptlk.wA.g param1g) throws IOException, JsonReadException {
      long l = JsonReader.i(param1g);
      if (l < 4294967296L)
        return Long.valueOf(l); 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("expecting a 32-bit unsigned integer, got: ");
      stringBuilder.append(l);
      throw new JsonReadException(stringBuilder.toString(), param1g.r());
    }
  }
  
  public class h extends JsonReader<Double> {
    public Double l(dbxyzptlk.wA.g param1g) throws IOException, JsonReadException {
      double d = param1g.i();
      param1g.u();
      return Double.valueOf(d);
    }
  }
  
  public class i extends JsonReader<Float> {
    public Float l(dbxyzptlk.wA.g param1g) throws IOException, JsonReadException {
      float f = param1g.l();
      param1g.u();
      return Float.valueOf(f);
    }
  }
  
  public class j extends JsonReader<String> {
    public String l(dbxyzptlk.wA.g param1g) throws IOException, JsonReadException {
      try {
        String str = param1g.q();
        param1g.u();
        return str;
      } catch (JsonParseException jsonParseException) {
        throw JsonReadException.b(jsonParseException);
      } 
    }
  }
  
  public class k extends JsonReader<byte[]> {
    public byte[] l(dbxyzptlk.wA.g param1g) throws IOException, JsonReadException {
      try {
        byte[] arrayOfByte = param1g.c();
        param1g.u();
        return arrayOfByte;
      } catch (JsonParseException jsonParseException) {
        throw JsonReadException.b(jsonParseException);
      } 
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\core\json\JsonReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */