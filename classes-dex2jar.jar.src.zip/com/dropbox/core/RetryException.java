package com.dropbox.core;

import java.util.concurrent.TimeUnit;

public class RetryException extends DbxException {
  private static final long serialVersionUID = 0L;
  
  public final long b;
  
  public RetryException(String paramString1, String paramString2) {
    this(paramString1, paramString2, 0L, TimeUnit.MILLISECONDS);
  }
  
  public RetryException(String paramString1, String paramString2, long paramLong, TimeUnit paramTimeUnit) {
    super(paramString1, paramString2);
    this.b = paramTimeUnit.toMillis(paramLong);
  }
  
  public long b() {
    return this.b;
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\core\RetryException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */