package com.dropbox.core.v2.loginviaemail;

import com.dropbox.core.DbxApiException;
import dbxyzptlk.Nl.c;
import dbxyzptlk.kk.j;

public class LoginViaEmailFinishErrorException extends DbxApiException {
  private static final long serialVersionUID = 0L;
  
  public final c c;
  
  public LoginViaEmailFinishErrorException(String paramString1, String paramString2, j paramj, c paramc) {
    super(paramString2, paramj, DbxApiException.b(paramString1, paramj, paramc));
    if (paramc != null) {
      this.c = paramc;
      return;
    } 
    throw new NullPointerException("errorValue");
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\core\v2\loginviaemail\LoginViaEmailFinishErrorException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */