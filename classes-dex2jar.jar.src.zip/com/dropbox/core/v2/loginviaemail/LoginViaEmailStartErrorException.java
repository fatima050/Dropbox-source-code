package com.dropbox.core.v2.loginviaemail;

import com.dropbox.core.DbxApiException;
import dbxyzptlk.Nl.f;
import dbxyzptlk.kk.j;

public class LoginViaEmailStartErrorException extends DbxApiException {
  private static final long serialVersionUID = 0L;
  
  public final f c;
  
  public LoginViaEmailStartErrorException(String paramString1, String paramString2, j paramj, f paramf) {
    super(paramString2, paramj, DbxApiException.b(paramString1, paramj, paramf));
    if (paramf != null) {
      this.c = paramf;
      return;
    } 
    throw new NullPointerException("errorValue");
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\core\v2\loginviaemail\LoginViaEmailStartErrorException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */