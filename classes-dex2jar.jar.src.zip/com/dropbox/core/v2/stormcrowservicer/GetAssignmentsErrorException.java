package com.dropbox.core.v2.stormcrowservicer;

import com.dropbox.core.DbxApiException;
import dbxyzptlk.kk.j;
import dbxyzptlk.pm.m;

public class GetAssignmentsErrorException extends DbxApiException {
  private static final long serialVersionUID = 0L;
  
  public final m c;
  
  public GetAssignmentsErrorException(String paramString1, String paramString2, j paramj, m paramm) {
    super(paramString2, paramj, DbxApiException.b(paramString1, paramj, paramm));
    if (paramm != null) {
      this.c = paramm;
      return;
    } 
    throw new NullPointerException("errorValue");
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\core\v2\stormcrowservicer\GetAssignmentsErrorException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */