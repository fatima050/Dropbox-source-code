package com.dropbox.core.oauth;

import com.dropbox.core.DbxException;
import dbxyzptlk.Fk.b;

public class DbxOAuthException extends DbxException {
  private static final long serialVersionUID = 0L;
  
  public final b b;
  
  public DbxOAuthException(String paramString, b paramb) {
    super(paramString, paramb.b());
    this.b = paramb;
  }
  
  public b b() {
    return this.b;
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\core\oauth\DbxOAuthException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */