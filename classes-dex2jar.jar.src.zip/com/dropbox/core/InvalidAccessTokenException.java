package com.dropbox.core;

import dbxyzptlk.Tk.b;

public class InvalidAccessTokenException extends DbxException {
  private static final long serialVersionUID = 0L;
  
  public b b;
  
  public InvalidAccessTokenException(String paramString1, String paramString2, b paramb) {
    super(paramString1, paramString2);
    this.b = paramb;
  }
  
  public b b() {
    return this.b;
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\core\InvalidAccessTokenException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */