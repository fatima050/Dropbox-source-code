package com.dropbox.core;

import java.io.IOException;
import java.security.cert.CertPathValidatorException;

public class NetworkIOException extends DbxException {
  private static final long serialVersionUID = 0L;
  
  public NetworkIOException(IOException paramIOException) {
    super(b(paramIOException), paramIOException);
  }
  
  public static String b(IOException paramIOException) {
    String str2 = paramIOException.getMessage();
    String str1 = str2;
    if (paramIOException instanceof javax.net.ssl.SSLHandshakeException) {
      Throwable throwable = paramIOException.getCause();
      str1 = str2;
      if (throwable instanceof CertPathValidatorException) {
        CertPathValidatorException certPathValidatorException = (CertPathValidatorException)throwable;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(str2);
        stringBuilder.append("[CERT PATH: ");
        stringBuilder.append(certPathValidatorException.getCertPath());
        stringBuilder.append("]");
        str1 = stringBuilder.toString();
      } 
    } 
    return str1;
  }
  
  public IOException c() {
    return (IOException)super.getCause();
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\core\NetworkIOException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */