package com.dropbox.core;

import com.fasterxml.jackson.core.JsonParseException;
import dbxyzptlk.Ck.a;
import dbxyzptlk.Hk.c;
import dbxyzptlk.Vk.a;
import dbxyzptlk.kk.j;
import java.io.IOException;
import java.lang.reflect.Field;

public final class DbxWrappedException extends Exception {
  private static final long serialVersionUID = 0L;
  
  public final Object a;
  
  public final String b;
  
  public final j c;
  
  public DbxWrappedException(Object paramObject, String paramString, j paramj) {
    this.a = paramObject;
    this.b = paramString;
    this.c = paramj;
  }
  
  public static <T> void a(a parama, String paramString, T paramT) {
    if (parama != null)
      parama.b(paramString, paramT); 
  }
  
  public static void b(a parama, String paramString, Object paramObject) {
    try {
      null = paramObject.getClass().getMethod("tag", null).invoke(paramObject, null);
      StringBuilder stringBuilder = new StringBuilder();
      this();
      stringBuilder.append(null.toString().toLowerCase());
      stringBuilder.append("value");
      String str = stringBuilder.toString();
      for (Field field : paramObject.getClass().getDeclaredFields()) {
        if (field.getName().equalsIgnoreCase(str)) {
          field.setAccessible(true);
          a(parama, paramString, field.get(paramObject));
          break;
        } 
      } 
    } catch (Exception exception) {}
  }
  
  public static <T> DbxWrappedException c(c<T> paramc, a.b paramb, String paramString) throws IOException, JsonParseException {
    String str = c.q(paramb);
    a a = (a)(new a.a(paramc)).b(paramb.b());
    Object object = a.a();
    a a1 = c.b;
    a(a1, paramString, object);
    b(a1, paramString, object);
    return new DbxWrappedException(object, str, a.b());
  }
  
  public Object d() {
    return this.a;
  }
  
  public String e() {
    return this.b;
  }
  
  public j f() {
    return this.c;
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\core\DbxWrappedException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */