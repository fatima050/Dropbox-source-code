package com.dropbox.core;

public class DbxException extends Exception {
  private static final long serialVersionUID = 0L;
  
  public final String a;
  
  public DbxException(String paramString) {
    this((String)null, paramString);
  }
  
  public DbxException(String paramString1, String paramString2) {
    super(paramString2);
    this.a = paramString1;
  }
  
  public DbxException(String paramString1, String paramString2, Throwable paramThrowable) {
    super(paramString2, paramThrowable);
    this.a = paramString1;
  }
  
  public DbxException(String paramString, Throwable paramThrowable) {
    this(null, paramString, paramThrowable);
  }
  
  public String a() {
    return this.a;
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\core\DbxException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */