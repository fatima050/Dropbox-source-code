package com.dropbox.android.user;

import android.app.Application;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import com.dropbox.android.notifications.f;
import com.dropbox.android.taskqueue.RealThumbnailStore;
import com.dropbox.internalclient.UserApi;
import com.dropbox.internalclient.c;
import com.dropbox.product.android.dbapp.filecache.WriteableFileCacheManager;
import com.dropbox.product.dbapp.common.service.ApiService;
import com.google.common.collect.m;
import dbxyzptlk.A6.a;
import dbxyzptlk.A9.c;
import dbxyzptlk.B9.e;
import dbxyzptlk.Bq.h;
import dbxyzptlk.C6.a;
import dbxyzptlk.CC.p;
import dbxyzptlk.Ce.a;
import dbxyzptlk.Ce.g;
import dbxyzptlk.Cg.a;
import dbxyzptlk.Ck.a;
import dbxyzptlk.Ec.g;
import dbxyzptlk.Fa.a;
import dbxyzptlk.Fj.a;
import dbxyzptlk.Ge.c;
import dbxyzptlk.Hy.B;
import dbxyzptlk.Hy.f;
import dbxyzptlk.Hy.g;
import dbxyzptlk.Hy.h;
import dbxyzptlk.Ie.a;
import dbxyzptlk.Ij.d;
import dbxyzptlk.Ij.m;
import dbxyzptlk.Ij.s;
import dbxyzptlk.Ik.e;
import dbxyzptlk.It.e;
import dbxyzptlk.It.l;
import dbxyzptlk.Ja.g;
import dbxyzptlk.Jh.e;
import dbxyzptlk.Kh.f;
import dbxyzptlk.Kk.a;
import dbxyzptlk.Kk.c;
import dbxyzptlk.Kk.d;
import dbxyzptlk.Kk.e;
import dbxyzptlk.La.a;
import dbxyzptlk.Lk.c;
import dbxyzptlk.Lk.z;
import dbxyzptlk.Me.a;
import dbxyzptlk.Me.d;
import dbxyzptlk.Me.e;
import dbxyzptlk.Me.j;
import dbxyzptlk.Ne.a;
import dbxyzptlk.Nk.d;
import dbxyzptlk.Nq.W;
import dbxyzptlk.Ny.D;
import dbxyzptlk.Ny.E;
import dbxyzptlk.Ny.F;
import dbxyzptlk.Ny.L;
import dbxyzptlk.Ny.r;
import dbxyzptlk.Ny.u;
import dbxyzptlk.Ny.x;
import dbxyzptlk.Ny.y;
import dbxyzptlk.Ow.g;
import dbxyzptlk.Qa.g;
import dbxyzptlk.Qa.n0;
import dbxyzptlk.Qa.s;
import dbxyzptlk.Qa.u;
import dbxyzptlk.Qh.c;
import dbxyzptlk.Sa.f;
import dbxyzptlk.Sq.k;
import dbxyzptlk.Uw.E;
import dbxyzptlk.Xs.G;
import dbxyzptlk.Xs.L;
import dbxyzptlk.Xs.U;
import dbxyzptlk.Xs.b0;
import dbxyzptlk.Xs.i;
import dbxyzptlk.Xs.l0;
import dbxyzptlk.Xs.n0;
import dbxyzptlk.Xs.o0;
import dbxyzptlk.Xs.r0;
import dbxyzptlk.bK.F;
import dbxyzptlk.bt.a;
import dbxyzptlk.ch.m;
import dbxyzptlk.ck.s;
import dbxyzptlk.ck.t;
import dbxyzptlk.ck.v;
import dbxyzptlk.eH.C;
import dbxyzptlk.ef.b0;
import dbxyzptlk.ib.a;
import dbxyzptlk.ib.c;
import dbxyzptlk.ib.k;
import dbxyzptlk.ix.y;
import dbxyzptlk.iy.r;
import dbxyzptlk.iy.s;
import dbxyzptlk.iy.t;
import dbxyzptlk.iy.v;
import dbxyzptlk.iy.x;
import dbxyzptlk.kf.a;
import dbxyzptlk.kx.a;
import dbxyzptlk.nk.N;
import dbxyzptlk.nk.e;
import dbxyzptlk.nk.q;
import dbxyzptlk.ok.a;
import dbxyzptlk.pc.d0;
import dbxyzptlk.pc.e0;
import dbxyzptlk.pc.p0;
import dbxyzptlk.pc.u0;
import dbxyzptlk.pj.a;
import dbxyzptlk.pj.f;
import dbxyzptlk.pj.h;
import dbxyzptlk.pj.i;
import dbxyzptlk.pj.m;
import dbxyzptlk.ps.x;
import dbxyzptlk.qh.c;
import dbxyzptlk.rx.d;
import dbxyzptlk.sh.d;
import dbxyzptlk.sh.t;
import dbxyzptlk.sz.e;
import dbxyzptlk.uh.g;
import dbxyzptlk.un.g;
import dbxyzptlk.uv.c;
import dbxyzptlk.vh.c;
import dbxyzptlk.vh.g;
import dbxyzptlk.vq.f;
import dbxyzptlk.vq.g;
import dbxyzptlk.vq.k;
import dbxyzptlk.vq.l;
import dbxyzptlk.vx.d;
import dbxyzptlk.vx.l;
import dbxyzptlk.vx.y;
import dbxyzptlk.wq.i;
import dbxyzptlk.wq.k;
import dbxyzptlk.wq.p;
import dbxyzptlk.wq.r;
import dbxyzptlk.x9.I;
import dbxyzptlk.x9.O;
import dbxyzptlk.x9.V;
import dbxyzptlk.x9.l;
import dbxyzptlk.xn.a;
import dbxyzptlk.xx.g;
import dbxyzptlk.y6.a;
import dbxyzptlk.y9.a;
import dbxyzptlk.ye.C0;
import dbxyzptlk.ye.k0;
import dbxyzptlk.ye.z0;
import dbxyzptlk.yn.j;
import dbxyzptlk.z9.a;
import dbxyzptlk.z9.c;
import dbxyzptlk.z9.d;
import dbxyzptlk.z9.e;
import dbxyzptlk.z9.f;
import dbxyzptlk.z9.i;
import dbxyzptlk.z9.j;
import dbxyzptlk.zc.a;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class b extends DbxUserManager.a {
  public final y A;
  
  public final t B;
  
  public final a C;
  
  public final Set<c> D;
  
  public final s E;
  
  public final a F;
  
  public final l.a G;
  
  public final e H;
  
  public final W I;
  
  public final Application a;
  
  public final g b;
  
  public final y.b c;
  
  public final m d;
  
  public final i e;
  
  public final G f;
  
  public final f g;
  
  public final dbxyzptlk.ok.b h;
  
  public final dbxyzptlk.rk.b i;
  
  public final g j;
  
  public final g k;
  
  public final f l;
  
  public final h m;
  
  public final h n;
  
  public final e<e> o;
  
  public final k p;
  
  public final dbxyzptlk.t6.b q;
  
  public final a r;
  
  public final C s;
  
  public final F t;
  
  public final C0 u;
  
  public final a v;
  
  public final a w;
  
  public final l0 x;
  
  public final a y;
  
  public final m z;
  
  public b(Application paramApplication, g paramg, m paramm, y.b paramb, i parami, G paramG, f paramf, dbxyzptlk.ok.b paramb1, dbxyzptlk.rk.b paramb2, g paramg1, g paramg2, f paramf1, h paramh, h paramh1, e<e> parame, k paramk, dbxyzptlk.t6.b paramb3, a parama, C paramC, F paramF, C0 paramC0, a parama1, a parama2, l0 paraml0, a parama3, m paramm1, y paramy, t paramt, a parama4, Set<c> paramSet, s params, a parama5, l.a parama6, e parame1, W paramW) {
    this.a = paramApplication;
    this.b = paramg;
    this.c = paramb;
    this.d = paramm;
    this.e = parami;
    this.f = paramG;
    this.g = paramf;
    this.h = paramb1;
    this.i = paramb2;
    this.j = paramg1;
    this.k = paramg2;
    this.l = paramf1;
    this.m = paramh;
    this.n = paramh1;
    this.o = parame;
    this.p = (k)p.o(paramk);
    this.q = paramb3;
    this.r = parama;
    this.s = paramC;
    this.t = paramF;
    this.u = paramC0;
    this.v = parama1;
    this.w = parama2;
    this.x = paraml0;
    this.y = parama3;
    this.z = paramm1;
    this.A = paramy;
    this.B = paramt;
    this.C = parama4;
    this.D = paramSet;
    this.E = params;
    this.F = parama5;
    this.G = parama6;
    this.H = parame1;
    this.I = paramW;
  }
  
  public Set<String> a() {
    HashSet<String> hashSet = new HashSet();
    hashSet.addAll(this.c.b());
    hashSet.addAll(this.e.m());
    return hashSet;
  }
  
  public d0 b(d0 paramd0, a parama, u0 paramu0) {
    c c = g(paramu0, parama.n(), paramd0.G1(), paramd0.v1(), paramd0.V1(), paramd0.h());
    return (d0)new p0((p0)paramd0, parama, paramu0, c);
  }
  
  public d0 c(u0 paramu0, a parama, j paramj, DbxUserManager paramDbxUserManager, e parame) {
    String str = parama.n();
    this.E.i("defaultuserfactory.newuser", str, System.currentTimeMillis(), Collections.emptyMap(), new m());
    b0 b0 = b0.d(this.j, str);
    ThreadPoolExecutor threadPoolExecutor = new ThreadPoolExecutor(16, 16, 60L, TimeUnit.SECONDS, new LinkedBlockingQueue<>(), (ThreadFactory)c.a(b.class).a(), new ThreadPoolExecutor.AbortPolicy());
    threadPoolExecutor.allowCoreThreadTimeOut(true);
    r0 r0 = this.e.b(str);
    o0 o0 = this.e.a(str);
    y y1 = this.c.a(str);
    f f1 = this.m.c((f.b)new a(this, parama, paramDbxUserManager, b0, str), (f.a)new b(this, parama, paramDbxUserManager, b0, str));
    c c1 = new c(f1, this.r, str);
    d d = this.l.b((f.b)f1, this.r, str);
    a a1 = parama.e();
    c c = f(this.a.getApplicationContext(), str, d, r0, (g)b0, this.h, this.v, this.u, this.B, this.F);
    U u = new U(c.b.y());
    c c4 = this.e.g(str, u.a());
    c c2 = c.a;
    e e2 = q.a((a)new i((f.b)f1, this.n), (N)new e0(f1), this.r.e()).b();
    j j1 = new j(paramDbxUserManager, str, (a)new a((UserApi)c1), d, (e)paramj, this.u, this.j, Boolean.valueOf(this.C.a()));
    k k1 = new k((k)new p(d), (f)new i(), (l)new r((Context)this.a, (d)j1));
    dbxyzptlk.pb.b b2 = new dbxyzptlk.pb.b((UserApi)c1, d);
    c c3 = new c(d);
    a a2 = new a((UserApi)c1);
    l l = this.G.a(str);
    RealThumbnailStore realThumbnailStore = new RealThumbnailStore((k)new c(y1), r0.k(), r0.A(), (d)c3, (L)r0, this.q, (g)b0, l);
    com.dropbox.android.taskqueue.b b1 = new com.dropbox.android.taskqueue.b((a)new dbxyzptlk.ib.b(y1), r0.i(), r0.z(), (d)c3, (L)r0, this.p, this.q, (g)k1);
    e e1 = new e();
    v v = new v(this.q);
    r r = s.a((g)b0, this.u, (UserApi)c1, d, c.b.y(), y1, v, threadPoolExecutor, this.z);
    k0 k0 = z0.a((Context)this.a);
    O o = new O((Context)this.a, str);
    dbxyzptlk.Ja.b b3 = new dbxyzptlk.Ja.b((Context)this.a, o0, r, (g)e1, k0, this.u, (V)o, l);
    b0 b01 = new b0(this.e, this.f, r0, this.x, this.y, c4);
    com.dropbox.product.dbapp.downloadmanager.b b4 = new com.dropbox.product.dbapp.downloadmanager.b((Context)this.a, (g)e1, (WriteableFileCacheManager)b3, (d)c3, (t)r, (L)r0, (g)realThumbnailStore, (a)b1, this.q, (g)b0, this.d, this.p, (g)k1, k0, this.I);
    s s1 = new s((d)j1, c2, this.a.getApplicationContext(), false, (v)paramj);
    a a3 = new a((t)s1, (d)c2, paramj, new Handler(Looper.getMainLooper()));
    f f3 = new f((i)new e((dbxyzptlk.z9.b)new d(d.s(), this.t)));
    c c5 = new c((Context)this.a, str);
    dbxyzptlk.y9.b b5 = new dbxyzptlk.y9.b((g)b0, this.E);
    I i1 = new I((Context)this.a, str, r, new l((UserApi)c1, d, c.b.y(), (g)b0), (j)f3, paramj, this.g, b3, (g)realThumbnailStore, (g)e1, o0, b4, (g)b0, (a)b1, new d((Context)this.a, (e)b3, r0, c4, (n0)b01, (g)b0, this.u), this.a.getContentResolver(), c.b.y(), this.A, this.E, (V)o, (a)b5, (a)c5);
    g g1 = new g((g)b0, o0, y1, b3, r, this.s, (Context)this.a, (V)o);
    f f2 = new f(this.g, str);
    E e3 = a.a(d, r, this.w, this.j, this.a.getApplicationContext(), c.b.y(), str, this.u, j1.t0(), (l)i1);
    B b6 = new B((t)r, (x)r, (l)i1, b4, (g)e1, b0, (h)f2, this.d, o0, (t)s1, (g)this.b, (g)realThumbnailStore, (a)b1, this.p, (d)c2, e3, (WriteableFileCacheManager)b3);
    x x = dbxyzptlk.X9.b.a(d, r0.I(), a.F(j1.t0()));
    D d1 = new D(b0);
    F f4 = new F(d, (u)new E(this.h, this.a.getApplicationContext()));
    L l1 = new L((Context)this.a, c.b.y(), x, (y)paramj, parame.b(), this.i, (r)d1, (x)f4);
    u u1 = new u(str, (Context)this.a);
    n0 n0 = new n0(str);
    c c6 = g(paramu0, parama.n(), a3, (dbxyzptlk.uv.b)u1, n0, (d)j1);
    p0 p0 = new p0(parama, (d)j1, paramj, r0, o0, this.k, parame, y1, this.g, (UserApi)c1, d, (g)b0, paramu0, (d)c2, c.b, (g)realThumbnailStore, (a)b1, (ApiService)b2, (g)e1, v, r, b3, (l)i1, (a)i1, (d)c3, (a)a2, b4, g1, (f)b6, l1, a3, u1, n0, c6, threadPoolExecutor, (t)s1, this.u, e2, x, e3, (n0)b01, this.H, this.a.getApplicationContext(), a1);
    p0.n();
    this.E.c("defaultuserfactory.newuser", d.SUCCESS, str, System.currentTimeMillis(), Collections.emptyMap(), new m());
    return (d0)p0;
  }
  
  public final c f(Context paramContext, String paramString, d paramd, r0 paramr0, g paramg, dbxyzptlk.ok.b paramb, a parama, C0 paramC0, t paramt, a parama1) {
    a a1 = new a(paramg);
    e e1 = new e(paramd, paramb, parama, false, false);
    c c1 = z.a(paramContext, this.D, g.a(paramString, paramr0.v(), (g)e1, (d)a1, paramC0, paramt, parama1));
    c c = c1.a();
    c.d();
    return new c(c, (c)c1);
  }
  
  public final c g(u0 paramu0, String paramString, a parama, dbxyzptlk.uv.b paramb, n0 paramn0, d paramd) {
    p.o(paramString);
    p.o(paramb);
    p.o(paramn0);
    m.a a1 = new m.a();
    a1.i(paramb);
    a1.i(paramn0);
    if (paramu0 == u0.PERSONAL) {
      a1.i(new s(paramString, parama));
    } else if (paramu0 == u0.BUSINESS) {
      a1.i(new g(paramd));
    } 
    return new c((Set)a1.m());
  }
  
  class b {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\androi\\user\b.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */