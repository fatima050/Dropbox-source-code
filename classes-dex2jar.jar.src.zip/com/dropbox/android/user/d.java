package com.dropbox.android.user;

import dbxyzptlk.bH.e;
import dbxyzptlk.oI.a;

public final class d implements e<c> {
  public final a<e.a> a;
  
  public d(a<e.a> parama) {
    this.a = parama;
  }
  
  public static d a(a<e.a> parama) {
    return new d(parama);
  }
  
  public static c c(e.a parama) {
    return new c(parama);
  }
  
  public c b() {
    return c((e.a)this.a.get());
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\androi\\user\d.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */