package com.dropbox.android.user;

import android.content.Context;
import dbxyzptlk.bH.e;
import dbxyzptlk.lf.k;
import dbxyzptlk.oI.a;
import dbxyzptlk.ok.b;
import dbxyzptlk.qb.e;
import dbxyzptlk.un.g;

public final class f implements e<e.a> {
  public final a<Context> a;
  
  public final a<b> b;
  
  public final a<e.b> c;
  
  public final a<g> d;
  
  public final a<dbxyzptlk.Ny.f> e;
  
  public final a<k> f;
  
  public f(a<Context> parama, a<b> parama1, a<e.b> parama2, a<g> parama3, a<dbxyzptlk.Ny.f> parama4, a<k> parama5) {
    this.a = parama;
    this.b = parama1;
    this.c = parama2;
    this.d = parama3;
    this.e = parama4;
    this.f = parama5;
  }
  
  public static f a(a<Context> parama, a<b> parama1, a<e.b> parama2, a<g> parama3, a<dbxyzptlk.Ny.f> parama4, a<k> parama5) {
    return new f(parama, parama1, parama2, parama3, parama4, parama5);
  }
  
  public static e.a c(Context paramContext, b paramb, e.b paramb1, g paramg, dbxyzptlk.Ny.f paramf, k paramk) {
    return new e.a(paramContext, paramb, paramb1, paramg, paramf, paramk);
  }
  
  public e.a b() {
    return c((Context)this.a.get(), (b)this.b.get(), (e.b)this.c.get(), (g)this.d.get(), (dbxyzptlk.Ny.f)this.e.get(), (k)this.f.get());
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\androi\\user\f.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */