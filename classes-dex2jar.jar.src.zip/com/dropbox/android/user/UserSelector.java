package com.dropbox.android.user;

import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import dbxyzptlk.CC.p;
import dbxyzptlk.pc.d0;
import dbxyzptlk.pc.u0;

public abstract class UserSelector implements Parcelable {
  public static UserSelector c(u0 paramu0) {
    return (UserSelector)new b(paramu0);
  }
  
  public static UserSelector d(String paramString) {
    return (UserSelector)new a(paramString);
  }
  
  public static UserSelector e(Bundle paramBundle) {
    p.p(paramBundle, "No UserSelector Bundle specified");
    UserSelector userSelector = (UserSelector)paramBundle.getParcelable("com.dropbox.android.USER_SELECTOR_BUNDLE_KEY");
    p.p(userSelector, "No UserSelector specified");
    return userSelector;
  }
  
  public static d0 f(Intent paramIntent, a parama) {
    p.o(paramIntent);
    p.o(parama);
    Bundle bundle = paramIntent.getExtras();
    if (g(bundle)) {
      d0 d0 = e(bundle).b(parama);
      if (d0 != null)
        return d0; 
    } 
    return null;
  }
  
  public static boolean g(Bundle paramBundle) {
    boolean bool;
    if (paramBundle != null && paramBundle.containsKey("com.dropbox.android.USER_SELECTOR_BUNDLE_KEY")) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public static void h(Bundle paramBundle, UserSelector paramUserSelector) {
    paramBundle.putParcelable("com.dropbox.android.USER_SELECTOR_BUNDLE_KEY", (Parcelable)paramUserSelector);
  }
  
  public static Intent i(Intent paramIntent, UserSelector paramUserSelector) {
    return paramIntent.putExtra("com.dropbox.android.USER_SELECTOR_BUNDLE_KEY", (Parcelable)paramUserSelector);
  }
  
  public static void j(Intent paramIntent) {
    paramIntent.removeExtra("com.dropbox.android.USER_SELECTOR_BUNDLE_KEY");
  }
  
  public abstract d0 b(a parama);
  
  class UserSelector {}
  
  class UserSelector {}
  
  class UserSelector {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\androi\\user\UserSelector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */