package com.dropbox.android.user;

import android.os.Handler;
import android.os.Looper;
import dbxyzptlk.CC.p;
import dbxyzptlk.Ee.a;
import dbxyzptlk.qb.e;
import java.util.concurrent.atomic.AtomicBoolean;

public class g {
  public final Handler a = new Handler(Looper.getMainLooper());
  
  public a.b b;
  
  public a.f c;
  
  public final AtomicBoolean d = new AtomicBoolean(false);
  
  public void d() {
    this.a.post((Runnable)new b(this));
  }
  
  public final boolean e() {
    boolean bool;
    if (Looper.myLooper() == Looper.getMainLooper()) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public void f(a.b paramb, DbxUserManager paramDbxUserManager) {
    p.j(this.d.getAndSet(true) ^ true, "Assert failed: %1$s", "Setup should only be called once");
    a a = new a(this, paramb, paramDbxUserManager);
    if (!e()) {
      this.a.post((Runnable)a);
    } else {
      a.run();
    } 
  }
  
  public void g(a parama) {
    a.b b2 = parama.l();
    e e = parama.k().d();
    if (b2 == null || parama.t()) {
      e.j0(false);
      return;
    } 
    a.b b1 = this.b;
    if (b1 == null || !b1.j(b2))
      e.j0(true); 
  }
  
  class g {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\androi\\user\g.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */