package com.dropbox.android.user;

import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.Pair;
import com.dropbox.android.accounts.store.a;
import com.dropbox.android.accounts.store.b;
import com.dropbox.common.stormcrow_gen.StormcrowAndroidClearAccountsOnAddFailure;
import com.dropbox.core.android.auth.SharedAccount;
import com.google.common.collect.z;
import dbxyzptlk.C6.a;
import dbxyzptlk.C6.b;
import dbxyzptlk.CC.l;
import dbxyzptlk.CC.p;
import dbxyzptlk.CC.v;
import dbxyzptlk.Ce.a;
import dbxyzptlk.EC.b0;
import dbxyzptlk.Ec.a;
import dbxyzptlk.Ec.g;
import dbxyzptlk.Ee.a;
import dbxyzptlk.Fe.b;
import dbxyzptlk.He.p;
import dbxyzptlk.Jh.e;
import dbxyzptlk.Kk.e;
import dbxyzptlk.Me.a;
import dbxyzptlk.Ne.b;
import dbxyzptlk.Ry.b;
import dbxyzptlk.Xy.j0;
import dbxyzptlk.Xy.k0;
import dbxyzptlk.Xy.m0;
import dbxyzptlk.Za.a;
import dbxyzptlk.dk.o;
import dbxyzptlk.ef.E;
import dbxyzptlk.lf.k;
import dbxyzptlk.lf.o;
import dbxyzptlk.pc.d0;
import dbxyzptlk.pc.g0;
import dbxyzptlk.pc.u0;
import dbxyzptlk.pc.v0;
import dbxyzptlk.qb.e;
import dbxyzptlk.qc.A;
import dbxyzptlk.qc.d;
import dbxyzptlk.qc.j;
import dbxyzptlk.qc.n;
import dbxyzptlk.qc.t;
import dbxyzptlk.qc.v;
import dbxyzptlk.sL.a;
import dbxyzptlk.sc.P;
import dbxyzptlk.sp.b;
import dbxyzptlk.un.g;
import dbxyzptlk.yn.j;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

public class h implements DbxUserManager {
  public final b a;
  
  public final DbxUserManager.a b;
  
  public final g0 c;
  
  public final j.b d;
  
  public final c e;
  
  public final g f;
  
  public final m0 g;
  
  public final b h;
  
  public final e<e> i;
  
  public final Handler j = new Handler(Looper.getMainLooper());
  
  public final o<DbxUserManager.b> k = new o(null);
  
  public k l;
  
  public o m;
  
  public final g n;
  
  public a o;
  
  public E p;
  
  public a q = null;
  
  public final AtomicBoolean r = new AtomicBoolean(false);
  
  public final a<DbxUserManager.e> s = a.d();
  
  public final a<DbxUserManager.f> t = a.f();
  
  public final Set<DbxUserManager.c> u = new HashSet<>();
  
  public final Set<DbxUserManager.d> v = new HashSet<>();
  
  public final Executor w = Executors.newSingleThreadExecutor((ThreadFactory)dbxyzptlk.Ge.c.a(h.class).a());
  
  public final AtomicBoolean x = new AtomicBoolean(false);
  
  public h(b paramb, DbxUserManager.a parama, c paramc, g0 paramg0, j.b paramb1, g paramg, e<e> parame, k paramk, o paramo, g paramg1, a parama1, E paramE, m0 paramm0, b paramb2) {
    this.a = paramb;
    this.b = parama;
    this.d = paramb1;
    this.e = paramc;
    this.c = paramg0;
    this.f = paramg;
    this.i = parame;
    this.l = paramk;
    this.m = paramo;
    this.n = paramg1;
    this.o = parama1;
    this.p = paramE;
    this.g = paramm0;
    this.h = paramb2;
  }
  
  public static void K(d0 paramd0, a parama) {
    paramd0.h2().h1(parama);
  }
  
  public static boolean L(a parama, a parama1) {
    String str1;
    String str4 = parama.i();
    String str3 = a.n(parama1);
    String str6 = parama.a();
    String str5 = parama1.h();
    String str2 = null;
    if (str6 == null) {
      parama1 = null;
    } else {
      str1 = b.e(str6);
    } 
    if (str5 != null)
      str2 = b.e(str5); 
    a.d("Updating team paths {oldPathRoot=%s, oldPathRoot=%s, oldHomePath=%s, newHomePath=%s}", new Object[] { str4, str3, str1, str2 });
    if ((v.b(str2) && v.b(str3)) || (!v.b(str2) && !v.b(str3))) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    p.e(bool1, "Assert failed.");
    boolean bool1 = p.k(str4, str3);
    boolean bool2 = p.k(str1, str2);
    if (v.b(str1) && !v.b(str4)) {
      if (bool1) {
        a.d("Received missing home path information. Updating home path to %s", new Object[] { str2 });
        parama.x(str2);
        return true;
      } 
      a.m("Not enough information to perform a CDM migration. Need to unlink", new Object[0]);
      return false;
    } 
    if (!bool1 || !bool2)
      if (!bool1 && !bool2) {
        a.d("Both home path and root path changed. Settings pending home and root path to (%s, %s)", new Object[] { str2, str3 });
        parama.G(str2, str3);
      } else if (!bool1) {
        a.d("Path root changed. Setting pending path root to %s", new Object[] { str3 });
        parama.H(str3);
      } else {
        a.d("Home path changed. Setting pending home path to %s", new Object[] { str2 });
        parama.F(str2);
      }  
    return true;
  }
  
  public static String y(a parama) {
    n.i i;
    if (parama == null) {
      parama = null;
    } else {
      i = parama.t();
    } 
    return (i != null) ? i.r0() : null;
  }
  
  public static boolean z(a parama) {
    n.i i;
    if (parama == null) {
      i = null;
    } else {
      i = parama.t();
    } 
    return (i != null) ? n.c.EMM_REQUIRED.equals(parama.t().l0()) : false;
  }
  
  public final boolean A(Set<String> paramSet1, Set<String> paramSet2) {
    boolean bool;
    if (Collections.disjoint(paramSet1, paramSet2) && !paramSet1.isEmpty()) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public final void B(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) {
    Exception exception;
    DbxUserManager.b b1;
    o<DbxUserManager.b> o1 = this.k;
    /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{dbxyzptlk/dk/o<InnerObjectType{ObjectType{com/dropbox/android/user/DbxUserManager}.Lcom/dropbox/android/user/DbxUserManager$b;}>}, name=null} */
    try {
      boolean bool1;
      if (paramBoolean1 != this.r.get()) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      p.e(bool1, "Assert failed.");
      b1 = (DbxUserManager.b)this.k.b();
      if (b1 == null) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      if (paramBoolean1 == bool1) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      p.e(bool1, "Assert failed.");
      if (b1 != null) {
        a a2 = b1.b();
      } else {
        exception = null;
      } 
    } finally {}
    Set<String> set1 = a.s((a)exception);
    Pair<a, a> pair = this.a.e(set1);
    Set<String> set2 = b.l(pair);
    boolean bool = A(set1, set2);
    t(bool, u((a)exception, pair, paramBoolean1));
    a a1 = v(b1, pair, bool);
    if (exception != a1 || b1 == null)
      H(b1, a1); 
    if (paramBoolean2 && !a1.t()) {
      u0 u0 = u0.PERSONAL;
      if (a1.r(u0) != null)
        J(a1.r(u0)); 
    } 
    if (paramBoolean2) {
      for (d0 d0 : a1.b()) {
        d0.h2().v1(true);
        d0.h2().S1(System.currentTimeMillis());
      } 
      this.g.c(k0.SIGN_UP);
      this.g.d(j0.HAS_NOT_SEEN_ONBOARDING);
    } else if (paramBoolean3) {
      this.g.c(k0.SIGN_IN);
      this.g.d(j0.HAS_NOT_SEEN_ONBOARDING);
    } 
    if (a1 != null && !a1.t()) {
      u0 u0 = u0.PERSONAL;
      if (a1.r(u0) != null) {
        d0 d0 = a1.r(u0);
        long l1 = d0.h2().Z0();
        long l2 = System.currentTimeMillis();
        if (TimeUnit.DAYS.convert(l2 - l1, TimeUnit.MILLISECONDS) <= 30L)
          d0.s1().d().w(true); 
      } 
    } 
    z.f f = z.a(set2, set1);
    if (!f.isEmpty()) {
      p.o(a1);
      ArrayList<d0> arrayList = new ArrayList();
      this();
      b0<String> b0 = f.b();
      while (b0.hasNext()) {
        d0 d0 = a1.q(b0.next());
        if (d0 != null) {
          arrayList.add(d0);
          d0.h2().y1(Instant.now());
        } 
      } 
      if (!arrayList.isEmpty() && !paramBoolean2 && paramBoolean3)
        I(arrayList); 
    } 
    if (!paramBoolean1 && a1 != null)
      if (paramBoolean3 && f.size() == 1) {
        d0 d0 = (d0)p.o(a1.q(f.b().next()));
        this.p.l();
        this.o.h(a1, false);
        if (!this.o.e(d0))
          this.p.d(); 
      } else {
        this.o.h(a1, false);
      }  
    this.r.set(true);
    if (!paramBoolean1 && exception != a1)
      E(a1); 
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{dbxyzptlk/dk/o<InnerObjectType{ObjectType{com/dropbox/android/user/DbxUserManager}.Lcom/dropbox/android/user/DbxUserManager$b;}>}, name=null} */
  }
  
  public final void C(d0 paramd0) {
    Set<DbxUserManager.c> set = this.u;
    /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{java/util/Set<InnerObjectType{ObjectType{com/dropbox/android/user/DbxUserManager}.Lcom/dropbox/android/user/DbxUserManager$c;}>}, name=null} */
    try {
      ArrayList arrayList = new ArrayList();
      this((Collection)this.u);
      Iterator<DbxUserManager.c> iterator = arrayList.iterator();
      while (iterator.hasNext())
        ((DbxUserManager.c)iterator.next()).a(paramd0); 
    } finally {}
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/util/Set<InnerObjectType{ObjectType{com/dropbox/android/user/DbxUserManager}.Lcom/dropbox/android/user/DbxUserManager$c;}>}, name=null} */
  }
  
  public final void D(d0 paramd0) {
    Set<DbxUserManager.d> set = this.v;
    /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{java/util/Set<InnerObjectType{ObjectType{com/dropbox/android/user/DbxUserManager}.Lcom/dropbox/android/user/DbxUserManager$d;}>}, name=null} */
    try {
      ArrayList arrayList = new ArrayList();
      this((Collection)this.v);
      Iterator<DbxUserManager.d> iterator = arrayList.iterator();
      while (iterator.hasNext())
        ((DbxUserManager.d)iterator.next()).a(paramd0); 
    } finally {}
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/util/Set<InnerObjectType{ObjectType{com/dropbox/android/user/DbxUserManager}.Lcom/dropbox/android/user/DbxUserManager$d;}>}, name=null} */
  }
  
  public final void E(a parama) {
    p.e(Thread.holdsLock(this.k), "Assert failed.");
    b.b();
    this.j.post((Runnable)new a(this, parama));
    this.s.c((a.b)new b(this, parama));
  }
  
  public final d0 F(a parama, a parama1, d paramd) {
    if (parama != null) {
      d0 d0 = parama.q(parama1.n());
    } else {
      parama = null;
    } 
    return (parama != null) ? this.b.d((d0)parama, parama1) : x(parama1, paramd);
  }
  
  public final d0 G(String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: getfield k : Ldbxyzptlk/dk/o;
    //   4: invokestatic holdsLock : (Ljava/lang/Object;)Z
    //   7: ldc 'Assert failed.'
    //   9: invokestatic e : (ZLjava/lang/Object;)V
    //   12: aload_0
    //   13: getfield k : Ldbxyzptlk/dk/o;
    //   16: invokevirtual b : ()Ljava/lang/Object;
    //   19: checkcast com/dropbox/android/user/DbxUserManager$b
    //   22: astore #4
    //   24: aload #4
    //   26: invokevirtual b : ()Lcom/dropbox/android/user/a;
    //   29: astore #5
    //   31: aconst_null
    //   32: astore_3
    //   33: aload #5
    //   35: ifnull -> 48
    //   38: aload #5
    //   40: aload_1
    //   41: invokevirtual q : (Ljava/lang/String;)Ldbxyzptlk/pc/d0;
    //   44: astore_2
    //   45: goto -> 50
    //   48: aconst_null
    //   49: astore_2
    //   50: aload_2
    //   51: ifnonnull -> 56
    //   54: aconst_null
    //   55: areturn
    //   56: aload #5
    //   58: invokevirtual t : ()Z
    //   61: ifeq -> 140
    //   64: aload #5
    //   66: invokevirtual b : ()Ljava/lang/Iterable;
    //   69: invokeinterface iterator : ()Ljava/util/Iterator;
    //   74: astore #6
    //   76: aload #6
    //   78: invokeinterface hasNext : ()Z
    //   83: ifeq -> 115
    //   86: aload #6
    //   88: invokeinterface next : ()Ljava/lang/Object;
    //   93: checkcast dbxyzptlk/pc/d0
    //   96: astore_3
    //   97: aload_3
    //   98: invokeinterface getId : ()Ljava/lang/String;
    //   103: aload_1
    //   104: invokevirtual equals : (Ljava/lang/Object;)Z
    //   107: ifne -> 76
    //   110: aload_3
    //   111: astore_1
    //   112: goto -> 117
    //   115: aconst_null
    //   116: astore_1
    //   117: aload_1
    //   118: invokestatic o : (Ljava/lang/Object;)Ljava/lang/Object;
    //   121: pop
    //   122: aload_1
    //   123: aconst_null
    //   124: aload_0
    //   125: getfield e : Lcom/dropbox/android/user/c;
    //   128: invokevirtual d : ()Lcom/dropbox/android/user/e;
    //   131: aload #5
    //   133: invokevirtual l : ()Lcom/dropbox/android/user/a$b;
    //   136: invokestatic e : (Ldbxyzptlk/pc/d0;Ldbxyzptlk/pc/d0;Lcom/dropbox/android/user/e;Lcom/dropbox/android/user/a$b;)Lcom/dropbox/android/user/a;
    //   139: astore_3
    //   140: aload_3
    //   141: ifnonnull -> 151
    //   144: aload_0
    //   145: getfield e : Lcom/dropbox/android/user/c;
    //   148: invokevirtual c : ()V
    //   151: aload_0
    //   152: aload #4
    //   154: aload_3
    //   155: invokevirtual H : (Lcom/dropbox/android/user/DbxUserManager$b;Lcom/dropbox/android/user/a;)V
    //   158: aload_2
    //   159: areturn
  }
  
  public final void H(DbxUserManager.b paramb, a parama) {
    if (paramb != null)
      a.i3().o("old", a.d(paramb.b())).o("new", a.d(parama)).i(this.f); 
    if (parama == null)
      this.e.b(); 
    DbxUserManager.b b1 = new DbxUserManager.b(this.e.d(), parama);
    p.e(this.k.a(paramb, b1), "Assert failed.");
  }
  
  public void I(List<d0> paramList) {
    b.b();
    Set set = this.n.c0();
    for (d0 d0 : paramList) {
      if (!set.contains(d0.getId()) && (P.a(d0.i2(), d0.R1(), d0) || this.h.a()))
        d0.h2().l1(true); 
    } 
  }
  
  public final void J(d0 paramd0) {
    p.e(u0.PERSONAL.equals(paramd0.i2()), "Assert failed.");
    e e1 = paramd0.s1().d();
    e1.Z(true);
    e1.a0();
    e1.w(true);
    paramd0.h2().m1(true);
    paramd0.h2().M1(true);
  }
  
  public a a() {
    p.j(this.r.get(), "Assert failed: %1$s", "getUsers() called before loadUsers() has been called.");
    return ((DbxUserManager.b)this.k.b()).b();
  }
  
  public void b() {}
  
  public g c(u0 paramu0) {
    a a1 = a();
    return (a1 != null) ? a1.m(paramu0).e() : this.f;
  }
  
  public void d(DbxUserManager.c paramc) {
    p.j(this.r.get() ^ true, "Assert failed: %1$s", "InitializeUserListeners must be registered before users are loaded");
    synchronized (this.u) {
      p.e(this.u.add(paramc), "Assert failed.");
      return;
    } 
  }
  
  public a<d0> e(b paramb, a parama, boolean paramBoolean) throws DbxUserManager.RegisterUserException {
    // Byte code:
    //   0: invokestatic b : ()V
    //   3: aload_0
    //   4: getfield k : Ldbxyzptlk/dk/o;
    //   7: astore #7
    //   9: aload #7
    //   11: monitorenter
    //   12: new dbxyzptlk/Me/a
    //   15: astore #8
    //   17: aload #8
    //   19: aload_1
    //   20: invokevirtual a : ()Ldbxyzptlk/qc/n;
    //   23: aconst_null
    //   24: aconst_null
    //   25: invokespecial <init> : (Ldbxyzptlk/qc/n;Ldbxyzptlk/qc/j;Ldbxyzptlk/qc/v;)V
    //   28: aload_1
    //   29: invokevirtual b : ()Ldbxyzptlk/qc/t;
    //   32: astore #9
    //   34: aload #8
    //   36: invokevirtual v : ()Ldbxyzptlk/qc/A;
    //   39: astore_1
    //   40: iconst_0
    //   41: istore #6
    //   43: iconst_0
    //   44: istore #4
    //   46: invokestatic a : ()Lcom/dropbox/core/android/auth/SharedAccount$b;
    //   49: aload_1
    //   50: invokevirtual f0 : ()Ljava/lang/String;
    //   53: invokevirtual i : (Ljava/lang/String;)Lcom/dropbox/core/android/auth/SharedAccount$b;
    //   56: aload_1
    //   57: invokevirtual d0 : ()Ljava/lang/String;
    //   60: invokevirtual c : (Ljava/lang/String;)Lcom/dropbox/core/android/auth/SharedAccount$b;
    //   63: aload #8
    //   65: invokevirtual d : ()Ljava/lang/String;
    //   68: invokevirtual b : (Ljava/lang/String;)Lcom/dropbox/core/android/auth/SharedAccount$b;
    //   71: aload #8
    //   73: invokevirtual w : ()Ljava/lang/String;
    //   76: invokevirtual j : (Ljava/lang/String;)Lcom/dropbox/core/android/auth/SharedAccount$b;
    //   79: aload_1
    //   80: invokevirtual e0 : ()Ldbxyzptlk/qc/d;
    //   83: invokestatic p : (Ldbxyzptlk/qc/d;)Ldbxyzptlk/mk/s0;
    //   86: invokevirtual e : (Ldbxyzptlk/mk/s0;)Lcom/dropbox/core/android/auth/SharedAccount$b;
    //   89: aload #9
    //   91: invokestatic r : (Ldbxyzptlk/qc/t;)Lcom/dropbox/core/android/auth/SiblingInfo;
    //   94: invokevirtual f : (Lcom/dropbox/core/android/auth/SiblingInfo;)Lcom/dropbox/core/android/auth/SharedAccount$b;
    //   97: astore #11
    //   99: aload_2
    //   100: instanceof com/dropbox/base/http/AccessTokenPair
    //   103: ifeq -> 138
    //   106: aload_2
    //   107: checkcast com/dropbox/base/http/AccessTokenPair
    //   110: astore #10
    //   112: aload #11
    //   114: aload #10
    //   116: getfield key : Ljava/lang/String;
    //   119: invokevirtual g : (Ljava/lang/String;)Lcom/dropbox/core/android/auth/SharedAccount$b;
    //   122: aload #10
    //   124: getfield secret : Ljava/lang/String;
    //   127: invokevirtual h : (Ljava/lang/String;)Lcom/dropbox/core/android/auth/SharedAccount$b;
    //   130: pop
    //   131: goto -> 158
    //   134: astore_1
    //   135: goto -> 495
    //   138: aload_2
    //   139: instanceof com/dropbox/base/http/Oauth2AccessToken
    //   142: ifeq -> 450
    //   145: aload #11
    //   147: aload_2
    //   148: checkcast com/dropbox/base/http/Oauth2AccessToken
    //   151: invokevirtual getAccessToken : ()Ljava/lang/String;
    //   154: invokevirtual d : (Ljava/lang/String;)Lcom/dropbox/core/android/auth/SharedAccount$b;
    //   157: pop
    //   158: aload #11
    //   160: invokevirtual a : ()Lcom/dropbox/core/android/auth/SharedAccount;
    //   163: astore #10
    //   165: iconst_1
    //   166: istore #5
    //   168: aload_0
    //   169: getfield a : Ldbxyzptlk/C6/b;
    //   172: aload #10
    //   174: aload_0
    //   175: getfield x : Ljava/util/concurrent/atomic/AtomicBoolean;
    //   178: invokevirtual get : ()Z
    //   181: invokeinterface g : (Lcom/dropbox/core/android/auth/SharedAccount;Z)Lcom/dropbox/android/accounts/store/a;
    //   186: astore #10
    //   188: aload #10
    //   190: instanceof com/dropbox/android/accounts/store/a$b
    //   193: ifeq -> 230
    //   196: aload #10
    //   198: checkcast com/dropbox/android/accounts/store/a$b
    //   201: invokevirtual b : ()Lcom/dropbox/android/accounts/store/a$b;
    //   204: astore #10
    //   206: aload_0
    //   207: aconst_null
    //   208: putfield q : Ldbxyzptlk/Me/a;
    //   211: aload #7
    //   213: monitorexit
    //   214: aload #10
    //   216: areturn
    //   217: astore_1
    //   218: goto -> 502
    //   221: astore_2
    //   222: goto -> 378
    //   225: astore #10
    //   227: goto -> 389
    //   230: aload #10
    //   232: checkcast com/dropbox/android/accounts/store/a$a
    //   235: invokevirtual a : ()Ljava/lang/Object;
    //   238: checkcast dbxyzptlk/C6/a
    //   241: astore #10
    //   243: aload #10
    //   245: aload #8
    //   247: invokevirtual h : ()Ljava/lang/String;
    //   250: invokevirtual x : (Ljava/lang/String;)V
    //   253: aload #10
    //   255: aload #8
    //   257: invokestatic n : (Ldbxyzptlk/Me/a;)Ljava/lang/String;
    //   260: invokevirtual E : (Ljava/lang/String;)V
    //   263: aload_0
    //   264: getfield q : Ldbxyzptlk/Me/a;
    //   267: ifnonnull -> 273
    //   270: iconst_1
    //   271: istore #6
    //   273: iload #6
    //   275: ldc_w 'Object must be null: %1$s'
    //   278: ldc_w 'Shouldn't have registration AccountInfo'
    //   281: invokestatic j : (ZLjava/lang/String;Ljava/lang/Object;)V
    //   284: aload_0
    //   285: aload #8
    //   287: putfield q : Ldbxyzptlk/Me/a;
    //   290: aload_0
    //   291: iload_3
    //   292: iconst_1
    //   293: invokevirtual k : (ZZ)V
    //   296: aload_0
    //   297: getfield k : Ldbxyzptlk/dk/o;
    //   300: invokevirtual b : ()Ljava/lang/Object;
    //   303: checkcast com/dropbox/android/user/DbxUserManager$b
    //   306: invokevirtual b : ()Lcom/dropbox/android/user/a;
    //   309: astore_2
    //   310: aload_2
    //   311: ifnull -> 365
    //   314: aload_2
    //   315: aload_1
    //   316: invokevirtual f0 : ()Ljava/lang/String;
    //   319: invokevirtual q : (Ljava/lang/String;)Ldbxyzptlk/pc/d0;
    //   322: astore_1
    //   323: aload_1
    //   324: ifnull -> 352
    //   327: aload_1
    //   328: aload #8
    //   330: invokestatic K : (Ldbxyzptlk/pc/d0;Ldbxyzptlk/Me/a;)V
    //   333: new com/dropbox/android/accounts/store/a$a
    //   336: dup
    //   337: aload_1
    //   338: invokespecial <init> : (Ljava/lang/Object;)V
    //   341: astore_1
    //   342: aload_0
    //   343: aconst_null
    //   344: putfield q : Ldbxyzptlk/Me/a;
    //   347: aload #7
    //   349: monitorexit
    //   350: aload_1
    //   351: areturn
    //   352: new com/dropbox/android/user/DbxUserManager$RegisterUserException
    //   355: astore_1
    //   356: aload_1
    //   357: ldc_w 'Failed to add user.'
    //   360: invokespecial <init> : (Ljava/lang/String;)V
    //   363: aload_1
    //   364: athrow
    //   365: new com/dropbox/android/user/DbxUserManager$RegisterUserException
    //   368: astore_1
    //   369: aload_1
    //   370: ldc_w 'Failed to add user.'
    //   373: invokespecial <init> : (Ljava/lang/String;)V
    //   376: aload_1
    //   377: athrow
    //   378: new com/dropbox/android/user/DbxUserManager$RegisterUserException
    //   381: astore_1
    //   382: aload_1
    //   383: aload_2
    //   384: invokespecial <init> : (Ljava/lang/Throwable;)V
    //   387: aload_1
    //   388: athrow
    //   389: aload_0
    //   390: invokevirtual a : ()Lcom/dropbox/android/user/a;
    //   393: ifnull -> 399
    //   396: goto -> 402
    //   399: iconst_0
    //   400: istore #5
    //   402: iload #4
    //   404: ifne -> 435
    //   407: iload #5
    //   409: ifne -> 435
    //   412: aload_0
    //   413: invokevirtual s : ()Z
    //   416: ifeq -> 435
    //   419: iinc #4, 1
    //   422: aload_0
    //   423: getfield a : Ldbxyzptlk/C6/b;
    //   426: invokeinterface c : ()Z
    //   431: pop
    //   432: goto -> 46
    //   435: new com/dropbox/android/user/DbxUserManager$RegisterUserException
    //   438: astore_1
    //   439: aload_1
    //   440: ldc_w 'Failed to add user.'
    //   443: aload #10
    //   445: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   448: aload_1
    //   449: athrow
    //   450: new java/lang/RuntimeException
    //   453: astore #8
    //   455: new java/lang/StringBuilder
    //   458: astore_1
    //   459: aload_1
    //   460: invokespecial <init> : ()V
    //   463: aload_1
    //   464: ldc_w 'Unsupported AccessToken type: '
    //   467: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   470: pop
    //   471: aload_1
    //   472: aload_2
    //   473: invokevirtual getClass : ()Ljava/lang/Class;
    //   476: invokevirtual getCanonicalName : ()Ljava/lang/String;
    //   479: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   482: pop
    //   483: aload #8
    //   485: aload_1
    //   486: invokevirtual toString : ()Ljava/lang/String;
    //   489: invokespecial <init> : (Ljava/lang/String;)V
    //   492: aload #8
    //   494: athrow
    //   495: aload_0
    //   496: aconst_null
    //   497: putfield q : Ldbxyzptlk/Me/a;
    //   500: aload_1
    //   501: athrow
    //   502: aload #7
    //   504: monitorexit
    //   505: aload_1
    //   506: athrow
    // Exception table:
    //   from	to	target	type
    //   12	40	134	finally
    //   46	131	134	finally
    //   138	158	134	finally
    //   158	165	134	finally
    //   168	206	225	com/dropbox/android/accounts/store/AddSharedAccountException$BadStateException
    //   168	206	221	com/dropbox/android/accounts/store/AddSharedAccountException
    //   168	206	134	finally
    //   206	214	217	finally
    //   230	243	225	com/dropbox/android/accounts/store/AddSharedAccountException$BadStateException
    //   230	243	221	com/dropbox/android/accounts/store/AddSharedAccountException
    //   230	243	134	finally
    //   243	263	134	finally
    //   263	270	134	finally
    //   273	310	134	finally
    //   314	323	134	finally
    //   327	342	134	finally
    //   342	350	217	finally
    //   352	365	134	finally
    //   365	378	134	finally
    //   378	389	134	finally
    //   389	396	134	finally
    //   412	419	134	finally
    //   422	432	134	finally
    //   435	450	134	finally
    //   450	495	134	finally
    //   495	502	217	finally
    //   502	505	217	finally
  }
  
  public a.f f(DbxUserManager.e parame) {
    return this.s.i(parame);
  }
  
  public DbxUserManager.b g() {
    p.j(this.r.get(), "Assert failed: %1$s", "getIdentity() called before loadUsers() has been called.");
    return (DbxUserManager.b)this.k.b();
  }
  
  public boolean h(String paramString) {
    b.b();
    o<DbxUserManager.b> o1 = this.k;
    /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{dbxyzptlk/dk/o<InnerObjectType{ObjectType{com/dropbox/android/user/DbxUserManager}.Lcom/dropbox/android/user/DbxUserManager$b;}>}, name=null} */
    try {
      d0 d0 = G(paramString);
      if (d0 != null) {
        d0.j2();
        E(((DbxUserManager.b)this.k.b()).b());
        /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{dbxyzptlk/dk/o<InnerObjectType{ObjectType{com/dropbox/android/user/DbxUserManager}.Lcom/dropbox/android/user/DbxUserManager$b;}>}, name=null} */
        return true;
      } 
    } finally {}
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{dbxyzptlk/dk/o<InnerObjectType{ObjectType{com/dropbox/android/user/DbxUserManager}.Lcom/dropbox/android/user/DbxUserManager$b;}>}, name=null} */
    return false;
  }
  
  public void i(DbxUserManager.d paramd) {
    synchronized (this.v) {
      p.e(this.v.add(paramd), "Assert failed.");
      return;
    } 
  }
  
  public void j() {
    B(true, false, false);
  }
  
  public void k(boolean paramBoolean1, boolean paramBoolean2) {
    b.b();
    B(false, paramBoolean1, paramBoolean2);
  }
  
  public a.f l(DbxUserManager.f paramf) {
    return this.t.i(paramf);
  }
  
  public a m(b paramb, j paramj, v paramv) {
    b.b();
    o<DbxUserManager.b> o1 = this.k;
    /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{dbxyzptlk/dk/o<InnerObjectType{ObjectType{com/dropbox/android/user/DbxUserManager}.Lcom/dropbox/android/user/DbxUserManager$b;}>}, name=null} */
    try {
      a4 = paramb.a().t0();
      a3 = ((DbxUserManager.b)this.k.b()).b();
      if (a3 == null) {
        /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{dbxyzptlk/dk/o<InnerObjectType{ObjectType{com/dropbox/android/user/DbxUserManager}.Lcom/dropbox/android/user/DbxUserManager$b;}>}, name=null} */
        return null;
      } 
    } finally {}
    d0 d0 = a3.q(a4.f0());
    if (d0 == null) {
      /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{dbxyzptlk/dk/o<InnerObjectType{ObjectType{com/dropbox/android/user/DbxUserManager}.Lcom/dropbox/android/user/DbxUserManager$b;}>}, name=null} */
      return null;
    } 
    a a2 = new a();
    this(paramb.a(), paramj, paramv);
    a a3;
    A a4;
    K(d0, a2);
    SharedAccount sharedAccount = d0.k2().f();
    b b1 = this.a;
    a a1 = a2;
    if (b1.f(sharedAccount, b1.h(sharedAccount, a2, paramb.b()))) {
      k(false, false);
      a a5 = ((DbxUserManager.b)this.k.b()).b();
      if (a5 == null) {
        /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{dbxyzptlk/dk/o<InnerObjectType{ObjectType{com/dropbox/android/user/DbxUserManager}.Lcom/dropbox/android/user/DbxUserManager$b;}>}, name=null} */
        return null;
      } 
      d0 d01 = a5.q(a4.f0());
      if (d01 == null) {
        /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{dbxyzptlk/dk/o<InnerObjectType{ObjectType{com/dropbox/android/user/DbxUserManager}.Lcom/dropbox/android/user/DbxUserManager$b;}>}, name=null} */
        return null;
      } 
      a1 = d01.h2().t0();
    } 
    if (!L(d0.k2(), a1)) {
      d d = new d();
      this(this, d0);
      d.start();
      /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{dbxyzptlk/dk/o<InnerObjectType{ObjectType{com/dropbox/android/user/DbxUserManager}.Lcom/dropbox/android/user/DbxUserManager$b;}>}, name=null} */
      return null;
    } 
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{dbxyzptlk/dk/o<InnerObjectType{ObjectType{com/dropbox/android/user/DbxUserManager}.Lcom/dropbox/android/user/DbxUserManager$b;}>}, name=null} */
    return a1;
  }
  
  public void n() {
    b.a();
    this.w.execute(new c(this));
  }
  
  public a<d0> o(b paramb, boolean paramBoolean) throws DbxUserManager.RegisterUserException {
    // Byte code:
    //   0: invokestatic b : ()V
    //   3: aload_0
    //   4: getfield k : Ldbxyzptlk/dk/o;
    //   7: astore #4
    //   9: aload #4
    //   11: monitorenter
    //   12: new dbxyzptlk/Me/a
    //   15: astore #5
    //   17: aload #5
    //   19: aload_1
    //   20: invokevirtual a : ()Ldbxyzptlk/qc/n;
    //   23: aconst_null
    //   24: aconst_null
    //   25: invokespecial <init> : (Ldbxyzptlk/qc/n;Ldbxyzptlk/qc/j;Ldbxyzptlk/qc/v;)V
    //   28: aload #5
    //   30: invokevirtual v : ()Ldbxyzptlk/qc/A;
    //   33: astore_1
    //   34: aload_0
    //   35: getfield a : Ldbxyzptlk/C6/b;
    //   38: aload_1
    //   39: invokevirtual f0 : ()Ljava/lang/String;
    //   42: invokeinterface d : (Ljava/lang/String;)Ldbxyzptlk/C6/a;
    //   47: astore #6
    //   49: iconst_0
    //   50: istore_3
    //   51: aload #6
    //   53: ifnull -> 228
    //   56: aload #6
    //   58: invokevirtual e : ()Ldbxyzptlk/Ce/a;
    //   61: ifnull -> 211
    //   64: aload #6
    //   66: aload #5
    //   68: invokevirtual h : ()Ljava/lang/String;
    //   71: invokevirtual x : (Ljava/lang/String;)V
    //   74: aload #6
    //   76: aload #5
    //   78: invokestatic n : (Ldbxyzptlk/Me/a;)Ljava/lang/String;
    //   81: invokevirtual E : (Ljava/lang/String;)V
    //   84: aload_0
    //   85: getfield q : Ldbxyzptlk/Me/a;
    //   88: ifnonnull -> 93
    //   91: iconst_1
    //   92: istore_3
    //   93: iload_3
    //   94: ldc_w 'Object must be null: %1$s'
    //   97: ldc_w 'Shouldn't have registration AccountInfo'
    //   100: invokestatic j : (ZLjava/lang/String;Ljava/lang/Object;)V
    //   103: aload_0
    //   104: aload #5
    //   106: putfield q : Ldbxyzptlk/Me/a;
    //   109: aload_0
    //   110: iload_2
    //   111: iconst_1
    //   112: invokevirtual k : (ZZ)V
    //   115: aload_0
    //   116: getfield k : Ldbxyzptlk/dk/o;
    //   119: invokevirtual b : ()Ljava/lang/Object;
    //   122: checkcast com/dropbox/android/user/DbxUserManager$b
    //   125: invokevirtual b : ()Lcom/dropbox/android/user/a;
    //   128: astore #6
    //   130: aload #6
    //   132: ifnull -> 198
    //   135: aload #6
    //   137: aload_1
    //   138: invokevirtual f0 : ()Ljava/lang/String;
    //   141: invokevirtual q : (Ljava/lang/String;)Ldbxyzptlk/pc/d0;
    //   144: astore_1
    //   145: aload_1
    //   146: ifnull -> 185
    //   149: aload_1
    //   150: aload #5
    //   152: invokestatic K : (Ldbxyzptlk/pc/d0;Ldbxyzptlk/Me/a;)V
    //   155: new com/dropbox/android/accounts/store/a$a
    //   158: astore #5
    //   160: aload #5
    //   162: aload_1
    //   163: invokespecial <init> : (Ljava/lang/Object;)V
    //   166: aload_0
    //   167: aconst_null
    //   168: putfield q : Ldbxyzptlk/Me/a;
    //   171: aload #4
    //   173: monitorexit
    //   174: aload #5
    //   176: areturn
    //   177: astore_1
    //   178: goto -> 259
    //   181: astore_1
    //   182: goto -> 252
    //   185: new com/dropbox/android/user/DbxUserManager$RegisterUserException
    //   188: astore_1
    //   189: aload_1
    //   190: ldc_w 'Failed to get user.'
    //   193: invokespecial <init> : (Ljava/lang/String;)V
    //   196: aload_1
    //   197: athrow
    //   198: new com/dropbox/android/user/DbxUserManager$RegisterUserException
    //   201: astore_1
    //   202: aload_1
    //   203: ldc_w 'Failed to get user.'
    //   206: invokespecial <init> : (Ljava/lang/String;)V
    //   209: aload_1
    //   210: athrow
    //   211: new com/dropbox/android/user/DbxUserManager$RegisterUserException
    //   214: astore_1
    //   215: aload_1
    //   216: ldc_w 'AccessToken has NULL DATA'
    //   219: invokespecial <init> : (Ljava/lang/String;)V
    //   222: aload_1
    //   223: invokestatic h : (Ljava/lang/Throwable;)V
    //   226: aload_1
    //   227: athrow
    //   228: new com/dropbox/android/user/DbxUserManager$RegisterUserException
    //   231: astore_1
    //   232: aload_1
    //   233: ldc_w 'AMD NULL DATA'
    //   236: invokespecial <init> : (Ljava/lang/String;)V
    //   239: aload_1
    //   240: ldc_w 'Account Store Missing Info'
    //   243: iconst_0
    //   244: anewarray java/lang/Object
    //   247: invokestatic i : (Ljava/lang/Throwable;Ljava/lang/String;[Ljava/lang/Object;)V
    //   250: aload_1
    //   251: athrow
    //   252: aload_0
    //   253: aconst_null
    //   254: putfield q : Ldbxyzptlk/Me/a;
    //   257: aload_1
    //   258: athrow
    //   259: aload #4
    //   261: monitorexit
    //   262: aload_1
    //   263: athrow
    // Exception table:
    //   from	to	target	type
    //   12	49	181	finally
    //   56	84	181	finally
    //   84	91	181	finally
    //   93	130	181	finally
    //   135	145	181	finally
    //   149	166	181	finally
    //   166	174	177	finally
    //   185	198	181	finally
    //   198	211	181	finally
    //   211	228	181	finally
    //   228	252	181	finally
    //   252	259	177	finally
    //   259	262	177	finally
  }
  
  public boolean p(String paramString, boolean paramBoolean) {
    b.b();
    o<DbxUserManager.b> o1 = this.k;
    /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{dbxyzptlk/dk/o<InnerObjectType{ObjectType{com/dropbox/android/user/DbxUserManager}.Lcom/dropbox/android/user/DbxUserManager$b;}>}, name=null} */
    try {
      d0 d0 = G(paramString);
      if (d0 != null) {
        if (!paramBoolean)
          this.a.b(d0.k2().f()); 
        d0.U1();
        E(((DbxUserManager.b)this.k.b()).b());
        /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{dbxyzptlk/dk/o<InnerObjectType{ObjectType{com/dropbox/android/user/DbxUserManager}.Lcom/dropbox/android/user/DbxUserManager$b;}>}, name=null} */
        return true;
      } 
    } finally {}
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{dbxyzptlk/dk/o<InnerObjectType{ObjectType{com/dropbox/android/user/DbxUserManager}.Lcom/dropbox/android/user/DbxUserManager$b;}>}, name=null} */
    return false;
  }
  
  public final boolean s() {
    return ((e)this.i.b()).l(StormcrowAndroidClearAccountsOnAddFailure.VDISABLED) ^ true;
  }
  
  public final void t(boolean paramBoolean1, boolean paramBoolean2) {
    if (paramBoolean1) {
      this.e.c();
    } else if (paramBoolean2) {
      this.e.b();
      this.e.c();
    } 
  }
  
  public final boolean u(a parama, Pair<a, a> paramPair, boolean paramBoolean) {
    p.e(Thread.holdsLock(this.k), "Assert failed.");
    if (!paramBoolean)
      b.b(); 
    HashMap<Object, Object> hashMap = new HashMap<>();
    Object object = paramPair.first;
    if (object != null)
      hashMap.put(((a)object).n(), paramPair.first); 
    object = paramPair.second;
    if (object != null)
      hashMap.put(((a)object).n(), paramPair.second); 
    if (parama != null) {
      p.e(paramBoolean ^ true, "Assert failed.");
      for (d0 d0 : parama.b()) {
        if (!hashMap.containsKey(d0.getId()))
          d0.U1(); 
      } 
    } 
    object = new HashSet();
    if (paramBoolean) {
      HashSet<String> hashSet = new HashSet();
      for (String str : this.b.a()) {
        if (!hashMap.containsKey(str)) {
          hashSet.add(str);
          object.add("userfactory");
        } 
      } 
      boolean bool = hashSet.isEmpty();
      int j = bool ^ true;
      int i = j;
      if (!bool) {
        a.L().l("defunct_users", hashSet.size()).l("current_users", hashMap.size()).o("source", TextUtils.join(",", (Iterable)object)).o("defunct_user_ids", TextUtils.join(",", hashSet)).i(this.f);
        this.c.a(hashSet);
        i = j;
      } 
    } else {
      paramBoolean = false;
    } 
    return paramBoolean;
  }
  
  public final a v(DbxUserManager.b paramb, Pair<a, a> paramPair, boolean paramBoolean) {
    a a1;
    t t1;
    boolean bool;
    a a4;
    d0 d01;
    t t2 = null;
    if (paramb != null) {
      a4 = paramb.b();
    } else {
      a4 = null;
    } 
    Set<String> set1 = a.s(a4);
    Set set = b.l(paramPair);
    a a3 = (a)paramPair.first;
    a a6 = (a)paramPair.second;
    if (set.isEmpty())
      return null; 
    if (paramb == null || paramBoolean) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      if (paramb != null)
        p.e(true ^ this.e.e(), "Assert failed."); 
      this.e.b();
    } 
    A a2 = a3.l();
    A a5 = (A)A.h0().I(a3.n()).G(a3.g()).H(a3.j()).s();
    d0 d02 = F(a4, a3, null);
    if (a6 != null) {
      if (a2 != null) {
        d d = a2.e0();
      } else {
        paramb = null;
      } 
      d01 = F(a4, a6, (d)paramb);
      if (a2 != null) {
        A a7 = a2;
      } else {
        A a7 = (A)A.h0().I(a6.n()).G(a6.g()).H(a6.j()).s();
      } 
    } else {
      paramb = null;
      d01 = null;
    } 
    if (a2 != null) {
      a1 = d02.h().t0();
      t t = (t)t.a0().F(a2).s();
      a2 = a5;
    } else if (a6 != null) {
      a a8 = d01.h().t0();
      t2 = (t)t.a0().F(a6.l()).s();
      a a7 = a1;
      a1 = a8;
      t t = t2;
    } else {
      a1 = null;
      a3 = null;
      t1 = t2;
    } 
    a.b b1 = w((A)t1, y(a1), (t)a3, z(a1), this.l.a());
    if (bool || set1.isEmpty())
      this.e.d().e(b1, this); 
    return (set1.equals(set) && l.a(a4.l(), b1) && a4.q(d02.getId()) == d02 && (d01 == null || a4.q(d01.getId()) == d01)) ? a4 : ((b1 != null) ? a.e(d02, d01, this.e.d(), b1) : a.f(d02, a5, this.e.d()));
  }
  
  public final a.b w(A paramA, String paramString, t paramt, boolean paramBoolean1, boolean paramBoolean2) {
    return (paramA != null && paramt != null && paramt.Z() && !paramBoolean2 && !paramBoolean1) ? new a.b(paramA, paramt.Y(), paramString) : null;
  }
  
  public final d0 x(a parama, d paramd) {
    String str = parama.n();
    j j = this.d.a(str);
    p.e(Thread.holdsLock(this.k), "Assert failed.");
    a a1 = this.q;
    if (a1 != null && a1.v().f0().equals(str))
      j.h1(this.q); 
    u0 u0 = v0.b(parama, paramd, j);
    d0 d0 = this.b.c(u0, parama, j, this, this.e.d());
    if (!parama.q()) {
      parama.y();
      a.k3().o("uid", d0.getId()).i(this.f);
      a.d().i(this.f);
      C(d0);
    } 
    D(d0);
    return d0;
  }
  
  public class c implements Runnable {
    public final h a;
    
    public c(h this$0) {}
    
    public void run() {
      this.a.k(false, false);
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\androi\\user\h.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */