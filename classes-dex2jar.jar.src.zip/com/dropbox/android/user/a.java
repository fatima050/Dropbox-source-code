package com.dropbox.android.user;

import android.text.TextUtils;
import android.util.JsonWriter;
import android.util.Pair;
import com.google.common.collect.j;
import dbxyzptlk.CC.p;
import dbxyzptlk.Ej.d;
import dbxyzptlk.Oh.u;
import dbxyzptlk.pc.d0;
import dbxyzptlk.pc.u0;
import dbxyzptlk.qc.A;
import java.io.IOException;
import java.io.StringWriter;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class a {
  public final Pair<d0, d0> a;
  
  public final e b;
  
  public final b c;
  
  public final A d;
  
  public a(d0 paramd01, d0 paramd02, e parame, b paramb) {
    p.o(paramd01);
    p.o(parame);
    p.o(paramb);
    p.e(paramb.c(paramd01.getId()), "Assert failed.");
    d0 d02 = paramd01;
    d0 d01 = paramd02;
    if (paramd02 != null) {
      boolean bool;
      p.e(paramb.c(paramd02.getId()), "Assert failed.");
      int i = paramd01.getId().compareTo(paramd02.getId());
      if (i != 0) {
        bool = true;
      } else {
        bool = false;
      } 
      p.e(bool, "Assert failed.");
      d02 = paramd01;
      d01 = paramd02;
      if (i > 0) {
        d01 = paramd01;
        d02 = paramd02;
      } 
    } 
    this.a = Pair.create(d02, d01);
    this.b = parame;
    this.d = null;
    this.c = paramb;
  }
  
  public a(d0 paramd0, A paramA, e parame) {
    p.o(paramd0);
    p.o(paramA);
    p.e(paramA.f0().equals(paramd0.getId()), "Assert failed.");
    p.o(parame);
    this.a = Pair.create(paramd0, null);
    this.b = parame;
    this.d = paramA;
    this.c = null;
  }
  
  public static String c(String paramString1, String paramString2, b paramb) {
    String str;
    if (paramb != null) {
      str = paramb.g();
      String str1 = paramb.e();
    } else {
      str = null;
      paramb = null;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("DbxUserset<");
    stringBuilder.append(paramString1);
    stringBuilder.append(",");
    stringBuilder.append(paramString2);
    stringBuilder.append("|");
    stringBuilder.append(str);
    stringBuilder.append(",");
    stringBuilder.append((String)paramb);
    stringBuilder.append(">");
    return stringBuilder.toString();
  }
  
  public static String d(a parama) {
    if (parama == null)
      return "null"; 
    StringWriter stringWriter = new StringWriter();
    JsonWriter jsonWriter = new JsonWriter(stringWriter);
    try {
      jsonWriter.beginObject();
      jsonWriter.name("users");
      jsonWriter.beginArray();
      for (d0 d0 : parama.b())
        jsonWriter.value(w(d0.getId(), d0.i2(), d0.a())); 
    } catch (IOException iOException) {}
    jsonWriter.endArray();
    jsonWriter.name("pairing");
    b b1 = iOException.l();
    if (b1 == null) {
      jsonWriter.nullValue();
    } else {
      A a1 = b1.d();
      A a2 = b1.f();
      StringBuilder stringBuilder = new StringBuilder();
      this();
      stringBuilder.append(w(a1.f0(), u0.BUSINESS, a1.d0()));
      stringBuilder.append(",");
      stringBuilder.append(w(a2.f0(), u0.PERSONAL, a2.d0()));
      jsonWriter.value(stringBuilder.toString());
    } 
    if (b1 != null) {
      jsonWriter.name("team_name");
      jsonWriter.value(b1.i());
    } 
    jsonWriter.endObject();
    jsonWriter.close();
    return stringWriter.toString();
  }
  
  public static a e(d0 paramd01, d0 paramd02, e parame, b paramb) {
    return new a(paramd01, paramd02, parame, paramb);
  }
  
  public static a f(d0 paramd0, A paramA, e parame) {
    return new a(paramd0, paramA, parame);
  }
  
  public static Set<String> s(a parama) {
    if (parama == null)
      return Collections.emptySet(); 
    HashSet<String> hashSet = new HashSet(2);
    Iterator<d0> iterator = parama.b().iterator();
    while (iterator.hasNext())
      hashSet.add(((d0)iterator.next()).getId()); 
    return hashSet;
  }
  
  public static String w(String paramString1, u0 paramu0, String paramString2) {
    return TextUtils.join("|", (Object[])new String[] { paramString1, paramu0.name(), paramString2 });
  }
  
  public Iterable<A> a() {
    b b1 = this.c;
    return (Iterable<A>)((b1 == null) ? j.J(this.d) : j.L(b.b(b1), b.a(this.c)));
  }
  
  public Iterable<d0> b() {
    Pair<d0, d0> pair = this.a;
    Object object = pair.second;
    return (object == null) ? Collections.singletonList((d0)pair.first) : Arrays.asList(new d0[] { (d0)pair.first, (d0)object });
  }
  
  public A g(String paramString) {
    for (A a1 : a()) {
      if (a1.f0().equals(paramString))
        return a1; 
    } 
    return null;
  }
  
  public d0 h() {
    d0 d0 = q(k().d().E());
    return (d0 != null) ? d0 : m(u0.PERSONAL);
  }
  
  public String i() {
    String str2 = k().d().E();
    String str1 = str2;
    if (str2 == null)
      str1 = m(u0.PERSONAL).getId(); 
    return str1;
  }
  
  public String j() {
    String str = ((d0)this.a.first).getId();
    Object object = this.a.second;
    if (object == null) {
      object = null;
    } else {
      object = ((d0)object).getId();
    } 
    return c(str, (String)object, this.c);
  }
  
  public e k() {
    return this.b;
  }
  
  public b l() {
    return this.c;
  }
  
  public d0 m(u0 paramu0) {
    Pair<d0, d0> pair = this.a;
    return (pair.second == null) ? (d0)pair.first : r(paramu0);
  }
  
  public u n() {
    return (u)new a(((d0)this.a.first).k2());
  }
  
  public d0 o() {
    Pair<d0, d0> pair = this.a;
    if (pair.second == null)
      return (d0)pair.first; 
    throw new IllegalStateException("Expected a single user");
  }
  
  public d0 p(String paramString) {
    for (d0 d0 : b()) {
      if (d0.a().equals(paramString))
        return d0; 
    } 
    return null;
  }
  
  public d0 q(String paramString) {
    for (d0 d0 : b()) {
      if (d0.getId().equals(paramString))
        return d0; 
    } 
    return null;
  }
  
  public d0 r(u0 paramu0) {
    for (d0 d0 : b()) {
      if (d0.i2() == paramu0)
        return d0; 
    } 
    return null;
  }
  
  public boolean t() {
    boolean bool;
    if (this.a.second != null) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(getClass());
    stringBuilder.append("@[");
    stringBuilder.append("id=");
    stringBuilder.append(j());
    stringBuilder.append("]");
    return stringBuilder.toString();
  }
  
  public boolean u(d paramd) {
    Iterator<d0> iterator = b().iterator();
    while (iterator.hasNext()) {
      if (((d0)iterator.next()).x1().c(paramd))
        return true; 
    } 
    return false;
  }
  
  public d0 v(String paramString) {
    Iterator<d0> iterator = b().iterator();
    while (iterator.hasNext()) {
      if (((d0)iterator.next()).getId().equals(paramString))
        k().d().Y(paramString); 
    } 
    return h();
  }
  
  class a {}
  
  class a {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\androi\\user\a.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */