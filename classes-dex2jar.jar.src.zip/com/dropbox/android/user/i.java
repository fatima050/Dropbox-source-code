package com.dropbox.android.user;

import dbxyzptlk.C6.b;
import dbxyzptlk.Ec.g;
import dbxyzptlk.Jh.e;
import dbxyzptlk.Kk.e;
import dbxyzptlk.Xy.m0;
import dbxyzptlk.Za.a;
import dbxyzptlk.bH.e;
import dbxyzptlk.ef.E;
import dbxyzptlk.lf.k;
import dbxyzptlk.lf.o;
import dbxyzptlk.oI.a;
import dbxyzptlk.pc.g0;
import dbxyzptlk.sp.b;
import dbxyzptlk.un.g;
import dbxyzptlk.yn.j;

public final class i implements e<h> {
  public final a<b> a;
  
  public final a<DbxUserManager.a> b;
  
  public final a<c> c;
  
  public final a<g0> d;
  
  public final a<j.b> e;
  
  public final a<g> f;
  
  public final a<e<e>> g;
  
  public final a<k> h;
  
  public final a<o> i;
  
  public final a<g> j;
  
  public final a<a> k;
  
  public final a<E> l;
  
  public final a<m0> m;
  
  public final a<b> n;
  
  public i(a<b> parama, a<DbxUserManager.a> parama1, a<c> parama2, a<g0> parama3, a<j.b> parama4, a<g> parama5, a<e<e>> parama6, a<k> parama7, a<o> parama8, a<g> parama9, a<a> parama10, a<E> parama11, a<m0> parama12, a<b> parama13) {
    this.a = parama;
    this.b = parama1;
    this.c = parama2;
    this.d = parama3;
    this.e = parama4;
    this.f = parama5;
    this.g = parama6;
    this.h = parama7;
    this.i = parama8;
    this.j = parama9;
    this.k = parama10;
    this.l = parama11;
    this.m = parama12;
    this.n = parama13;
  }
  
  public static i a(a<b> parama, a<DbxUserManager.a> parama1, a<c> parama2, a<g0> parama3, a<j.b> parama4, a<g> parama5, a<e<e>> parama6, a<k> parama7, a<o> parama8, a<g> parama9, a<a> parama10, a<E> parama11, a<m0> parama12, a<b> parama13) {
    return new i(parama, parama1, parama2, parama3, parama4, parama5, parama6, parama7, parama8, parama9, parama10, parama11, parama12, parama13);
  }
  
  public static h c(b paramb, DbxUserManager.a parama, Object paramObject, g0 paramg0, j.b paramb1, g paramg, e<e> parame, k paramk, o paramo, g paramg1, a parama1, E paramE, m0 paramm0, b paramb2) {
    return new h(paramb, parama, (c)paramObject, paramg0, paramb1, paramg, parame, paramk, paramo, paramg1, parama1, paramE, paramm0, paramb2);
  }
  
  public h b() {
    return c((b)this.a.get(), (DbxUserManager.a)this.b.get(), this.c.get(), (g0)this.d.get(), (j.b)this.e.get(), (g)this.f.get(), (e<e>)this.g.get(), (k)this.h.get(), (o)this.i.get(), (g)this.j.get(), (a)this.k.get(), (E)this.l.get(), (m0)this.m.get(), (b)this.n.get());
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\androi\\user\i.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */