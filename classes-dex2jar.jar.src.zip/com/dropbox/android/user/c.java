package com.dropbox.android.user;

import dbxyzptlk.CC.p;
import dbxyzptlk.pc.i0;
import dbxyzptlk.pc.j0;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.atomic.AtomicReference;

public class c implements j0 {
  public final Set<i0> a = new HashSet<>();
  
  public final AtomicReference<e> b = new AtomicReference<>();
  
  public final e.a c;
  
  public c(e.a parama) {
    this.c = parama;
  }
  
  public void a(i0 parami0) {
    synchronized (this.a) {
      p.e(this.a.add(parami0), "Assert failed.");
      return;
    } 
  }
  
  public void b() {
    if ((e)this.b.getAndSet(this.c.a()) == null)
      return; 
    throw new IllegalStateException("Cannot call create when there's already a managed state.");
  }
  
  public void c() {
    e e = this.b.getAndSet(null);
    if (e != null) {
      f();
      e.a();
      return;
    } 
    throw new IllegalStateException("Cannot call destroy when there's no managed state.");
  }
  
  public e d() {
    return this.b.get();
  }
  
  public boolean e() {
    boolean bool;
    if (this.b.get() != null) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public final void f() {
    Set<i0> set = this.a;
    /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{java/util/Set<ObjectType{dbxyzptlk/pc/i0}>}, name=null} */
    try {
      ArrayList arrayList = new ArrayList();
      this((Collection)this.a);
      Iterator<i0> iterator = arrayList.iterator();
      while (iterator.hasNext())
        ((i0)iterator.next()).u(); 
    } finally {
      Exception exception;
    } 
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/util/Set<ObjectType{dbxyzptlk/pc/i0}>}, name=null} */
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\androi\\user\c.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */