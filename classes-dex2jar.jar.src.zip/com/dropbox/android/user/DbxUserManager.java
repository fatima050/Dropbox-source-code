package com.dropbox.android.user;

import com.dropbox.core.android.auth.SharedAccount;
import dbxyzptlk.CC.l;
import dbxyzptlk.CC.p;
import dbxyzptlk.Ec.g;
import dbxyzptlk.Me.f;
import dbxyzptlk.pc.d0;
import dbxyzptlk.pc.u0;
import dbxyzptlk.pc.v0;
import dbxyzptlk.yn.j;
import java.util.Set;

public interface DbxUserManager extends f {
  a a();
  
  void b();
  
  g c(u0 paramu0);
  
  void d(c paramc);
  
  com.dropbox.android.accounts.store.a<d0> e(dbxyzptlk.Ne.b paramb, dbxyzptlk.Ce.a parama, boolean paramBoolean) throws RegisterUserException;
  
  dbxyzptlk.Ee.a.f f(e parame);
  
  b g();
  
  boolean h(String paramString);
  
  void i(d paramd);
  
  void j();
  
  void k(boolean paramBoolean1, boolean paramBoolean2);
  
  dbxyzptlk.Ee.a.f l(f paramf);
  
  void n();
  
  com.dropbox.android.accounts.store.a<d0> o(dbxyzptlk.Ne.b paramb, boolean paramBoolean) throws RegisterUserException;
  
  boolean p(String paramString, boolean paramBoolean);
  
  public static class RegisterUserException extends Exception {
    private static final long serialVersionUID = 21791956152470273L;
    
    public RegisterUserException(String param1String) {
      super(param1String);
    }
    
    public RegisterUserException(String param1String, Throwable param1Throwable) {
      super(param1String, param1Throwable);
    }
    
    public RegisterUserException(Throwable param1Throwable) {
      super(param1Throwable);
    }
  }
  
  public static abstract class a {
    public abstract Set<String> a();
    
    public abstract d0 b(d0 param1d0, dbxyzptlk.C6.a param1a, u0 param1u0);
    
    public abstract d0 c(u0 param1u0, dbxyzptlk.C6.a param1a, j param1j, DbxUserManager param1DbxUserManager, e param1e);
    
    public final d0 d(d0 param1d0, dbxyzptlk.C6.a param1a) {
      SharedAccount sharedAccount1 = param1a.f();
      SharedAccount sharedAccount2 = param1d0.k2().f();
      return (l.a(sharedAccount1.h, sharedAccount2.h) && l.a(sharedAccount1.g, sharedAccount2.g) && l.a(sharedAccount1.j, sharedAccount2.j) && l.a(sharedAccount1.i, sharedAccount2.i) && l.a(sharedAccount1.k, sharedAccount2.k)) ? param1d0 : b(param1d0, param1a, v0.b(param1a, null, param1d0.h2()));
    }
  }
  
  public static class b {
    public final a a;
    
    public final e b;
    
    public b(e param1e, a param1a) {
      p.o(param1e);
      this.b = param1e;
      if (param1a != null) {
        boolean bool;
        if (param1e == param1a.k()) {
          bool = true;
        } else {
          bool = false;
        } 
        p.e(bool, "Assert failed.");
      } 
      this.a = param1a;
    }
    
    public e a() {
      return this.b;
    }
    
    public a b() {
      return this.a;
    }
  }
  
  public static interface c {
    void a(d0 param1d0);
  }
  
  public static interface d {
    void a(d0 param1d0);
  }
  
  class DbxUserManager {}
  
  public static interface f {
    void a(a param1a);
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\androi\\user\DbxUserManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */