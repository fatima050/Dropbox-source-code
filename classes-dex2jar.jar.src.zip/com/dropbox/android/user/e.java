package com.dropbox.android.user;

import android.content.Context;
import dbxyzptlk.Ny.f;
import dbxyzptlk.lf.k;
import dbxyzptlk.ok.b;
import dbxyzptlk.un.g;
import dbxyzptlk.x9.u;

public class e {
  public final dbxyzptlk.qb.e a;
  
  public final u b;
  
  public final f c;
  
  public final g d;
  
  public e(dbxyzptlk.qb.e parame, u paramu, f paramf, g paramg) {
    this.a = parame;
    this.b = paramu;
    this.c = paramf;
    this.d = paramg;
  }
  
  public void a() {
    this.a.C();
    this.d.d();
  }
  
  public f b() {
    return this.c;
  }
  
  public u c() {
    return this.b;
  }
  
  public dbxyzptlk.qb.e d() {
    return this.a;
  }
  
  public void e(a.b paramb, DbxUserManager paramDbxUserManager) {
    this.d.f(paramb, paramDbxUserManager);
  }
  
  public static class a {
    public final Context a;
    
    public final b b;
    
    public final g c;
    
    public final dbxyzptlk.qb.e.b d;
    
    public final f e;
    
    public final k f;
    
    public a(Context param1Context, b param1b, dbxyzptlk.qb.e.b param1b1, g param1g, f param1f, k param1k) {
      this.a = param1Context;
      this.b = param1b;
      this.d = param1b1;
      this.c = param1g;
      this.e = param1f;
      this.f = param1k;
    }
    
    public e a() {
      dbxyzptlk.qb.e e = this.d.a();
      return new e(e, new u(this.a, this.c, e, this.b, this.f), this.e, new g());
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\androi\\user\e.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */