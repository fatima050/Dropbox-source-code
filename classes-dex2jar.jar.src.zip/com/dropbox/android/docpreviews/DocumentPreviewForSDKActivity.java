package com.dropbox.android.docpreviews;

import android.content.Context;
import android.content.Intent;
import com.dropbox.android.DropboxApplication;
import com.dropbox.android.activity.DropboxBrowser;
import com.dropbox.android.activity.base.BaseForSDKUserRequestActivity;
import com.dropbox.product.dbapp.openwith.b;
import com.dropbox.product.dbapp.path.DropboxPath;
import dbxyzptlk.CC.p;
import dbxyzptlk.Ec.a;
import dbxyzptlk.Ec.m;
import dbxyzptlk.M8.d;
import dbxyzptlk.pc.d0;
import dbxyzptlk.w6.V0;
import dbxyzptlk.yx.e;

public class DocumentPreviewForSDKActivity extends BaseForSDKUserRequestActivity {
  public m B4() {
    return a.O1();
  }
  
  public void C4(d0 paramd0) {
    p.o(paramd0);
    String str = b.d(getIntent());
    try {
      DropboxPath dropboxPath = new DropboxPath(str, false);
      Intent intent = G4(dropboxPath, paramd0);
      if (intent != null) {
        startActivity(intent);
      } else {
        startActivity(DropboxBrowser.x4((Context)this, dropboxPath, paramd0.l()));
      } 
      finish();
      return;
    } catch (RuntimeException runtimeException) {
      F4(1, getResources().getString(V0.external_preview_invalid_path));
      return;
    } 
  }
  
  public void D4() {
    F4(2, getResources().getString(V0.external_preview_invalid_user));
  }
  
  public final Intent G4(DropboxPath paramDropboxPath, d0 paramd0) {
    return ((d)DropboxApplication.c1((Context)this).a(paramd0.l())).v3().f((Context)this, paramDropboxPath, paramd0.l(), e.SDK_PREVIEW);
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\android\docpreviews\DocumentPreviewForSDKActivity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */