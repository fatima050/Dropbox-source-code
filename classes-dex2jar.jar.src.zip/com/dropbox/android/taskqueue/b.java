package com.dropbox.android.taskqueue;

import com.dropbox.common.taskqueue.SingleAttemptTaskQueue;
import com.dropbox.common.taskqueue.TaskQueue;
import com.dropbox.common.taskqueue.TaskResult;
import com.dropbox.product.dbapp.path.Path;
import com.google.common.collect.e;
import com.google.common.collect.z;
import dbxyzptlk.CC.h;
import dbxyzptlk.CC.p;
import dbxyzptlk.CC.q;
import dbxyzptlk.EC.D;
import dbxyzptlk.Fj.a;
import dbxyzptlk.He.p;
import dbxyzptlk.Sq.k;
import dbxyzptlk.Xs.L;
import dbxyzptlk.dk.A;
import dbxyzptlk.lc.e;
import dbxyzptlk.rx.d;
import dbxyzptlk.vq.g;
import java.io.File;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

public class b<T extends Path> implements a<T> {
  public final File a;
  
  public final File b;
  
  public final PreviewDownloadTask$c<T> c;
  
  public final HashMap<T, HashSet<a.b<T>>> d = new HashMap<>();
  
  public final TaskQueue<PreviewDownloadTask<T>> e;
  
  public final c<T> f;
  
  public k g;
  
  public final com.dropbox.common.taskqueue.c.a h = new a(this);
  
  public b(dbxyzptlk.ib.a<T> parama, File paramFile1, File paramFile2, d<T> paramd, L paramL, k paramk, dbxyzptlk.t6.b paramb, g paramg) {
    paramFile1 = (File)p.o(paramFile1);
    this.a = paramFile1;
    this.b = paramFile2;
    c<Path> c1 = new c<>(paramFile1, paramFile2, parama, null);
    this.f = (c)c1;
    k k1 = (k)p.o(paramk);
    this.g = k1;
    this.c = new PreviewDownloadTask$c<>(paramd, paramL, (c)c1, k1, paramg);
    this.e = (TaskQueue<PreviewDownloadTask<T>>)new SingleAttemptTaskQueue(paramb, 4, 5);
  }
  
  public void a(T[] paramArrayOfT) {
    j(z.k((Object[])p.o(paramArrayOfT)));
  }
  
  public void b(T paramT, String paramString) {
    p.o(paramT);
    p.o(paramString);
    PreviewDownloadTask<T> previewDownloadTask = this.c.a(paramT, paramString, false);
    previewDownloadTask.a(this.h);
    this.e.e((TaskQueue.BaseTask)previewDownloadTask);
  }
  
  public void c(T paramT, String paramString) {
    this.f.k(paramT, paramString);
  }
  
  public void clear() {
    j(Collections.emptySet());
  }
  
  public void d(T paramT, String paramString) {
    p.o(paramT);
    p.o(paramString);
    p.e(k(), "Assert failed.");
    PreviewDownloadTask<T> previewDownloadTask = this.c.a(paramT, paramString, true);
    previewDownloadTask.a(this.h);
    this.e.e((TaskQueue.BaseTask)previewDownloadTask);
  }
  
  public void e() {
    clear();
    this.e.l();
  }
  
  public void f(T paramT, a.b<T> paramb) {
    HashSet<a.b<T>> hashSet;
    p.o(paramT);
    p.o(paramb);
    HashMap<T, HashSet<a.b<T>>> hashMap = this.d;
    /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{java/util/HashMap<[GenericType{T}, ObjectType{java/util/HashSet<InnerObjectType{ObjectType{dbxyzptlk/Fj/a}.Ldbxyzptlk/Fj/a$b;<GenericType{T}>}>}]>}, name=null} */
    try {
      HashSet<a.b<T>> hashSet1 = this.d.get(paramT);
      hashSet = hashSet1;
      if (hashSet1 == null) {
        hashSet = new HashSet();
        this();
        this.d.put(paramT, hashSet);
      } 
    } finally {}
    p.e(hashSet.add(paramb), "Assert failed.");
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/util/HashMap<[GenericType{T}, ObjectType{java/util/HashSet<InnerObjectType{ObjectType{dbxyzptlk/Fj/a}.Ldbxyzptlk/Fj/a$b;<GenericType{T}>}>}]>}, name=null} */
  }
  
  public void g(T paramT, a.b<T> paramb) {
    p.o(paramT);
    p.o(paramb);
    HashMap<T, HashSet<a.b<T>>> hashMap = this.d;
    /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{java/util/HashMap<[GenericType{T}, ObjectType{java/util/HashSet<InnerObjectType{ObjectType{dbxyzptlk/Fj/a}.Ldbxyzptlk/Fj/a$b;<GenericType{T}>}>}]>}, name=null} */
    try {
      HashSet hashSet = this.d.get(paramT);
      p.o(hashSet);
      p.e(hashSet.remove(paramb), "Assert failed.");
      if (hashSet.isEmpty())
        this.d.remove(paramT); 
    } finally {}
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/util/HashMap<[GenericType{T}, ObjectType{java/util/HashSet<InnerObjectType{ObjectType{dbxyzptlk/Fj/a}.Ldbxyzptlk/Fj/a$b;<GenericType{T}>}>}]>}, name=null} */
  }
  
  public final void j(Set<T> paramSet) {
    this.e.i();
    this.f.c(paramSet);
  }
  
  public final boolean k() {
    boolean bool;
    if (this.b != null) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public class a implements com.dropbox.common.taskqueue.c.a {
    public final b a;
    
    public a(b this$0) {}
    
    public void a(com.dropbox.common.taskqueue.c param1c, TaskResult param1TaskResult) {
      a.a a1;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("onError(");
      stringBuilder.append(param1TaskResult);
      stringBuilder.append(")");
      dbxyzptlk.sL.a.d(stringBuilder.toString(), new Object[0]);
      PreviewDownloadTask previewDownloadTask = (PreviewDownloadTask)param1c;
      Path path = previewDownloadTask.p();
      String str = previewDownloadTask.q();
      switch (b.b.a[param1TaskResult.a().ordinal()]) {
        default:
          a1 = a.a.OTHER;
          break;
        case 6:
          a1 = a.a.ENCRCRYPTED_FOLDER_CLIENT_NOT_ENROLLED;
          break;
        case 5:
          a1 = a.a.FILETYPE_NOT_SUPPORTED;
          break;
        case 4:
          a1 = a.a.PASSWORD_PROTECTED_FILE;
          break;
        case 3:
          a1 = a.a.FILE_TOO_LARGE;
          break;
        case 2:
          a1 = a.a.NETWORK_ERROR;
          break;
        case 1:
          a1 = a.a.PENDING;
          break;
      } 
      HashMap hashMap = b.i(this.a);
      /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{java/util/HashMap}, name=null} */
      try {
        HashSet hashSet = (HashSet)b.i(this.a).get(path);
        if (hashSet != null) {
          HashSet hashSet1 = new HashSet();
          this(hashSet);
          Iterator<a.b> iterator = hashSet1.iterator();
          while (iterator.hasNext())
            ((a.b)iterator.next()).c(path, str, a1); 
        } 
      } finally {}
      /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/util/HashMap}, name=null} */
    }
    
    public void b(com.dropbox.common.taskqueue.c param1c) {
      PreviewDownloadTask previewDownloadTask = (PreviewDownloadTask)param1c;
      Path path = previewDownloadTask.p();
      String str = previewDownloadTask.q();
      boolean bool = previewDownloadTask.s();
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("preview download complete for ");
      stringBuilder.append(path);
      stringBuilder.append(" rev = ");
      stringBuilder.append(str);
      dbxyzptlk.sL.a.d(stringBuilder.toString(), new Object[0]);
      File file = b.h(this.a).d(path, str);
      if (file == null) {
        dbxyzptlk.sL.a.j("failed to load preview from cache for %s", new Object[] { path.y0() });
        a(param1c, new TaskResult(TaskResult.b.STORAGE_ERROR));
        return;
      } 
      HashMap hashMap = b.i(this.a);
      /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{java/util/HashMap}, name=null} */
      try {
        HashSet hashSet = (HashSet)b.i(this.a).get(path);
        if (hashSet != null) {
          HashSet hashSet1 = new HashSet();
          this(hashSet);
          Iterator<a.b> iterator = hashSet1.iterator();
          while (iterator.hasNext())
            ((a.b)iterator.next()).a(path, str, file, bool); 
        } 
      } finally {}
      /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/util/HashMap}, name=null} */
    }
    
    public void c(com.dropbox.common.taskqueue.c param1c, long param1Long1, long param1Long2) {
      Path path = ((PreviewDownloadTask)param1c).p();
      HashMap hashMap = b.i(this.a);
      /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{java/util/HashMap}, name=null} */
      try {
        HashSet hashSet = (HashSet)b.i(this.a).get(path);
        if (hashSet != null) {
          HashSet hashSet1 = new HashSet();
          this(hashSet);
          Iterator<a.b> iterator = hashSet1.iterator();
          while (iterator.hasNext())
            ((a.b)iterator.next()).d(param1Long1, param1Long2); 
        } 
      } finally {}
      /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/util/HashMap}, name=null} */
    }
    
    public void d(com.dropbox.common.taskqueue.c param1c) {}
    
    public void e(com.dropbox.common.taskqueue.c param1c) {
      PreviewDownloadTask previewDownloadTask = (PreviewDownloadTask)param1c;
      Path path = previewDownloadTask.p();
      String str = previewDownloadTask.q();
      HashMap hashMap = b.i(this.a);
      /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{java/util/HashMap}, name=null} */
      try {
        HashSet hashSet = (HashSet)b.i(this.a).get(path);
        if (hashSet != null) {
          HashSet hashSet1 = new HashSet();
          this(hashSet);
          Iterator<a.b> iterator = hashSet1.iterator();
          while (iterator.hasNext())
            ((a.b)iterator.next()).b(path, str); 
        } 
      } finally {}
      /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/util/HashMap}, name=null} */
    }
  }
  
  public static class c<U extends Path> {
    public final File a;
    
    public final File b;
    
    public final dbxyzptlk.ib.a<U> c;
    
    public c(File param1File1, File param1File2, dbxyzptlk.ib.a<U> param1a) {
      this.a = (File)p.o(param1File1);
      this.b = param1File2;
      this.c = (dbxyzptlk.ib.a<U>)p.o(param1a);
    }
    
    public static <V extends Path> String h(V param1V) {
      p.o(param1V);
      String str = param1V.getName().toLowerCase(Locale.US).replaceAll("[^a-zA-Z0-9]", "");
      return (str.length() >= 8) ? str.substring(0, 8) : p.m(str, 8, '-');
    }
    
    public void c(Set<U> param1Set) {
      if (param1Set.isEmpty()) {
        dbxyzptlk.HK.c.e(this.a);
        dbxyzptlk.HK.c.e(this.b);
        this.c.a();
      } else {
        HashSet hashSet1 = z.i(e.e(z.c(param1Set, (q)new c(this)), (h)new d(this)));
        HashSet hashSet2 = z.i(e.e(z.c(param1Set, (q)new e(this)), (h)new f(this)));
        Collection collection = this.c.getAll();
        D.p(collection, (q)new g(this, hashSet1, hashSet2));
        if (this.c.c(collection))
          for (dbxyzptlk.ib.a.a a1 : collection) {
            dbxyzptlk.HK.c.e(e(a1.c));
            dbxyzptlk.HK.c.e(f(a1.c));
          }  
      } 
    }
    
    public File d(U param1U, String param1String) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("cache get ");
      stringBuilder.append(param1U);
      stringBuilder.append(" rev ");
      stringBuilder.append(param1String);
      dbxyzptlk.sL.a.d(stringBuilder.toString(), new Object[0]);
      dbxyzptlk.ib.a.a a1 = this.c.e((Path)param1U, param1String);
      if (a1 == null) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("no cache entry exists for: ");
        stringBuilder.append(param1U);
        stringBuilder.append(" rev ");
        stringBuilder.append(param1String);
        dbxyzptlk.sL.a.d(stringBuilder.toString(), new Object[0]);
        return null;
      } 
      File file1 = e(a1.c);
      File file2 = f(a1.c);
      if (!file1.exists())
        file1 = file2; 
      if (file1 == null || !file1.exists()) {
        dbxyzptlk.sL.a.j("preview no longer exists: %s", new Object[] { param1U.y0() });
        k(param1U, param1String);
        return null;
      } 
      if (a1.a != file1.length()) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("preview size mismatch: ");
        stringBuilder1.append(a1.a);
        stringBuilder1.append(" != ");
        stringBuilder1.append(file1.length());
        dbxyzptlk.sL.a.j(stringBuilder1.toString(), new Object[0]);
        k(param1U, param1String);
        return null;
      } 
      if (a1.b != file1.lastModified()) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("preview mod time mismatch: ");
        stringBuilder1.append(a1.b);
        stringBuilder1.append(" != ");
        stringBuilder1.append(file1.lastModified());
        dbxyzptlk.sL.a.j(stringBuilder1.toString(), new Object[0]);
        k(param1U, param1String);
        return null;
      } 
      return file1;
    }
    
    public final File e(String param1String) {
      return new File(g(param1String, false), param1String);
    }
    
    public final File f(String param1String) {
      if (i()) {
        File file = new File(g(param1String, true), param1String);
      } else {
        param1String = null;
      } 
      return (File)param1String;
    }
    
    public final File g(String param1String, boolean param1Boolean) {
      File file;
      p.o(param1String);
      boolean bool = param1String.isEmpty();
      boolean bool1 = true;
      p.d(bool ^ true);
      bool = bool1;
      if (param1Boolean)
        if (this.b != null) {
          bool = bool1;
        } else {
          bool = false;
        }  
      p.d(bool);
      if (param1Boolean) {
        file = this.b;
      } else {
        file = this.a;
      } 
      return new File(file, Character.toString(param1String.charAt(9)));
    }
    
    public final boolean i() {
      boolean bool;
      if (this.b != null) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    }
    
    public File j(U param1U, String param1String1, File param1File, String param1String2, boolean param1Boolean) {
      /* monitor enter ThisExpression{InnerObjectType{ObjectType{com/dropbox/android/taskqueue/b}.Lcom/dropbox/android/taskqueue/b$c;}} */
      try {
        p.o(param1U);
        p.o(param1String1);
        p.o(param1File);
        p.o(param1String2);
        if (!param1Boolean || i()) {
          bool = true;
        } else {
          bool = false;
        } 
      } finally {}
      p.d(bool);
      StringBuilder stringBuilder3 = new StringBuilder();
      this();
      File file1;
      StringBuilder stringBuilder2;
      File file2;
      stringBuilder3.append("cache put path=");
      stringBuilder3.append(param1U);
      stringBuilder3.append(" rev=");
      stringBuilder3.append(param1String1);
      dbxyzptlk.sL.a.d(stringBuilder3.toString(), new Object[0]);
      boolean bool = param1String2.equals("application/pdf");
      stringBuilder3 = null;
      if (!bool && !param1String2.equals("text/html")) {
        stringBuilder2 = new StringBuilder();
        this();
        stringBuilder2.append("preview for ");
        stringBuilder2.append(param1U.y0());
        stringBuilder2.append(" has unknown mime type ");
        stringBuilder2.append(param1String2);
        dbxyzptlk.sL.a.j(stringBuilder2.toString(), new Object[0]);
        /* monitor exit ThisExpression{InnerObjectType{ObjectType{com/dropbox/android/taskqueue/b}.Lcom/dropbox/android/taskqueue/b$c;}} */
        return null;
      } 
      param1String2 = A.e(param1String2);
      UUID uUID = UUID.randomUUID();
      String str = String.format("%s-%s.%s", new Object[] { h(param1U), uUID.toString(), param1String2 });
      File file4 = e(str);
      File file3 = f(str);
      if (param1Boolean) {
        file2 = file3;
      } else {
        file2 = file4;
      } 
      p.o(file2);
      if (file4.exists() && !file4.delete()) {
        dbxyzptlk.sL.a.j("couldn't delete unexpected preview file for %s", new Object[] { param1U.y0() });
        /* monitor exit ThisExpression{InnerObjectType{ObjectType{com/dropbox/android/taskqueue/b}.Lcom/dropbox/android/taskqueue/b$c;}} */
        return null;
      } 
      if (file3 != null && file3.exists() && !file3.delete()) {
        dbxyzptlk.sL.a.j("couldn't delete unexpected preview file for %s", new Object[] { param1U.y0() });
        /* monitor exit ThisExpression{InnerObjectType{ObjectType{com/dropbox/android/taskqueue/b}.Lcom/dropbox/android/taskqueue/b$c;}} */
        return null;
      } 
      file3 = file2.getParentFile();
      if (!file3.exists() && !com.dropbox.base.filesystem.c.q(file3)) {
        dbxyzptlk.sL.a.j("couldn't create directory %s", new Object[] { file3 });
        /* monitor exit ThisExpression{InnerObjectType{ObjectType{com/dropbox/android/taskqueue/b}.Lcom/dropbox/android/taskqueue/b$c;}} */
        return null;
      } 
      dbxyzptlk.sL.a.d("preview file path =  %s", new Object[] { file2.getPath() });
      dbxyzptlk.ib.a<U> a1 = this.c;
      a a2 = new a();
      this(this, file2);
      param1Boolean = a1.f((Path)param1U, (String)stringBuilder2, param1File, str, (q)a2);
      StringBuilder stringBuilder1 = stringBuilder3;
      if (param1Boolean)
        file1 = file2; 
      /* monitor exit ThisExpression{InnerObjectType{ObjectType{com/dropbox/android/taskqueue/b}.Lcom/dropbox/android/taskqueue/b$c;}} */
      return file1;
    }
    
    public void k(U param1U, String param1String) {
      boolean bool;
      p.o(param1U);
      if (param1U.q0()) {
        bool = m(param1U);
      } else {
        bool = l(param1U, param1String);
      } 
      if (bool)
        dbxyzptlk.sL.a.d("deleted previews for  %s", new Object[] { param1U.getName() }); 
    }
    
    public final boolean l(U param1U, String param1String) {
      dbxyzptlk.ib.a.a a1 = this.c.e((Path)param1U, param1String);
      boolean bool = false;
      if (a1 == null) {
        dbxyzptlk.sL.a.j("tried to remove nonexistent cache entry for %s", new Object[] { param1U.y0() });
        return false;
      } 
      File file1 = e(a1.c);
      File file2 = f(a1.c);
      try {
        if (file1.exists())
          file1.delete(); 
      } catch (Exception exception) {}
      if (file2 != null && file2.exists())
        file2.delete(); 
      bool = true;
      return this.c.b((Path)param1U) & bool;
    }
    
    public final boolean m(U param1U) {
      dbxyzptlk.sL.a.d("removing previews for  %s", new Object[] { param1U });
      p.o(param1U);
      p.d(param1U.q0());
      return this.c.d((Path)param1U, (q)new b(this));
    }
    
    public boolean n(U param1U, String param1String, boolean param1Boolean) {
      StringBuilder stringBuilder;
      p.o(param1U);
      p.o(param1String);
      if (param1Boolean && !i())
        return false; 
      dbxyzptlk.ib.a.a a1 = this.c.e((Path)param1U, param1String);
      if (a1 == null) {
        stringBuilder = new StringBuilder();
        stringBuilder.append("no cache entry exists for: ");
        stringBuilder.append(param1U);
        stringBuilder.append(" rev ");
        stringBuilder.append(param1String);
        dbxyzptlk.sL.a.d(stringBuilder.toString(), new Object[0]);
        return false;
      } 
      File file4 = e(((dbxyzptlk.ib.a.a)stringBuilder).c);
      File file3 = (File)p.o(f(((dbxyzptlk.ib.a.a)stringBuilder).c));
      File file2 = file4;
      File file1 = file3;
      if (param1Boolean) {
        file1 = file4;
        file2 = file3;
      } 
      if (file2.exists())
        return true; 
      file3 = file2.getParentFile();
      return (!file3.exists() && !com.dropbox.base.filesystem.c.q(file3)) ? false : file1.renameTo(file2);
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\android\taskqueue\b.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */