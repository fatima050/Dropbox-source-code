package com.dropbox.android.taskqueue;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Looper;
import com.dropbox.common.taskqueue.SingleAttemptTaskQueue;
import com.dropbox.common.taskqueue.TaskQueue;
import com.dropbox.common.taskqueue.TaskResult;
import com.dropbox.common.taskqueue.c;
import com.dropbox.product.dbapp.path.Path;
import com.google.common.collect.q;
import com.google.common.collect.z;
import dbxyzptlk.CC.l;
import dbxyzptlk.CC.p;
import dbxyzptlk.CC.q;
import dbxyzptlk.EC.D;
import dbxyzptlk.Ec.g;
import dbxyzptlk.Ee.a;
import dbxyzptlk.Fe.b;
import dbxyzptlk.HK.c;
import dbxyzptlk.HK.e;
import dbxyzptlk.It.l;
import dbxyzptlk.It.m;
import dbxyzptlk.Ow.c;
import dbxyzptlk.Ow.d;
import dbxyzptlk.Ow.e;
import dbxyzptlk.Ow.g;
import dbxyzptlk.Xs.L;
import dbxyzptlk.YJ.t;
import dbxyzptlk.dk.X;
import dbxyzptlk.ib.k;
import dbxyzptlk.rx.d;
import dbxyzptlk.sL.a;
import dbxyzptlk.t6.b;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Collections;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class RealThumbnailStore<S extends Path> implements g<S> {
  public final File a;
  
  public final File b;
  
  public final k<S> c;
  
  public final ThumbnailTask$c<S> d;
  
  public final Handler e = new Handler(Looper.getMainLooper());
  
  public final a.c<e<S>, g.d<S>> f = a.c.e();
  
  public final d g = new d(5000);
  
  public final Map<e<S>, String> h = q.g();
  
  public final TaskQueue<ThumbnailTask<S>> i;
  
  public final TaskQueue<ThumbnailTask<S>> j;
  
  public final TaskQueue<ThumbnailTask<S>> k;
  
  public final TaskQueue<ThumbnailPreloadTask> l;
  
  public final l m;
  
  public final c.a n = new h(this);
  
  public RealThumbnailStore(k<S> paramk, File paramFile1, File paramFile2, ThumbnailTask$c<S> paramThumbnailTask$c, b paramb, l paraml) {
    this.c = (k<S>)p.o(paramk);
    this.a = (File)p.o(paramFile1);
    this.d = (ThumbnailTask$c<S>)p.o(paramThumbnailTask$c);
    this.b = paramFile2;
    this.i = (TaskQueue<ThumbnailTask<S>>)new SingleAttemptTaskQueue(paramb, 4, 5);
    this.j = (TaskQueue<ThumbnailTask<S>>)new SingleAttemptTaskQueue(paramb, 3, 4);
    this.k = (TaskQueue<ThumbnailTask<S>>)new SingleAttemptTaskQueue(paramb, 8, 4);
    this.l = (TaskQueue<ThumbnailPreloadTask>)new SingleAttemptTaskQueue(paramb, 1, 4);
    this.m = paraml;
  }
  
  public RealThumbnailStore(k<S> paramk, File paramFile1, File paramFile2, d<S> paramd, L paramL, b paramb, g paramg, l paraml) {
    this(paramk, paramFile1, paramFile2, new ThumbnailTask$c<>(paramd, paramL, paramg), paramb, paraml);
  }
  
  public static g.c C(TaskResult.b paramb) {
    if (paramb == null)
      return null; 
    int i = i.b[paramb.ordinal()];
    return (i != 1) ? ((i != 2) ? ((i != 3) ? g.c.OTHER : g.c.THUMBNAIL_UNAVAILABLE) : g.c.PERMANENT_FAILURE) : g.c.NETWORK_ERROR;
  }
  
  public static String I(c paramc) {
    StringBuilder stringBuilder;
    switch (i.c[paramc.ordinal()]) {
      default:
        stringBuilder = new StringBuilder();
        stringBuilder.append("Unexpected thumb size: ");
        stringBuilder.append(paramc);
        throw new IllegalArgumentException(stringBuilder.toString());
      case 9:
        return "original";
      case 8:
        return "256x256_fit_one_bestfit";
      case 7:
        return "3200x2400_bestfit";
      case 6:
        return "2048x1536_bestfit";
      case 5:
        return "1024x768_bestfit";
      case 4:
        return "960x640_bestfit";
      case 3:
        return "640x480_bestfit";
      case 2:
        return "256x256";
      case 1:
        break;
    } 
    return "large";
  }
  
  public final boolean A(TaskQueue<ThumbnailTask<S>> paramTaskQueue, e<S> parame, String paramString) {
    p.e(P(), "Assert failed.");
    ThumbnailTask<S> thumbnailTask = this.d.b(parame, paramString, O(parame), K(parame), true, paramTaskQueue);
    if (thumbnailTask == null)
      return false; 
    thumbnailTask.a(this.n);
    paramTaskQueue.e((TaskQueue.BaseTask)thumbnailTask);
    return true;
  }
  
  public final void B() {
    if (this.h.isEmpty())
      return; 
    synchronized (this.g) {
      Set<?> set = this.c.f(this.h);
      this.h.keySet().removeAll(set);
      return;
    } 
  }
  
  public final Bitmap D(e<S> parame) {
    File file = E(parame);
    if (file != null && file.exists())
      try {
        return Q(file);
      } catch (IOException iOException) {} 
    return null;
  }
  
  public final File E(e<S> parame) {
    // Byte code:
    //   0: aload_1
    //   1: invokestatic o : (Ljava/lang/Object;)Ljava/lang/Object;
    //   4: pop
    //   5: aload_0
    //   6: invokevirtual P : ()Z
    //   9: ifeq -> 21
    //   12: aload_0
    //   13: aload_1
    //   14: invokevirtual O : (Ldbxyzptlk/Ow/e;)Ljava/io/File;
    //   17: astore_2
    //   18: goto -> 23
    //   21: aconst_null
    //   22: astore_2
    //   23: aload_2
    //   24: ifnull -> 36
    //   27: aload_2
    //   28: astore_3
    //   29: aload_2
    //   30: invokevirtual exists : ()Z
    //   33: ifne -> 42
    //   36: aload_0
    //   37: aload_1
    //   38: invokevirtual K : (Ldbxyzptlk/Ow/e;)Ljava/io/File;
    //   41: astore_3
    //   42: aload_3
    //   43: invokevirtual exists : ()Z
    //   46: ifeq -> 51
    //   49: aload_3
    //   50: areturn
    //   51: aconst_null
    //   52: areturn
  }
  
  public TaskQueue<ThumbnailTask<S>> F(g.a parama) {
    p.o(parama);
    int i = i.a[parama.ordinal()];
    if (i != 1) {
      if (i != 2) {
        if (i == 3)
          return this.k; 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Unrecognized Queue: ");
        stringBuilder.append(parama);
        throw new IllegalStateException(stringBuilder.toString());
      } 
      return this.j;
    } 
    return this.i;
  }
  
  public final String G(e<S> parame) {
    d.a<S> a1 = new d.a(parame);
    U(a1);
    String str2 = parame.d().m2();
    String str3 = this.g.b(a1, str2);
    if (str3 != null)
      return str3; 
    String str1 = H(parame);
    this.g.d(a1, str2, str1);
    return str1;
  }
  
  public final String H(e<S> parame) {
    return this.c.g(parame);
  }
  
  public final File J(S paramS) {
    return new File(this.a, m.a(this.m, (Path)paramS).b());
  }
  
  public File K(e<S> parame) {
    return M(parame, false);
  }
  
  public final ThumbnailTask<S> L(TaskQueue<ThumbnailTask<S>> paramTaskQueue, e<S> parame, String paramString, boolean paramBoolean) {
    File file;
    if (P()) {
      file = O(parame);
    } else {
      file = null;
    } 
    ThumbnailTask<S> thumbnailTask = this.d.a(parame, paramString, file, K(parame), paramBoolean, paramTaskQueue);
    if (thumbnailTask == null)
      return null; 
    thumbnailTask.a(this.n);
    return thumbnailTask;
  }
  
  public final File M(e<S> parame, boolean paramBoolean) {
    boolean bool;
    File file1;
    p.o(parame);
    if (!paramBoolean || this.b != null) {
      bool = true;
    } else {
      bool = false;
    } 
    p.d(bool);
    if (paramBoolean) {
      file1 = this.b;
    } else {
      file1 = this.a;
    } 
    File file2 = new File(file1, m.b(this.m, file1, parame.d()).b());
    String str2 = I(parame.e());
    String str1 = parame.c().getExtension();
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(str2);
    stringBuilder.append(".");
    stringBuilder.append(str1);
    return new File(file2, stringBuilder.toString());
  }
  
  public final File N(S paramS) {
    return new File(this.b, m.a(this.m, (Path)paramS).b());
  }
  
  public File O(e<S> parame) {
    return M(parame, true);
  }
  
  public final boolean P() {
    boolean bool;
    if (this.b != null) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public final Bitmap Q(File paramFile) throws IOException {
    p.o(paramFile);
    BitmapFactory.Options options = new BitmapFactory.Options();
    options.inPreferredConfig = Bitmap.Config.RGB_565;
    options.inTempStorage = X.a();
    File file = null;
    try {
      FileInputStream fileInputStream2 = new FileInputStream();
      this(paramFile);
      FileInputStream fileInputStream1 = io.sentry.instrumentation.file.h.b.a(fileInputStream2, paramFile);
    } finally {
      options = null;
    } 
    e.b((InputStream)paramFile);
    throw options;
  }
  
  public final void R(e<S> parame, String paramString) {
    y(parame, (a.b<g.d<S>>)new b(this, parame, paramString));
  }
  
  public final void S(e<S> parame, TaskResult.b paramb) {
    y(parame, (a.b<g.d<S>>)new c(this, parame, paramb));
  }
  
  public final void T(e<S> parame, long paramLong1, long paramLong2) {
    y(parame, (a.b<g.d<S>>)new d(this, paramLong1, paramLong2));
  }
  
  public final void U(d.a<S> parama) {
    if (!this.g.c(parama))
      for (Map.Entry entry : this.c.e(parama).entrySet())
        this.g.d(parama, ((Path)entry.getKey()).m2(), (String)entry.getValue());  
  }
  
  public void a(S[] paramArrayOfS) {
    w(z.k((Object[])p.o(paramArrayOfS)));
  }
  
  public void b(g.a parama, e<S> parame) {
    F(parama).v(parame.f());
  }
  
  public File c(e<S> parame, String paramString) {
    b.b();
    p.o(parame);
    p.d(t.C(paramString) ^ true);
    String str = G(parame);
    return (str != null && l.a(str, paramString)) ? E(parame) : null;
  }
  
  public void clear() {
    w(Collections.emptySet());
  }
  
  public g.b d(g.a parama, e<S> parame, String paramString) {
    Long long_1;
    p.o(parame);
    p.d(t.C(paramString) ^ true);
    String str = G(parame);
    Bitmap bitmap = null;
    Long long_2 = null;
    if (str != null) {
      bitmap = D(parame);
      File file = E(parame);
      long_1 = long_2;
      if (bitmap != null) {
        long_1 = long_2;
        if (file != null)
          long_1 = Long.valueOf(file.length()); 
      } 
    } else {
      long_1 = null;
    } 
    boolean bool = false;
    if (str == null || !l.a(paramString, str) || bitmap == null)
      bool = z(F(parama), parame, paramString, false); 
    return new g.b(bool, bitmap, long_1);
  }
  
  public void e() {
    clear();
    this.l.l();
    this.k.l();
    this.j.l();
    this.i.l();
  }
  
  public void f(g.a parama, e<S> parame, String paramString) {
    p.o(parama);
    p.o(parame);
    p.d(t.C(paramString) ^ true);
    this.l.e((TaskQueue.BaseTask)new ThumbnailPreloadTask(this, parama, parame, paramString, false));
  }
  
  public void flush() {
    B();
  }
  
  public void g(S paramS) {
    p.o(paramS);
    c.e(J(paramS));
    c.e(N(paramS));
    this.c.c((Path)paramS);
  }
  
  public void h(g.a parama, e<S> parame, String paramString) {
    b.b();
    p.o(parama);
    p.o(parame);
    p.d(t.C(paramString) ^ true);
    p.e(P(), "Assert failed.");
    String str = G(parame);
    if (str != null && l.a(str, paramString)) {
      if (O(parame).exists())
        return; 
      if (K(parame).exists())
        A(F(parama), parame, paramString); 
    } 
    z(F(parama), parame, paramString, true);
  }
  
  public void i(g.a parama, e<S> parame) {
    this.l.v(parame.f());
    F(parama).v(parame.f());
  }
  
  public Bitmap j(g.a parama, e<S> parame, String paramString) {
    b.b();
    p.o(parame);
    p.d(t.C(paramString) ^ true);
    return (G(parame) != null) ? D(parame) : null;
  }
  
  public a.f k(e<S> parame, g.d<S> paramd) {
    return this.f.f(parame, paramd);
  }
  
  public File l(g.a parama, e<S> parame, String paramString) {
    File file;
    p.o(parame);
    p.d(t.C(paramString) ^ true);
    String str = G(parame);
    if (str != null && l.a(str, paramString)) {
      file = E(parame);
    } else {
      str = null;
    } 
    if (str == null)
      file = v(F(parama), parame, paramString, false); 
    return file;
  }
  
  public void u(e<S> parame, String paramString, boolean paramBoolean) {
    p.o(parame);
    p.o(paramString);
    String str = parame.d().m2();
    synchronized (this.g) {
      d d1 = this.g;
      d.a a1 = new d.a();
      this(parame);
      d1.d(a1, str, paramString);
      this.h.put(parame, paramString);
      if (this.h.size() > 20 || paramBoolean)
        B(); 
      return;
    } 
  }
  
  public final File v(TaskQueue<ThumbnailTask<S>> paramTaskQueue, e<S> parame, String paramString, boolean paramBoolean) {
    ThumbnailTask<S> thumbnailTask = L(paramTaskQueue, parame, paramString, paramBoolean);
    if (thumbnailTask == null)
      return null; 
    thumbnailTask.e();
    return E(parame);
  }
  
  public final void w(Set<S> paramSet) {
    g.a[] arrayOfA = g.a.values();
    int i = arrayOfA.length;
    for (byte b = 0; b < i; b++)
      F(arrayOfA[b]).i(); 
    this.l.i();
    this.g.a();
    B();
    x(paramSet);
  }
  
  public final void x(Set<S> paramSet) {
    if (paramSet.isEmpty()) {
      c.e(this.a);
      c.e(this.b);
      this.c.a();
    } else {
      Set<?> set = z.c(paramSet, (q)new e(this));
      paramSet = z.c(paramSet, (q)new f(this));
      HashSet hashSet = z.i(this.c.getAll());
      hashSet.removeAll(set);
      D.p(hashSet, (q)new g(this, paramSet));
      if (this.c.d(hashSet))
        for (Path path : hashSet) {
          c.e(J((S)path));
          c.e(N((S)path));
        }  
    } 
  }
  
  public final void y(e<S> parame, a.b<g.d<S>> paramb) {
    this.e.post((Runnable)new a(this, parame, paramb));
  }
  
  public final boolean z(TaskQueue<ThumbnailTask<S>> paramTaskQueue, e<S> parame, String paramString, boolean paramBoolean) {
    ThumbnailTask<S> thumbnailTask = L(paramTaskQueue, parame, paramString, paramBoolean);
    if (thumbnailTask == null)
      return false; 
    thumbnailTask.a(this.n);
    paramTaskQueue.e((TaskQueue.BaseTask)thumbnailTask);
    return true;
  }
  
  class RealThumbnailStore {}
  
  public class h implements c.a {
    public final RealThumbnailStore a;
    
    public h(RealThumbnailStore this$0) {}
    
    public void a(c param1c, TaskResult param1TaskResult) {
      e e = ((ThumbnailTask)param1c).p();
      RealThumbnailStore.r(this.a, e, param1TaskResult.a());
    }
    
    public void b(c param1c) {
      ThumbnailTask thumbnailTask = (ThumbnailTask)param1c;
      e<S> e = thumbnailTask.p();
      String str = thumbnailTask.r();
      boolean bool = thumbnailTask.s();
      if (str == null) {
        a.j("Completed thumb task, but unknown revision! Can't update thumbnail store db without knowing the revision!", new Object[0]);
        return;
      } 
      this.a.u(e, str, bool);
      if (thumbnailTask.q().x() <= 1)
        RealThumbnailStore.o(this.a); 
      RealThumbnailStore.q(this.a, e, str);
    }
    
    public void c(c param1c, long param1Long1, long param1Long2) {
      e e = ((ThumbnailTask)param1c).p();
      RealThumbnailStore.s(this.a, e, param1Long1, param1Long2);
    }
    
    public void d(c param1c) {}
    
    public void e(c param1c) {}
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\android\taskqueue\RealThumbnailStore.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */