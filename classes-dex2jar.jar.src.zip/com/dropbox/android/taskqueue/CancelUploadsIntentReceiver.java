package com.dropbox.android.taskqueue;

import android.content.Context;
import android.content.Intent;
import com.dropbox.android.DropboxApplication;
import com.dropbox.android.user.a;
import com.dropbox.common.android.context.BaseBroadcastReceiver;
import dbxyzptlk.CC.v;
import dbxyzptlk.Nz.D;
import dbxyzptlk.Rh.b;
import dbxyzptlk.Rh.o;
import dbxyzptlk.Yh.e;
import dbxyzptlk.lc.b;
import dbxyzptlk.pc.d0;
import dbxyzptlk.sL.a;
import java.io.Serializable;
import java.util.ArrayList;

public class CancelUploadsIntentReceiver extends BaseBroadcastReceiver {
  public static Intent b(String paramString, b paramb) {
    Intent intent = new Intent();
    intent.putExtra("EXTRA_USER_ID", paramString);
    intent.putExtra("EXTRA_TASK_TYPE", (Serializable)paramb);
    intent.setAction("com.dropbox.android.taskqueue.ACTION_CANCEL_MANUAL_UPLOADS");
    return intent;
  }
  
  public void onReceive(Context paramContext, Intent paramIntent) {
    super.onReceive(paramContext, paramIntent);
    String str = paramIntent.getStringExtra("EXTRA_USER_ID");
    b b = (b)paramIntent.getSerializableExtra("EXTRA_TASK_TYPE");
    if (b == null)
      return; 
    a.d("Received intent to cancel all upload type:  %s", new Object[] { b.name() });
    a a = DropboxApplication.b1(paramContext).a();
    if (a != null) {
      d0 d0 = a.q(str);
      if (d0 != null)
        d0.Q1().execute((Runnable)new b(b, paramContext, str)); 
    } 
  }
  
  class CancelUploadsIntentReceiver {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\android\taskqueue\CancelUploadsIntentReceiver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */