package com.dropbox.android.sharing;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import androidx.appcompat.app.a;
import com.dropbox.android.DropboxApplication;
import com.dropbox.android.activity.base.BaseIdentityActivity;
import com.dropbox.android.user.a;
import com.dropbox.common.android.ui.widgets.CollapsibleHalfSheetView;
import com.dropbox.product.dbapp.path.DropboxPath;
import com.google.common.collect.j;
import dbxyzptlk.CC.p;
import dbxyzptlk.EC.b0;
import dbxyzptlk.Ec.g;
import dbxyzptlk.Fc.Qg;
import dbxyzptlk.Fc.e7;
import dbxyzptlk.Fc.f7;
import dbxyzptlk.Fc.g7;
import dbxyzptlk.Fc.h7;
import dbxyzptlk.Fc.i7;
import dbxyzptlk.K6.a;
import dbxyzptlk.Z2.a;
import dbxyzptlk.cz.i;
import dbxyzptlk.lz.p;
import dbxyzptlk.qc.A;
import dbxyzptlk.rf.i;
import dbxyzptlk.sL.a;
import dbxyzptlk.yf.e;

public class GrantAccessDispatchActivity extends BaseIdentityActivity {
  public String d;
  
  public a e;
  
  public c.a f = null;
  
  public Handler g = new Handler();
  
  public g h;
  
  public final a.a<c.a> i = (a.a<c.a>)new a(this);
  
  public final i.h<String> j = (i.h<String>)new b(this);
  
  public static i7 L4(boolean paramBoolean) {
    i7 i7;
    if (paramBoolean) {
      i7 = i7.FOLDER;
    } else {
      i7 = i7.FILE;
    } 
    return i7;
  }
  
  public static Intent O4(Context paramContext, Uri paramUri) {
    Intent intent = new Intent(paramContext, GrantAccessDispatchActivity.class);
    intent.setData(paramUri);
    return intent;
  }
  
  public static Intent P4(Context paramContext, String paramString) {
    return O4(paramContext, Uri.parse(paramString));
  }
  
  public static Intent Q4(Context paramContext, String paramString1, DropboxPath paramDropboxPath, String paramString2) {
    return SharedContentInviteActivity.L4(paramContext, paramString1, paramDropboxPath, Qg.GRANT_ACCESS_ANDROID, CollapsibleHalfSheetView.j.FULL_SCREEN, false, paramString2);
  }
  
  public static String R4(Intent paramIntent) {
    if (paramIntent.getData() != null) {
      Uri uri = paramIntent.getData();
    } else {
      paramIntent = null;
    } 
    p.p(paramIntent, "Expected a url to load");
    return paramIntent.toString();
  }
  
  public final void M4() {
    a a1 = this.e;
    if (a1 != null)
      a1.dismiss(); 
  }
  
  public final String N4(String paramString) {
    a.b b = z4().l();
    if (b != null) {
      b0<A> b0 = j.L(b.d(), b.f()).p();
      while (b0.hasNext()) {
        A a1 = b0.next();
        if (!a1.f0().equals(paramString))
          return a1.d0(); 
      } 
    } 
    a.d("Can't log in a second user: no pairing info found", new Object[0]);
    return null;
  }
  
  public final void S4(GrantAccessErrorActivity.GrantAccessErrorStatus paramGrantAccessErrorStatus) {
    startActivity(GrantAccessErrorActivity.E4((Context)this, this.f.b(), paramGrantAccessErrorStatus, this.d));
    finish();
  }
  
  public final void T4(e7 parame7, i7 parami7) {
    (new f7()).k(parame7).l(parami7).g(this.h);
  }
  
  public final void U4() {
    (new g7()).k(i7.UNKNOWN).g(this.h);
  }
  
  public final void V4(i7 parami7) {
    (new h7()).k(parami7).g(this.h);
  }
  
  public final void W4() {
    this.f.a().a(this.j, this.f.b());
  }
  
  public void X3(Bundle paramBundle, boolean paramBoolean) {}
  
  public final void X4() {
    this.g.post((Runnable)new d(this));
  }
  
  public final void Y4() {
    if (this.e == null) {
      a a1 = e.a((Context)this, getString(p.scl_grant_loading));
      this.e = a1;
      a1.setCancelable(true);
      this.e.setOnCancelListener((DialogInterface.OnCancelListener)new c(this));
      this.e.setCanceledOnTouchOutside(false);
      this.e.show();
    } 
  }
  
  public void j2() {
    startActivity(a.d((Context)this, getIntent(), true, null));
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    setContentView(i.frag_container);
    this.h = DropboxApplication.b0((Context)this);
    if (w4())
      return; 
    this.d = R4(getIntent());
    A4(paramBundle);
  }
  
  public void onStart() {
    super.onStart();
    U4();
    Y4();
    getSupportLoaderManager().d(0, null, this.i);
  }
  
  public void onStop() {
    super.onStop();
    M4();
  }
  
  class GrantAccessDispatchActivity {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\android\sharing\GrantAccessDispatchActivity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */