package com.dropbox.android.sharing;

import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.animation.StateListAnimator;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.View;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.o;
import com.dropbox.android.DropboxApplication;
import com.dropbox.android.activity.base.BaseIdentityActivity;
import com.dropbox.android.user.a;
import com.dropbox.common.android.ui.widgets.DbxToolbar;
import com.dropbox.kaiken.scoping.ViewingUserSelector;
import com.dropbox.product.dbapp.entry.LocalEntry;
import com.dropbox.product.dbapp.entry.SharedLinkLocalEntry;
import com.dropbox.product.dbapp.path.SharedLinkPath;
import dbxyzptlk.CC.p;
import dbxyzptlk.Fe.c;
import dbxyzptlk.Fq.f;
import dbxyzptlk.Fq.q;
import dbxyzptlk.K6.a;
import dbxyzptlk.dk.H;
import dbxyzptlk.dk.S;
import dbxyzptlk.dk.x;
import dbxyzptlk.rc.b;
import dbxyzptlk.sL.a;
import dbxyzptlk.tx.b;
import dbxyzptlk.w6.Q0;
import dbxyzptlk.w6.R0;
import dbxyzptlk.zb.c0;
import java.io.Serializable;

public class SharedLinkFolderBrowserActivity extends BaseIdentityActivity implements DbxToolbar.c, f {
  public SharedLinkFolderBrowserFragment d;
  
  public DbxToolbar e;
  
  public View f;
  
  public SharedLinkPath g;
  
  public b h;
  
  public String i;
  
  public String j;
  
  public c k;
  
  public Boolean l;
  
  public Boolean m;
  
  public SharedLinkLocalEntry n = null;
  
  public x o;
  
  public static Intent D4(Context paramContext, SharedLinkLocalEntry paramSharedLinkLocalEntry, String paramString1, String paramString2, c paramc, Boolean paramBoolean1, Boolean paramBoolean2) {
    p.o(paramContext);
    p.o(paramSharedLinkLocalEntry);
    Intent intent = new Intent(paramContext, SharedLinkFolderBrowserActivity.class);
    intent.putExtra("ARG_PATH", (Parcelable)paramSharedLinkLocalEntry.s());
    intent.putExtra("ARG_SHARED_CONTENT_USER_ID", paramString1);
    intent.putExtra("ARG_SHARED_CONTENT_FOLDER_ID", paramString2);
    intent.putExtra("ARG_ROOT_LOCAL_ENTRY", (Parcelable)paramSharedLinkLocalEntry);
    intent.putExtra("ARG_PASSWORD", (Serializable)paramc);
    intent.putExtra("ARG_CAN_MOUNT", paramBoolean1);
    intent.putExtra("ARG_CAN_REQUEST_ACCESS", paramBoolean2);
    if (paramString1 != null)
      q.d(intent, ViewingUserSelector.a(paramString1)); 
    return intent;
  }
  
  public void B4() {
    startActivity(a.a((Context)this, null, true));
  }
  
  public void C4(SharedLinkLocalEntry paramSharedLinkLocalEntry) {
    if (((SharedLinkPath)paramSharedLinkLocalEntry.s()).h1())
      this.n = paramSharedLinkLocalEntry; 
    if (!((SharedLinkPath)paramSharedLinkLocalEntry.s()).h(this.o)) {
      SharedLinkLocalEntry sharedLinkLocalEntry = this.n;
      if ((sharedLinkLocalEntry != null && !b.a((LocalEntry)sharedLinkLocalEntry)) || !b.a((LocalEntry)paramSharedLinkLocalEntry))
        this.f.setVisibility(0); 
    } 
  }
  
  public SharedLinkPath E4() {
    return this.g.e();
  }
  
  public DbxToolbar G() {
    return this.e;
  }
  
  public void X3(Bundle paramBundle, boolean paramBoolean) {
    if (paramBundle == null) {
      this.d = SharedLinkFolderBrowserFragment.F4(this.n, this.i, this.j, this.k, this.l, this.m);
      o o = getSupportFragmentManager().q();
      o.b(Q0.frag_container, (Fragment)this.d);
      o.k();
    } else {
      this.d = (SharedLinkFolderBrowserFragment)getSupportFragmentManager().l0(Q0.frag_container);
    } 
  }
  
  public boolean k3(a parama) {
    String str = this.i;
    return (str == null || (parama != null && parama.q(str) != null));
  }
  
  public void onBackPressed() {
    SharedLinkFolderBrowserFragment sharedLinkFolderBrowserFragment = this.d;
    if (sharedLinkFolderBrowserFragment == null || !sharedLinkFolderBrowserFragment.v2())
      super.onBackPressed(); 
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    if (!w4() && !u()) {
      setContentView(R0.shared_link_browser_container);
      this.o = ((c0)s()).v0();
      DbxToolbar dbxToolbar = (DbxToolbar)findViewById(Q0.dbx_toolbar);
      this.e = dbxToolbar;
      dbxToolbar.b();
      View view = findViewById(Q0.appbar);
      StateListAnimator stateListAnimator = new StateListAnimator();
      ObjectAnimator objectAnimator = ObjectAnimator.ofFloat(view, "elevation", new float[] { 0.0F });
      stateListAnimator.addState(new int[0], (Animator)objectAnimator);
      view.setStateListAnimator(stateListAnimator);
      setSupportActionBar((Toolbar)this.e);
      setTitle(null);
      this.f = findViewById(Q0.bottom_bar);
      Bundle bundle = getIntent().getExtras();
      if (bundle == null) {
        a.g("Original intent extras were null, finishing activity", new Object[0]);
        finish();
      } else {
        this.g = (SharedLinkPath)H.d(bundle, "ARG_PATH", SharedLinkPath.class);
        this.i = bundle.getString("ARG_SHARED_CONTENT_USER_ID");
        this.j = bundle.getString("ARG_SHARED_CONTENT_FOLDER_ID");
        this.n = (SharedLinkLocalEntry)H.d(bundle, "ARG_ROOT_LOCAL_ENTRY", SharedLinkLocalEntry.class);
        this.h = DropboxApplication.Z0((Context)this);
        this.k = (c)S.a(bundle, "ARG_PASSWORD", c.class);
        this.l = Boolean.valueOf(bundle.getBoolean("ARG_CAN_MOUNT"));
        this.m = Boolean.valueOf(bundle.getBoolean("ARG_CAN_REQUEST_ACCESS"));
        this.f.setVisibility(8);
        A4(paramBundle);
        findViewById(Q0.appbar).setAccessibilityTraversalBefore(Q0.frag_container);
        this.f.setAccessibilityTraversalAfter(Q0.frag_container);
      } 
    } 
  }
  
  public void onResumeFragments() {
    super.onResumeFragments();
    this.h.f((FragmentActivity)this);
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\android\sharing\SharedLinkFolderBrowserActivity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */