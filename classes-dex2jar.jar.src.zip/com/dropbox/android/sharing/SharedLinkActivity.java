package com.dropbox.android.sharing;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import com.dropbox.android.DropboxApplication;
import com.dropbox.android.activity.base.BaseIdentityActivity;
import com.dropbox.android.sharedlinkreceiverflow.view.SharedLinkReceiverFlowProgressDialogFragment;
import com.dropbox.android.user.a;
import com.dropbox.product.dbapp.sharing.data.entity.SharedLinkUrl;
import com.dropbox.product.dbapp.sharing.data.entity.SharedLinkUrlParseException;
import dbxyzptlk.Ec.a;
import dbxyzptlk.Ec.m;
import dbxyzptlk.Fc.E2;
import dbxyzptlk.Fq.f;
import dbxyzptlk.K6.a;
import dbxyzptlk.az.X;
import dbxyzptlk.dk.S;
import dbxyzptlk.pc.d0;
import dbxyzptlk.rf.i;
import dbxyzptlk.tb.b;
import java.io.Serializable;

public class SharedLinkActivity extends BaseIdentityActivity implements f {
  public static final ComponentName e;
  
  public SharedLinkUrl d;
  
  static {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(SharedLinkActivity.class.getName());
    stringBuilder.append(".ContentLinkAlias");
    e = new ComponentName("com.dropbox.android", stringBuilder.toString());
  }
  
  public static Intent C4(Context paramContext, Uri paramUri) {
    Intent intent;
    if (SharedLinkUrl.d(paramUri)) {
      intent = new Intent(paramContext, SharedLinkActivity.class);
      intent.setData(paramUri);
    } else {
      intent = new Intent("android.intent.action.VIEW", paramUri);
      intent.addFlags(268435456);
    } 
    return intent;
  }
  
  public static Intent D4(Context paramContext, Uri paramUri, E2 paramE2) {
    Intent intent = C4(paramContext, paramUri);
    intent.putExtra("ARG_SOURCE", (Serializable)paramE2);
    return intent;
  }
  
  public static Intent E4(Context paramContext, Uri paramUri, String paramString) {
    Intent intent = C4(paramContext, paramUri);
    intent.putExtra("ARG_PASSWORD", paramString);
    return intent;
  }
  
  public static Intent F4(Context paramContext, Uri paramUri, String paramString) {
    Intent intent = C4(paramContext, paramUri);
    intent.putExtra("EMAIL_PREFILL", paramString);
    return intent;
  }
  
  public static Intent G4(Context paramContext, Uri paramUri, String paramString) {
    Intent intent = C4(paramContext, paramUri);
    intent.putExtra("EXTRA_HOME_SESSION_ID", paramString);
    return intent;
  }
  
  public static Intent H4(Context paramContext, Uri paramUri, E2 paramE2) {
    Intent intent = new Intent(paramContext, SharedLinkActivity.class);
    intent.setData(paramUri);
    intent.putExtra("ARG_SHOW_COMMENTS_IF_POSSIBLE", true);
    intent.putExtra("ARG_SOURCE", (Serializable)paramE2);
    return intent;
  }
  
  public final void B4(SharedLinkUrlParseException paramSharedLinkUrlParseException, Uri paramUri, b paramb) {
    paramb.f(paramSharedLinkUrlParseException);
    startActivity(SharedLinkErrorActivity.x4((Context)this, X.PARSE_ERROR, paramUri, false));
    finish();
  }
  
  public void X3(Bundle paramBundle, boolean paramBoolean) {}
  
  public void j2() {
    startActivity(a.d((Context)this, getIntent(), true, null));
  }
  
  public boolean k3(a parama) {
    String str = this.d.c;
    boolean bool1 = str.startsWith("/l/spri");
    boolean bool = true;
    if (bool1 || str.startsWith("/spri")) {
      if (parama == null)
        bool = false; 
      return bool;
    } 
    return true;
  }
  
  public void onCreate(Bundle paramBundle) {
    m m;
    super.onCreate(paramBundle);
    setContentView(i.frag_container);
    Intent intent = getIntent();
    Uri uri = intent.getData();
    try {
      SharedLinkUrl sharedLinkUrl = SharedLinkUrl.a(uri);
      this.d = sharedLinkUrl;
      boolean bool = sharedLinkUrl.e;
      boolean bool1 = true;
      if (bool || getIntent().getBooleanExtra("ARG_SHOW_COMMENTS_IF_POSSIBLE", false)) {
        bool = true;
      } else {
        bool = false;
      } 
      E2 e2 = (E2)S.b(getIntent(), "ARG_SOURCE", E2.class);
      if (e2 == E2.IN_APP_NOTIFICATION_ANDROID || e2 == E2.SYSTEM_NOTIFICATION_ANDROID)
        bool1 = false; 
      SharedLinkReceiverFlowProgressDialogFragment.t2(getIntent(), bool, bool1).show(getSupportFragmentManager(), SharedLinkReceiverFlowProgressDialogFragment.class.getName());
      if (!w4() && !u()) {
        if (this.d.c.startsWith("/l/scl") || this.d.c.startsWith("/scl")) {
          String str = intent.getStringExtra("ARG_INVITATION_SIGNATURE");
          if (str != null && z4() != null && !z4().t()) {
            getIntent().removeExtra("ARG_INVITATION_SIGNATURE");
            d0 d0 = z4().o();
            if (d0.h2().E0()) {
              m = a.z2();
            } else {
              m = a.y2();
            } 
            m.o("invitation_sig", str).i(d0.e());
          } 
        } 
        A4(paramBundle);
      } 
      return;
    } catch (SharedLinkUrlParseException sharedLinkUrlParseException) {
      B4(sharedLinkUrlParseException, (Uri)m, ((DropboxApplication)getApplication()).u().a());
      return;
    } 
  }
  
  public void onDestroy() {
    SharedLinkReceiverFlowProgressDialogFragment.q2(getSupportFragmentManager());
    super.onDestroy();
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\android\sharing\SharedLinkActivity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */