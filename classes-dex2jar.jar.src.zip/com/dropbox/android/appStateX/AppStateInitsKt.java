package com.dropbox.android.appStateX;

import android.app.Application;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import com.dropbox.android.notifications.f;
import com.dropbox.android.taskqueue.CancelUploadsIntentReceiver;
import com.dropbox.android.user.DbxUserManager;
import com.dropbox.common.android.context.BaseBroadcastReceiver;
import dbxyzptlk.A6.a;
import dbxyzptlk.Cj.d;
import dbxyzptlk.DI.s;
import dbxyzptlk.Ec.g;
import dbxyzptlk.Fc.V;
import dbxyzptlk.Fe.b;
import dbxyzptlk.Ie.a;
import dbxyzptlk.Ij.s;
import dbxyzptlk.Mq.a;
import dbxyzptlk.Mq.c;
import dbxyzptlk.Mq.f;
import dbxyzptlk.Mq.h;
import dbxyzptlk.N6.r;
import dbxyzptlk.Nh.d;
import dbxyzptlk.V1.b;
import dbxyzptlk.aH.a;
import dbxyzptlk.f6.h;
import dbxyzptlk.fh.d;
import dbxyzptlk.fh.e;
import dbxyzptlk.kf.f;
import dbxyzptlk.mi.c;
import dbxyzptlk.mi.d;
import dbxyzptlk.mi.e;
import dbxyzptlk.mi.f;
import dbxyzptlk.ni.a;
import dbxyzptlk.ok.b;
import dbxyzptlk.pj.h;
import dbxyzptlk.rc.b;
import dbxyzptlk.un.g;
import kotlin.Metadata;

@Metadata(d1 = {"\000|\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020\000\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\007\n\002\030\002\n\000\n\002\030\002\n\002\b\004\032-\020\t\032\0020\b2\006\020\001\032\0020\0002\006\020\003\032\0020\0022\006\020\005\032\0020\0042\006\020\007\032\0020\006¢\006\004\b\t\020\n\032Å\001\020$\032\0020\b2\006\020\001\032\0020\0002\f\020\r\032\b\022\004\022\0020\f0\0132\f\020\005\032\b\022\004\022\0020\0040\0132\f\020\017\032\b\022\004\022\0020\0160\0132\f\020\021\032\b\022\004\022\0020\0200\0132\f\020\023\032\b\022\004\022\0020\0220\0132\f\020\025\032\b\022\004\022\0020\0240\0132\f\020\027\032\b\022\004\022\0020\0260\0132\f\020\031\032\b\022\004\022\0020\0300\0132\f\020\033\032\b\022\004\022\0020\0320\0132\f\020\035\032\b\022\004\022\0020\0340\0132\f\020\037\032\b\022\004\022\0020\0360\0132\f\020!\032\b\022\004\022\0020 0\0132\006\020#\032\0020\"¢\006\004\b$\020%\032\027\020&\032\0020\b2\006\020\001\032\0020\000H\002¢\006\004\b&\020'\032K\020(\032\0020\b2\006\020\001\032\0020\0002\006\020\025\032\0020\0242\006\020\005\032\0020\0042\f\020\033\032\b\022\004\022\0020\0320\0132\006\020\035\032\0020\0342\006\020\037\032\0020\0362\006\020!\032\0020 ¢\006\004\b(\020)\0325\020.\032\0020\b2\006\020\001\032\0020\0002\006\020+\032\0020*2\006\020\005\032\0020\0042\006\020\035\032\0020\0342\006\020-\032\0020,¢\006\004\b.\020/¨\0060"}, d2 = {"Landroid/app/Application;", "app", "Ldbxyzptlk/Ij/s;", "udcl", "Ldbxyzptlk/mi/c;", "perfMonitor", "Ldbxyzptlk/Ec/g;", "analyticsLogger", "Ldbxyzptlk/pI/D;", "b", "(Landroid/app/Application;Ldbxyzptlk/Ij/s;Ldbxyzptlk/mi/c;Ldbxyzptlk/Ec/g;)V", "Ldbxyzptlk/aH/a;", "Ldbxyzptlk/fh/e;", "devSettingsComponent", "Ldbxyzptlk/ok/b;", "envInfo", "Ldbxyzptlk/un/g;", "globalProperties", "Ldbxyzptlk/kf/f;", "crashReportingWiring", "Lcom/dropbox/android/user/DbxUserManager;", "userManager", "Ldbxyzptlk/rc/b;", "userLeapManager", "Ldbxyzptlk/N6/r;", "lateDropboxInit", "", "userSupplier", "Lcom/dropbox/android/notifications/f;", "systemTrayNotificationController", "Ldbxyzptlk/Ie/a;", "appInForegroundUtil", "Ldbxyzptlk/Cj/d;", "userStore", "Ldbxyzptlk/A6/a;", "dbAppLoginGate", "c", "(Landroid/app/Application;Ldbxyzptlk/aH/a;Ldbxyzptlk/aH/a;Ldbxyzptlk/aH/a;Ldbxyzptlk/aH/a;Ldbxyzptlk/aH/a;Ldbxyzptlk/aH/a;Ldbxyzptlk/aH/a;Ldbxyzptlk/aH/a;Ldbxyzptlk/aH/a;Ldbxyzptlk/aH/a;Ldbxyzptlk/aH/a;Ldbxyzptlk/aH/a;Ldbxyzptlk/A6/a;)V", "d", "(Landroid/app/Application;)V", "e", "(Landroid/app/Application;Lcom/dropbox/android/user/DbxUserManager;Ldbxyzptlk/mi/c;Ldbxyzptlk/aH/a;Lcom/dropbox/android/notifications/f;Ldbxyzptlk/Ie/a;Ldbxyzptlk/Cj/d;)V", "Ldbxyzptlk/pj/h;", "dbxHttpHeaders", "Ldbxyzptlk/Nh/d;", "localizationComponent", "g", "(Landroid/app/Application;Ldbxyzptlk/pj/h;Ldbxyzptlk/mi/c;Lcom/dropbox/android/notifications/f;Ldbxyzptlk/Nh/d;)V", "Dropbox_normalRelease"}, k = 2, mv = {1, 9, 0}, xi = 48)
public final class AppStateInitsKt {
  public static final void b(Application paramApplication, s params, c paramc, g paramg) {
    s.h(paramApplication, "app");
    s.h(params, "udcl");
    s.h(paramc, "perfMonitor");
    s.h(paramg, "analyticsLogger");
    b.a();
    d(paramApplication);
    s.j(params, "app.initialization.cold", null, 0L, null, null, 30, null);
    paramc.b((f)new a(paramg));
    paramc.e((d)a.a);
    paramc.d((e)c.b);
  }
  
  public static final void c(Application paramApplication, a<e> parama, a<c> parama1, a<b> parama2, a<g> parama3, a<f> parama4, a<DbxUserManager> parama5, a<b> parama6, a<r> parama7, a<Object> parama8, a<f> parama9, a<a> parama10, a<d> parama11, a parama12) {
    s.h(paramApplication, "app");
    s.h(parama, "devSettingsComponent");
    s.h(parama1, "perfMonitor");
    s.h(parama2, "envInfo");
    s.h(parama3, "globalProperties");
    s.h(parama4, "crashReportingWiring");
    s.h(parama5, "userManager");
    s.h(parama6, "userLeapManager");
    s.h(parama7, "lateDropboxInit");
    s.h(parama8, "userSupplier");
    s.h(parama9, "systemTrayNotificationController");
    s.h(parama10, "appInForegroundUtil");
    s.h(parama11, "userStore");
    s.h(parama12, "dbAppLoginGate");
    d.a().set(((e)parama.get()).b());
    ((b)parama2.get()).l(((g)parama3.get()).u(), ((g)parama3.get()).v());
    f f = (f)parama4.get();
    String str = ((g)parama3.get()).u();
    s.g(str, "deviceID(...)");
    f.b(str);
    ((r)parama7.get()).d();
    ((c)parama1.get()).d((e)f.b);
    Object object1 = parama5.get();
    s.g(object1, "get(...)");
    object1 = object1;
    Object object2 = parama1.get();
    s.g(object2, "get(...)");
    object2 = object2;
    Object object3 = parama9.get();
    s.g(object3, "get(...)");
    object3 = object3;
    Object object4 = parama10.get();
    s.g(object4, "get(...)");
    object4 = object4;
    Object object5 = parama11.get();
    s.g(object5, "get(...)");
    e(paramApplication, (DbxUserManager)object1, (c)object2, parama8, (f)object3, (a)object4, (d)object5);
  }
  
  public static final void d(Application paramApplication) {
    h.a.c((Context)paramApplication, null, null);
  }
  
  public static final void e(Application paramApplication, DbxUserManager paramDbxUserManager, c paramc, a<Object> parama, f paramf, a parama1, d paramd) {
    // Byte code:
    //   0: aload_0
    //   1: ldc 'app'
    //   3: invokestatic h : (Ljava/lang/Object;Ljava/lang/String;)V
    //   6: aload_1
    //   7: ldc 'userManager'
    //   9: invokestatic h : (Ljava/lang/Object;Ljava/lang/String;)V
    //   12: aload_2
    //   13: ldc 'perfMonitor'
    //   15: invokestatic h : (Ljava/lang/Object;Ljava/lang/String;)V
    //   18: aload_3
    //   19: ldc 'userSupplier'
    //   21: invokestatic h : (Ljava/lang/Object;Ljava/lang/String;)V
    //   24: aload #4
    //   26: ldc 'systemTrayNotificationController'
    //   28: invokestatic h : (Ljava/lang/Object;Ljava/lang/String;)V
    //   31: aload #5
    //   33: ldc 'appInForegroundUtil'
    //   35: invokestatic h : (Ljava/lang/Object;Ljava/lang/String;)V
    //   38: aload #6
    //   40: ldc 'userStore'
    //   42: invokestatic h : (Ljava/lang/Object;Ljava/lang/String;)V
    //   45: aload_2
    //   46: getstatic dbxyzptlk/Mq/f.b : Ldbxyzptlk/Mq/f;
    //   49: invokeinterface d : (Ldbxyzptlk/mi/e;)V
    //   54: aload_3
    //   55: invokeinterface get : ()Ljava/lang/Object;
    //   60: pop
    //   61: aload_1
    //   62: invokeinterface j : ()V
    //   67: aload_1
    //   68: invokeinterface a : ()Lcom/dropbox/android/user/a;
    //   73: astore_2
    //   74: aload_2
    //   75: ifnull -> 97
    //   78: aload_2
    //   79: invokevirtual h : ()Ldbxyzptlk/pc/d0;
    //   82: astore_2
    //   83: aload_2
    //   84: ifnull -> 97
    //   87: aload_2
    //   88: invokeinterface l : ()Ljava/lang/String;
    //   93: astore_2
    //   94: goto -> 99
    //   97: aconst_null
    //   98: astore_2
    //   99: aload #6
    //   101: aload_2
    //   102: invokeinterface d : (Ljava/lang/String;)V
    //   107: aload_1
    //   108: invokeinterface g : ()Lcom/dropbox/android/user/DbxUserManager$b;
    //   113: invokevirtual a : ()Lcom/dropbox/android/user/e;
    //   116: invokevirtual d : ()Ldbxyzptlk/qb/e;
    //   119: new dbxyzptlk/N6/c
    //   122: dup
    //   123: aload #6
    //   125: invokespecial <init> : (Ldbxyzptlk/Cj/d;)V
    //   128: invokevirtual W : (Ldbxyzptlk/qb/e$c;)V
    //   131: aload #4
    //   133: invokevirtual t : ()V
    //   136: aload #5
    //   138: aload_0
    //   139: invokevirtual d : (Landroid/app/Application;)V
    //   142: return
  }
  
  public static final void f(d paramd, String paramString) {
    s.h(paramd, "$userStore");
    paramd.d(paramString);
  }
  
  public static final void g(Application paramApplication, h paramh, c paramc, f paramf, d paramd) {
    s.h(paramApplication, "app");
    s.h(paramh, "dbxHttpHeaders");
    s.h(paramc, "perfMonitor");
    s.h(paramf, "systemTrayNotificationController");
    s.h(paramd, "localizationComponent");
    paramc.d((e)h.b);
    paramApplication.registerReceiver((BroadcastReceiver)new AppStateInitsKt$registerReceivers$1(paramh, paramd, paramf), new IntentFilter("android.intent.action.LOCALE_CHANGED"));
    b.l((Context)paramApplication, (BroadcastReceiver)new CancelUploadsIntentReceiver(), new IntentFilter("com.dropbox.android.taskqueue.ACTION_CANCEL_MANUAL_UPLOADS"), 4);
    new V();
  }
  
  @Metadata(d1 = {"\000\035\n\000\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\003*\001\000\b\n\030\0002\0020\001J\037\020\007\032\0020\0062\006\020\003\032\0020\0022\006\020\005\032\0020\004H\026¢\006\004\b\007\020\b¨\006\t"}, d2 = {"com/dropbox/android/appStateX/AppStateInitsKt$registerReceivers$1", "Lcom/dropbox/common/android/context/BaseBroadcastReceiver;", "Landroid/content/Context;", "context", "Landroid/content/Intent;", "intent", "Ldbxyzptlk/pI/D;", "onReceive", "(Landroid/content/Context;Landroid/content/Intent;)V", "Dropbox_normalRelease"}, k = 1, mv = {1, 9, 0}, xi = 48)
  public static final class AppStateInitsKt$registerReceivers$1 extends BaseBroadcastReceiver {
    public final h a;
    
    public final d b;
    
    public final f c;
    
    public AppStateInitsKt$registerReceivers$1(h param1h, d param1d, f param1f) {}
    
    public void onReceive(Context param1Context, Intent param1Intent) {
      s.h(param1Context, "context");
      s.h(param1Intent, "intent");
      super.onReceive(param1Context, param1Intent);
      this.a.f(this.b.N0().a());
      this.c.F();
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\android\appStateX\AppStateInitsKt.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */