package com.dropbox.android.notifications;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.Pair;
import com.dropbox.android.DropboxApplication;
import com.dropbox.android.user.DbxUserManager;
import com.dropbox.android.user.a;
import dbxyzptlk.Ag.a;
import dbxyzptlk.Ag.b;
import dbxyzptlk.Bg.a;
import dbxyzptlk.CC.p;
import dbxyzptlk.CI.a;
import dbxyzptlk.Df.o;
import dbxyzptlk.Ec.a;
import dbxyzptlk.Ec.m;
import dbxyzptlk.Gs.n;
import dbxyzptlk.H5.h;
import dbxyzptlk.J5.a;
import dbxyzptlk.K5.b;
import dbxyzptlk.Ms.b;
import dbxyzptlk.Qa.A;
import dbxyzptlk.Qa.B;
import dbxyzptlk.Qa.C;
import dbxyzptlk.Qa.k;
import dbxyzptlk.Qa.y;
import dbxyzptlk.Qa.z;
import dbxyzptlk.T1.r;
import dbxyzptlk.V1.c;
import dbxyzptlk.Vg.b;
import dbxyzptlk.dk.c0;
import dbxyzptlk.ef.b0;
import dbxyzptlk.hn.a;
import dbxyzptlk.iH.b;
import dbxyzptlk.iH.c;
import dbxyzptlk.kI.a;
import dbxyzptlk.pc.d0;
import dbxyzptlk.sL.a;
import dbxyzptlk.yn.j;
import io.reactivex.android.schedulers.AndroidSchedulers;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

public class f {
  public final Context a;
  
  public final dbxyzptlk.Ec.g b;
  
  public final e c;
  
  public final Object d = new Object();
  
  public final k e;
  
  public final HashMap<String, e> f = new HashMap<>();
  
  public final HashSet<String> g = new HashSet<>();
  
  public final b h = new b();
  
  public f(Context paramContext, dbxyzptlk.Ec.g paramg) {
    paramContext = paramContext.getApplicationContext();
    this.a = paramContext;
    this.b = paramg;
    this.c = new e(this, null);
    this.e = new k(paramContext);
  }
  
  public static String A(String paramString, int paramInt) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramString);
    stringBuilder.append(":");
    stringBuilder.append(paramInt);
    return stringBuilder.toString();
  }
  
  public static Pair<String, Integer> C(String paramString) {
    String[] arrayOfString = paramString.split(":");
    return new Pair(arrayOfString[0], Integer.valueOf(Integer.parseInt(arrayOfString[1])));
  }
  
  public void B(String paramString, g$c paramg$c) {
    if (u(paramString)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Cannot mask ");
      stringBuilder.append(paramg$c.name());
      stringBuilder.append(". Notification controller was destroyed for user ");
      stringBuilder.append(paramString);
      a.d(stringBuilder.toString(), new Object[0]);
      return;
    } 
    q(paramString).l(paramg$c);
    j(paramString, paramg$c);
  }
  
  @SuppressLint({"SwallowedException"})
  public void D(Intent paramIntent, DbxUserManager paramDbxUserManager) {
    a.d d;
    String str = null;
    if (paramIntent != null) {
      d = (a.d)paramIntent.getAction();
    } else {
      d = null;
    } 
    if ("ACTION_NOTIFICATION_ACTED_UPON".equals(d)) {
      StringBuilder stringBuilder;
      dbxyzptlk.Ec.g g1;
      d0 d0;
      String str6 = paramIntent.getStringExtra("EXTRA_NOTIFICATION_NAME");
      String str2 = paramIntent.getStringExtra("EXTRA_NOTIFICAITON_TYPE");
      String str3 = paramIntent.getStringExtra("EXTRA_TARGET_OBJECT_KEY");
      b b2 = b.valueOf(paramIntent.getStringExtra("EXTRA_ACTION"));
      if (b2 != b.TAP_NON_CANCEL) {
        i = 1;
      } else {
        i = 0;
      } 
      String str4 = paramIntent.getStringExtra("EXTRA_NOTIFICATION_TAG");
      String str1 = paramIntent.getStringExtra("EXTRA_RENDER_ID");
      String str5 = paramIntent.getStringExtra("EXTRA_LOGGING_TAG");
      if (paramIntent.getSerializableExtra("EXTRA_BLUENOTE_LOGGING_FIELDS") != null) {
        d = (a.d)paramIntent.getSerializableExtra("EXTRA_BLUENOTE_LOGGING_FIELDS");
      } else {
        d = null;
      } 
      if (paramIntent.hasExtra("EXTRA_USER_ID")) {
        String str7 = paramIntent.getStringExtra("EXTRA_USER_ID");
        if (u(str7)) {
          stringBuilder = new StringBuilder();
          stringBuilder.append("Cannot do action for ");
          stringBuilder.append(str6);
          stringBuilder.append(". Notification controller was destroyed for user ");
          stringBuilder.append(str7);
          a.d(stringBuilder.toString(), new Object[0]);
          return;
        } 
        a a = paramDbxUserManager.a();
        if (a != null) {
          d0 d01 = a.q(str7);
        } else {
          a = null;
        } 
        if (a == null) {
          a.j("Notification acted upon, but cannot find user.", new Object[0]);
          return;
        } 
        dbxyzptlk.Ec.g g2 = p(str7);
        d0 = (d0)a;
        g1 = g2;
      } else {
        g1 = this.b;
        d0 = null;
      } 
      if (d0 != null)
        str = d0.getId(); 
      e e1 = q(str);
      if (i) {
        p.e(stringBuilder.hasExtra("EXTRA_NOTIFICATION_ID"), "Assert failed.");
        i = stringBuilder.getIntExtra("EXTRA_NOTIFICATION_ID", -1);
        if (b2 == b.QUICK_ACTION_CLEAR && Build.VERSION.SDK_INT < 31) {
          r().cancel(e1.i(str6), i);
          this.a.sendBroadcast(new Intent("android.intent.action.CLOSE_SYSTEM_DIALOGS"));
        } 
        if (str4 != null)
          e1.h.remove(str4); 
        e.d(e1, str6, i);
        Object object = e1.e;
        /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
        try {
          if (e1.f.f(str6))
            e1.g.a(str6); 
        } finally {}
        /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
      } 
      if (stringBuilder.hasExtra("EXTRA_PENDING_INTENT")) {
        PendingIntent pendingIntent = (PendingIntent)c.b((Intent)stringBuilder, "EXTRA_PENDING_INTENT", PendingIntent.class);
        try {
          pendingIntent.send();
        } catch (android.app.PendingIntent.CanceledException canceledException) {}
      } 
      long l = stringBuilder.getLongExtra("EXTRA_ACK_NID", -1L);
      int i = l cmp 0L;
      if (i >= 0)
        if (d0 == null) {
          a.j("Notification acked, but no user.", new Object[0]);
        } else {
          d0.i0().b(new long[] { l });
        }  
      m m1 = a.H1(b2.toString().toLowerCase(Locale.US), str6);
      if (str4 != null)
        m1.o("tag", str4); 
      if (i >= 0)
        m1.m("nid", l); 
      m1.i(g1);
      e.b b1 = new e.b(Long.valueOf(l), str1, str2, str3, "loud", Integer.valueOf(0), str5, d);
      m m2 = a.x1();
      b1.recordTo(m2);
      m2.i(g1);
    } 
  }
  
  public void E(String paramString, j paramj) {
    synchronized (this.d) {
      p.e(this.f.containsKey(paramString) ^ true, "Assert failed.");
      HashMap<String, e> hashMap = this.f;
      e e1 = new e();
      this(this, paramString, paramj, null);
      hashMap.put(paramString, e1);
      this.g.remove(paramString);
      return;
    } 
  }
  
  public void F() {
    this.e.d();
  }
  
  public int G(String paramString1, g.b paramb, String paramString2, Long paramLong, String paramString3, a.d paramd, Bundle paramBundle) {
    String str1;
    StringBuilder stringBuilder;
    byte b1;
    boolean bool;
    if (u(paramString1)) {
      stringBuilder = new StringBuilder();
      stringBuilder.append("Cannot show ");
      stringBuilder.append(paramb.name());
      stringBuilder.append(". Notification controller was destroyed for user ");
      stringBuilder.append(paramString1);
      a.d(stringBuilder.toString(), new Object[0]);
      return 0;
    } 
    e e1 = q(paramString1);
    dbxyzptlk.Ec.g g1 = p(paramString1);
    if (stringBuilder != null && e1.h.containsKey(stringBuilder)) {
      b1 = ((Integer)((Pair)e1.h.get(stringBuilder)).second).intValue();
      bool = true;
    } else {
      b1 = -1;
      bool = false;
    } 
    c c = paramb.build(this.a, paramString1, paramBundle);
    if (c == null)
      return 0; 
    String str2 = paramb.getName();
    int i = paramb.getTypeId();
    if (i != -1) {
      str1 = Integer.valueOf(i).toString();
    } else {
      str1 = str2;
    } 
    i = b1;
    if (b1 == -1)
      i = e1.h(); 
    if (stringBuilder != null)
      e1.h.put(stringBuilder, new Pair(str2, Integer.valueOf(i))); 
    n(paramString1, e1, c, str2, str1, paramString3, i, (String)stringBuilder, paramLong, paramd);
    J(paramString1, e1, c, str2, str1, paramString3, i, (String)stringBuilder, paramLong, paramd, bool);
    a.H1("show", str2).o("tag", (String)stringBuilder).i(g1);
    return i;
  }
  
  public boolean H(String paramString, g$c paramg$c, Bundle paramBundle) {
    StringBuilder stringBuilder;
    String str1;
    if (u(paramString)) {
      stringBuilder = new StringBuilder();
      stringBuilder.append("Cannot show ");
      stringBuilder.append(paramg$c.name());
      stringBuilder.append(". Notification controller was destroyed for user ");
      stringBuilder.append(paramString);
      a.d(stringBuilder.toString(), new Object[0]);
      return false;
    } 
    String str2 = paramg$c.getName();
    int i = paramg$c.getTypeId();
    if (i != -1) {
      str1 = Integer.valueOf(i).toString();
    } else {
      str1 = str2;
    } 
    if (paramg$c.isMuteable())
      p.p(paramString, "User ID cannot be null for muteable notifications"); 
    e e1 = q(paramString);
    dbxyzptlk.Ec.g g1 = p(paramString);
    null = (Object<g$c>)e1.e;
    /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
    try {
      if (e1.g.b(str2)) {
        /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
        return false;
      } 
    } finally {}
    if (paramg$c.isMuteable())
      e1.f.a(str2); 
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
    null = (Object<g$c>)e1.i;
    /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object<ObjectType{com/dropbox/android/notifications/g$c}>}, name=null} */
    try {
      if (e1.i.contains(paramg$c)) {
        /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object<ObjectType{com/dropbox/android/notifications/g$c}>}, name=null} */
        return false;
      } 
    } finally {}
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object<ObjectType{com/dropbox/android/notifications/g$c}>}, name=null} */
    i = e1.j();
    synchronized (e.a(e1)) {
      if (paramg$c.isUpdateable() || !e.c(e1, str2, i)) {
        c c = paramg$c.build(this.a, paramString, (Bundle)stringBuilder);
        if (c == null)
          return false; 
        n(paramString, e1, c, str2, str1, "", i, null, null, null);
        I(paramString, e1, c, str2, str1, "", i, null, null, null);
        a.H1("show", str2).i(g1);
        return true;
      } 
      return false;
    } 
  }
  
  public final void I(String paramString1, e parame, c paramc, String paramString2, String paramString3, String paramString4, int paramInt, String paramString5, Long paramLong, a.d paramd) {
    J(paramString1, parame, paramc, paramString2, paramString3, paramString4, paramInt, paramString5, paramLong, paramd, false);
  }
  
  public final void J(String paramString1, e parame, c paramc, String paramString2, String paramString3, String paramString4, int paramInt, String paramString5, Long paramLong, a.d paramd, boolean paramBoolean) {
    b b1;
    String str = UUID.randomUUID().toString();
    Notification notification = paramc.M(this, paramString1, paramString2, paramString3, paramString4, paramInt, paramString5, paramLong, str, paramd, paramBoolean);
    if (notification == null)
      return; 
    if ((notification.flags & 0x10) != 0) {
      b1 = b.TAP_AUTO_CANCEL;
    } else {
      b1 = b.TAP_NON_CANCEL;
    } 
    Intent intent = m(notification.contentIntent, paramString1, paramString2, paramString3, paramString4, paramInt, paramString5, paramLong, str, b1, "surface", paramd);
    notification.contentIntent = c0.a(this.a, intent);
    notification.deleteIntent = c0.a(this.a, m(notification.deleteIntent, paramString1, paramString2, paramString3, paramString4, paramInt, paramString5, paramLong, str, b.DISMISSED, "dismiss", paramd));
    NotificationManager notificationManager = r();
    if (!paramBoolean || v(paramString2, paramInt)) {
      notificationManager.notify(parame.i(paramString2), paramInt, notification);
      e.e(parame, paramString2, paramInt, intent);
      if (!paramBoolean) {
        e.b b2 = new e.b(paramLong, str, paramString3, paramString4, "loud", Integer.valueOf(0), paramd);
        m m = a.F1();
        b2.recordTo(m);
        if (r.e(this.a).a())
          m.i(p(paramString1)); 
      } 
      return;
    } 
  }
  
  public void K(String paramString, g$c paramg$c) {
    if (u(paramString)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Cannot unmask ");
      stringBuilder.append(paramg$c.name());
      stringBuilder.append(". Notification controller was destroyed for user ");
      stringBuilder.append(paramString);
      a.d(stringBuilder.toString(), new Object[0]);
      return;
    } 
    q(paramString).o(paramg$c);
  }
  
  public void j(String paramString, g$c paramg$c) {
    if (u(paramString)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Cannot clear ");
      stringBuilder.append(paramg$c.name());
      stringBuilder.append(". Notification controller was destroyed for user ");
      stringBuilder.append(paramString);
      a.d(stringBuilder.toString(), new Object[0]);
      return;
    } 
    if (paramg$c.isMuteable())
      p.p(paramString, "User ID cannot be null for muteable notifications"); 
    e e1 = q(paramString);
    String str = paramg$c.getName();
    s(e1, str, e1.j());
    e.f(e1, str);
  }
  
  public void k(String paramString1, String paramString2) {
    if (u(paramString1)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Cannot clear ");
      stringBuilder.append(paramString2);
      stringBuilder.append(". Notification controller was destroyed for user ");
      stringBuilder.append(paramString1);
      a.d(stringBuilder.toString(), new Object[0]);
      return;
    } 
    e e1 = q(paramString1);
    Pair pair = e1.h.remove(paramString2);
    if (pair != null)
      s(e1, (String)pair.first, ((Integer)pair.second).intValue()); 
  }
  
  public void l(d0 paramd0) {
    null = paramd0.getId();
    synchronized (this.d) {
      this.g.add(null);
      e e1 = this.f.remove(null);
      if (e1 != null)
        e.b(e1); 
      return;
    } 
  }
  
  public final Intent m(PendingIntent paramPendingIntent, String paramString1, String paramString2, String paramString3, String paramString4, int paramInt, String paramString5, Long paramLong, String paramString6, b paramb, String paramString7, a.d paramd) {
    Intent intent = new Intent(this.a, SystemTrayNotificationTrampolineActivity.class);
    intent.setAction("ACTION_NOTIFICATION_ACTED_UPON");
    intent.putExtra("EXTRA_NOTIFICATION_NAME", paramString2);
    intent.putExtra("EXTRA_NOTIFICAITON_TYPE", paramString3);
    intent.putExtra("EXTRA_TARGET_OBJECT_KEY", paramString4);
    intent.putExtra("EXTRA_NOTIFICATION_ID", paramInt);
    intent.putExtra("EXTRA_RENDER_ID", paramString6);
    intent.putExtra("EXTRA_ACTION", paramb.toString());
    intent.putExtra("EXTRA_LOGGING_TAG", paramString7);
    if (paramPendingIntent != null)
      intent.putExtra("EXTRA_PENDING_INTENT", (Parcelable)paramPendingIntent); 
    if (paramString1 != null)
      intent.putExtra("EXTRA_USER_ID", paramString1); 
    if (paramString5 != null)
      intent.putExtra("EXTRA_NOTIFICATION_TAG", paramString5); 
    if (paramLong != null)
      intent.putExtra("EXTRA_ACK_NID", paramLong.longValue()); 
    if (paramd != null)
      intent.putExtra("EXTRA_BLUENOTE_LOGGING_FIELDS", (Serializable)paramd); 
    return intent;
  }
  
  public final void n(String paramString1, e parame, c paramc, String paramString2, String paramString3, String paramString4, int paramInt, String paramString5, Long paramLong, a.d paramd) {
    if (paramc.N() != null && paramc.O() != null) {
      d0 d0 = DropboxApplication.b1(this.a).a().q(paramString1);
      if (d0 == null)
        return; 
      y y = new y(this, paramc);
      z z = new z(this, paramString1, parame, paramc, paramString2, paramString3, paramString4, paramInt, paramString5, paramLong, paramd);
      c c1 = d0.e2().a(c.K(paramc)).J(a.c()).z(AndroidSchedulers.a()).H((dbxyzptlk.lH.g)new A(this, d0, (a)y, paramc, (Runnable)z), (dbxyzptlk.lH.g)new B((a)y, paramc, (Runnable)z));
      this.h.a(c1);
    } 
  }
  
  public final Iterable<e> o() {
    synchronized (this.d) {
      ArrayList<e> arrayList = new ArrayList();
      this((Collection)this.f.values());
      arrayList.add(this.c);
      return arrayList;
    } 
  }
  
  public final dbxyzptlk.Ec.g p(String paramString) {
    return (dbxyzptlk.Ec.g)((paramString != null) ? b0.d(this.b, paramString) : this.b);
  }
  
  public final e q(String paramString) {
    if (paramString != null)
      synchronized (this.d) {
        e e1 = this.f.get(paramString);
        p.o(e1);
        return e1;
      }  
    return this.c;
  }
  
  public NotificationManager r() {
    return (NotificationManager)this.a.getSystemService("notification");
  }
  
  public final void s(e parame, String paramString, int paramInt) {
    r().cancel(parame.i(paramString), paramInt);
    e.d(parame, paramString, paramInt);
  }
  
  public void t() {
    this.e.b();
  }
  
  public final boolean u(String paramString) {
    Object object = this.d;
    /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
    if (paramString != null)
      try {
        if (this.g.contains(paramString)) {
          boolean bool1 = true;
          /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
          return bool1;
        } 
      } finally {} 
    boolean bool = false;
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
    return bool;
  }
  
  public boolean v(String paramString, int paramInt) {
    Iterator<e> iterator = o().iterator();
    while (iterator.hasNext()) {
      if (e.c(iterator.next(), paramString, paramInt))
        return true; 
    } 
    return false;
  }
  
  class f {}
  
  class f {}
  
  public static class d extends g {
    public final j b;
    
    public d(j param1j) {
      this.b = param1j;
      e();
    }
    
    public String d() {
      j j1 = this.b;
      return (j1 != null) ? j1.e1() : null;
    }
    
    public void g(String param1String) {
      j j1 = this.b;
      if (j1 != null)
        j1.D1(param1String); 
    }
  }
  
  public static class e {
    public final AtomicInteger a = new AtomicInteger(1);
    
    public final f b;
    
    public final String c;
    
    public final Map<String, Intent> d = new HashMap<>();
    
    public final Object e = new Object();
    
    public final f.g f;
    
    public final f.g g;
    
    public final ConcurrentHashMap<String, Pair<String, Integer>> h = new ConcurrentHashMap<>();
    
    public final EnumSet<g$c> i = EnumSet.noneOf(g$c.class);
    
    public e(f param1f) {
      this(param1f, null, null);
    }
    
    public e(f param1f, String param1String, j param1j) {
      this.b = param1f;
      if (param1String != null) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("u");
        stringBuilder.append(param1String);
        this.c = stringBuilder.toString();
      } else {
        this.c = "no_user";
      } 
      this.f = new f.f(param1j);
      this.g = new f.d(param1j);
    }
    
    public final void g() {
      for (String str : this.h.keySet()) {
        Pair pair = this.h.remove(str);
        if (pair != null)
          f.g(this.b, this, (String)pair.first, ((Integer)pair.second).intValue()); 
      } 
      Map<String, Intent> map = this.d;
      /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{java/util/Map<[ObjectType{java/lang/String}, ObjectType{android/content/Intent}]>}, name=null} */
      try {
        HashSet hashSet = new HashSet();
        this((Collection)this.d.keySet());
        Iterator<String> iterator = hashSet.iterator();
        while (iterator.hasNext()) {
          Pair pair = f.i(iterator.next());
          f.g(this.b, this, (String)pair.first, ((Integer)pair.second).intValue());
          if (((Integer)pair.second).intValue() == j())
            p((String)pair.first); 
        } 
      } finally {
        Exception exception;
      } 
      /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/util/Map<[ObjectType{java/lang/String}, ObjectType{android/content/Intent}]>}, name=null} */
    }
    
    public int h() {
      return this.a.getAndIncrement();
    }
    
    public String i(String param1String) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(this.c);
      stringBuilder.append(":");
      stringBuilder.append(param1String);
      return stringBuilder.toString();
    }
    
    public int j() {
      return 1;
    }
    
    public final boolean k(String param1String, int param1Int) {
      synchronized (this.d) {
        return this.d.containsKey(f.h(param1String, param1Int));
      } 
    }
    
    public void l(g$c param1g$c) {
      synchronized (this.i) {
        p.e(this.i.add(param1g$c), "Assert failed.");
        return;
      } 
    }
    
    public final void m(String param1String, int param1Int) {
      synchronized (this.d) {
        this.d.remove(f.h(param1String, param1Int));
        return;
      } 
    }
    
    public final void n(String param1String, int param1Int, Intent param1Intent) {
      synchronized (this.d) {
        this.d.put(f.h(param1String, param1Int), param1Intent);
        return;
      } 
    }
    
    public void o(g$c param1g$c) {
      synchronized (this.i) {
        p.e(this.i.remove(param1g$c), "Assert failed.");
        return;
      } 
    }
    
    public final void p(String param1String) {
      synchronized (this.e) {
        this.g.f(param1String);
        this.f.f(param1String);
        return;
      } 
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("tagPrefix: ");
      stringBuilder.append(this.c);
      stringBuilder.append("; toMute: ");
      stringBuilder.append(this.f);
      stringBuilder.append("; muted: ");
      stringBuilder.append(this.g);
      return stringBuilder.toString();
    }
  }
  
  public static class f extends g {
    public final j b;
    
    public f(j param1j) {
      this.b = param1j;
      e();
    }
    
    public String d() {
      j j1 = this.b;
      return (j1 != null) ? j1.f1() : null;
    }
    
    public void g(String param1String) {
      j j1 = this.b;
      if (j1 != null)
        j1.G1(param1String); 
    }
  }
  
  public static abstract class g {
    public final HashSet<String> a = new HashSet<>();
    
    public g() {
      e();
    }
    
    public final boolean a(String param1String) {
      boolean bool = this.a.add(param1String);
      if (bool)
        c(); 
      return bool;
    }
    
    public final boolean b(String param1String) {
      return this.a.contains(param1String);
    }
    
    public final void c() {
      g(TextUtils.join("|", this.a));
    }
    
    public abstract String d();
    
    public void e() {
      String str = d();
      this.a.clear();
      if (str != null) {
        String[] arrayOfString = TextUtils.split(str, "\\|");
        Collections.addAll(this.a, arrayOfString);
      } 
    }
    
    public final boolean f(String param1String) {
      boolean bool = this.a.remove(param1String);
      if (bool)
        c(); 
      return bool;
    }
    
    public abstract void g(String param1String);
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\android\notifications\f.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */