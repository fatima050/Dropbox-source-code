package com.dropbox.android;

import android.app.Application;
import android.content.Context;
import androidx.lifecycle.DefaultLifecycleObserver;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.ProcessLifecycleOwner;
import androidx.work.a;
import com.dropbox.android.filemanager.ApiManager;
import com.dropbox.android.notifications.f;
import com.dropbox.android.service.InstallReferrerWorker;
import com.dropbox.android.user.DbxUserManager;
import com.dropbox.android.user.a;
import com.dropbox.common.lock_screen.LockReceiver;
import com.dropbox.common.skeleton.core.BaseSkeletonApplication;
import com.dropbox.product.dbapp.common.service.ApiService;
import com.dropbox.product.dbapp.downloadmanager.b;
import com.dropbox.product.dbapp.path.SharedLinkPath;
import dbxyzptlk.A9.f;
import dbxyzptlk.C8.g;
import dbxyzptlk.DI.s;
import dbxyzptlk.Dx.a;
import dbxyzptlk.Dx.d;
import dbxyzptlk.Dx.e;
import dbxyzptlk.Dx.f;
import dbxyzptlk.Ec.g;
import dbxyzptlk.Ec.h;
import dbxyzptlk.Ec.i;
import dbxyzptlk.Ec.q;
import dbxyzptlk.Fc.M;
import dbxyzptlk.Fc.O;
import dbxyzptlk.Fe.b;
import dbxyzptlk.Fq.p;
import dbxyzptlk.Fr.b;
import dbxyzptlk.Ft.c;
import dbxyzptlk.Hy.c;
import dbxyzptlk.Ij.s;
import dbxyzptlk.Ja.j;
import dbxyzptlk.Kk.e;
import dbxyzptlk.Kt.f;
import dbxyzptlk.Kt.g;
import dbxyzptlk.La.b;
import dbxyzptlk.Lr.b;
import dbxyzptlk.Lu.b;
import dbxyzptlk.Nh.b;
import dbxyzptlk.Nh.d;
import dbxyzptlk.Nk.b;
import dbxyzptlk.Oa.c;
import dbxyzptlk.Ow.g;
import dbxyzptlk.Sq.k;
import dbxyzptlk.Tr.b;
import dbxyzptlk.U2.h;
import dbxyzptlk.Vv.b;
import dbxyzptlk.Vv.g;
import dbxyzptlk.W6.d;
import dbxyzptlk.W6.x;
import dbxyzptlk.Xs.G;
import dbxyzptlk.Xs.K;
import dbxyzptlk.Xs.f0;
import dbxyzptlk.Xs.q;
import dbxyzptlk.Zs.i;
import dbxyzptlk.Zs.k;
import dbxyzptlk.Zu.e;
import dbxyzptlk.af.b;
import dbxyzptlk.av.e;
import dbxyzptlk.av.f;
import dbxyzptlk.bh.b;
import dbxyzptlk.df.b;
import dbxyzptlk.e5.n;
import dbxyzptlk.e5.x;
import dbxyzptlk.e5.y;
import dbxyzptlk.ef.E;
import dbxyzptlk.iy.A;
import dbxyzptlk.jf.b;
import dbxyzptlk.jf.o;
import dbxyzptlk.jf.u;
import dbxyzptlk.lf.k;
import dbxyzptlk.mi.c;
import dbxyzptlk.no.f;
import dbxyzptlk.ns.b;
import dbxyzptlk.oj.c;
import dbxyzptlk.ok.b;
import dbxyzptlk.pI.D;
import dbxyzptlk.pc.d0;
import dbxyzptlk.pf.g;
import dbxyzptlk.pj.m;
import dbxyzptlk.ps.d;
import dbxyzptlk.ps.f;
import dbxyzptlk.rc.b;
import dbxyzptlk.rk.e;
import dbxyzptlk.sc.C;
import dbxyzptlk.sh.g;
import dbxyzptlk.u9.b;
import dbxyzptlk.un.g;
import dbxyzptlk.uw.d;
import dbxyzptlk.uw.e;
import dbxyzptlk.vx.t;
import dbxyzptlk.w6.I0;
import dbxyzptlk.w6.c;
import dbxyzptlk.wb.e;
import dbxyzptlk.wb.g;
import dbxyzptlk.wc.d;
import dbxyzptlk.xx.g;
import dbxyzptlk.ye.A;
import dbxyzptlk.ye.C0;
import dbxyzptlk.ye.Y;
import dbxyzptlk.ye.b0;
import dbxyzptlk.ye.f0;
import dbxyzptlk.yj.c;
import dbxyzptlk.za.d;
import dbxyzptlk.zb.f0;
import dbxyzptlk.zj.s;
import dbxyzptlk.zv.l;
import dbxyzptlk.zv.m;
import io.sentry.android.core.performance.e;
import java.util.concurrent.ExecutorService;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

@Metadata(d1 = {"\000 \003\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\000\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\004\n\002\020\013\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\007\n\002\030\002\n\002\b\007\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\006\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\005\b\027\030\000 ¤\0012\0020\0012\0020\0022\0020\0032\0020\0042\0020\0052\0020\0052\0020\0052\0020\0062\0020\0072\0020\b2\0020\t2\0020\n2\0020\0132\0020\f2\0020\r2\0020\0162\0020\0172\0020\0202\0020\0212\0020\0222\0020\0232\0020\0242\0020\0252\0020\0262\0020\0272\0020\0302\0020\005:\002¿\001B\007¢\006\004\b\031\020\032J\017\020\034\032\0020\033H\002¢\006\004\b\034\020\032J\017\020\035\032\0020\033H\002¢\006\004\b\035\020\032J\027\020 \032\0020\0332\006\020\037\032\0020\036H\024¢\006\004\b \020!J\017\020\"\032\0020\033H\026¢\006\004\b\"\020\032J\027\020%\032\0020\0332\006\020$\032\0020#H\026¢\006\004\b%\020&J\027\020'\032\0020\0332\006\020$\032\0020#H\026¢\006\004\b'\020&J\017\020)\032\0020(H\026¢\006\004\b)\020*J\r\020,\032\0020+¢\006\004\b,\020-J\017\020/\032\0020.H\026¢\006\004\b/\0200J\017\0202\032\00201H\026¢\006\004\b2\0203J\017\0205\032\00204H\026¢\006\004\b5\0206J\017\0208\032\00207H\026¢\006\004\b8\0209R(\020A\032\b\022\004\022\0020+0:8\006@\006X.¢\006\022\n\004\b;\020<\032\004\b=\020>\"\004\b?\020@R\"\020I\032\0020B8\006@\006X.¢\006\022\n\004\bC\020D\032\004\bE\020F\"\004\bG\020HR\024\020M\032\0020J8BX\004¢\006\006\032\004\bK\020LR\024\020Q\032\0020N8BX\004¢\006\006\032\004\bO\020PR\024\020U\032\0020R8BX\004¢\006\006\032\004\bS\020TR\024\020Y\032\0020V8BX\004¢\006\006\032\004\bW\020XR\024\020]\032\0020Z8BX\004¢\006\006\032\004\b[\020\\R\024\020a\032\0020^8BX\004¢\006\006\032\004\b_\020`R\024\020e\032\0020b8BX\004¢\006\006\032\004\bc\020dR\021\020i\032\0020f8F¢\006\006\032\004\bg\020hR\024\020m\032\0020j8VX\004¢\006\006\032\004\bk\020lR\021\020q\032\0020n8F¢\006\006\032\004\bo\020pR\024\020u\032\0020r8VX\004¢\006\006\032\004\bs\020tR\024\020y\032\0020v8VX\004¢\006\006\032\004\bw\020xR\024\020}\032\0020z8VX\004¢\006\006\032\004\b{\020|R\025\020\001\032\0020~8VX\004¢\006\006\032\004\bC\020R\037\020\001\032\0030\0018VX\004¢\006\017\022\005\b\001\020\032\032\006\b\001\020\001R\030\020\001\032\0030\0018VX\004¢\006\b\032\006\b\001\020\001R\030\020\001\032\0030\0018VX\004¢\006\b\032\006\b\001\020\001R\030\020\001\032\0030\0018VX\004¢\006\b\032\006\b\001\020\001R\030\020\001\032\0030\0018VX\004¢\006\b\032\006\b\001\020\001R\035\020\001\032\0020J8VX\004¢\006\016\022\005\b\001\020\032\032\005\b\001\020LR\037\020\001\032\0030\0018VX\004¢\006\017\022\005\b\001\020\032\032\006\b\001\020\001R\037\020¢\001\032\0030\0018VX\004¢\006\017\022\005\b¡\001\020\032\032\006\b\001\020 \001R\030\020¦\001\032\0030£\0018VX\004¢\006\b\032\006\b¤\001\020¥\001R\030\020ª\001\032\0030§\0018VX\004¢\006\b\032\006\b¨\001\020©\001R\030\020®\001\032\0030«\0018VX\004¢\006\b\032\006\b¬\001\020­\001R\030\020²\001\032\0030¯\0018VX\004¢\006\b\032\006\b°\001\020±\001R\030\020¶\001\032\0030³\0018VX\004¢\006\b\032\006\b´\001\020µ\001R\025\020º\001\032\0030·\0018F¢\006\b\032\006\b¸\001\020¹\001R\030\020¾\001\032\0030»\0018VX\004¢\006\b\032\006\b¼\001\020½\001¨\006À\001"}, d2 = {"Lcom/dropbox/android/DropboxApplication;", "Lcom/dropbox/common/skeleton/core/BaseSkeletonApplication;", "Ldbxyzptlk/bh/b;", "Ldbxyzptlk/Ec/h;", "Ldbxyzptlk/ps/f;", "", "Ldbxyzptlk/jf/o;", "Ldbxyzptlk/Nh/b;", "Ldbxyzptlk/Kt/g;", "Landroidx/lifecycle/DefaultLifecycleObserver;", "Ldbxyzptlk/wb/g;", "Ldbxyzptlk/Lr/b;", "Ldbxyzptlk/Tr/b;", "Ldbxyzptlk/zv/m;", "Ldbxyzptlk/uw/e;", "Ldbxyzptlk/af/b;", "Ldbxyzptlk/Zs/k;", "Ldbxyzptlk/av/f;", "Landroidx/work/a$c;", "Ldbxyzptlk/Vv/b;", "Ldbxyzptlk/rk/e;", "Ldbxyzptlk/Dx/a;", "Ldbxyzptlk/Dx/e;", "Ldbxyzptlk/Dx/f;", "Ldbxyzptlk/Dx/d;", "<init>", "()V", "Ldbxyzptlk/pI/D;", "f1", "e1", "Landroid/content/Context;", "base", "attachBaseContext", "(Landroid/content/Context;)V", "onCreate", "Landroidx/lifecycle/LifecycleOwner;", "owner", "onStop", "(Landroidx/lifecycle/LifecycleOwner;)V", "onStart", "", "b", "()Z", "Ldbxyzptlk/w6/I0;", "l0", "()Ldbxyzptlk/w6/I0;", "Ldbxyzptlk/Ft/c;", "g1", "()Ldbxyzptlk/Ft/c;", "Ldbxyzptlk/zj/s;", "B", "()Ldbxyzptlk/zj/s;", "Landroidx/work/a;", "w", "()Landroidx/work/a;", "Ldbxyzptlk/bh/a;", "q", "()Ldbxyzptlk/bh/a;", "Ldbxyzptlk/oI/a;", "f", "Ldbxyzptlk/oI/a;", "k0", "()Ldbxyzptlk/oI/a;", "setDropboxApplicationProviders", "(Ldbxyzptlk/oI/a;)V", "dropboxApplicationProviders", "Ldbxyzptlk/kf/a;", "g", "Ldbxyzptlk/kf/a;", "Y", "()Ldbxyzptlk/kf/a;", "setCrashReportingManager", "(Ldbxyzptlk/kf/a;)V", "crashReportingManager", "Ldbxyzptlk/Ec/g;", "a0", "()Ldbxyzptlk/Ec/g;", "defaultEventLogger", "Ldbxyzptlk/ef/E;", "y0", "()Ldbxyzptlk/ef/E;", "legacyPerfTracer", "Ldbxyzptlk/Xs/f0;", "Q0", "()Ldbxyzptlk/Xs/f0;", "sharedLinkLocalStorage", "Ldbxyzptlk/Xs/G;", "o0", "()Ldbxyzptlk/Xs/G;", "externalLocalStorage", "Ldbxyzptlk/Xs/K;", "r0", "()Ldbxyzptlk/Xs/K;", "globalExternalStorage", "Ldbxyzptlk/iy/A;", "R0", "()Ldbxyzptlk/iy/A;", "sharedLinkMetadataManager", "Ldbxyzptlk/A9/f;", "M0", "()Ldbxyzptlk/A9/f;", "shareLinkDownloadService", "Lcom/dropbox/android/user/DbxUserManager;", "a1", "()Lcom/dropbox/android/user/DbxUserManager;", "userManager", "Ldbxyzptlk/ye/C0;", "z", "()Ldbxyzptlk/ye/C0;", "systemTimeSource", "Ldbxyzptlk/ye/f0;", "f0", "()Ldbxyzptlk/ye/f0;", "devicePolicyHelper", "Ldbxyzptlk/zv/l;", "m2", "()Ldbxyzptlk/zv/l;", "passwordsLauncher", "Ldbxyzptlk/Zs/i;", "c", "()Ldbxyzptlk/Zs/i;", "dropboxDocumentProviderComponent", "Ldbxyzptlk/Vv/g;", "j", "()Ldbxyzptlk/Vv/g;", "services", "Ldbxyzptlk/jf/b;", "()Ldbxyzptlk/jf/b;", "contextComponent", "Ldbxyzptlk/Nh/d;", "R", "()Ldbxyzptlk/Nh/d;", "getLocalizationComponent$annotations", "localizationComponent", "Ldbxyzptlk/Lr/a;", "i", "()Ldbxyzptlk/Lr/a;", "accountAvatarComponent", "Ldbxyzptlk/Tr/a;", "e", "()Ldbxyzptlk/Tr/a;", "activationModulesComponent", "Ldbxyzptlk/ps/d;", "o", "()Ldbxyzptlk/ps/d;", "cloudDocsComponent", "Ldbxyzptlk/Kt/f;", "d", "()Ldbxyzptlk/Kt/f;", "fileLockingComponent", "m", "getAnalyticsLogger$annotations", "analyticsLogger", "Ldbxyzptlk/pf/g;", "H", "()Ldbxyzptlk/pf/g;", "getPermissionManager$annotations", "permissionManager", "Ldbxyzptlk/oj/c;", "t", "()Ldbxyzptlk/oj/c;", "getSafeIntentStarter$annotations", "safeIntentStarter", "Ldbxyzptlk/av/e;", "h", "()Ldbxyzptlk/av/e;", "linkNodesComponent", "Ldbxyzptlk/uw/d;", "s", "()Ldbxyzptlk/uw/d;", "sharedContentMemberListComponent", "Ldbxyzptlk/wb/e;", "u", "()Ldbxyzptlk/wb/e;", "sharedLinkReceiverFlowComponent", "Ldbxyzptlk/Ec/i;", "v", "()Ldbxyzptlk/Ec/i;", "analyticsSdk", "Ldbxyzptlk/ye/Y;", "c0", "()Ldbxyzptlk/ye/Y;", "deviceComponent", "Ldbxyzptlk/W6/x;", "W", "()Ldbxyzptlk/W6/x;", "cameraUploadsManager", "Ldbxyzptlk/lf/k;", "m0", "()Ldbxyzptlk/lf/k;", "emmHelper", "a", "Dropbox_normalRelease"}, k = 1, mv = {1, 9, 0}, xi = 48)
public class DropboxApplication extends BaseSkeletonApplication implements b, h, f, o, b, g, DefaultLifecycleObserver, g, b, b, m, e, b, k, f, a.c, b, e, a, e, f, d {
  public static final a h = new a(null);
  
  public static final int i = 8;
  
  public static final Object j = new Object();
  
  public static boolean k;
  
  public dbxyzptlk.oI.a<I0> f;
  
  public dbxyzptlk.kf.a g;
  
  public static final u A0(Context paramContext) {
    return h.K(paramContext);
  }
  
  public static final t B0(Context paramContext) {
    return h.L(paramContext);
  }
  
  public static final LockReceiver C0(Context paramContext) {
    return h.M(paramContext);
  }
  
  public static final m D0(Context paramContext) {
    return h.N(paramContext);
  }
  
  public static final g E0(Context paramContext) {
    return h.O(paramContext);
  }
  
  public static final g F0(Context paramContext) {
    return h.P(paramContext);
  }
  
  public static final c G0(Context paramContext) {
    return h.Q(paramContext);
  }
  
  public static final dbxyzptlk.vv.a H0(Context paramContext) {
    return h.R(paramContext);
  }
  
  public static final d I0(Context paramContext) {
    return h.T(paramContext);
  }
  
  public static final c J0(Context paramContext) {
    return h.U(paramContext);
  }
  
  public static final g K0(Context paramContext) {
    return h.V(paramContext);
  }
  
  public static final c L0(Context paramContext) {
    return h.W(paramContext);
  }
  
  public static final f0 N0(Context paramContext) {
    return h.Z(paramContext);
  }
  
  public static final b O0(Context paramContext) {
    return h.c0(paramContext);
  }
  
  public static final j P0(Context paramContext) {
    return h.d0(paramContext);
  }
  
  public static final b S(Context paramContext) {
    return h.b(paramContext);
  }
  
  public static final A S0(Context paramContext) {
    return h.g0(paramContext);
  }
  
  public static final ApiManager T(Context paramContext) {
    return h.d(paramContext);
  }
  
  public static final dbxyzptlk.iz.a T0(Context paramContext) {
    return h.h0(paramContext);
  }
  
  public static final Application U(Context paramContext) {
    return h.e(paramContext);
  }
  
  public static final g<SharedLinkPath> U0(Context paramContext) {
    return h.j0(paramContext);
  }
  
  public static final d V(Context paramContext) {
    return h.f(paramContext);
  }
  
  public static final q V0(Context paramContext) {
    return h.k0(paramContext);
  }
  
  public static final C0 W0(Context paramContext) {
    return h.l0(paramContext);
  }
  
  public static final x X(Context paramContext) {
    return h.g(paramContext);
  }
  
  public static final f X0(Context paramContext) {
    return h.m0(paramContext);
  }
  
  public static final s Y0(Context paramContext) {
    return h.n0(paramContext);
  }
  
  public static final b Z(Context paramContext) {
    return h.k(paramContext);
  }
  
  public static final b Z0(Context paramContext) {
    return h.p0(paramContext);
  }
  
  public static final g b0(Context paramContext) {
    return h.l(paramContext);
  }
  
  public static final DbxUserManager b1(Context paramContext) {
    return h.q0(paramContext);
  }
  
  public static final p c1(Context paramContext) {
    return h.r0(paramContext);
  }
  
  public static final b0 d0(Context paramContext) {
    return h.m(paramContext);
  }
  
  public static final boolean d1(Context paramContext) {
    return h.s0(paramContext);
  }
  
  public static final dbxyzptlk.Za.a e0(Context paramContext) {
    return h.n(paramContext);
  }
  
  public static final f0 g0(Context paramContext) {
    return h.o(paramContext);
  }
  
  public static final k h0(Context paramContext) {
    return h.p(paramContext);
  }
  
  public static final void h1() {
    h.t0();
  }
  
  public static final q i0(Context paramContext) {
    return h.q(paramContext);
  }
  
  public static final e j0(Context paramContext) {
    return h.r(paramContext);
  }
  
  public static final k n0(Context paramContext) {
    return h.u(paramContext);
  }
  
  public static final G p0(Context paramContext) {
    return h.w(paramContext);
  }
  
  public static final f q0(Context paramContext) {
    return h.z(paramContext);
  }
  
  public static final g s0(Context paramContext) {
    return h.B(paramContext);
  }
  
  public static final g t0(Context paramContext) {
    return h.C(paramContext);
  }
  
  public static final String u0(Context paramContext) {
    return h.D(paramContext);
  }
  
  public static final C v0(Context paramContext) {
    return h.E(paramContext);
  }
  
  public static final dbxyzptlk.Cg.a w0(Context paramContext) {
    return h.F(paramContext);
  }
  
  public static final b x0(Context paramContext) {
    return h.G(paramContext);
  }
  
  private final E y0() {
    h.t0();
    return l0().h0();
  }
  
  public static final E z0(Context paramContext) {
    return h.I(paramContext);
  }
  
  public s B() {
    return a.c().a(this);
  }
  
  public g H() {
    return l0().H();
  }
  
  public final f M0() {
    h.t0();
    return l0().j0();
  }
  
  public final f0 Q0() {
    return l0().Y().K1();
  }
  
  public d R() {
    return l0().R();
  }
  
  public final A R0() {
    h.t0();
    return l0().m0();
  }
  
  public final x W() {
    return l0().n();
  }
  
  public final dbxyzptlk.kf.a Y() {
    dbxyzptlk.kf.a a1 = this.g;
    if (a1 != null)
      return a1; 
    s.u("crashReportingManager");
    return null;
  }
  
  public final g a0() {
    h.t0();
    return m();
  }
  
  public final DbxUserManager a1() {
    h.t0();
    return l0().a();
  }
  
  public void attachBaseContext(Context paramContext) {
    s.h(paramContext, "base");
    super.attachBaseContext(paramContext);
    dbxyzptlk.o4.a.l((Context)this);
  }
  
  public boolean b() {
    return false;
  }
  
  public i c() {
    h.t0();
    return l0().c();
  }
  
  public Y c0() {
    return l0().f0();
  }
  
  public f d() {
    return l0().d();
  }
  
  public dbxyzptlk.Tr.a e() {
    return l0().e();
  }
  
  public final void e1() {
    synchronized (j) {
      k = true;
      null.notifyAll();
      D d1 = D.a;
      return;
    } 
  }
  
  public final f0 f0() {
    return c0().U1();
  }
  
  public final void f1() {
    if (l0().W().L()) {
      x x = ((n.a)(new n.a(InstallReferrerWorker.class)).a("InstallReferrerWork")).b();
      l0().l().d(x);
      l0().W().x0(false);
    } else {
      l0().V().c();
    } 
  }
  
  public b g() {
    return l0().g();
  }
  
  public c g1() {
    return l0().X();
  }
  
  public e h() {
    return l0().h();
  }
  
  public dbxyzptlk.Lr.a i() {
    return l0().i();
  }
  
  public g j() {
    a a1 = a1().a();
    s.e(a1);
    d0 d0 = a1.h();
    s.e(d0);
    return (g)new d(d0);
  }
  
  public final dbxyzptlk.oI.a<I0> k0() {
    dbxyzptlk.oI.a<I0> a1 = this.f;
    if (a1 != null)
      return a1; 
    s.u("dropboxApplicationProviders");
    return null;
  }
  
  public final I0 l0() {
    Object object = k0().get();
    s.g(object, "get(...)");
    return (I0)object;
  }
  
  public g m() {
    return l0().m();
  }
  
  public k m0() {
    return l0().x();
  }
  
  public l m2() {
    return l0().Q().m2();
  }
  
  public d o() {
    return l0().o();
  }
  
  public final G o0() {
    return l0().Y().J1();
  }
  
  public void onCreate() {
    e.r((Application)this);
    super.onCreate();
    ((c)c.b((Context)this, c.class, c.e((Context)this), false)).o1(this);
    dbxyzptlk.Dc.a.a(l0().a().a(), (p)this);
    e1();
    Y().g();
    f1();
    ProcessLifecycleOwner.i.a().getLifecycle().a((h)this);
    e.s((Application)this);
  }
  
  public void onStart(LifecycleOwner paramLifecycleOwner) {
    s.h(paramLifecycleOwner, "owner");
    dbxyzptlk.Ec.a.e().i(m());
    (new O()).k("dbapp").g(m());
  }
  
  public void onStop(LifecycleOwner paramLifecycleOwner) {
    s.h(paramLifecycleOwner, "owner");
    (new M()).k("dbapp").g(m());
  }
  
  public dbxyzptlk.bh.a q() {
    return (dbxyzptlk.bh.a)l0().q();
  }
  
  public final K r0() {
    return l0().Y().I1();
  }
  
  public d s() {
    return l0().s();
  }
  
  public c t() {
    return l0().t();
  }
  
  public e u() {
    return l0().u();
  }
  
  public i v() {
    return l0().v();
  }
  
  public a w() {
    a a1 = (new a.b()).b(120700000, 120701000).c((y)l0().j()).a();
    s.g(a1, "build(...)");
    return a1;
  }
  
  public C0 z() {
    return c0().z();
  }
  
  @Metadata(d1 = {"\000Ü\004\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\020\016\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\020\013\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\027\020\007\032\0020\0062\006\020\005\032\0020\004H\002¢\006\004\b\007\020\bJ\027\020\n\032\0020\t2\006\020\005\032\0020\004H\002¢\006\004\b\n\020\013J\027\020\r\032\0020\f2\006\020\005\032\0020\004H\002¢\006\004\b\r\020\016J\017\020\020\032\0020\017H\007¢\006\004\b\020\020\003J\027\020\022\032\0020\0212\006\020\005\032\0020\004H\007¢\006\004\b\022\020\023J\027\020\025\032\0020\0242\006\020\005\032\0020\004H\007¢\006\004\b\025\020\026J\027\020\030\032\0020\0272\006\020\005\032\0020\004H\007¢\006\004\b\030\020\031J\027\020\033\032\0020\0322\006\020\005\032\0020\004H\007¢\006\004\b\033\020\034J\027\020\036\032\0020\0352\006\020\005\032\0020\004H\007¢\006\004\b\036\020\037J\027\020!\032\0020 2\006\020\005\032\0020\004H\007¢\006\004\b!\020\"J\027\020$\032\0020#2\006\020\005\032\0020\004H\007¢\006\004\b$\020%J\027\020'\032\0020&2\006\020\005\032\0020\004H\007¢\006\004\b'\020(J\027\020*\032\0020)2\006\020\005\032\0020\004H\007¢\006\004\b*\020+J\027\020-\032\0020,2\006\020\005\032\0020\004H\007¢\006\004\b-\020.J\027\0200\032\0020/2\006\020\005\032\0020\004H\007¢\006\004\b0\0201J\027\0203\032\002022\006\020\005\032\0020\004H\007¢\006\004\b3\0204J\027\0206\032\002052\006\020\005\032\0020\004H\007¢\006\004\b6\0207J\027\0209\032\002082\006\020\005\032\0020\004H\007¢\006\004\b9\020:J\027\020<\032\0020;2\006\020\005\032\0020\004H\007¢\006\004\b<\020=J\027\020?\032\0020>2\006\020\005\032\0020\004H\007¢\006\004\b?\020@J\027\020B\032\0020A2\006\020\005\032\0020\004H\007¢\006\004\bB\020CJ\027\020E\032\0020D2\006\020\005\032\0020\004H\007¢\006\004\bE\020FJ\027\020H\032\0020G2\006\020\005\032\0020\004H\007¢\006\004\bH\020IJ\027\020K\032\0020J2\006\020\005\032\0020\004H\007¢\006\004\bK\020LJ\027\020N\032\0020M2\006\020\005\032\0020\004H\007¢\006\004\bN\020OJ\027\020Q\032\0020P2\006\020\005\032\0020\004H\007¢\006\004\bQ\020RJ\027\020T\032\0020S2\006\020\005\032\0020\004H\007¢\006\004\bT\020UJ\027\020W\032\0020V2\006\020\005\032\0020\004H\007¢\006\004\bW\020XJ\027\020Z\032\0020Y2\006\020\005\032\0020\004H\007¢\006\004\bZ\020[J\027\020]\032\0020\\2\006\020\005\032\0020\004H\007¢\006\004\b]\020^J\035\020a\032\b\022\004\022\0020`0_2\006\020\005\032\0020\004H\007¢\006\004\ba\020bJ\027\020d\032\0020c2\006\020\005\032\0020\004H\007¢\006\004\bd\020eJ\027\020g\032\0020f2\006\020\005\032\0020\004H\007¢\006\004\bg\020hJ\027\020j\032\0020i2\006\020\005\032\0020\004H\007¢\006\004\bj\020kJ\035\020m\032\b\022\004\022\0020`0l2\006\020\005\032\0020\004H\007¢\006\004\bm\020nJ\027\020p\032\0020o2\006\020\005\032\0020\004H\007¢\006\004\bp\020qJ\035\020s\032\b\022\004\022\0020`0r2\006\020\005\032\0020\004H\007¢\006\004\bs\020tJ\035\020v\032\b\022\004\022\0020`0u2\006\020\005\032\0020\004H\007¢\006\004\bv\020wJ\027\020y\032\0020x2\006\020\005\032\0020\004H\007¢\006\004\by\020zJ\027\020|\032\0020{2\006\020\005\032\0020\004H\007¢\006\004\b|\020}J\030\020\032\0020~2\006\020\005\032\0020\004H\007¢\006\005\b\020\001J\033\020\001\032\0030\0012\006\020\005\032\0020\004H\007¢\006\006\b\001\020\001J\033\020\001\032\0030\0012\006\020\005\032\0020\004H\007¢\006\006\b\001\020\001J\033\020\001\032\0030\0012\006\020\005\032\0020\004H\007¢\006\006\b\001\020\001J\033\020\001\032\0030\0012\006\020\005\032\0020\004H\007¢\006\006\b\001\020\001J\033\020\001\032\0030\0012\006\020\005\032\0020\004H\007¢\006\006\b\001\020\001J\033\020\001\032\0030\0012\006\020\005\032\0020\004H\007¢\006\006\b\001\020\001J\033\020\001\032\0030\0012\006\020\005\032\0020\004H\007¢\006\006\b\001\020\001J\033\020\001\032\0030\0012\006\020\005\032\0020\004H\007¢\006\006\b\001\020\001J\033\020\001\032\0030\0012\006\020\005\032\0020\004H\007¢\006\006\b\001\020\001J\033\020\001\032\0030\0012\006\020\005\032\0020\004H\007¢\006\006\b\001\020\001J\035\020 \001\032\005\030\0010\0012\006\020\005\032\0020\004H\007¢\006\006\b \001\020¡\001J\033\020£\001\032\0030¢\0012\006\020\005\032\0020\004H\007¢\006\006\b£\001\020¤\001J\033\020¦\001\032\0030¥\0012\006\020\005\032\0020\004H\007¢\006\006\b¦\001\020§\001J\033\020©\001\032\0030¨\0012\006\020\005\032\0020\004H\007¢\006\006\b©\001\020ª\001J\033\020¬\001\032\0030«\0012\006\020\005\032\0020\004H\007¢\006\006\b¬\001\020­\001J\033\020¯\001\032\0030®\0012\006\020\005\032\0020\004H\007¢\006\006\b¯\001\020°\001J\033\020²\001\032\0030±\0012\006\020\005\032\0020\004H\007¢\006\006\b²\001\020³\001J\033\020µ\001\032\0030´\0012\006\020\005\032\0020\004H\007¢\006\006\bµ\001\020¶\001J\033\020¸\001\032\0030·\0012\006\020\005\032\0020\004H\007¢\006\006\b¸\001\020¹\001J\033\020»\001\032\0030º\0012\006\020\005\032\0020\004H\007¢\006\006\b»\001\020¼\001J\033\020¾\001\032\0030½\0012\006\020\005\032\0020\004H\007¢\006\006\b¾\001\020¿\001J\033\020Á\001\032\0030À\0012\006\020\005\032\0020\004H\007¢\006\006\bÁ\001\020Â\001J\033\020Ä\001\032\0030Ã\0012\006\020\005\032\0020\004H\007¢\006\006\bÄ\001\020Å\001J\033\020Ç\001\032\0030Æ\0012\006\020\005\032\0020\004H\007¢\006\006\bÇ\001\020È\001J\031\020Ê\001\032\0030É\0012\006\020\005\032\0020\004¢\006\006\bÊ\001\020Ë\001J\033\020Í\001\032\0030Ì\0012\006\020\005\032\0020\004H\007¢\006\006\bÍ\001\020Î\001J\033\020Ð\001\032\0030Ï\0012\006\020\005\032\0020\004H\007¢\006\006\bÐ\001\020Ñ\001J\033\020Ó\001\032\0030Ò\0012\006\020\005\032\0020\004H\007¢\006\006\bÓ\001\020Ô\001J\033\020Ö\001\032\0030Õ\0012\006\020\005\032\0020\004H\007¢\006\006\bÖ\001\020×\001J\031\020Ù\001\032\0030Ø\0012\006\020\005\032\0020\004¢\006\006\bÙ\001\020Ú\001J\031\020Ü\001\032\0030Û\0012\006\020\005\032\0020\004¢\006\006\bÜ\001\020Ý\001R\031\020Þ\001\032\0030¢\0018\002@\002X\016¢\006\007\n\005\bÞ\001\020]R\030\020à\001\032\0030ß\0018\002X\004¢\006\b\n\006\bà\001\020á\001¨\006â\001"}, d2 = {"Lcom/dropbox/android/DropboxApplication$a;", "", "<init>", "()V", "Landroid/content/Context;", "context", "Ldbxyzptlk/w6/I0;", "t", "(Landroid/content/Context;)Ldbxyzptlk/w6/I0;", "Lcom/dropbox/android/DropboxApplication;", "s", "(Landroid/content/Context;)Lcom/dropbox/android/DropboxApplication;", "Ldbxyzptlk/Ft/c;", "y", "(Landroid/content/Context;)Ldbxyzptlk/Ft/c;", "Ldbxyzptlk/pI/D;", "t0", "Ldbxyzptlk/Lu/b;", "G", "(Landroid/content/Context;)Ldbxyzptlk/Lu/b;", "", "D", "(Landroid/content/Context;)Ljava/lang/String;", "Ldbxyzptlk/oj/c;", "W", "(Landroid/content/Context;)Ldbxyzptlk/oj/c;", "Ldbxyzptlk/no/f;", "z", "(Landroid/content/Context;)Ldbxyzptlk/no/f;", "Ldbxyzptlk/pf/g;", "V", "(Landroid/content/Context;)Ldbxyzptlk/pf/g;", "Ldbxyzptlk/ye/C0;", "l0", "(Landroid/content/Context;)Ldbxyzptlk/ye/C0;", "Ldbxyzptlk/C8/g;", "P", "(Landroid/content/Context;)Ldbxyzptlk/C8/g;", "Ldbxyzptlk/ye/b0;", "m", "(Landroid/content/Context;)Ldbxyzptlk/ye/b0;", "Landroid/app/Application;", "e", "(Landroid/content/Context;)Landroid/app/Application;", "Ldbxyzptlk/Ec/g;", "l", "(Landroid/content/Context;)Ldbxyzptlk/Ec/g;", "Ldbxyzptlk/ef/E;", "I", "(Landroid/content/Context;)Ldbxyzptlk/ef/E;", "Ldbxyzptlk/mi/c;", "U", "(Landroid/content/Context;)Ldbxyzptlk/mi/c;", "Lcom/dropbox/common/lock_screen/LockReceiver;", "M", "(Landroid/content/Context;)Lcom/dropbox/common/lock_screen/LockReceiver;", "Ldbxyzptlk/wc/d;", "T", "(Landroid/content/Context;)Ldbxyzptlk/wc/d;", "Lcom/dropbox/android/user/DbxUserManager;", "q0", "(Landroid/content/Context;)Lcom/dropbox/android/user/DbxUserManager;", "Lcom/dropbox/android/filemanager/ApiManager;", "d", "(Landroid/content/Context;)Lcom/dropbox/android/filemanager/ApiManager;", "Ldbxyzptlk/Xs/f0;", "e0", "(Landroid/content/Context;)Ldbxyzptlk/Xs/f0;", "Ldbxyzptlk/Xs/G;", "w", "(Landroid/content/Context;)Ldbxyzptlk/Xs/G;", "Ldbxyzptlk/Xs/K;", "A", "(Landroid/content/Context;)Ldbxyzptlk/Xs/K;", "Ldbxyzptlk/xx/g;", "C", "(Landroid/content/Context;)Ldbxyzptlk/xx/g;", "Ldbxyzptlk/un/g;", "B", "(Landroid/content/Context;)Ldbxyzptlk/un/g;", "Ldbxyzptlk/iz/a;", "h0", "(Landroid/content/Context;)Ldbxyzptlk/iz/a;", "Ldbxyzptlk/u9/b;", "c0", "(Landroid/content/Context;)Ldbxyzptlk/u9/b;", "Ldbxyzptlk/iy/A;", "g0", "(Landroid/content/Context;)Ldbxyzptlk/iy/A;", "Ldbxyzptlk/Ja/j;", "d0", "(Landroid/content/Context;)Ldbxyzptlk/Ja/j;", "Ldbxyzptlk/zb/f0;", "Z", "(Landroid/content/Context;)Ldbxyzptlk/zb/f0;", "Lcom/dropbox/product/dbapp/downloadmanager/b;", "Lcom/dropbox/product/dbapp/path/SharedLinkPath;", "b0", "(Landroid/content/Context;)Lcom/dropbox/product/dbapp/downloadmanager/b;", "Ldbxyzptlk/A9/f;", "X", "(Landroid/content/Context;)Ldbxyzptlk/A9/f;", "Ldbxyzptlk/La/b;", "f0", "(Landroid/content/Context;)Ldbxyzptlk/La/b;", "Ljava/util/concurrent/ExecutorService;", "i0", "(Landroid/content/Context;)Ljava/util/concurrent/ExecutorService;", "Ldbxyzptlk/Ow/g;", "j0", "(Landroid/content/Context;)Ldbxyzptlk/Ow/g;", "Ldbxyzptlk/vx/t;", "L", "(Landroid/content/Context;)Ldbxyzptlk/vx/t;", "Ldbxyzptlk/Fj/a;", "a0", "(Landroid/content/Context;)Ldbxyzptlk/Fj/a;", "Lcom/dropbox/product/dbapp/common/service/ApiService;", "Y", "(Landroid/content/Context;)Lcom/dropbox/product/dbapp/common/service/ApiService;", "Ldbxyzptlk/Xs/q;", "q", "(Landroid/content/Context;)Ldbxyzptlk/Xs/q;", "Ldbxyzptlk/vv/a;", "R", "(Landroid/content/Context;)Ldbxyzptlk/vv/a;", "Ldbxyzptlk/Kk/e;", "r", "(Landroid/content/Context;)Ldbxyzptlk/Kk/e;", "Ldbxyzptlk/ye/f0;", "o", "(Landroid/content/Context;)Ldbxyzptlk/ye/f0;", "Ldbxyzptlk/lf/k;", "u", "(Landroid/content/Context;)Ldbxyzptlk/lf/k;", "Ldbxyzptlk/Y6/a;", "i", "(Landroid/content/Context;)Ldbxyzptlk/Y6/a;", "Ldbxyzptlk/sc/C;", "E", "(Landroid/content/Context;)Ldbxyzptlk/sc/C;", "Lcom/dropbox/android/notifications/f;", "m0", "(Landroid/content/Context;)Lcom/dropbox/android/notifications/f;", "Ldbxyzptlk/W6/x;", "g", "(Landroid/content/Context;)Ldbxyzptlk/W6/x;", "Ldbxyzptlk/W6/d;", "f", "(Landroid/content/Context;)Ldbxyzptlk/W6/d;", "Ldbxyzptlk/df/b;", "b", "(Landroid/content/Context;)Ldbxyzptlk/df/b;", "Ldbxyzptlk/ok/b;", "v", "(Landroid/content/Context;)Ldbxyzptlk/ok/b;", "Ldbxyzptlk/pj/m;", "N", "(Landroid/content/Context;)Ldbxyzptlk/pj/m;", "Ldbxyzptlk/Hy/c;", "Q", "(Landroid/content/Context;)Ldbxyzptlk/Hy/c;", "", "s0", "(Landroid/content/Context;)Z", "Ldbxyzptlk/Sq/k;", "p", "(Landroid/content/Context;)Ldbxyzptlk/Sq/k;", "Ldbxyzptlk/Nk/b;", "k", "(Landroid/content/Context;)Ldbxyzptlk/Nk/b;", "Ldbxyzptlk/Za/a;", "n", "(Landroid/content/Context;)Ldbxyzptlk/Za/a;", "Ldbxyzptlk/zv/l;", "S", "(Landroid/content/Context;)Ldbxyzptlk/zv/l;", "Ldbxyzptlk/Zu/e;", "J", "(Landroid/content/Context;)Ldbxyzptlk/Zu/e;", "Ldbxyzptlk/ns/b;", "h", "(Landroid/content/Context;)Ldbxyzptlk/ns/b;", "Ldbxyzptlk/Fr/b;", "a", "(Landroid/content/Context;)Ldbxyzptlk/Fr/b;", "Ldbxyzptlk/Ct/a;", "o0", "(Landroid/content/Context;)Ldbxyzptlk/Ct/a;", "Ldbxyzptlk/sh/g;", "O", "(Landroid/content/Context;)Ldbxyzptlk/sh/g;", "Ldbxyzptlk/Oa/c;", "x", "(Landroid/content/Context;)Ldbxyzptlk/Oa/c;", "Ldbxyzptlk/Fq/p;", "r0", "(Landroid/content/Context;)Ldbxyzptlk/Fq/p;", "Ldbxyzptlk/rc/b;", "p0", "(Landroid/content/Context;)Ldbxyzptlk/rc/b;", "Ldbxyzptlk/Mu/a;", "H", "(Landroid/content/Context;)Ldbxyzptlk/Mu/a;", "Ldbxyzptlk/Ec/q;", "k0", "(Landroid/content/Context;)Ldbxyzptlk/Ec/q;", "Ldbxyzptlk/Cg/a;", "F", "(Landroid/content/Context;)Ldbxyzptlk/Cg/a;", "Ldbxyzptlk/Ij/s;", "n0", "(Landroid/content/Context;)Ldbxyzptlk/Ij/s;", "Ldbxyzptlk/jf/u;", "K", "(Landroid/content/Context;)Ldbxyzptlk/jf/u;", "Ldbxyzptlk/A6/a;", "j", "(Landroid/content/Context;)Ldbxyzptlk/A6/a;", "Ldbxyzptlk/ye/A;", "c", "(Landroid/content/Context;)Ldbxyzptlk/ye/A;", "applicationCreated", "Ljava/lang/Object;", "applicationCreatedMonitor", "Ljava/lang/Object;", "Dropbox_normalRelease"}, k = 1, mv = {1, 9, 0}, xi = 48)
  public static final class a {
    public a() {}
    
    public final K A(Context param1Context) {
      s.h(param1Context, "context");
      return DropboxApplication.M(s(param1Context));
    }
    
    public final g B(Context param1Context) {
      s.h(param1Context, "context");
      return t(param1Context).W();
    }
    
    public final g C(Context param1Context) {
      s.h(param1Context, "context");
      return t(param1Context).O();
    }
    
    public final String D(Context param1Context) {
      s.h(param1Context, "context");
      return t(param1Context).J();
    }
    
    public final C E(Context param1Context) {
      s.h(param1Context, "context");
      b.a();
      return t(param1Context).Z();
    }
    
    public final dbxyzptlk.Cg.a F(Context param1Context) {
      s.h(param1Context, "context");
      return t(param1Context).C().i();
    }
    
    public final b G(Context param1Context) {
      s.h(param1Context, "context");
      return t(param1Context).I();
    }
    
    public final dbxyzptlk.Mu.a H(Context param1Context) {
      s.h(param1Context, "context");
      return t(param1Context).S();
    }
    
    public final E I(Context param1Context) {
      s.h(param1Context, "context");
      return DropboxApplication.N(s(param1Context));
    }
    
    public final e J(Context param1Context) {
      s.h(param1Context, "context");
      return s(param1Context).h().a();
    }
    
    public final u K(Context param1Context) {
      s.h(param1Context, "context");
      return t(param1Context).p();
    }
    
    public final t L(Context param1Context) {
      s.h(param1Context, "context");
      b.a();
      return t(param1Context).D();
    }
    
    public final LockReceiver M(Context param1Context) {
      s.h(param1Context, "context");
      return t(param1Context).b();
    }
    
    public final m N(Context param1Context) {
      s.h(param1Context, "context");
      return t(param1Context).s0();
    }
    
    public final g O(Context param1Context) {
      s.h(param1Context, "context");
      return t(param1Context).Y0();
    }
    
    public final g P(Context param1Context) {
      s.h(param1Context, "context");
      return t(param1Context).V();
    }
    
    public final c Q(Context param1Context) {
      s.h(param1Context, "context");
      return t(param1Context).w();
    }
    
    public final dbxyzptlk.vv.a R(Context param1Context) {
      s.h(param1Context, "context");
      b.a();
      return t(param1Context).y();
    }
    
    public final l S(Context param1Context) {
      s.h(param1Context, "context");
      return s(param1Context).m2();
    }
    
    public final d T(Context param1Context) {
      s.h(param1Context, "context");
      return t(param1Context).B();
    }
    
    public final c U(Context param1Context) {
      s.h(param1Context, "context");
      return t(param1Context).n2();
    }
    
    public final g V(Context param1Context) {
      s.h(param1Context, "context");
      return t(param1Context).H();
    }
    
    public final c W(Context param1Context) {
      s.h(param1Context, "context");
      return t(param1Context).t();
    }
    
    public final f X(Context param1Context) {
      s.h(param1Context, "context");
      b.a();
      return DropboxApplication.O(s(param1Context));
    }
    
    public final ApiService<SharedLinkPath> Y(Context param1Context) {
      s.h(param1Context, "context");
      b.a();
      return t(param1Context).L();
    }
    
    public final f0 Z(Context param1Context) {
      s.h(param1Context, "context");
      return t(param1Context).e0();
    }
    
    public final b a(Context param1Context) {
      s.h(param1Context, "context");
      return s(param1Context).i().a();
    }
    
    public final dbxyzptlk.Fj.a<SharedLinkPath> a0(Context param1Context) {
      s.h(param1Context, "context");
      b.a();
      return t(param1Context).G();
    }
    
    public final b b(Context param1Context) {
      s.h(param1Context, "context");
      return t(param1Context).M();
    }
    
    public final b<SharedLinkPath> b0(Context param1Context) {
      s.h(param1Context, "context");
      return t(param1Context).A();
    }
    
    public final A c(Context param1Context) {
      s.h(param1Context, "context");
      return t(param1Context).f0().a();
    }
    
    public final b c0(Context param1Context) {
      s.h(param1Context, "context");
      return t(param1Context).z();
    }
    
    public final ApiManager d(Context param1Context) {
      s.h(param1Context, "context");
      return t(param1Context).d0();
    }
    
    public final j d0(Context param1Context) {
      s.h(param1Context, "context");
      return t(param1Context).N();
    }
    
    public final Application e(Context param1Context) {
      s.h(param1Context, "context");
      return (Application)s(param1Context);
    }
    
    public final f0 e0(Context param1Context) {
      s.h(param1Context, "context");
      return DropboxApplication.P(s(param1Context));
    }
    
    public final d f(Context param1Context) {
      s.h(param1Context, "context");
      return t(param1Context).b0();
    }
    
    public final b f0(Context param1Context) {
      s.h(param1Context, "context");
      b.a();
      return t(param1Context).l0();
    }
    
    public final x g(Context param1Context) {
      s.h(param1Context, "context");
      return s(param1Context).W();
    }
    
    public final A g0(Context param1Context) {
      s.h(param1Context, "context");
      return DropboxApplication.Q(s(param1Context));
    }
    
    public final b h(Context param1Context) {
      s.h(param1Context, "context");
      return s(param1Context).o().a();
    }
    
    public final dbxyzptlk.iz.a h0(Context param1Context) {
      s.h(param1Context, "context");
      b.a();
      return t(param1Context).i0();
    }
    
    public final dbxyzptlk.Y6.a i(Context param1Context) {
      s.h(param1Context, "context");
      return t(param1Context).U();
    }
    
    public final ExecutorService i0(Context param1Context) {
      s.h(param1Context, "context");
      b.a();
      return t(param1Context).a0();
    }
    
    public final dbxyzptlk.A6.a j(Context param1Context) {
      s.h(param1Context, "context");
      return t(param1Context).c0();
    }
    
    public final g<SharedLinkPath> j0(Context param1Context) {
      s.h(param1Context, "context");
      b.a();
      return t(param1Context).E();
    }
    
    public final b k(Context param1Context) {
      s.h(param1Context, "context");
      return t(param1Context).k();
    }
    
    public final q k0(Context param1Context) {
      s.h(param1Context, "context");
      return t(param1Context).e1();
    }
    
    public final g l(Context param1Context) {
      s.h(param1Context, "context");
      return DropboxApplication.K(s(param1Context));
    }
    
    public final C0 l0(Context param1Context) {
      s.h(param1Context, "context");
      return s(param1Context).z();
    }
    
    public final b0 m(Context param1Context) {
      s.h(param1Context, "context");
      return t(param1Context).g0();
    }
    
    public final f m0(Context param1Context) {
      s.h(param1Context, "context");
      return t(param1Context).p1();
    }
    
    public final dbxyzptlk.Za.a n(Context param1Context) {
      s.h(param1Context, "context");
      return t(param1Context).P();
    }
    
    public final s n0(Context param1Context) {
      s.h(param1Context, "context");
      return t(param1Context).f();
    }
    
    public final f0 o(Context param1Context) {
      s.h(param1Context, "context");
      return s(param1Context).f0();
    }
    
    public final dbxyzptlk.Ct.a o0(Context param1Context) {
      s.h(param1Context, "context");
      return y(param1Context).a();
    }
    
    public final k p(Context param1Context) {
      s.h(param1Context, "context");
      return t(param1Context).p0();
    }
    
    public final b p0(Context param1Context) {
      s.h(param1Context, "context");
      return t(param1Context).K();
    }
    
    public final q q(Context param1Context) {
      s.h(param1Context, "context");
      return t(param1Context).Y();
    }
    
    public final DbxUserManager q0(Context param1Context) {
      s.h(param1Context, "context");
      return s(param1Context).a1();
    }
    
    public final e r(Context param1Context) {
      s.h(param1Context, "context");
      return t(param1Context).T();
    }
    
    public final p r0(Context param1Context) {
      s.h(param1Context, "context");
      return (p)s(param1Context);
    }
    
    public final DropboxApplication s(Context param1Context) {
      param1Context = param1Context.getApplicationContext();
      s.f(param1Context, "null cannot be cast to non-null type com.dropbox.android.DropboxApplication");
      return (DropboxApplication)param1Context;
    }
    
    public final boolean s0(Context param1Context) {
      s.h(param1Context, "context");
      return s(param1Context).b();
    }
    
    public final I0 t(Context param1Context) {
      return s(param1Context).l0();
    }
    
    public final void t0() {
      if (!s.c("main", Thread.currentThread().getName())) {
        Object object = DropboxApplication.J();
        /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
        while (true) {
          try {
            boolean bool = DropboxApplication.I();
            if (!bool) {
              try {
                DropboxApplication.J().wait();
              } catch (InterruptedException interruptedException) {}
              continue;
            } 
          } finally {
            Exception exception;
          } 
          D d = D.a;
          /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
          return;
        } 
      } 
    }
    
    public final k u(Context param1Context) {
      s.h(param1Context, "context");
      return s(param1Context).m0();
    }
    
    public final b v(Context param1Context) {
      s.h(param1Context, "context");
      return t(param1Context).n0();
    }
    
    public final G w(Context param1Context) {
      s.h(param1Context, "context");
      return DropboxApplication.L(s(param1Context));
    }
    
    public final c x(Context param1Context) {
      s.h(param1Context, "context");
      return t(param1Context).k0();
    }
    
    public final c y(Context param1Context) {
      return s(param1Context).g1();
    }
    
    public final f z(Context param1Context) {
      s.h(param1Context, "context");
      return t(param1Context).F();
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\android\DropboxApplication.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */