package com.dropbox.android.provider;

import android.content.ContentProvider;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.pm.PackageInfo;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.Binder;
import android.os.ParcelFileDescriptor;
import android.util.Pair;
import com.dropbox.android.DropboxApplication;
import com.dropbox.android.user.DbxUserManager;
import com.dropbox.android.user.a;
import com.dropbox.common.android.context.SafePackageManager;
import com.dropbox.product.dbapp.entry.DropboxLocalEntry;
import com.dropbox.product.dbapp.entry.LocalEntry;
import com.dropbox.product.dbapp.entry.SharedLinkLocalEntry;
import com.dropbox.product.dbapp.path.DropboxPath;
import com.dropbox.product.dbapp.path.Path;
import com.dropbox.product.dbapp.path.SharedLinkPath;
import dbxyzptlk.CC.p;
import dbxyzptlk.EC.G;
import dbxyzptlk.Ec.a;
import dbxyzptlk.Ec.g;
import dbxyzptlk.He.h;
import dbxyzptlk.It.k;
import dbxyzptlk.Ja.g;
import dbxyzptlk.Ja.j;
import dbxyzptlk.Ny.L;
import dbxyzptlk.Ny.f;
import dbxyzptlk.Uz.a;
import dbxyzptlk.Uz.b;
import dbxyzptlk.iy.A;
import dbxyzptlk.iy.m;
import dbxyzptlk.iy.r;
import dbxyzptlk.iy.t;
import dbxyzptlk.jf.E;
import dbxyzptlk.pc.d0;
import dbxyzptlk.qf.a;
import dbxyzptlk.sL.a;
import dbxyzptlk.xx.g;
import io.sentry.android.core.performance.e;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class FileCacheProvider extends ContentProvider {
  public static final Uri h = b.a("FileNotFound");
  
  public g a;
  
  public DbxUserManager b;
  
  public A c;
  
  public j d;
  
  public g e;
  
  public final Map<String, d<DropboxPath>> f = new HashMap<>();
  
  public d<SharedLinkPath> g;
  
  public static void b(SharedLinkLocalEntry paramSharedLinkLocalEntry, String paramString) throws SecurityException {
    if (ParcelFileDescriptor.parseMode(paramString) == 268435456)
      return; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Trying to write to readonly file: contentId: ");
    stringBuilder.append(paramSharedLinkLocalEntry.i());
    stringBuilder.append("mode: ");
    stringBuilder.append(paramString);
    throw new SecurityException(stringBuilder.toString());
  }
  
  public static List<String> d(SafePackageManager paramSafePackageManager, int paramInt) {
    try {
      String[] arrayOfString = paramSafePackageManager.h(paramInt);
      if (arrayOfString != null)
        return Arrays.asList(arrayOfString); 
      a.d("No packages found for user id", new Object[0]);
      return (List)Collections.emptyList();
    } catch (com.dropbox.common.android.context.SafePackageManager.PackageManagerCrashedException packageManagerCrashedException) {
      a.d("Package manager crashed when calling getPackagesForUid", new Object[0]);
      return Collections.emptyList();
    } 
  }
  
  public static PackageInfo q(SafePackageManager paramSafePackageManager, String paramString) {
    try {
      return paramSafePackageManager.g(paramString, 0);
    } catch (com.dropbox.common.android.context.SafePackageManager.PackageManagerCrashedException|android.content.pm.PackageManager.NameNotFoundException packageManagerCrashedException) {
      return null;
    } 
  }
  
  public static <P extends Path> Uri v(P paramP, t<P> paramt) {
    p.e(paramP.q0() ^ true, "Assert failed.");
    LocalEntry localEntry = paramt.f((Path)paramP);
    if (localEntry == null || localEntry.i() == null)
      return null; 
    String str = h.e(paramP.getName());
    return b.b(localEntry.i(), str);
  }
  
  public final void a(DropboxLocalEntry paramDropboxLocalEntry, String paramString) throws SecurityException {
    if (ParcelFileDescriptor.parseMode(paramString) == 268435456)
      return; 
    List<String> list = c();
    if (!paramDropboxLocalEntry.z()) {
      for (String str : list) {
        PackageInfo packageInfo = q(k(), str);
        if (packageInfo != null) {
          if (!a.a(packageInfo.packageName, packageInfo.versionCode))
            continue; 
          StringBuilder stringBuilder2 = new StringBuilder();
          stringBuilder2.append("Package is blocked to writing to file: path: ");
          stringBuilder2.append(paramDropboxLocalEntry.P());
          stringBuilder2.append(" mode: ");
          stringBuilder2.append(paramString);
          stringBuilder2.append(" package: ");
          stringBuilder2.append(str);
          throw new SecurityException(stringBuilder2.toString());
        } 
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("Package information unavailable trying to write to file: path: ");
        stringBuilder1.append(paramDropboxLocalEntry.P());
        stringBuilder1.append(" mode: ");
        stringBuilder1.append(paramString);
        stringBuilder1.append(" package: ");
        stringBuilder1.append(str);
        throw new SecurityException(stringBuilder1.toString());
      } 
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Trying to write to readonly file: path: ");
    stringBuilder.append(paramDropboxLocalEntry.P());
    stringBuilder.append(" mode: ");
    stringBuilder.append(paramString);
    stringBuilder.append(" callingPackages: ");
    stringBuilder.append(str);
    throw new SecurityException(stringBuilder.toString());
  }
  
  public List<String> c() {
    return d(k(), Binder.getCallingUid());
  }
  
  public int delete(Uri paramUri, String paramString, String[] paramArrayOfString) {
    return 0;
  }
  
  public ContentResolver e() {
    return getContext().getContentResolver();
  }
  
  public final g f() {
    /* monitor enter ThisExpression{ObjectType{com/dropbox/android/provider/FileCacheProvider}} */
    try {
      g g2 = this.a;
      if (g2 == null)
        try {
          this.a = DropboxApplication.b0(getContext());
        } catch (IllegalStateException illegalStateException) {
          RuntimeException runtimeException = new RuntimeException();
          this(illegalStateException);
          throw runtimeException;
        }  
    } finally {
      Exception exception;
    } 
    g g1 = this.a;
    /* monitor exit ThisExpression{ObjectType{com/dropbox/android/provider/FileCacheProvider}} */
    return g1;
  }
  
  public Pair<DropboxLocalEntry, d0> g(String paramString) {
    a a = n().a();
    if (a != null)
      for (d0 d0 : a.b()) {
        DropboxLocalEntry dropboxLocalEntry = d0.q().j(paramString);
        if (dropboxLocalEntry != null)
          return new Pair(dropboxLocalEntry, d0); 
      }  
    return null;
  }
  
  public String getType(Uri paramUri) {
    DropboxApplication.h1();
    try {
      LocalEntry localEntry;
      String str = w(paramUri);
      Pair<DropboxLocalEntry, d0> pair = g(str);
      if (pair != null) {
        localEntry = (LocalEntry)pair.first;
        o((d0)pair.second);
      } else {
        localEntry = m().j((String)localEntry);
        p();
      } 
      if (localEntry == null) {
        a.M0("getType", c(), null, "path not found for content id").i(f());
        return null;
      } 
      return (new h(localEntry)).b();
    } catch (UriParseException uriParseException) {
      a.M0("getType", c(), null, "uri parse failure").i(f());
      return null;
    } 
  }
  
  public final g.c h() {
    return (g.c)new b(this);
  }
  
  public final g i() {
    /* monitor enter ThisExpression{ObjectType{com/dropbox/android/provider/FileCacheProvider}} */
    try {
      if (this.e == null)
        this.e = DropboxApplication.t0(getContext()); 
    } finally {
      Exception exception;
    } 
    g g1 = this.e;
    /* monitor exit ThisExpression{ObjectType{com/dropbox/android/provider/FileCacheProvider}} */
    return g1;
  }
  
  public Uri insert(Uri paramUri, ContentValues paramContentValues) {
    return null;
  }
  
  public final <P extends Path> m<P> j(t<P> paramt) {
    return (m<P>)new a(this, paramt);
  }
  
  public final SafePackageManager k() {
    return E.a(getContext());
  }
  
  public final j l() {
    /* monitor enter ThisExpression{ObjectType{com/dropbox/android/provider/FileCacheProvider}} */
    try {
      if (this.d == null)
        this.d = DropboxApplication.P0(getContext()); 
    } finally {
      Exception exception;
    } 
    j j1 = this.d;
    /* monitor exit ThisExpression{ObjectType{com/dropbox/android/provider/FileCacheProvider}} */
    return j1;
  }
  
  public final A m() {
    /* monitor enter ThisExpression{ObjectType{com/dropbox/android/provider/FileCacheProvider}} */
    try {
      if (this.c == null)
        this.c = DropboxApplication.S0(getContext()); 
    } finally {
      Exception exception;
    } 
    A a = this.c;
    /* monitor exit ThisExpression{ObjectType{com/dropbox/android/provider/FileCacheProvider}} */
    return a;
  }
  
  public final DbxUserManager n() {
    /* monitor enter ThisExpression{ObjectType{com/dropbox/android/provider/FileCacheProvider}} */
    try {
      DbxUserManager dbxUserManager1 = this.b;
      if (dbxUserManager1 == null)
        try {
          this.b = DropboxApplication.b1(getContext());
        } catch (IllegalStateException illegalStateException) {
          RuntimeException runtimeException = new RuntimeException();
          this(illegalStateException);
          throw runtimeException;
        }  
    } finally {
      Exception exception;
    } 
    DbxUserManager dbxUserManager = this.b;
    /* monitor exit ThisExpression{ObjectType{com/dropbox/android/provider/FileCacheProvider}} */
    return dbxUserManager;
  }
  
  public final void o(d0 paramd0) {
    /* monitor enter ThisExpression{ObjectType{com/dropbox/android/provider/FileCacheProvider}} */
    try {
      String str = paramd0.getId();
      if (!this.f.containsKey(str)) {
        r r = paramd0.q();
        g g1 = new g();
        this(getContext(), (t)r, DropboxPath.class);
        m<Path> m = j((t<Path>)r);
        g.c c = h();
        d<DropboxPath> d1 = new d();
        this(m, g1, c);
        d1.a((t)paramd0.q(), paramd0.Y1(), paramd0.D1());
        this.f.put(str, d1);
      } 
    } finally {}
    /* monitor exit ThisExpression{ObjectType{com/dropbox/android/provider/FileCacheProvider}} */
  }
  
  public boolean onCreate() {
    e.t((ContentProvider)this);
    e.u((ContentProvider)this);
    return true;
  }
  
  public ParcelFileDescriptor openFile(Uri paramUri, String paramString) throws FileNotFoundException, SecurityException {
    StringBuilder stringBuilder;
    DropboxApplication.h1();
    a.d("openFile: uri:  %s", new Object[] { paramUri });
    try {
      ParcelFileDescriptor parcelFileDescriptor;
      DropboxPath dropboxPath;
      int i = ParcelFileDescriptor.parseMode(paramString);
      List<String> list = c();
      d0 d0 = null;
      try {
        g g1;
        String str = w(paramUri);
        Pair<DropboxLocalEntry, d0> pair = g(str);
        if (pair != null) {
          File file;
          DropboxLocalEntry dropboxLocalEntry = (DropboxLocalEntry)pair.first;
          d0 = (d0)pair.second;
          g1 = d0.D1();
          r("openFile", dropboxLocalEntry, d0, list, paramString);
          dropboxPath = dropboxLocalEntry.P();
          a(dropboxLocalEntry, paramString);
          if (i == 268435456) {
            try {
              file = g1.p(dropboxLocalEntry);
            } catch (IOException iOException) {}
          } else {
            boolean bool;
            if ((0x32000000 & i) != 0) {
              bool = true;
            } else {
              bool = false;
            } 
            file = g1.q((DropboxLocalEntry)iOException, bool);
          } 
          parcelFileDescriptor = ParcelFileDescriptor.open(file, i);
          o(d0);
        } else {
          SharedLinkLocalEntry sharedLinkLocalEntry = (SharedLinkLocalEntry)m().j((String)g1);
          d0 d01 = d0;
          if (sharedLinkLocalEntry != null) {
            s("query", sharedLinkLocalEntry, (List<String>)dropboxPath, paramString);
            b(sharedLinkLocalEntry, paramString);
            parcelFileDescriptor = ParcelFileDescriptor.open(l().k((SharedLinkPath)sharedLinkLocalEntry.s()).a(), i);
            p();
          } 
        } 
        if (parcelFileDescriptor != null)
          return parcelFileDescriptor; 
        throw new FileNotFoundException("path not found for content id");
      } catch (UriParseException uriParseException) {
        a.M0("openFile", (List)dropboxPath, null, "uri parse failure").i(f());
        stringBuilder = new StringBuilder();
        stringBuilder.append("Invalid uri: ");
        stringBuilder.append(parcelFileDescriptor);
        throw new FileNotFoundException(stringBuilder.toString());
      } 
    } catch (IllegalArgumentException illegalArgumentException) {
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("Invalid mode: ");
      stringBuilder1.append((String)stringBuilder);
      throw new FileNotFoundException(stringBuilder1.toString());
    } 
  }
  
  public final void p() {
    /* monitor enter ThisExpression{ObjectType{com/dropbox/android/provider/FileCacheProvider}} */
    try {
      if (this.g != null) {
        A a = m();
        g g2 = i();
        g g1 = new g();
        this(getContext(), (t)a, SharedLinkPath.class);
        m<Path> m = j((t<Path>)a);
        d<SharedLinkPath> d1 = new d();
        this(m, g1, null);
        d1.a((t)a, g2, null);
        this.g = d1;
      } 
    } finally {
      Exception exception;
    } 
    /* monitor exit ThisExpression{ObjectType{com/dropbox/android/provider/FileCacheProvider}} */
  }
  
  public Cursor query(Uri paramUri, String[] paramArrayOfString1, String paramString1, String[] paramArrayOfString2, String paramString2) {
    DropboxApplication.h1();
    a.d("query: uri:  %s", new Object[] { paramUri });
    List<String> list = c();
    paramString1 = null;
    try {
      MatrixCursor matrixCursor1;
      MatrixCursor matrixCursor2;
      d0 d0;
      String str = w(paramUri);
      ArrayList<e> arrayList = G.h();
      if (paramArrayOfString1 == null) {
        arrayList.addAll(e.b().values());
      } else {
        int i = paramArrayOfString1.length;
        for (byte b = 0; b < i; b++) {
          String str1 = paramArrayOfString1[b];
          e e = e.i(str1);
          if (e != null) {
            arrayList.add(e);
          } else {
            a.M0("query", list, paramArrayOfString1, "query for unsupported col").o("col", str1).i(f());
          } 
        } 
      } 
      Pair<DropboxLocalEntry, d0> pair = g(str);
      if (pair != null) {
        DropboxLocalEntry dropboxLocalEntry = (DropboxLocalEntry)pair.first;
        d0 = (d0)pair.second;
        r("query", dropboxLocalEntry, d0, list, null);
        if (!d0.c().r(dropboxLocalEntry.P()).a().exists()) {
          a.M0("query", list, paramArrayOfString1, "file does not exist").i(f());
          return null;
        } 
        matrixCursor2 = (new h((LocalEntry)dropboxLocalEntry)).a(arrayList, d0.Y1(), d0.D1(), 1L);
        matrixCursor2.setNotificationUri(e(), paramUri);
        o(d0);
        matrixCursor1 = matrixCursor2;
      } else {
        SharedLinkLocalEntry sharedLinkLocalEntry = (SharedLinkLocalEntry)m().j((String)d0);
        matrixCursor1 = matrixCursor2;
        if (sharedLinkLocalEntry != null) {
          k k = l().k((SharedLinkPath)sharedLinkLocalEntry.s());
          s("query", sharedLinkLocalEntry, list, null);
          if (!k.a().exists()) {
            a.M0("query", list, paramArrayOfString1, "file does not exist").i(f());
            return null;
          } 
          matrixCursor1 = (new h((LocalEntry)sharedLinkLocalEntry)).a(arrayList, null, null, 1L);
          p();
        } 
      } 
      if (matrixCursor1 == null)
        a.M0("query", list, paramArrayOfString1, "path not found for content id").i(f()); 
      return (Cursor)matrixCursor1;
    } catch (UriParseException uriParseException) {
      a.M0("query", list, paramArrayOfString1, "uri parse failure").i(f());
      return null;
    } 
  }
  
  public void r(String paramString1, DropboxLocalEntry paramDropboxLocalEntry, d0 paramd0, List<String> paramList, String paramString2) {
    f f = paramd0.s1().b();
    L l = paramd0.J1();
    f.a(paramString1, paramDropboxLocalEntry, paramList, paramd0.e(), paramString2, l, f).start();
  }
  
  public void s(String paramString1, SharedLinkLocalEntry paramSharedLinkLocalEntry, List<String> paramList, String paramString2) {
    f.b(paramString1, paramSharedLinkLocalEntry, paramList, f(), paramString2).start();
  }
  
  public void shutdown() {
    DbxUserManager dbxUserManager = this.b;
    if (dbxUserManager != null) {
      a a = dbxUserManager.a();
      if (a != null) {
        Iterator<d0> iterator = a.b().iterator();
        while (iterator.hasNext())
          t(iterator.next()); 
      } 
    } 
    u();
  }
  
  public final void t(d0 paramd0) {
    /* monitor enter ThisExpression{ObjectType{com/dropbox/android/provider/FileCacheProvider}} */
    try {
      String str = paramd0.getId();
      d d1 = this.f.get(str);
      if (d1 != null) {
        d1.b((t)paramd0.q(), paramd0.Y1());
        this.f.remove(str);
      } 
    } finally {}
    /* monitor exit ThisExpression{ObjectType{com/dropbox/android/provider/FileCacheProvider}} */
  }
  
  public final void u() {
    /* monitor enter ThisExpression{ObjectType{com/dropbox/android/provider/FileCacheProvider}} */
    try {
      if (this.g != null) {
        A a = m();
        g g1 = i();
        this.g.b((t)a, g1);
      } 
    } finally {
      Exception exception;
    } 
    /* monitor exit ThisExpression{ObjectType{com/dropbox/android/provider/FileCacheProvider}} */
  }
  
  public int update(Uri paramUri, ContentValues paramContentValues, String paramString, String[] paramArrayOfString) {
    return 0;
  }
  
  public String w(Uri paramUri) throws UriParseException {
    if (!h.equals(paramUri)) {
      String str;
      if (paramUri.getScheme().equals("content") && paramUri.getAuthority().equals("com.dropbox.android.FileCache")) {
        if (!paramUri.getPath().endsWith("/")) {
          List<String> list = paramUri.getPathSegments();
          if (list.size() == 2) {
            if (((String)list.get(0)).equals("filecache")) {
              String str1 = list.get(1);
              int i = str1.lastIndexOf('.');
              str = str1;
              if (i > -1)
                str = str1.substring(0, i); 
              if (a.b(str))
                return str; 
              StringBuilder stringBuilder4 = new StringBuilder();
              stringBuilder4.append("Uri has invalid content id: ");
              stringBuilder4.append(str);
              throw new UriParseException(stringBuilder4.toString());
            } 
            StringBuilder stringBuilder3 = new StringBuilder();
            stringBuilder3.append("Uri has invalid base path: ");
            stringBuilder3.append(str);
            throw new UriParseException(stringBuilder3.toString());
          } 
          StringBuilder stringBuilder2 = new StringBuilder();
          stringBuilder2.append("Uri has wrong number of path segments: ");
          stringBuilder2.append(str);
          throw new UriParseException(stringBuilder2.toString());
        } 
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("Uri can't refer to a directory: ");
        stringBuilder1.append(str);
        throw new UriParseException(stringBuilder1.toString());
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Uri has invalid scheme or authority: ");
      stringBuilder.append(str);
      throw new UriParseException(stringBuilder.toString());
    } 
    throw new UriParseException("FileNotFound uri requested");
  }
  
  public static class UriParseException extends Exception {
    private static final long serialVersionUID = 8254166718145592666L;
    
    public UriParseException(String param1String) {
      super(param1String);
    }
  }
  
  class FileCacheProvider {}
  
  class FileCacheProvider {}
  
  class FileCacheProvider {}
  
  class FileCacheProvider {}
  
  class FileCacheProvider {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\android\provider\FileCacheProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */