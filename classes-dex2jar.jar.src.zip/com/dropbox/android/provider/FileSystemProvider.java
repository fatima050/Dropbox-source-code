package com.dropbox.android.provider;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.content.res.Resources;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.util.Pair;
import com.dropbox.base.filesystem.c;
import dbxyzptlk.CC.p;
import dbxyzptlk.EC.G;
import dbxyzptlk.Em.W;
import dbxyzptlk.eh.b;
import dbxyzptlk.ye.z0;
import io.sentry.android.core.performance.e;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

public class FileSystemProvider extends ContentProvider {
  public W a;
  
  public static void a(List<Pair<Uri, File>> paramList, File paramFile, Uri paramUri) {
    if (paramFile.isDirectory() && paramFile.canRead()) {
      File[] arrayOfFile = c.u(paramFile);
      Arrays.sort(arrayOfFile, (Comparator<? super File>)new b(null));
      int i = arrayOfFile.length;
      for (byte b = 0; b < i; b++) {
        File file = arrayOfFile[b];
        if (!file.isHidden())
          paramList.add(new Pair(paramUri.buildUpon().appendPath(file.getName()).build(), file)); 
      } 
    } 
  }
  
  public final Cursor b(Resources paramResources, List<Pair<Uri, File>> paramList, Uri paramUri, W.a parama, boolean paramBoolean1, boolean paramBoolean2) {
    MatrixCursor matrixCursor = new MatrixCursor(new String[] { "_id", "uri", "path", "filename", "is_dir", "size", "modified" });
    Iterator<Pair<Uri, File>> iterator = paramList.iterator();
    for (byte b = 1; iterator.hasNext(); b++) {
      Pair pair = iterator.next();
      matrixCursor.addRow(new Object[] { Integer.valueOf(b), ((Uri)pair.first).toString(), ((File)pair.second).getPath(), this.a.e((Uri)pair.first, paramResources), Boolean.toString(((File)pair.second).isDirectory()), Long.valueOf(((File)pair.second).length()), Long.valueOf(((File)pair.second).lastModified()) });
    } 
    if (parama == W.a.INTERNAL_DIR || parama == W.a.SD_CARD_DIR || (parama != W.a.BASE && paramBoolean1 && paramBoolean2)) {
      W w = this.a;
      return b.addUpFolder((Cursor)matrixCursor, w.e(w.f(paramUri), paramResources));
    } 
    return (Cursor)matrixCursor;
  }
  
  public final List<Pair<Uri, File>> c(Uri paramUri, W.a parama, boolean paramBoolean1, boolean paramBoolean2, File paramFile1, File paramFile2) {
    ArrayList<Pair<Uri, File>> arrayList = G.h();
    int i = a.a[parama.ordinal()];
    if (i != 1) {
      StringBuilder stringBuilder;
      if (i != 2 && i != 3) {
        if (i == 4 || i == 5) {
          if (paramBoolean2)
            a(arrayList, this.a.h(paramUri), paramUri); 
          return arrayList;
        } 
        stringBuilder = new StringBuilder();
        stringBuilder.append("Unexpected type: ");
        stringBuilder.append(parama);
        throw new RuntimeException(stringBuilder.toString());
      } 
      if (paramBoolean1)
        a(arrayList, this.a.h((Uri)stringBuilder), (Uri)stringBuilder); 
    } else {
      if (paramBoolean1)
        arrayList.add(new Pair(this.a.c(), paramFile1)); 
      if (paramBoolean2)
        arrayList.add(new Pair(this.a.d(), paramFile2)); 
    } 
    return arrayList;
  }
  
  public int delete(Uri paramUri, String paramString, String[] paramArrayOfString) {
    return 0;
  }
  
  public String getType(Uri paramUri) {
    return null;
  }
  
  public Uri insert(Uri paramUri, ContentValues paramContentValues) {
    return null;
  }
  
  public boolean onCreate() {
    e.t((ContentProvider)this);
    this.a = new W("com.dropbox.android");
    e.u((ContentProvider)this);
    return true;
  }
  
  public Cursor query(Uri paramUri, String[] paramArrayOfString1, String paramString1, String[] paramArrayOfString2, String paramString2) {
    boolean bool2 = c.m(z0.a(getContext()), (Context)p.o(getContext()));
    boolean bool1 = c.n();
    File file1 = c.f();
    File file2 = c.v();
    W.a a = this.a.g(paramUri);
    List<Pair<Uri, File>> list = c(paramUri, a, bool2, bool1, file1, file2);
    return b(getContext().getResources(), list, paramUri, a, bool2, bool1);
  }
  
  public int update(Uri paramUri, ContentValues paramContentValues, String paramString, String[] paramArrayOfString) {
    return 0;
  }
  
  class FileSystemProvider {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\android\provider\FileSystemProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */