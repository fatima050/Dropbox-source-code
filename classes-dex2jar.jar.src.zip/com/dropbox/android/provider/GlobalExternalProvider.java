package com.dropbox.android.provider;

import android.content.ContentProvider;
import androidx.core.content.FileProvider;
import io.sentry.android.core.performance.e;

public class GlobalExternalProvider extends FileProvider {
  public boolean onCreate() {
    e.t((ContentProvider)this);
    e.u((ContentProvider)this);
    return true;
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\android\provider\GlobalExternalProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */