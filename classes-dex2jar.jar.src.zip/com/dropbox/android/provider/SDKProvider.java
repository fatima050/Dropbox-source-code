package com.dropbox.android.provider;

import android.content.ContentProvider;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.Binder;
import com.dropbox.android.DropboxApplication;
import com.dropbox.android.user.DbxUserManager;
import dbxyzptlk.Ec.g;
import dbxyzptlk.ib.f;
import dbxyzptlk.ib.g;
import dbxyzptlk.ib.h;
import dbxyzptlk.ib.i;
import dbxyzptlk.ib.j;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

public class SDKProvider extends ContentProvider {
  public static final UriMatcher b = new UriMatcher(-1);
  
  public final AtomicBoolean a = new AtomicBoolean(false);
  
  static {
    for (b b : b.values())
      b.addURI("com.dropbox.android.provider.SDK", b.path(), b.ordinal()); 
  }
  
  public static void a(String paramString, Context paramContext) {
    if (paramString != null)
      paramContext.enforceCallingPermission(paramString, null); 
  }
  
  public static void b(ContentResolver paramContentResolver, DbxUserManager paramDbxUserManager) {
    paramDbxUserManager.l(new a(paramContentResolver));
  }
  
  public static b c(Uri paramUri) {
    int i = b.match(paramUri);
    for (b b : b.values()) {
      if (i == b.ordinal())
        return b; 
    } 
    return null;
  }
  
  public int delete(Uri paramUri, String paramString, String[] paramArrayOfString) {
    DropboxApplication.h1();
    return 0;
  }
  
  public String getType(Uri paramUri) {
    b b = c(paramUri);
    return (b != null) ? b.mimeType() : null;
  }
  
  public Uri insert(Uri paramUri, ContentValues paramContentValues) {
    DropboxApplication.h1();
    b b = c(paramUri);
    if (b == null)
      return null; 
    a(b.writePermission(), getContext());
    return b.insert(paramUri, paramContentValues);
  }
  
  public boolean onCreate() {
    io.sentry.android.core.performance.e.t(this);
    io.sentry.android.core.performance.e.u(this);
    return true;
  }
  
  public Cursor query(Uri paramUri, String[] paramArrayOfString1, String paramString1, String[] paramArrayOfString2, String paramString2) {
    DropboxApplication.h1();
    Context context = getContext();
    DbxUserManager dbxUserManager = DropboxApplication.b1(context);
    g g = DropboxApplication.b0(context);
    if (this.a.compareAndSet(false, true)) {
      String[] arrayOfString = context.getPackageManager().getPackagesForUid(Binder.getCallingUid());
      dbxyzptlk.Ec.a.u2().p("calling.pkgs", Arrays.asList(arrayOfString)).o("uri", paramUri.toString()).i(g);
    } 
    b b = c(paramUri);
    if (b == null)
      return null; 
    a(b.readPermission(), context);
    return b.query(dbxUserManager, g, paramUri, paramArrayOfString1, paramString1, paramArrayOfString2, paramString2);
  }
  
  public int update(Uri paramUri, ContentValues paramContentValues, String paramString, String[] paramArrayOfString) {
    DropboxApplication.h1();
    b b = c(paramUri);
    if (b == null)
      return 0; 
    a(b.writePermission(), getContext());
    return b.update(paramUri, paramContentValues, paramString, paramArrayOfString);
  }
  
  public class a implements DbxUserManager.f {
    public final ContentResolver a;
    
    public a(SDKProvider this$0) {}
    
    public void a(com.dropbox.android.user.a param1a) {
      this.a.notifyChange(SDKProvider.b.ACCOUNT_INFO.uri(), null);
    }
  }
  
  public enum b {
    ACCOUNT_INFO("account_info", "com.dropbox.android.provider.ACCOUNT_INFO_READ", null, "vnd.android.cursor.item/vnd.dropbox.account_info", null) {
      public Uri insert(Uri param2Uri, ContentValues param2ContentValues) {
        return null;
      }
      
      public Cursor query(DbxUserManager param2DbxUserManager, g param2g, Uri param2Uri, String[] param2ArrayOfString1, String param2String1, String[] param2ArrayOfString2, String param2String2) {
        com.dropbox.android.user.a a1 = param2DbxUserManager.a();
        if (a1 == null)
          return null; 
        MatrixCursor matrixCursor = new MatrixCursor(new String[] { "uid" });
        Iterator<String> iterator = com.dropbox.android.user.a.s(a1).iterator();
        while (iterator.hasNext()) {
          matrixCursor.addRow(new Object[] { Long.valueOf(Long.parseLong(iterator.next())) });
        } 
        return (Cursor)matrixCursor;
      }
      
      public int update(Uri param2Uri, ContentValues param2ContentValues, String param2String, String[] param2ArrayOfString) {
        return 0;
      }
    },
    CAN_SHOW_GALLERY_POPUP("account_info", "com.dropbox.android.provider.ACCOUNT_INFO_READ", null, "vnd.android.cursor.item/vnd.dropbox.account_info", null),
    IS_ANY_USER_LOGGED_IN("account_info", "com.dropbox.android.provider.ACCOUNT_INFO_READ", null, "vnd.android.cursor.item/vnd.dropbox.account_info", null),
    IS_SAMSUNG_DOCS_AND_GALLERY_DEAL_DEVICE("is_samsung_docs_and_gallery_deal_device", null, null, "vnd.android.cursor.item/vnd.dropbox.is_samsung_docs_and_gallery_deal_device", null) {
      private static final String IS_DEAL_DEVICE = "is_deal_device";
      
      public Uri insert(Uri param2Uri, ContentValues param2ContentValues) {
        return null;
      }
      
      public Cursor query(DbxUserManager param2DbxUserManager, g param2g, Uri param2Uri, String[] param2ArrayOfString1, String param2String1, String[] param2ArrayOfString2, String param2String2) {
        MatrixCursor matrixCursor = new MatrixCursor(new String[] { "is_deal_device" });
        matrixCursor.addRow(new Object[] { Integer.valueOf(0) });
        return (Cursor)matrixCursor;
      }
      
      public int update(Uri param2Uri, ContentValues param2ContentValues, String param2String, String[] param2ArrayOfString) {
        return 0;
      }
    },
    IS_USER_LOGGED_IN("is_samsung_docs_and_gallery_deal_device", null, null, "vnd.android.cursor.item/vnd.dropbox.is_samsung_docs_and_gallery_deal_device", null);
    
    private static final b[] $VALUES;
    
    private final String mMimeType;
    
    private final String mPath;
    
    private final String mReadPermission;
    
    private final Uri mUri;
    
    private final String mWritePermission;
    
    static {
      $VALUES = a();
    }
    
    b(String param1String1, String param1String2, String param1String3, String param1String4) {
      this.mPath = param1String1;
      this.mUri = (new Uri.Builder()).scheme("content").authority("com.dropbox.android.provider.SDK").path(param1String1).build();
      this.mMimeType = param1String4;
      this.mReadPermission = param1String2;
      this.mWritePermission = param1String3;
    }
    
    public abstract Uri insert(Uri param1Uri, ContentValues param1ContentValues);
    
    public String mimeType() {
      return this.mMimeType;
    }
    
    public String path() {
      return this.mPath;
    }
    
    public abstract Cursor query(DbxUserManager param1DbxUserManager, g param1g, Uri param1Uri, String[] param1ArrayOfString1, String param1String1, String[] param1ArrayOfString2, String param1String2);
    
    public String readPermission() {
      return this.mReadPermission;
    }
    
    public abstract int update(Uri param1Uri, ContentValues param1ContentValues, String param1String, String[] param1ArrayOfString);
    
    public Uri uri() {
      return this.mUri;
    }
    
    public String writePermission() {
      return this.mWritePermission;
    }
    
    public enum a {
      public Uri insert(Uri param2Uri, ContentValues param2ContentValues) {
        return null;
      }
      
      public Cursor query(DbxUserManager param2DbxUserManager, g param2g, Uri param2Uri, String[] param2ArrayOfString1, String param2String1, String[] param2ArrayOfString2, String param2String2) {
        com.dropbox.android.user.a a1 = param2DbxUserManager.a();
        if (a1 == null)
          return null; 
        MatrixCursor matrixCursor = new MatrixCursor(new String[] { "uid" });
        Iterator<String> iterator = com.dropbox.android.user.a.s(a1).iterator();
        while (iterator.hasNext()) {
          matrixCursor.addRow(new Object[] { Long.valueOf(Long.parseLong(iterator.next())) });
        } 
        return (Cursor)matrixCursor;
      }
      
      public int update(Uri param2Uri, ContentValues param2ContentValues, String param2String, String[] param2ArrayOfString) {
        return 0;
      }
    }
    
    public enum b {
      private static final String IS_DEAL_DEVICE = "is_deal_device";
      
      public Uri insert(Uri param2Uri, ContentValues param2ContentValues) {
        return null;
      }
      
      public Cursor query(DbxUserManager param2DbxUserManager, g param2g, Uri param2Uri, String[] param2ArrayOfString1, String param2String1, String[] param2ArrayOfString2, String param2String2) {
        MatrixCursor matrixCursor = new MatrixCursor(new String[] { "is_deal_device" });
        matrixCursor.addRow(new Object[] { Integer.valueOf(0) });
        return (Cursor)matrixCursor;
      }
      
      public int update(Uri param2Uri, ContentValues param2ContentValues, String param2String, String[] param2ArrayOfString) {
        return 0;
      }
    }
    
    public enum c {
      private static final String CAN_SHOW = "can_show";
      
      private static final int DO_NOT_SHOW = 0;
      
      public Uri insert(Uri param2Uri, ContentValues param2ContentValues) {
        return null;
      }
      
      public Cursor query(DbxUserManager param2DbxUserManager, g param2g, Uri param2Uri, String[] param2ArrayOfString1, String param2String1, String[] param2ArrayOfString2, String param2String2) {
        MatrixCursor matrixCursor = new MatrixCursor(new String[] { "can_show" });
        matrixCursor.addRow(new Object[] { Integer.valueOf(0) });
        return (Cursor)matrixCursor;
      }
      
      public int update(Uri param2Uri, ContentValues param2ContentValues, String param2String, String[] param2ArrayOfString) {
        return 0;
      }
    }
    
    public enum d {
      private static final int HAS_USER = 1;
      
      private static final String LOGGED_IN = "logged_in";
      
      private static final int NO_USERS = 0;
      
      public Uri insert(Uri param2Uri, ContentValues param2ContentValues) {
        return null;
      }
      
      public Cursor query(DbxUserManager param2DbxUserManager, g param2g, Uri param2Uri, String[] param2ArrayOfString1, String param2String1, String[] param2ArrayOfString2, String param2String2) {
        boolean bool;
        if (param2DbxUserManager.a() == null) {
          bool = false;
        } else {
          bool = true;
        } 
        dbxyzptlk.Ec.a.q2().l("result", bool).i(param2g);
        MatrixCursor matrixCursor = new MatrixCursor(new String[] { "logged_in" });
        matrixCursor.addRow(new Object[] { Integer.valueOf(bool) });
        return (Cursor)matrixCursor;
      }
      
      public int update(Uri param2Uri, ContentValues param2ContentValues, String param2String, String[] param2ArrayOfString) {
        return 0;
      }
    }
    
    public enum e {
      public Uri insert(Uri param2Uri, ContentValues param2ContentValues) {
        return null;
      }
      
      public Cursor query(DbxUserManager param2DbxUserManager, g param2g, Uri param2Uri, String[] param2ArrayOfString1, String param2String1, String[] param2ArrayOfString2, String param2String2) {
        List<String> list = param2Uri.getPathSegments();
        byte b1 = 1;
        String str = list.get(1);
        com.dropbox.android.user.a a = param2DbxUserManager.a();
        if (a == null) {
          b1 = 0;
        } else if (a.q(str) == null) {
          b1 = -1;
        } 
        MatrixCursor matrixCursor = new MatrixCursor(new String[] { "logged_in" });
        matrixCursor.addRow(new Object[] { Integer.valueOf(b1) });
        return (Cursor)matrixCursor;
      }
      
      public int update(Uri param2Uri, ContentValues param2ContentValues, String param2String, String[] param2ArrayOfString) {
        return 0;
      }
    }
  }
  
  public enum a {
    public Uri insert(Uri param1Uri, ContentValues param1ContentValues) {
      return null;
    }
    
    public Cursor query(DbxUserManager param1DbxUserManager, g param1g, Uri param1Uri, String[] param1ArrayOfString1, String param1String1, String[] param1ArrayOfString2, String param1String2) {
      com.dropbox.android.user.a a1 = param1DbxUserManager.a();
      if (a1 == null)
        return null; 
      MatrixCursor matrixCursor = new MatrixCursor(new String[] { "uid" });
      Iterator<String> iterator = com.dropbox.android.user.a.s(a1).iterator();
      while (iterator.hasNext()) {
        matrixCursor.addRow(new Object[] { Long.valueOf(Long.parseLong(iterator.next())) });
      } 
      return (Cursor)matrixCursor;
    }
    
    public int update(Uri param1Uri, ContentValues param1ContentValues, String param1String, String[] param1ArrayOfString) {
      return 0;
    }
  }
  
  public enum b {
    private static final String IS_DEAL_DEVICE = "is_deal_device";
    
    public Uri insert(Uri param1Uri, ContentValues param1ContentValues) {
      return null;
    }
    
    public Cursor query(DbxUserManager param1DbxUserManager, g param1g, Uri param1Uri, String[] param1ArrayOfString1, String param1String1, String[] param1ArrayOfString2, String param1String2) {
      MatrixCursor matrixCursor = new MatrixCursor(new String[] { "is_deal_device" });
      matrixCursor.addRow(new Object[] { Integer.valueOf(0) });
      return (Cursor)matrixCursor;
    }
    
    public int update(Uri param1Uri, ContentValues param1ContentValues, String param1String, String[] param1ArrayOfString) {
      return 0;
    }
  }
  
  public enum c {
    private static final String CAN_SHOW = "can_show";
    
    private static final int DO_NOT_SHOW = 0;
    
    public Uri insert(Uri param1Uri, ContentValues param1ContentValues) {
      return null;
    }
    
    public Cursor query(DbxUserManager param1DbxUserManager, g param1g, Uri param1Uri, String[] param1ArrayOfString1, String param1String1, String[] param1ArrayOfString2, String param1String2) {
      MatrixCursor matrixCursor = new MatrixCursor(new String[] { "can_show" });
      matrixCursor.addRow(new Object[] { Integer.valueOf(0) });
      return (Cursor)matrixCursor;
    }
    
    public int update(Uri param1Uri, ContentValues param1ContentValues, String param1String, String[] param1ArrayOfString) {
      return 0;
    }
  }
  
  public enum d {
    private static final int HAS_USER = 1;
    
    private static final String LOGGED_IN = "logged_in";
    
    private static final int NO_USERS = 0;
    
    public Uri insert(Uri param1Uri, ContentValues param1ContentValues) {
      return null;
    }
    
    public Cursor query(DbxUserManager param1DbxUserManager, g param1g, Uri param1Uri, String[] param1ArrayOfString1, String param1String1, String[] param1ArrayOfString2, String param1String2) {
      boolean bool;
      if (param1DbxUserManager.a() == null) {
        bool = false;
      } else {
        bool = true;
      } 
      dbxyzptlk.Ec.a.q2().l("result", bool).i(param1g);
      MatrixCursor matrixCursor = new MatrixCursor(new String[] { "logged_in" });
      matrixCursor.addRow(new Object[] { Integer.valueOf(bool) });
      return (Cursor)matrixCursor;
    }
    
    public int update(Uri param1Uri, ContentValues param1ContentValues, String param1String, String[] param1ArrayOfString) {
      return 0;
    }
  }
  
  public enum e {
    public Uri insert(Uri param1Uri, ContentValues param1ContentValues) {
      return null;
    }
    
    public Cursor query(DbxUserManager param1DbxUserManager, g param1g, Uri param1Uri, String[] param1ArrayOfString1, String param1String1, String[] param1ArrayOfString2, String param1String2) {
      List<String> list = param1Uri.getPathSegments();
      byte b1 = 1;
      String str = list.get(1);
      com.dropbox.android.user.a a = param1DbxUserManager.a();
      if (a == null) {
        b1 = 0;
      } else if (a.q(str) == null) {
        b1 = -1;
      } 
      MatrixCursor matrixCursor = new MatrixCursor(new String[] { "logged_in" });
      matrixCursor.addRow(new Object[] { Integer.valueOf(b1) });
      return (Cursor)matrixCursor;
    }
    
    public int update(Uri param1Uri, ContentValues param1ContentValues, String param1String, String[] param1ArrayOfString) {
      return 0;
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\android\provider\SDKProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */