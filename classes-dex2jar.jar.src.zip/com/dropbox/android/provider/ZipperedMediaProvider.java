package com.dropbox.android.provider;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.res.Resources;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.database.MergeCursor;
import android.net.Uri;
import android.util.SparseArray;
import dbxyzptlk.CC.p;
import dbxyzptlk.CC.v;
import dbxyzptlk.EC.G;
import dbxyzptlk.Fe.b;
import dbxyzptlk.eh.e;
import dbxyzptlk.w6.V0;
import dbxyzptlk.x9.x;
import io.sentry.android.core.performance.e;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.Locale;
import java.util.TreeMap;

public class ZipperedMediaProvider extends ContentProvider {
  public static final Uri a = (new Uri.Builder()).scheme("content").authority("com.dropbox.android.ZipperedMediaProvider").build();
  
  public static String a(Calendar paramCalendar1, Calendar paramCalendar2, Resources paramResources) {
    p.o(paramCalendar1);
    p.o(paramCalendar2);
    p.o(paramResources);
    if (paramCalendar2.getTimeInMillis() <= 86400000L)
      return paramResources.getString(V0.date_bucket_unknown); 
    if (!paramCalendar1.after(paramCalendar2))
      return paramResources.getString(V0.date_bucket_today); 
    Calendar calendar2 = (Calendar)b.c(paramCalendar1.clone(), Calendar.class);
    calendar2.add(5, -1);
    if (!calendar2.after(paramCalendar2))
      return paramResources.getString(V0.date_bucket_yesterday); 
    Calendar calendar1 = (Calendar)b.c(paramCalendar1.clone(), Calendar.class);
    calendar1.add(5, -6);
    return !calendar1.after(paramCalendar2) ? (new SimpleDateFormat("EEEE", Locale.getDefault())).format(paramCalendar2.getTime()) : (((Locale.getDefault().equals(Locale.US) || Locale.getDefault().equals(Locale.CANADA)) && paramCalendar1.get(1) == paramCalendar2.get(1)) ? (new SimpleDateFormat("MMMM d", Locale.getDefault())).format(paramCalendar2.getTime()) : DateFormat.getDateInstance(1, Locale.getDefault()).format(paramCalendar2.getTime()));
  }
  
  public SparseArray<String> b(Uri paramUri, boolean paramBoolean, int paramInt) {
    boolean bool;
    String[] arrayOfString;
    if (paramBoolean) {
      arrayOfString = new String[3];
      arrayOfString[0] = "video_id";
      arrayOfString[1] = "kind";
      arrayOfString[2] = "_data";
    } else {
      arrayOfString = new String[3];
      arrayOfString[0] = "image_id";
      arrayOfString[1] = "kind";
      arrayOfString[2] = "_data";
    } 
    Cursor cursor = getContext().getContentResolver().query(paramUri, arrayOfString, null, null, null);
    if (cursor != null) {
      bool = cursor.getCount();
    } else {
      bool = false;
    } 
    SparseArray<String> sparseArray = new SparseArray(bool);
    if (cursor != null) {
      while (cursor.moveToNext()) {
        if (cursor.getInt(1) == paramInt || sparseArray.get(cursor.getInt(0)) == null)
          sparseArray.put(cursor.getInt(0), cursor.getString(2)); 
      } 
      cursor.close();
    } 
    return sparseArray;
  }
  
  public int delete(Uri paramUri, String paramString, String[] paramArrayOfString) {
    return 0;
  }
  
  public String getType(Uri paramUri) {
    return null;
  }
  
  public Uri insert(Uri paramUri, ContentValues paramContentValues) {
    return null;
  }
  
  public boolean onCreate() {
    e.t(this);
    e.u(this);
    return true;
  }
  
  public Cursor query(Uri paramUri, String[] paramArrayOfString1, String paramString1, String[] paramArrayOfString2, String paramString2) {
    a a;
    int j;
    ArrayList<a> arrayList1 = G.h();
    if (paramArrayOfString1 != null) {
      j = paramArrayOfString1.length;
      for (byte b = 0; b < j; b++) {
        String str = paramArrayOfString1[b];
        if (str != null && str.equals("mini_thumb_path")) {
          b = 1;
          // Byte code: goto -> 56
        } 
      } 
    } 
    int i = 3;
    for (x x : x.values()) {
      Cursor cursor = getContext().getContentResolver().query(x.getUri(), null, null, null, "date_added DESC");
      if (cursor != null)
        arrayList1.add(new a(this, x, cursor, b(x.getThumbUri(), x.isVideo(), i))); 
    } 
    paramArrayOfString2 = new String[9];
    paramArrayOfString2[0] = "_id";
    paramArrayOfString2[1] = "_data";
    paramArrayOfString2[2] = "date_modified";
    paramArrayOfString2[3] = "date_added";
    paramArrayOfString2[4] = "content_uri";
    paramArrayOfString2[5] = "thumb_path";
    paramArrayOfString2[6] = "vid_duration";
    paramArrayOfString2[7] = "display_name";
    paramArrayOfString2[8] = "_cursor_type_tag";
    TreeMap<Object, Object> treeMap = new TreeMap<>();
    Iterator<a> iterator = arrayList1.iterator();
    i = 0;
    while (true) {
      j = i;
      if (iterator.hasNext()) {
        a = iterator.next();
        i += a.b.getCount();
        a.b.moveToFirst();
        continue;
      } 
      break;
    } 
    while (j > 0) {
      a a1;
      String str1;
      long l1;
      Iterator<a> iterator1 = arrayList1.iterator();
      iterator = null;
      while (iterator1.hasNext()) {
        a = iterator1.next();
        if (!a.b.isAfterLast()) {
          if (a1 == null)
            continue; 
          Cursor cursor1 = a.b;
          String str8 = cursor1.getString(cursor1.getColumnIndex("date_added"));
          Cursor cursor2 = a1.b;
          String str9 = cursor2.getString(cursor2.getColumnIndex("date_added"));
          if ((str8 != null) ? ((str9 != null) ? (str8.compareTo(str9) > 0) : (str8 != null)) : (str8 != null))
            continue; 
        } 
        continue;
        a1 = a;
      } 
      Cursor cursor = a1.b;
      String str2 = cursor.getString(cursor.getColumnIndex("_data"));
      i = cursor.getInt(cursor.getColumnIndex("_id"));
      String str5 = cursor.getString(cursor.getColumnIndex("_data"));
      String str4 = cursor.getString(cursor.getColumnIndex("date_modified"));
      String str3 = cursor.getString(cursor.getColumnIndex("date_added"));
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(a1.a.getUri());
      stringBuilder.append("/");
      stringBuilder.append(cursor.getInt(cursor.getColumnIndex("_id")));
      String str7 = stringBuilder.toString();
      Object object = a1.c.get(cursor.getInt(cursor.getColumnIndex("_id")));
      boolean bool = a1.a.isVideo();
      long l2 = 0L;
      if (bool) {
        l1 = cursor.getLong(cursor.getColumnIndex("duration"));
      } else {
        l1 = 0L;
      } 
      String str6 = cursor.getString(cursor.getColumnIndex("_display_name"));
      if (a1.a.isVideo()) {
        str1 = "_tag_video";
      } else {
        str1 = "_tag_photo";
      } 
      if (!v.b(str2)) {
        String str = cursor.getString(cursor.getColumnIndex("date_added"));
        str2 = str;
        if (str == null)
          str2 = cursor.getString(cursor.getColumnIndex("date_modified")); 
        if (str2 != null)
          l2 = Long.valueOf(str2).longValue() * 1000L; 
        Calendar calendar1 = Calendar.getInstance();
        calendar1.setTimeInMillis(l2);
        calendar1.set(11, 0);
        calendar1.set(12, 0);
        calendar1.set(13, 0);
        calendar1.set(14, 0);
        Long long_ = Long.valueOf(calendar1.getTimeInMillis());
        if (treeMap.get(long_) == null)
          treeMap.put(long_, new MatrixCursor(paramArrayOfString2)); 
        ((MatrixCursor)treeMap.get(long_)).addRow(new Object[] { Integer.valueOf(i), str5, str4, str3, str7, object, Long.valueOf(l1), str6, str1 });
      } 
      cursor.moveToNext();
      j--;
    } 
    iterator = arrayList1.iterator();
    while (iterator.hasNext())
      ((a)iterator.next()).b.close(); 
    ArrayList<Cursor> arrayList = G.h();
    Calendar calendar = Calendar.getInstance();
    calendar.set(11, 0);
    calendar.set(12, 0);
    calendar.set(13, 0);
    calendar.set(14, 0);
    for (Long long_ : treeMap.descendingKeySet()) {
      Calendar calendar1 = Calendar.getInstance();
      calendar1.setTimeInMillis(long_.longValue());
      arrayList.add(e.createSeparator(a(calendar, calendar1, getContext().getResources())));
      arrayList.add((Cursor)treeMap.get(long_));
    } 
    if (arrayList.isEmpty())
      arrayList.add(new MatrixCursor(paramArrayOfString2)); 
    return (Cursor)new MergeCursor(arrayList.<Cursor>toArray(new Cursor[arrayList.size()]));
  }
  
  public int update(Uri paramUri, ContentValues paramContentValues, String paramString, String[] paramArrayOfString) {
    return 0;
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\android\provider\ZipperedMediaProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */