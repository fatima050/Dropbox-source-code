package com.dropbox.android.dauth;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.a;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.o;
import com.dropbox.android.DropboxApplication;
import com.dropbox.android.activity.OpenWithDauthInterstitialFragment;
import com.dropbox.android.activity.base.BaseIdentityActivity;
import com.dropbox.android.user.a;
import com.dropbox.common.activity.BaseActivity;
import com.dropbox.common.safeintentstarter.NoHandlerForIntentException;
import com.dropbox.dbapp.android.util.UIHelpers;
import com.dropbox.internalclient.UserApi;
import com.dropbox.product.dbapp.openwith.SessionId;
import com.google.common.collect.j;
import com.google.common.collect.m;
import dbxyzptlk.C7.k;
import dbxyzptlk.C7.n;
import dbxyzptlk.C7.o;
import dbxyzptlk.CC.p;
import dbxyzptlk.CC.t;
import dbxyzptlk.CC.v;
import dbxyzptlk.Df.C;
import dbxyzptlk.Df.g;
import dbxyzptlk.Df.x;
import dbxyzptlk.E6.k3;
import dbxyzptlk.EC.G;
import dbxyzptlk.Ec.a;
import dbxyzptlk.Ec.g;
import dbxyzptlk.Fc.Z2;
import dbxyzptlk.Fe.b;
import dbxyzptlk.He.c;
import dbxyzptlk.K6.a;
import dbxyzptlk.Ny.L;
import dbxyzptlk.Ny.f;
import dbxyzptlk.Wa.b;
import dbxyzptlk.Z2.a;
import dbxyzptlk.bf.a;
import dbxyzptlk.lq.d;
import dbxyzptlk.lq.f;
import dbxyzptlk.lq.j;
import dbxyzptlk.oj.c;
import dbxyzptlk.pc.d0;
import dbxyzptlk.pc.u0;
import dbxyzptlk.qc.A;
import dbxyzptlk.qc.d;
import dbxyzptlk.rf.e;
import dbxyzptlk.sL.a;
import dbxyzptlk.w6.Q0;
import dbxyzptlk.w6.R0;
import dbxyzptlk.w6.V0;
import dbxyzptlk.yf.e;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class DelegatedAuthActivity extends BaseIdentityActivity implements f, OpenWithDauthInterstitialFragment.d, a {
  public static final ComponentName L = new ComponentName("com.dropbox.android", "com.dropbox.android.activity.auth.DropboxAuth");
  
  public View A;
  
  public boolean B = false;
  
  public boolean C = false;
  
  public boolean D = false;
  
  public String E = null;
  
  public List<A> F;
  
  public String G;
  
  public boolean H = false;
  
  public g I;
  
  public LayoutInflater J;
  
  public c K;
  
  public final j d = j.b();
  
  public String e;
  
  public String f;
  
  public String g;
  
  public String h;
  
  public String i;
  
  public String j;
  
  public String k = "";
  
  public Set<String> l;
  
  public b m;
  
  public Drawable n;
  
  public SessionId o;
  
  public View p;
  
  public View q;
  
  public ViewGroup r;
  
  public View s;
  
  public TextView t;
  
  public Button u;
  
  public Button v;
  
  public WebView w;
  
  public View x;
  
  public View y;
  
  public View z;
  
  public static Intent g5(Intent paramIntent, n paramn) {
    paramIntent.putExtra("ACCESS_TOKEN", paramn.d());
    paramIntent.putExtra("ACCESS_SECRET", paramn.b());
    paramIntent.putExtra("UID", String.valueOf(paramn.e()));
    if (paramn.c() != null)
      paramIntent.putExtra("AUTH_STATE", paramn.c()); 
    if (paramn.a() != null)
      paramIntent.putExtra("AUTH_QUERY_RESULTS", paramn.a()); 
    return paramIntent;
  }
  
  public static r r5(a parama, g paramg, String paramString1, String paramString2, SessionId paramSessionId) {
    d0 d0;
    b.a();
    p.o(parama);
    p.o(paramg);
    p.o(paramString2);
    p.o(paramString1);
    f f1 = parama.k().b();
    if (paramSessionId != null) {
      p.j(paramString2.isEmpty() ^ true, "Assert failed: %1$s", "Provided a sessionId without desired User!");
      d0 = parama.q(paramString2);
      if (d0 == null) {
        p.e(parama.t(), "Assert failed.");
        return (r)new e();
      } 
      L l = d0.J1();
      return (r)new f(paramSessionId, d0.e(), l, paramString1, f1);
    } 
    return (r)new g(f1, paramString1, (g)d0);
  }
  
  public void A5(MotionEvent paramMotionEvent) {
    if ((paramMotionEvent.getFlags() & 0x1) != 0 && paramMotionEvent.getAction() == 1) {
      ArrayList<String> arrayList = G.h();
      for (PackageInfo packageInfo : getPackageManager().getInstalledPackages(4096)) {
        int i = packageInfo.applicationInfo.flags;
        if ((i & 0x1) == 0 && (i & 0x200000) == 0) {
          String[] arrayOfString = packageInfo.requestedPermissions;
          if (arrayOfString != null && c.b((Object[])arrayOfString, "android.permission.SYSTEM_ALERT_WINDOW"))
            arrayList.add(packageInfo.packageName); 
        } 
      } 
      a.D().p("installed_overlay_apps", arrayList).i(this.I);
      a.d("obscured by  %s", new Object[] { arrayList });
    } 
  }
  
  public OpenWithDauthInterstitialFragment.e B0() {
    if (this.m == null)
      return null; 
    p.o(this.n);
    OpenWithDauthInterstitialFragment.e e = (new OpenWithDauthInterstitialFragment.e()).l(this.n).n(this.m.d0()).p(this.m.c0()).m(this.m.a0()).k(getString(V0.auth_interstitial_next));
    SessionId sessionId = this.o;
    if (sessionId != null) {
      p.e(sessionId.d().equals(SessionId.a.NO_SCREEN) ^ true, "Assert failed.");
      e.o(getString(V0.auth_interstitial_not_now));
    } 
    return e;
  }
  
  public final Intent B5(String paramString1, String paramString2) {
    Intent intent = new Intent("android.intent.action.VIEW");
    h5(intent);
    intent.addCategory("android.intent.category.BROWSABLE");
    intent.addCategory("android.intent.category.DEFAULT");
    intent.setClassName(paramString1, paramString2);
    intent.setFlags(603979776);
    return intent;
  }
  
  public final Intent C5() {
    Intent intent = new Intent("android.intent.action.VIEW");
    h5(intent);
    intent.setFlags(603979776);
    return intent;
  }
  
  public final void D5(d0 paramd0) {
    this.q.setOnClickListener((View.OnClickListener)new b(this, paramd0));
  }
  
  public final void E5() {
    this.q.setOnClickListener((View.OnClickListener)new c(this));
  }
  
  public final void F5() {
    p.o(this.m);
    p.o(this.n);
    OpenWithDauthInterstitialFragment openWithDauthInterstitialFragment = OpenWithDauthInterstitialFragment.o2((BaseActivity)this);
    o o = getSupportFragmentManager().q();
    o.u(Q0.dauth_interstitial_frag, (Fragment)openWithDauthInterstitialFragment);
    o.k();
  }
  
  public final void G5() {
    boolean bool1;
    a a1 = z4();
    p.o(a1);
    p.o(this.F);
    int i = this.F.size();
    boolean bool2 = true;
    if (i > 0) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    p.e(bool1, "Assert failed.");
    this.x.setVisibility(8);
    this.z.setVisibility(8);
    this.A.setVisibility(8);
    this.y.setVisibility(0);
    if (this.F.size() == 1) {
      A a2 = this.F.get(0);
      d0 d0 = a1.q(a2.f0());
      H5(a2, this.k.isEmpty());
      if (d0 != null) {
        D5(d0);
      } else {
        p.e(k3.a(a1), "Assert failed.");
        E5();
      } 
    } else {
      if (this.F.size() == 2) {
        bool1 = bool2;
      } else {
        bool1 = false;
      } 
      p.e(bool1, "Assert failed.");
      p.j(this.k.isEmpty(), "Assert failed: %1$s", "Should not have 2 account options when uid desired!");
      p.e(k3.a(a1), "Assert failed.");
      I5();
    } 
  }
  
  public final void H5(A paramA, boolean paramBoolean) {
    this.p.setVisibility(0);
    this.r.setVisibility(8);
    this.t.setVisibility(8);
    ((TextView)findViewById(Q0.dauth_one_account_email)).setText(paramA.d0());
    if (paramBoolean) {
      this.s.setVisibility(0);
    } else {
      this.s.setVisibility(8);
    } 
  }
  
  public final void I5() {
    boolean bool;
    if (this.F.size() == 2) {
      bool = true;
    } else {
      bool = false;
    } 
    p.d(bool);
    this.p.setVisibility(8);
    this.r.setVisibility(0);
    this.t.setVisibility(0);
    this.t.setText(V0.auth_choose_account);
    this.r.removeAllViews();
    this.J.inflate(R0.dauth_user_chooser_divider, this.r, true);
    i5(this.r, this.F);
    this.J.inflate(R0.dauth_user_chooser_divider, this.r, true);
  }
  
  public void J2() {
    throw new IllegalStateException("Should never be called!");
  }
  
  public final void J5(d0 paramd0) {
    n n;
    a.A().i(this.I);
    d d1 = new d(paramd0.u2(), paramd0.C().d());
    if (this.H) {
      n = new n(this, (a)d1, this.e, this.G);
      n.i(1);
      n.execute((Object[])new Void[0]);
    } else {
      o o = new o(this, (a)n, this.e, this.i, this.j);
      o.i(1);
      o.execute((Object[])new Void[0]);
    } 
  }
  
  public void K(String paramString) {
    p.o(paramString);
    d0 d0 = z4().q(paramString);
    p.o(d0);
    J5(d0);
  }
  
  public final void K5(n paramn) {
    String str = this.g;
    if (str != null) {
      Intent intent1 = g5(B5(str, this.h), paramn);
      try {
        startActivity(intent1);
        a.E().o("calling.pkg", this.g).o("calling.class", this.h).o("consumer.key", this.e).i(this.I);
        finish();
      } catch (ActivityNotFoundException activityNotFoundException2) {
        a.C().o("calling.pkg", this.g).o("calling.class", this.h).o("consumer.key", this.e).o("error", activityNotFoundException2.getMessage()).i(this.I);
        j5();
      } 
      return;
    } 
    Intent intent = g5(C5(), (n)activityNotFoundException2);
    try {
      if (!l5()) {
        j5();
        return;
      } 
    } catch (NoHandlerForIntentException noHandlerForIntentException) {
    
    } catch (ActivityNotFoundException activityNotFoundException1) {}
    this.K.c((Context)this, (Intent)activityNotFoundException1);
    a.E().o("consumer.key", this.e).i(this.I);
    finish();
  }
  
  public void X3(Bundle paramBundle, boolean paramBoolean) {
    if (this.B)
      return; 
    List<A> list = s5();
    this.F = list;
    if (list.size() == 0) {
      (new Z2()).g(this.I);
      w5();
      finish();
      return;
    } 
    if (paramBoolean) {
      String str = this.E;
      if (str != null) {
        K(str);
        this.E = null;
      } 
    } 
  }
  
  public void a4() {
    finish();
  }
  
  public final Intent h5(Intent paramIntent) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("db-");
    stringBuilder.append(this.e);
    stringBuilder.append("://");
    stringBuilder.append(1);
    stringBuilder.append("/connect");
    paramIntent.setData(Uri.parse(stringBuilder.toString()));
    return paramIntent;
  }
  
  public final void i5(ViewGroup paramViewGroup, List<A> paramList) {
    for (byte b1 = 0; b1 < paramList.size(); b1++) {
      String str;
      A a1 = paramList.get(b1);
      View view = this.J.inflate(R0.dauth_user_item, paramViewGroup, false);
      TextView textView2 = (TextView)view.findViewById(Q0.title);
      TextView textView1 = (TextView)view.findViewById(Q0.text);
      if (a1.e0() == d.BUSINESS) {
        a.b b2 = z4().l();
        if (b2 != null) {
          String str1 = b2.i();
        } else {
          b2 = null;
        } 
        a.b b3 = b2;
        if (b2 == null)
          str = getString(d.settings_business_title); 
      } else {
        str = getString(d.settings_personal_title);
      } 
      textView2.setText(str);
      textView1.setText(a1.d0());
      view.setOnClickListener((View.OnClickListener)new k(this, a1));
      paramViewGroup.addView(view);
      if (b1 != paramList.size() - 1)
        this.J.inflate(R0.dauth_user_item_divider, paramViewGroup, true); 
    } 
  }
  
  public void j2() {
    String str;
    if (this.k.isEmpty()) {
      str = null;
    } else {
      str = "com.dropbox.intent.action.DROPBOX_LOGIN";
    } 
    startActivity(a.d((Context)this, getIntent(), true, str));
  }
  
  public final void j5() {
    k5(getString(V0.auth_improperly_configured));
  }
  
  public final void k5(String paramString) {
    this.B = true;
    g g1 = new g((Context)this);
    g1.setCancelable(false);
    g1.setTitle(V0.auth_error_dialog_title);
    g1.setMessage(paramString);
    g1.setPositiveButton(V0.ok, (DialogInterface.OnClickListener)new d(this));
    g1.show();
    a.C().o("msg", paramString).i(this.I);
  }
  
  public final boolean l5() {
    if (Build.VERSION.SDK_INT >= 30)
      return true; 
    Intent intent = C5();
    List list = getPackageManager().queryIntentActivities(intent, 0);
    if (list == null || list.size() == 0) {
      a.j("Authenticating API app has not set up proper intent filter for URI scheme.", new Object[0]);
      return false;
    } 
    if (list.size() > 1) {
      a.j("Multiple entries are registered for URI scheme for authenticating API app.", new Object[0]);
      a.h(new Throwable("Multiple activities registered for URI scheme"));
      return false;
    } 
    return true;
  }
  
  public final void m5(o paramo) {
    Intent intent = new Intent();
    String str = paramo.b();
    if (str != null) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("code=");
      stringBuilder.append(str);
      stringBuilder.append("&tk=https://api.dropbox.com/oauth2/token");
      intent.putExtra("ResonponseUrlQueryParams", stringBuilder.toString());
      setResult(-1, intent);
    } else {
      setResult(0, intent);
    } 
    finish();
  }
  
  public j n2() {
    return this.d;
  }
  
  public final void n5() {
    g g1 = new g((Context)this);
    g1.setTitle(V0.auth_error_dialog_title);
    g1.setMessage(V0.auth_retry_connect_info);
    g1.setPositiveButton(V0.ok, null);
    g1.show();
  }
  
  public final void o5() {
    this.z.setVisibility(8);
    this.y.setVisibility(8);
    this.A.setVisibility(0);
    this.x.setVisibility(8);
  }
  
  @SuppressLint({"MissingSuperCall"})
  public void onBackPressed() {
    t5();
  }
  
  public void onCreate(Bundle paramBundle) {
    if (C.a(getResources())) {
      int i = getResources().getDimensionPixelSize(e.dbx_action_bar_size);
      UIHelpers.c((Activity)this, (int)((getResources().getDisplayMetrics()).density * 431.0F) + i, -1);
    } 
    super.onCreate(paramBundle);
    if (w4())
      return; 
    this.K = DropboxApplication.L0((Context)this);
    this.J = LayoutInflater.from((Context)this);
    this.I = DropboxApplication.b0((Context)this);
    if (paramBundle != null) {
      this.E = paramBundle.getString("SIS_KEY_PENDINGAUTHUID");
      this.D = paramBundle.getBoolean("SIS_KEY_SHOWING_APP_INFO");
    } 
    Intent intent = getIntent();
    String str1 = intent.getAction();
    String str3 = intent.getStringExtra("AuthorizeUrlQueryParams");
    if (str3 != null) {
      try {
        str3 = URLDecoder.decode(str3, "UTF-8");
        Map map = t.g("&").l("=").a(str3);
        this.e = (String)map.get("client_id");
        this.G = (String)map.get("redirect_uri");
        this.k = v.e(intent.getStringExtra("UserId"));
        this.f = "";
        this.i = "oauth2:";
        this.H = true;
      } catch (UnsupportedEncodingException unsupportedEncodingException) {
        a.i(unsupportedEncodingException, "Encoding 'UTF-8' is not supported.", new Object[0]);
      } 
    } else {
      this.e = intent.getStringExtra("CONSUMER_KEY");
      this.f = intent.getStringExtra("CONSUMER_SIG");
      this.g = intent.getStringExtra("CALLING_PACKAGE");
      this.k = v.e(intent.getStringExtra("DESIRED_UID"));
      intent.getStringExtra("TARGET_SDK_VERSION");
      intent.getStringExtra("DROPBOX_SDK_JAVA_VERSION");
    } 
    String[] arrayOfString = intent.getStringArrayExtra("ALREADY_AUTHED_UIDS");
    if (arrayOfString != null) {
      this.l = (Set<String>)m.E((Object[])arrayOfString);
    } else {
      this.l = (Set<String>)m.H();
    } 
    String str2 = getIntent().getStringExtra("SESSION_ID");
    if (str2 != null)
      try {
        if (!this.k.isEmpty()) {
          this.o = SessionId.a(str2);
        } else {
          sessionIdException = new SessionId.SessionIdException();
          this("Provided a sessionId without desired User!");
          throw sessionIdException;
        } 
      } catch (com.dropbox.product.dbapp.openwith.SessionId.SessionIdException sessionIdException) {
        a.k((Throwable)sessionIdException, "SessionID decode failed", new Object[0]);
        j5();
        A4(paramBundle);
        return;
      }  
    if (!this.k.isEmpty() && this.l.contains(this.k)) {
      a.j("AlreadyAuthedUids contain DesiredUid", new Object[0]);
      j5();
      A4(paramBundle);
      return;
    } 
    if (this.e == null || (this.f == null && !this.H)) {
      a.j("App trying to authenticate without setting a consumer key or sig.", new Object[0]);
      j5();
      A4(paramBundle);
      return;
    } 
    if ("com.dropbox.android.AUTHENTICATE_V1".equals(sessionIdException)) {
      if (this.g != null)
        this.h = "com.dropbox.client2.android.AuthActivity"; 
    } else if ("com.dropbox.android.AUTHENTICATE_V2".equals(sessionIdException)) {
      this.h = intent.getStringExtra("CALLING_CLASS");
      this.i = intent.getStringExtra("AUTH_STATE");
      this.j = intent.getStringExtra("AUTH_QUERY_PARAMS");
      if (this.g == null || this.h == null) {
        a.j("App trying to authenticate without setting calling package, class, or state.", new Object[0]);
        j5();
        A4(paramBundle);
        return;
      } 
    } else if (!this.H) {
      j5();
      A4(paramBundle);
      a.j("Unknown authentication action: %s", new Object[] { sessionIdException });
      return;
    } 
    if (!this.H && !l5()) {
      j5();
      A4(paramBundle);
      return;
    } 
    setContentView(R0.auth_screen);
    this.p = findViewById(Q0.one_account_layout);
    this.q = findViewById(Q0.dauth_one_account_allow_button);
    this.r = (ViewGroup)findViewById(Q0.multi_account_layout);
    this.s = findViewById(Q0.dauth_other_account);
    this.t = (TextView)findViewById(Q0.dauth_account_selector_label);
    this.u = (Button)findViewById(Q0.button_cancel);
    this.v = (Button)findViewById(Q0.button_retry);
    this.w = (WebView)findViewById(Q0.app_info);
    this.x = findViewById(Q0.auth_progress_layout);
    this.y = findViewById(Q0.auth_layout);
    this.z = findViewById(Q0.retry_layout);
    this.A = findViewById(Q0.dauth_interstitial_frag);
    this.w.setWebViewClient((WebViewClient)new h(this));
    this.s.setOnClickListener((View.OnClickListener)new i(this));
    this.u.setOnClickListener((View.OnClickListener)new j(this));
    this.v.setOnClickListener((View.OnClickListener)new k(this));
    this.q.setOnTouchListener((View.OnTouchListener)new l(this));
    A4(paramBundle);
  }
  
  public Dialog onCreateDialog(int paramInt) {
    if (paramInt != 1)
      return null; 
    a a1 = e.a((Context)this, getString(V0.auth_please_wait));
    a1.setCancelable(false);
    return (Dialog)a1;
  }
  
  public void onPause() {
    super.onPause();
    this.C = false;
  }
  
  public void onResumeFragments() {
    super.onResumeFragments();
    this.C = true;
    if (this.B)
      return; 
    if (this.y.getVisibility() == 0)
      return; 
    if (this.D) {
      z5();
      return;
    } 
    if (this.H) {
      z5();
      return;
    } 
    r r = r5(z4(), this.I, this.g, this.k, this.o);
    getSupportLoaderManager().f(2, null, (a.a)new a(this, r));
  }
  
  public void onSaveInstanceState(Bundle paramBundle) {
    super.onSaveInstanceState(paramBundle);
    paramBundle.putString("SIS_KEY_PENDINGAUTHUID", this.E);
    paramBundle.putBoolean("SIS_KEY_SHOWING_APP_INFO", this.D);
  }
  
  public final void p5() {
    if (this.H) {
      Intent intent1 = new Intent();
      intent1.putExtra("ResonponseUrlQueryParams", "error=access_denied");
      setResult(0, intent1);
      finish();
      return;
    } 
    Intent intent = new Intent("android.intent.action.VIEW");
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("db-");
    stringBuilder.append(this.e);
    stringBuilder.append("://");
    stringBuilder.append(1);
    stringBuilder.append("/error");
    intent.setData(Uri.parse(stringBuilder.toString()));
    intent.setFlags(603979776);
    try {
      this.K.c((Context)this, intent);
    } catch (NoHandlerForIntentException noHandlerForIntentException) {
      x.f((Context)this, V0.cannot_open_browser_error);
    } catch (ActivityNotFoundException activityNotFoundException) {
      a.C().o("calling.class", this.h).o("consumer.key", this.e).o("error", activityNotFoundException.getMessage()).i(this.I);
      j5();
    } 
    finish();
  }
  
  public final OpenWithDauthInterstitialFragment q5() {
    return (OpenWithDauthInterstitialFragment)getSupportFragmentManager().l0(Q0.dauth_interstitial_frag);
  }
  
  public final List<A> s5() {
    a a1 = z4();
    p.o(a1);
    if (!this.k.isEmpty()) {
      A a2 = a1.g(this.k);
      return (List<A>)((a2 != null) ? j.J(a2) : j.H());
    } 
    ArrayList<A> arrayList = G.h();
    for (A a2 : a1.a()) {
      if (!this.l.contains(a2.f0()))
        arrayList.add(a2); 
    } 
    return arrayList;
  }
  
  public void t1(int paramInt1, int paramInt2, Intent paramIntent) {
    if (paramInt1 == 1 && paramInt2 == -1 && paramIntent != null) {
      String str = paramIntent.getExtras().getString("EXTRA_LOGGED_IN_USER_ID");
      if (!v.b(str)) {
        d0 d0 = z4().q(str);
        if (d0 == null) {
          this.E = str;
        } else {
          J5(d0);
        } 
      } 
    } 
  }
  
  public final void t5() {
    a.B().i(this.I);
    p5();
  }
  
  public final void u5(d0 paramd0) {
    p.o(paramd0);
    J5(paramd0);
  }
  
  public final void v5() {
    startActivityForResult(a.a((Context)this, "com.dropbox.intent.action.DROPBOX_LOGIN_SECOND_ACCOUNT", false), 1);
  }
  
  public final void w5() {
    if (this.H) {
      setResult(0, new Intent());
      finish();
      return;
    } 
    d0 d0 = z4().m(u0.PERSONAL);
    UserApi userApi = d0.u2();
    Intent intent = new Intent("android.intent.action.VIEW", Uri.parse((new d(d0.u2(), d0.C().d())).b(userApi.i(), d0.getId(), this.e, this.f, userApi.c().a().toString(), this.i, this.j)));
    try {
      this.K.c((Context)this, intent);
    } catch (NoHandlerForIntentException noHandlerForIntentException) {
      x.f((Context)this, V0.cannot_open_browser_error);
    } 
  }
  
  public final void x5() {
    z5();
  }
  
  public void z0() {
    if (!this.C)
      return; 
    FragmentManager fragmentManager = getSupportFragmentManager();
    Fragment fragment = fragmentManager.l0(Q0.dauth_interstitial_frag);
    o o = fragmentManager.q();
    o.t(fragment);
    o.k();
    z5();
  }
  
  public final void z5() {
    this.D = true;
    d0 d0 = z4().m(u0.PERSONAL);
    d d1 = new d(d0.u2(), d0.C().d());
    getSupportLoaderManager().f(1, null, (a.a)new m(this, (a)d1));
    this.z.setVisibility(8);
    this.y.setVisibility(8);
    this.A.setVisibility(8);
    this.x.setVisibility(0);
  }
  
  class DelegatedAuthActivity {}
  
  class DelegatedAuthActivity {}
  
  class DelegatedAuthActivity {}
  
  class DelegatedAuthActivity {}
  
  class DelegatedAuthActivity {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\android\dauth\DelegatedAuthActivity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */