package com.dropbox.android.accounts.login.api;

import com.dropbox.core.android.auth.SiblingInfo;
import com.squareup.moshi.JsonDataException;
import dbxyzptlk.Ce.a;
import dbxyzptlk.DI.s;
import dbxyzptlk.RG.f;
import dbxyzptlk.RG.i;
import dbxyzptlk.RG.n;
import dbxyzptlk.RG.q;
import dbxyzptlk.TG.c;
import dbxyzptlk.mk.s0;
import dbxyzptlk.qI.Y;
import kotlin.Metadata;

@Metadata(d1 = {"\000T\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\003\n\002\020\016\n\002\b\002\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\006\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\003\030\0002\b\022\004\022\0020\0020\001B\017\022\006\020\004\032\0020\003¢\006\004\b\005\020\006J\017\020\b\032\0020\007H\026¢\006\004\b\b\020\tJ\027\020\f\032\0020\0022\006\020\013\032\0020\nH\026¢\006\004\b\f\020\rJ!\020\022\032\0020\0212\006\020\017\032\0020\0162\b\020\020\032\004\030\0010\002H\026¢\006\004\b\022\020\023R\024\020\027\032\0020\0248\002X\004¢\006\006\n\004\b\025\020\026R\032\020\032\032\b\022\004\022\0020\0070\0018\002X\004¢\006\006\n\004\b\030\020\031R\032\020\035\032\b\022\004\022\0020\0330\0018\002X\004¢\006\006\n\004\b\034\020\031R\034\020 \032\n\022\006\022\004\030\0010\0360\0018\002X\004¢\006\006\n\004\b\037\020\031R\034\020#\032\n\022\006\022\004\030\0010!0\0018\002X\004¢\006\006\n\004\b\"\020\031¨\006$"}, d2 = {"Lcom/dropbox/android/accounts/login/api/DbAppAccountJsonAdapter;", "Ldbxyzptlk/RG/f;", "Lcom/dropbox/android/accounts/login/api/DbAppAccount;", "Ldbxyzptlk/RG/q;", "moshi", "<init>", "(Ldbxyzptlk/RG/q;)V", "", "toString", "()Ljava/lang/String;", "Ldbxyzptlk/RG/i;", "reader", "j", "(Ldbxyzptlk/RG/i;)Lcom/dropbox/android/accounts/login/api/DbAppAccount;", "Ldbxyzptlk/RG/n;", "writer", "value_", "Ldbxyzptlk/pI/D;", "k", "(Ldbxyzptlk/RG/n;Lcom/dropbox/android/accounts/login/api/DbAppAccount;)V", "Ldbxyzptlk/RG/i$a;", "a", "Ldbxyzptlk/RG/i$a;", "options", "b", "Ldbxyzptlk/RG/f;", "stringAdapter", "Ldbxyzptlk/Ce/a;", "c", "accessTokenAdapter", "Ldbxyzptlk/mk/s0;", "d", "nullableRoleAdapter", "Lcom/dropbox/core/android/auth/SiblingInfo;", "e", "nullableSiblingInfoAdapter", "dbapp_account_login_api_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class DbAppAccountJsonAdapter extends f<DbAppAccount> {
  public final i.a a;
  
  public final f<String> b;
  
  public final f<a> c;
  
  public final f<s0> d;
  
  public final f<SiblingInfo> e;
  
  public DbAppAccountJsonAdapter(q paramq) {
    i.a a1 = i.a.a(new String[] { "userId", "accessToken", "displayName", "email", "userName", "role", "siblingInfo" });
    s.g(a1, "of(...)");
    this.a = a1;
    f<String> f2 = paramq.f(String.class, Y.e(), "userId");
    s.g(f2, "adapter(...)");
    this.b = f2;
    f2 = paramq.f(a.class, Y.e(), "accessToken");
    s.g(f2, "adapter(...)");
    this.c = (f)f2;
    f2 = paramq.f(s0.class, Y.e(), "role");
    s.g(f2, "adapter(...)");
    this.d = (f)f2;
    f<SiblingInfo> f1 = paramq.f(SiblingInfo.class, Y.e(), "siblingInfo");
    s.g(f1, "adapter(...)");
    this.e = f1;
  }
  
  public DbAppAccount j(i parami) {
    String str1;
    String str2;
    String str3;
    s0 s0;
    a a1;
    s.h(parami, "reader");
    parami.P();
    String str4 = null;
    SiblingInfo siblingInfo6 = null;
    SiblingInfo siblingInfo1 = siblingInfo6;
    SiblingInfo siblingInfo2 = siblingInfo1;
    SiblingInfo siblingInfo3 = siblingInfo2;
    SiblingInfo siblingInfo4 = siblingInfo3;
    SiblingInfo siblingInfo5 = siblingInfo4;
    while (parami.c()) {
      switch (parami.o(this.a)) {
        default:
          continue;
        case 6:
          siblingInfo5 = (SiblingInfo)this.e.b(parami);
          continue;
        case 5:
          s0 = (s0)this.d.b(parami);
          continue;
        case 4:
          str3 = (String)this.b.b(parami);
          if (str3 != null)
            continue; 
          jsonDataException = c.w("userName", "userName", parami);
          s.g(jsonDataException, "unexpectedNull(...)");
          throw jsonDataException;
        case 3:
          str2 = (String)this.b.b((i)jsonDataException);
          if (str2 != null)
            continue; 
          jsonDataException = c.w("email", "email", (i)jsonDataException);
          s.g(jsonDataException, "unexpectedNull(...)");
          throw jsonDataException;
        case 2:
          str1 = (String)this.b.b((i)jsonDataException);
          if (str1 != null)
            continue; 
          jsonDataException = c.w("displayName", "displayName", (i)jsonDataException);
          s.g(jsonDataException, "unexpectedNull(...)");
          throw jsonDataException;
        case 1:
          a1 = (a)this.c.b((i)jsonDataException);
          if (a1 != null)
            continue; 
          jsonDataException = c.w("accessToken", "accessToken", (i)jsonDataException);
          s.g(jsonDataException, "unexpectedNull(...)");
          throw jsonDataException;
        case 0:
          str4 = (String)this.b.b((i)jsonDataException);
          if (str4 != null)
            continue; 
          jsonDataException = c.w("userId", "userId", (i)jsonDataException);
          s.g(jsonDataException, "unexpectedNull(...)");
          throw jsonDataException;
        case -1:
          break;
      } 
      jsonDataException.s();
      jsonDataException.D1();
    } 
    jsonDataException.T();
    if (str4 != null) {
      if (a1 != null) {
        if (str1 != null) {
          if (str2 != null) {
            if (str3 != null)
              return new DbAppAccount(str4, a1, str1, str2, null, str3, s0, siblingInfo5, 16, null); 
            jsonDataException = c.n("userName", "userName", (i)jsonDataException);
            s.g(jsonDataException, "missingProperty(...)");
            throw jsonDataException;
          } 
          jsonDataException = c.n("email", "email", (i)jsonDataException);
          s.g(jsonDataException, "missingProperty(...)");
          throw jsonDataException;
        } 
        jsonDataException = c.n("displayName", "displayName", (i)jsonDataException);
        s.g(jsonDataException, "missingProperty(...)");
        throw jsonDataException;
      } 
      jsonDataException = c.n("accessToken", "accessToken", (i)jsonDataException);
      s.g(jsonDataException, "missingProperty(...)");
      throw jsonDataException;
    } 
    JsonDataException jsonDataException = c.n("userId", "userId", (i)jsonDataException);
    s.g(jsonDataException, "missingProperty(...)");
    throw jsonDataException;
  }
  
  public void k(n paramn, DbAppAccount paramDbAppAccount) {
    s.h(paramn, "writer");
    if (paramDbAppAccount != null) {
      paramn.c();
      paramn.h("userId");
      this.b.i(paramn, paramDbAppAccount.l());
      paramn.h("accessToken");
      this.c.i(paramn, paramDbAppAccount.b());
      paramn.h("displayName");
      this.b.i(paramn, paramDbAppAccount.r());
      paramn.h("email");
      this.b.i(paramn, paramDbAppAccount.a());
      paramn.h("userName");
      this.b.i(paramn, paramDbAppAccount.e());
      paramn.h("role");
      this.d.i(paramn, paramDbAppAccount.c());
      paramn.h("siblingInfo");
      this.e.i(paramn, paramDbAppAccount.d());
      paramn.g();
      return;
    } 
    throw new NullPointerException("value_ was null! Wrap in .nullSafe() to write nullable values.");
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder(34);
    stringBuilder.append("GeneratedJsonAdapter(");
    stringBuilder.append("DbAppAccount");
    stringBuilder.append(')');
    String str = stringBuilder.toString();
    s.g(str, "toString(...)");
    return str;
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\android\accounts\login\api\DbAppAccountJsonAdapter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */