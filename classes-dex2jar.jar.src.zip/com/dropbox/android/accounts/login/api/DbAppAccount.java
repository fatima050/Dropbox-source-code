package com.dropbox.android.accounts.login.api;

import com.dropbox.core.android.auth.SiblingInfo;
import dbxyzptlk.Ce.a;
import dbxyzptlk.DI.s;
import dbxyzptlk.Pe.f;
import dbxyzptlk.RG.g;
import dbxyzptlk.mk.s0;
import java.util.Map;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

@g(generateAdapter = true)
@Metadata(d1 = {"\000P\n\002\030\002\n\002\030\002\n\002\020\016\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020$\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\005\n\002\020\b\n\002\b\002\n\002\020\000\n\000\n\002\020\013\n\002\b\027\b\b\030\0002\0020\001Be\022\n\020\004\032\0060\002j\002`\003\022\006\020\006\032\0020\005\022\n\020\b\032\0060\002j\002`\007\022\n\020\n\032\0060\002j\002`\t\022\024\b\002\020\f\032\016\022\004\022\0020\002\022\004\022\0020\0020\013\022\006\020\r\032\0020\002\022\b\020\017\032\004\030\0010\016\022\b\020\021\032\004\030\0010\020¢\006\004\b\022\020\023J\020\020\024\032\0020\002HÖ\001¢\006\004\b\024\020\025J\020\020\027\032\0020\026HÖ\001¢\006\004\b\027\020\030J\032\020\034\032\0020\0332\b\020\032\032\004\030\0010\031HÖ\003¢\006\004\b\034\020\035R\036\020\004\032\0060\002j\002`\0038\026X\004¢\006\f\n\004\b\036\020\037\032\004\b \020\025R\032\020\006\032\0020\0058\026X\004¢\006\f\n\004\b!\020\"\032\004\b!\020#R\036\020\b\032\0060\002j\002`\0078\026X\004¢\006\f\n\004\b$\020\037\032\004\b%\020\025R\036\020\n\032\0060\002j\002`\t8\026X\004¢\006\f\n\004\b&\020\037\032\004\b\036\020\025R&\020\f\032\016\022\004\022\0020\002\022\004\022\0020\0020\0138\026X\004¢\006\f\n\004\b'\020(\032\004\b)\020*R\027\020\r\032\0020\0028\006¢\006\f\n\004\b+\020\037\032\004\b'\020\025R\031\020\017\032\004\030\0010\0168\006¢\006\f\n\004\b,\020-\032\004\b$\020.R\031\020\021\032\004\030\0010\0208\006¢\006\f\n\004\b/\0200\032\004\b&\0201¨\0062"}, d2 = {"Lcom/dropbox/android/accounts/login/api/DbAppAccount;", "Ldbxyzptlk/Pe/f;", "", "Lcom/dropbox/common/auth/account/UserId;", "userId", "Ldbxyzptlk/Ce/a;", "accessToken", "Lcom/dropbox/common/auth/account/DisplayName;", "displayName", "Lcom/dropbox/common/auth/account/EmailAddress;", "email", "", "unknownFields", "userName", "Ldbxyzptlk/mk/s0;", "role", "Lcom/dropbox/core/android/auth/SiblingInfo;", "siblingInfo", "<init>", "(Ljava/lang/String;Ldbxyzptlk/Ce/a;Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Ldbxyzptlk/mk/s0;Lcom/dropbox/core/android/auth/SiblingInfo;)V", "toString", "()Ljava/lang/String;", "", "hashCode", "()I", "", "other", "", "equals", "(Ljava/lang/Object;)Z", "a", "Ljava/lang/String;", "l", "b", "Ldbxyzptlk/Ce/a;", "()Ldbxyzptlk/Ce/a;", "c", "r", "d", "e", "Ljava/util/Map;", "getUnknownFields", "()Ljava/util/Map;", "f", "g", "Ldbxyzptlk/mk/s0;", "()Ldbxyzptlk/mk/s0;", "h", "Lcom/dropbox/core/android/auth/SiblingInfo;", "()Lcom/dropbox/core/android/auth/SiblingInfo;", "dbapp_account_login_api_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class DbAppAccount implements f {
  public final String a;
  
  public final a b;
  
  public final String c;
  
  public final String d;
  
  public final transient Map<String, String> e;
  
  public final String f;
  
  public final s0 g;
  
  public final SiblingInfo h;
  
  public DbAppAccount(String paramString1, a parama, String paramString2, String paramString3, Map<String, String> paramMap, String paramString4, s0 params0, SiblingInfo paramSiblingInfo) {
    this.a = paramString1;
    this.b = parama;
    this.c = paramString2;
    this.d = paramString3;
    this.e = paramMap;
    this.f = paramString4;
    this.g = params0;
    this.h = paramSiblingInfo;
  }
  
  public String a() {
    return this.d;
  }
  
  public a b() {
    return this.b;
  }
  
  public final s0 c() {
    return this.g;
  }
  
  public final SiblingInfo d() {
    return this.h;
  }
  
  public final String e() {
    return this.f;
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof DbAppAccount))
      return false; 
    paramObject = paramObject;
    return !s.c(this.a, ((DbAppAccount)paramObject).a) ? false : (!s.c(this.b, ((DbAppAccount)paramObject).b) ? false : (!s.c(this.c, ((DbAppAccount)paramObject).c) ? false : (!s.c(this.d, ((DbAppAccount)paramObject).d) ? false : (!s.c(this.e, ((DbAppAccount)paramObject).e) ? false : (!s.c(this.f, ((DbAppAccount)paramObject).f) ? false : ((this.g != ((DbAppAccount)paramObject).g) ? false : (!!s.c(this.h, ((DbAppAccount)paramObject).h))))))));
  }
  
  public int hashCode() {
    int i;
    int i2 = this.a.hashCode();
    int m = this.b.hashCode();
    int n = this.c.hashCode();
    int i1 = this.d.hashCode();
    int k = this.e.hashCode();
    int i3 = this.f.hashCode();
    s0 s01 = this.g;
    int j = 0;
    if (s01 == null) {
      i = 0;
    } else {
      i = s01.hashCode();
    } 
    SiblingInfo siblingInfo = this.h;
    if (siblingInfo != null)
      j = siblingInfo.hashCode(); 
    return ((((((i2 * 31 + m) * 31 + n) * 31 + i1) * 31 + k) * 31 + i3) * 31 + i) * 31 + j;
  }
  
  public String l() {
    return this.a;
  }
  
  public String r() {
    return this.c;
  }
  
  public String toString() {
    String str2 = this.a;
    a a1 = this.b;
    String str4 = this.c;
    String str3 = this.d;
    Map<String, String> map = this.e;
    String str1 = this.f;
    s0 s01 = this.g;
    SiblingInfo siblingInfo = this.h;
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("DbAppAccount(userId=");
    stringBuilder.append(str2);
    stringBuilder.append(", accessToken=");
    stringBuilder.append(a1);
    stringBuilder.append(", displayName=");
    stringBuilder.append(str4);
    stringBuilder.append(", email=");
    stringBuilder.append(str3);
    stringBuilder.append(", unknownFields=");
    stringBuilder.append(map);
    stringBuilder.append(", userName=");
    stringBuilder.append(str1);
    stringBuilder.append(", role=");
    stringBuilder.append(s01);
    stringBuilder.append(", siblingInfo=");
    stringBuilder.append(siblingInfo);
    stringBuilder.append(")");
    return stringBuilder.toString();
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\android\accounts\login\api\DbAppAccount.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */