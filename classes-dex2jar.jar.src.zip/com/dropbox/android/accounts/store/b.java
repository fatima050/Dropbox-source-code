package com.dropbox.android.accounts.store;

import android.annotation.SuppressLint;
import android.util.Pair;
import com.dropbox.core.android.auth.SharedAccount;
import com.dropbox.core.android.auth.SiblingInfo;
import dbxyzptlk.A6.a;
import dbxyzptlk.C6.a;
import dbxyzptlk.C6.b;
import dbxyzptlk.C6.c;
import dbxyzptlk.CC.l;
import dbxyzptlk.CC.p;
import dbxyzptlk.EC.G;
import dbxyzptlk.Me.a;
import dbxyzptlk.mk.s0;
import dbxyzptlk.mk.t;
import dbxyzptlk.mk.y0;
import dbxyzptlk.qc.A;
import dbxyzptlk.qc.d;
import dbxyzptlk.qc.t;
import dbxyzptlk.sL.a;
import dbxyzptlk.z6.a;
import dbxyzptlk.z6.e;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

public class b implements b {
  public final y0 a;
  
  public final e b;
  
  public final a c;
  
  public final a d;
  
  public b(y0 paramy0, e parame, a parama, a parama1) {
    this.a = paramy0;
    this.b = parame;
    this.c = parama;
    this.d = parama1;
  }
  
  @SuppressLint({"UnknownNullness"})
  public static Set<String> l(Pair<a, a> paramPair) {
    HashSet<String> hashSet = new HashSet();
    Object object2 = paramPair.first;
    if (object2 != null)
      hashSet.add(((a)object2).n()); 
    Object object1 = paramPair.second;
    if (object1 != null)
      hashSet.add(((a)object1).n()); 
    return hashSet;
  }
  
  public static s0 p(d paramd) {
    int i = a.a[paramd.ordinal()];
    if (i != 1) {
      if (i != 2) {
        if (i == 3)
          return s0.PERSONAL; 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Unexpected AccountRole: ");
        stringBuilder.append(paramd);
        throw new IllegalStateException(stringBuilder.toString());
      } 
      return s0.DFB;
    } 
    return null;
  }
  
  public static SiblingInfo r(t paramt) {
    if (paramt == null || !paramt.Z())
      return null; 
    A a1 = paramt.Y();
    s0 s0 = p(a1.e0());
    return new SiblingInfo(a1.f0(), a1.d0(), s0);
  }
  
  public final a.b<a> a(SharedAccount paramSharedAccount1, SharedAccount paramSharedAccount2) {
    if (paramSharedAccount2.f.equals(paramSharedAccount1.f))
      return new a.b(a.b.a.UserIdAlreadyExists); 
    if (paramSharedAccount2.g.equalsIgnoreCase(paramSharedAccount1.g))
      return new a.b(a.b.a.EmailAlreadyExists); 
    if (paramSharedAccount2.j == paramSharedAccount1.j)
      return new a.b(a.b.a.RoleAlreadyExists); 
    SiblingInfo siblingInfo = paramSharedAccount2.k;
    return (siblingInfo == null || paramSharedAccount1.k == null || !siblingInfo.a.equals(paramSharedAccount1.f) || !paramSharedAccount1.k.a.equals(paramSharedAccount2.f) || paramSharedAccount2.k.c != paramSharedAccount1.j || paramSharedAccount1.k.c != paramSharedAccount2.j) ? new a.b(a.b.a.SiblingMismatch) : null;
  }
  
  public void b(SharedAccount paramSharedAccount) {
    if (q()) {
      this.c.d(paramSharedAccount.f);
    } else {
      this.a.b(paramSharedAccount).g();
    } 
  }
  
  public boolean c() {
    boolean bool;
    if (this.a.c().i() == null) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public a d(String paramString) {
    p.o(paramString);
    if (q()) {
      for (SharedAccount sharedAccount : this.c.a()) {
        if (paramString.equals(sharedAccount.f))
          return new a(sharedAccount, this.b); 
      } 
    } else {
      for (SharedAccount sharedAccount : this.a.a().d()) {
        if (paramString.equals(sharedAccount.f))
          return new a(sharedAccount, this.b); 
      } 
    } 
    return null;
  }
  
  public Pair<a, a> e(Collection<String> paramCollection) {
    // Byte code:
    //   0: aload_1
    //   1: invokestatic o : (Ljava/lang/Object;)Ljava/lang/Object;
    //   4: pop
    //   5: aload_0
    //   6: invokevirtual k : ()Ljava/util/List;
    //   9: astore #12
    //   11: ldc '%s accounts in the AccountManager.'
    //   13: iconst_1
    //   14: anewarray java/lang/Object
    //   17: dup
    //   18: iconst_0
    //   19: aload #12
    //   21: invokeinterface size : ()I
    //   26: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   29: aastore
    //   30: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   33: aload #12
    //   35: invokeinterface iterator : ()Ljava/util/Iterator;
    //   40: astore #6
    //   42: aload #6
    //   44: invokeinterface hasNext : ()Z
    //   49: ifeq -> 252
    //   52: aload #6
    //   54: invokeinterface next : ()Ljava/lang/Object;
    //   59: checkcast dbxyzptlk/C6/a
    //   62: astore #7
    //   64: aload #7
    //   66: invokevirtual l : ()Ldbxyzptlk/qc/A;
    //   69: astore #8
    //   71: aload #8
    //   73: ifnull -> 164
    //   76: new java/lang/StringBuilder
    //   79: dup
    //   80: invokespecial <init> : ()V
    //   83: astore #5
    //   85: aload #5
    //   87: ldc_w ' ('
    //   90: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   93: pop
    //   94: aload #5
    //   96: aload #8
    //   98: invokevirtual f0 : ()Ljava/lang/String;
    //   101: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   104: pop
    //   105: aload #5
    //   107: ldc_w '|'
    //   110: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   113: pop
    //   114: aload #5
    //   116: aload #8
    //   118: invokevirtual d0 : ()Ljava/lang/String;
    //   121: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   124: pop
    //   125: aload #5
    //   127: ldc_w '|'
    //   130: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   133: pop
    //   134: aload #5
    //   136: aload #8
    //   138: invokevirtual e0 : ()Ldbxyzptlk/qc/d;
    //   141: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   144: pop
    //   145: aload #5
    //   147: ldc_w ')'
    //   150: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   153: pop
    //   154: aload #5
    //   156: invokevirtual toString : ()Ljava/lang/String;
    //   159: astore #5
    //   161: goto -> 169
    //   164: ldc_w ''
    //   167: astore #5
    //   169: new java/lang/StringBuilder
    //   172: dup
    //   173: invokespecial <init> : ()V
    //   176: astore #8
    //   178: aload #8
    //   180: aload #7
    //   182: invokevirtual n : ()Ljava/lang/String;
    //   185: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   188: pop
    //   189: aload #8
    //   191: ldc_w '|'
    //   194: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   197: pop
    //   198: aload #8
    //   200: aload #7
    //   202: invokevirtual g : ()Ljava/lang/String;
    //   205: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   208: pop
    //   209: aload #8
    //   211: ldc_w '|'
    //   214: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   217: pop
    //   218: aload #8
    //   220: aload #7
    //   222: invokevirtual j : ()Ldbxyzptlk/qc/d;
    //   225: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   228: pop
    //   229: aload #8
    //   231: aload #5
    //   233: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   236: pop
    //   237: aload #8
    //   239: invokevirtual toString : ()Ljava/lang/String;
    //   242: iconst_0
    //   243: anewarray java/lang/Object
    //   246: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   249: goto -> 42
    //   252: aload #12
    //   254: invokeinterface isEmpty : ()Z
    //   259: istore #4
    //   261: aconst_null
    //   262: astore #11
    //   264: iload #4
    //   266: ifeq -> 279
    //   269: new android/util/Pair
    //   272: dup
    //   273: aconst_null
    //   274: aconst_null
    //   275: invokespecial <init> : (Ljava/lang/Object;Ljava/lang/Object;)V
    //   278: areturn
    //   279: aload #12
    //   281: invokeinterface iterator : ()Ljava/util/Iterator;
    //   286: astore #13
    //   288: aconst_null
    //   289: astore #8
    //   291: aconst_null
    //   292: astore #7
    //   294: aload #7
    //   296: astore #5
    //   298: aload #13
    //   300: invokeinterface hasNext : ()Z
    //   305: ifeq -> 696
    //   308: aload #13
    //   310: invokeinterface next : ()Ljava/lang/Object;
    //   315: checkcast dbxyzptlk/C6/a
    //   318: astore #6
    //   320: aload #6
    //   322: invokevirtual j : ()Ldbxyzptlk/qc/d;
    //   325: astore #14
    //   327: getstatic dbxyzptlk/qc/d.PERSONAL : Ldbxyzptlk/qc/d;
    //   330: aload #14
    //   332: invokevirtual equals : (Ljava/lang/Object;)Z
    //   335: istore #4
    //   337: iconst_1
    //   338: istore_3
    //   339: iload #4
    //   341: ifeq -> 458
    //   344: aload #8
    //   346: ifnonnull -> 360
    //   349: aload #6
    //   351: astore #9
    //   353: aload #7
    //   355: astore #10
    //   357: goto -> 588
    //   360: ldc_w 'We've got more than one personal account here'
    //   363: iconst_0
    //   364: anewarray java/lang/Object
    //   367: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   370: aload #8
    //   372: invokevirtual n : ()Ljava/lang/String;
    //   375: astore #9
    //   377: aload #6
    //   379: invokevirtual n : ()Ljava/lang/String;
    //   382: astore #14
    //   384: aload_1
    //   385: aload #9
    //   387: invokeinterface contains : (Ljava/lang/Object;)Z
    //   392: aload_1
    //   393: aload #14
    //   395: invokeinterface contains : (Ljava/lang/Object;)Z
    //   400: if_icmpne -> 408
    //   403: iconst_1
    //   404: istore_2
    //   405: goto -> 410
    //   408: iconst_0
    //   409: istore_2
    //   410: iload_2
    //   411: ifeq -> 424
    //   414: aload #14
    //   416: aload #9
    //   418: invokevirtual compareTo : (Ljava/lang/String;)I
    //   421: iflt -> 349
    //   424: aload #8
    //   426: astore #9
    //   428: aload #7
    //   430: astore #10
    //   432: iload_2
    //   433: ifne -> 588
    //   436: aload #8
    //   438: astore #9
    //   440: aload #7
    //   442: astore #10
    //   444: aload_1
    //   445: aload #14
    //   447: invokeinterface contains : (Ljava/lang/Object;)Z
    //   452: ifeq -> 588
    //   455: goto -> 349
    //   458: aload #8
    //   460: astore #9
    //   462: aload #7
    //   464: astore #10
    //   466: getstatic dbxyzptlk/qc/d.BUSINESS : Ldbxyzptlk/qc/d;
    //   469: aload #14
    //   471: invokevirtual equals : (Ljava/lang/Object;)Z
    //   474: ifeq -> 588
    //   477: aload #7
    //   479: ifnonnull -> 485
    //   482: goto -> 580
    //   485: ldc_w 'We've got more than one business account here'
    //   488: iconst_0
    //   489: anewarray java/lang/Object
    //   492: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   495: aload #7
    //   497: invokevirtual n : ()Ljava/lang/String;
    //   500: astore #9
    //   502: aload #6
    //   504: invokevirtual n : ()Ljava/lang/String;
    //   507: astore #14
    //   509: aload_1
    //   510: aload #9
    //   512: invokeinterface contains : (Ljava/lang/Object;)Z
    //   517: aload_1
    //   518: aload #14
    //   520: invokeinterface contains : (Ljava/lang/Object;)Z
    //   525: if_icmpne -> 533
    //   528: iconst_1
    //   529: istore_2
    //   530: goto -> 535
    //   533: iconst_0
    //   534: istore_2
    //   535: iload_2
    //   536: ifeq -> 549
    //   539: aload #14
    //   541: aload #9
    //   543: invokevirtual compareTo : (Ljava/lang/String;)I
    //   546: iflt -> 580
    //   549: aload #8
    //   551: astore #9
    //   553: aload #7
    //   555: astore #10
    //   557: iload_2
    //   558: ifne -> 588
    //   561: aload #8
    //   563: astore #9
    //   565: aload #7
    //   567: astore #10
    //   569: aload_1
    //   570: aload #14
    //   572: invokeinterface contains : (Ljava/lang/Object;)Z
    //   577: ifeq -> 588
    //   580: aload #6
    //   582: astore #10
    //   584: aload #8
    //   586: astore #9
    //   588: aload #5
    //   590: ifnonnull -> 596
    //   593: goto -> 681
    //   596: aload #5
    //   598: invokevirtual n : ()Ljava/lang/String;
    //   601: astore #7
    //   603: aload #6
    //   605: invokevirtual n : ()Ljava/lang/String;
    //   608: astore #14
    //   610: aload_1
    //   611: aload #7
    //   613: invokeinterface contains : (Ljava/lang/Object;)Z
    //   618: aload_1
    //   619: aload #14
    //   621: invokeinterface contains : (Ljava/lang/Object;)Z
    //   626: if_icmpne -> 634
    //   629: iload_3
    //   630: istore_2
    //   631: goto -> 636
    //   634: iconst_0
    //   635: istore_2
    //   636: iload_2
    //   637: ifeq -> 650
    //   640: aload #14
    //   642: aload #7
    //   644: invokevirtual compareTo : (Ljava/lang/String;)I
    //   647: iflt -> 681
    //   650: aload #9
    //   652: astore #8
    //   654: aload #10
    //   656: astore #7
    //   658: iload_2
    //   659: ifne -> 298
    //   662: aload #9
    //   664: astore #8
    //   666: aload #10
    //   668: astore #7
    //   670: aload_1
    //   671: aload #14
    //   673: invokeinterface contains : (Ljava/lang/Object;)Z
    //   678: ifeq -> 298
    //   681: aload #6
    //   683: astore #5
    //   685: aload #9
    //   687: astore #8
    //   689: aload #10
    //   691: astore #7
    //   693: goto -> 298
    //   696: aload #8
    //   698: ifnull -> 737
    //   701: aload #7
    //   703: ifnull -> 737
    //   706: aload_1
    //   707: aload #8
    //   709: invokevirtual n : ()Ljava/lang/String;
    //   712: invokeinterface contains : (Ljava/lang/Object;)Z
    //   717: ifne -> 737
    //   720: aload_1
    //   721: aload #7
    //   723: invokevirtual n : ()Ljava/lang/String;
    //   726: invokeinterface contains : (Ljava/lang/Object;)Z
    //   731: ifeq -> 737
    //   734: goto -> 745
    //   737: aload #8
    //   739: ifnull -> 745
    //   742: goto -> 749
    //   745: aload #7
    //   747: astore #8
    //   749: aload #8
    //   751: ifnonnull -> 773
    //   754: ldc_w 'Could not determine the role of any of the accounts in the account manager.'
    //   757: iconst_0
    //   758: anewarray java/lang/Object
    //   761: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   764: aload #5
    //   766: invokestatic o : (Ljava/lang/Object;)Ljava/lang/Object;
    //   769: pop
    //   770: goto -> 777
    //   773: aload #8
    //   775: astore #5
    //   777: aload #5
    //   779: invokevirtual l : ()Ldbxyzptlk/qc/A;
    //   782: ifnull -> 860
    //   785: aload_0
    //   786: aload #5
    //   788: invokevirtual l : ()Ldbxyzptlk/qc/A;
    //   791: invokevirtual f0 : ()Ljava/lang/String;
    //   794: aload #12
    //   796: invokevirtual j : (Ljava/lang/String;Ljava/util/Collection;)Ldbxyzptlk/C6/a;
    //   799: astore_1
    //   800: aload_1
    //   801: ifnull -> 857
    //   804: aload_1
    //   805: invokevirtual l : ()Ldbxyzptlk/qc/A;
    //   808: astore #6
    //   810: aload #6
    //   812: ifnull -> 847
    //   815: aload #5
    //   817: invokevirtual n : ()Ljava/lang/String;
    //   820: aload #6
    //   822: invokevirtual f0 : ()Ljava/lang/String;
    //   825: invokevirtual equals : (Ljava/lang/Object;)Z
    //   828: ifne -> 857
    //   831: ldc_w 'Primary account thinks it's paired. Its sibling thinks it's paired to somebody else.'
    //   834: iconst_0
    //   835: anewarray java/lang/Object
    //   838: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   841: aload #11
    //   843: astore_1
    //   844: goto -> 945
    //   847: ldc_w 'Primary account thinks it's paired. Its sibling doesn't.'
    //   850: iconst_0
    //   851: anewarray java/lang/Object
    //   854: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   857: goto -> 945
    //   860: aload #12
    //   862: invokeinterface iterator : ()Ljava/util/Iterator;
    //   867: astore #6
    //   869: aload #11
    //   871: astore_1
    //   872: aload #6
    //   874: invokeinterface hasNext : ()Z
    //   879: ifeq -> 945
    //   882: aload #6
    //   884: invokeinterface next : ()Ljava/lang/Object;
    //   889: checkcast dbxyzptlk/C6/a
    //   892: astore_1
    //   893: aload #5
    //   895: invokevirtual n : ()Ljava/lang/String;
    //   898: aload_1
    //   899: invokevirtual n : ()Ljava/lang/String;
    //   902: invokevirtual equals : (Ljava/lang/Object;)Z
    //   905: ifne -> 869
    //   908: aload_1
    //   909: invokevirtual l : ()Ldbxyzptlk/qc/A;
    //   912: astore #7
    //   914: aload #7
    //   916: ifnull -> 869
    //   919: aload #5
    //   921: invokevirtual n : ()Ljava/lang/String;
    //   924: aload #7
    //   926: invokevirtual f0 : ()Ljava/lang/String;
    //   929: invokevirtual equals : (Ljava/lang/Object;)Z
    //   932: ifeq -> 869
    //   935: ldc_w 'Primary account doesn't think it is paired. The sibling does.'
    //   938: iconst_0
    //   939: anewarray java/lang/Object
    //   942: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   945: new android/util/Pair
    //   948: dup
    //   949: aload #5
    //   951: aload_1
    //   952: invokespecial <init> : (Ljava/lang/Object;Ljava/lang/Object;)V
    //   955: areturn
  }
  
  @SuppressLint({"CheckResult"})
  public boolean f(SharedAccount paramSharedAccount, c paramc) {
    SharedAccount.b b1;
    dbxyzptlk.Fe.b.b();
    p.o(paramSharedAccount);
    p.o(paramc);
    if (paramSharedAccount == paramc.a) {
      boolean bool2 = q();
      boolean bool1 = false;
      boolean bool3 = false;
      if (bool2) {
        paramSharedAccount = this.c.e(paramSharedAccount.f);
        return (paramSharedAccount != null) ? s(paramSharedAccount, paramc) : false;
      } 
      List<SharedAccount> list = (List)this.a.a().d();
      Iterator<SharedAccount> iterator = list.iterator();
      SharedAccount sharedAccount1 = null;
      SharedAccount sharedAccount2;
      for (sharedAccount2 = null; iterator.hasNext(); sharedAccount2 = sharedAccount) {
        SharedAccount sharedAccount = iterator.next();
        if (t.a(paramSharedAccount, sharedAccount)) {
          sharedAccount1 = sharedAccount;
          continue;
        } 
      } 
      if (sharedAccount1 == null)
        return false; 
      SiblingInfo siblingInfo = paramc.f;
      if (siblingInfo == null || !sharedAccount1.f.equals(siblingInfo.a)) {
        boolean bool4;
        Iterator<SharedAccount> iterator1 = i(list, paramc).iterator();
        bool2 = false;
        while (iterator1.hasNext()) {
          SharedAccount sharedAccount3;
          SharedAccount sharedAccount4;
          SharedAccount sharedAccount5 = iterator1.next();
          if (sharedAccount1.f.equals(sharedAccount5.f)) {
            siblingInfo = null;
            sharedAccount4 = sharedAccount2;
          } else {
            sharedAccount3 = sharedAccount1;
            sharedAccount4 = sharedAccount2;
            if (sharedAccount2 != null) {
              sharedAccount3 = sharedAccount1;
              sharedAccount4 = sharedAccount2;
              if (sharedAccount2.f.equals(sharedAccount5.f)) {
                sharedAccount4 = null;
                sharedAccount3 = sharedAccount1;
              } 
            } 
          } 
          b(sharedAccount5);
          bool2 = true;
          sharedAccount1 = sharedAccount3;
          sharedAccount2 = sharedAccount4;
        } 
        if (sharedAccount1 != null || sharedAccount2 != null) {
          bool4 = true;
        } else {
          bool4 = false;
        } 
        p.e(bool4, "Assert failed.");
        if (sharedAccount1 == null) {
          siblingInfo = paramc.f;
          if (siblingInfo != null) {
            bool2 = bool3;
            if (!siblingInfo.a.equals(sharedAccount2.f)) {
              bool2 = true;
              p.e(bool2, "Assert failed.");
              o(sharedAccount2);
              return true;
            } 
            p.e(bool2, "Assert failed.");
            o(sharedAccount2);
            return true;
          } 
        } else {
          p.o(sharedAccount1);
          if (sharedAccount2 != null && (n(sharedAccount1, paramc) || m(sharedAccount1, paramc))) {
            Iterator<SharedAccount> iterator2 = ((List)this.a.a().d()).iterator();
            while (iterator2.hasNext()) {
              b(iterator2.next());
              bool2 = true;
            } 
            return bool2;
          } 
          b1 = sharedAccount1.b();
          if (!paramc.d.equals(sharedAccount1.h)) {
            b1.b(paramc.d);
            bool1 = true;
          } 
          if (!paramc.e.equals(sharedAccount1.i)) {
            b1.j(paramc.e);
            bool1 = true;
          } 
          s0 s0 = paramc.c;
          if (s0 != sharedAccount1.j) {
            b1.e(s0);
            bool1 = true;
          } 
          if (!l.a(sharedAccount1.k, paramc.f)) {
            b1.f(paramc.f);
            bool1 = true;
          } 
          if (!paramc.b.equalsIgnoreCase(sharedAccount1.g)) {
            b1.c(paramc.b);
            if (this.a.e(b1.a(), paramc.b).i() != null)
              return bool2; 
          } else if (bool1) {
            this.a.d(b1.a()).i();
          } else {
            return bool2;
          } 
          return true;
        } 
      } else {
        throw new RuntimeException("target.userId == siblingInfo.userId ????");
      } 
    } else {
      throw new RuntimeException("account != accountUpdate.account");
    } 
    boolean bool = true;
    p.e(bool, "Assert failed.");
    o((SharedAccount)b1);
    return true;
  }
  
  public a<a> g(SharedAccount paramSharedAccount, boolean paramBoolean) throws AddSharedAccountException {
    p.o(paramSharedAccount);
    List<SharedAccount> list = (List)this.a.a().d();
    Iterator<SharedAccount> iterator = list.iterator();
    while (iterator.hasNext()) {
      if (t.a(paramSharedAccount, iterator.next()))
        return (a<a>)new a.a(d(paramSharedAccount.f)); 
    } 
    if (list.size() >= 2)
      return (a<a>)new a.b(a.b.a.TooManyAccounts); 
    if (list.size() == 1)
      if (((SharedAccount)list.get(0)).j != null) {
        a.b<a> b1 = a(paramSharedAccount, list.get(0));
        if (b1 != null)
          return (a<a>)b1; 
      } else {
        throw new AddSharedAccountException.BadStateException("The existing account has <null> role. Call updateAccount to set its role first before adding a new account");
      }  
    if (this.a.f(paramSharedAccount).i() != null)
      a.g("Failed to add account", new Object[0]); 
    a a1 = d(paramSharedAccount.f);
    if (a1 != null)
      return (a<a>)new a.a(a1); 
    throw new AddSharedAccountException.BadStateException("Failed to add account to AccountStore. Missing Account manager data.");
  }
  
  public c h(SharedAccount paramSharedAccount, a parama, t paramt) {
    A a1 = parama.v();
    if (paramt.Z()) {
      A a2 = paramt.Y();
      SiblingInfo siblingInfo = new SiblingInfo(a2.f0(), a2.d0(), p(a2.e0()));
    } else {
      paramt = null;
    } 
    return new c(paramSharedAccount, a1.d0(), p(a1.e0()), parama.d(), parama.w(), (SiblingInfo)paramt);
  }
  
  public final Collection<SharedAccount> i(List<SharedAccount> paramList, c paramc) {
    ArrayList<SharedAccount> arrayList = new ArrayList();
    HashSet<String> hashSet2 = new HashSet();
    hashSet2.add(paramc.a.f);
    SiblingInfo siblingInfo = paramc.f;
    if (siblingInfo != null)
      hashSet2.add(siblingInfo.a); 
    HashSet<String> hashSet1 = new HashSet();
    Iterator<SharedAccount> iterator = paramList.iterator();
    while (iterator.hasNext())
      hashSet1.add(((SharedAccount)iterator.next()).f); 
    HashSet<String> hashSet3 = new HashSet<>(hashSet2);
    hashSet3.retainAll(hashSet1);
    int i = hashSet3.size();
    boolean bool2 = false;
    if (i > 0) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    p.e(bool1, "Assert failed.");
    if (hashSet1.equals(hashSet2))
      return arrayList; 
    if (paramList.size() == 1)
      return arrayList; 
    boolean bool1 = bool2;
    if (paramList.size() == 2)
      bool1 = true; 
    p.e(bool1, "Assert failed.");
    for (SharedAccount sharedAccount : paramList) {
      if (sharedAccount.j == s0.DFB)
        arrayList.add(sharedAccount); 
    } 
    return arrayList;
  }
  
  public final a j(String paramString, Collection<a> paramCollection) {
    for (a a1 : paramCollection) {
      if (a1.n().equals(paramString))
        return a1; 
    } 
    return null;
  }
  
  public final List<a> k() {
    ArrayList<a> arrayList = G.h();
    if (q()) {
      Iterator<SharedAccount> iterator = this.c.a().iterator();
      while (iterator.hasNext())
        arrayList.add(new a(iterator.next(), this.b)); 
    } else {
      Iterator<SharedAccount> iterator = ((List)this.a.a().d()).iterator();
      while (iterator.hasNext())
        arrayList.add(new a(iterator.next(), this.b)); 
    } 
    return arrayList;
  }
  
  public final boolean m(SharedAccount paramSharedAccount, c paramc) {
    if (paramc.f != null) {
      SiblingInfo siblingInfo = paramSharedAccount.k;
      if (siblingInfo != null && paramc.b.equalsIgnoreCase(siblingInfo.b) && paramc.f.b.equalsIgnoreCase(paramSharedAccount.g))
        return true; 
    } 
    return false;
  }
  
  public final boolean n(SharedAccount paramSharedAccount, c paramc) {
    SiblingInfo siblingInfo = paramc.f;
    if (siblingInfo != null) {
      SiblingInfo siblingInfo1 = paramSharedAccount.k;
      if (siblingInfo1 != null && paramSharedAccount.j == siblingInfo.c && siblingInfo1.c == paramc.c)
        return true; 
    } 
    return false;
  }
  
  public final void o(SharedAccount paramSharedAccount) {
    SharedAccount.b b1 = paramSharedAccount.b();
    b1.f(null);
    this.a.d(b1.a()).g();
  }
  
  public final boolean q() {
    return this.d.a();
  }
  
  public final boolean s(SharedAccount paramSharedAccount, c paramc) {
    boolean bool;
    if (!paramc.d.equals(paramSharedAccount.h) || !paramc.e.equals(paramSharedAccount.i) || paramc.c != paramSharedAccount.j || !l.a(paramSharedAccount.k, paramc.f) || !paramc.b.equalsIgnoreCase(paramSharedAccount.g)) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool)
      this.c.c(paramSharedAccount.f); 
    return bool;
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\android\accounts\store\b.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */