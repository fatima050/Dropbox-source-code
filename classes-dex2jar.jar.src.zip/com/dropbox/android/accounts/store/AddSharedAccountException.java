package com.dropbox.android.accounts.store;

import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

@Metadata(d1 = {"\000 \n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\020\016\n\002\b\003\n\002\030\002\n\002\030\002\n\000\b6\030\0002\0060\001j\002`\002:\002\006\007B\017\b\004\022\006\020\003\032\0020\004¢\006\002\020\005\001\002\b\t¨\006\n"}, d2 = {"Lcom/dropbox/android/accounts/store/AddSharedAccountException;", "Ljava/lang/Exception;", "Lkotlin/Exception;", "message", "", "(Ljava/lang/String;)V", "BadStateException", "UserErrorException", "Lcom/dropbox/android/accounts/store/AddSharedAccountException$BadStateException;", "Lcom/dropbox/android/accounts/store/AddSharedAccountException$UserErrorException;", "dbapp_account_store_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
public abstract class AddSharedAccountException extends Exception {
  public AddSharedAccountException(String paramString) {
    super(paramString);
  }
  
  @Metadata(d1 = {"\000\022\n\002\030\002\n\002\030\002\n\000\n\002\020\016\n\002\b\002\030\0002\0020\001B\r\022\006\020\002\032\0020\003¢\006\002\020\004¨\006\005"}, d2 = {"Lcom/dropbox/android/accounts/store/AddSharedAccountException$BadStateException;", "Lcom/dropbox/android/accounts/store/AddSharedAccountException;", "message", "", "(Ljava/lang/String;)V", "dbapp_account_store_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
  public static final class BadStateException extends AddSharedAccountException {
    public BadStateException(String param1String) {
      super(param1String, null);
    }
  }
  
  class AddSharedAccountException {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\android\accounts\store\AddSharedAccountException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */