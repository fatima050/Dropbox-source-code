package com.dropbox.android;

import com.dropbox.common.skeleton.core.a;
import com.squareup.anvil.annotations.MergeComponent;
import dbxyzptlk.Jh.h;
import dbxyzptlk.zj.s;
import kotlin.Metadata;

@MergeComponent(scope = h.class)
@Metadata(d1 = {"\000\f\n\002\030\002\n\002\030\002\n\002\b\002\bg\030\0002\0020\001:\001\002ø\001\000\002\006\n\004\b!0\001¨\006\003À\006\001"}, d2 = {"Lcom/dropbox/android/b;", "Ldbxyzptlk/zj/s;", "a", "Dropbox_normalRelease"}, k = 1, mv = {1, 9, 0}, xi = 48)
public interface b extends s, a.a {
  @Metadata(d1 = {"\000\026\n\002\030\002\n\002\020\000\n\002\030\002\n\000\n\002\030\002\n\002\b\003\bg\030\0002\0020\001J\031\020\005\032\0020\0042\b\b\001\020\003\032\0020\002H&¢\006\004\b\005\020\006ø\001\000\002\006\n\004\b!0\001¨\006\007À\006\001"}, d2 = {"Lcom/dropbox/android/b$a;", "", "Lcom/dropbox/android/DropboxApplication;", "app", "Ldbxyzptlk/zj/s;", "a", "(Lcom/dropbox/android/DropboxApplication;)Ldbxyzptlk/zj/s;", "Dropbox_normalRelease"}, k = 1, mv = {1, 9, 0}, xi = 48)
  public static interface a {
    s a(DropboxApplication param1DropboxApplication);
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\android\b.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */