package com.dropbox.android.filemanager;

import android.net.Uri;
import com.dropbox.android.user.DbxUserManager;
import com.dropbox.android.user.a;
import com.dropbox.common.legacy_api.exception.DropboxException;
import com.dropbox.common.stormcrow_gen.StormcrowMobileAndroidLoginApiV2;
import com.dropbox.core.BadRequestException;
import com.dropbox.core.DbxException;
import com.dropbox.core.NetworkIOException;
import com.dropbox.core.v2.account.PasswordResetErrorException;
import com.dropbox.internalclient.NoAuthApi;
import com.dropbox.internalclient.UserApi;
import com.dropbox.internalclient.d;
import dbxyzptlk.Bq.h;
import dbxyzptlk.CC.m;
import dbxyzptlk.CC.p;
import dbxyzptlk.Cg.a;
import dbxyzptlk.Ec.a;
import dbxyzptlk.Ec.g;
import dbxyzptlk.Fc.Z8;
import dbxyzptlk.Fe.b;
import dbxyzptlk.Fe.c;
import dbxyzptlk.Jh.e;
import dbxyzptlk.Kk.e;
import dbxyzptlk.Nk.b;
import dbxyzptlk.Nk.d;
import dbxyzptlk.Ok.y0;
import dbxyzptlk.Q6.a;
import dbxyzptlk.YJ.t;
import dbxyzptlk.Zy.c;
import dbxyzptlk.df.b;
import dbxyzptlk.dk.x;
import dbxyzptlk.mk.A;
import dbxyzptlk.mk.A0;
import dbxyzptlk.mk.B0;
import dbxyzptlk.mk.e;
import dbxyzptlk.mk.f;
import dbxyzptlk.mk.g;
import dbxyzptlk.mk.u;
import dbxyzptlk.mk.z;
import dbxyzptlk.pc.d0;
import dbxyzptlk.pc.u0;
import dbxyzptlk.pj.g;
import dbxyzptlk.sL.a;
import dbxyzptlk.sh.g;
import dbxyzptlk.un.g;
import dbxyzptlk.wm.e;
import dbxyzptlk.x9.U;
import dbxyzptlk.x9.Y;
import dbxyzptlk.x9.y;
import java.util.ArrayList;
import java.util.List;

public class ApiManager {
  public volatile NoAuthApi a;
  
  public volatile y b;
  
  public final g c;
  
  public final g d;
  
  public final h e;
  
  public final a f;
  
  public final DbxUserManager g;
  
  public final b h;
  
  public final g i;
  
  public final e<e> j;
  
  public final g k;
  
  public final U l;
  
  public final x m;
  
  public final g n;
  
  public final c o;
  
  public ApiManager(h paramh, g paramg, NoAuthApi paramNoAuthApi, y paramy, DbxUserManager paramDbxUserManager, g paramg1, a parama, b paramb, g paramg2, e<e> parame, g paramg3, g paramg4, U paramU, x paramx, c paramc) {
    this.e = paramh;
    this.d = paramg;
    this.a = paramNoAuthApi;
    this.b = paramy;
    this.g = paramDbxUserManager;
    this.c = paramg1;
    this.f = parama;
    this.h = paramb;
    this.i = paramg2;
    this.j = parame;
    this.n = paramg3;
    this.k = paramg4;
    this.l = paramU;
    this.m = paramx;
    this.o = paramc;
  }
  
  public static void e(DbxUserManager paramDbxUserManager, UserApi paramUserApi, g paramg, String paramString, boolean paramBoolean, c paramc) {
    b.b();
    if (paramUserApi != null && !paramUserApi.y())
      try {
        paramUserApi.z();
      } catch (DropboxException dropboxException) {
        a.h3().o("msg", dropboxException.getMessage()).i(paramg);
      }  
    a.j("Deauthenticating user.", new Object[0]);
    if (!paramDbxUserManager.p(paramString, paramBoolean)) {
      a.d("Unable to remove user:  %s", new Object[] { paramString });
    } else {
      a.f().o("reason", paramc.name()).i(paramg);
      a.d("Removed user:  %s", new Object[] { paramString });
      if (paramc == c.AUTH_SESSION_INVALID)
        a.h(new RuntimeException("Deauthenticated user due to invalid auth session")); 
    } 
  }
  
  public static void f(DbxUserManager paramDbxUserManager, d0 paramd0, c paramc) {
    e(paramDbxUserManager, paramd0.u2(), paramd0.e(), paramd0.getId(), false, paramc);
  }
  
  public d0 A(b paramb, String paramString) throws DropboxException, DbxException, LoginNeedsTwofactorCodeException, DbxUserManager.RegisterUserException {
    u u = l().u(paramb, paramString);
    O(u);
    a.j("Successfully authenticated", new Object[0]);
    return u(u, "login", false);
  }
  
  public d0 B(String paramString) throws DropboxException, DbxUserManager.RegisterUserException, DbxException {
    B0 b0 = this.d.N0();
    if (b0 != null) {
      u u;
      if (Q()) {
        u = this.i.e(b0.a(), paramString);
      } else {
        u = l().I(b0.a(), (String)u);
      } 
      return t(u, "login.two_factor", false);
    } 
    throw new DropboxException("Tried to log in without twofactor checkpoint token");
  }
  
  public d0 C(String paramString1, c paramc, String paramString2, String paramString3, NoAuthApi.b paramb, boolean paramBoolean, String paramString4, String paramString5) throws DropboxException, DbxUserManager.RegisterUserException, SignUpNeedsRecaptchaException {
    u u;
    if (Q()) {
      u = this.i.g(paramString1, paramc, paramString2, paramString3, paramb.name(), paramBoolean, paramString4, paramString5);
    } else {
      u = l().o(paramString1, paramc, paramString2, paramString3, paramb, paramBoolean, (String)u, paramString5);
    } 
    if (!u.k())
      return g(paramString1, u); 
    a.d("Sign up needs recaptcha", new Object[0]);
    NoAuthApi.SignUpState signUpState = new NoAuthApi.SignUpState(paramString2, paramString3, paramb, paramBoolean);
    throw new SignUpNeedsRecaptchaException(new NoAuthApi.RecaptchaState(paramString1, paramc, u.f(), m.e(signUpState)));
  }
  
  public d0 D(NoAuthApi.b paramb, boolean paramBoolean) throws DropboxException, DbxUserManager.RegisterUserException {
    g.c c1 = this.d.e0();
    if (c1 != null) {
      u u;
      String str = c1.b();
      if (Q()) {
        u = this.i.d(c1.a(), paramb.name(), paramBoolean);
      } else {
        u = l().q(c1.a(), (NoAuthApi.b)u, paramBoolean);
      } 
      return g(str, u);
    } 
    throw new DropboxException("Tried to do Google sign up without Google signup info");
  }
  
  public d0 E(u paramu, boolean paramBoolean) throws DbxUserManager.RegisterUserException, DbxException {
    // Byte code:
    //   0: ldc_w 'handling logged in user'
    //   3: iconst_0
    //   4: anewarray java/lang/Object
    //   7: invokestatic j : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   10: aload_1
    //   11: invokevirtual h : ()J
    //   14: invokestatic toString : (J)Ljava/lang/String;
    //   17: astore_3
    //   18: new com/dropbox/android/filemanager/ApiManager$b
    //   21: dup
    //   22: aload_0
    //   23: aload_1
    //   24: invokevirtual a : ()Ldbxyzptlk/Ce/a;
    //   27: invokespecial <init> : (Lcom/dropbox/android/filemanager/ApiManager;Ldbxyzptlk/Ce/a;)V
    //   30: astore_1
    //   31: aload_0
    //   32: getfield e : Ldbxyzptlk/Bq/h;
    //   35: aload_1
    //   36: aconst_null
    //   37: invokevirtual c : (Ldbxyzptlk/Kh/f$b;Ldbxyzptlk/Kh/f$a;)Ldbxyzptlk/Kh/f;
    //   40: astore_1
    //   41: aload_0
    //   42: aload_0
    //   43: getfield n : Ldbxyzptlk/pj/g;
    //   46: invokeinterface b : ()Ldbxyzptlk/pj/f;
    //   51: aload_1
    //   52: aload_0
    //   53: getfield f : Ldbxyzptlk/Cg/a;
    //   56: aload_3
    //   57: invokevirtual b : (Ldbxyzptlk/pj/f$b;Ldbxyzptlk/Cg/a;Ljava/lang/String;)Ldbxyzptlk/Nk/d;
    //   60: invokevirtual j : (Ldbxyzptlk/Nk/d;)Ldbxyzptlk/wm/e;
    //   63: invokestatic c : (Ldbxyzptlk/wm/e;)Ldbxyzptlk/Ne/b;
    //   66: astore_1
    //   67: aload_0
    //   68: monitorenter
    //   69: aload_0
    //   70: getfield g : Lcom/dropbox/android/user/DbxUserManager;
    //   73: aload_1
    //   74: iload_2
    //   75: invokeinterface o : (Ldbxyzptlk/Ne/b;Z)Lcom/dropbox/android/accounts/store/a;
    //   80: astore_1
    //   81: aload_0
    //   82: monitorexit
    //   83: aload_1
    //   84: instanceof com/dropbox/android/accounts/store/a$b
    //   87: ifne -> 117
    //   90: aload_1
    //   91: checkcast com/dropbox/android/accounts/store/a$a
    //   94: invokevirtual a : ()Ljava/lang/Object;
    //   97: checkcast dbxyzptlk/pc/d0
    //   100: astore_1
    //   101: aload_0
    //   102: iload_2
    //   103: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   106: aload_1
    //   107: invokeinterface l : ()Ljava/lang/String;
    //   112: invokevirtual v : (Ljava/lang/Boolean;Ljava/lang/String;)V
    //   115: aload_1
    //   116: areturn
    //   117: new com/dropbox/android/user/DbxUserManager$RegisterUserException
    //   120: dup
    //   121: aload_1
    //   122: checkcast com/dropbox/android/accounts/store/a$b
    //   125: invokevirtual a : ()Lcom/dropbox/android/accounts/store/AddSharedAccountException$UserErrorException;
    //   128: invokespecial <init> : (Ljava/lang/Throwable;)V
    //   131: athrow
    //   132: astore_1
    //   133: aload_0
    //   134: monitorexit
    //   135: aload_1
    //   136: athrow
    //   137: astore_1
    //   138: new com/dropbox/android/user/DbxUserManager$RegisterUserException
    //   141: dup
    //   142: ldc_w 'login failed'
    //   145: aload_1
    //   146: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   149: astore_1
    //   150: aload_1
    //   151: invokestatic h : (Ljava/lang/Throwable;)V
    //   154: aload_1
    //   155: athrow
    // Exception table:
    //   from	to	target	type
    //   67	69	137	com/dropbox/android/user/DbxUserManager$RegisterUserException
    //   69	83	132	finally
    //   133	135	132	finally
    //   135	137	137	com/dropbox/android/user/DbxUserManager$RegisterUserException
  }
  
  public void F(b paramb, String paramString1, String paramString2) throws DbxException, DropboxException, LoginRequiresSsoException {
    NoAuthApi.c c1 = o(paramString1, paramString2);
    if (c1 != NoAuthApi.c.REQUIRED) {
      l().K(paramb, paramString1);
      return;
    } 
    throw new LoginRequiresSsoException(c1);
  }
  
  public void G(String paramString1, String paramString2) throws DropboxException, LoginRequiresSsoException, PasswordResetErrorException, BadRequestException, DbxException {
    NoAuthApi.c c1 = o(paramString1, paramString2);
    if (c1 != NoAuthApi.c.REQUIRED) {
      this.i.h(paramString1);
      return;
    } 
    throw new LoginRequiresSsoException(c1);
  }
  
  public String H() throws DropboxException {
    B0 b0 = this.d.N0();
    if (b0 != null) {
      String str;
      if (Q()) {
        str = this.i.i(b0.a());
      } else {
        str = l().M(b0.a());
      } 
      if (str != null) {
        b0 = new B0(b0.a(), b0.b(), str, b0.d());
        this.d.K0(b0);
      } 
      return str;
    } 
    throw new DropboxException("Tried to resend twofactor code without having checkpoint token");
  }
  
  public boolean I() {
    B0 b0 = this.d.N0();
    if (b0 != null) {
      if (b0.c())
        this.d.K0(null); 
      return b0.c() ^ true;
    } 
    return false;
  }
  
  public A0 J(String paramString) throws DropboxException {
    return l().k(paramString);
  }
  
  public final void K(u paramu, String paramString) throws AppleLoginNeedsPasswordException {
    if (!paramu.i())
      return; 
    e e1 = paramu.b();
    this.d.n0(new f(e1, paramString));
    throw new AppleLoginNeedsPasswordException(paramString);
  }
  
  public final void L(u paramu, String paramString) throws GoogleLoginNeedsPasswordException {
    if (!paramu.j())
      return; 
    z z = paramu.e();
    a.d("Partially authenticated - need password", new Object[0]);
    this.d.u0(new A(z, paramString));
    throw new GoogleLoginNeedsPasswordException(paramString);
  }
  
  public final void M(u paramu, String paramString) throws GoogleLoginRequiresSignupException {
    if (!paramu.l())
      return; 
    String str = paramu.d();
    a.d("Not authenticated - we need to create an account for the user", new Object[0]);
    this.d.v0(new g.c(paramString, str));
    throw new GoogleLoginRequiresSignupException();
  }
  
  public final void N(u paramu, String paramString, c paramc) throws LoginNeedsRecaptchaException {
    if (!paramu.k())
      return; 
    a.d("Partially authenticated - need recaptcha", new Object[0]);
    throw new LoginNeedsRecaptchaException(new NoAuthApi.RecaptchaState(paramString, paramc, paramu.f(), m.a()));
  }
  
  public final void O(u paramu) throws LoginNeedsTwofactorCodeException {
    if (!paramu.m())
      return; 
    B0 b0 = paramu.g();
    a.d("Partially authenticated - need twofactor", new Object[0]);
    this.d.K0(b0);
    throw new LoginNeedsTwofactorCodeException();
  }
  
  public final void P(String paramString1, c paramc, String paramString2) throws DropboxException, LoginRequiresSsoException {
    NoAuthApi.c c1 = o(paramString1, paramString2);
    if (c1 != NoAuthApi.c.REQUIRED) {
      NoAuthApi.c c2 = NoAuthApi.c.OPTIONAL;
      if (c1 != c2 || paramc.c() != 0) {
        if (c1 == c2)
          (new Z8()).g(this.c); 
        return;
      } 
    } 
    throw new LoginRequiresSsoException(c1);
  }
  
  public final boolean Q() {
    return ((e)this.j.b()).l(StormcrowMobileAndroidLoginApiV2.VENABLED);
  }
  
  public void a() {
    if (this.d.C() != null)
      this.d.n0(null); 
  }
  
  public void b() {
    if (this.d.d0() != null)
      this.d.u0(null); 
  }
  
  public void c() {
    if (this.d.e0() != null)
      this.d.v0(null); 
  }
  
  public void d() {
    if (this.d.N0() != null)
      this.d.K0(null); 
  }
  
  public final d0 g(String paramString, u paramu) throws DropboxException, DbxUserManager.RegisterUserException {
    this.d.r(paramString);
    a.j("Successfully created new user", new Object[0]);
    return s(paramString, paramu, "new_account", true);
  }
  
  public d0 h(A0 paramA0, String paramString1, String paramString2) throws DropboxException, DbxUserManager.RegisterUserException {
    a.d("Retrieving access token for SSO user", new Object[0]);
    u u = l().J(paramA0.b(), paramString1, paramString2);
    a.j("Successfully authenticated via SSO", new Object[0]);
    return s(paramA0.c(), u, "login.sso", false);
  }
  
  public f i() {
    return this.d.C();
  }
  
  public final e j(d paramd) throws DbxException {
    byte b1 = 0;
    while (b1 < 2) {
      try {
        return paramd.V().c();
      } catch (NetworkIOException networkIOException) {
        b1++;
      } 
    } 
    return paramd.V().c();
  }
  
  public A k() {
    return this.d.d0();
  }
  
  public final NoAuthApi l() {
    return this.a;
  }
  
  public Uri m(String paramString) throws DropboxException {
    return l().g(paramString);
  }
  
  public List<d> n() {
    ArrayList<Y> arrayList = new ArrayList();
    a a1 = this.g.a();
    if (a1 != null) {
      ArrayList<d0> arrayList1 = new ArrayList();
      d0 d01 = a1.q(a1.k().d().E());
      d0 d02 = a1.r(u0.BUSINESS);
      d0 d03 = a1.r(u0.PERSONAL);
      if (d01 != null)
        arrayList1.add(d01); 
      if (d02 != null && !d02.equals(d01))
        arrayList1.add(d02); 
      if (d03 != null && !d03.equals(d01))
        arrayList1.add(d03); 
      for (d0 d0 : arrayList1)
        arrayList.add(new Y(d0.u2(), d0.C(), this.k, this.l, this.m, this.o)); 
    } else {
      arrayList.add(this.b);
    } 
    p.e(arrayList.isEmpty() ^ true, "Assert failed.");
    return (List)arrayList;
  }
  
  public final NoAuthApi.c o(String paramString1, String paramString2) throws DropboxException {
    return a.h(this.i.a(paramString1, paramString2));
  }
  
  public B0 p() {
    return this.d.N0();
  }
  
  public Uri q(String paramString1, String paramString2) {
    p.o(paramString1);
    p.o(paramString2);
    return l().A(paramString1, paramString2);
  }
  
  public d0 r(c paramc) throws DropboxException, DbxUserManager.RegisterUserException, LoginNeedsTwofactorCodeException, LoginNeedsRecaptchaException {
    A a1 = k();
    if (a1 != null) {
      u u;
      String str1 = a1.a();
      String str2 = a1.d();
      if (Q()) {
        u = this.i.f(str2, paramc, null, null, null, y0.d(str1));
      } else {
        u = l().t(paramc, (String)u, str2);
      } 
      O(u);
      N(u, str2, paramc);
      return s(str2, u, "login.google", false);
    } 
    throw new DropboxException("Tried to log in without a Google login checkpoint token");
  }
  
  public final d0 s(String paramString1, u paramu, String paramString2, boolean paramBoolean) throws DropboxException, DbxUserManager.RegisterUserException {
    p.d(t.C(paramString1) ^ true);
    return t(paramu, paramString2, paramBoolean);
  }
  
  public d0 t(u paramu, String paramString, boolean paramBoolean) throws DropboxException, DbxUserManager.RegisterUserException {
    // Byte code:
    //   0: ldc_w 'handling logged in user'
    //   3: iconst_0
    //   4: anewarray java/lang/Object
    //   7: invokestatic j : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   10: aload_1
    //   11: invokevirtual h : ()J
    //   14: invokestatic toString : (J)Ljava/lang/String;
    //   17: astore #4
    //   19: aload_1
    //   20: invokevirtual a : ()Ldbxyzptlk/Ce/a;
    //   23: astore_1
    //   24: invokestatic i : ()Ldbxyzptlk/Ec/m;
    //   27: ldc_w 'source'
    //   30: aload_2
    //   31: invokevirtual o : (Ljava/lang/String;Ljava/lang/String;)Ldbxyzptlk/Ec/m;
    //   34: ldc_w 'user'
    //   37: aload #4
    //   39: invokevirtual o : (Ljava/lang/String;Ljava/lang/String;)Ldbxyzptlk/Ec/m;
    //   42: aload_0
    //   43: getfield c : Ldbxyzptlk/Ec/g;
    //   46: invokevirtual i : (Ldbxyzptlk/Ec/g;)V
    //   49: aload_0
    //   50: invokevirtual d : ()V
    //   53: aload_0
    //   54: invokevirtual b : ()V
    //   57: aload_0
    //   58: invokevirtual c : ()V
    //   61: aload_0
    //   62: invokevirtual a : ()V
    //   65: new com/dropbox/android/filemanager/ApiManager$a
    //   68: dup
    //   69: aload_0
    //   70: aload_1
    //   71: invokespecial <init> : (Lcom/dropbox/android/filemanager/ApiManager;Ldbxyzptlk/Ce/a;)V
    //   74: astore_2
    //   75: new dbxyzptlk/y6/a
    //   78: dup
    //   79: new com/dropbox/internalclient/c
    //   82: dup
    //   83: aload_0
    //   84: getfield e : Ldbxyzptlk/Bq/h;
    //   87: aload_2
    //   88: aconst_null
    //   89: invokevirtual c : (Ldbxyzptlk/Kh/f$b;Ldbxyzptlk/Kh/f$a;)Ldbxyzptlk/Kh/f;
    //   92: aload_0
    //   93: getfield f : Ldbxyzptlk/Cg/a;
    //   96: aload #4
    //   98: invokespecial <init> : (Ldbxyzptlk/Kh/f;Ldbxyzptlk/Cg/a;Ljava/lang/String;)V
    //   101: invokespecial <init> : (Lcom/dropbox/internalclient/UserApi;)V
    //   104: invokevirtual a : ()Ldbxyzptlk/Ne/b;
    //   107: astore_2
    //   108: new dbxyzptlk/Fc/F8
    //   111: dup
    //   112: invokespecial <init> : ()V
    //   115: aload_0
    //   116: getfield c : Ldbxyzptlk/Ec/g;
    //   119: invokevirtual g : (Ldbxyzptlk/Ec/g;)V
    //   122: aload_0
    //   123: monitorenter
    //   124: aload_0
    //   125: getfield g : Lcom/dropbox/android/user/DbxUserManager;
    //   128: aload_2
    //   129: aload_1
    //   130: iload_3
    //   131: invokeinterface e : (Ldbxyzptlk/Ne/b;Ldbxyzptlk/Ce/a;Z)Lcom/dropbox/android/accounts/store/a;
    //   136: astore_1
    //   137: aload_0
    //   138: monitorexit
    //   139: aload_1
    //   140: instanceof com/dropbox/android/accounts/store/a$b
    //   143: ifne -> 173
    //   146: aload_1
    //   147: checkcast com/dropbox/android/accounts/store/a$a
    //   150: invokevirtual a : ()Ljava/lang/Object;
    //   153: checkcast dbxyzptlk/pc/d0
    //   156: astore_1
    //   157: aload_0
    //   158: iload_3
    //   159: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   162: aload_1
    //   163: invokeinterface l : ()Ljava/lang/String;
    //   168: invokevirtual v : (Ljava/lang/Boolean;Ljava/lang/String;)V
    //   171: aload_1
    //   172: areturn
    //   173: new com/dropbox/android/user/DbxUserManager$RegisterUserException
    //   176: dup
    //   177: aload_1
    //   178: checkcast com/dropbox/android/accounts/store/a$b
    //   181: invokevirtual a : ()Lcom/dropbox/android/accounts/store/AddSharedAccountException$UserErrorException;
    //   184: invokespecial <init> : (Ljava/lang/Throwable;)V
    //   187: athrow
    //   188: astore_1
    //   189: aload_0
    //   190: monitorexit
    //   191: aload_1
    //   192: athrow
    //   193: astore_1
    //   194: new dbxyzptlk/Fc/Q8
    //   197: dup
    //   198: invokespecial <init> : ()V
    //   201: aload_1
    //   202: invokevirtual getMessage : ()Ljava/lang/String;
    //   205: invokevirtual l : (Ljava/lang/String;)Ldbxyzptlk/Fc/Q8;
    //   208: aload_0
    //   209: getfield c : Ldbxyzptlk/Ec/g;
    //   212: invokevirtual g : (Ldbxyzptlk/Ec/g;)V
    //   215: aload_1
    //   216: athrow
    // Exception table:
    //   from	to	target	type
    //   122	124	193	com/dropbox/android/user/DbxUserManager$RegisterUserException
    //   124	139	188	finally
    //   189	191	188	finally
    //   191	193	193	com/dropbox/android/user/DbxUserManager$RegisterUserException
  }
  
  public final d0 u(u paramu, String paramString, boolean paramBoolean) throws DropboxException, DbxUserManager.RegisterUserException {
    return t(paramu, paramString, paramBoolean);
  }
  
  public final void v(Boolean paramBoolean, String paramString) {
    this.h.h(paramString);
    if (paramBoolean.booleanValue()) {
      this.h.c();
    } else {
      this.h.d();
    } 
  }
  
  public d0 w(String paramString1, c paramc, String paramString2, String paramString3, String paramString4) throws DropboxException, LoginNeedsTwofactorCodeException, LoginNeedsRecaptchaException, LoginRequiresSsoException, DbxUserManager.RegisterUserException {
    u u;
    P(paramString1, paramc, paramString2);
    if (Q()) {
      u = this.i.f(paramString1, paramc, paramString2, paramString3, paramString4, null);
    } else {
      u = l().F(paramString1, paramc, (String)u, paramString3, paramString4);
    } 
    O(u);
    N(u, paramString1, paramc);
    a.j("Successfully authenticated", new Object[0]);
    return s(paramString1, u, "login", false);
  }
  
  public d0 x(b paramb, String paramString1, String paramString2, String paramString3) throws DropboxException, DbxException, LoginNeedsTwofactorCodeException, DbxUserManager.RegisterUserException, NoAuthApi.AppleLoginRequiresSignupException, AppleLoginNeedsPasswordException {
    p.o(paramb);
    p.o(paramString1);
    p.o(paramString2);
    u u = l().Q(paramb, paramString1, paramString2, paramString3);
    K(u, u.c());
    O(u);
    a.j("Successfully authenticated", new Object[0]);
    return t(u, "login", false);
  }
  
  public d0 y(c paramc) throws DropboxException, DbxUserManager.RegisterUserException, LoginNeedsTwofactorCodeException, LoginNeedsRecaptchaException {
    f f = i();
    if (f != null) {
      String str = f.d();
      u u = l().r(paramc, f.a());
      O(u);
      N(u, str, paramc);
      return t(u, "login.apple", false);
    } 
    throw new DropboxException("Tried to log in without an Apple login checkpoint token");
  }
  
  public d0 z(String paramString1, String paramString2, String paramString3) throws DropboxException, DbxUserManager.RegisterUserException, LoginNeedsTwofactorCodeException, GoogleLoginNeedsPasswordException, LoginRequiresSsoException, GoogleLoginRequiresSignupException {
    u u;
    P(paramString1, new c(""), paramString3);
    if (Q()) {
      u = this.i.c(paramString1, paramString2, paramString3);
    } else {
      u = l().H(paramString1, (String)u, paramString3);
    } 
    O(u);
    L(u, paramString1);
    M(u, paramString1);
    a.j("Successfully authenticated", new Object[0]);
    return s(paramString1, u, "login.google", false);
  }
  
  class ApiManager {}
  
  class ApiManager {}
  
  class ApiManager {}
  
  class ApiManager {}
  
  class ApiManager {}
  
  class ApiManager {}
  
  class ApiManager {}
  
  class ApiManager {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\android\filemanager\ApiManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */