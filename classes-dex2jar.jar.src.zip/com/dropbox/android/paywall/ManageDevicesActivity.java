package com.dropbox.android.paywall;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.FragmentManager;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.t;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.dropbox.android.dbapp.manage_devices.models.MobileDeviceToUnlink;
import com.dropbox.common.activity.BaseActivity;
import com.dropbox.common.android.ui.dialogs.DbxAlertDialogFragment;
import com.dropbox.kaiken.scoping.ViewingUserSelector;
import dbxyzptlk.B7.e;
import dbxyzptlk.CI.a;
import dbxyzptlk.CI.l;
import dbxyzptlk.D7.c;
import dbxyzptlk.DI.s;
import dbxyzptlk.Df.b;
import dbxyzptlk.E7.a;
import dbxyzptlk.Ec.g;
import dbxyzptlk.F7.a;
import dbxyzptlk.F7.b;
import dbxyzptlk.Fq.h;
import dbxyzptlk.I7.a;
import dbxyzptlk.I7.c;
import dbxyzptlk.I7.m;
import dbxyzptlk.I7.p;
import dbxyzptlk.K7.b;
import dbxyzptlk.L7.c;
import dbxyzptlk.U2.n;
import dbxyzptlk.U2.z;
import dbxyzptlk.Za.b;
import dbxyzptlk.Za.c;
import dbxyzptlk.Za.d;
import dbxyzptlk.Za.g;
import dbxyzptlk.Za.n;
import dbxyzptlk.ck.e;
import dbxyzptlk.ck.t;
import dbxyzptlk.dk.S;
import dbxyzptlk.dk.d0;
import dbxyzptlk.fp.b;
import dbxyzptlk.ok.b;
import dbxyzptlk.re.k;
import dbxyzptlk.rk.b;
import dbxyzptlk.w6.Q0;
import dbxyzptlk.w6.T0;
import dbxyzptlk.w6.V0;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import kotlin.Metadata;

@Metadata(d1 = {"\000Ê\001\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\007\n\002\020\003\n\002\b\004\n\002\020\013\n\002\b\004\n\002\030\002\n\002\b\004\n\002\020\t\n\002\b\002\n\002\030\002\n\002\b\005\n\002\020 \n\002\030\002\n\002\b\006\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\f\b\007\030\000 m2\0020\0012\0020\0022\0020\0032\0020\004:\003nopB\007¢\006\004\b\005\020\006J\031\020\n\032\0020\t2\b\020\b\032\004\030\0010\007H\002¢\006\004\b\n\020\013J\031\020\f\032\0020\t2\b\020\b\032\004\030\0010\007H\024¢\006\004\b\f\020\013J\017\020\r\032\0020\tH\024¢\006\004\b\r\020\006J\027\020\017\032\0020\t2\006\020\016\032\0020\007H\024¢\006\004\b\017\020\013J\r\020\020\032\0020\t¢\006\004\b\020\020\006J\025\020\023\032\0020\t2\006\020\022\032\0020\021¢\006\004\b\023\020\024J\017\020\025\032\0020\tH\026¢\006\004\b\025\020\006J\027\020\030\032\0020\t2\006\020\027\032\0020\026H\026¢\006\004\b\030\020\031J\017\020\032\032\0020\tH\027¢\006\004\b\032\020\006J\027\020\035\032\0020\0262\006\020\034\032\0020\033H\026¢\006\004\b\035\020\036J\017\020\037\032\0020\tH\002¢\006\004\b\037\020\006J\017\020!\032\0020 H\002¢\006\004\b!\020\"J\027\020%\032\0020\t2\006\020$\032\0020#H\002¢\006\004\b%\020&J\017\020'\032\0020\tH\002¢\006\004\b'\020\006J\031\020(\032\0020\t2\b\020\022\032\004\030\0010\021H\002¢\006\004\b(\020\024J+\020-\032\0020\t2\f\020+\032\b\022\004\022\0020*0)2\f\020,\032\b\022\004\022\0020 0)H\002¢\006\004\b-\020.J\017\020/\032\0020\tH\002¢\006\004\b/\020\006J+\0200\032\0020\t2\f\020+\032\b\022\004\022\0020*0)2\f\020,\032\b\022\004\022\0020 0)H\002¢\006\004\b0\020.R\026\0204\032\002018\002@\002X.¢\006\006\n\004\b2\0203R\026\0208\032\002058\002@\002X.¢\006\006\n\004\b6\0207R\026\020<\032\002098\002@\002X.¢\006\006\n\004\b:\020;R\026\020@\032\0020=8\002@\002X.¢\006\006\n\004\b>\020?R\026\020D\032\0020A8\002@\002X.¢\006\006\n\004\bB\020CR\026\020H\032\0020E8\002@\002X.¢\006\006\n\004\bF\020GR\026\020L\032\0020I8\002@\002X.¢\006\006\n\004\bJ\020KR\026\020P\032\0020M8\002@\002X.¢\006\006\n\004\bN\020OR\026\020T\032\0020Q8\002@\002X.¢\006\006\n\004\bR\020SR\026\020X\032\0020U8\002@\002X.¢\006\006\n\004\bV\020WR\026\020\\\032\0020Y8\002@\002X.¢\006\006\n\004\bZ\020[R\026\020`\032\0020]8\002@\002X.¢\006\006\n\004\b^\020_R\026\020d\032\0020a8\002@\002X.¢\006\006\n\004\bb\020cR\026\020h\032\0020e8\002@\002X.¢\006\006\n\004\bf\020gR\030\020$\032\004\030\0010#8\002@\002X\016¢\006\006\n\004\bi\020jR\026\020\027\032\0020\0268\002@\002X\016¢\006\006\n\004\bk\020l¨\006q"}, d2 = {"Lcom/dropbox/android/paywall/ManageDevicesActivity;", "Lcom/dropbox/common/activity/BaseActivity;", "Ldbxyzptlk/Fq/h;", "Lcom/dropbox/common/android/ui/dialogs/DbxAlertDialogFragment$c;", "Ldbxyzptlk/I7/a$a;", "<init>", "()V", "Landroid/os/Bundle;", "savedInstanceState", "Ldbxyzptlk/pI/D;", "M4", "(Landroid/os/Bundle;)V", "onCreate", "onResumeFragments", "outState", "onSaveInstanceState", "J4", "", "error", "I4", "(Ljava/lang/Throwable;)V", "L0", "", "isEligibleForTrial", "h2", "(Z)V", "onBackPressed", "Landroid/view/MenuItem;", "item", "onOptionsItemSelected", "(Landroid/view/MenuItem;)Z", "Q4", "", "E4", "()J", "Ldbxyzptlk/I7/m$b;", "deviceLimitInfo", "F4", "(Ldbxyzptlk/I7/m$b;)V", "R4", "G4", "", "Lcom/dropbox/android/dbapp/manage_devices/models/MobileDeviceToUnlink;", "mobileDevices", "desktopDevices", "L4", "(Ljava/util/List;Ljava/util/List;)V", "K4", "H4", "Ldbxyzptlk/B7/e;", "c", "Ldbxyzptlk/B7/e;", "binding", "Ldbxyzptlk/L7/c;", "d", "Ldbxyzptlk/L7/c;", "adapter", "Ldbxyzptlk/I7/m;", "e", "Ldbxyzptlk/I7/m;", "model", "Ldbxyzptlk/F7/a;", "f", "Ldbxyzptlk/F7/a;", "deviceLimitApi", "Ldbxyzptlk/I7/p;", "g", "Ldbxyzptlk/I7/p;", "userDeviceLimitManager", "Ldbxyzptlk/ok/b;", "h", "Ldbxyzptlk/ok/b;", "envInfo", "Ldbxyzptlk/E7/a;", "i", "Ldbxyzptlk/E7/a;", "deviceLimitLogger", "Ldbxyzptlk/ck/t;", "j", "Ldbxyzptlk/ck/t;", "userCapabilitiesManager", "Ldbxyzptlk/I7/c;", "k", "Ldbxyzptlk/I7/c;", "eligibilityForTrialChecker", "Ldbxyzptlk/K7/b;", "l", "Ldbxyzptlk/K7/b;", "linkedDevicesStateProvider", "Landroid/widget/TextView;", "m", "Landroid/widget/TextView;", "upgradeButton", "Ldbxyzptlk/D7/c;", "n", "Ldbxyzptlk/D7/c;", "source", "Ldbxyzptlk/fp/b;", "o", "Ldbxyzptlk/fp/b;", "paymentsIntentProvider", "Ldbxyzptlk/ck/e;", "p", "Ldbxyzptlk/ck/e;", "enableFitSystemWindowGate", "q", "Ldbxyzptlk/I7/m$b;", "r", "Z", "s", "a", "ErrorLoadingDeviceInfoDialogFragment", "UnlinkConfirmationDialogFragment", "Dropbox_normalRelease"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class ManageDevicesActivity extends BaseActivity implements h, DbxAlertDialogFragment.c, a.a {
  public static final a s = new a(null);
  
  public static final int t = 8;
  
  public e c;
  
  public c d;
  
  public m e;
  
  public a f;
  
  public p g;
  
  public b h;
  
  public a i;
  
  public t j;
  
  public c k;
  
  public b l;
  
  public TextView m;
  
  public c n;
  
  public b o;
  
  public e p;
  
  public m.b q;
  
  public boolean r;
  
  private final void M4(Bundle paramBundle) {
    e e8 = this.p;
    e e9 = null;
    e e4 = e8;
    if (e8 == null) {
      s.u("enableFitSystemWindowGate");
      e4 = null;
    } 
    if (e4.a()) {
      e e11 = this.c;
      e e10 = e11;
      if (e11 == null) {
        s.u("binding");
        e10 = null;
      } 
      e10.d.setFitsSystemWindows(true);
    } 
    e e7 = this.c;
    e e3 = e7;
    if (e7 == null) {
      s.u("binding");
      e3 = null;
    } 
    e3.h.setHasFixedSize(false);
    e7 = this.c;
    e3 = e7;
    if (e7 == null) {
      s.u("binding");
      e3 = null;
    } 
    e3.h.setLayoutManager((RecyclerView.p)new LinearLayoutManager((Context)this));
    a a1 = this.i;
    if (a1 == null) {
      s.u("deviceLimitLogger");
      a1 = null;
    } 
    c c6 = this.n;
    if (c6 == null) {
      s.u("source");
      c6 = null;
    } 
    p p4 = this.g;
    p p3 = p4;
    if (p4 == null) {
      s.u("userDeviceLimitManager");
      p3 = null;
    } 
    c c3 = new c((Context)this, a1, c6, p3.c());
    this.d = c3;
    c3.r((a)new c(this));
    e e6 = this.c;
    e e2 = e6;
    if (e6 == null) {
      s.u("binding");
      e2 = null;
    } 
    RecyclerView recyclerView = e2.h;
    c c5 = this.d;
    c c2 = c5;
    if (c5 == null) {
      s.u("adapter");
      c2 = null;
    } 
    recyclerView.setAdapter((RecyclerView.h)c2);
    setSupportActionBar((Toolbar)findViewById(Q0.dbx_toolbar));
    ActionBar actionBar = getSupportActionBar();
    if (actionBar != null)
      actionBar.u(true); 
    c c4 = this.n;
    c c1 = c4;
    if (c4 == null) {
      s.u("source");
      c1 = null;
    } 
    if (c1 == c.PAYWALL) {
      setTitle(V0.manage_devices_from_paywall_title);
      e e11 = this.c;
      e e10 = e11;
      if (e11 == null) {
        s.u("binding");
        e10 = null;
      } 
      e10.l.setText(V0.manage_devices_from_paywall_upsell_title);
    } else {
      setTitle(V0.manage_devices_title);
      e e11 = this.c;
      e e10 = e11;
      if (e11 == null) {
        s.u("binding");
        e10 = null;
      } 
      e10.l.setText(V0.manage_devices_upsell_title);
    } 
    m m2 = (m)(new t((z)this)).a(m.class);
    this.e = m2;
    m m1 = m2;
    if (m2 == null) {
      s.u("model");
      m1 = null;
    } 
    m1.K().j((LifecycleOwner)this, (n)new b((l)new d(this)));
    m2 = this.e;
    m1 = m2;
    if (m2 == null) {
      s.u("model");
      m1 = null;
    } 
    b b2 = this.h;
    b b1 = b2;
    if (b2 == null) {
      s.u("envInfo");
      b1 = null;
    } 
    String str = b1.b();
    p p2 = this.g;
    p p1 = p2;
    if (p2 == null) {
      s.u("userDeviceLimitManager");
      p1 = null;
    } 
    a a3 = this.f;
    a a2 = a3;
    if (a3 == null) {
      s.u("deviceLimitApi");
      a2 = null;
    } 
    m1.L(str, p1, a2);
    TextView textView2 = this.m;
    TextView textView1 = textView2;
    if (textView2 == null) {
      s.u("upgradeButton");
      textView1 = null;
    } 
    textView1.setOnClickListener((View.OnClickListener)new b(this));
    e e5 = this.c;
    e e1 = e5;
    if (e5 == null) {
      s.u("binding");
      e1 = null;
    } 
    e1.b.setOnClickListener((View.OnClickListener)new c(this));
    e1 = this.c;
    if (e1 == null) {
      s.u("binding");
      e1 = e9;
    } 
    e1.c.setOnClickListener((View.OnClickListener)new d(this));
    R4();
    if (paramBundle != null)
      h2(paramBundle.getBoolean("SIS_IS_ELIGIBLE_FOR_TRIAL")); 
    Q4();
  }
  
  public static final void N4(ManageDevicesActivity paramManageDevicesActivity, View paramView) {
    s.h(paramManageDevicesActivity, "this$0");
    a a2 = paramManageDevicesActivity.i;
    b b2 = null;
    a a1 = a2;
    if (a2 == null) {
      s.u("deviceLimitLogger");
      a1 = null;
    } 
    c c2 = paramManageDevicesActivity.n;
    c c1 = c2;
    if (c2 == null) {
      s.u("source");
      c1 = null;
    } 
    a1.o(c1, paramManageDevicesActivity.r);
    b b1 = paramManageDevicesActivity.o;
    if (b1 == null) {
      s.u("paymentsIntentProvider");
      b1 = b2;
    } 
    paramManageDevicesActivity.startActivity(b1.a((Context)paramManageDevicesActivity, k.MANAGE_DEVICES));
  }
  
  public static final void O4(ManageDevicesActivity paramManageDevicesActivity, View paramView) {
    s.h(paramManageDevicesActivity, "this$0");
    a a2 = paramManageDevicesActivity.i;
    c c3 = null;
    a a1 = a2;
    if (a2 == null) {
      s.u("deviceLimitLogger");
      a1 = null;
    } 
    c c4 = paramManageDevicesActivity.n;
    c c2 = c4;
    if (c4 == null) {
      s.u("source");
      c2 = null;
    } 
    a1.b(c2);
    ArrayList<MobileDeviceToUnlink> arrayList = new ArrayList();
    ArrayList<Long> arrayList1 = new ArrayList();
    c c1 = paramManageDevicesActivity.d;
    if (c1 == null) {
      s.u("adapter");
      c1 = c3;
    } 
    for (m.a a3 : c1.o()) {
      m.a.b b1;
      if (a3 instanceof m.a.b) {
        b1 = (m.a.b)a3;
        arrayList.add(new MobileDeviceToUnlink(b1.g(), b1.f()));
        continue;
      } 
      if (b1 instanceof m.a.a)
        arrayList1.add(Long.valueOf(((m.a.a)b1).f())); 
    } 
    UnlinkConfirmationDialogFragment.y.a(arrayList, arrayList1).u2((Context)paramManageDevicesActivity, paramManageDevicesActivity.getSupportFragmentManager());
  }
  
  public static final void P4(ManageDevicesActivity paramManageDevicesActivity, View paramView) {
    s.h(paramManageDevicesActivity, "this$0");
    a a2 = paramManageDevicesActivity.i;
    c c1 = null;
    a a1 = a2;
    if (a2 == null) {
      s.u("deviceLimitLogger");
      a1 = null;
    } 
    c c2 = paramManageDevicesActivity.n;
    if (c2 == null) {
      s.u("source");
    } else {
      c1 = c2;
    } 
    a1.a(c1);
    long l = paramManageDevicesActivity.E4();
    String str = paramManageDevicesActivity.getResources().getQuantityString(T0.manage_devices_error_no_devices_selected_body, (int)l, new Object[] { Long.valueOf(l) });
    s.g(str, "getQuantityString(...)");
    DbxAlertDialogFragment dbxAlertDialogFragment = (new DbxAlertDialogFragment.b(paramManageDevicesActivity.getString(V0.manage_devices_error_no_devices_selected_title), str, paramManageDevicesActivity.getString(V0.manage_devices_error_no_devices_selected_ok))).a();
    FragmentManager fragmentManager = paramManageDevicesActivity.getSupportFragmentManager();
    s.g(fragmentManager, "getSupportFragmentManager(...)");
    dbxAlertDialogFragment.show(fragmentManager, "ErrorDialog");
  }
  
  public final long E4() {
    c c3 = this.n;
    c c2 = null;
    c c1 = c3;
    if (c3 == null) {
      s.u("source");
      c1 = null;
    } 
    if (c1 == c.PREFERENCES)
      return 1L; 
    c1 = this.n;
    if (c1 == null) {
      s.u("source");
      c1 = c2;
    } 
    if (c1 == c.MODULAR_ACCOUNT_TAB) {
      m.b b2 = this.q;
      return (b2 == null) ? 0L : ((b2.b() == -1L) ? 0L : Math.max(b2.a().size() - b2.b(), 0L));
    } 
    m.b b1 = this.q;
    return (b1 == null) ? 1L : Math.max(b1.a().size() - b1.b(), 1L);
  }
  
  public final void F4(m.b paramb) {
    ViewingUserSelector viewingUserSelector;
    b b2 = this.l;
    c c3 = null;
    b b1 = b2;
    if (b2 == null) {
      s.u("linkedDevicesStateProvider");
      b1 = null;
    } 
    b1.p();
    c c4 = this.n;
    c c2 = c4;
    if (c4 == null) {
      s.u("source");
      c2 = null;
    } 
    if (c2 == c.PAYWALL && !paramb.c()) {
      ManageDevicesLandingActivity.a a1 = ManageDevicesLandingActivity.d;
      viewingUserSelector = w();
      if (viewingUserSelector != null) {
        startActivity(a1.a((Context)this, viewingUserSelector));
        finish();
        return;
      } 
      throw new IllegalStateException("Required value was null.");
    } 
    e e2 = this.c;
    e e1 = e2;
    if (e2 == null) {
      s.u("binding");
      e1 = null;
    } 
    e1.g.setVisibility(8);
    this.q = (m.b)viewingUserSelector;
    c c1 = this.d;
    if (c1 == null) {
      s.u("adapter");
      c1 = c3;
    } 
    c1.t((m.b)viewingUserSelector);
    Q4();
    R4();
  }
  
  public final void G4(Throwable paramThrowable) {
    ErrorLoadingDeviceInfoDialogFragment.y.a((Context)this, paramThrowable).f4((Context)this, getSupportFragmentManager(), "DeviceInfoLoadError");
  }
  
  public final void H4(List<MobileDeviceToUnlink> paramList, List<Long> paramList1) {
    a a2 = this.i;
    c c1 = null;
    a a1 = a2;
    if (a2 == null) {
      s.u("deviceLimitLogger");
      a1 = null;
    } 
    c c2 = this.n;
    if (c2 == null) {
      s.u("source");
    } else {
      c1 = c2;
    } 
    a1.l(c1, paramList.size() + paramList1.size());
    L4(paramList, paramList1);
  }
  
  public final void I4(Throwable paramThrowable) {
    s.h(paramThrowable, "error");
    e e2 = this.c;
    e e1 = e2;
    if (e2 == null) {
      s.u("binding");
      e1 = null;
    } 
    e1.f.setVisibility(8);
    if (paramThrowable instanceof com.dropbox.core.NetworkIOException) {
      DbxAlertDialogFragment dbxAlertDialogFragment = (new DbxAlertDialogFragment.b(getString(V0.manage_devices_unlink_error_network_title), getString(V0.manage_devices_unlink_error_network_body), getString(V0.manage_devices_error_network_ok))).a();
      FragmentManager fragmentManager = getSupportFragmentManager();
      s.g(fragmentManager, "getSupportFragmentManager(...)");
      dbxAlertDialogFragment.show(fragmentManager, "NetworkErrorDialog");
    } else {
      DbxAlertDialogFragment dbxAlertDialogFragment = (new DbxAlertDialogFragment.b(null, getString(V0.manage_devices_error_unlink), getString(V0.ok))).a();
      FragmentManager fragmentManager = getSupportFragmentManager();
      s.g(fragmentManager, "getSupportFragmentManager(...)");
      dbxAlertDialogFragment.show(fragmentManager, "ErrorDialog");
    } 
  }
  
  public final void J4() {
    K4();
    e e2 = this.c;
    e e1 = e2;
    if (e2 == null) {
      s.u("binding");
      e1 = null;
    } 
    e1.f.setVisibility(8);
  }
  
  public final void K4() {
    m m2 = this.e;
    a a1 = null;
    m m1 = m2;
    if (m2 == null) {
      s.u("model");
      m1 = null;
    } 
    b b2 = this.h;
    b b1 = b2;
    if (b2 == null) {
      s.u("envInfo");
      b1 = null;
    } 
    String str = b1.b();
    p p2 = this.g;
    p p1 = p2;
    if (p2 == null) {
      s.u("userDeviceLimitManager");
      p1 = null;
    } 
    a a2 = this.f;
    if (a2 == null) {
      s.u("deviceLimitApi");
    } else {
      a1 = a2;
    } 
    m1.L(str, p1, a1);
  }
  
  public void L0() {}
  
  public final void L4(List<MobileDeviceToUnlink> paramList, List<Long> paramList1) {
    a a2 = this.f;
    e e2 = null;
    a a1 = a2;
    if (a2 == null) {
      s.u("deviceLimitApi");
      a1 = null;
    } 
    (new n(this, a1, paramList, paramList1)).execute((Object[])new Void[0]);
    e e1 = this.c;
    if (e1 == null) {
      s.u("binding");
      e1 = e2;
    } 
    e1.f.setVisibility(0);
  }
  
  public final void Q4() {
    boolean bool;
    c c2 = this.d;
    e e2 = null;
    c c1 = c2;
    if (c2 == null) {
      s.u("adapter");
      c1 = null;
    } 
    if (c1.n() >= E4()) {
      bool = true;
    } else {
      bool = false;
    } 
    e e3 = this.c;
    e e1 = e3;
    if (e3 == null) {
      s.u("binding");
      e1 = null;
    } 
    e1.b.setEnabled(bool);
    e1 = this.c;
    if (e1 == null) {
      s.u("binding");
      e1 = e2;
    } 
    e1.b.setClickable(bool);
  }
  
  public final void R4() {
    long l;
    m.b b1 = this.q;
    e e3 = null;
    e e2 = null;
    if (b1 != null) {
      l = b1.b();
    } else {
      p p2 = this.g;
      p p1 = p2;
      if (p2 == null) {
        s.u("userDeviceLimitManager");
        p1 = null;
      } 
      l = p1.c();
    } 
    t t2 = this.j;
    t t1 = t2;
    if (t2 == null) {
      s.u("userCapabilitiesManager");
      t1 = null;
    } 
    boolean bool = d0.c(t1);
    if (l == Long.MAX_VALUE || !bool) {
      e e4 = this.c;
      if (e4 == null) {
        s.u("binding");
        e4 = e3;
      } 
      e4.e.setVisibility(8);
      return;
    } 
    e e1 = this.c;
    if (e1 == null) {
      s.u("binding");
      e1 = e2;
    } 
    e1.e.setVisibility(0);
  }
  
  public void h2(boolean paramBoolean) {
    this.r = paramBoolean;
    TextView textView2 = null;
    TextView textView1 = null;
    if (paramBoolean) {
      textView2 = this.m;
      if (textView2 == null) {
        s.u("upgradeButton");
      } else {
        textView1 = textView2;
      } 
      b.b(textView1, getString(V0.manage_devices_upgrade_with_trial_text));
    } else {
      textView1 = this.m;
      if (textView1 == null) {
        s.u("upgradeButton");
        textView1 = textView2;
      } 
      b.b(textView1, getString(V0.manage_devices_upgrade_text));
    } 
  }
  
  public void onBackPressed() {
    super.onBackPressed();
    a a2 = this.i;
    c c1 = null;
    a a1 = a2;
    if (a2 == null) {
      s.u("deviceLimitLogger");
      a1 = null;
    } 
    c c2 = this.n;
    if (c2 == null) {
      s.u("source");
    } else {
      c1 = c2;
    } 
    a1.g(c1);
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    if (u())
      return; 
    g g = (g)s();
    b b1 = g.Z8();
    this.f = (a)new b(g.D(), b1);
    this.g = g.T7();
    this.h = g.n0();
    this.i = new a((g)g.j());
    this.j = g.O();
    this.k = g.U3();
    this.o = g.o();
    this.l = g.u1();
    this.p = g.A();
    Intent intent = getIntent();
    s.g(intent, "getIntent(...)");
    Serializable serializable = S.b(intent, "EXTRA_SOURCE", c.class);
    s.e(serializable);
    this.n = (c)serializable;
    a a2 = this.i;
    e e2 = null;
    a a1 = a2;
    if (a2 == null) {
      s.u("deviceLimitLogger");
      a1 = null;
    } 
    c c2 = this.n;
    c c1 = c2;
    if (c2 == null) {
      s.u("source");
      c1 = null;
    } 
    a1.i(c1);
    e e1 = e.c(getLayoutInflater());
    s.g(e1, "inflate(...)");
    this.c = e1;
    if (e1 == null) {
      s.u("binding");
      e1 = e2;
    } 
    setContentView((View)e1.b());
    View view = findViewById(Q0.upgradeButton);
    s.g(view, "findViewById(...)");
    this.m = (TextView)view;
    M4(paramBundle);
  }
  
  public boolean onOptionsItemSelected(MenuItem paramMenuItem) {
    s.h(paramMenuItem, "item");
    if (paramMenuItem.getItemId() == 16908332) {
      a a2 = this.i;
      c c1 = null;
      a a1 = a2;
      if (a2 == null) {
        s.u("deviceLimitLogger");
        a1 = null;
      } 
      c c2 = this.n;
      if (c2 == null) {
        s.u("source");
      } else {
        c1 = c2;
      } 
      a1.g(c1);
    } 
    return super.onOptionsItemSelected(paramMenuItem);
  }
  
  public void onResumeFragments() {
    super.onResumeFragments();
    c c2 = this.k;
    c c1 = c2;
    if (c2 == null) {
      s.u("eligibilityForTrialChecker");
      c1 = null;
    } 
    (new a((BaseActivity)this, c1)).execute((Object[])new Void[0]);
  }
  
  public void onSaveInstanceState(Bundle paramBundle) {
    s.h(paramBundle, "outState");
    super.onSaveInstanceState(paramBundle);
    paramBundle.putBoolean("SIS_IS_ELIGIBLE_FOR_TRIAL", this.r);
  }
  
  class ManageDevicesActivity {}
  
  class ManageDevicesActivity {}
  
  class ManageDevicesActivity {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\android\paywall\ManageDevicesActivity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */