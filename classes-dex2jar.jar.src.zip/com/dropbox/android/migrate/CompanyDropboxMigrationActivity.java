package com.dropbox.android.migrate;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.SpannableStringBuilder;
import android.text.method.LinkMovementMethod;
import android.util.Pair;
import android.view.View;
import android.widget.TextView;
import com.dropbox.android.DropboxApplication;
import com.dropbox.android.activity.DropboxBrowser;
import com.dropbox.android.preference.a;
import com.dropbox.android.settings.UnlinkDialog;
import com.dropbox.common.activity.BaseActivity;
import com.dropbox.common.android.ui.widgets.FullscreenImageTitleTextButtonView;
import dbxyzptlk.EC.D;
import dbxyzptlk.F6.m;
import dbxyzptlk.Me.a;
import dbxyzptlk.N9.c;
import dbxyzptlk.N9.d;
import dbxyzptlk.N9.e;
import dbxyzptlk.Na.b;
import dbxyzptlk.Na.c;
import dbxyzptlk.Na.d;
import dbxyzptlk.Na.e;
import dbxyzptlk.Na.f;
import dbxyzptlk.Na.g;
import dbxyzptlk.Na.h;
import dbxyzptlk.Na.k;
import dbxyzptlk.Na.q;
import dbxyzptlk.Na.r;
import dbxyzptlk.Na.s;
import dbxyzptlk.Z2.a;
import dbxyzptlk.ci.a;
import dbxyzptlk.dk.W;
import dbxyzptlk.dk.g;
import dbxyzptlk.gh.k;
import dbxyzptlk.gh.l;
import dbxyzptlk.pc.d0;
import dbxyzptlk.w6.V0;
import java.util.ArrayList;

public class CompanyDropboxMigrationActivity extends BaseActivity implements UnlinkDialog.b, a.a, s, r, a {
  public q c;
  
  public FullscreenImageTitleTextButtonView d;
  
  public TextView e;
  
  public d f;
  
  public final a.a<a> g = (a.a<a>)new a(this);
  
  public static Intent E4(Context paramContext) {
    Intent intent = new Intent(paramContext, CompanyDropboxMigrationActivity.class);
    intent.setFlags(268468224);
    return intent;
  }
  
  public final SpannableStringBuilder D4() {
    W w = new W(getResources().getString(V0.cdm_migration_logout_text));
    Pair pair = (Pair)D.o(w.a());
    SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder(w.toString());
    W.b(getResources(), spannableStringBuilder, ((Integer)pair.first).intValue(), ((Integer)pair.second).intValue(), (g.a)new b(this));
    return spannableStringBuilder;
  }
  
  public void K0() {
    this.d.post((Runnable)new g(this));
  }
  
  public final void M4() {
    TextView textView = new TextView((Context)this);
    this.e = textView;
    textView.setTextAppearance(l.Body_Large);
    this.e.setText((CharSequence)D4());
    this.e.setMovementMethod(LinkMovementMethod.getInstance());
  }
  
  public void N1() {
    finish();
  }
  
  public final void N4() {
    this.d.setButtonVisibility(0);
    this.d.setButtonEnabled(true);
    this.d.setTitleText(V0.cdm_migration_title_error);
  }
  
  public boolean O2() {
    return false;
  }
  
  public void P2(ArrayList<String> paramArrayList) {
    UnlinkDialog.p2(this, paramArrayList).show(getSupportFragmentManager(), UnlinkDialog.t);
  }
  
  public void S0() {
    this.d.post((Runnable)new e(this));
  }
  
  public void T() {
    this.d.setBottomContent((View)this.e);
  }
  
  public boolean X2() {
    return false;
  }
  
  public void Y3(boolean paramBoolean) {
    N4();
    if (paramBoolean)
      this.d.setBottomContent((View)this.e); 
    this.d.setBodyText(V0.cdm_migration_subtitle_network_error);
    this.d.setButtonText(V0.cdm_migration_button_retry_network_error);
    this.d.setButtonOnClickListener((View.OnClickListener)new d(this));
  }
  
  public void Z2() {}
  
  public void b2(d0 paramd0) {
    (new k((Context)this, paramd0)).execute((Object[])new Void[0]);
  }
  
  public void cancel() {
    setResult(0);
    finish();
  }
  
  public void f0() {
    this.d.post((Runnable)new f(this));
  }
  
  public void f2() {
    this.d.setLottieResource(k.ic_dig_phone_checkmark_spot);
    this.d.a();
    this.d.setTitleText(V0.cdm_migration_title_done);
    this.d.setBodyText(V0.cdm_migration_subtitle_done);
    this.d.setButtonText(V0.cdm_migration_button_done);
    this.d.setButtonVisibility(0);
    this.d.setButtonEnabled(true);
    this.d.setBottomContentVisibility(8);
    this.d.setButtonOnClickListener((View.OnClickListener)new c(this));
  }
  
  public void i0(boolean paramBoolean) {
    N4();
    if (paramBoolean)
      this.d.setBottomContent((View)this.e); 
    this.d.setBodyText(V0.cdm_migration_subtitle_error);
    this.d.setButtonText(V0.cdm_migration_button_retry_error);
    this.d.setButtonOnClickListener((View.OnClickListener)new h(this));
  }
  
  public void k(ArrayList<String> paramArrayList) {
    this.c.k(paramArrayList);
  }
  
  public boolean k0() {
    return m.a.k0();
  }
  
  public void m0() {
    getSupportLoaderManager().f(0, null, this.g);
  }
  
  public void n(ArrayList<String> paramArrayList) {
    this.c.n(paramArrayList);
  }
  
  public void o() {
    this.c.o();
    finish();
    startActivity(DropboxBrowser.z4());
  }
  
  public void o3() {
    this.d.setLottieResource(k.ic_dig_peaceful_fishing_spot);
    this.d.a();
    this.d.setTitleText(V0.cdm_migration_title);
    this.d.setBodyText(V0.cdm_migration_subtitle);
    this.d.setButtonVisibility(8);
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    d d1 = ((c)((DropboxApplication)getApplication()).A()).j1(new e(this));
    this.f = d1;
    d1.a(this);
    M4();
    FullscreenImageTitleTextButtonView fullscreenImageTitleTextButtonView = new FullscreenImageTitleTextButtonView((Context)this);
    this.d = fullscreenImageTitleTextButtonView;
    setContentView((View)fullscreenImageTitleTextButtonView);
    if (paramBundle == null) {
      this.c.x();
    } else {
      this.c.z(paramBundle.getString("SIS_USER_ID"), paramBundle.getSerializable("SIS_MIGRATION_STATE"));
    } 
    setResult(-1);
  }
  
  public void onDestroy() {
    super.onDestroy();
    this.f = null;
  }
  
  public void onSaveInstanceState(Bundle paramBundle) {
    super.onSaveInstanceState(paramBundle);
    paramBundle.putSerializable("SIS_MIGRATION_STATE", this.c.a());
    paramBundle.putString("SIS_USER_ID", this.c.l());
  }
  
  public d0 t(String paramString) {
    return this.c.t(paramString);
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\android\migrate\CompanyDropboxMigrationActivity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */