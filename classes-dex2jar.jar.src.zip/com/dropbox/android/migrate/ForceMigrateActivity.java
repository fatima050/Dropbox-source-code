package com.dropbox.android.migrate;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.text.SpannableStringBuilder;
import android.text.method.LinkMovementMethod;
import android.util.Pair;
import android.view.View;
import android.widget.TextView;
import com.dropbox.android.DropboxApplication;
import com.dropbox.android.activity.DropboxBrowser;
import com.dropbox.android.preference.a;
import com.dropbox.android.settings.UnlinkDialog;
import com.dropbox.android.user.DbxUserManager;
import com.dropbox.android.user.a;
import com.dropbox.common.activity.BaseActivity;
import com.dropbox.common.android.ui.widgets.FullscreenImageTitleTextButtonView;
import dbxyzptlk.CC.p;
import dbxyzptlk.EC.G;
import dbxyzptlk.Na.v;
import dbxyzptlk.Na.x;
import dbxyzptlk.Z2.a;
import dbxyzptlk.ci.a;
import dbxyzptlk.dk.W;
import dbxyzptlk.dk.g;
import dbxyzptlk.gh.l;
import dbxyzptlk.jf.E;
import dbxyzptlk.pc.d0;
import dbxyzptlk.pc.u0;
import dbxyzptlk.w6.P0;
import dbxyzptlk.w6.V0;
import java.util.ArrayList;
import java.util.Iterator;

public class ForceMigrateActivity extends BaseActivity implements UnlinkDialog.b, a.a, a {
  public DbxUserManager c;
  
  public a<ForceMigrateActivity> d;
  
  public final a.a<Boolean> e = (a.a<Boolean>)new b(this);
  
  private SpannableStringBuilder A4() {
    W w = new W(getResources().getString(V0.forced_migration_logout_text));
    int i = w.a().size();
    boolean bool = true;
    if (i != 1)
      bool = false; 
    p.e(bool, "Assert failed.");
    Pair pair = w.a().get(0);
    SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder(w.toString());
    W.b(getResources(), spannableStringBuilder, ((Integer)pair.first).intValue(), ((Integer)pair.second).intValue(), (g.a)new a(this));
    return spannableStringBuilder;
  }
  
  public boolean O2() {
    return false;
  }
  
  public boolean X2() {
    return false;
  }
  
  public void Z2() {}
  
  public void k(ArrayList<String> paramArrayList) {
    this.d.g(paramArrayList);
  }
  
  public boolean k0() {
    return false;
  }
  
  public void n(ArrayList<String> paramArrayList) {
    this.d.k(paramArrayList);
  }
  
  public void o() {
    this.d.j();
    finish();
    startActivity(DropboxBrowser.z4());
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    DbxUserManager dbxUserManager = DropboxApplication.b1((Context)this);
    this.c = dbxUserManager;
    this.d = new a((Activity)this, dbxUserManager, DropboxApplication.b0((Context)this));
    TextView textView = new TextView((Context)this);
    textView.setTextAppearance(l.Body_Large);
    textView.setText((CharSequence)A4());
    textView.setMovementMethod(LinkMovementMethod.getInstance());
    FullscreenImageTitleTextButtonView fullscreenImageTitleTextButtonView = new FullscreenImageTitleTextButtonView((Context)this);
    fullscreenImageTitleTextButtonView.setImageResource(P0.fm_splash);
    fullscreenImageTitleTextButtonView.setTitleText(V0.forced_migration_title);
    y4(fullscreenImageTitleTextButtonView);
    fullscreenImageTitleTextButtonView.setButtonText(V0.force_migration_button);
    fullscreenImageTitleTextButtonView.setButtonOnClickListener((View.OnClickListener)new v(this));
    fullscreenImageTitleTextButtonView.setBottomContent((View)textView);
    setContentView((View)fullscreenImageTitleTextButtonView);
    setResult(-1);
    getSupportLoaderManager().f(0, null, this.e);
  }
  
  public Dialog onCreateDialog(int paramInt) {
    return this.d.i(paramInt);
  }
  
  public d0 t(String paramString) {
    d0 d0;
    a a1 = DropboxApplication.b1((Context)this).a();
    if (a1 == null) {
      paramString = null;
    } else {
      d0 = a1.q(paramString);
    } 
    return d0;
  }
  
  public final void y4(FullscreenImageTitleTextButtonView paramFullscreenImageTitleTextButtonView) {
    a a1 = this.c.a();
    if (a1 == null) {
      finish();
      return;
    } 
    d0 d01 = a1.r(u0.BUSINESS);
    d0 d02 = a1.r(u0.PERSONAL);
    if (d01 != null && x.c(d01, false)) {
      String str = d01.a();
    } else if (d02 != null && x.c(d02, false)) {
      String str = d02.a();
    } else {
      d01 = null;
    } 
    if (d01 != null) {
      paramFullscreenImageTitleTextButtonView.setBodyText(getResources().getString(V0.forced_migration_subtitle_with_email, new Object[] { d01 }));
    } else {
      paramFullscreenImageTitleTextButtonView.setBodyText(V0.forced_migration_subtitle);
    } 
  }
  
  public final void z4() {
    a a1 = this.c.a();
    if (a1 == null) {
      finish();
      return;
    } 
    ArrayList<String> arrayList = G.i(a.s(a1));
    Iterator<d0> iterator = a1.b().iterator();
    while (iterator.hasNext())
      arrayList.add(((d0)iterator.next()).getId()); 
    UnlinkDialog.p2(this, arrayList).show(getSupportFragmentManager(), UnlinkDialog.t);
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\android\migrate\ForceMigrateActivity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */