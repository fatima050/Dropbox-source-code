package com.dropbox.android.preference;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import com.dropbox.android.DropboxApplication;
import com.dropbox.android.activity.base.BaseUserActivity;
import com.dropbox.android.settings.UnlinkDialog;
import com.dropbox.common.activity.BaseActivity;
import dbxyzptlk.DI.s;
import dbxyzptlk.pc.d0;
import dbxyzptlk.qI.s;
import java.util.ArrayList;
import kotlin.Metadata;

@Metadata(d1 = {"\000F\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\020\016\n\002\b\007\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\006\b\007\030\000 !2\0020\0012\0020\0022\0020\003:\001\"B\007¢\006\004\b\004\020\005J\031\020\t\032\0020\b2\b\020\007\032\004\030\0010\006H\024¢\006\004\b\t\020\nJ\035\020\016\032\0020\b2\f\020\r\032\b\022\004\022\0020\f0\013H\026¢\006\004\b\016\020\017J\017\020\020\032\0020\bH\026¢\006\004\b\020\020\005J\035\020\021\032\0020\b2\f\020\r\032\b\022\004\022\0020\f0\013H\026¢\006\004\b\021\020\017J\017\020\022\032\0020\bH\026¢\006\004\b\022\020\005J\031\020\025\032\0020\0242\b\020\023\032\004\030\0010\fH\026¢\006\004\b\025\020\026R\026\020\023\032\0020\f8\002@\002X.¢\006\006\n\004\b\027\020\030R\034\020\034\032\b\022\004\022\0020\0000\0318\002@\002X.¢\006\006\n\004\b\032\020\033R\026\020 \032\0020\0358\002@\002X.¢\006\006\n\004\b\036\020\037¨\006#"}, d2 = {"Lcom/dropbox/android/preference/LogoutActivity;", "Lcom/dropbox/android/activity/base/BaseUserActivity;", "Lcom/dropbox/android/settings/UnlinkDialog$b;", "Lcom/dropbox/android/preference/a$a;", "<init>", "()V", "Landroid/os/Bundle;", "savedInstanceState", "Ldbxyzptlk/pI/D;", "onCreate", "(Landroid/os/Bundle;)V", "Ljava/util/ArrayList;", "", "userIds", "k", "(Ljava/util/ArrayList;)V", "Z2", "n", "o", "userId", "Ldbxyzptlk/pc/d0;", "t", "(Ljava/lang/String;)Ldbxyzptlk/pc/d0;", "g", "Ljava/lang/String;", "Lcom/dropbox/android/preference/a;", "h", "Lcom/dropbox/android/preference/a;", "unlinkHelper", "Lcom/dropbox/android/settings/UnlinkDialog;", "i", "Lcom/dropbox/android/settings/UnlinkDialog;", "unlinkDialog", "j", "a", "Dropbox_normalRelease"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class LogoutActivity extends BaseUserActivity implements UnlinkDialog.b, a$a {
  public static final a j = new a(null);
  
  public static final int k = 8;
  
  public String g;
  
  public a<LogoutActivity> h;
  
  public UnlinkDialog i;
  
  public void Z2() {
    UnlinkDialog unlinkDialog2 = this.i;
    UnlinkDialog unlinkDialog1 = unlinkDialog2;
    if (unlinkDialog2 == null) {
      s.u("unlinkDialog");
      unlinkDialog1 = null;
    } 
    unlinkDialog1.dismiss();
    finish();
  }
  
  public void k(ArrayList<String> paramArrayList) {
    s.h(paramArrayList, "userIds");
    a<LogoutActivity> a2 = this.h;
    a<LogoutActivity> a1 = a2;
    if (a2 == null) {
      s.u("unlinkHelper");
      a1 = null;
    } 
    a1.g(paramArrayList);
  }
  
  public void n(ArrayList<String> paramArrayList) {
    s.h(paramArrayList, "userIds");
    a<LogoutActivity> a2 = this.h;
    a<LogoutActivity> a1 = a2;
    if (a2 == null) {
      s.u("unlinkHelper");
      a1 = null;
    } 
    a1.k(paramArrayList);
  }
  
  public void o() {
    a<LogoutActivity> a2 = this.h;
    a<LogoutActivity> a1 = a2;
    if (a2 == null) {
      s.u("unlinkHelper");
      a1 = null;
    } 
    a1.j();
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    if (w4())
      return; 
    Bundle bundle = getIntent().getExtras();
    if (bundle != null) {
      s.g(bundle, "requireNotNull(...)");
      String str = bundle.getString("EXTRA_USER_ID");
      if (str != null) {
        this.g = str;
        DropboxApplication.a a1 = DropboxApplication.h;
        this.h = new a((Activity)this, a1.q0((Context)this), a1.l((Context)this));
        UnlinkDialog.a a2 = UnlinkDialog.s;
        String str2 = this.g;
        UnlinkDialog unlinkDialog2 = null;
        String str1 = str2;
        if (str2 == null) {
          s.u("userId");
          str1 = null;
        } 
        this.i = UnlinkDialog.a.d(a2, (BaseActivity)this, s.g((Object[])new String[] { str1 }, ), null, null, 12, null);
        A4(paramBundle);
        UnlinkDialog unlinkDialog1 = this.i;
        if (unlinkDialog1 == null) {
          s.u("unlinkDialog");
          unlinkDialog1 = unlinkDialog2;
        } 
        unlinkDialog1.show(getSupportFragmentManager(), "LogoutActivity.kt");
        return;
      } 
      throw new IllegalArgumentException("Required value was null.");
    } 
    throw new IllegalArgumentException("Required value was null.");
  }
  
  public d0 t(String paramString) {
    d0 d0 = z4().q(paramString);
    if (d0 != null)
      return d0; 
    throw new IllegalArgumentException("Required value was null.");
  }
  
  class LogoutActivity {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\android\preference\LogoutActivity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */