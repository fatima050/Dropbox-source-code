package com.dropbox.android.activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Parcelable;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewOutlineProvider;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.o;
import androidx.lifecycle.i;
import androidx.lifecycle.t;
import com.dropbox.android.DropboxApplication;
import com.dropbox.android.activity.base.BaseIdentityActivity;
import com.dropbox.android.activity.base.BaseIdentityFragment;
import com.dropbox.android.content.activityfeed.ActivityTabbedFragment;
import com.dropbox.android.content.notifications.activity.NotificationsActivity;
import com.dropbox.android.dbapp.modular_account_tab.ui.impl.view.ModularAccountTabFragment;
import com.dropbox.android.fileactions.FileLauncher;
import com.dropbox.android.preference.PreferenceActivity;
import com.dropbox.android.preference.UserPreferenceFragment;
import com.dropbox.android.preference.a;
import com.dropbox.android.settings.UnlinkDialog;
import com.dropbox.android.sharing.FileExportBroadcastReceiver;
import com.dropbox.android.sharing.snackbar.SnackbarBroadcastReceiver;
import com.dropbox.android.update.MainActivityBanner;
import com.dropbox.android.user.UserSelector;
import com.dropbox.android.user.a;
import com.dropbox.common.activity.BaseActivity;
import com.dropbox.common.android.ui.dialogs.DbxAlertDialogFragment;
import com.dropbox.common.android.ui.widgets.DbxToolbar;
import com.dropbox.common.taskqueue.TaskResult;
import com.dropbox.common.util.LifecycleExecutor;
import com.dropbox.dbapp.android.file_actions.DeleteDialogFragment;
import com.dropbox.drawer_deprecation.impl.RealDrawerDeprecationTooltipManager;
import com.dropbox.kaiken.scoping.ViewingUserSelector;
import com.dropbox.product.android.dbapp.filerequest.view.FileRequestsFragment;
import com.dropbox.product.android.dbapp.photos.ui.view.PhotosFragment;
import com.dropbox.product.android.dbapp.teamactivity.view.TeamActivityFragment;
import com.dropbox.product.dbapp.directorypicker.FileSystemWarningDialogFrag;
import com.dropbox.product.dbapp.entry.DropboxLocalEntry;
import com.dropbox.product.dbapp.entry.LocalEntry;
import com.dropbox.product.dbapp.file_manager.Changesets;
import com.dropbox.product.dbapp.modular_home.impl.view.ModularHomeFragment;
import com.dropbox.product.dbapp.path.DropboxPath;
import com.dropbox.product.dbapp.upload.FileSystemWarningUploadResult;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.navigation.NavigationBarView;
import com.google.android.material.snackbar.Snackbar;
import dbxyzptlk.Bf.c;
import dbxyzptlk.Bf.d;
import dbxyzptlk.Bf.g;
import dbxyzptlk.CC.m;
import dbxyzptlk.CC.p;
import dbxyzptlk.CI.a;
import dbxyzptlk.CI.p;
import dbxyzptlk.Df.j;
import dbxyzptlk.Df.k;
import dbxyzptlk.Df.x;
import dbxyzptlk.E6.F0;
import dbxyzptlk.E6.J0;
import dbxyzptlk.E6.a;
import dbxyzptlk.E6.l3;
import dbxyzptlk.E6.o;
import dbxyzptlk.E6.p;
import dbxyzptlk.E6.q;
import dbxyzptlk.E6.r;
import dbxyzptlk.E6.s;
import dbxyzptlk.E6.t;
import dbxyzptlk.E6.u;
import dbxyzptlk.E6.v;
import dbxyzptlk.E6.w;
import dbxyzptlk.E6.y;
import dbxyzptlk.EC.G;
import dbxyzptlk.Ec.a;
import dbxyzptlk.Ec.d;
import dbxyzptlk.Ec.g;
import dbxyzptlk.Em.F;
import dbxyzptlk.Em.n;
import dbxyzptlk.Fc.D6;
import dbxyzptlk.Fc.U3;
import dbxyzptlk.Fe.b;
import dbxyzptlk.Fq.f;
import dbxyzptlk.Fq.o;
import dbxyzptlk.He.i;
import dbxyzptlk.Ho.b;
import dbxyzptlk.Ho.c;
import dbxyzptlk.Ho.f;
import dbxyzptlk.Ho.g;
import dbxyzptlk.Ho.h;
import dbxyzptlk.Ho.i;
import dbxyzptlk.Ho.j;
import dbxyzptlk.Ho.k;
import dbxyzptlk.Ho.l;
import dbxyzptlk.Ho.m;
import dbxyzptlk.Ho.r;
import dbxyzptlk.Ho.u;
import dbxyzptlk.Io.f;
import dbxyzptlk.J4.d;
import dbxyzptlk.K6.a;
import dbxyzptlk.K8.d;
import dbxyzptlk.Km.b;
import dbxyzptlk.Ko.a;
import dbxyzptlk.Ky.m;
import dbxyzptlk.Lm.a;
import dbxyzptlk.Lq.a;
import dbxyzptlk.Me.a;
import dbxyzptlk.N9.J;
import dbxyzptlk.Ni.b;
import dbxyzptlk.Ni.c;
import dbxyzptlk.Or.a;
import dbxyzptlk.P7.a;
import dbxyzptlk.Rh.b;
import dbxyzptlk.Rw.b;
import dbxyzptlk.Rx.a;
import dbxyzptlk.Rx.b;
import dbxyzptlk.Sq.C;
import dbxyzptlk.Sq.k;
import dbxyzptlk.T1.r;
import dbxyzptlk.T6.d;
import dbxyzptlk.T6.f;
import dbxyzptlk.U2.g;
import dbxyzptlk.U2.z;
import dbxyzptlk.Uw.x;
import dbxyzptlk.V6.b;
import dbxyzptlk.Vy.k;
import dbxyzptlk.W6.d;
import dbxyzptlk.W6.x;
import dbxyzptlk.Y7.a;
import dbxyzptlk.Y7.h;
import dbxyzptlk.Y7.i;
import dbxyzptlk.Yr.a;
import dbxyzptlk.Yr.b;
import dbxyzptlk.Yr.c;
import dbxyzptlk.Yr.g;
import dbxyzptlk.Zr.c;
import dbxyzptlk.bK.J;
import dbxyzptlk.bf.a;
import dbxyzptlk.d7.a;
import dbxyzptlk.d7.b;
import dbxyzptlk.dk.H;
import dbxyzptlk.dk.S;
import dbxyzptlk.ef.E;
import dbxyzptlk.fb.i;
import dbxyzptlk.iH.c;
import dbxyzptlk.iy.B;
import dbxyzptlk.jf.u;
import dbxyzptlk.lH.g;
import dbxyzptlk.lq.f;
import dbxyzptlk.lq.j;
import dbxyzptlk.mi.c;
import dbxyzptlk.mi.d;
import dbxyzptlk.nc.a;
import dbxyzptlk.nc.b;
import dbxyzptlk.nc.d;
import dbxyzptlk.no.d;
import dbxyzptlk.no.e;
import dbxyzptlk.no.f;
import dbxyzptlk.no.m;
import dbxyzptlk.oq.a;
import dbxyzptlk.oq.e;
import dbxyzptlk.pI.D;
import dbxyzptlk.pc.d0;
import dbxyzptlk.pc.u0;
import dbxyzptlk.pf.d;
import dbxyzptlk.pf.g;
import dbxyzptlk.pf.j;
import dbxyzptlk.qb.e;
import dbxyzptlk.qx.f;
import dbxyzptlk.rc.b;
import dbxyzptlk.ry.f;
import dbxyzptlk.sL.a;
import dbxyzptlk.sc.P;
import dbxyzptlk.sc.g;
import dbxyzptlk.sh.e;
import dbxyzptlk.t9.g;
import dbxyzptlk.ui.g;
import dbxyzptlk.w6.Q0;
import dbxyzptlk.w6.R0;
import dbxyzptlk.w6.T0;
import dbxyzptlk.w6.V0;
import dbxyzptlk.wa.k;
import dbxyzptlk.wc.d;
import dbxyzptlk.xw.a;
import dbxyzptlk.ye.b0;
import dbxyzptlk.yn.j;
import dbxyzptlk.yx.e;
import dbxyzptlk.zb.b0;
import dbxyzptlk.zn.d;
import io.reactivex.android.schedulers.AndroidSchedulers;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.TimeUnit;

public class DbxMainActivity extends BaseIdentityActivity implements f, MainBrowserLoadingFragment$c, c$e, a$n, DbxToolbar.c, d, DeleteDialogFragment.d, f, FileSystemWarningDialogFrag.e, DbxAlertDialogFragment.c, k, a, UnlinkDialog.b, a.a, f, FileLauncher.a, k, a, c, a, i, m, TeamActivityFragment.b {
  public static final String Y = i.a(DbxMainActivity.class, new Object[0]);
  
  public LifecycleExecutor A;
  
  public a<DbxMainActivity> B = null;
  
  public f C;
  
  public b D;
  
  public x E;
  
  public d F;
  
  public l3 G;
  
  public boolean H;
  
  public d I;
  
  public a J;
  
  public g K;
  
  public g L;
  
  public j M;
  
  public u N;
  
  public g O;
  
  public h P;
  
  public d0 Q;
  
  public f R;
  
  public g S;
  
  public C T;
  
  public b0 U;
  
  public i V;
  
  public e W;
  
  public a X;
  
  public final j d = j.b();
  
  public final EnumMap<j, Fragment> e = new EnumMap<>(j.class);
  
  public g f;
  
  public E g;
  
  public c h;
  
  public c<DbxMainActivity> i;
  
  public a j;
  
  public DbxToolbar k;
  
  public AppBarLayout l;
  
  public View m;
  
  public DrawerLayout n;
  
  public View o;
  
  public MainActivityBanner p;
  
  public final c q = new c();
  
  public boolean r = false;
  
  public boolean s = false;
  
  public F0 t;
  
  public k u;
  
  public d v;
  
  public l w;
  
  public f x;
  
  public i y;
  
  public c z = null;
  
  public static boolean R5(j paramj) {
    p.o(paramj);
    int n = i.b[paramj.ordinal()];
    return (n != 1 && n != 3 && n != 9 && n != 6 && n != 7);
  }
  
  public static Intent g5(Context paramContext, String paramString, DropboxLocalEntry paramDropboxLocalEntry) {
    Intent intent = new Intent(paramContext, DbxMainActivity.class);
    UserSelector.i(intent, UserSelector.d(paramString));
    intent.setAction("ACTION_OPEN_FILE_SHORTCUT");
    intent.putExtra("EXTRA_FILE_SHORTCUT_ENTRY", (Parcelable)paramDropboxLocalEntry);
    return intent;
  }
  
  public static DropboxPath k5(Intent paramIntent) {
    p.d("ACTION_QUICK_UPLOAD_TRACKING".equals(paramIntent.getAction()));
    Bundle bundle = paramIntent.getExtras();
    if (bundle != null) {
      DropboxPath dropboxPath = (DropboxPath)H.d(bundle, "EXTRA_QUICK_UPLOAD_DESTINATION_PATH", DropboxPath.class);
      if (dropboxPath != null)
        return dropboxPath; 
    } 
    return null;
  }
  
  public static Intent l5(Context paramContext, String paramString, DropboxPath paramDropboxPath, long paramLong) {
    p.o(paramContext);
    Intent intent = new Intent(paramContext, DbxMainActivity.class);
    UserSelector.i(intent, UserSelector.d(paramString));
    intent.setAction("ACTION_QUICK_UPLOAD_TRACKING");
    intent.putExtra("EXTRA_QUICK_UPLOAD_DESTINATION_PATH", (Parcelable)paramDropboxPath);
    intent.putExtra("EXTRA_QUICK_UPLOAD_TASK_ID", paramLong);
    return intent;
  }
  
  public void A(DropboxLocalEntry paramDropboxLocalEntry, d0 paramd0) {
    b.a();
    p.e(paramDropboxLocalEntry.q0() ^ true, "Assert failed.");
    DropboxPath dropboxPath = paramDropboxLocalEntry.P();
    A5(dropboxPath, paramd0.getId(), false, false);
    FileLauncher fileLauncher = this.S.a((BaseActivity)this, e.FILES);
    b b1 = this.v.a(dropboxPath, paramd0);
    this.x.F().b();
    fileLauncher.t(b1, (LocalEntry)paramDropboxLocalEntry, B.SORT_BY_NAME, paramd0.e(), paramd0);
  }
  
  public void A3(String paramString, Long paramLong, TaskResult paramTaskResult) {
    if (z4().q(paramString) == null)
      return; 
    boolean bool = paramTaskResult instanceof FileSystemWarningUploadResult;
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Was expecting task result of FileSystemWarningUploadResult, got ");
    stringBuilder.append(paramTaskResult);
    p.j(bool, "Assert failed: %1$s", stringBuilder.toString());
    Bundle bundle = new Bundle();
    bundle.putLong("com.dropbox.android.activity.DbxMainActivity.ARG_UPLOAD_TASK_ID_V2", paramLong.longValue());
    bundle.putString("com.dropbox.android.activity.DbxMainActivity.ARG_USER_ID", paramString);
    FileSystemWarningDialogFrag.u2(((FileSystemWarningUploadResult)paramTaskResult).b(), bundle, f.fsw_cancel_upload).l2(getSupportFragmentManager());
  }
  
  public final void A5(DropboxPath paramDropboxPath, String paramString, boolean paramBoolean1, boolean paramBoolean2) {
    p.o(paramDropboxPath);
    this.A.a((Runnable)new h(this, paramDropboxPath, paramString, paramBoolean2, paramBoolean1));
  }
  
  public void B1(Set<String> paramSet, Bundle paramBundle) {
    if (paramBundle == null)
      return; 
    d0 d01 = z4().q(paramBundle.getString("com.dropbox.android.activity.DbxMainActivity.ARG_USER_ID"));
    p.o(d01);
    (new Thread((Runnable)new f(this, paramBundle.containsKey("com.dropbox.android.activity.DbxMainActivity.ARG_UPLOAD_TASK_ID_V2"), ((b)DropboxApplication.c1((Context)this).a(d01.getId())).G(), paramBundle, paramSet))).start();
  }
  
  public boolean B3(b paramb, boolean paramBoolean) {
    p.o(paramb);
    if (!this.i.p(paramb) && !this.r) {
      V4(paramb, paramBoolean);
      return true;
    } 
    return false;
  }
  
  @SuppressLint({"AnnotateVersionCheck", "InlinedApi"})
  public final void B5(Bundle paramBundle) {
    boolean bool = k.c(this.Q.i());
    if (Build.VERSION.SDK_INT >= 33 && O5() && !bool) {
      d d1 = new d("android.permission.POST_NOTIFICATIONS", null, 1234321, (a)new t(), (p)new u());
      this.M = this.L.d((Activity)this, paramBundle, d1);
      this.Q.h2().z1(System.currentTimeMillis());
    } 
    this.f.c(a.G1(Boolean.valueOf(r.e((Context)this).a())));
  }
  
  public View C0() {
    Fragment fragment = getSupportFragmentManager().l0(Q0.frag_container);
    return (fragment instanceof d) ? ((d)fragment).C0() : this.q.b();
  }
  
  public void C1() {
    (new Handler(Looper.getMainLooper())).post((Runnable)new v(this));
  }
  
  public void C5() {
    this.w.c((Context)this, 0);
  }
  
  public final void D5(boolean paramBoolean) {
    FragmentManager fragmentManager = getSupportFragmentManager();
    List list = fragmentManager.C0();
    if (list != null) {
      HashMap<Object, Object> hashMap = new HashMap<>(list.size());
      for (Fragment fragment : list) {
        if (fragment != null)
          hashMap.put(fragment.getClass(), fragment); 
      } 
      for (j j1 : j.values()) {
        Fragment fragment2 = (Fragment)hashMap.get(j.b(j1));
        Fragment fragment1 = fragment2;
        if (j1 == j.PHOTOS) {
          fragment1 = fragment2;
          if (fragment2 == null)
            fragment1 = (Fragment)hashMap.get(PhotosFragment.class); 
        } 
        if (fragment1 != null)
          if (paramBoolean) {
            o o = fragmentManager.q();
            o.t(fragment1);
            o.k();
          } else {
            this.e.put(j1, fragment1);
          }  
      } 
      fragmentManager.h0();
    } 
  }
  
  public final void E5(Fragment paramFragment, b paramb, boolean paramBoolean1, boolean paramBoolean2) {
    p.o(paramFragment);
    p.o(paramb);
    FragmentManager fragmentManager = getSupportFragmentManager();
    if (r1(paramFragment)) {
      if (paramBoolean2 && paramFragment instanceof F)
        ((F)paramFragment).C2(); 
      return;
    } 
    if (paramBoolean2 && paramFragment instanceof n)
      this.g.j(); 
    getSupportFragmentManager().q1(null, 1);
    Fragment fragment = fragmentManager.l0(Q0.frag_container);
    U4(fragment);
    if (fragment == null || !paramBoolean2 || !this.H) {
      F5(paramFragment, paramb, paramBoolean1, paramBoolean2, false);
      return;
    } 
    this.r = true;
    this.j.r0((Runnable)new d(this, paramFragment, paramb, paramBoolean1));
  }
  
  public final void F5(Fragment paramFragment, b paramb, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) {
    o o = getSupportFragmentManager().q();
    if (paramBoolean3) {
      o.v(Q0.frag_container, paramFragment, e5(paramb));
      o.i(null);
    } else if (paramBoolean1) {
      o.j(paramFragment);
    } else {
      o.c(Q0.frag_container, paramFragment, e5(paramb));
    } 
    o.l();
    if (this.H) {
      a a1 = this.j;
      if (a1 != null && !paramBoolean2)
        a1.q0(paramb); 
    } 
    this.w.i(paramb, paramBoolean2);
    G5(paramFragment);
  }
  
  public DbxToolbar G() {
    return this.k;
  }
  
  public void G1() {
    this.x.F().b();
  }
  
  public final void G5(Fragment paramFragment) {
    b.c(paramFragment, g.class);
    int n = ((g)paramFragment).R();
    if (n == 0)
      return; 
    this.k.setTitle(n);
    supportInvalidateOptionsMenu();
  }
  
  public final void H5() {
    o o = m5(this.Q);
    if (o == null)
      return; 
    c c1 = (c)o;
    this.K = c1.L();
    this.J = b.a((J)i.a(getLifecycle()), (c)this, this.K, c1.r().b(), c1.r().a());
  }
  
  public boolean I1() {
    return Objects.equals(getIntent().getAction(), b.SHARING_TOOLTIP.getValue());
  }
  
  public final void I5() {
    o o = m5(this.Q);
    if (o == null)
      return; 
    c c1 = (c)o;
    NavigationBarView navigationBarView = (NavigationBarView)findViewById(a.dbapp_main_nav_view);
    navigationBarView.setOnItemReselectedListener((NavigationBarView.OnItemReselectedListener)new s(this));
    g g1 = i.a(getLifecycle());
    this.w = J.a((View)navigationBarView, Q4(), this.H, (b)this.j, (h)this.x, (J)g1, c1.a3(), c1.U4());
  }
  
  public final void J5() {
    NavigationBarView navigationBarView = (NavigationBarView)findViewById(a.dbapp_main_nav_view);
    a a1 = c5();
    if (a1 != null) {
      r r = new r((m)new u(navigationBarView.getRootView(), getApplicationContext()));
      this.W = (e)new RealDrawerDeprecationTooltipManager(getLifecycle(), a1.k2(), (f)r, a1.w6(), a1.U7(), getApplicationContext(), (a)new r(this));
      this.X = (a)new b((f)r, a1.U7(), getApplicationContext());
    } 
  }
  
  public void K(String paramString) {
    F f1 = (F)Z4();
    p.o(f1);
    p.e(r1(f1.Z0()), "Assert failed.");
    f1.K(paramString);
  }
  
  public void K3() {
    startActivity(new Intent((Context)this, PreferenceActivity.class));
  }
  
  public final void K5() {
    d d1 = (d)(new t((z)this, (t.b)new J0(j5(), z4()))).a(d.class);
    this.I = d1;
    d1.J((BaseActivity)this, (c$e)this);
  }
  
  public void L() {
    F f1 = (F)Z4();
    if (f1 != null && r1(f1.Z0())) {
      f1.L();
      return;
    } 
    PhotosFragment photosFragment = h5();
    if (photosFragment != null && r1((Fragment)photosFragment))
      photosFragment.L(); 
  }
  
  public void L0() {}
  
  public void L2() {
    l l1 = this.w;
    if (l1 != null)
      l1.b(); 
  }
  
  public final void L5() {
    o o = m5(this.Q);
    if (o != null)
      ((d)o).m3().a((AppCompatActivity)this); 
  }
  
  public void M3() {
    P0();
  }
  
  public final void M5() {
    this.y = (i)new k(this.Q);
    this.x = (f)(new t((z)this, (t.b)new g(null, (d)this, this.y, f5()))).a(f.class);
  }
  
  public final Boolean N5() {
    d0 d01 = this.Q;
    return (d01 != null) ? Boolean.valueOf(y.b((e)d01.i())) : Boolean.FALSE;
  }
  
  public void O1(Bundle paramBundle) {
    if (paramBundle == null)
      return; 
    d0 d01 = z4().q(paramBundle.getString("com.dropbox.android.activity.DbxMainActivity.ARG_USER_ID"));
    p.o(d01);
    (new Thread((Runnable)new g(this, paramBundle.containsKey("com.dropbox.android.activity.DbxMainActivity.ARG_UPLOAD_TASK_ID_V2"), ((b)DropboxApplication.c1((Context)this).a(d01.getId())).G(), paramBundle))).start();
  }
  
  public final boolean O5() {
    boolean bool1;
    long l2 = this.Q.h2().H0();
    long l1 = System.currentTimeMillis();
    long l4 = TimeUnit.MILLISECONDS.toDays(7L);
    boolean bool2 = false;
    if (l1 - l2 >= l4) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    if (l2 == 0L || bool1)
      bool2 = true; 
    return bool2;
  }
  
  public void P() {
    g g1 = this.O;
    if (g1 != null)
      g1.a((b)b.c.a, (c)c.c.a); 
  }
  
  public void P0() {
    boolean bool;
    String str;
    g g1 = this.Q.e();
    if (!z4().t()) {
      (new D6()).g(g1);
      startActivity(a.a((Context)this, "com.dropbox.intent.action.DROPBOX_LOGIN_SECOND_ACCOUNT", false));
      return;
    } 
    p.o(this.Q);
    a a1 = z4();
    d0 d01 = this.Q;
    u0 u0 = u0.PERSONAL;
    if (d01.equals(a1.r(u0))) {
      this.Q = a1.r(u0.BUSINESS);
      if (a1.l().h(getResources()) == null) {
        str = getString(V0.gas_snackbar_work_default);
      } else {
        str = getString(V0.gas_snackbar_work, new Object[] { a1.l().h(getResources()) });
      } 
    } else {
      this.Q = a1.r(u0);
      str = getString(V0.gas_snackbar_personal);
    } 
    k k1 = new k(this.Q);
    this.y = (i)k1;
    this.x.G((i)k1);
    this.x.H(f5());
    a1.k().d().Y(this.Q.getId());
    j j1 = a5();
    this.s = p5();
    if (d.h(getResources())) {
      recreate();
    } else {
      a a2 = this.j;
      if (a2 != null) {
        a2.o0();
        this.j.n0();
      } 
      this.n.removeView(this.j.N());
      a2 = S4();
      this.j = a2;
      a2.A0();
      V5();
    } 
    I5();
    J5();
    c c1 = this.q;
    c1.f(Snackbar.make(c1.b(), str, -1));
    l l1 = this.w;
    if (this.Q.i2() == u0) {
      bool = true;
    } else {
      bool = false;
    } 
    l1.l(bool);
    this.w.k(p5());
    W5();
    if (j1.equals(j.PHOTOS) && !Q5()) {
      b b1 = T4();
      this.i.p(b1);
      V4(b1, false);
    } else if (j1.equals(j.NOTIFICATIONS) && p5()) {
      c<DbxMainActivity> c2 = this.i;
      b b1 = b.ACTIVITY;
      c2.p(b1);
      V4(b1, false);
    } else if (j1.equals(j.ACTIVITY) && !p5()) {
      startActivity(NotificationsActivity.B4((Context)this, this.Q.getId()));
    } else if (j1.equals(j.FAVORITES) && !p5()) {
      startActivity(OfflineFilesActivity.B4((Context)this, this.Q.getId()));
    } else if (j1.equals(j.ACCOUNT)) {
      U5();
    } else {
      W4(a5(), false, false);
    } 
    this.G.d(this.Q.getId());
  }
  
  public final boolean P5() {
    return g.getInstance().equals(g.RELEASE) ^ true;
  }
  
  public void Q2() {
    l l1 = this.w;
    if (l1 != null)
      l1.j(); 
  }
  
  public void Q3() {
    PhotosFragment photosFragment = h5();
    if (photosFragment != null && r1((Fragment)photosFragment))
      photosFragment.Q3(); 
  }
  
  public final j Q4() {
    return (j)new b(this);
  }
  
  public final boolean Q5() {
    return this.y.a();
  }
  
  public void R3(DropboxPath paramDropboxPath, String paramString, boolean paramBoolean) {
    A5(paramDropboxPath, paramString, true, paramBoolean);
  }
  
  public final boolean R4(Fragment paramFragment) {
    d0 d01;
    String str;
    boolean bool = false;
    if (paramFragment == null)
      return false; 
    if (paramFragment instanceof a && ((BaseIdentityFragment)paramFragment).q2()) {
      d01 = ((a)paramFragment).c0();
      if (d01 == null || this.Q.equals(d01))
        bool = true; 
      return bool;
    } 
    if (d01 instanceof FileRequestsFragment)
      return ((FileRequestsFragment)d01).l().equals(this.Q.getId()); 
    if (d01 instanceof UserPreferenceFragment) {
      str = ((UserPreferenceFragment)d01).N3();
      return this.Q.getId().equals(str);
    } 
    if (str instanceof F) {
      str = ((F)str).h3();
      return this.Q.getId().equals(str);
    } 
    if (str instanceof ModularHomeFragment) {
      ModularHomeFragment modularHomeFragment = (ModularHomeFragment)str;
      String str1 = modularHomeFragment.l();
      f f1 = this.R;
      if (f1 != null) {
        modularHomeFragment.M3(f1);
        this.R = null;
      } 
      return this.Q.getId().equals(str1);
    } 
    return true;
  }
  
  public void S2(Uri paramUri, ViewingUserSelector paramViewingUserSelector) {
    if (Z4() instanceof F) {
      F f1 = (F)Z4();
      if (f1 != null && r1(f1.Z0()))
        f1.q0(paramUri, paramViewingUserSelector); 
    } 
  }
  
  public void S3() {
    if (this.Q != null && z4() != null && this.X != null) {
      e e1 = z4().k().d();
      if (!e1.P()) {
        e1.g0(true);
        this.X.show();
      } 
    } 
  }
  
  public final a S4() {
    a a1 = new a((BaseActivity)this, (Toolbar)this.k, this.n, (a$n)this, this.f, z4(), P5(), this.s, this.Q, (h)this.x);
    a1.a((DrawerLayout.d)new c(this));
    return a1;
  }
  
  public final void S5() {
    g g1 = this.O;
    if (g1 != null)
      g1.a((b)b.a.a, (c)c.b.a); 
  }
  
  public final b T4() {
    return this.y.b();
  }
  
  public final void T5() {
    this.m.setVisibility(8);
    this.l.setOutlineProvider(ViewOutlineProvider.BACKGROUND);
  }
  
  public final void U4(Fragment paramFragment) {
    if (paramFragment != null) {
      o o = getSupportFragmentManager().q();
      o.p(paramFragment);
      o.k();
    } 
  }
  
  public final void U5() {
    Fragment fragment = Y4();
    j j1 = j.ACCOUNT;
    E5(fragment, j1.getTabGroup(), false, false);
    this.e.put(j1, fragment);
  }
  
  public void V0() {
    g g1 = this.O;
    if (g1 != null)
      g1.a((b)b.b.a, (c)c.c.a); 
  }
  
  public void V2() {
    for (Fragment fragment : getSupportFragmentManager().C0()) {
      if (fragment instanceof d)
        ((d)fragment).V2(); 
    } 
    this.q.a();
  }
  
  public final void V4(b paramb, boolean paramBoolean) {
    j j2;
    d0 d01;
    j j1;
    switch (i.a[paramb.ordinal()]) {
      default:
        throw new IllegalStateException("This should never happen.");
      case 8:
        j2 = j.ACCOUNT;
        break;
      case 7:
        j2 = j.FILE_REQUESTS;
        break;
      case 6:
        j2 = j.MODULAR_HOME;
        break;
      case 5:
        j2 = j.ACTIVITY;
        break;
      case 4:
        j2 = j.NOTIFICATIONS;
        break;
      case 3:
        j2 = j.FAVORITES;
        break;
      case 2:
        d01 = this.Q;
        if (d01 != null && d01.i2() != u0.PERSONAL) {
          a.g("The user doesn't have access to Photos tab", new Object[0]);
          return;
        } 
        j1 = j.PHOTOS;
        break;
      case 1:
        j1 = j.BROWSER;
        break;
    } 
    W4(j1, paramBoolean, false);
  }
  
  public final void V5() {
    a a1 = c5();
    if (a1 != null && a1.X2().b())
      return; 
    boolean bool = N5().booleanValue();
    this.H = bool ^ true;
    if (!bool) {
      this.j.b();
      this.j.x0();
    } else {
      this.j.c();
      this.j.R();
    } 
  }
  
  public final void W4(j paramj, boolean paramBoolean1, boolean paramBoolean2) {
    RealBrowserFragment realBrowserFragment;
    Fragment fragment = this.e.get(paramj);
    X5(paramj);
    boolean bool2 = R4(fragment);
    boolean bool1 = true;
    if (bool2 && !paramBoolean2) {
      paramBoolean2 = true;
    } else {
      paramBoolean2 = false;
    } 
    if (!paramBoolean2) {
      Fragment fragment2;
      FileRequestsFragment fileRequestsFragment;
      ModularHomeFragment modularHomeFragment;
      ActivityTabbedFragment activityTabbedFragment;
      Fragment fragment1;
      PhotosFragment photosFragment;
      MainBrowserLoadingFragment mainBrowserLoadingFragment;
      String str = this.Q.getId();
      switch (i.b[paramj.ordinal()]) {
        default:
          throw new IllegalStateException("This should never happen.");
        case 9:
          fragment2 = Y4();
          break;
        case 8:
          fileRequestsFragment = FileRequestsFragment.T2((String)fragment2, null);
          break;
        case 7:
          p.o(fileRequestsFragment);
          p.o(this.Q);
          modularHomeFragment = ModularHomeFragment.V1.a((String)fileRequestsFragment, this.Q.i2(), P.b(this.Q, getResources()), this.R);
          this.R = null;
          break;
        case 6:
          activityTabbedFragment = ActivityTabbedFragment.F2((String)modularHomeFragment);
          break;
        case 5:
          startActivity(NotificationsActivity.B4((Context)this, this.Q.getId()));
          return;
        case 4:
          startActivity(OfflineFilesActivity.B4((Context)this, this.Q.getId()));
          return;
        case 3:
          fragment1 = getSupportFragmentManager().m0(e5(b.PHOTOS));
          if (fragment1 != null) {
            paramBoolean2 = bool1;
            break;
          } 
          photosFragment = PhotosFragment.M3(this.Q.getId());
          break;
        case 2:
          mainBrowserLoadingFragment = MainBrowserLoadingFragment.E2();
          break;
        case 1:
          realBrowserFragment = RealBrowserFragment.l6((String)mainBrowserLoadingFragment);
          break;
      } 
    } 
    if (paramj == j.BROWSER && !r1((Fragment)realBrowserFragment)) {
      this.h.e((d)a.a);
      this.g.i();
    } 
    this.e.put(paramj, realBrowserFragment);
    if (realBrowserFragment instanceof g) {
      if (this.Q.h().t0() != null) {
        bool1 = this.Q.h().t0().y();
      } else {
        bool1 = false;
      } 
      g g1 = (g)realBrowserFragment;
      bool2 = g1.h1(bool1);
      if (g1.d1(bool1)) {
        getSupportActionBar().C();
      } else {
        getSupportActionBar().l();
      } 
      if (bool2) {
        this.o.setVisibility(0);
      } else {
        this.o.setVisibility(8);
      } 
    } 
    E5((Fragment)realBrowserFragment, paramj.getTabGroup(), paramBoolean2, paramBoolean1);
  }
  
  public void W5() {
    a a1 = this.I.G();
    if (this.Q.i2() == u0.PERSONAL) {
      this.w.c((Context)this, 0);
      int n = a1.b();
      this.w.g((Context)this, n, getResources().getQuantityString(T0.accessibility_unread_notifications_message, n, new Object[] { Integer.valueOf(n) }));
    } else {
      this.w.f((Context)this, 0);
      this.w.d((Context)this, a1.a(), getString(V0.accessibility_unread_alerts_message));
    } 
  }
  
  public void X0(b paramb) {
    b b1;
    if (paramb == b.PHOTOS && !Q5()) {
      b1 = T4();
    } else {
      b b2 = b.ACTIVITY;
      if (paramb == b2 && !this.s) {
        b1 = b.NOTIFICATIONS;
      } else {
        b1 = paramb;
        if (paramb == b.NOTIFICATIONS) {
          b1 = paramb;
          if (this.s)
            b1 = b2; 
        } 
      } 
    } 
    V4(b1, false);
  }
  
  public void X3(Bundle paramBundle, boolean paramBoolean) {
    a a2;
    DbxToolbar dbxToolbar = (DbxToolbar)findViewById(Q0.dbx_toolbar);
    this.k = dbxToolbar;
    setSupportActionBar((Toolbar)dbxToolbar);
    this.m = findViewById(Q0.app_bar_hr);
    this.l = (AppBarLayout)findViewById(Q0.app_bar_layout);
    this.o = findViewById(d.dbx_toolbar_spacer);
    this.n = (DrawerLayout)findViewById(Q0.drawer_layout);
    this.p = (MainActivityBanner)findViewById(Q0.main_activity_banner);
    this.q.c(findViewById(Q0.main_snack_bar_container));
    a a1 = z4();
    this.j = S4();
    I5();
    J5();
    d0 d01 = a1.r(u0.PERSONAL);
    if (d01 != null) {
      a2 = d01.h().t0();
      j j1 = d01.h2();
    } else {
      a2 = null;
      d01 = null;
    } 
    F0 f0 = new F0(a2, this.p, (j)d01);
    this.t = f0;
    f0.e();
    D5(paramBoolean);
    K5();
    this.i.k(paramBundle, getIntent());
  }
  
  public final ActivityTabbedFragment X4() {
    return (ActivityTabbedFragment)this.e.get(j.ACTIVITY);
  }
  
  public final void X5(j paramj) {
    p.o(paramj);
    if (R5(paramj)) {
      T5();
    } else {
      o5();
    } 
  }
  
  public void Y0() {
    W4(j.BROWSER, false, false);
    Fragment fragment = this.e.get(j.LOADING_BROWSER);
    if (fragment != null) {
      o o = getSupportFragmentManager().q();
      o.t(fragment);
      o.k();
    } 
  }
  
  public final Fragment Y4() {
    a.a a1 = a.b(this.Q.i());
    if (a1 == a.a.V1 || a1 == a.a.V2 || a1 == a.a.CONTROL)
      (new U3()).k(a.a.a().a()).l(a1.getCaseSensitiveVariantName()).g(this.f); 
    return (Fragment)((a1 == a.a.V2) ? ModularAccountTabFragment.r2(this.Q.l()) : UserPreferenceFragment.r4(this.Q.i2()));
  }
  
  public void Z1(h paramh) {
    this.P = paramh;
    ArrayList arrayList = G.k((Object[])new String[] { this.Q.l() });
    if (DropboxApplication.e0((Context)this).g(this.Q)) {
      String str = getString(V0.settings_unlink_grandfathered_user_dialog_message);
    } else {
      paramh = null;
    } 
    UnlinkDialog.q2((BaseActivity)this, arrayList, (String)paramh).show(getSupportFragmentManager(), UnlinkDialog.t);
  }
  
  public void Z2() {
    h h1 = this.P;
    if (h1 != null) {
      h1.a(false);
      this.P = null;
    } 
  }
  
  public final n Z4() {
    return (n)this.e.get(j.BROWSER);
  }
  
  public j a5() {
    j j1 = b5();
    if (j1 != null)
      return j1; 
    throw new IllegalStateException("No currently selected tab");
  }
  
  public j b5() {
    Fragment fragment = getSupportFragmentManager().l0(Q0.frag_container);
    for (Map.Entry<j, Fragment> entry : this.e.entrySet()) {
      if (entry.getValue() == fragment)
        return (j)entry.getKey(); 
    } 
    return null;
  }
  
  public void c0(DropboxPath paramDropboxPath, String paramString) {
    A5(paramDropboxPath, paramString, true, false);
  }
  
  public void c2(boolean paramBoolean) {
    if (this.H) {
      a a1 = this.j;
      if (a1 != null)
        a1.u0(paramBoolean); 
    } 
  }
  
  public final a c5() {
    o o = m5(this.Q);
    return (o != null) ? (a)o : null;
  }
  
  public b d3() {
    return this.x.p();
  }
  
  public a d5() {
    return this.j;
  }
  
  public void e0(DropboxPath paramDropboxPath, String paramString, Boolean paramBoolean) {
    y1(paramDropboxPath, m.e(paramString), paramBoolean.booleanValue());
  }
  
  public final String e5(b paramb) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("FRAG_TAG_");
    stringBuilder.append(paramb.name());
    return stringBuilder.toString();
  }
  
  public void f3(Snackbar paramSnackbar) {
    Fragment fragment = getSupportFragmentManager().l0(Q0.frag_container);
    if (fragment instanceof d) {
      ((d)fragment).f3(paramSnackbar);
    } else {
      this.q.f(paramSnackbar);
    } 
  }
  
  public final e f5() {
    m m1 = new m(this.Q.i());
    return this.C.a((d)m1, this.f);
  }
  
  public final PhotosFragment h5() {
    Fragment fragment = this.e.get(j.PHOTOS);
    return (fragment instanceof PhotosFragment) ? (PhotosFragment)fragment : null;
  }
  
  public int i2() {
    return 2;
  }
  
  public a i5() {
    return this.I.G();
  }
  
  public int j5() {
    return 1;
  }
  
  public void k(ArrayList<String> paramArrayList) {
    a<DbxMainActivity> a1 = this.B;
    if (a1 != null)
      a1.g(paramArrayList); 
    h h1 = this.P;
    if (h1 != null) {
      h1.a(true);
      this.P = null;
    } 
  }
  
  public void k1() {
    a a1 = this.I.G();
    p.o(a1);
    W5();
    ActivityTabbedFragment activityTabbedFragment = X4();
    if (activityTabbedFragment != null && a1.a() > 0)
      activityTabbedFragment.G2(); 
  }
  
  public final o m5(d0 paramd0) {
    if (paramd0 != null) {
      String str = paramd0.getId();
      if (str != null)
        return DropboxApplication.c1((Context)this).a(str); 
    } 
    return null;
  }
  
  public void n(ArrayList<String> paramArrayList) {
    a<DbxMainActivity> a1 = this.B;
    if (a1 != null)
      a1.k(paramArrayList); 
  }
  
  public j n2() {
    return this.d;
  }
  
  public final boolean n5() {
    boolean bool;
    d0 d01 = this.Q;
    if (d01 != null && d01.h().t0() != null && this.Q.h().t0().y()) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public void o() {
    a<DbxMainActivity> a1 = this.B;
    if (a1 != null)
      a1.j(); 
  }
  
  public void o1(List<DropboxLocalEntry> paramList, Changesets paramChangesets) {
    p.o(paramList);
    p.o(paramChangesets);
    F f1 = (F)Z4();
    if (f1 != null && r1(f1.Z0()))
      f1.o1(paramList, paramChangesets); 
    PhotosFragment photosFragment = h5();
    if (photosFragment != null && r1((Fragment)photosFragment))
      photosFragment.o1(paramList, paramChangesets); 
    S5();
  }
  
  public final void o5() {
    this.m.setVisibility(8);
    this.l.setOutlineProvider(null);
  }
  
  public void onBackPressed() {
    if (this.H) {
      a a1 = this.j;
      if (a1 != null && a1.P())
        return; 
    } 
    F f1 = (F)Z4();
    if (f1 != null && r1(f1.Z0()) && f1.v2())
      return; 
    if (this.U.b() && isTaskRoot())
      return; 
    super.onBackPressed();
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    this.A = new LifecycleExecutor(getLifecycle());
    this.f = DropboxApplication.b0((Context)this);
    this.g = DropboxApplication.z0((Context)this);
    this.h = DropboxApplication.J0((Context)this);
    this.D = DropboxApplication.Z0((Context)this);
    this.u = DropboxApplication.h0((Context)this);
    this.v = DropboxApplication.I0((Context)this);
    this.F = DropboxApplication.V((Context)this);
    this.E = DropboxApplication.X((Context)this);
    this.L = DropboxApplication.K0((Context)this);
    if (w4())
      return; 
    this.G = new l3((FragmentActivity)this, this.D, this.E);
    this.Q = z5(z4(), getIntent().getExtras());
    this.C = DropboxApplication.q0((Context)this);
    o o = m5(this.Q);
    if (o != null) {
      ((w)o).F4(this);
      g g1 = ((k)o).p1();
      this.O = g1;
      g1.b((FragmentActivity)this);
    } else {
      ((w)((DropboxApplication)getApplicationContext()).A()).F4(this);
    } 
    M5();
    x5();
    this.i = new c((BaseIdentityActivity)this, this.T);
    new FileExportBroadcastReceiver(getLifecycle(), DropboxApplication.A0((Context)this));
    this.N = DropboxApplication.A0((Context)this);
    new SnackbarBroadcastReceiver(getLifecycle(), (d)this, this.N, this.u, (a)this.V, ((b0)o).O4(), (a)new p(this), (a)new q(this));
    this.s = p5();
    this.H = N5().booleanValue() ^ true;
    setContentView(R0.dropbox_navigation_drawer);
    this.R = (f)S.b(getIntent(), "EXTRA_HOME_MODULE_TYPE", f.class);
    getIntent().removeExtra("EXTRA_HOME_MODULE_TYPE");
    a a3 = new a(this);
    getSupportFragmentManager().l((FragmentManager.n)a3);
    this.B = new a((Activity)this, DropboxApplication.b1((Context)this), DropboxApplication.b0((Context)this));
    A4(paramBundle);
    findViewById(Q0.frag_container).setImportantForAccessibility(1);
    findViewById(Q0.app_bar_layout).setImportantForAccessibility(1);
    findViewById(Q0.frag_container).setAccessibilityTraversalAfter(Q0.app_bar_layout);
    this.G.d(this.Q.getId());
    H5();
    L5();
    B5(paramBundle);
    a a1 = a.a;
    a.a a2 = a1.a(this.Q.i());
    this.f.a((d)(new U3()).k(a1.b().a()).l(a2.getCaseSensitiveVariantName()));
  }
  
  public void onDestroy() {
    super.onDestroy();
    if (this.H) {
      a a1 = this.j;
      if (a1 != null)
        a1.n0(); 
    } 
  }
  
  public void onNewIntent(Intent paramIntent) {
    super.onNewIntent(paramIntent);
    this.i.l(paramIntent);
  }
  
  public void onPause() {
    super.onPause();
    this.t.f();
    if (this.H) {
      a a1 = this.j;
      if (a1 != null)
        a1.o0(); 
    } 
    this.J.d();
  }
  
  public void onResumeFragments() {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual z4 : ()Lcom/dropbox/android/user/a;
    //   4: invokevirtual k : ()Lcom/dropbox/android/user/e;
    //   7: invokevirtual d : ()Ldbxyzptlk/qb/e;
    //   10: invokevirtual E : ()Ljava/lang/String;
    //   13: astore_1
    //   14: aload_0
    //   15: invokevirtual z4 : ()Lcom/dropbox/android/user/a;
    //   18: invokevirtual t : ()Z
    //   21: ifeq -> 44
    //   24: aload_0
    //   25: getfield Q : Ldbxyzptlk/pc/d0;
    //   28: invokeinterface getId : ()Ljava/lang/String;
    //   33: aload_1
    //   34: invokevirtual equals : (Ljava/lang/Object;)Z
    //   37: ifne -> 44
    //   40: aload_0
    //   41: invokevirtual P0 : ()V
    //   44: aload_0
    //   45: invokevirtual getSupportFragmentManager : ()Landroidx/fragment/app/FragmentManager;
    //   48: getstatic dbxyzptlk/w6/Q0.frag_container : I
    //   51: invokevirtual l0 : (I)Landroidx/fragment/app/Fragment;
    //   54: astore_1
    //   55: aload_1
    //   56: ifnull -> 64
    //   59: aload_0
    //   60: aload_1
    //   61: invokevirtual G5 : (Landroidx/fragment/app/Fragment;)V
    //   64: aload_0
    //   65: getfield J : Ldbxyzptlk/Yr/a;
    //   68: invokeinterface a : ()Ldbxyzptlk/Vr/d;
    //   73: astore_1
    //   74: aload_1
    //   75: ifnull -> 124
    //   78: aload_1
    //   79: getstatic dbxyzptlk/Vr/d$d.a : Ldbxyzptlk/Vr/d$d;
    //   82: if_acmpne -> 124
    //   85: aload_0
    //   86: getfield J : Ldbxyzptlk/Yr/a;
    //   89: invokeinterface e : ()Ldbxyzptlk/Vr/e;
    //   94: astore_1
    //   95: aload_0
    //   96: aload_0
    //   97: aload_0
    //   98: getfield Q : Ldbxyzptlk/pc/d0;
    //   101: invokeinterface getId : ()Ljava/lang/String;
    //   106: aload_1
    //   107: getstatic dbxyzptlk/Pk/h.BLOCKING_AGE_VERIFICATION : Ldbxyzptlk/Pk/h;
    //   110: invokevirtual ordinal : ()I
    //   113: invokestatic x4 : (Landroid/content/Context;Ljava/lang/String;Ldbxyzptlk/Vr/e;I)Landroid/content/Intent;
    //   116: invokevirtual startActivity : (Landroid/content/Intent;)V
    //   119: aload_0
    //   120: invokevirtual finish : ()V
    //   123: return
    //   124: aload_0
    //   125: getfield J : Ldbxyzptlk/Yr/a;
    //   128: invokeinterface c : ()V
    //   133: aload_0
    //   134: getfield J : Ldbxyzptlk/Yr/a;
    //   137: invokeinterface b : ()V
    //   142: aload_0
    //   143: getfield D : Ldbxyzptlk/rc/b;
    //   146: aload_0
    //   147: invokeinterface d : (Landroidx/fragment/app/FragmentActivity;)V
    //   152: aload_0
    //   153: getfield D : Ldbxyzptlk/rc/b;
    //   156: aload_0
    //   157: invokeinterface H : (Landroidx/fragment/app/FragmentActivity;)V
    //   162: aload_0
    //   163: invokespecial onResumeFragments : ()V
    //   166: aload_0
    //   167: getfield i : Lcom/dropbox/android/activity/c;
    //   170: aload_0
    //   171: getfield Q : Ldbxyzptlk/pc/d0;
    //   174: invokevirtual m : (Ldbxyzptlk/pc/d0;)Z
    //   177: pop
    //   178: aload_0
    //   179: getfield H : Z
    //   182: ifeq -> 198
    //   185: aload_0
    //   186: getfield j : Lcom/dropbox/android/activity/a;
    //   189: astore_1
    //   190: aload_1
    //   191: ifnull -> 198
    //   194: aload_1
    //   195: invokevirtual p0 : ()V
    //   198: aload_0
    //   199: getfield t : Ldbxyzptlk/E6/F0;
    //   202: invokevirtual g : ()V
    //   205: aload_0
    //   206: getfield w : Ldbxyzptlk/Ho/l;
    //   209: aload_0
    //   210: invokevirtual Q5 : ()Z
    //   213: invokevirtual l : (Z)V
    //   216: aload_0
    //   217: getfield w : Ldbxyzptlk/Ho/l;
    //   220: aload_0
    //   221: invokevirtual p5 : ()Z
    //   224: invokevirtual k : (Z)V
    //   227: aload_0
    //   228: invokevirtual W5 : ()V
    //   231: aload_0
    //   232: invokevirtual b5 : ()Lcom/dropbox/android/activity/DbxMainActivity$j;
    //   235: astore_2
    //   236: aload_2
    //   237: ifnull -> 400
    //   240: aload_2
    //   241: getstatic com/dropbox/android/activity/DbxMainActivity$j.PHOTOS : Lcom/dropbox/android/activity/DbxMainActivity$j;
    //   244: invokevirtual equals : (Ljava/lang/Object;)Z
    //   247: ifeq -> 266
    //   250: aload_0
    //   251: invokevirtual Q5 : ()Z
    //   254: ifne -> 266
    //   257: aload_0
    //   258: aload_0
    //   259: invokevirtual T4 : ()Ldbxyzptlk/Rx/b;
    //   262: iconst_0
    //   263: invokevirtual V4 : (Ldbxyzptlk/Rx/b;Z)V
    //   266: getstatic com/dropbox/android/activity/DbxMainActivity$j.NOTIFICATIONS : Lcom/dropbox/android/activity/DbxMainActivity$j;
    //   269: astore_1
    //   270: aload_2
    //   271: aload_1
    //   272: invokevirtual equals : (Ljava/lang/Object;)Z
    //   275: ifeq -> 309
    //   278: aload_0
    //   279: getfield s : Z
    //   282: ifeq -> 309
    //   285: aload_0
    //   286: getfield i : Lcom/dropbox/android/activity/c;
    //   289: astore_3
    //   290: getstatic dbxyzptlk/Rx/b.ACTIVITY : Ldbxyzptlk/Rx/b;
    //   293: astore #4
    //   295: aload_3
    //   296: aload #4
    //   298: invokevirtual p : (Ldbxyzptlk/Rx/b;)Z
    //   301: pop
    //   302: aload_0
    //   303: aload #4
    //   305: iconst_0
    //   306: invokevirtual V4 : (Ldbxyzptlk/Rx/b;Z)V
    //   309: aload_2
    //   310: aload_1
    //   311: invokevirtual equals : (Ljava/lang/Object;)Z
    //   314: ifne -> 329
    //   317: aload_2
    //   318: astore_1
    //   319: aload_2
    //   320: getstatic com/dropbox/android/activity/DbxMainActivity$j.ACTIVITY : Lcom/dropbox/android/activity/DbxMainActivity$j;
    //   323: invokevirtual equals : (Ljava/lang/Object;)Z
    //   326: ifeq -> 363
    //   329: aload_2
    //   330: astore_1
    //   331: aload_0
    //   332: getfield s : Z
    //   335: ifne -> 363
    //   338: aload_0
    //   339: getfield i : Lcom/dropbox/android/activity/c;
    //   342: astore_1
    //   343: getstatic dbxyzptlk/Rx/b.HOME : Ldbxyzptlk/Rx/b;
    //   346: astore_2
    //   347: aload_1
    //   348: aload_2
    //   349: invokevirtual p : (Ldbxyzptlk/Rx/b;)Z
    //   352: pop
    //   353: aload_0
    //   354: aload_2
    //   355: iconst_0
    //   356: invokevirtual V4 : (Ldbxyzptlk/Rx/b;Z)V
    //   359: getstatic com/dropbox/android/activity/DbxMainActivity$j.MODULAR_HOME : Lcom/dropbox/android/activity/DbxMainActivity$j;
    //   362: astore_1
    //   363: aload_1
    //   364: getstatic com/dropbox/android/activity/DbxMainActivity$j.FAVORITES : Lcom/dropbox/android/activity/DbxMainActivity$j;
    //   367: invokevirtual equals : (Ljava/lang/Object;)Z
    //   370: ifeq -> 382
    //   373: aload_0
    //   374: aload_0
    //   375: invokevirtual T4 : ()Ldbxyzptlk/Rx/b;
    //   378: iconst_0
    //   379: invokevirtual V4 : (Ldbxyzptlk/Rx/b;Z)V
    //   382: aload_0
    //   383: getfield w : Ldbxyzptlk/Ho/l;
    //   386: aload_1
    //   387: invokestatic i : (Lcom/dropbox/android/activity/DbxMainActivity$j;)Ldbxyzptlk/Rx/b;
    //   390: iconst_0
    //   391: invokevirtual i : (Ldbxyzptlk/Rx/b;Z)Z
    //   394: pop
    //   395: aload_0
    //   396: aload_1
    //   397: invokevirtual X5 : (Lcom/dropbox/android/activity/DbxMainActivity$j;)V
    //   400: aload_0
    //   401: getfield x : Ldbxyzptlk/Ho/f;
    //   404: invokevirtual F : ()Ldbxyzptlk/no/e;
    //   407: aload_0
    //   408: invokeinterface a : (Landroid/app/Activity;)V
    //   413: aload_0
    //   414: getfield D : Ldbxyzptlk/rc/b;
    //   417: aload_0
    //   418: invokeinterface g : (Landroidx/fragment/app/FragmentActivity;)V
    //   423: aload_0
    //   424: getfield F : Ldbxyzptlk/W6/d;
    //   427: aload_0
    //   428: invokeinterface a : (Lcom/dropbox/common/activity/BaseActivity;)V
    //   433: aload_0
    //   434: invokevirtual getIntent : ()Landroid/content/Intent;
    //   437: astore_1
    //   438: aload_1
    //   439: ifnull -> 464
    //   442: aload_1
    //   443: ldc_w 'EXTRA_IS_FROM_MANUAL_PHOTO_VIDEO_UPLOAD'
    //   446: iconst_0
    //   447: invokevirtual getBooleanExtra : (Ljava/lang/String;Z)Z
    //   450: ifeq -> 464
    //   453: aload_0
    //   454: invokevirtual P : ()V
    //   457: aload_1
    //   458: ldc_w 'EXTRA_IS_FROM_MANUAL_PHOTO_VIDEO_UPLOAD'
    //   461: invokevirtual removeExtra : (Ljava/lang/String;)V
    //   464: return
  }
  
  public void onSaveInstanceState(Bundle paramBundle) {
    super.onSaveInstanceState(paramBundle);
    this.i.n(paramBundle);
    j j1 = this.M;
    if (j1 != null)
      j1.onSaveInstanceState(paramBundle); 
  }
  
  public void onStart() {
    super.onStart();
    y5();
  }
  
  public void onStop() {
    super.onStop();
    this.i.o();
    c c1 = this.z;
    if (c1 != null) {
      c1.dispose();
      this.z = null;
    } 
  }
  
  public final boolean p5() {
    return !(this.Q.i2() == u0.PERSONAL);
  }
  
  public boolean r1(Fragment paramFragment) {
    boolean bool;
    p.o(paramFragment);
    if (paramFragment == getSupportFragmentManager().l0(Q0.frag_container)) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public void setTitle(int paramInt) {
    throw new IllegalStateException("Cannot set title on DbxMainActivity with this method. Fragments should instead implement ToolbarTitleProvider");
  }
  
  public void setTitle(CharSequence paramCharSequence) {
    throw new IllegalStateException("Cannot set title on DbxMainActivity with this method.Fragments should instead implement ToolbarTitleProvider");
  }
  
  public d0 t(String paramString) {
    return z4().q(paramString);
  }
  
  public void t1(int paramInt1, int paramInt2, Intent paramIntent) {
    this.i.j(paramInt1, paramInt2, paramIntent, this.Q, (c$e)this);
  }
  
  public boolean x1() {
    PhotosFragment photosFragment = h5();
    return (photosFragment != null && r1((Fragment)photosFragment)) ? photosFragment.x1() : false;
  }
  
  public void x2() {
    b b1 = b.ACCOUNT;
    V4(b1, true);
    this.w.i(b1, false);
  }
  
  public final void x5() {
    d.a(this, DropboxApplication.i0((Context)this).F1(), (b)new a(DropboxApplication.U((Context)this)), this.f);
  }
  
  public void y1(DropboxPath paramDropboxPath, m<String> paramm, boolean paramBoolean) {
    if (paramm.d()) {
      R3(paramDropboxPath, (String)paramm.g(), paramBoolean);
    } else {
      this.A.a((Runnable)new e(this, paramDropboxPath));
    } 
  }
  
  public final void y5() {
    d0 d01 = this.Q;
    if (d01 != null)
      this.z = d01.F().g().c().observeOn(AndroidSchedulers.a()).subscribe((g)new o(this)); 
  }
  
  public final d0 z5(a parama, Bundle paramBundle) {
    p.o(parama);
    if (z4().l() == null)
      return z4().o(); 
    if (UserSelector.g(paramBundle)) {
      d0 d03 = UserSelector.e(paramBundle).b(parama);
      if (d03 != null)
        return d03; 
    } 
    d0 d02 = parama.q(parama.k().d().E());
    d0 d01 = d02;
    if (d02 == null)
      d01 = parama.m(u0.PERSONAL); 
    return d01;
  }
  
  class DbxMainActivity {}
  
  class DbxMainActivity {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\android\activity\DbxMainActivity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */