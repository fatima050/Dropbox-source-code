package com.dropbox.android.activity;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import com.dropbox.android.DropboxApplication;
import com.dropbox.android.user.UserSelector;
import com.dropbox.common.activity.BaseActivity;
import com.dropbox.kaiken.scoping.ViewingUserSelector;
import com.dropbox.product.dbapp.path.DropboxPath;
import dbxyzptlk.DI.s;
import dbxyzptlk.F6.m;
import dbxyzptlk.Fq.q;
import dbxyzptlk.Oh.s;
import dbxyzptlk.ci.a;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

@Metadata(d1 = {"\000*\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\013\n\002\b\003\n\002\030\002\n\000\n\002\030\002\n\002\b\b\b\007\030\000 \0222\0020\0012\0020\0022\0020\003:\001\023B\007¢\006\004\b\004\020\005J\017\020\007\032\0020\006H\026¢\006\004\b\007\020\bJ\017\020\t\032\0020\006H\026¢\006\004\b\t\020\bJ\031\020\r\032\0020\f2\b\020\013\032\004\030\0010\nH\024¢\006\004\b\r\020\016J\017\020\017\032\0020\fH\024¢\006\004\b\017\020\005J\017\020\020\032\0020\006H\026¢\006\004\b\020\020\bJ\017\020\021\032\0020\006H\026¢\006\004\b\021\020\b¨\006\024"}, d2 = {"Lcom/dropbox/android/activity/DropboxBrowser;", "Lcom/dropbox/common/activity/BaseActivity;", "Ldbxyzptlk/Oh/s;", "Ldbxyzptlk/ci/a;", "<init>", "()V", "", "a0", "()Z", "k0", "Landroid/os/Bundle;", "savedInstanceState", "Ldbxyzptlk/pI/D;", "onCreate", "(Landroid/os/Bundle;)V", "onResumeFragments", "X2", "O2", "c", "a", "Dropbox_normalRelease"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class DropboxBrowser extends BaseActivity implements s, a {
  public static final a c = new a(null);
  
  public static final String d = "EXTRA_ACTION_BAR_ACTIVITY_ACTION";
  
  public static final Intent A4(DropboxPath paramDropboxPath, String paramString) {
    return c.d(paramDropboxPath, paramString);
  }
  
  public static final Intent B4(DropboxPath paramDropboxPath, String paramString) {
    return c.f(paramDropboxPath, paramString);
  }
  
  public static final Intent C4(DropboxPath paramDropboxPath, String paramString) {
    return c.h(paramDropboxPath, paramString);
  }
  
  public static final Intent x4(Context paramContext, DropboxPath paramDropboxPath, String paramString) {
    return c.a(paramContext, paramDropboxPath, paramString);
  }
  
  public static final Intent y4(String paramString1, String paramString2) {
    return c.b(paramString1, paramString2);
  }
  
  public static final Intent z4() {
    return c.c();
  }
  
  public boolean O2() {
    return m.a.O2();
  }
  
  public boolean X2() {
    return m.a.X2();
  }
  
  public boolean a0() {
    return false;
  }
  
  public boolean k0() {
    return false;
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    Object object = getIntent().clone();
    s.f(object, "null cannot be cast to non-null type android.content.Intent");
    Intent intent = (Intent)object;
    if (!isTaskRoot() && !intent.hasExtra("EXTRA_INITIAL_LOGIN") && s.c("android.intent.action.MAIN", intent.getAction()) && intent.hasCategory("android.intent.category.LAUNCHER")) {
      finish();
      return;
    } 
    if (!intent.getBooleanExtra("EXTRA_IS_INTERNAL", false))
      intent.setFlags(0); 
    intent.removeExtra("EXTRA_IS_INTERNAL");
    if (DropboxApplication.h.q0((Context)this).a() == null) {
      intent.putExtra("EXTRA_INITIAL_LOGIN", true);
      if (intent.hasExtra("EXTRA_USER_ID") || UserSelector.g(intent.getExtras())) {
        object = "com.dropbox.intent.action.DROPBOX_LOGIN";
      } else {
        object = null;
      } 
      startActivity(dbxyzptlk.K6.a.f((Context)this, intent, false, (String)object, null, null, 48, null));
      finish();
      return;
    } 
    object = intent.getStringExtra("EXTRA_USER_ID");
    if (object != null) {
      UserSelector.i(intent, UserSelector.d((String)object));
      q.d(intent, ViewingUserSelector.b.a((String)object));
    } 
    intent.setClass((Context)this, DbxMainActivity.class);
    object = d;
    String str = intent.getStringExtra((String)object);
    if (str != null)
      intent.setAction(str); 
    intent.removeExtra("EXTRA_USER_ID");
    intent.removeExtra((String)object);
    intent.setFlags(67108864);
    startActivity(intent);
    finish();
  }
  
  public void onResumeFragments() {
    super.onResumeFragments();
    dbxyzptlk.sL.a.a.e(new RuntimeException("onResumeFragments was called. This should never happen."));
  }
  
  @Metadata(d1 = {"\000*\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\020\016\n\002\b\003\n\002\030\002\n\002\b/\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\017\020\005\032\0020\004H\007¢\006\004\b\005\020\006J\037\020\013\032\0020\0042\006\020\b\032\0020\0072\006\020\n\032\0020\tH\007¢\006\004\b\013\020\fJ'\020\017\032\0020\0042\006\020\016\032\0020\r2\006\020\b\032\0020\0072\006\020\n\032\0020\tH\007¢\006\004\b\017\020\020J\037\020\022\032\0020\0042\006\020\021\032\0020\t2\006\020\n\032\0020\tH\007¢\006\004\b\022\020\023J\037\020\024\032\0020\0042\006\020\b\032\0020\0072\006\020\n\032\0020\tH\007¢\006\004\b\024\020\fJ\037\020\025\032\0020\0042\006\020\b\032\0020\0072\006\020\n\032\0020\tH\007¢\006\004\b\025\020\fJ\017\020\026\032\0020\004H\002¢\006\004\b\026\020\006R \020\027\032\0020\t8\006XD¢\006\022\n\004\b\027\020\030\022\004\b\033\020\003\032\004\b\031\020\032R\024\020\034\032\0020\t8\006XT¢\006\006\n\004\b\034\020\030R\024\020\035\032\0020\t8\006XT¢\006\006\n\004\b\035\020\030R\024\020\036\032\0020\t8\006XT¢\006\006\n\004\b\036\020\030R\024\020\037\032\0020\t8\006XT¢\006\006\n\004\b\037\020\030R\024\020 \032\0020\t8\006XT¢\006\006\n\004\b \020\030R\024\020!\032\0020\t8\006XT¢\006\006\n\004\b!\020\030R\024\020\"\032\0020\t8\006XT¢\006\006\n\004\b\"\020\030R\024\020#\032\0020\t8\006XT¢\006\006\n\004\b#\020\030R\024\020$\032\0020\t8\006XT¢\006\006\n\004\b$\020\030R\024\020%\032\0020\t8\006XT¢\006\006\n\004\b%\020\030R\024\020&\032\0020\t8\006XT¢\006\006\n\004\b&\020\030R\024\020'\032\0020\t8\006XT¢\006\006\n\004\b'\020\030R\024\020(\032\0020\t8\006XT¢\006\006\n\004\b(\020\030R\024\020)\032\0020\t8\006XT¢\006\006\n\004\b)\020\030R\024\020*\032\0020\t8\006XT¢\006\006\n\004\b*\020\030R\024\020+\032\0020\t8\006XT¢\006\006\n\004\b+\020\030R\024\020,\032\0020\t8\006XT¢\006\006\n\004\b,\020\030R\024\020-\032\0020\t8\006XT¢\006\006\n\004\b-\020\030R\024\020.\032\0020\t8\006XT¢\006\006\n\004\b.\020\030R\024\020/\032\0020\t8\006XT¢\006\006\n\004\b/\020\030R\024\0200\032\0020\t8\006XT¢\006\006\n\004\b0\020\030R\024\0201\032\0020\t8\006XT¢\006\006\n\004\b1\020\030R\024\0202\032\0020\t8\002XT¢\006\006\n\004\b2\020\030R\024\0203\032\0020\t8\006XT¢\006\006\n\004\b3\020\030R\024\0204\032\0020\t8\006XT¢\006\006\n\004\b4\020\030R\024\0205\032\0020\t8\006XT¢\006\006\n\004\b5\020\030R\024\0206\032\0020\t8\006XT¢\006\006\n\004\b6\020\030R\024\0207\032\0020\t8\006XT¢\006\006\n\004\b7\020\030R\024\0208\032\0020\t8\006XT¢\006\006\n\004\b8\020\030R\024\0209\032\0020\t8\006XT¢\006\006\n\004\b9\020\030R\024\020:\032\0020\t8\006XT¢\006\006\n\004\b:\020\030R\024\020;\032\0020\t8\002XT¢\006\006\n\004\b;\020\030¨\006<"}, d2 = {"Lcom/dropbox/android/activity/DropboxBrowser$a;", "", "<init>", "()V", "Landroid/content/Intent;", "c", "()Landroid/content/Intent;", "Lcom/dropbox/product/dbapp/path/DropboxPath;", "path", "", "userId", "d", "(Lcom/dropbox/product/dbapp/path/DropboxPath;Ljava/lang/String;)Landroid/content/Intent;", "Landroid/content/Context;", "context", "a", "(Landroid/content/Context;Lcom/dropbox/product/dbapp/path/DropboxPath;Ljava/lang/String;)Landroid/content/Intent;", "action", "b", "(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;", "h", "f", "g", "EXTRA_ACTION_BAR_ACTIVITY_ACTION", "Ljava/lang/String;", "e", "()Ljava/lang/String;", "getEXTRA_ACTION_BAR_ACTIVITY_ACTION$annotations", "ACTION_ACCOUNT", "ACTION_CAMERA_UPLOAD_GALLERY", "ACTION_FAVORITES", "ACTION_FILE_REQUESTS", "ACTION_GO_TO_APP_SETTING", "ACTION_GO_TO_FOLDER", "ACTION_HOME", "ACTION_MOST_RECENT_UPDATE", "ACTION_MOST_RECENT_UPLOAD", "ACTION_NOTIFICATIONS_FEED", "ACTION_PHOTOS", "ACTION_PREVIEW_DOCUMENT", "ACTION_RECENTS", "ACTION_REMOTE_INSTALL", "ACTION_UPLOAD_FAILURE_DLG", "ACTION_UPLOAD_FAILURE_SAF", "ACTION_UPLOAD_FSW_DLG", "ACTION_VIEW_IN_FOLDER", "EXTRA_DISABLE_ALL_INTROS", "EXTRA_FILENAME", "EXTRA_FILEPATH", "EXTRA_INITIAL_LOGIN", "EXTRA_IS_INTERNAL", "EXTRA_NO_SHOW_REMOTE_INSTALLER", "EXTRA_PATH", "EXTRA_REMOTE_INSTALL_SOURCE", "EXTRA_SHARE", "EXTRA_SHOULD_SHOW_SHARING_TUTORIAL", "EXTRA_STATUS", "EXTRA_TOOLTIP_SOURCE", "EXTRA_UPLOAD_TASK_V2_ID", "EXTRA_USER_ID", "Dropbox_normalRelease"}, k = 1, mv = {1, 9, 0}, xi = 48)
  public static final class a {
    public a() {}
    
    public final Intent a(Context param1Context, DropboxPath param1DropboxPath, String param1String) {
      s.h(param1Context, "context");
      s.h(param1DropboxPath, "path");
      s.h(param1String, "userId");
      Intent intent = new Intent(param1Context, DbxMainActivity.class);
      intent.addCategory("android.intent.category.DEFAULT");
      intent.setFlags(536870912);
      intent.setData(param1DropboxPath.n());
      UserSelector.i(intent, UserSelector.d(param1String));
      intent.putExtra("EXTRA_IS_INTERNAL", true);
      return intent;
    }
    
    public final Intent b(String param1String1, String param1String2) {
      s.h(param1String1, "action");
      s.h(param1String2, "userId");
      Intent intent = g();
      intent.addCategory("android.intent.category.DEFAULT");
      intent.setFlags(536870912);
      UserSelector.i(intent, UserSelector.d(param1String2));
      intent.putExtra(e(), param1String1);
      intent.putExtra("EXTRA_IS_INTERNAL", true);
      return intent;
    }
    
    public final Intent c() {
      Intent intent = g();
      intent.addCategory("android.intent.category.DEFAULT");
      intent.putExtra("EXTRA_IS_INTERNAL", true);
      intent.setFlags(536870912);
      return intent;
    }
    
    public final Intent d(DropboxPath param1DropboxPath, String param1String) {
      s.h(param1DropboxPath, "path");
      s.h(param1String, "userId");
      Intent intent = g();
      intent.addCategory("android.intent.category.DEFAULT");
      intent.setData(param1DropboxPath.n());
      intent.putExtra("EXTRA_USER_ID", param1String);
      return intent;
    }
    
    public final String e() {
      return DropboxBrowser.w4();
    }
    
    public final Intent f(DropboxPath param1DropboxPath, String param1String) {
      s.h(param1DropboxPath, "path");
      s.h(param1String, "userId");
      Intent intent = g();
      intent.setFlags(537001984);
      UserSelector.i(intent, UserSelector.d(param1String));
      intent.putExtra(e(), "ACTION_GO_TO_FOLDER");
      intent.putExtra("EXTRA_PATH", (Parcelable)param1DropboxPath);
      intent.putExtra("EXTRA_IS_INTERNAL", true);
      return intent;
    }
    
    public final Intent g() {
      Intent intent = (new Intent("com.dropbox.BROWSE")).setComponent(new ComponentName("com.dropbox.android", DropboxBrowser.class.getCanonicalName()));
      s.g(intent, "setComponent(...)");
      return intent;
    }
    
    public final Intent h(DropboxPath param1DropboxPath, String param1String) {
      s.h(param1DropboxPath, "path");
      s.h(param1String, "userId");
      Intent intent = g();
      intent.setFlags(537001984);
      UserSelector.i(intent, UserSelector.d(param1String));
      intent.putExtra(e(), "ACTION_VIEW_IN_FOLDER");
      intent.putExtra("EXTRA_PATH", (Parcelable)param1DropboxPath);
      intent.putExtra("EXTRA_IS_INTERNAL", true);
      return intent;
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\android\activity\DropboxBrowser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */