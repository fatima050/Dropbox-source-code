package com.dropbox.android.activity.base;

import android.os.Bundle;
import com.dropbox.android.user.UserSelector;
import com.dropbox.android.user.a;
import dbxyzptlk.CC.p;
import dbxyzptlk.Fe.b;
import dbxyzptlk.pc.d0;

public abstract class BaseUserActivity extends BaseIdentityActivity {
  public boolean d = false;
  
  public boolean e = false;
  
  public UserSelector f = null;
  
  public UserSelector B4() {
    return UserSelector.e(getIntent().getExtras());
  }
  
  public d0 C4() {
    b.a();
    p.e(this.d, "Assert failed.");
    p.e(this.e, "Assert failed.");
    a a = z4();
    return (a != null) ? this.f.b(a) : null;
  }
  
  public final void X3(Bundle paramBundle, boolean paramBoolean) {
    p.e(k3(z4()), "Assert failed.");
    getLifecycle();
  }
  
  public final boolean k3(a parama) {
    boolean bool;
    if (parama != null && this.f.b(parama) != null) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    this.d = true;
    this.f = B4();
  }
  
  public boolean w4() {
    this.e = true;
    return super.w4();
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\android\activity\base\BaseUserActivity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */