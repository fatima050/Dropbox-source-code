package com.dropbox.android.activity.base;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import com.dropbox.android.DropboxApplication;
import com.dropbox.android.activity.DropboxBrowser;
import com.dropbox.android.user.DbxUserManager;
import com.dropbox.android.user.a;
import com.dropbox.android.user.e;
import com.dropbox.common.activity.BaseActivity;
import dbxyzptlk.F6.a;
import dbxyzptlk.F6.o;

public abstract class BaseIdentityActivity extends BaseActivity implements o {
  public a c;
  
  public void A4(Bundle paramBundle) {
    this.c.e(paramBundle);
  }
  
  public void j2() {
    Intent intent = DropboxBrowser.z4();
    intent.setFlags(268468224);
    startActivity(intent);
  }
  
  public boolean k3(a parama) {
    boolean bool;
    if (parama != null) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public void onCreate(Bundle paramBundle) {
    a a1 = new a(DropboxApplication.b1((Context)this), this);
    this.c = a1;
    a1.f(paramBundle);
    super.onCreate(paramBundle);
  }
  
  public void onDestroy() {
    super.onDestroy();
    this.c.g();
  }
  
  public void onPause() {
    super.onPause();
    this.c.h();
  }
  
  public void onResumeFragments() {
    super.onResumeFragments();
    this.c.i();
  }
  
  public void onSaveInstanceState(Bundle paramBundle) {
    super.onSaveInstanceState(paramBundle);
    this.c.j(paramBundle);
  }
  
  public void onStart() {
    super.onStart();
    this.c.k();
  }
  
  public void onStop() {
    super.onStop();
    this.c.l();
  }
  
  public boolean w4() {
    return this.c.a();
  }
  
  public DbxUserManager.b x4() {
    return this.c.b();
  }
  
  public e y4() {
    return this.c.c();
  }
  
  public a z4() {
    return this.c.d();
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\android\activity\base\BaseIdentityActivity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */