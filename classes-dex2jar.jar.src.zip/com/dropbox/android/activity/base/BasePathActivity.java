package com.dropbox.android.activity.base;

import android.content.Context;
import android.os.Bundle;
import com.dropbox.android.DropboxApplication;
import com.dropbox.android.user.a;
import com.dropbox.product.dbapp.path.Path;
import dbxyzptlk.CC.m;
import dbxyzptlk.CC.p;
import dbxyzptlk.Fe.b;
import dbxyzptlk.Km.b;
import dbxyzptlk.pc.d0;

public abstract class BasePathActivity<P extends Path> extends BaseIdentityActivity {
  public boolean d = false;
  
  public boolean e = false;
  
  public b<P> f;
  
  public b<P> B4() {
    b.a();
    p.e(this.d, "Assert failed.");
    p.e(this.e, "Assert failed.");
    return this.f;
  }
  
  public d0 C4() {
    d0 d0;
    b<P> b1 = this.f;
    b<P> b2 = null;
    if (b1 == null)
      return null; 
    m m = b1.k();
    b1 = b2;
    if (m.d()) {
      a a = z4();
      b1 = b2;
      if (a != null)
        d0 = a.q((String)m.c()); 
    } 
    return d0;
  }
  
  public final void X3(Bundle paramBundle, boolean paramBoolean) {
    p.e(k3(z4()), "Assert failed.");
  }
  
  public final boolean k3(a parama) {
    b<P> b1 = this.f;
    boolean bool = false;
    if (b1 == null)
      return false; 
    m m = b1.k();
    if (m.d()) {
      boolean bool1 = bool;
      if (parama != null) {
        bool1 = bool;
        if (parama.q((String)m.c()) != null)
          bool1 = true; 
      } 
      return bool1;
    } 
    return true;
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    this.d = true;
    this.f = DropboxApplication.I0((Context)this).b((Context)this, getIntent().getExtras(), x4().b());
  }
  
  public boolean w4() {
    this.e = true;
    return super.w4();
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\android\activity\base\BasePathActivity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */