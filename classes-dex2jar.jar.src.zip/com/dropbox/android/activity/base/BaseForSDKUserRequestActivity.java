package com.dropbox.android.activity.base;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import com.dropbox.android.DropboxApplication;
import com.dropbox.android.user.a;
import com.dropbox.product.dbapp.openwith.b;
import dbxyzptlk.CC.p;
import dbxyzptlk.CC.v;
import dbxyzptlk.Ec.m;
import dbxyzptlk.Fe.b;
import dbxyzptlk.K6.a;
import dbxyzptlk.bf.a;
import dbxyzptlk.pc.d0;
import dbxyzptlk.qc.A;

public abstract class BaseForSDKUserRequestActivity extends BaseIdentityActivity implements a {
  public String d;
  
  public A e;
  
  public d0 f;
  
  public boolean g = false;
  
  public abstract m B4();
  
  public abstract void C4(d0 paramd0);
  
  public abstract void D4();
  
  public final void E4() {
    a a1 = z4();
    p.o(a1);
    this.e = a1.g(this.d);
    this.f = a1.q(this.d);
  }
  
  public void F4(int paramInt, String paramString) {
    p.j(this.g ^ true, "Assert failed: %1$s", "Cannot call showError after onCreate has finished!");
    b.a();
    setResult(paramInt);
    ErrorDialogFragment errorDialogFragment = ErrorDialogFragment.x2(paramString);
    errorDialogFragment.setRetainInstance(false);
    errorDialogFragment.f4((Context)this, getSupportFragmentManager(), "ERROR_DIALOG_FRAGMENT_TAG");
  }
  
  public void X3(Bundle paramBundle, boolean paramBoolean) {
    d0 d01 = this.f;
    if (d01 == null) {
      if (this.e == null) {
        D4();
      } else {
        p.o(z4().l());
        startActivityForResult(a.a((Context)this, "com.dropbox.intent.action.DROPBOX_LOGIN_SECOND_ACCOUNT", false), 1);
      } 
    } else {
      C4(d01);
    } 
  }
  
  public void j2() {
    startActivity(a.d((Context)this, getIntent(), true, "com.dropbox.intent.action.DROPBOX_LOGIN"));
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    if (w4())
      return; 
    this.d = v.e(b.e(getIntent()));
    E4();
    if (paramBundle == null) {
      boolean bool;
      m m = B4().s(this.d);
      if (this.f != null) {
        bool = true;
      } else {
        bool = false;
      } 
      m = m.n("user_linked", Boolean.valueOf(bool));
      (new a(DropboxApplication.b0((Context)this), z4().k().b(), m, getIntent().getStringExtra("com.dropbox.android.intent.extra.CALLING_PACKAGE"))).start();
    } 
    A4(paramBundle);
    this.g = true;
  }
  
  public void t1(int paramInt1, int paramInt2, Intent paramIntent) {
    if (paramInt1 == 1)
      if (paramInt2 == -1 && paramIntent != null) {
        String str = paramIntent.getExtras().getString("EXTRA_LOGGED_IN_USER_ID");
        if (str != null) {
          p.e(this.d.equals(str), "Assert failed.");
          E4();
          d0 d01 = this.f;
          if (d01 != null)
            C4(d01); 
        } 
      } else {
        finish();
      }  
  }
  
  class BaseForSDKUserRequestActivity {}
  
  class BaseForSDKUserRequestActivity {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\android\activity\base\BaseForSDKUserRequestActivity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */