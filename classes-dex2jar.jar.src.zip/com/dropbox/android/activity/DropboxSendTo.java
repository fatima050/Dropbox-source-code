package com.dropbox.android.activity;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.View;
import androidx.activity.result.ActivityResult;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.t;
import com.dropbox.android.user.UserSelector;
import com.dropbox.android.user.a;
import com.dropbox.dbapp.android.browser.DropboxDirectoryPickerFragment;
import com.dropbox.dbapp.android.browser.HistoryEntry;
import com.dropbox.dbapp.android.browser.NewFileNameDialogFragment;
import com.dropbox.dbapp.android.send_to.DropboxHeaderDirectoryPickerFragment;
import com.dropbox.dbapp.android.send_to.SendToHostActivity;
import com.dropbox.dbapp.folder.picker.view.FolderPickerActivity;
import com.dropbox.kaiken.scoping.ViewingUserSelector;
import com.dropbox.product.dbapp.path.DropboxPath;
import com.dropbox.product.dbapp.path.Path;
import com.dropbox.product.dbapp.upload.PreparingUploadDialogFragment;
import com.dropbox.product.dbapp.upload.a;
import com.dropbox.product.dbapp.upload.e;
import com.google.android.material.snackbar.Snackbar;
import com.google.common.collect.m;
import dbxyzptlk.Bf.d;
import dbxyzptlk.Bk.a;
import dbxyzptlk.C9.a;
import dbxyzptlk.CC.p;
import dbxyzptlk.Df.i;
import dbxyzptlk.Df.x;
import dbxyzptlk.E6.J;
import dbxyzptlk.E6.K;
import dbxyzptlk.E6.L;
import dbxyzptlk.E6.M;
import dbxyzptlk.E6.k3;
import dbxyzptlk.Ec.a;
import dbxyzptlk.Ec.g;
import dbxyzptlk.Em.i;
import dbxyzptlk.Fc.Af;
import dbxyzptlk.Fc.Nh;
import dbxyzptlk.Fm.a;
import dbxyzptlk.Fm.b;
import dbxyzptlk.Fq.f;
import dbxyzptlk.K6.a;
import dbxyzptlk.Nm.a;
import dbxyzptlk.Nz.r;
import dbxyzptlk.U2.z;
import dbxyzptlk.V1.c;
import dbxyzptlk.dk.H;
import dbxyzptlk.dk.v;
import dbxyzptlk.gh.l;
import dbxyzptlk.h.a;
import dbxyzptlk.h.b;
import dbxyzptlk.i.a;
import dbxyzptlk.i.d;
import dbxyzptlk.lo.s;
import dbxyzptlk.lx.a;
import dbxyzptlk.mn.l;
import dbxyzptlk.pc.d0;
import dbxyzptlk.pn.o;
import dbxyzptlk.rn.a;
import dbxyzptlk.vx.J;
import dbxyzptlk.w6.Q0;
import dbxyzptlk.w6.V0;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class DropboxSendTo extends DropboxDirectoryPickerActivity implements r, e.a, NewFileNameDialogFragment.b, f, d {
  public static final ComponentName w;
  
  public static final ComponentName x;
  
  public e m;
  
  public g n;
  
  public DropboxPath o;
  
  public Set<Uri> p;
  
  public String q;
  
  public b r;
  
  public Boolean s;
  
  public b<Intent> t;
  
  public String u;
  
  public d0 v;
  
  static {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(DropboxSendTo.class.getName());
    stringBuilder.append(".EmailAlias");
    w = new ComponentName("com.dropbox.android", stringBuilder.toString());
    stringBuilder = new StringBuilder();
    stringBuilder.append(DropboxSendTo.class.getName());
    stringBuilder.append(".FileAlias");
    x = new ComponentName("com.dropbox.android", stringBuilder.toString());
  }
  
  public DropboxSendTo() {
    super(l.upload_sheet_choose_directory_button, true);
  }
  
  public static Intent P4(Context paramContext, Uri paramUri) {
    Intent intent = new Intent(paramContext, DropboxSendTo.class);
    intent.setAction("android.intent.action.SEND");
    intent.putExtra("android.intent.extra.STREAM", (Parcelable)paramUri);
    return intent;
  }
  
  public static Intent Q4(Context paramContext, String paramString) {
    Intent intent = new Intent(paramContext, DropboxSendTo.class);
    intent.setAction("android.intent.action.SEND");
    intent.putExtra("android.intent.extra.STREAM", (Parcelable)Uri.fromFile(new File(paramString)));
    intent.putExtra("EXTRA_FROM_DOWNLOAD_NOTIFICATION", true);
    return intent;
  }
  
  public View C0() {
    View view;
    d d1 = E4();
    if (d1 == null) {
      d1 = null;
    } else {
      view = d1.C0();
    } 
    return view;
  }
  
  public void I4(String paramString) {
    this.q = paramString;
    super.I4(getResources().getString(V0.send_to_v2_title_bar));
  }
  
  public void J1() {
    O4();
  }
  
  public void J4() {
    if (!this.s.booleanValue()) {
      boolean bool = this.m.a();
      this.d = (Fragment)DropboxHeaderDirectoryPickerFragment.v4(this.e, this.f, this.g, "THIRD_PARTY_UPLOADS", this.q, this.m.h(), bool);
      C4();
    } 
  }
  
  public void K(String paramString) {
    K4(paramString, HistoryEntry.a((Path)DropboxPath.d), true);
  }
  
  public DropboxDirectoryPickerFragment K4(String paramString, HistoryEntry paramHistoryEntry, boolean paramBoolean) {
    boolean bool = this.m.a();
    this.d = (Fragment)DropboxHeaderDirectoryPickerFragment.w4(paramString, paramHistoryEntry, this.e, this.f, this.g, paramBoolean, "THIRD_PARTY_UPLOADS", this.q, this.m.h(), bool);
    C4();
    return (DropboxDirectoryPickerFragment)this.d;
  }
  
  public final void N4() {
    J j = G4();
    p.o(j);
    p.o(this.p);
    p.o(this.o);
    S4(j.p());
  }
  
  public final void O4() {
    Fragment fragment = getSupportFragmentManager().m0("TAG_PREPARING_UPLOAD");
    if (fragment != null)
      ((PreparingUploadDialogFragment)fragment).dismiss(); 
  }
  
  public final void S4(String paramString) {
    String str;
    b b1 = this.r;
    if (b1 == null) {
      b1 = null;
    } else {
      str = (String)b1.F().f();
    } 
    Set set = a.a(this.p, str);
    PreparingUploadDialogFragment.F2(paramString, this.o, a.SEND_TO, true, set).show(getSupportFragmentManager(), "TAG_PREPARING_UPLOAD");
  }
  
  public final void T4() {
    String str = l();
    J j = G4();
    if (j != null && str != null) {
      a a1 = j.k0();
      a1.o(str);
      a1.r(System.currentTimeMillis());
    } 
  }
  
  public void V2() {
    d d1 = E4();
    if (d1 != null)
      d1.V2(); 
  }
  
  public void X3(Bundle paramBundle, boolean paramBoolean) {
    a a1 = z4();
    if (!a1.t()) {
      d0 d01 = a1.o();
      this.v = d01;
      this.s = Boolean.valueOf(o.b(d01.i()));
    } else {
      this.s = Boolean.valueOf(o.c(a1.h().i()));
    } 
    if (this.s.booleanValue())
      this.t = registerForActivityResult((a)new d(), (a)new L(this)); 
    super.X3(paramBundle, paramBoolean);
    if (paramBundle == null || paramBoolean) {
      Intent intent;
      Uri[] arrayOfUri = v.a(getIntent());
      if (this.m.g() == e.b.URI && arrayOfUri.length == 0) {
        x.f((Context)this, V0.error_no_files_selected);
        finish();
        return;
      } 
      String str1 = a1.k().d().M();
      String str2 = null;
      if (str1 == null) {
        str1 = null;
      } else {
        d0 d01 = a1.q(str1);
      } 
      long l = a1.k().d().K();
      if (System.currentTimeMillis() - l > 180000L)
        str1 = str2; 
      if (this.s.booleanValue()) {
        if (a1.t()) {
          intent = FolderPickerActivity.B4((Context)this, K.a((Object[])this.m.h()), true);
          this.t.a(intent);
        } else {
          intent = FolderPickerActivity.A4((Context)this, K.a((Object[])this.m.h()), a.SEND_TO, s.EXTERNAL, null, true, true);
          this.t.a(intent);
        } 
      } else if (k3.a(a1) && (!v.d((Context)this, v.a(getIntent())) || a1.t())) {
        if (intent == null) {
          J4();
        } else {
          HistoryEntry historyEntry = HistoryEntry.a((Path)intent.h2().I0());
          K4(intent.getId(), historyEntry, true);
        } 
      } else {
        d0 d01;
        if (intent == null)
          d01 = a1.o(); 
        HistoryEntry historyEntry = HistoryEntry.a((Path)d01.h2().I0());
        K4(d01.getId(), historyEntry, false);
      } 
    } 
  }
  
  public void f3(Snackbar paramSnackbar) {
    d d1 = E4();
    if (d1 != null)
      d1.f3(paramSnackbar); 
  }
  
  public void h0(DropboxPath paramDropboxPath) {
    StringBuilder stringBuilder;
    if (l() == null)
      return; 
    this.o = paramDropboxPath;
    Uri[] arrayOfUri = this.m.h();
    e.b b1 = this.m.g();
    (new Af()).k(this.m.b()).g(this.n);
    int i = a.a[b1.ordinal()];
    if (i != 1) {
      if (i != 2) {
        String str;
        if (i == 3) {
          str = getIntent().getStringExtra("android.intent.extra.SUBJECT");
          NewFileNameDialogFragment.t2(a.URL, str).l2(getSupportFragmentManager());
        } else {
          stringBuilder = new StringBuilder();
          stringBuilder.append("unknown type: ");
          stringBuilder.append(str);
          throw new IllegalStateException(stringBuilder.toString());
        } 
      } else {
        NewFileNameDialogFragment.r2(a.FILE).l2(getSupportFragmentManager());
      } 
    } else {
      this.p = (Set<Uri>)m.E((Object[])stringBuilder);
      N4();
    } 
  }
  
  public void i1() {
    O4();
  }
  
  public void j2() {
    boolean bool = v.d((Context)this, v.a(getIntent()));
    a.c().n("have_granted_permission", Boolean.valueOf(bool)).i(this.n);
    if (bool && findViewById(Q0.frag_container) != null) {
      x.f((Context)this, V0.error_login_needed_to_access);
      finish();
      return;
    } 
    Intent intent = new Intent(getIntent());
    intent.removeExtra("share_screenshot");
    intent.removeExtra("share_favicon");
    startActivity(a.d((Context)this, intent, false, null));
  }
  
  public String l() {
    String str = this.u;
    if (str != null)
      return str; 
    d0 d01 = this.v;
    return (d01 != null) ? d01.getId() : super.l();
  }
  
  public final void l0(DropboxPath paramDropboxPath, List<Uri> paramList, List<J> paramList1) {
    if (paramList1.isEmpty()) {
      J1();
      return;
    } 
    T4();
    String str = l();
    ViewingUserSelector viewingUserSelector = ViewingUserSelector.a(str);
    if (paramList.size() > 0) {
      intent = (Intent)paramList.get(0);
    } else {
      intent = null;
    } 
    Intent intent = a.a((Context)this, paramList, paramList1, viewingUserSelector, (Uri)intent, false);
    if (intent != null) {
      UserSelector.i(intent, UserSelector.d(str));
      setResult(-1, intent);
    } 
    startActivity(SendToHostActivity.x4((Context)this, str, paramList1, paramList, paramDropboxPath, null));
    finish();
  }
  
  public void onCreate(Bundle paramBundle) {
    if (u())
      return; 
    this.n = ((M)s()).d();
    f.a a1 = new f.a(getResources());
    e e1 = new e(getIntent(), getContentResolver(), (f)a1);
    this.m = e1;
    I4(e1.c());
    super.onCreate(paramBundle);
    G().setNavigationIcon(i.d(G().getNavigationIcon(), (Context)this, a.standard_text));
    G().setTitleTextAppearance((Context)this, l.TextAppearance_Dig_Title_Small);
    this.r = (b)(new t((z)this)).a(b.class);
    if (!this.m.i()) {
      x.f((Context)this, a.error_generic);
      finish();
      return;
    } 
    if (paramBundle != null) {
      ArrayList arrayList = H.b(paramBundle, "SENT_FILES", Uri.class);
      if (arrayList != null)
        this.p = (Set<Uri>)m.B(arrayList); 
      this.o = (DropboxPath)H.d(paramBundle, "SELECTED_DIR", DropboxPath.class);
      this.u = paramBundle.getString("FOLDER_PICKER_RESULT_USER_ID");
    } else if (getIntent().hasExtra("EXTRA_FROM_DOWNLOAD_NOTIFICATION")) {
      z4().h().h2().g1();
      a.i0().o("userset_id", z4().j()).i(this.n);
    } 
    i.a(findViewById(Q0.frag_container));
    (new Nh()).k((this.m.h()).length).g(this.n);
  }
  
  public void onSaveInstanceState(Bundle paramBundle) {
    ArrayList arrayList;
    super.onSaveInstanceState(paramBundle);
    if (this.p != null) {
      arrayList = new ArrayList<>(this.p);
    } else {
      arrayList = null;
    } 
    paramBundle.putParcelableArrayList("SENT_FILES", arrayList);
    paramBundle.putParcelable("SELECTED_DIR", (Parcelable)this.o);
    paramBundle.putString("FOLDER_PICKER_RESULT_USER_ID", this.u);
  }
  
  public void onStop() {
    super.onStop();
    if (!isChangingConfigurations()) {
      J j = G4();
      if (j != null)
        j.v().r(); 
    } 
  }
  
  public void p1(String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: getfield m : Lcom/dropbox/android/activity/e;
    //   4: invokevirtual e : ()Ljava/lang/String;
    //   7: astore_2
    //   8: aload_2
    //   9: astore #4
    //   11: aload_2
    //   12: ifnonnull -> 20
    //   15: ldc_w ''
    //   18: astore #4
    //   20: aconst_null
    //   21: astore #6
    //   23: aconst_null
    //   24: astore_3
    //   25: aconst_null
    //   26: astore #7
    //   28: aload_0
    //   29: invokevirtual G4 : ()Ldbxyzptlk/E6/J;
    //   32: astore_2
    //   33: aload_2
    //   34: invokestatic o : (Ljava/lang/Object;)Ljava/lang/Object;
    //   37: pop
    //   38: aload_2
    //   39: invokeinterface h0 : ()Ldbxyzptlk/Xs/r0;
    //   44: invokevirtual o : ()Ljava/io/File;
    //   47: astore_2
    //   48: new java/io/File
    //   51: astore #8
    //   53: aload #8
    //   55: aload_2
    //   56: aload_1
    //   57: invokespecial <init> : (Ljava/io/File;Ljava/lang/String;)V
    //   60: new java/io/FileOutputStream
    //   63: astore_1
    //   64: aload_1
    //   65: aload #8
    //   67: invokespecial <init> : (Ljava/io/File;)V
    //   70: aload_1
    //   71: aload #8
    //   73: invokestatic a : (Ljava/io/FileOutputStream;Ljava/io/File;)Ljava/io/FileOutputStream;
    //   76: astore_1
    //   77: aload #7
    //   79: astore_3
    //   80: aload_1
    //   81: astore_2
    //   82: new java/io/OutputStreamWriter
    //   85: astore #5
    //   87: aload #7
    //   89: astore_3
    //   90: aload_1
    //   91: astore_2
    //   92: aload #5
    //   94: aload_1
    //   95: ldc_w 'UTF-8'
    //   98: invokespecial <init> : (Ljava/io/OutputStream;Ljava/lang/String;)V
    //   101: aload #4
    //   103: invokeinterface toString : ()Ljava/lang/String;
    //   108: invokestatic isNetworkUrl : (Ljava/lang/String;)Z
    //   111: ifeq -> 142
    //   114: aload #4
    //   116: invokeinterface toString : ()Ljava/lang/String;
    //   121: aload #5
    //   123: invokestatic a : (Ljava/lang/String;Ljava/io/OutputStreamWriter;)V
    //   126: goto -> 154
    //   129: astore #4
    //   131: aload #5
    //   133: astore_3
    //   134: goto -> 277
    //   137: astore #4
    //   139: goto -> 229
    //   142: aload #5
    //   144: aload #4
    //   146: invokeinterface toString : ()Ljava/lang/String;
    //   151: invokevirtual write : (Ljava/lang/String;)V
    //   154: aload #5
    //   156: invokevirtual flush : ()V
    //   159: aload_1
    //   160: invokevirtual getFD : ()Ljava/io/FileDescriptor;
    //   163: invokevirtual sync : ()V
    //   166: aload_0
    //   167: aload #8
    //   169: invokestatic fromFile : (Ljava/io/File;)Landroid/net/Uri;
    //   172: invokestatic J : (Ljava/lang/Object;)Lcom/google/common/collect/m;
    //   175: putfield p : Ljava/util/Set;
    //   178: aload_0
    //   179: invokevirtual N4 : ()V
    //   182: aload #5
    //   184: invokevirtual close : ()V
    //   187: aload_1
    //   188: ifnull -> 276
    //   191: aload_1
    //   192: invokevirtual close : ()V
    //   195: goto -> 276
    //   198: astore #4
    //   200: aload_2
    //   201: astore_1
    //   202: goto -> 277
    //   205: astore #4
    //   207: aload #6
    //   209: astore #5
    //   211: goto -> 229
    //   214: astore #4
    //   216: aconst_null
    //   217: astore_1
    //   218: goto -> 277
    //   221: astore #4
    //   223: aconst_null
    //   224: astore_1
    //   225: aload #6
    //   227: astore #5
    //   229: aload #5
    //   231: astore_3
    //   232: aload_1
    //   233: astore_2
    //   234: aload_0
    //   235: getstatic dbxyzptlk/w6/V0.error_text_upload_not_imp : I
    //   238: invokestatic h : (Landroid/content/Context;I)Landroid/widget/Toast;
    //   241: pop
    //   242: aload #5
    //   244: astore_3
    //   245: aload_1
    //   246: astore_2
    //   247: aload #4
    //   249: ldc_w 'IOException creating tmp file for upload'
    //   252: iconst_0
    //   253: anewarray java/lang/Object
    //   256: invokestatic k : (Ljava/lang/Throwable;Ljava/lang/String;[Ljava/lang/Object;)V
    //   259: aload #5
    //   261: ifnull -> 269
    //   264: aload #5
    //   266: invokevirtual close : ()V
    //   269: aload_1
    //   270: ifnull -> 276
    //   273: goto -> 191
    //   276: return
    //   277: aload_3
    //   278: ifnull -> 285
    //   281: aload_3
    //   282: invokevirtual close : ()V
    //   285: aload_1
    //   286: ifnull -> 293
    //   289: aload_1
    //   290: invokevirtual close : ()V
    //   293: aload #4
    //   295: athrow
    //   296: astore_2
    //   297: goto -> 166
    //   300: astore_2
    //   301: goto -> 187
    //   304: astore_1
    //   305: goto -> 276
    //   308: astore_2
    //   309: goto -> 269
    //   312: astore_2
    //   313: goto -> 285
    //   316: astore_1
    //   317: goto -> 293
    // Exception table:
    //   from	to	target	type
    //   28	77	221	java/io/IOException
    //   28	77	214	finally
    //   82	87	205	java/io/IOException
    //   82	87	198	finally
    //   92	101	205	java/io/IOException
    //   92	101	198	finally
    //   101	126	137	java/io/IOException
    //   101	126	129	finally
    //   142	154	137	java/io/IOException
    //   142	154	129	finally
    //   154	159	137	java/io/IOException
    //   154	159	129	finally
    //   159	166	296	java/io/SyncFailedException
    //   159	166	137	java/io/IOException
    //   159	166	129	finally
    //   166	182	137	java/io/IOException
    //   166	182	129	finally
    //   182	187	300	java/io/IOException
    //   191	195	304	java/io/IOException
    //   234	242	198	finally
    //   247	259	198	finally
    //   264	269	308	java/io/IOException
    //   281	285	312	java/io/IOException
    //   289	293	316	java/io/IOException
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\android\activity\DropboxSendTo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */