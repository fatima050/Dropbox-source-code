package com.dropbox.android.activity;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.o;
import com.dropbox.android.activity.base.BaseIdentityActivity;
import com.dropbox.android.user.a;
import com.dropbox.common.android.ui.widgets.DbxToolbar;
import com.dropbox.dbapp.android.browser.DropboxDirectoryPickerFragment;
import com.dropbox.dbapp.android.browser.DropboxEntryPickerFragment;
import com.dropbox.dbapp.android.browser.HistoryEntry;
import com.dropbox.product.dbapp.path.DropboxPath;
import com.google.android.material.snackbar.Snackbar;
import dbxyzptlk.Bf.c;
import dbxyzptlk.Bf.d;
import dbxyzptlk.CC.p;
import dbxyzptlk.E6.W;
import dbxyzptlk.E6.X;
import dbxyzptlk.E6.k3;
import dbxyzptlk.Ec.g;
import dbxyzptlk.Fq.f;
import dbxyzptlk.Jm.f;
import dbxyzptlk.lq.f;
import dbxyzptlk.lq.j;
import dbxyzptlk.pc.d0;
import dbxyzptlk.rf.i;
import dbxyzptlk.w6.Q0;
import java.util.List;

public abstract class DropboxEntryPickerActivity extends BaseIdentityActivity implements f, DropboxEntryPickerFragment.b, DbxToolbar.c, d, f {
  public DropboxEntryPickerFragment d;
  
  public String e;
  
  public List<String> f;
  
  public DbxToolbar g;
  
  public f h;
  
  public g i;
  
  public final c j = new c();
  
  public final j k = j.b();
  
  public final String[] B4() {
    String[] arrayOfString2 = getIntent().getStringArrayExtra("android.intent.extra.MIME_TYPES");
    String str = getIntent().getType();
    String[] arrayOfString1 = arrayOfString2;
    if (arrayOfString2 == null) {
      arrayOfString1 = arrayOfString2;
      if (str != null) {
        arrayOfString1 = new String[1];
        arrayOfString1[0] = str;
      } 
    } 
    return arrayOfString1;
  }
  
  public View C0() {
    return this.j.b();
  }
  
  public X C4() {
    String str = l();
    return (str == null) ? null : (X)this.h.a(str);
  }
  
  public void D4(String paramString) {
    boolean bool;
    if (this.d == null) {
      bool = true;
    } else {
      bool = false;
    } 
    p.j(bool, "Object must be null: %1$s", "setCaption should be called before any fragment is setup.");
    this.e = paramString;
  }
  
  public void E4(List<String> paramList) {
    boolean bool;
    if (this.d == null) {
      bool = true;
    } else {
      bool = false;
    } 
    p.j(bool, "Object must be null: %1$s", "setExtensions should be called before any fragment is setup.");
    this.f = paramList;
  }
  
  public void F4(List<String> paramList) {
    H4(DropboxEntryPickerFragment.R3(this.e, paramList));
  }
  
  public DbxToolbar G() {
    return this.g;
  }
  
  public void G4(String[] paramArrayOfString) {
    H4(DropboxEntryPickerFragment.S3(this.e, paramArrayOfString));
  }
  
  public final void H4(DropboxEntryPickerFragment paramDropboxEntryPickerFragment) {
    this.d = paramDropboxEntryPickerFragment;
    a a = z4();
    String str1 = a.k().d().L();
    String str2 = null;
    if (str1 != null) {
      d0 d0 = a.q(str1);
    } else {
      str1 = null;
    } 
    long l = a.k().d().J();
    if (System.currentTimeMillis() - l > 180000L)
      str1 = str2; 
    if (!k3.a(a) || str1 != null) {
      DropboxPath dropboxPath;
      d0 d0;
      if (str1 != null) {
        str2 = str1;
      } else {
        d0 = z4().o();
      } 
      p.o(d0);
      if (str1 == null) {
        dropboxPath = DropboxPath.d;
      } else {
        dropboxPath = d0.h2().G0();
      } 
      this.d.E3((HistoryEntry)new HistoryEntry.DropboxHistoryEntry(dropboxPath), d0.getId());
    } 
    o o = getSupportFragmentManager().q();
    o.v(Q0.frag_container, (Fragment)this.d, DropboxDirectoryPickerFragment.h0);
    o.k();
  }
  
  public void K(String paramString) {
    p.o(this.d);
    p.o(z4().q(paramString));
    this.d.E3((HistoryEntry)new HistoryEntry.DropboxHistoryEntry(DropboxPath.d), paramString);
  }
  
  public void V2() {
    this.j.a();
  }
  
  public void X3(Bundle paramBundle, boolean paramBoolean) {
    if (paramBundle == null || paramBoolean) {
      p.o(z4());
      String[] arrayOfString = B4();
      if (this.f == null || arrayOfString == null) {
        paramBoolean = true;
      } else {
        paramBoolean = false;
      } 
      p.e(paramBoolean, "Assert failed.");
      List<String> list = this.f;
      if (list != null) {
        F4(list);
      } else {
        G4(arrayOfString);
      } 
      return;
    } 
    this.d = (DropboxEntryPickerFragment)getSupportFragmentManager().l0(Q0.frag_container);
  }
  
  public void f3(Snackbar paramSnackbar) {
    this.j.f(paramSnackbar);
  }
  
  public String l() {
    DropboxEntryPickerFragment dropboxEntryPickerFragment = this.d;
    if (dropboxEntryPickerFragment != null) {
      String str = dropboxEntryPickerFragment.l();
    } else {
      dropboxEntryPickerFragment = null;
    } 
    return (String)dropboxEntryPickerFragment;
  }
  
  public j n2() {
    return this.k;
  }
  
  public void onBackPressed() {
    DropboxEntryPickerFragment dropboxEntryPickerFragment = this.d;
    if (dropboxEntryPickerFragment == null || !dropboxEntryPickerFragment.v2())
      super.onBackPressed(); 
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    setContentView(i.frag_toolbar_container);
    DbxToolbar dbxToolbar = (DbxToolbar)findViewById(Q0.dbx_toolbar);
    this.g = dbxToolbar;
    dbxToolbar.b();
    setSupportActionBar((Toolbar)this.g);
    setTitle(null);
    if (w4())
      return; 
    if (u())
      return; 
    W w = (W)s();
    this.h = w.I0();
    this.i = w.d();
    A4(paramBundle);
    this.g.setAccessibilityTraversalBefore(Q0.frag_container);
    this.j.c(findViewById(Q0.frag_container));
  }
  
  public void onDestroy() {
    this.j.g();
    super.onDestroy();
  }
  
  public boolean onOptionsItemSelected(MenuItem paramMenuItem) {
    if (paramMenuItem.getItemId() == 16908332) {
      finish();
      return true;
    } 
    return super.onOptionsItemSelected(paramMenuItem);
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\android\activity\DropboxEntryPickerActivity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */