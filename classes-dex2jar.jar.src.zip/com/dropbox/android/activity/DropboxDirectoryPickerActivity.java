package com.dropbox.android.activity;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.o;
import com.dropbox.android.activity.base.BaseIdentityActivity;
import com.dropbox.common.android.ui.widgets.DbxToolbar;
import com.dropbox.dbapp.android.browser.DropboxDirectoryPickerFragment;
import com.dropbox.dbapp.android.browser.HistoryEntry;
import com.dropbox.product.android.dbapp.search.directory_search.view.DirectorySearchFragment;
import com.dropbox.product.dbapp.path.DropboxPath;
import com.dropbox.product.dbapp.path.Path;
import dbxyzptlk.Bf.d;
import dbxyzptlk.CC.p;
import dbxyzptlk.E6.B;
import dbxyzptlk.E6.I;
import dbxyzptlk.E6.J;
import dbxyzptlk.Ec.a;
import dbxyzptlk.Ec.g;
import dbxyzptlk.Fq.d;
import dbxyzptlk.Jm.f;
import dbxyzptlk.lq.f;
import dbxyzptlk.lq.j;
import dbxyzptlk.qx.a;
import dbxyzptlk.qx.f;
import dbxyzptlk.rf.i;
import dbxyzptlk.w6.Q0;
import dbxyzptlk.z8.b;
import java.util.Objects;

public abstract class DropboxDirectoryPickerActivity extends BaseIdentityActivity implements f, a, DbxToolbar.c, f, DirectorySearchFragment.a, d {
  public Fragment d;
  
  public int e;
  
  public final boolean f;
  
  public String g;
  
  public DbxToolbar h;
  
  public String i;
  
  public g j;
  
  public f k;
  
  public final j l = j.b();
  
  public DropboxDirectoryPickerActivity(int paramInt, boolean paramBoolean) {
    this.e = paramInt;
    this.f = paramBoolean;
  }
  
  public final void C4() {
    o o = getSupportFragmentManager().q();
    o.v(Q0.frag_container, this.d, DropboxDirectoryPickerFragment.h0);
    o.k();
  }
  
  public g D4() {
    J j1 = G4();
    return (g)((j1 == null) ? this.j : j1.j());
  }
  
  public d E4() {
    return (d)this.d;
  }
  
  public boolean F4() {
    return false;
  }
  
  public DbxToolbar G() {
    return this.h;
  }
  
  public J G4() {
    String str = l();
    return (str == null) ? null : (J)this.k.a(str);
  }
  
  public void I4(String paramString) {
    boolean bool;
    if (this.d == null) {
      bool = true;
    } else {
      bool = false;
    } 
    p.j(bool, "Object must be null: %1$s", "setCaption should be called before any fragment is setup.");
    this.g = paramString;
  }
  
  public void J4() {
    this.d = (Fragment)DropboxDirectoryPickerFragment.X3(this.e, this.f, F4(), this.g, this.i);
    C4();
  }
  
  public void K(String paramString) {
    p.o(this.d);
    ((DropboxDirectoryPickerFragment)this.d).K(paramString);
  }
  
  public DropboxDirectoryPickerFragment K4(String paramString, HistoryEntry paramHistoryEntry, boolean paramBoolean) {
    this.d = (Fragment)DropboxDirectoryPickerFragment.Z3(paramString, paramHistoryEntry, this.e, this.f, F4(), this.g, paramBoolean, true, this.i);
    C4();
    return (DropboxDirectoryPickerFragment)this.d;
  }
  
  public void L4() {
    this.d = (Fragment)DropboxDirectoryPickerFragment.Y3(this.e, this.f, F4(), this.g, true, this.i);
    C4();
  }
  
  public void V1(DropboxPath paramDropboxPath) {
    getSupportFragmentManager().k1();
    ((DropboxDirectoryPickerFragment)this.d).N0((Path)paramDropboxPath);
  }
  
  public void X3(Bundle paramBundle, boolean paramBoolean) {
    if (paramBundle == null || paramBoolean) {
      Objects.requireNonNull(z4(), "userset cannot be null");
      J4();
      return;
    } 
    this.d = getSupportFragmentManager().l0(Q0.frag_container);
  }
  
  public void e0(DropboxPath paramDropboxPath, String paramString, Boolean paramBoolean) {
    Fragment fragment = this.d;
    if (fragment != null)
      ((DropboxDirectoryPickerFragment)fragment).N0((Path)paramDropboxPath); 
  }
  
  public String l() {
    Fragment fragment = this.d;
    if (fragment != null) {
      String str = ((DropboxDirectoryPickerFragment)fragment).l();
    } else {
      fragment = null;
    } 
    return (String)fragment;
  }
  
  public j n2() {
    return this.l;
  }
  
  public void onBackPressed() {
    Fragment fragment = this.d;
    if (fragment != null && !(fragment instanceof DropboxDirectoryPickerFragment)) {
      super.onBackPressed();
      return;
    } 
    if (fragment == null || !((DropboxDirectoryPickerFragment)fragment).v2()) {
      a.O().o("source", this.i).i(D4());
      super.onBackPressed();
    } 
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    setContentView(i.frag_toolbar_container);
    DbxToolbar dbxToolbar = (DbxToolbar)findViewById(Q0.dbx_toolbar);
    this.h = dbxToolbar;
    dbxToolbar.b();
    setSupportActionBar((Toolbar)this.h);
    if (u())
      return; 
    B b = (B)s();
    this.k = b.I0();
    this.j = b.d();
    this.h.setNavigationOnClickListener((View.OnClickListener)new I(this));
    setTitle(null);
    String str = getIntent().getStringExtra("EXTRA_PICK_DIRECTORY_LOGGING_SOURCE");
    this.i = str;
    if (str == null)
      this.i = "UNKNOWN"; 
    if (w4())
      return; 
    findViewById(b.shadow_compat).setVisibility(8);
    A4(paramBundle);
  }
  
  public boolean onOptionsItemSelected(MenuItem paramMenuItem) {
    if (paramMenuItem.getItemId() == 16908332) {
      finish();
      return true;
    } 
    return super.onOptionsItemSelected(paramMenuItem);
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\android\activity\DropboxDirectoryPickerActivity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */