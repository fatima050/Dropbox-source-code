package com.dropbox.android.activity;

import android.content.ClipData;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import com.dropbox.android.DropboxApplication;
import com.dropbox.android.activity.dialog.MultipleFileDownloadProgressDialogFrag;
import com.dropbox.common.safeintentstarter.NoHandlerForIntentException;
import com.dropbox.product.dbapp.entry.DropboxLocalEntry;
import com.dropbox.product.dbapp.entry.LocalEntry;
import com.dropbox.product.dbapp.path.DropboxPath;
import dbxyzptlk.CC.p;
import dbxyzptlk.E6.X;
import dbxyzptlk.Ec.a;
import dbxyzptlk.Ec.g;
import dbxyzptlk.Ec.m;
import dbxyzptlk.Em.Q;
import dbxyzptlk.Em.i;
import dbxyzptlk.Em.l;
import dbxyzptlk.Fe.b;
import dbxyzptlk.He.h;
import dbxyzptlk.It.k;
import dbxyzptlk.K6.a;
import dbxyzptlk.Km.a;
import dbxyzptlk.Km.b;
import dbxyzptlk.Nm.a;
import dbxyzptlk.P6.i;
import dbxyzptlk.P6.j;
import dbxyzptlk.Uz.b;
import dbxyzptlk.Z2.a;
import dbxyzptlk.dk.A;
import dbxyzptlk.oj.c;
import dbxyzptlk.rs.a;
import dbxyzptlk.w6.Q0;
import dbxyzptlk.w6.V0;
import java.util.ArrayList;
import java.util.List;

public class DropboxGetFrom extends DropboxEntryPickerActivity implements i.b<DropboxPath>, Q {
  public g l;
  
  public final Handler m = new Handler(Looper.getMainLooper());
  
  public boolean n;
  
  public int o;
  
  public Intent p;
  
  public MultipleFileDownloadProgressDialogFrag<DropboxGetFrom, DropboxPath> q;
  
  public c r;
  
  public boolean F1(DropboxLocalEntry paramDropboxLocalEntry) {
    return a.b((LocalEntry)paramDropboxLocalEntry) ^ true;
  }
  
  public final Uri K4(LocalEntry<DropboxPath> paramLocalEntry, k<?> paramk) {
    p.o(paramLocalEntry);
    p.o(paramk);
    String str = paramLocalEntry.i();
    p.o(str);
    return b.b(str, h.e(paramLocalEntry.k()));
  }
  
  public final void L4(k<?> paramk, LocalEntry<DropboxPath> paramLocalEntry) {
    Uri uri;
    String str1;
    int i;
    Intent intent1;
    this.q.z2();
    Intent intent2 = getIntent();
    String str4 = intent2.getType();
    String str3 = paramLocalEntry.M();
    String str2 = str3;
    if (str3 == null)
      str2 = A.y(paramk.c().getName()); 
    Bundle bundle = intent2.getExtras();
    if (paramLocalEntry instanceof DropboxLocalEntry && ((DropboxLocalEntry)paramLocalEntry).c0()) {
      i = 1;
    } else {
      i = 0;
    } 
    if (!paramLocalEntry.z() && !i) {
      i = 3;
    } else {
      i = 1;
    } 
    if (str2 != null && str2.startsWith("image/") && bundle != null && "true".equals(bundle.getString("crop")) && !h1() && !this.n) {
      Uri uri1 = paramk.d();
      Intent intent = new Intent("com.android.camera.action.CROP");
      intent.putExtras(new Bundle(bundle));
      intent.addFlags(0x2000000 | i);
      intent.setDataAndType(uri1, str2);
      try {
        M4(str4, str2, 1);
        this.r.c((Context)this, intent);
        finish();
        return;
      } catch (NoHandlerForIntentException noHandlerForIntentException) {}
    } 
    if (this.n) {
      if (this.p == null) {
        intent1 = new Intent();
        this.p = intent1;
        intent1.setFlags(i);
      } 
      uri = K4(paramLocalEntry, paramk);
      if (this.p.getClipData() == null) {
        str1 = getResources().getString(V0.entry_picker_clipdata_label);
        this.p.setClipData(ClipData.newRawUri(str1, uri));
      } else {
        this.p.getClipData().addItem(new ClipData.Item(uri));
      } 
      i = this.o - 1;
      this.o = i;
      if (i == 0) {
        M4(str4, null, this.p.getClipData().getItemCount());
        setResult(-1, this.p);
        finish();
      } 
    } else {
      Intent intent = new Intent();
      this.p = intent;
      intent.setFlags(i);
      uri = K4((LocalEntry<DropboxPath>)str1, (k<?>)uri);
      this.p.addFlags(i);
      if (intent1 != null) {
        this.p.setDataAndType(uri, (String)intent1);
      } else {
        this.p.setData(uri);
      } 
      M4(str4, (String)intent1, 1);
      setResult(-1, this.p);
      finish();
    } 
  }
  
  public final void M4(String paramString1, String paramString2, int paramInt) {
    ComponentName componentName = getCallingActivity();
    m m = a.P0().o("request.mime.type", paramString1).o("result.mime.type", paramString2).l("result.selection.size", paramInt).n("multiselect.enabled", Boolean.valueOf(h1()));
    if (componentName != null) {
      paramString1 = componentName.flattenToShortString();
    } else {
      paramString1 = null;
    } 
    m.o("caller", paramString1).i(this.l);
  }
  
  public void P3(DropboxLocalEntry paramDropboxLocalEntry) {
    p.o(paramDropboxLocalEntry);
    X x = C4();
    p.o(x);
    l l = x.p2();
    a a = x.k0();
    l.j0(paramDropboxLocalEntry.P().g());
    a.e(x.p());
    a.s(System.currentTimeMillis());
    ArrayList<DropboxLocalEntry> arrayList = new ArrayList();
    arrayList.add(paramDropboxLocalEntry);
    Q1(arrayList);
  }
  
  public void Q1(List<DropboxLocalEntry> paramList) {
    p.o(paramList);
    this.p = null;
    this.q = null;
    int i = paramList.size();
    this.o = i;
    if (i > 1) {
      this.n = true;
    } else {
      this.n = false;
    } 
    X x = C4();
    p.o(x);
    a a = x.r0();
    for (i = 0; i < paramList.size(); i++) {
      DropboxLocalEntry dropboxLocalEntry = paramList.get(i);
      i i1 = new i((Context)this, this, (LocalEntry)dropboxLocalEntry, a.a(dropboxLocalEntry.P()));
      i1.c();
      MultipleFileDownloadProgressDialogFrag<DropboxGetFrom, DropboxPath> multipleFileDownloadProgressDialogFrag = this.q;
      if (multipleFileDownloadProgressDialogFrag == null) {
        multipleFileDownloadProgressDialogFrag = MultipleFileDownloadProgressDialogFrag.B2((j)i1);
        this.q = multipleFileDownloadProgressDialogFrag;
        multipleFileDownloadProgressDialogFrag.u2((Context)this, getSupportFragmentManager());
      } else {
        multipleFileDownloadProgressDialogFrag.x2((j)i1);
      } 
      i1.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, (Object[])new Void[0]);
    } 
  }
  
  public void b() {}
  
  public Intent getIntent() {
    Intent intent = new Intent(super.getIntent());
    intent.setClipData(null);
    return intent;
  }
  
  public boolean h1() {
    return getIntent().getBooleanExtra("android.intent.extra.ALLOW_MULTIPLE", false);
  }
  
  public void j2() {
    startActivity(a.d((Context)this, getIntent(), true, null));
  }
  
  public void onCreate(Bundle paramBundle) {
    D4(getResources().getString(V0.choose_file_title_caption));
    super.onCreate(paramBundle);
    this.l = DropboxApplication.b0((Context)this);
    this.r = DropboxApplication.L0((Context)this);
    ComponentName componentName = getCallingActivity();
    m m = a.O0().o("request.mime.type", getIntent().getType());
    if (componentName != null) {
      String str = componentName.flattenToShortString();
    } else {
      componentName = null;
    } 
    m.o("caller", (String)componentName).i(this.l);
    i.a(findViewById(Q0.frag_container));
  }
  
  public void s3(k<DropboxPath> paramk, LocalEntry<DropboxPath> paramLocalEntry, b<DropboxPath> paramb, Context paramContext) {
    p.o(paramk);
    p.o(paramLocalEntry);
    p.o(paramb);
    p.o(paramContext);
    b.c(paramLocalEntry, DropboxLocalEntry.class);
    DropboxLocalEntry dropboxLocalEntry = (DropboxLocalEntry)paramLocalEntry;
    if (dropboxLocalEntry.i() == null) {
      getSupportLoaderManager().f(1, null, (a.a)new a(this, paramLocalEntry, paramk));
    } else {
      L4(paramk, (LocalEntry<DropboxPath>)dropboxLocalEntry);
    } 
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\android\activity\DropboxGetFrom.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */