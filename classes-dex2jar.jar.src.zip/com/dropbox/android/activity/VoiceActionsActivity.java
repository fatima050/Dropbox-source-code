package com.dropbox.android.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import com.dropbox.android.activity.base.BaseIdentityActivity;
import com.dropbox.product.android.dbapp.search.impl.model.SearchParams;
import com.dropbox.product.android.dbapp.search.impl.view.SearchActivity;
import com.dropbox.product.dbapp.path.DropboxPath;
import dbxyzptlk.Ec.a;
import dbxyzptlk.Ec.g;
import dbxyzptlk.K6.a;
import dbxyzptlk.fw.f;
import dbxyzptlk.pc.u0;
import dbxyzptlk.sc.H;
import dbxyzptlk.yx.e;

public class VoiceActionsActivity extends BaseIdentityActivity {
  public final String B4(f paramf) {
    int i = a.a[paramf.ordinal()];
    if (i != 1) {
      if (i == 2)
        return z4().r(u0.BUSINESS).getId(); 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Unknown PairingFilterState ");
      stringBuilder.append(paramf);
      throw new IllegalStateException(stringBuilder.toString());
    } 
    return z4().r(u0.PERSONAL).getId();
  }
  
  public void X3(Bundle paramBundle, boolean paramBoolean) {}
  
  public void j2() {
    super.j2();
    startActivity(a.d((Context)this, getIntent(), true, null));
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    if (w4())
      return; 
    g g = z4().m(u0.PERSONAL).e();
    if (paramBundle == null) {
      Intent intent = getIntent();
      if ("com.google.android.gms.actions.SEARCH_ACTION".equals(intent.getAction())) {
        a.Z0().o("action", "search").i(g);
        String str2 = intent.getStringExtra("query");
        String str1 = str2;
        if (str2 == null)
          str1 = ""; 
        f f = H.a(z4());
        SearchParams searchParams = new SearchParams(str1, DropboxPath.d, f, "", true);
        startActivity(SearchActivity.x4((Context)this, searchParams, e.FILES, B4(searchParams.g())));
      } 
    } 
    finish();
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\android\activity\VoiceActionsActivity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */