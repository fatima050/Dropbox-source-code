package com.dropbox.android.activity.login;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import com.dropbox.android.accounts.login.api.DbAppAccount;
import com.dropbox.android.filemanager.ApiManager;
import com.dropbox.android.user.DbxUserManager;
import com.dropbox.common.auth.login.api.AuthLaunchSource;
import com.dropbox.dbapp.auth.api.LoginSurface;
import com.squareup.anvil.annotations.ContributesMultibinding;
import dbxyzptlk.CI.p;
import dbxyzptlk.DI.s;
import dbxyzptlk.DI.u;
import dbxyzptlk.Jh.d;
import dbxyzptlk.U2.v;
import dbxyzptlk.U2.w;
import dbxyzptlk.bK.J;
import dbxyzptlk.bK.J0;
import dbxyzptlk.bK.w0;
import dbxyzptlk.ch.m;
import dbxyzptlk.dk.H;
import dbxyzptlk.eK.B;
import dbxyzptlk.eK.G;
import dbxyzptlk.eK.I;
import dbxyzptlk.lf.k;
import dbxyzptlk.pI.D;
import dbxyzptlk.pI.j;
import dbxyzptlk.pI.k;
import dbxyzptlk.pI.p;
import dbxyzptlk.pc.d0;
import dbxyzptlk.tI.g;
import dbxyzptlk.vI.l;
import dbxyzptlk.ye.c0;
import kotlin.Metadata;

@ContributesMultibinding(scope = d.class)
@Metadata(d1 = {"\000¼\001\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\030\002\n\000\n\002\030\002\n\002\b\004\n\002\020\016\n\000\n\002\020\013\n\002\b\003\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\b\n\002\030\002\n\002\b\036\n\002\030\002\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\b\n\002\030\002\n\002\b \n\002\030\002\n\002\b\007\n\002\030\002\n\002\b\n\b\007\030\0002\0020\001:\004\001\001Bq\b\007\022\f\020\004\032\b\022\004\022\0020\0030\002\022\006\020\006\032\0020\005\022\006\020\b\032\0020\007\022\006\020\n\032\0020\t\022\006\020\f\032\0020\013\022\006\020\016\032\0020\r\022\006\020\020\032\0020\017\022\006\020\022\032\0020\021\022\b\b\001\020\024\032\0020\023\022\006\020\026\032\0020\025\022\006\020\030\032\0020\027\022\006\020\032\032\0020\031¢\006\004\b\033\020\034J\030\020 \032\0020\0372\006\020\036\032\0020\035H@¢\006\004\b \020!J\017\020\"\032\0020\037H\002¢\006\004\b\"\020#J\037\020(\032\0020\0372\006\020%\032\0020$2\006\020'\032\0020&H\002¢\006\004\b(\020)J\037\020-\032\0020,2\006\020+\032\0020*2\b\020\036\032\004\030\0010\035¢\006\004\b-\020.J\025\0201\032\0020,2\006\0200\032\0020/¢\006\004\b1\0202J\030\0204\032\0020\0372\006\0203\032\0020&H@¢\006\004\b4\0205J\030\0206\032\0020\0372\006\020+\032\0020*H@¢\006\004\b6\0207J\031\020:\032\0020,2\b\0209\032\004\030\00108H\000¢\006\004\b:\020;J\r\020<\032\0020&¢\006\004\b<\020=J\r\020>\032\0020&¢\006\004\b>\020=J\027\020?\032\0020&2\b\020+\032\004\030\0010*¢\006\004\b?\020@R\032\020\004\032\b\022\004\022\0020\0030\0028\002X\004¢\006\006\n\004\bA\020BR\024\020\006\032\0020\0058\002X\004¢\006\006\n\004\bC\020DR\024\020\b\032\0020\0078\002X\004¢\006\006\n\004\bE\020FR\024\020\n\032\0020\t8\002X\004¢\006\006\n\004\bG\020HR\024\020\f\032\0020\0138\002X\004¢\006\006\n\004\bI\020JR\024\020\016\032\0020\r8\002X\004¢\006\006\n\004\bK\020LR\024\020\020\032\0020\0178\002X\004¢\006\006\n\004\bM\020NR\024\020\022\032\0020\0218\002X\004¢\006\006\n\004\bO\020PR\024\020\026\032\0020\0258\002X\004¢\006\006\n\004\bQ\020RR\024\020\030\032\0020\0278\002X\004¢\006\006\n\004\bS\020TR\024\020\032\032\0020\0318\002X\004¢\006\006\n\004\bU\020VR\032\020[\032\b\022\004\022\0020X0W8\002X\004¢\006\006\n\004\bY\020ZR\035\020a\032\b\022\004\022\0020X0\\8\006¢\006\f\n\004\b]\020^\032\004\b_\020`R\024\020d\032\0020&8\002X\004¢\006\006\n\004\bb\020cR$\020l\032\004\030\0010e8\006@\006X\016¢\006\022\n\004\bf\020g\032\004\bh\020i\"\004\bj\020kR$\020s\032\004\030\0010*8\006@\006X\016¢\006\022\n\004\bm\020n\032\004\bo\020p\"\004\bq\020rR$\020y\032\004\030\0010$8\006@\006X\016¢\006\022\n\004\bt\020u\032\004\bc\020v\"\004\bw\020xR$\020}\032\004\030\0010$8\006@\006X\016¢\006\022\n\004\bz\020u\032\004\b{\020v\"\004\b|\020xR&\020\001\032\004\030\0010$8\006@\006X\016¢\006\023\n\004\b~\020u\032\004\b\020v\"\005\b\001\020xR\037\020\001\032\0020&8FX\002¢\006\017\n\006\b\001\020\001\032\005\b\001\020=R*\020\001\032\0030\0018\006@\006X\016¢\006\030\n\006\b\001\020\001\032\006\b\001\020\001\"\006\b\001\020\001R*\020\001\032\0030\0018\006@\006X\016¢\006\030\n\006\b\001\020\001\032\006\b\001\020\001\"\006\b\001\020\001¨\006\001"}, d2 = {"Lcom/dropbox/android/activity/login/b;", "Ldbxyzptlk/U2/v;", "Ldbxyzptlk/Pe/a;", "Lcom/dropbox/android/accounts/login/api/DbAppAccount;", "accountMakerInteractor", "Ldbxyzptlk/yj/a;", "appInfoProvider", "Lcom/dropbox/android/filemanager/ApiManager;", "apiManager", "Lcom/dropbox/android/user/DbxUserManager;", "userManager", "Ldbxyzptlk/lf/k;", "emmHelper", "Ldbxyzptlk/Ve/b;", "accountSelectionContract", "Ldbxyzptlk/Tf/a;", "loginLauncher", "Landroid/content/res/Resources;", "resources", "Landroid/content/Context;", "context", "Ldbxyzptlk/C8/b;", "dealsInvestigationLogger", "Ldbxyzptlk/Dn/a;", "susiBeforePreviewFeatureGate", "Ldbxyzptlk/ch/m;", "dispatchers", "<init>", "(Ldbxyzptlk/Pe/a;Ldbxyzptlk/yj/a;Lcom/dropbox/android/filemanager/ApiManager;Lcom/dropbox/android/user/DbxUserManager;Ldbxyzptlk/lf/k;Ldbxyzptlk/Ve/b;Ldbxyzptlk/Tf/a;Landroid/content/res/Resources;Landroid/content/Context;Ldbxyzptlk/C8/b;Ldbxyzptlk/Dn/a;Ldbxyzptlk/ch/m;)V", "Landroid/os/Bundle;", "savedInstanceState", "Ldbxyzptlk/pI/D;", "e0", "(Landroid/os/Bundle;Ldbxyzptlk/tI/d;)Ljava/lang/Object;", "m0", "()V", "", "userId", "", "isNewAccount", "j0", "(Ljava/lang/String;Z)V", "Landroid/content/Intent;", "intent", "Ldbxyzptlk/bK/w0;", "f0", "(Landroid/content/Intent;Landroid/os/Bundle;)Ldbxyzptlk/bK/w0;", "Lcom/dropbox/android/activity/login/b$a;", "event", "h0", "(Lcom/dropbox/android/activity/login/b$a;)Ldbxyzptlk/bK/w0;", "initialSetup", "i0", "(ZLdbxyzptlk/tI/d;)Ljava/lang/Object;", "d0", "(Landroid/content/Intent;Ldbxyzptlk/tI/d;)Ljava/lang/Object;", "Lcom/dropbox/android/user/a;", "users", "c0", "(Lcom/dropbox/android/user/a;)Ldbxyzptlk/bK/w0;", "g0", "()Z", "l0", "k0", "(Landroid/content/Intent;)Z", "c", "Ldbxyzptlk/Pe/a;", "d", "Ldbxyzptlk/yj/a;", "e", "Lcom/dropbox/android/filemanager/ApiManager;", "f", "Lcom/dropbox/android/user/DbxUserManager;", "g", "Ldbxyzptlk/lf/k;", "h", "Ldbxyzptlk/Ve/b;", "i", "Ldbxyzptlk/Tf/a;", "j", "Landroid/content/res/Resources;", "k", "Ldbxyzptlk/C8/b;", "l", "Ldbxyzptlk/Dn/a;", "m", "Ldbxyzptlk/ch/m;", "Ldbxyzptlk/eK/B;", "Lcom/dropbox/android/activity/login/b$b;", "n", "Ldbxyzptlk/eK/B;", "_viewState", "Ldbxyzptlk/eK/G;", "o", "Ldbxyzptlk/eK/G;", "b0", "()Ldbxyzptlk/eK/G;", "viewState", "p", "Z", "isChromeOS", "Ldbxyzptlk/Ee/a$f;", "q", "Ldbxyzptlk/Ee/a$f;", "a0", "()Ldbxyzptlk/Ee/a$f;", "setUsersetListenerRegistration", "(Ldbxyzptlk/Ee/a$f;)V", "usersetListenerRegistration", "r", "Landroid/content/Intent;", "X", "()Landroid/content/Intent;", "setNextIntent", "(Landroid/content/Intent;)V", "nextIntent", "s", "Ljava/lang/String;", "()Ljava/lang/String;", "setStartingScreen", "(Ljava/lang/String;)V", "startingScreen", "t", "U", "setEmailPrefill", "emailPrefill", "u", "V", "setExpectedUserPairUserId", "expectedUserPairUserId", "v", "Ldbxyzptlk/pI/j;", "Y", "showSignupSignInBottomSheet", "Lcom/dropbox/dbapp/auth/api/LoginSurface;", "w", "Lcom/dropbox/dbapp/auth/api/LoginSurface;", "W", "()Lcom/dropbox/dbapp/auth/api/LoginSurface;", "setLoginSurface", "(Lcom/dropbox/dbapp/auth/api/LoginSurface;)V", "loginSurface", "Lcom/dropbox/common/auth/login/api/AuthLaunchSource;", "x", "Lcom/dropbox/common/auth/login/api/AuthLaunchSource;", "T", "()Lcom/dropbox/common/auth/login/api/AuthLaunchSource;", "setAuthLaunchSource", "(Lcom/dropbox/common/auth/login/api/AuthLaunchSource;)V", "authLaunchSource", "a", "b", "Dropbox_normalRelease"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class b extends v {
  public final dbxyzptlk.Pe.a<DbAppAccount> c;
  
  public final dbxyzptlk.yj.a d;
  
  public final ApiManager e;
  
  public final DbxUserManager f;
  
  public final k g;
  
  public final dbxyzptlk.Ve.b h;
  
  public final dbxyzptlk.Tf.a i;
  
  public final Resources j;
  
  public final dbxyzptlk.C8.b k;
  
  public final dbxyzptlk.Dn.a l;
  
  public final m m;
  
  public final B<b> n;
  
  public final G<b> o;
  
  public final boolean p;
  
  public dbxyzptlk.Ee.a.f q;
  
  public Intent r;
  
  public String s;
  
  public String t;
  
  public String u;
  
  public final j v;
  
  public LoginSurface w;
  
  public AuthLaunchSource x;
  
  public b(dbxyzptlk.Pe.a<DbAppAccount> parama, dbxyzptlk.yj.a parama1, ApiManager paramApiManager, DbxUserManager paramDbxUserManager, k paramk, dbxyzptlk.Ve.b paramb, dbxyzptlk.Tf.a parama2, Resources paramResources, Context paramContext, dbxyzptlk.C8.b paramb1, dbxyzptlk.Dn.a parama3, m paramm) {
    this.c = parama;
    this.d = parama1;
    this.e = paramApiManager;
    this.f = paramDbxUserManager;
    this.g = paramk;
    this.h = paramb;
    this.i = parama2;
    this.j = paramResources;
    this.k = paramb1;
    this.l = parama3;
    this.m = paramm;
    B<b> b1 = I.b(0, 0, null, 7, null);
    this.n = b1;
    this.o = (G<b>)b1;
    this.p = ((Boolean)c0.a.c().invoke(paramContext)).booleanValue();
    this.v = k.a(new i(this));
    this.w = (LoginSurface)LoginSurface.Default.a;
    this.x = (AuthLaunchSource)AuthLaunchSource.Organic.a;
  }
  
  public static final void n0(b paramb, com.dropbox.android.user.a parama) {
    s.h(paramb, "this$0");
    paramb.c0(parama);
  }
  
  public final AuthLaunchSource T() {
    return this.x;
  }
  
  public final String U() {
    return this.t;
  }
  
  public final String V() {
    return this.u;
  }
  
  public final LoginSurface W() {
    return this.w;
  }
  
  public final Intent X() {
    return this.r;
  }
  
  public final boolean Y() {
    return ((Boolean)this.v.getValue()).booleanValue();
  }
  
  public final String Z() {
    return this.s;
  }
  
  public final dbxyzptlk.Ee.a.f a0() {
    return this.q;
  }
  
  public final G<b> b0() {
    return this.o;
  }
  
  public final w0 c0(com.dropbox.android.user.a parama) {
    return dbxyzptlk.bK.h.d(w.a((v)this), null, null, new c(parama, this, null), 3, null);
  }
  
  public final Object d0(Intent paramIntent, dbxyzptlk.tI.d<? super D> paramd) {
    Intent intent = (Intent)dbxyzptlk.V1.c.b(paramIntent, "com.dropbox.activity.extra.NEXT_INTENT", Intent.class);
    if (intent != null)
      this.r = intent; 
    LoginSurface loginSurface = (LoginSurface)dbxyzptlk.V1.c.b(paramIntent, "com.dropbox.activity.extra.LOGIN_SURFACE", LoginSurface.class);
    if (loginSurface != null)
      this.w = loginSurface; 
    AuthLaunchSource authLaunchSource = (AuthLaunchSource)dbxyzptlk.V1.c.b(paramIntent, "com.dropbox.activity.extra.EXTRA_LAUNCH_SOURCE", AuthLaunchSource.class);
    if (authLaunchSource != null)
      this.x = authLaunchSource; 
    this.s = paramIntent.getAction();
    if (paramIntent.getBooleanExtra("EXTRA_LAUNCH_LOGIN", false)) {
      Object object1 = this.n.c(new b.d(paramIntent.getData()), paramd);
      return (object1 == dbxyzptlk.uI.c.g()) ? object1 : D.a;
    } 
    Object object = this.n.c(b.f.a, paramd);
    return (object == dbxyzptlk.uI.c.g()) ? object : D.a;
  }
  
  public final Object e0(Bundle paramBundle, dbxyzptlk.tI.d<? super D> paramd) {
    if (paramBundle.containsKey("SIS_KEY_NEXT_INTENT"))
      this.r = (Intent)H.d(paramBundle, "SIS_KEY_NEXT_INTENT", Intent.class); 
    if (paramBundle.containsKey("SIS_KEY_LOGIN_SURFACE")) {
      LoginSurface.Default default_;
      LoginSurface loginSurface2 = (LoginSurface)H.d(paramBundle, "SIS_KEY_LOGIN_SURFACE", LoginSurface.class);
      LoginSurface loginSurface1 = loginSurface2;
      if (loginSurface2 == null)
        default_ = LoginSurface.Default.a; 
      this.w = (LoginSurface)default_;
    } 
    if (paramBundle.containsKey("SIS_KEY_AUTH_LAUNCH_SOURCE")) {
      AuthLaunchSource.Organic organic;
      AuthLaunchSource authLaunchSource2 = (AuthLaunchSource)H.d(paramBundle, "SIS_KEY_AUTH_LAUNCH_SOURCE", AuthLaunchSource.class);
      AuthLaunchSource authLaunchSource1 = authLaunchSource2;
      if (authLaunchSource2 == null)
        organic = AuthLaunchSource.Organic.a; 
      this.x = (AuthLaunchSource)organic;
    } 
    this.s = paramBundle.getString("SIS_KEY_INTENT_ACTION", null);
    if (paramBundle.getBoolean("SIS_SHOW_BLOCKING_DIALOG", false)) {
      paramBundle.putBoolean("SIS_SHOW_BLOCKING_DIALOG", false);
      Object object = this.n.c(b.e.a, paramd);
      return (object == dbxyzptlk.uI.c.g()) ? object : D.a;
    } 
    return D.a;
  }
  
  public final w0 f0(Intent paramIntent, Bundle paramBundle) {
    s.h(paramIntent, "intent");
    return dbxyzptlk.bK.h.d(w.a((v)this), null, null, new d(paramBundle, this, paramIntent, null), 3, null);
  }
  
  public final boolean g0() {
    return (s.c("com.dropbox.intent.action.DROPBOX_LOGIN_SECOND_ACCOUNT", this.s) || this.u != null);
  }
  
  public final w0 h0(a parama) {
    s.h(parama, "event");
    return dbxyzptlk.bK.h.d(w.a((v)this), null, null, (p)new e(parama, this, null), 3, null);
  }
  
  public final Object i0(boolean paramBoolean, dbxyzptlk.tI.d<? super D> paramd) {
    // Byte code:
    //   0: aload_2
    //   1: instanceof com/dropbox/android/activity/login/b$f
    //   4: ifeq -> 43
    //   7: aload_2
    //   8: checkcast com/dropbox/android/activity/login/b$f
    //   11: astore #4
    //   13: aload #4
    //   15: getfield x : I
    //   18: istore_3
    //   19: iload_3
    //   20: ldc_w -2147483648
    //   23: iand
    //   24: ifeq -> 43
    //   27: aload #4
    //   29: iload_3
    //   30: ldc_w -2147483648
    //   33: iadd
    //   34: putfield x : I
    //   37: aload #4
    //   39: astore_2
    //   40: goto -> 53
    //   43: new com/dropbox/android/activity/login/b$f
    //   46: dup
    //   47: aload_0
    //   48: aload_2
    //   49: invokespecial <init> : (Lcom/dropbox/android/activity/login/b;Ldbxyzptlk/tI/d;)V
    //   52: astore_2
    //   53: aload_2
    //   54: getfield v : Ljava/lang/Object;
    //   57: astore #6
    //   59: invokestatic g : ()Ljava/lang/Object;
    //   62: astore #5
    //   64: aload_2
    //   65: getfield x : I
    //   68: istore_3
    //   69: iload_3
    //   70: ifeq -> 124
    //   73: iload_3
    //   74: iconst_1
    //   75: if_icmpeq -> 102
    //   78: iload_3
    //   79: iconst_2
    //   80: if_icmpne -> 91
    //   83: aload #6
    //   85: invokestatic b : (Ljava/lang/Object;)V
    //   88: goto -> 397
    //   91: new java/lang/IllegalStateException
    //   94: dup
    //   95: ldc_w 'call to 'resume' before 'invoke' with coroutine'
    //   98: invokespecial <init> : (Ljava/lang/String;)V
    //   101: athrow
    //   102: aload_2
    //   103: getfield u : Z
    //   106: istore_1
    //   107: aload_2
    //   108: getfield t : Ljava/lang/Object;
    //   111: checkcast com/dropbox/android/activity/login/b
    //   114: astore #4
    //   116: aload #6
    //   118: invokestatic b : (Ljava/lang/Object;)V
    //   121: goto -> 338
    //   124: aload #6
    //   126: invokestatic b : (Ljava/lang/Object;)V
    //   129: aload_0
    //   130: invokevirtual g0 : ()Z
    //   133: ifeq -> 335
    //   136: aload_0
    //   137: getfield f : Lcom/dropbox/android/user/DbxUserManager;
    //   140: invokeinterface a : ()Lcom/dropbox/android/user/a;
    //   145: astore #6
    //   147: aload #6
    //   149: ifnull -> 335
    //   152: aload #6
    //   154: invokevirtual t : ()Z
    //   157: ifne -> 335
    //   160: aload #6
    //   162: invokevirtual o : ()Ldbxyzptlk/pc/d0;
    //   165: astore #4
    //   167: aload #4
    //   169: ldc_w 'getSingleUser(...)'
    //   172: invokestatic g : (Ljava/lang/Object;Ljava/lang/String;)V
    //   175: aload #6
    //   177: invokevirtual l : ()Lcom/dropbox/android/user/a$b;
    //   180: astore #6
    //   182: aload #6
    //   184: ifnonnull -> 244
    //   187: getstatic dbxyzptlk/sL/a.a : Ldbxyzptlk/sL/a$b;
    //   190: ldc_w 'Can't log in a second user: no pairing info found'
    //   193: iconst_0
    //   194: anewarray java/lang/Object
    //   197: invokevirtual a : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   200: aload_0
    //   201: getfield n : Ldbxyzptlk/eK/B;
    //   204: astore #4
    //   206: getstatic com/dropbox/android/activity/login/b$b$a.a : Lcom/dropbox/android/activity/login/b$b$a;
    //   209: astore #6
    //   211: aload_2
    //   212: aload_0
    //   213: putfield t : Ljava/lang/Object;
    //   216: aload_2
    //   217: iload_1
    //   218: putfield u : Z
    //   221: aload_2
    //   222: iconst_1
    //   223: putfield x : I
    //   226: aload #4
    //   228: aload #6
    //   230: aload_2
    //   231: invokeinterface c : (Ljava/lang/Object;Ldbxyzptlk/tI/d;)Ljava/lang/Object;
    //   236: aload #5
    //   238: if_acmpne -> 335
    //   241: aload #5
    //   243: areturn
    //   244: iconst_2
    //   245: anewarray dbxyzptlk/qc/A
    //   248: dup
    //   249: iconst_0
    //   250: aload #6
    //   252: invokevirtual d : ()Ldbxyzptlk/qc/A;
    //   255: aastore
    //   256: dup
    //   257: iconst_1
    //   258: aload #6
    //   260: invokevirtual f : ()Ldbxyzptlk/qc/A;
    //   263: aastore
    //   264: invokestatic p : ([Ljava/lang/Object;)Ljava/util/List;
    //   267: invokeinterface iterator : ()Ljava/util/Iterator;
    //   272: astore #7
    //   274: aload #7
    //   276: invokeinterface hasNext : ()Z
    //   281: ifeq -> 335
    //   284: aload #7
    //   286: invokeinterface next : ()Ljava/lang/Object;
    //   291: checkcast dbxyzptlk/qc/A
    //   294: astore #6
    //   296: aload #6
    //   298: invokevirtual f0 : ()Ljava/lang/String;
    //   301: aload #4
    //   303: invokeinterface getId : ()Ljava/lang/String;
    //   308: invokestatic c : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   311: ifne -> 274
    //   314: aload_0
    //   315: aload #6
    //   317: invokevirtual d0 : ()Ljava/lang/String;
    //   320: putfield t : Ljava/lang/String;
    //   323: aload_0
    //   324: aload #6
    //   326: invokevirtual f0 : ()Ljava/lang/String;
    //   329: putfield u : Ljava/lang/String;
    //   332: goto -> 274
    //   335: aload_0
    //   336: astore #4
    //   338: iload_1
    //   339: ifeq -> 401
    //   342: aload #4
    //   344: invokevirtual g0 : ()Z
    //   347: ifeq -> 401
    //   350: aload #4
    //   352: getfield n : Ldbxyzptlk/eK/B;
    //   355: astore #4
    //   357: new com/dropbox/android/activity/login/b$b$d
    //   360: dup
    //   361: aconst_null
    //   362: iconst_1
    //   363: aconst_null
    //   364: invokespecial <init> : (Landroid/net/Uri;ILkotlin/jvm/internal/DefaultConstructorMarker;)V
    //   367: astore #6
    //   369: aload_2
    //   370: aconst_null
    //   371: putfield t : Ljava/lang/Object;
    //   374: aload_2
    //   375: iconst_2
    //   376: putfield x : I
    //   379: aload #4
    //   381: aload #6
    //   383: aload_2
    //   384: invokeinterface c : (Ljava/lang/Object;Ldbxyzptlk/tI/d;)Ljava/lang/Object;
    //   389: aload #5
    //   391: if_acmpne -> 397
    //   394: aload #5
    //   396: areturn
    //   397: getstatic dbxyzptlk/pI/D.a : Ldbxyzptlk/pI/D;
    //   400: areturn
    //   401: getstatic dbxyzptlk/pI/D.a : Ldbxyzptlk/pI/D;
    //   404: areturn
  }
  
  public final void j0(String paramString, boolean paramBoolean) {
    dbxyzptlk.bK.h.d(w.a((v)this), this.m.b().s((g)J0.b), null, (p)new g(this, paramString, paramBoolean, null), 2, null);
  }
  
  public final boolean k0(Intent paramIntent) {
    boolean bool1;
    boolean bool3 = false;
    if (paramIntent != null) {
      bool2 = paramIntent.getBooleanExtra("EXTRA_LAUNCH_LOGIN", false);
    } else {
      bool2 = false;
    } 
    if (!bool2 && !g0()) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    if (bool1 && this.p)
      this.k.c(); 
    boolean bool2 = bool3;
    if (bool1) {
      bool2 = bool3;
      if (!this.p)
        bool2 = true; 
    } 
    return bool2;
  }
  
  public final boolean l0() {
    boolean bool;
    if (g0()) {
      bool = false;
    } else {
      bool = ((Boolean)dbxyzptlk.bK.h.f(null, (p)new h(this, null), 1, null)).booleanValue();
    } 
    return bool;
  }
  
  public final void m0() {
    this.q = this.f.l((DbxUserManager.f)new dbxyzptlk.I6.e(this));
    c0(this.f.a());
  }
  
  class b {}
  
  @Metadata(d1 = {"\000.\n\002\030\002\n\002\020\000\n\002\b\b\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\000\bv\030\0002\0020\001:\b\002\003\004\005\006\007\b\t\001\b\n\013\f\r\016\017\020\021ø\001\000\002\006\n\004\b!0\001¨\006\022À\006\001"}, d2 = {"Lcom/dropbox/android/activity/login/b$b;", "", "a", "b", "c", "d", "e", "f", "g", "h", "Lcom/dropbox/android/activity/login/b$b$a;", "Lcom/dropbox/android/activity/login/b$b$b;", "Lcom/dropbox/android/activity/login/b$b$c;", "Lcom/dropbox/android/activity/login/b$b$d;", "Lcom/dropbox/android/activity/login/b$b$e;", "Lcom/dropbox/android/activity/login/b$b$f;", "Lcom/dropbox/android/activity/login/b$b$g;", "Lcom/dropbox/android/activity/login/b$b$h;", "Dropbox_normalRelease"}, k = 1, mv = {1, 9, 0}, xi = 48)
  public static interface b {
    @Metadata(d1 = {"\000*\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\016\n\002\b\002\n\002\020\b\n\002\b\002\n\002\020\000\n\000\n\002\020\013\n\002\b\003\bÇ\n\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\020\020\005\032\0020\004HÖ\001¢\006\004\b\005\020\006J\020\020\b\032\0020\007HÖ\001¢\006\004\b\b\020\tJ\032\020\r\032\0020\f2\b\020\013\032\004\030\0010\nHÖ\003¢\006\004\b\r\020\016¨\006\017"}, d2 = {"Lcom/dropbox/android/activity/login/b$b$a;", "Lcom/dropbox/android/activity/login/b$b;", "<init>", "()V", "", "toString", "()Ljava/lang/String;", "", "hashCode", "()I", "", "other", "", "equals", "(Ljava/lang/Object;)Z", "Dropbox_normalRelease"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class a implements b {
      public static final a a = new a();
      
      public boolean equals(Object param2Object) {
        return (this == param2Object) ? true : (!!(param2Object instanceof a));
      }
      
      public int hashCode() {
        return -1344146865;
      }
      
      public String toString() {
        return "CancelAndFinish";
      }
    }
    
    @Metadata(d1 = {"\000*\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\016\n\002\b\002\n\002\020\b\n\002\b\002\n\002\020\000\n\000\n\002\020\013\n\002\b\003\bÇ\n\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\020\020\005\032\0020\004HÖ\001¢\006\004\b\005\020\006J\020\020\b\032\0020\007HÖ\001¢\006\004\b\b\020\tJ\032\020\r\032\0020\f2\b\020\013\032\004\030\0010\nHÖ\003¢\006\004\b\r\020\016¨\006\017"}, d2 = {"Lcom/dropbox/android/activity/login/b$b$b;", "Lcom/dropbox/android/activity/login/b$b;", "<init>", "()V", "", "toString", "()Ljava/lang/String;", "", "hashCode", "()I", "", "other", "", "equals", "(Ljava/lang/Object;)Z", "Dropbox_normalRelease"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class b implements b {
      public static final b a = new b();
      
      public boolean equals(Object param2Object) {
        return (this == param2Object) ? true : (!!(param2Object instanceof b));
      }
      
      public int hashCode() {
        return 1251049802;
      }
      
      public String toString() {
        return "DismissBlockingScreen";
      }
    }
    
    class b {}
    
    class b {}
    
    @Metadata(d1 = {"\000*\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\016\n\002\b\002\n\002\020\b\n\002\b\002\n\002\020\000\n\000\n\002\020\013\n\002\b\003\bÇ\n\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\020\020\005\032\0020\004HÖ\001¢\006\004\b\005\020\006J\020\020\b\032\0020\007HÖ\001¢\006\004\b\b\020\tJ\032\020\r\032\0020\f2\b\020\013\032\004\030\0010\nHÖ\003¢\006\004\b\r\020\016¨\006\017"}, d2 = {"Lcom/dropbox/android/activity/login/b$b$e;", "Lcom/dropbox/android/activity/login/b$b;", "<init>", "()V", "", "toString", "()Ljava/lang/String;", "", "hashCode", "()I", "", "other", "", "equals", "(Ljava/lang/Object;)Z", "Dropbox_normalRelease"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class e implements b {
      public static final e a = new e();
      
      public boolean equals(Object param2Object) {
        return (this == param2Object) ? true : (!!(param2Object instanceof e));
      }
      
      public int hashCode() {
        return -2013982049;
      }
      
      public String toString() {
        return "ShowBlockingScreen";
      }
    }
    
    @Metadata(d1 = {"\000*\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\016\n\002\b\002\n\002\020\b\n\002\b\002\n\002\020\000\n\000\n\002\020\013\n\002\b\003\bÇ\n\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\020\020\005\032\0020\004HÖ\001¢\006\004\b\005\020\006J\020\020\b\032\0020\007HÖ\001¢\006\004\b\b\020\tJ\032\020\r\032\0020\f2\b\020\013\032\004\030\0010\nHÖ\003¢\006\004\b\r\020\016¨\006\017"}, d2 = {"Lcom/dropbox/android/activity/login/b$b$f;", "Lcom/dropbox/android/activity/login/b$b;", "<init>", "()V", "", "toString", "()Ljava/lang/String;", "", "hashCode", "()I", "", "other", "", "equals", "(Ljava/lang/Object;)Z", "Dropbox_normalRelease"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class f implements b {
      public static final f a = new f();
      
      public boolean equals(Object param2Object) {
        return (this == param2Object) ? true : (!!(param2Object instanceof f));
      }
      
      public int hashCode() {
        return -721899261;
      }
      
      public String toString() {
        return "ShowLoginTour";
      }
    }
    
    class b {}
    
    @Metadata(d1 = {"\000*\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\016\n\002\b\002\n\002\020\b\n\002\b\002\n\002\020\000\n\000\n\002\020\013\n\002\b\003\bÇ\n\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\020\020\005\032\0020\004HÖ\001¢\006\004\b\005\020\006J\020\020\b\032\0020\007HÖ\001¢\006\004\b\b\020\tJ\032\020\r\032\0020\f2\b\020\013\032\004\030\0010\nHÖ\003¢\006\004\b\r\020\016¨\006\017"}, d2 = {"Lcom/dropbox/android/activity/login/b$b$h;", "Lcom/dropbox/android/activity/login/b$b;", "<init>", "()V", "", "toString", "()Ljava/lang/String;", "", "hashCode", "()I", "", "other", "", "equals", "(Ljava/lang/Object;)Z", "Dropbox_normalRelease"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class h implements b {
      public static final h a = new h();
      
      public boolean equals(Object param2Object) {
        return (this == param2Object) ? true : (!!(param2Object instanceof h));
      }
      
      public int hashCode() {
        return -548793240;
      }
      
      public String toString() {
        return "ZeroState";
      }
    }
  }
  
  @Metadata(d1 = {"\000*\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\016\n\002\b\002\n\002\020\b\n\002\b\002\n\002\020\000\n\000\n\002\020\013\n\002\b\003\bÇ\n\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\020\020\005\032\0020\004HÖ\001¢\006\004\b\005\020\006J\020\020\b\032\0020\007HÖ\001¢\006\004\b\b\020\tJ\032\020\r\032\0020\f2\b\020\013\032\004\030\0010\nHÖ\003¢\006\004\b\r\020\016¨\006\017"}, d2 = {"Lcom/dropbox/android/activity/login/b$b$a;", "Lcom/dropbox/android/activity/login/b$b;", "<init>", "()V", "", "toString", "()Ljava/lang/String;", "", "hashCode", "()I", "", "other", "", "equals", "(Ljava/lang/Object;)Z", "Dropbox_normalRelease"}, k = 1, mv = {1, 9, 0}, xi = 48)
  public static final class a implements b {
    public static final a a = new a();
    
    public boolean equals(Object param1Object) {
      return (this == param1Object) ? true : (!!(param1Object instanceof a));
    }
    
    public int hashCode() {
      return -1344146865;
    }
    
    public String toString() {
      return "CancelAndFinish";
    }
  }
  
  @Metadata(d1 = {"\000*\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\016\n\002\b\002\n\002\020\b\n\002\b\002\n\002\020\000\n\000\n\002\020\013\n\002\b\003\bÇ\n\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\020\020\005\032\0020\004HÖ\001¢\006\004\b\005\020\006J\020\020\b\032\0020\007HÖ\001¢\006\004\b\b\020\tJ\032\020\r\032\0020\f2\b\020\013\032\004\030\0010\nHÖ\003¢\006\004\b\r\020\016¨\006\017"}, d2 = {"Lcom/dropbox/android/activity/login/b$b$b;", "Lcom/dropbox/android/activity/login/b$b;", "<init>", "()V", "", "toString", "()Ljava/lang/String;", "", "hashCode", "()I", "", "other", "", "equals", "(Ljava/lang/Object;)Z", "Dropbox_normalRelease"}, k = 1, mv = {1, 9, 0}, xi = 48)
  public static final class b implements b {
    public static final b a = new b();
    
    public boolean equals(Object param1Object) {
      return (this == param1Object) ? true : (!!(param1Object instanceof b));
    }
    
    public int hashCode() {
      return 1251049802;
    }
    
    public String toString() {
      return "DismissBlockingScreen";
    }
  }
  
  class b {}
  
  class b {}
  
  @Metadata(d1 = {"\000*\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\016\n\002\b\002\n\002\020\b\n\002\b\002\n\002\020\000\n\000\n\002\020\013\n\002\b\003\bÇ\n\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\020\020\005\032\0020\004HÖ\001¢\006\004\b\005\020\006J\020\020\b\032\0020\007HÖ\001¢\006\004\b\b\020\tJ\032\020\r\032\0020\f2\b\020\013\032\004\030\0010\nHÖ\003¢\006\004\b\r\020\016¨\006\017"}, d2 = {"Lcom/dropbox/android/activity/login/b$b$e;", "Lcom/dropbox/android/activity/login/b$b;", "<init>", "()V", "", "toString", "()Ljava/lang/String;", "", "hashCode", "()I", "", "other", "", "equals", "(Ljava/lang/Object;)Z", "Dropbox_normalRelease"}, k = 1, mv = {1, 9, 0}, xi = 48)
  public static final class e implements b {
    public static final e a = new e();
    
    public boolean equals(Object param1Object) {
      return (this == param1Object) ? true : (!!(param1Object instanceof e));
    }
    
    public int hashCode() {
      return -2013982049;
    }
    
    public String toString() {
      return "ShowBlockingScreen";
    }
  }
  
  @Metadata(d1 = {"\000*\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\016\n\002\b\002\n\002\020\b\n\002\b\002\n\002\020\000\n\000\n\002\020\013\n\002\b\003\bÇ\n\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\020\020\005\032\0020\004HÖ\001¢\006\004\b\005\020\006J\020\020\b\032\0020\007HÖ\001¢\006\004\b\b\020\tJ\032\020\r\032\0020\f2\b\020\013\032\004\030\0010\nHÖ\003¢\006\004\b\r\020\016¨\006\017"}, d2 = {"Lcom/dropbox/android/activity/login/b$b$f;", "Lcom/dropbox/android/activity/login/b$b;", "<init>", "()V", "", "toString", "()Ljava/lang/String;", "", "hashCode", "()I", "", "other", "", "equals", "(Ljava/lang/Object;)Z", "Dropbox_normalRelease"}, k = 1, mv = {1, 9, 0}, xi = 48)
  public static final class f implements b {
    public static final f a = new f();
    
    public boolean equals(Object param1Object) {
      return (this == param1Object) ? true : (!!(param1Object instanceof f));
    }
    
    public int hashCode() {
      return -721899261;
    }
    
    public String toString() {
      return "ShowLoginTour";
    }
  }
  
  class b {}
  
  @Metadata(d1 = {"\000*\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\016\n\002\b\002\n\002\020\b\n\002\b\002\n\002\020\000\n\000\n\002\020\013\n\002\b\003\bÇ\n\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\020\020\005\032\0020\004HÖ\001¢\006\004\b\005\020\006J\020\020\b\032\0020\007HÖ\001¢\006\004\b\b\020\tJ\032\020\r\032\0020\f2\b\020\013\032\004\030\0010\nHÖ\003¢\006\004\b\r\020\016¨\006\017"}, d2 = {"Lcom/dropbox/android/activity/login/b$b$h;", "Lcom/dropbox/android/activity/login/b$b;", "<init>", "()V", "", "toString", "()Ljava/lang/String;", "", "hashCode", "()I", "", "other", "", "equals", "(Ljava/lang/Object;)Z", "Dropbox_normalRelease"}, k = 1, mv = {1, 9, 0}, xi = 48)
  public static final class h implements b {
    public static final h a = new h();
    
    public boolean equals(Object param1Object) {
      return (this == param1Object) ? true : (!!(param1Object instanceof h));
    }
    
    public int hashCode() {
      return -548793240;
    }
    
    public String toString() {
      return "ZeroState";
    }
  }
  
  @dbxyzptlk.vI.f(c = "com.dropbox.android.activity.login.DbxLoginViewModel$handleNewUserset$1", f = "DbxLoginViewModel.kt", l = {230, 232, 236, 240}, m = "invokeSuspend")
  @Metadata(d1 = {"\000\f\n\002\030\002\n\002\030\002\n\002\b\002\020\002\032\0020\001*\0020\000H@¢\006\004\b\002\020\003"}, d2 = {"Ldbxyzptlk/bK/J;", "Ldbxyzptlk/pI/D;", "<anonymous>", "(Ldbxyzptlk/bK/J;)V"}, k = 3, mv = {1, 9, 0})
  public static final class c extends l implements p<J, dbxyzptlk.tI.d<? super D>, Object> {
    public int t;
    
    public final com.dropbox.android.user.a u;
    
    public final b v;
    
    public c(com.dropbox.android.user.a param1a, b param1b, dbxyzptlk.tI.d<? super c> param1d) {
      super(2, param1d);
    }
    
    public final dbxyzptlk.tI.d<D> create(Object param1Object, dbxyzptlk.tI.d<?> param1d) {
      return (dbxyzptlk.tI.d<D>)new c(this.u, this.v, (dbxyzptlk.tI.d)param1d);
    }
    
    public final Object invoke(J param1J, dbxyzptlk.tI.d<? super D> param1d) {
      return ((c)create(param1J, param1d)).invokeSuspend(D.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = dbxyzptlk.uI.c.g();
      int i = this.t;
      if (i != 0) {
        if (i == 1 || i == 2 || i == 3 || i == 4) {
          p.b(param1Object);
          return D.a;
        } 
        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
      } 
      p.b(param1Object);
      if (this.u == null)
        return D.a; 
      if (this.v.g0()) {
        d0 d0 = this.u.q(this.v.V());
        if (d0 != null) {
          d0.k2().J(b.K(this.v).b());
          d0.L1().a();
          param1Object = b.P(this.v);
          b.b.c c1 = new b.b.c(d0);
          this.t = 1;
          if (param1Object.c(c1, (dbxyzptlk.tI.d)this) == object)
            return object; 
        } else if (this.u.t()) {
          param1Object = b.P(this.v);
          b.b.a a1 = b.b.a.a;
          this.t = 2;
          if (param1Object.c(a1, (dbxyzptlk.tI.d)this) == object)
            return object; 
        } 
      } else if (this.u.t()) {
        B b1 = b.P(this.v);
        param1Object = b.b.a.a;
        this.t = 3;
        if (b1.c(param1Object, (dbxyzptlk.tI.d)this) == object)
          return object; 
      } else {
        this.u.o().k2().J(b.K(this.v).b());
        this.u.o().L1().a();
        param1Object = b.P(this.v);
        d0 d0 = this.u.o();
        s.g(d0, "getSingleUser(...)");
        b.b.c c1 = new b.b.c(d0);
        this.t = 4;
        if (param1Object.c(c1, (dbxyzptlk.tI.d)this) == object)
          return object; 
      } 
      return D.a;
    }
  }
  
  @dbxyzptlk.vI.f(c = "com.dropbox.android.activity.login.DbxLoginViewModel$initViews$1", f = "DbxLoginViewModel.kt", l = {92, 95, 97}, m = "invokeSuspend")
  @Metadata(d1 = {"\000\f\n\002\030\002\n\002\030\002\n\002\b\002\020\002\032\0020\001*\0020\000H@¢\006\004\b\002\020\003"}, d2 = {"Ldbxyzptlk/bK/J;", "Ldbxyzptlk/pI/D;", "<anonymous>", "(Ldbxyzptlk/bK/J;)V"}, k = 3, mv = {1, 9, 0})
  public static final class d extends l implements p<J, dbxyzptlk.tI.d<? super D>, Object> {
    public int t;
    
    public int u;
    
    public final Bundle v;
    
    public final b w;
    
    public final Intent x;
    
    public d(Bundle param1Bundle, b param1b, Intent param1Intent, dbxyzptlk.tI.d<? super d> param1d) {
      super(2, param1d);
    }
    
    public final dbxyzptlk.tI.d<D> create(Object param1Object, dbxyzptlk.tI.d<?> param1d) {
      return (dbxyzptlk.tI.d<D>)new d(this.v, this.w, this.x, (dbxyzptlk.tI.d)param1d);
    }
    
    public final Object invoke(J param1J, dbxyzptlk.tI.d<? super D> param1d) {
      return ((d)create(param1J, param1d)).invokeSuspend(D.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = dbxyzptlk.uI.c.g();
      int i = this.u;
      boolean bool = false;
      if (i != 0) {
        if (i != 1) {
          if (i != 2) {
            if (i == 3) {
              p.b(param1Object);
            } else {
              throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            } 
          } else {
            i = this.t;
            p.b(param1Object);
            param1Object = this.w;
          } 
        } else {
          i = this.t;
          p.b(param1Object);
          b.O(this.w).n();
        } 
      } else {
        p.b(param1Object);
        param1Object = this.v;
        if (param1Object == null) {
          i = 1;
        } else {
          i = 0;
        } 
        if (i != 0) {
          param1Object = this.w;
          Intent intent = this.x;
          this.t = i;
          this.u = 1;
          if (param1Object.d0(intent, (dbxyzptlk.tI.d<? super D>)this) == object)
            return object; 
        } else {
          b b1 = this.w;
          s.e(param1Object);
          this.t = i;
          this.u = 2;
          if (b.Q(b1, (Bundle)param1Object, (dbxyzptlk.tI.d)this) == object)
            return object; 
          param1Object = this.w;
        } 
        b.O(this.w).n();
      } 
      b.S(this.w);
      return D.a;
    }
  }
  
  @dbxyzptlk.vI.f(c = "com.dropbox.android.activity.login.DbxLoginViewModel", f = "DbxLoginViewModel.kt", l = {144, 157}, m = "recreateUI")
  @Metadata(k = 3, mv = {1, 9, 0}, xi = 48)
  public static final class f extends dbxyzptlk.vI.d {
    public Object t;
    
    public boolean u;
    
    public Object v;
    
    public final b w;
    
    public int x;
    
    public f(b param1b, dbxyzptlk.tI.d<? super f> param1d) {
      super(param1d);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      this.v = param1Object;
      this.x |= Integer.MIN_VALUE;
      return this.w.i0(false, (dbxyzptlk.tI.d<? super D>)this);
    }
  }
  
  @Metadata(d1 = {"\000\b\n\002\020\013\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"", "b", "()Ljava/lang/Boolean;"}, k = 3, mv = {1, 9, 0})
  public static final class i extends u implements dbxyzptlk.CI.a<Boolean> {
    public final b f;
    
    public i(b param1b) {
      super(0);
    }
    
    public final Boolean b() {
      return Boolean.valueOf(b.N(this.f).isEnabled());
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\android\activity\login\b.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */