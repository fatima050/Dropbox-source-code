package com.dropbox.android.activity.login;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import androidx.activity.ComponentActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.o;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.s;
import androidx.lifecycle.t;
import com.dropbox.android.activity.LoginTourFragment;
import com.dropbox.android.user.UserSelector;
import com.dropbox.common.activity.BaseActivity;
import com.dropbox.common.auth.login.LoginActivity;
import com.dropbox.dbapp.auth.api.LoginSurface;
import com.dropbox.dbapp.auth.login.DbappLoginActivity;
import com.dropbox.dbapp.auth.login.DbappLoginModalActivity;
import dbxyzptlk.C7.b;
import dbxyzptlk.CI.p;
import dbxyzptlk.DI.L;
import dbxyzptlk.DI.s;
import dbxyzptlk.DI.u;
import dbxyzptlk.Df.x;
import dbxyzptlk.E6.E0;
import dbxyzptlk.Fc.H6;
import dbxyzptlk.Fc.X8;
import dbxyzptlk.Fc.qh;
import dbxyzptlk.I6.b;
import dbxyzptlk.U2.i;
import dbxyzptlk.U2.v;
import dbxyzptlk.U2.w;
import dbxyzptlk.U2.y;
import dbxyzptlk.U2.z;
import dbxyzptlk.Uf.v;
import dbxyzptlk.Ve.b;
import dbxyzptlk.bK.J;
import dbxyzptlk.bK.h;
import dbxyzptlk.bK.w0;
import dbxyzptlk.bf.a;
import dbxyzptlk.eK.j;
import dbxyzptlk.pI.D;
import dbxyzptlk.pI.j;
import dbxyzptlk.pI.k;
import dbxyzptlk.pI.p;
import dbxyzptlk.pc.d0;
import dbxyzptlk.vI.l;
import dbxyzptlk.w6.Q0;
import dbxyzptlk.w6.R0;
import dbxyzptlk.w6.W0;
import dbxyzptlk.yj.e;
import dbxyzptlk.zj.h;
import java.util.concurrent.ConcurrentHashMap;
import kotlin.KotlinNothingValueException;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

@Metadata(d1 = {"\000¤\001\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\b\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\007\n\002\020\b\n\002\b\006\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\007\n\002\030\002\n\002\b\006\n\002\030\002\n\002\b\007\n\002\030\002\n\002\b\007\n\002\030\002\n\002\b\007\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\003\n\002\020\000\n\002\b\007\b\007\030\000 m2\0020\0012\0020\0022\0020\0032\0020\004:\001nB\007¢\006\004\b\005\020\006J\017\020\b\032\0020\007H\002¢\006\004\b\b\020\006J\017\020\n\032\0020\tH\002¢\006\004\b\n\020\013J\033\020\016\032\0020\0072\n\b\002\020\r\032\004\030\0010\fH\002¢\006\004\b\016\020\017J\027\020\022\032\0020\0072\006\020\021\032\0020\020H\002¢\006\004\b\022\020\023J\017\020\024\032\0020\007H\002¢\006\004\b\024\020\006J\017\020\025\032\0020\007H\002¢\006\004\b\025\020\006J\017\020\026\032\0020\007H\002¢\006\004\b\026\020\006J\017\020\027\032\0020\007H\002¢\006\004\b\027\020\006J\017\020\030\032\0020\007H\002¢\006\004\b\030\020\006J\031\020\033\032\0020\0072\b\020\032\032\004\030\0010\031H\026¢\006\004\b\033\020\034J\027\020\037\032\0020\0072\006\020\036\032\0020\035H\024¢\006\004\b\037\020 J\017\020!\032\0020\007H\024¢\006\004\b!\020\006J\017\020\"\032\0020\007H\026¢\006\004\b\"\020\006J\027\020$\032\0020\0072\006\020#\032\0020\031H\024¢\006\004\b$\020\034J)\020(\032\0020\0072\006\020&\032\0020%2\006\020'\032\0020%2\b\020\r\032\004\030\0010\035H\026¢\006\004\b(\020)J\017\020*\032\0020\007H\026¢\006\004\b*\020\006J\017\020+\032\0020\007H\026¢\006\004\b+\020\006J!\0200\032\0020\0072\b\020-\032\004\030\0010,2\006\020/\032\0020.H\026¢\006\004\b0\0201J\037\0204\032\0020\0072\006\020-\032\0020,2\006\0203\032\00202H\026¢\006\004\b4\0205J\017\0206\032\0020\007H\026¢\006\004\b6\020\006R\"\020>\032\002078\006@\006X.¢\006\022\n\004\b8\0209\032\004\b:\020;\"\004\b<\020=R\"\020E\032\0020?8\006@\006X.¢\006\022\n\004\b*\020@\032\004\bA\020B\"\004\bC\020DR\"\020M\032\0020F8\006@\006X.¢\006\022\n\004\bG\020H\032\004\bI\020J\"\004\bK\020LR\"\020U\032\0020N8\006@\006X.¢\006\022\n\004\bO\020P\032\004\bQ\020R\"\004\bS\020TR\"\020]\032\0020V8\006@\006X.¢\006\022\n\004\bW\020X\032\004\bY\020Z\"\004\b[\020\\R\033\020c\032\0020^8BX\002¢\006\f\n\004\b_\020`\032\004\ba\020bR\030\020g\032\004\030\0010d8\002@\002X\016¢\006\006\n\004\be\020fR\033\020l\032\0020h8VX\002¢\006\f\n\004\bi\020`\032\004\bj\020k¨\006o"}, d2 = {"Lcom/dropbox/android/activity/login/DbxLoginActivity;", "Lcom/dropbox/common/activity/BaseActivity;", "Ldbxyzptlk/E6/E0;", "Ldbxyzptlk/bf/a;", "Ldbxyzptlk/yj/e;", "<init>", "()V", "Ldbxyzptlk/pI/D;", "L4", "Ldbxyzptlk/bK/w0;", "M4", "()Ldbxyzptlk/bK/w0;", "Landroid/net/Uri;", "data", "N4", "(Landroid/net/Uri;)V", "Ldbxyzptlk/pc/d0;", "user", "C4", "(Ldbxyzptlk/pc/d0;)V", "P4", "J4", "K4", "H4", "I4", "Landroid/os/Bundle;", "savedInstanceState", "onCreate", "(Landroid/os/Bundle;)V", "Landroid/content/Intent;", "intent", "onNewIntent", "(Landroid/content/Intent;)V", "onDestroy", "finish", "outState", "onSaveInstanceState", "", "requestCode", "resultCode", "t1", "(IILandroid/content/Intent;)V", "d", "p", "Ldbxyzptlk/Fc/H6;", "source", "Ldbxyzptlk/Fc/X8;", "googleSourcePage", "v", "(Ldbxyzptlk/Fc/H6;Ldbxyzptlk/Fc/X8;)V", "Ldbxyzptlk/Fc/qh;", "siaSourcePage", "u2", "(Ldbxyzptlk/Fc/H6;Ldbxyzptlk/Fc/qh;)V", "M2", "Ldbxyzptlk/Ve/b;", "c", "Ldbxyzptlk/Ve/b;", "D4", "()Ldbxyzptlk/Ve/b;", "setAccountSelectionContract", "(Ldbxyzptlk/Ve/b;)V", "accountSelectionContract", "Ldbxyzptlk/Tf/a;", "Ldbxyzptlk/Tf/a;", "E4", "()Ldbxyzptlk/Tf/a;", "setLoginLauncher", "(Ldbxyzptlk/Tf/a;)V", "loginLauncher", "Landroidx/lifecycle/t$b;", "e", "Landroidx/lifecycle/t$b;", "G4", "()Landroidx/lifecycle/t$b;", "setViewModelFactory", "(Landroidx/lifecycle/t$b;)V", "viewModelFactory", "Ldbxyzptlk/Uf/v;", "f", "Ldbxyzptlk/Uf/v;", "getSimplifiedSignInLogger", "()Ldbxyzptlk/Uf/v;", "setSimplifiedSignInLogger", "(Ldbxyzptlk/Uf/v;)V", "simplifiedSignInLogger", "Ldbxyzptlk/Cn/a;", "g", "Ldbxyzptlk/Cn/a;", "getNewDbappLoginLogger", "()Ldbxyzptlk/Cn/a;", "setNewDbappLoginLogger", "(Ldbxyzptlk/Cn/a;)V", "newDbappLoginLogger", "Lcom/dropbox/android/activity/login/b;", "h", "Ldbxyzptlk/pI/j;", "F4", "()Lcom/dropbox/android/activity/login/b;", "viewModel", "Landroid/app/Dialog;", "i", "Landroid/app/Dialog;", "blockingDialog", "", "j", "D3", "()Ljava/lang/Object;", "daggerComponent", "k", "a", "Dropbox_normalRelease"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class DbxLoginActivity extends BaseActivity implements E0, a, e {
  public static final a k = new a(null);
  
  public static final int l = 8;
  
  public b c;
  
  public dbxyzptlk.Tf.a d;
  
  public t.b e;
  
  public v f;
  
  public dbxyzptlk.Cn.a g;
  
  public final j h;
  
  public Dialog i;
  
  public final j j;
  
  public DbxLoginActivity() {
    g g = new g(this);
    this.h = (j)new s(L.b(b.class), new e((ComponentActivity)this), g, new f(null, (ComponentActivity)this));
    this.j = k.a(new d((z)this, this));
  }
  
  private final void C4(d0 paramd0) {
    if (F4().g0()) {
      Intent intent1 = new Intent();
      intent1.putExtra("EXTRA_LOGGED_IN_USER_ID", paramd0.getId());
      setResult(-1, intent1);
    } else {
      setResult(-1);
    } 
    Intent intent = F4().X();
    if (intent != null) {
      intent.setExtrasClassLoader(getClassLoader());
      UserSelector.i(intent, UserSelector.d(paramd0.getId()));
      if (dbxyzptlk.K6.a.h(intent))
        startActivity(intent); 
    } 
    finish();
  }
  
  public Object D3() {
    return this.j.getValue();
  }
  
  public final b D4() {
    b b1 = this.c;
    if (b1 != null)
      return b1; 
    s.u("accountSelectionContract");
    return null;
  }
  
  public final dbxyzptlk.Tf.a E4() {
    dbxyzptlk.Tf.a a1 = this.d;
    if (a1 != null)
      return a1; 
    s.u("loginLauncher");
    return null;
  }
  
  public final b F4() {
    return (b)this.h.getValue();
  }
  
  public final t.b G4() {
    t.b b1 = this.e;
    if (b1 != null)
      return b1; 
    s.u("viewModelFactory");
    return null;
  }
  
  public final void H4() {
    if (F4().k0(getIntent())) {
      J4();
    } else {
      P4();
    } 
  }
  
  public final void I4() {
    if (F4().Y()) {
      startActivityForResult(DbappLoginModalActivity.h.getLaunchIntent((Context)this), 500);
    } else {
      H4();
    } 
  }
  
  public final void J4() {
    startActivityForResult(DbappLoginActivity.i.getLaunchIntent((Context)this, F4().T()), 500);
  }
  
  public final void K4() {
    LoginSurface loginSurface = F4().W();
    if (s.c(loginSurface, LoginSurface.Default.a)) {
      H4();
    } else if (s.c(loginSurface, LoginSurface.SignupSigninBottomSheet.a)) {
      I4();
    } 
  }
  
  public final void L4() {
    if (!((LoginSurface)dbxyzptlk.V1.c.b(getIntent(), "com.dropbox.activity.extra.LOGIN_SURFACE", LoginSurface.class) instanceof dbxyzptlk.Cn.b))
      setTheme(W0.Theme_Dropbox_Intro); 
  }
  
  public void M2() {
    setResult(0);
    finish();
  }
  
  public final w0 M4() {
    return h.d((J)i.a((LifecycleOwner)this), null, null, new c(this, null), 3, null);
  }
  
  public final void N4(Uri paramUri) {
    if (paramUri == null && F4().l0()) {
      startActivityForResult(D4().createIntent((Context)this, null), 501);
    } else {
      Intent intent = dbxyzptlk.Tf.a.c(E4(), (Context)this, dbxyzptlk.Tf.a.b.LOGIN, F4().U(), null, F4().g0() ^ true, null, 40, null);
      intent.addFlags(131072);
      if (paramUri != null)
        intent.setData(paramUri); 
      startActivityForResult(intent, 500);
    } 
  }
  
  public final void P4() {
    FragmentManager fragmentManager = getSupportFragmentManager();
    String str = LoginTourFragment.A;
    if (fragmentManager.m0(str) != null)
      return; 
    o o = getSupportFragmentManager().q();
    s.g(o, "beginTransaction(...)");
    o.c(Q0.frag_container_A, (Fragment)LoginTourFragment.u2(), str);
    o.k();
  }
  
  public void d() {
    O4(this, null, 1, null);
  }
  
  public void finish() {
    super.finish();
    if (Build.VERSION.SDK_INT >= 34) {
      dbxyzptlk.I6.a.a(this, 1, 0, 0);
    } else {
      overridePendingTransition(0, 0);
    } 
  }
  
  public void onCreate(Bundle paramBundle) {
    L4();
    super.onCreate(paramBundle);
    ((b)dbxyzptlk.yj.c.b((Context)this, b.class, dbxyzptlk.yj.c.d((Activity)this), false)).a(this);
    M4();
    setContentView(R0.login_frag_container);
    b b1 = F4();
    Intent intent = getIntent();
    s.g(intent, "getIntent(...)");
    b1.f0(intent, paramBundle);
  }
  
  public void onDestroy() {
    Dialog dialog = this.i;
    if (dialog != null)
      dialog.dismiss(); 
    dbxyzptlk.Ee.a.f f = F4().a0();
    if (f != null)
      f.a(); 
    super.onDestroy();
  }
  
  public void onNewIntent(Intent paramIntent) {
    s.h(paramIntent, "intent");
    super.onNewIntent(paramIntent);
    h.d((J)i.a((LifecycleOwner)this), null, null, (p)new b(this, paramIntent, null), 3, null);
  }
  
  public void onSaveInstanceState(Bundle paramBundle) {
    s.h(paramBundle, "outState");
    super.onSaveInstanceState(paramBundle);
    if (F4().X() != null)
      paramBundle.putParcelable("SIS_KEY_NEXT_INTENT", (Parcelable)F4().X()); 
    if (F4().Z() != null)
      paramBundle.putString("SIS_KEY_INTENT_ACTION", F4().Z()); 
    Dialog dialog = this.i;
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (dialog != null) {
      bool1 = bool2;
      if (dialog.isShowing() == true)
        bool1 = true; 
    } 
    paramBundle.putBoolean("SIS_SHOW_BLOCKING_DIALOG", bool1);
    paramBundle.putParcelable("SIS_KEY_LOGIN_SURFACE", (Parcelable)F4().W());
    paramBundle.putParcelable("SIS_KEY_AUTH_LAUNCH_SOURCE", (Parcelable)F4().T());
  }
  
  public void p() {
    Intent intent = new Intent((Context)this, LoginActivity.class);
    intent.setData(dbxyzptlk.Tf.a.a.b());
    startActivityForResult(intent, 500);
  }
  
  public void t1(int paramInt1, int paramInt2, Intent paramIntent) {
    if (paramInt1 != 500) {
      if (paramInt1 == 501)
        F4().h0((b.a)new b.a.a(paramInt2, paramIntent)); 
    } else {
      F4().h0((b.a)new b.a.b(paramInt2, paramIntent));
    } 
  }
  
  public void u2(H6 paramH6, qh paramqh) {
    s.h(paramH6, "source");
    s.h(paramqh, "siaSourcePage");
    if (F4().l0()) {
      startActivityForResult(D4().createIntent((Context)this, null), 501);
    } else {
      startActivityForResult(dbxyzptlk.Tf.a.c(E4(), (Context)this, dbxyzptlk.Tf.a.b.SIA, null, null, F4().g0() ^ true, null, 44, null), 500);
    } 
  }
  
  public void v(H6 paramH6, X8 paramX8) {
    s.h(paramX8, "googleSourcePage");
    if (F4().l0()) {
      startActivityForResult(D4().createIntent((Context)this, null), 501);
    } else {
      startActivityForResult(dbxyzptlk.Tf.a.c(E4(), (Context)this, dbxyzptlk.Tf.a.b.SIG, null, null, F4().g0() ^ true, null, 44, null), 500);
    } 
  }
  
  @Metadata(d1 = {"\000\034\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\b\n\002\b\002\n\002\020\016\n\002\b\t\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003R\024\020\005\032\0020\0048\006XT¢\006\006\n\004\b\005\020\006R\024\020\b\032\0020\0078\006XT¢\006\006\n\004\b\b\020\tR\024\020\n\032\0020\0048\006XT¢\006\006\n\004\b\n\020\006R\024\020\013\032\0020\0078\006XT¢\006\006\n\004\b\013\020\tR\024\020\f\032\0020\0078\006XT¢\006\006\n\004\b\f\020\tR\024\020\r\032\0020\0078\006XT¢\006\006\n\004\b\r\020\tR\024\020\016\032\0020\0078\006XT¢\006\006\n\004\b\016\020\tR\024\020\017\032\0020\0078\006XT¢\006\006\n\004\b\017\020\t¨\006\020"}, d2 = {"Lcom/dropbox/android/activity/login/DbxLoginActivity$a;", "", "<init>", "()V", "", "ACCOUNT_SELECTION_REQUEST_CODE", "I", "", "EXTRA_LAUNCH_LOGIN", "Ljava/lang/String;", "LOGIN_REQUEST_CODE", "SIS_KEY_AUTH_LAUNCH_SOURCE", "SIS_KEY_LOGIN_SURFACE", "SIS_KEY_NEXT_INTENT", "SIS_KEY_STARTING_SCREEN", "SIS_SHOW_BLOCKING_DIALOG", "Dropbox_normalRelease"}, k = 1, mv = {1, 9, 0}, xi = 48)
  public static final class a {
    public a() {}
  }
  
  @dbxyzptlk.vI.f(c = "com.dropbox.android.activity.login.DbxLoginActivity$setupViewStates$1", f = "DbxLoginActivity.kt", l = {97}, m = "invokeSuspend")
  @Metadata(d1 = {"\000\f\n\002\030\002\n\002\030\002\n\002\b\002\020\002\032\0020\001*\0020\000H@¢\006\004\b\002\020\003"}, d2 = {"Ldbxyzptlk/bK/J;", "Ldbxyzptlk/pI/D;", "<anonymous>", "(Ldbxyzptlk/bK/J;)V"}, k = 3, mv = {1, 9, 0})
  public static final class c extends l implements p<J, dbxyzptlk.tI.d<? super D>, Object> {
    public int t;
    
    public final DbxLoginActivity u;
    
    public c(DbxLoginActivity param1DbxLoginActivity, dbxyzptlk.tI.d<? super c> param1d) {
      super(2, param1d);
    }
    
    public final dbxyzptlk.tI.d<D> create(Object param1Object, dbxyzptlk.tI.d<?> param1d) {
      return (dbxyzptlk.tI.d<D>)new c(this.u, (dbxyzptlk.tI.d)param1d);
    }
    
    public final Object invoke(J param1J, dbxyzptlk.tI.d<? super D> param1d) {
      return ((c)create(param1J, param1d)).invokeSuspend(D.a);
    }
    
    public final Object invokeSuspend(Object<b.b> param1Object) {
      Object object = dbxyzptlk.uI.c.g();
      int i = this.t;
      if (i != 0) {
        if (i != 1)
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine"); 
        p.b(param1Object);
      } else {
        p.b(param1Object);
        param1Object = (Object<b.b>)DbxLoginActivity.y4(this.u).b0();
        a a = new a(this.u);
        this.t = 1;
        if (param1Object.a(a, (dbxyzptlk.tI.d)this) == object)
          return object; 
      } 
      throw new KotlinNothingValueException();
    }
    
    @Metadata(d1 = {"\000\016\n\002\030\002\n\000\n\002\030\002\n\002\b\002\020\003\032\0020\0022\006\020\001\032\0020\000H@¢\006\004\b\003\020\004"}, d2 = {"Lcom/dropbox/android/activity/login/b$b;", "it", "Ldbxyzptlk/pI/D;", "a", "(Lcom/dropbox/android/activity/login/b$b;Ldbxyzptlk/tI/d;)Ljava/lang/Object;"}, k = 3, mv = {1, 9, 0})
    public static final class a<T> implements j {
      public final DbxLoginActivity a;
      
      public a(DbxLoginActivity param2DbxLoginActivity) {}
      
      public final Object a(b.b param2b, dbxyzptlk.tI.d<? super D> param2d) {
        if (!s.c(param2b, b.b.h.a))
          if (s.c(param2b, b.b.a.a)) {
            this.a.M2();
          } else {
            Dialog dialog;
            if (s.c(param2b, b.b.e.a)) {
              Dialog dialog1 = DbxLoginActivity.x4(this.a);
              if (dialog1 != null)
                dialog1.dismiss(); 
              DbxLoginActivity dbxLoginActivity = this.a;
              DbxLoginActivity.A4(dbxLoginActivity, b.LOGIN_PROGRESS_V2.onCreate((Activity)dbxLoginActivity));
              dialog = DbxLoginActivity.x4(this.a);
              if (dialog != null)
                dialog.show(); 
            } else if (s.c(dialog, b.b.b.a)) {
              dialog = DbxLoginActivity.x4(this.a);
              if (dialog != null)
                dialog.dismiss(); 
            } else if (s.c(dialog, b.b.f.a)) {
              DbxLoginActivity.z4(this.a);
            } else if (dialog instanceof b.b.g) {
              x.g((Context)this.a, ((b.b.g)dialog).a());
            } else if (dialog instanceof b.b.c) {
              DbxLoginActivity.w4(this.a, ((b.b.c)dialog).a());
            } else if (dialog instanceof b.b.d) {
              DbxLoginActivity.B4(this.a, ((b.b.d)dialog).a());
            } 
          }  
        return D.a;
      }
    }
  }
  
  @Metadata(d1 = {"\000\016\n\002\030\002\n\000\n\002\030\002\n\002\b\002\020\003\032\0020\0022\006\020\001\032\0020\000H@¢\006\004\b\003\020\004"}, d2 = {"Lcom/dropbox/android/activity/login/b$b;", "it", "Ldbxyzptlk/pI/D;", "a", "(Lcom/dropbox/android/activity/login/b$b;Ldbxyzptlk/tI/d;)Ljava/lang/Object;"}, k = 3, mv = {1, 9, 0})
  public static final class a<T> implements j {
    public final DbxLoginActivity a;
    
    public a(DbxLoginActivity param1DbxLoginActivity) {}
    
    public final Object a(b.b param1b, dbxyzptlk.tI.d<? super D> param1d) {
      if (!s.c(param1b, b.b.h.a))
        if (s.c(param1b, b.b.a.a)) {
          this.a.M2();
        } else {
          Dialog dialog;
          if (s.c(param1b, b.b.e.a)) {
            Dialog dialog1 = DbxLoginActivity.x4(this.a);
            if (dialog1 != null)
              dialog1.dismiss(); 
            DbxLoginActivity dbxLoginActivity = this.a;
            DbxLoginActivity.A4(dbxLoginActivity, b.LOGIN_PROGRESS_V2.onCreate((Activity)dbxLoginActivity));
            dialog = DbxLoginActivity.x4(this.a);
            if (dialog != null)
              dialog.show(); 
          } else if (s.c(dialog, b.b.b.a)) {
            dialog = DbxLoginActivity.x4(this.a);
            if (dialog != null)
              dialog.dismiss(); 
          } else if (s.c(dialog, b.b.f.a)) {
            DbxLoginActivity.z4(this.a);
          } else if (dialog instanceof b.b.g) {
            x.g((Context)this.a, ((b.b.g)dialog).a());
          } else if (dialog instanceof b.b.c) {
            DbxLoginActivity.w4(this.a, ((b.b.c)dialog).a());
          } else if (dialog instanceof b.b.d) {
            DbxLoginActivity.B4(this.a, ((b.b.d)dialog).a());
          } 
        }  
      return D.a;
    }
  }
  
  @Metadata(d1 = {"\000\b\n\002\020\000\n\002\b\004\020\004\032\0020\000\"\n\b\000\020\001\030\001*\0020\000H\n¢\006\004\b\002\020\003"}, d2 = {"", "T", "invoke", "()Ljava/lang/Object;", "<anonymous>"}, k = 3, mv = {1, 9, 0})
  public static final class d extends u implements dbxyzptlk.CI.a<Object> {
    public final z f;
    
    public final DbxLoginActivity g;
    
    public d(z param1z, DbxLoginActivity param1DbxLoginActivity) {
      super(0);
    }
    
    public final Object invoke() {
      dbxyzptlk.yj.d d1 = (dbxyzptlk.yj.d)(new t(this.f, dbxyzptlk.yj.d.d.a())).a(dbxyzptlk.yj.d.class);
      Class<a.a> clazz = a.a.class;
      if (h.a.class.isAssignableFrom(a.a.class))
        clazz = (Class)a.a.class.getEnclosingClass(); 
      ConcurrentHashMap<Class<a.a>, Object> concurrentHashMap = d1.G();
      Object<a.a> object2 = (Object<a.a>)concurrentHashMap.get(clazz);
      Object<a.a> object1 = object2;
      if (object2 == null) {
        w.a((v)d1);
        object1 = (Object<a.a>)this.g;
        object2 = (Object<a.a>)((a.b)dbxyzptlk.yj.c.b((Context)object1, a.b.class, dbxyzptlk.yj.c.d((Activity)object1), true)).u();
        object1 = object2;
        if (object2 != null)
          object1 = (Object<a.a>)object2.a(w.a((v)d1)); 
        clazz = (Class<a.a>)concurrentHashMap.putIfAbsent(clazz, object1);
        if (clazz != null)
          object1 = (Object<a.a>)clazz; 
      } 
      s.g(object1, "getOrPut(...)");
      return object1;
    }
  }
  
  @Metadata(d1 = {"\000\016\n\002\030\002\n\000\n\002\030\002\n\002\b\002\020\003\032\0020\002\"\n\b\000\020\001\030\001*\0020\000H\n¢\006\004\b\003\020\004"}, d2 = {"Ldbxyzptlk/U2/v;", "VM", "Ldbxyzptlk/U2/y;", "b", "()Ldbxyzptlk/U2/y;"}, k = 3, mv = {1, 9, 0})
  public static final class e extends u implements dbxyzptlk.CI.a<y> {
    public final ComponentActivity f;
    
    public e(ComponentActivity param1ComponentActivity) {
      super(0);
    }
    
    public final y b() {
      return this.f.getViewModelStore();
    }
  }
  
  @Metadata(d1 = {"\000\016\n\002\030\002\n\000\n\002\030\002\n\002\b\002\020\003\032\0020\002\"\n\b\000\020\001\030\001*\0020\000H\n¢\006\004\b\003\020\004"}, d2 = {"Ldbxyzptlk/U2/v;", "VM", "Ldbxyzptlk/X2/a;", "b", "()Ldbxyzptlk/X2/a;"}, k = 3, mv = {1, 9, 0})
  public static final class f extends u implements dbxyzptlk.CI.a<dbxyzptlk.X2.a> {
    public final dbxyzptlk.CI.a f;
    
    public final ComponentActivity g;
    
    public f(dbxyzptlk.CI.a param1a, ComponentActivity param1ComponentActivity) {
      super(0);
    }
    
    public final dbxyzptlk.X2.a b() {
      dbxyzptlk.CI.a a1 = this.f;
      if (a1 != null) {
        dbxyzptlk.X2.a a3 = (dbxyzptlk.X2.a)a1.invoke();
        dbxyzptlk.X2.a a2 = a3;
        return (a3 == null) ? this.g.getDefaultViewModelCreationExtras() : a2;
      } 
      return this.g.getDefaultViewModelCreationExtras();
    }
  }
  
  @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"Landroidx/lifecycle/t$b;", "b", "()Landroidx/lifecycle/t$b;"}, k = 3, mv = {1, 9, 0})
  public static final class g extends u implements dbxyzptlk.CI.a<t.b> {
    public final DbxLoginActivity f;
    
    public g(DbxLoginActivity param1DbxLoginActivity) {
      super(0);
    }
    
    public final t.b b() {
      return this.f.G4();
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\android\activity\login\DbxLoginActivity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */