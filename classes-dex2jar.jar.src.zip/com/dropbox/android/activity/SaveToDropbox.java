package com.dropbox.android.activity;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Parcelable;
import androidx.activity.result.ActivityResult;
import com.dropbox.android.DropboxApplication;
import com.dropbox.android.user.a;
import com.dropbox.common.activity.BaseActivity;
import com.dropbox.product.dbapp.directorypicker.FileSystemWarningDialogFrag;
import com.dropbox.product.dbapp.entry.DropboxLocalEntry;
import com.dropbox.product.dbapp.entry.LocalEntry;
import com.dropbox.product.dbapp.entry.SharedLinkLocalEntry;
import com.dropbox.product.dbapp.file_manager.FileSystemWarningDetails;
import com.dropbox.product.dbapp.file_manager.c;
import com.dropbox.product.dbapp.path.DropboxPath;
import com.dropbox.product.dbapp.path.SharedLinkPath;
import dbxyzptlk.CC.p;
import dbxyzptlk.Df.x;
import dbxyzptlk.E6.J;
import dbxyzptlk.E6.O2;
import dbxyzptlk.E6.Q2;
import dbxyzptlk.E6.R2;
import dbxyzptlk.Ec.a;
import dbxyzptlk.Ec.g;
import dbxyzptlk.Ec.m;
import dbxyzptlk.Fq.f;
import dbxyzptlk.He.p;
import dbxyzptlk.K6.a;
import dbxyzptlk.Km.b;
import dbxyzptlk.P6.D;
import dbxyzptlk.P6.F;
import dbxyzptlk.cp.a;
import dbxyzptlk.dk.H;
import dbxyzptlk.h.a;
import dbxyzptlk.h.b;
import dbxyzptlk.i.a;
import dbxyzptlk.i.d;
import dbxyzptlk.iy.B;
import dbxyzptlk.iz.a;
import dbxyzptlk.pc.d0;
import dbxyzptlk.re.j;
import dbxyzptlk.re.k;
import dbxyzptlk.sL.a;
import dbxyzptlk.sh.g;
import dbxyzptlk.t9.g;
import dbxyzptlk.un.g;
import dbxyzptlk.vx.r;
import dbxyzptlk.w6.V0;
import dbxyzptlk.wc.d;
import dbxyzptlk.yx.e;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

public class SaveToDropbox extends DropboxDirectoryPickerActivity implements FileSystemWarningDialogFrag.e, f {
  public g m;
  
  public g n;
  
  public ArrayList<SharedLinkLocalEntry> o;
  
  public a p;
  
  public SharedLinkLocalEntry q;
  
  public boolean r = false;
  
  public DropboxPath s;
  
  public g t;
  
  public g u;
  
  public d v;
  
  public F w;
  
  public b<Intent> x = registerForActivityResult((a)new d(), (a)new Q2(this));
  
  public SaveToDropbox() {
    super(V0.select_save_directory, true);
  }
  
  public static Intent O4(Context paramContext, SharedLinkLocalEntry paramSharedLinkLocalEntry) {
    Intent intent = new Intent(paramContext, SaveToDropbox.class);
    intent.putParcelableArrayListExtra("ARG_LOCAL_ENTRIES", new ArrayList(O2.a(paramSharedLinkLocalEntry)));
    return intent;
  }
  
  public static Intent P4(Context paramContext, SharedLinkLocalEntry paramSharedLinkLocalEntry, String paramString) {
    Intent intent = O4(paramContext, paramSharedLinkLocalEntry);
    intent.putExtra("ARG_SHARED_CONTENT_USER_ID", paramString);
    return intent;
  }
  
  public static Intent Q4(Context paramContext, List<SharedLinkLocalEntry> paramList) {
    Intent intent = new Intent(paramContext, SaveToDropbox.class);
    intent.putParcelableArrayListExtra("ARG_LOCAL_ENTRIES", new ArrayList<>(paramList));
    intent.putExtra("ARG_IS_MULTIPLE_FILES", true);
    return intent;
  }
  
  public void B1(Set<String> paramSet, Bundle paramBundle) {
    N4((DropboxPath)H.d(paramBundle, "ARG_DESTINATION_PATH", DropboxPath.class), r.CONFIRMED);
  }
  
  public final void N4(DropboxPath paramDropboxPath, r paramr) {
    J j = G4();
    p.o(j);
    d0 d0 = z4().q(l());
    this.s = paramDropboxPath;
    (new D(this, j.v(), this.o, paramDropboxPath, this.p, paramr, d0.q(), j.q0())).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, (Object[])new Void[0]);
  }
  
  public void O1(Bundle paramBundle) {
    this.w.d();
  }
  
  public final void S4(c.a parama, boolean paramBoolean) {
    switch (a.a[parama.ordinal()]) {
      case 7:
      case 8:
      case 9:
      case 10:
      case 11:
        this.w.a(parama);
        break;
      case 1:
      case 2:
      case 3:
      case 4:
      case 5:
      case 6:
        this.w.b(parama);
        break;
    } 
    m m = a.V2();
    m.o("failure_cause", parama.toString());
    m.n("should_show_upsell", Boolean.valueOf(paramBoolean));
    m.i(this.m);
  }
  
  public void T4(DropboxPath paramDropboxPath, List<FileSystemWarningDetails> paramList) {
    Bundle bundle = new Bundle();
    bundle.putParcelable("ARG_DESTINATION_PATH", (Parcelable)paramDropboxPath);
    FileSystemWarningDialogFrag.t2(paramList, bundle).l2(getSupportFragmentManager());
  }
  
  public void U4(String paramString, c.a parama) {
    a.d("Failed to save", new Object[0]);
    S4(parama, false);
    if (paramString != null) {
      x.g((Context)this, paramString);
    } else {
      x.f((Context)this, V0.save_to_dropbox_error);
    } 
    finish();
  }
  
  public void V4(List<DropboxLocalEntry> paramList) {
    x.f((Context)this, V0.save_to_dropbox_done);
    this.w.c();
    m m = a.W2().n("is_multi_file", Boolean.valueOf(this.r));
    if (!this.r) {
      m.n("is_dir", Boolean.valueOf(this.q.q0())).o("shared_link_access_level", this.q.K().toString());
      if (this.q.N() != null)
        m.o("rlkey_sha1", p.n(this.q.N())); 
      if (this.q.P() != null)
        m.o("sckey_sha1", p.n(this.q.P())); 
      if (this.q.U() != null)
        m.o("tkey_sha1", p.n(this.q.U())); 
      if (this.q.T() != null)
        m.o("subpath_sha1", p.n(this.q.T())); 
    } else {
      m.l("item_count", paramList.size());
    } 
    m.i(this.m);
    d0 d0 = z4().q(l());
    d0.h2().c(true);
    if (paramList == null || paramList.isEmpty()) {
      finish();
      return;
    } 
    DropboxLocalEntry dropboxLocalEntry = paramList.get(0);
    if (!dropboxLocalEntry.q0() && !this.r) {
      b b1 = this.v.a(dropboxLocalEntry.P(), d0);
      this.u.a((BaseActivity)this, e.CREATION).t(b1, (LocalEntry)dropboxLocalEntry, B.SORT_BY_NAME, d0.e(), d0);
    } else {
      Intent intent = DropboxBrowser.y4("ACTION_GO_TO_FOLDER", l());
      if (this.r) {
        intent.putExtra("EXTRA_PATH", (Parcelable)this.s);
      } else {
        intent = DropboxBrowser.x4((Context)this, dropboxLocalEntry.P(), l());
        intent.putExtra("EXTRA_PATH", (Parcelable)dropboxLocalEntry.P());
      } 
      startActivity(intent);
    } 
  }
  
  public void W4() {
    S4(c.a.FAILED_NOT_ENOUGH_QUOTA, true);
    J j = (J)p.o(G4());
    a a1 = new a("android-overquota-previews-upsell-faq", j.UPGRADE_FAQ);
    Intent intent = j.o().e((Context)this, k.OVERQUOTA_PREVIEWS_UPSELL, a1.a(), null, Collections.emptyList(), a1.b());
    this.x.a(intent);
  }
  
  public void X3(Bundle paramBundle, boolean paramBoolean) {
    super.X3(paramBundle, paramBoolean);
    if (paramBundle == null || paramBoolean) {
      String str;
      a a1 = z4();
      p.o(a1);
      if (getIntent().hasExtra("ARG_SHARED_CONTENT_USER_ID")) {
        String str1 = getIntent().getStringExtra("ARG_SHARED_CONTENT_USER_ID");
      } else {
        paramBundle = null;
      } 
      Bundle bundle = paramBundle;
      if (paramBundle == null)
        str = a1.h().getId(); 
      K4(str, null, false);
    } 
  }
  
  public void h0(DropboxPath paramDropboxPath) {
    p.o(l());
    a a1 = z4();
    if (a1 == null) {
      a.d("No users logged in. Not saving.", new Object[0]);
      return;
    } 
    if (a1.q(l()) == null) {
      a.d("User is no longer logged in. Not saving.", new Object[0]);
      return;
    } 
    this.w.e();
    N4(paramDropboxPath, r.CHECK);
  }
  
  public void j2() {
    startActivity(a.d((Context)this, getIntent(), true, null));
  }
  
  public void onCreate(Bundle paramBundle) {
    if (u())
      return; 
    R2 r2 = (R2)s();
    this.p = r2.Y0();
    this.m = r2.d();
    this.t = r2.a1();
    this.u = r2.T0();
    this.v = r2.U0();
    this.n = DropboxApplication.s0((Context)this);
    this.w = r2.V0();
    this.o = H.b(getIntent().getExtras(), "ARG_LOCAL_ENTRIES", SharedLinkLocalEntry.class);
    this.r = getIntent().getBooleanExtra("ARG_IS_MULTIPLE_FILES", false);
    this.w.f(this.o.get(0), this.o.size());
    m m = a.U2().n("is_multi_file", Boolean.valueOf(this.r));
    if (this.o.size() == 1) {
      this.q = this.o.get(0);
      I4(getResources().getString(V0.save_to_title_caption, new Object[] { this.q.J() }));
      m.o("ext", ((SharedLinkPath)this.q.s()).G2()).n("is_dir", Boolean.valueOf(this.q.q0())).o("shared_link_access_level", this.q.K().toString());
      if (this.q.N() != null)
        m.o("rlkey_sha1", this.q.N()); 
      if (this.q.P() != null)
        m.o("sckey_sha1", this.q.P()); 
      if (this.q.U() != null)
        m.o("tkey_sha1", this.q.U()); 
      if (this.q.T() != null)
        m.o("subpath_sha1", this.q.T()); 
    } else {
      m.l("item_count", this.o.size());
    } 
    m.i(this.m);
    if (paramBundle != null)
      this.s = (DropboxPath)H.d(paramBundle, "SIS_DESTINATION_PATH", DropboxPath.class); 
    super.onCreate(paramBundle);
  }
  
  public void onSaveInstanceState(Bundle paramBundle) {
    super.onSaveInstanceState(paramBundle);
    DropboxPath dropboxPath = this.s;
    if (dropboxPath != null)
      paramBundle.putParcelable("SIS_DESTINATION_PATH", (Parcelable)dropboxPath); 
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\android\activity\SaveToDropbox.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */