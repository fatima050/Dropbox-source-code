package com.dropbox.android.activity.payment;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import com.dropbox.android.DropboxApplication;
import com.dropbox.android.activity.base.BaseForSDKUserRequestActivity;
import com.dropbox.common.safeintentstarter.NoHandlerForIntentException;
import dbxyzptlk.CC.p;
import dbxyzptlk.Df.x;
import dbxyzptlk.Ec.a;
import dbxyzptlk.Ec.m;
import dbxyzptlk.dk.d0;
import dbxyzptlk.dk.g0;
import dbxyzptlk.oj.c;
import dbxyzptlk.pc.d0;
import dbxyzptlk.re.k;
import dbxyzptlk.w6.V0;

public class PaymentUpgradeForSDKActivity extends BaseForSDKUserRequestActivity {
  public c h;
  
  public m B4() {
    return a.R1();
  }
  
  public void C4(d0 paramd0) {
    p.o(paramd0);
    if (!d0.c(paramd0.R1())) {
      F4(1, getResources().getString(V0.external_payment_invalid_user));
      return;
    } 
    startActivity(paramd0.o().a((Context)this, k.OVER_QUOTA_EXTERNAL_APP));
    finish();
  }
  
  public void D4() {
    Intent intent = new Intent("android.intent.action.VIEW");
    intent.setData(Uri.parse(g0.UPGRADE_OVER_QUOTA_EXTERNAL_APP.localizedUrl(getApplicationContext())));
    try {
      this.h.c((Context)this, intent);
    } catch (NoHandlerForIntentException noHandlerForIntentException) {
      x.f((Context)this, V0.cannot_open_browser_error);
    } 
    finish();
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    this.h = DropboxApplication.L0((Context)this);
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\android\activity\payment\PaymentUpgradeForSDKActivity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */