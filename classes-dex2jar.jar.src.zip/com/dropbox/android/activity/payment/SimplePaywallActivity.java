package com.dropbox.android.activity.payment;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import androidx.compose.ui.platform.ComposeView;
import androidx.compose.ui.platform.j;
import com.dropbox.android.activity.base.BaseUserActivity;
import com.dropbox.android.paywall.ManageDevicesActivity;
import com.dropbox.android.preference.a;
import com.dropbox.android.user.DbxUserManager;
import com.dropbox.android.user.a;
import com.dropbox.common.activity.BaseActivity;
import com.dropbox.common.android.ui.dialogs.DbxAlertDialogFragment;
import dbxyzptlk.CI.a;
import dbxyzptlk.CI.p;
import dbxyzptlk.D7.c;
import dbxyzptlk.DI.s;
import dbxyzptlk.E7.a;
import dbxyzptlk.Ec.g;
import dbxyzptlk.F0.c;
import dbxyzptlk.J6.n;
import dbxyzptlk.pI.j;
import dbxyzptlk.pI.k;
import dbxyzptlk.pc.d0;
import dbxyzptlk.qI.s;
import dbxyzptlk.x0.X0;
import dbxyzptlk.x0.k0;
import dbxyzptlk.yj.c;
import java.util.ArrayList;
import kotlin.Metadata;

@Metadata(d1 = {"\000d\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\020\016\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\030\002\n\002\b\r\n\002\030\002\n\002\b\007\n\002\030\002\n\002\b\007\n\002\020\013\n\002\b\b\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\006\b\007\030\000 C2\0020\0012\0020\0022\0020\003:\001DB\007¢\006\004\b\004\020\005J\031\020\t\032\0020\b2\b\020\007\032\004\030\0010\006H\024¢\006\004\b\t\020\nJ\017\020\013\032\0020\bH\026¢\006\004\b\013\020\005J\031\020\017\032\0020\0162\b\020\r\032\004\030\0010\fH\026¢\006\004\b\017\020\020J'\020\024\032\0020\b2\026\020\023\032\022\022\004\022\0020\f0\021j\b\022\004\022\0020\f`\022H\026¢\006\004\b\024\020\025J\017\020\026\032\0020\bH\026¢\006\004\b\026\020\005J\017\020\027\032\0020\bH\002¢\006\004\b\027\020\005J\017\020\030\032\0020\bH\002¢\006\004\b\030\020\005R(\020\r\032\0020\f8\006@\006X.¢\006\030\n\004\b\031\020\032\022\004\b\037\020\005\032\004\b\033\020\034\"\004\b\035\020\036R\"\020'\032\0020 8\006@\006X.¢\006\022\n\004\b!\020\"\032\004\b#\020$\"\004\b%\020&R\"\020/\032\0020(8\006@\006X.¢\006\022\n\004\b)\020*\032\004\b+\020,\"\004\b-\020.R+\0208\032\002002\006\0201\032\002008B@BX\002¢\006\022\n\004\b2\0203\032\004\b4\0205\"\004\b6\0207R!\020>\032\b\022\004\022\0020\000098BX\002¢\006\f\n\004\b:\020;\032\004\b<\020=R\033\020B\032\0020?8BX\002¢\006\f\n\004\b\033\020;\032\004\b@\020A¨\006E"}, d2 = {"Lcom/dropbox/android/activity/payment/SimplePaywallActivity;", "Lcom/dropbox/android/activity/base/BaseUserActivity;", "Lcom/dropbox/common/android/ui/dialogs/DbxAlertDialogFragment$c;", "Lcom/dropbox/android/preference/a$a;", "<init>", "()V", "Landroid/os/Bundle;", "savedInstanceState", "Ldbxyzptlk/pI/D;", "onCreate", "(Landroid/os/Bundle;)V", "L0", "", "userId", "Ldbxyzptlk/pc/d0;", "t", "(Ljava/lang/String;)Ldbxyzptlk/pc/d0;", "Ljava/util/ArrayList;", "Lkotlin/collections/ArrayList;", "userIds", "n", "(Ljava/util/ArrayList;)V", "o", "M4", "L4", "g", "Ljava/lang/String;", "l", "()Ljava/lang/String;", "setUserId", "(Ljava/lang/String;)V", "getUserId$annotations", "Ldbxyzptlk/Ec/g;", "h", "Ldbxyzptlk/Ec/g;", "H4", "()Ldbxyzptlk/Ec/g;", "setLogger", "(Ldbxyzptlk/Ec/g;)V", "logger", "Lcom/dropbox/android/user/DbxUserManager;", "i", "Lcom/dropbox/android/user/DbxUserManager;", "K4", "()Lcom/dropbox/android/user/DbxUserManager;", "setUserManager", "(Lcom/dropbox/android/user/DbxUserManager;)V", "userManager", "", "<set-?>", "j", "Ldbxyzptlk/x0/k0;", "I4", "()Z", "N4", "(Z)V", "showLoading", "Lcom/dropbox/android/preference/a;", "k", "Ldbxyzptlk/pI/j;", "J4", "()Lcom/dropbox/android/preference/a;", "unlinkHelper", "Ldbxyzptlk/E7/a;", "G4", "()Ldbxyzptlk/E7/a;", "deviceLimitLogger", "m", "a", "Dropbox_normalRelease"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class SimplePaywallActivity extends BaseUserActivity implements DbxAlertDialogFragment.c, a.a {
  public static final a m = new a(null);
  
  public static final int n = 8;
  
  public String g;
  
  public g h;
  
  public DbxUserManager i;
  
  public final k0 j = X0.j(Boolean.FALSE, null, 2, null);
  
  public final j k = k.a((a)new d(this));
  
  public final j l = k.a((a)new b(this));
  
  private final a<SimplePaywallActivity> J4() {
    return (a<SimplePaywallActivity>)this.k.getValue();
  }
  
  public final a G4() {
    return (a)this.l.getValue();
  }
  
  public final g H4() {
    g g1 = this.h;
    if (g1 != null)
      return g1; 
    s.u("logger");
    return null;
  }
  
  public final boolean I4() {
    return ((Boolean)this.j.getValue()).booleanValue();
  }
  
  public final DbxUserManager K4() {
    DbxUserManager dbxUserManager = this.i;
    if (dbxUserManager != null)
      return dbxUserManager; 
    s.u("userManager");
    return null;
  }
  
  public void L0() {
    G4().m();
    N4(true);
    J4().g(s.g((Object[])new String[] { l() }));
  }
  
  public final void L4() {
    G4().n(t(l()).N1());
    a.y.a((BaseActivity)this);
  }
  
  public final void M4() {
    G4().h();
    startActivity(ManageDevicesActivity.s.a((Context)this, l(), c.PAYWALL));
    finish();
  }
  
  public final void N4(boolean paramBoolean) {
    this.j.setValue(Boolean.valueOf(paramBoolean));
  }
  
  public final String l() {
    String str = this.g;
    if (str != null)
      return str; 
    s.u("userId");
    return null;
  }
  
  public void n(ArrayList<String> paramArrayList) {
    s.h(paramArrayList, "userIds");
    J4().k(paramArrayList);
  }
  
  public void o() {
    J4().j();
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    if (w4())
      return; 
    long l1 = getIntent().getLongExtra("EXTRA_DEVICE_COUNT", -1L);
    long l2 = getIntent().getLongExtra("EXTRA_DEVICE_LIMIT", -1L);
    if (l1 > 0L && l2 > 0L) {
      ((n)c.b((Context)this, n.class, c.d((Activity)this), false)).i8(this);
      ComposeView composeView = new ComposeView((Context)this, null, 0, 6, null);
      composeView.setViewCompositionStrategy((j)j.d.b);
      composeView.setContent((p)c.c(2086609288, true, new c(this, l1, l2)));
      setContentView((View)composeView);
      A4(paramBundle);
      return;
    } 
    throw new IllegalArgumentException("Failed requirement.");
  }
  
  public d0 t(String paramString) {
    a a1 = K4().a();
    s.e(a1);
    d0 d0 = a1.q(paramString);
    s.e(d0);
    return d0;
  }
  
  class SimplePaywallActivity {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\android\activity\payment\SimplePaywallActivity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */