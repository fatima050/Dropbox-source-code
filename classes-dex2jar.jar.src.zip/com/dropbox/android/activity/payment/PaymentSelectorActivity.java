package com.dropbox.android.activity.payment;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.o;
import com.dropbox.android.DropboxApplication;
import com.dropbox.android.activity.base.BaseUserActivity;
import com.dropbox.android.preference.a;
import com.dropbox.common.activity.BaseActivity;
import com.dropbox.common.android.ui.dialogs.DbxAlertDialogFragment;
import com.dropbox.common.android.ui.widgets.DbxToolbar;
import com.dropbox.dbapp.purchase_journey.api.entities.PlanSupported;
import dbxyzptlk.Ec.a;
import dbxyzptlk.Fc.Zh;
import dbxyzptlk.Fe.b;
import dbxyzptlk.Me.a;
import dbxyzptlk.Me.d;
import dbxyzptlk.Or.d;
import dbxyzptlk.P6.k;
import dbxyzptlk.Pr.N;
import dbxyzptlk.Pr.b;
import dbxyzptlk.Pr.w;
import dbxyzptlk.Sy.g;
import dbxyzptlk.Sy.h;
import dbxyzptlk.Sy.k;
import dbxyzptlk.Tr.b;
import dbxyzptlk.bf.a;
import dbxyzptlk.df.b;
import dbxyzptlk.dk.S;
import dbxyzptlk.dk.d0;
import dbxyzptlk.fp.c;
import dbxyzptlk.pc.d0;
import dbxyzptlk.qa.b;
import dbxyzptlk.re.k;
import dbxyzptlk.rf.i;
import dbxyzptlk.sL.a;
import dbxyzptlk.w6.Q0;
import java.util.ArrayList;

public class PaymentSelectorActivity extends BaseUserActivity implements k, k.b, DbxToolbar.c, a, DbxAlertDialogFragment.c, a.a {
  public boolean g;
  
  public int h;
  
  public k i;
  
  public boolean j;
  
  public boolean k;
  
  public PaymentSelectorFragment l;
  
  public DbxToolbar m;
  
  public b n;
  
  public DbxAlertDialogFragment.c o;
  
  public a<PaymentSelectorActivity> p;
  
  public c q;
  
  private c D4() {
    if (this.q == null) {
      d0 d0 = C4();
      this.q = (c)new b((g)DropboxApplication.s0((Context)this), (h)d0.h2(), d0.getId(), d0.h(), d0.i());
    } 
    return this.q;
  }
  
  public a<PaymentSelectorActivity> E4() {
    return this.p;
  }
  
  public final void F4() {
    a.Y1().i(C4().e());
    PaymentSelectorFragment paymentSelectorFragment = this.l;
    if (paymentSelectorFragment != null) {
      paymentSelectorFragment.y3();
      Intent intent = D4().b(this.i, (Context)this);
      if (intent != null)
        startActivity(intent); 
    } 
  }
  
  public DbxToolbar G() {
    return this.m;
  }
  
  public void G4(DbxAlertDialogFragment.c paramc) {
    this.o = paramc;
  }
  
  public final void H4(boolean paramBoolean) {
    String str;
    PaymentSelectorFragment paymentSelectorFragment;
    Zh zh = new Zh();
    k k1 = this.i;
    if (k1 == null) {
      str = "unknown";
    } else {
      str = str.toString();
    } 
    zh.k(str).g(C4().e());
    I4(i.frag_toolbar_container);
    if (PaymentSelectorFragment.o3(this.i))
      this.m.b(); 
    int i = Q0.frag_container;
    if (paramBoolean) {
      paymentSelectorFragment = PaymentSelectorFragment.E3(this.i, C4());
      o o = getSupportFragmentManager().q();
      o.u(i, (Fragment)paymentSelectorFragment);
      o.k();
    } else {
      paymentSelectorFragment = (PaymentSelectorFragment)b.c(getSupportFragmentManager().l0(i), PaymentSelectorFragment.class);
    } 
    this.l = paymentSelectorFragment;
  }
  
  public void I4(int paramInt) {
    if (this.h != paramInt) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Swapping to layout 0x");
      stringBuilder.append(Integer.toString(paramInt, 16));
      stringBuilder.append(" from 0x");
      stringBuilder.append(Integer.toString(this.h, 16));
      a.d(stringBuilder.toString(), new Object[0]);
      this.l = null;
      this.h = paramInt;
      setContentView(paramInt);
      DbxToolbar dbxToolbar = (DbxToolbar)findViewById(Q0.dbx_toolbar);
      this.m = dbxToolbar;
      setSupportActionBar((Toolbar)dbxToolbar);
      getSupportActionBar().u(true);
    } else {
      a.d("Already at layout 0x %s", new Object[] { Integer.toString(paramInt, 16) });
    } 
  }
  
  public void L0() {
    DbxAlertDialogFragment.c c1 = this.o;
    if (c1 != null)
      c1.L0(); 
  }
  
  public void N(boolean paramBoolean) {
    if (paramBoolean) {
      (new k((BaseActivity)this, C4(), d.b.b)).execute((Object[])new Void[0]);
    } else {
      finish();
    } 
  }
  
  public void O3() {
    finish();
  }
  
  public void U3(d0 paramd0, a parama) {
    PlanSupported planSupported;
    if (parama.B()) {
      this.n.i();
    } else {
      this.n.e();
    } 
    int i = a.a[parama.o().ordinal()];
    if (i != 1) {
      if (i != 2) {
        if (i != 3) {
          if (i != 4) {
            planSupported = PlanSupported.NotSupported;
          } else {
            planSupported = PlanSupported.Essentials;
          } 
        } else {
          planSupported = PlanSupported.Professional;
        } 
      } else {
        planSupported = PlanSupported.Family;
      } 
    } else {
      planSupported = PlanSupported.Plus;
    } 
    Intent intent = D4().a(this.i, planSupported, (Context)this);
    if (intent != null) {
      startActivity(intent);
      finish();
    } else {
      I4(i.frag_toolbar_shadow_container);
      o o = getSupportFragmentManager().q();
      o.u(Q0.frag_container, (Fragment)UpgradeAccountSuccessFragmentV2.y2(paramd0.getId()));
      o.k();
      this.g = true;
    } 
  }
  
  public void b4() {
    DbxAlertDialogFragment.c c1 = this.o;
    if (c1 != null)
      c1.b4(); 
  }
  
  public void n(ArrayList<String> paramArrayList) {
    this.p.k(paramArrayList);
  }
  
  public void n0() {
    DbxAlertDialogFragment.c c1 = this.o;
    if (c1 != null)
      c1.n0(); 
  }
  
  public void o() {
    this.p.j();
  }
  
  public void onBackPressed() {
    F4();
    super.onBackPressed();
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    if (w4())
      return; 
    if (!d0.c(C4().R1())) {
      finish();
      return;
    } 
    this.p = new a((Activity)this, DropboxApplication.b1((Context)this), DropboxApplication.b0((Context)this));
    this.n = DropboxApplication.S((Context)this);
    this.i = (k)S.b(getIntent(), "EXTRA_UPGRADE_SOURCE", k.class);
    if (paramBundle != null) {
      this.g = paramBundle.getBoolean("SIS_KEY_SHOWINGUPGRADESUCCESS");
      this.j = paramBundle.getBoolean("SIS_CHECKED_EXISTING_SUBSCRIPTIONS", false);
      this.k = paramBundle.getBoolean("SIS_SUBSCRIPTION_USED", false);
      if (this.g) {
        I4(i.frag_toolbar_shadow_container);
      } else {
        H4(false);
      } 
    } else {
      H4(true);
    } 
    d d = ((b)getApplicationContext()).e().y();
    String str = C4().getId();
    k k1 = this.i;
    if (k1 == k.PASSWORDS_ACT_CARD) {
      d.b((b)w.a, str);
    } else if (k1 == k.VAULT_ACT_CARD) {
      d.b((b)N.a, str);
    } 
    A4(paramBundle);
  }
  
  public boolean onOptionsItemSelected(MenuItem paramMenuItem) {
    if (paramMenuItem.getItemId() == 16908332)
      F4(); 
    return super.onOptionsItemSelected(paramMenuItem);
  }
  
  public void onSaveInstanceState(Bundle paramBundle) {
    super.onSaveInstanceState(paramBundle);
    paramBundle.putBoolean("SIS_KEY_SHOWINGUPGRADESUCCESS", this.g);
    paramBundle.putBoolean("SIS_CHECKED_EXISTING_SUBSCRIPTIONS", this.j);
    paramBundle.putBoolean("SIS_SUBSCRIPTION_USED", this.k);
  }
  
  public void p0(boolean paramBoolean) {
    this.j = true;
    this.k = paramBoolean;
  }
  
  public d0 t(String paramString) {
    return z4().q(paramString);
  }
  
  public void t1(int paramInt1, int paramInt2, Intent paramIntent) {
    if (paramInt1 == 1 || paramInt1 == 0)
      this.l.t1(paramInt1, paramInt2, paramIntent); 
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\android\activity\payment\PaymentSelectorActivity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */