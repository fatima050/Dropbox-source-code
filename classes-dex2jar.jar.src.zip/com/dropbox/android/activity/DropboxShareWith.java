package com.dropbox.android.activity;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.TextView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.o;
import com.dropbox.android.DropboxApplication;
import com.dropbox.android.activity.base.BaseIdentityActivity;
import com.dropbox.common.activity.BaseActivity;
import com.dropbox.common.android.ui.widgets.DeterminateProgressBarView;
import com.dropbox.dbapp.user_chooser.UserChooserFragment;
import com.dropbox.product.dbapp.entry.DropboxLocalEntry;
import com.dropbox.product.dbapp.path.DropboxPath;
import com.google.android.material.snackbar.Snackbar;
import dbxyzptlk.Bc.n;
import dbxyzptlk.Bf.c;
import dbxyzptlk.Bf.d;
import dbxyzptlk.C9.a;
import dbxyzptlk.CC.p;
import dbxyzptlk.CI.l;
import dbxyzptlk.Df.g;
import dbxyzptlk.Df.x;
import dbxyzptlk.E6.N;
import dbxyzptlk.E6.O;
import dbxyzptlk.E6.P;
import dbxyzptlk.E6.Q;
import dbxyzptlk.E6.S;
import dbxyzptlk.E6.T;
import dbxyzptlk.E6.U;
import dbxyzptlk.E6.k3;
import dbxyzptlk.Ec.g;
import dbxyzptlk.Ee.a;
import dbxyzptlk.Fc.Fg;
import dbxyzptlk.Fc.Gg;
import dbxyzptlk.Fc.Qg;
import dbxyzptlk.Fe.b;
import dbxyzptlk.K6.b;
import dbxyzptlk.M8.a;
import dbxyzptlk.Rh.b;
import dbxyzptlk.Sz.d;
import dbxyzptlk.Uy.a;
import dbxyzptlk.Wh.b;
import dbxyzptlk.dk.v;
import dbxyzptlk.lq.a;
import dbxyzptlk.lq.f;
import dbxyzptlk.lq.j;
import dbxyzptlk.pI.D;
import dbxyzptlk.pc.d0;
import dbxyzptlk.pf.A;
import dbxyzptlk.pf.B;
import dbxyzptlk.pf.v;
import dbxyzptlk.pj.l;
import dbxyzptlk.pj.m;
import dbxyzptlk.pj.t;
import dbxyzptlk.rf.j;
import dbxyzptlk.sL.a;
import dbxyzptlk.sx.b;
import dbxyzptlk.w6.Q0;
import dbxyzptlk.w6.R0;
import dbxyzptlk.w6.V0;

public class DropboxShareWith extends BaseIdentityActivity implements a.b, f, d {
  public final j d = j.b();
  
  public UserChooserFragment e;
  
  public TextView f;
  
  public d0 g;
  
  public g h;
  
  public Long i;
  
  public b j;
  
  public DeterminateProgressBarView k;
  
  public float l;
  
  public Handler m = new Handler(Looper.getMainLooper());
  
  public a.f n;
  
  public final c o = new c();
  
  public View C0() {
    return this.o.b();
  }
  
  public void K(String paramString) {
    boolean bool;
    if (this.g == null) {
      bool = true;
    } else {
      bool = false;
    } 
    p.e(bool, "Object must be null.");
    this.g = z4().q(paramString);
    f5();
    h5();
  }
  
  public final void O4() {
    p.o(this.g);
    int i = Build.VERSION.SDK_INT;
    if (i >= 34) {
      d5();
    } else {
      B b1;
      if (i >= 33) {
        b1 = a.c;
      } else if (i >= 29) {
        b1 = a.b;
      } else {
        b1 = a.a;
      } 
      (new A(b1, this, (BaseActivity)this, DropboxApplication.K0(getBaseContext()), DropboxApplication.L0(getBaseContext()))).a(null, (v.a)new a(this));
    } 
  }
  
  public final void P4() {
    b.a();
    DeterminateProgressBarView determinateProgressBarView = this.k;
    if (determinateProgressBarView != null)
      determinateProgressBarView.setVisibility(8); 
  }
  
  public final void Q4() {
    this.m.post((Runnable)new d(this));
  }
  
  public final void R4(DropboxLocalEntry paramDropboxLocalEntry) {
    this.m.post((Runnable)new T(this, paramDropboxLocalEntry));
  }
  
  public final void S4() {
    boolean bool;
    if (this.g == null) {
      bool = true;
    } else {
      bool = false;
    } 
    p.e(bool, "Object must be null.");
    if (!k3.a(z4())) {
      K(z4().o().getId());
    } else {
      j5();
    } 
  }
  
  public final Uri T4() {
    Uri[] arrayOfUri = v.a(getIntent());
    if (arrayOfUri.length == 0)
      U4(); 
    int i = arrayOfUri.length;
    boolean bool = true;
    if (i != 1)
      bool = false; 
    p.j(bool, "Assert failed: %1$s", "Sharing multiple files at once not currently supported");
    return arrayOfUri[0];
  }
  
  public final void U4() {
    b.a();
    a.d("handleUploadFailure: Failed to share file", new Object[0]);
    if (this.g != null && this.i != null)
      ((b)DropboxApplication.c1(getApplicationContext()).a(this.g.getId())).G().n(this.i.longValue()); 
    x.f(getApplicationContext(), V0.error_failed_to_share_file);
    finish();
  }
  
  public void V2() {
    this.o.a();
  }
  
  public final void V4() {
    this.m.post((Runnable)new b(this));
  }
  
  public void X3(Bundle paramBundle, boolean paramBoolean) {}
  
  public void c1() {
    a.d("Upload failed due to network issues", new Object[0]);
    U4();
  }
  
  public final D c5(b paramb) {
    b.d d1;
    if (paramb instanceof b.d) {
      d1 = (b.d)paramb;
      g5((float)d1.b() / (float)d1.d());
    } else {
      DropboxLocalEntry dropboxLocalEntry;
      if (d1 instanceof b.g) {
        DropboxPath dropboxPath = (new b(((b.g)d1).b())).c();
        dropboxLocalEntry = this.g.q().k(dropboxPath);
        if (dropboxLocalEntry != null) {
          R4(dropboxLocalEntry);
        } else {
          Q4();
          V4();
        } 
      } else if (dropboxLocalEntry instanceof b.b) {
        Q4();
        V4();
      } 
    } 
    return D.a;
  }
  
  public final void d5() {
    i5();
    p.o(this.g);
    if (this.i != null) {
      k5();
    } else {
      a a = new a((Context)this, T4(), this.g.getId(), this.g.v(), this.g.q(), a.c.SENT_FILES, a.SHARE_WITH);
      a.c();
      a.execute((Object[])new Void[0]);
    } 
  }
  
  public final void e5() {
    if (isTaskRoot()) {
      startActivity(DropboxBrowser.z4());
      finish();
    } else {
      finish();
    } 
  }
  
  public void f3(Snackbar paramSnackbar) {
    this.o.f(paramSnackbar);
  }
  
  public final void f5() {
    this.f.setVisibility(8);
    if (this.e != null) {
      o o = getSupportFragmentManager().q();
      o.t((Fragment)this.e);
      o.k();
    } 
  }
  
  public final void g5(float paramFloat) {
    this.m.post((Runnable)new c(this, paramFloat));
  }
  
  public final void h5() {
    Uri uri = T4();
    String str = d.k(getContentResolver(), uri);
    (new g((Context)this)).setTitle(V0.share_with_confirmation_modal_title).setMessage(getString(V0.share_with_confirmation_modal_body, new Object[] { str })).setPositiveButton(V0.ok, (DialogInterface.OnClickListener)new O(this)).setNegativeButton(j.cancel, (DialogInterface.OnClickListener)new P(this)).setOnCancelListener((DialogInterface.OnCancelListener)new Q(this)).create().show();
  }
  
  public final void i5() {
    b.a();
    DeterminateProgressBarView determinateProgressBarView = this.k;
    if (determinateProgressBarView != null) {
      determinateProgressBarView.setVisibility(0);
      this.k.c(this.l);
    } 
  }
  
  public void j2() {
    (new Fg()).g(this.h);
    x.f((Context)this, V0.error_login_needed_to_access);
    finish();
  }
  
  public final void j5() {
    findViewById(16908290).setVisibility(0);
    this.f.setVisibility(0);
    this.e = UserChooserFragment.r2(true, false, a.NO_PADDING);
    o o = getSupportFragmentManager().q();
    o.u(Q0.frag_container, (Fragment)this.e);
    o.k();
  }
  
  public final void k5() {
    b.a();
    p.o(this.g);
    p.o(this.i);
    if (this.j != null)
      return; 
    b b1 = new b(getApplicationContext(), getLifecycle(), this.i.longValue(), this.g.getId(), (l)new S(this));
    this.j = b1;
    b1.d();
  }
  
  public final void l5() {
    b.a();
    p.o(this.g);
    p.o(this.i);
    b b1 = this.j;
    if (b1 == null)
      return; 
    b1.e();
    this.j = null;
    P4();
  }
  
  public j n2() {
    return this.d;
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    if (w4())
      return; 
    setContentView(R0.user_chooser_layout);
    this.h = DropboxApplication.b0((Context)this);
    this.f = (TextView)findViewById(Q0.user_chooser_subtitle);
    this.k = (DeterminateProgressBarView)findViewById(Q0.progress_view);
    m m = DropboxApplication.D0((Context)this);
    this.n = m.d((l)new N(this));
    if (!m.a().a()) {
      U4();
      return;
    } 
    this.o.c(findViewById(Q0.frag_container));
    if (paramBundle != null) {
      if (paramBundle.containsKey("SIS_UPLOAD_TASK_ID"))
        this.i = Long.valueOf(paramBundle.getLong("SIS_UPLOAD_TASK_ID")); 
      this.l = paramBundle.getInt("SIS_UPLOAD_PROGRESS");
      if (paramBundle.containsKey("SIS_USER_ID_FOR_SHARE")) {
        String str = (String)p.o(paramBundle.getString("SIS_USER_ID_FOR_SHARE"));
        this.g = z4().q(str);
      } 
    } else {
      Uri[] arrayOfUri = v.a(getIntent());
      if (arrayOfUri.length == 1)
        (new Gg()).k(arrayOfUri[0].getScheme()).g(this.h); 
    } 
    A4(paramBundle);
  }
  
  public void onDestroy() {
    super.onDestroy();
    this.o.g();
    this.n.a();
  }
  
  public void onSaveInstanceState(Bundle paramBundle) {
    super.onSaveInstanceState(paramBundle);
    d0 d01 = this.g;
    if (d01 != null)
      paramBundle.putString("SIS_USER_ID_FOR_SHARE", d01.getId()); 
    Long long_ = this.i;
    if (long_ != null)
      paramBundle.putLong("SIS_UPLOAD_TASK_ID", long_.longValue()); 
    paramBundle.putFloat("SIS_UPLOAD_PROGRESS", this.l);
  }
  
  public void onStart() {
    super.onStart();
    if (this.g == null) {
      S4();
    } else if (this.i == null) {
      h5();
    } else {
      i5();
      k5();
    } 
  }
  
  public void onStop() {
    super.onStop();
    if (this.i != null)
      l5(); 
  }
  
  public void v3(DropboxPath paramDropboxPath, String paramString, long paramLong) {
    this.i = Long.valueOf(paramLong);
    k5();
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\android\activity\DropboxShareWith.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */