package com.dropbox.android.activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcelable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.t;
import com.dropbox.android.DropboxApplication;
import com.dropbox.android.activity.base.BasePathActivity;
import com.dropbox.android.widget.SharedLinkDocumentPreviewActionsView;
import com.dropbox.common.android.ui.widgets.DbxToolbar;
import com.dropbox.dbapp.android.browser.NewFileNameDialogFragment;
import com.dropbox.product.dbapp.entry.LocalEntry;
import com.dropbox.product.dbapp.path.DropboxPath;
import com.dropbox.product.dbapp.path.Path;
import com.google.android.material.snackbar.Snackbar;
import dbxyzptlk.Bf.b;
import dbxyzptlk.Bf.c;
import dbxyzptlk.Bf.d;
import dbxyzptlk.CC.h;
import dbxyzptlk.CC.p;
import dbxyzptlk.E6.Z2;
import dbxyzptlk.E6.a3;
import dbxyzptlk.E6.b3;
import dbxyzptlk.E6.c3;
import dbxyzptlk.E6.d3;
import dbxyzptlk.E6.e3;
import dbxyzptlk.E6.g3;
import dbxyzptlk.Ec.a;
import dbxyzptlk.Ec.g;
import dbxyzptlk.Fe.b;
import dbxyzptlk.Fm.a;
import dbxyzptlk.HK.a;
import dbxyzptlk.HK.e;
import dbxyzptlk.He.h;
import dbxyzptlk.Ij.s;
import dbxyzptlk.It.k;
import dbxyzptlk.Ja.b;
import dbxyzptlk.Km.b;
import dbxyzptlk.Sq.L;
import dbxyzptlk.Sq.k;
import dbxyzptlk.Td.h;
import dbxyzptlk.U2.z;
import dbxyzptlk.V1.c;
import dbxyzptlk.X1.h;
import dbxyzptlk.bf.a;
import dbxyzptlk.dk.H;
import dbxyzptlk.dx.p;
import dbxyzptlk.eH.D;
import dbxyzptlk.eH.c;
import dbxyzptlk.gh.e;
import dbxyzptlk.gh.h;
import dbxyzptlk.gh.l;
import dbxyzptlk.iH.b;
import dbxyzptlk.iH.c;
import dbxyzptlk.iL.h;
import dbxyzptlk.iL.q;
import dbxyzptlk.kI.a;
import dbxyzptlk.lH.a;
import dbxyzptlk.lH.g;
import dbxyzptlk.pc.d0;
import dbxyzptlk.rc.b;
import dbxyzptlk.sL.a;
import dbxyzptlk.sc.c;
import dbxyzptlk.tx.b;
import dbxyzptlk.w6.O0;
import dbxyzptlk.w6.Q0;
import dbxyzptlk.w6.R0;
import dbxyzptlk.w6.V0;
import dbxyzptlk.wc.c;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.sentry.instrumentation.file.h;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.util.HashMap;
import java.util.Locale;
import java.util.concurrent.Callable;
import java.util.concurrent.TimeUnit;

public class TextEditActivity<P extends Path> extends BasePathActivity<P> implements NewFileNameDialogFragment.b, d, a {
  public String A = "\r\n";
  
  public final c B = new c();
  
  public g3 C;
  
  public b D = new b();
  
  public final SharedLinkDocumentPreviewActionsView.e E = (SharedLinkDocumentPreviewActionsView.e)new d(this);
  
  public g g;
  
  public b h;
  
  public s i;
  
  public P j;
  
  public TextView k;
  
  public String l;
  
  public ScrollView m;
  
  public View n;
  
  public boolean o = false;
  
  public boolean p = true;
  
  public boolean q = false;
  
  public boolean r = true;
  
  public boolean s = false;
  
  public boolean t = false;
  
  public final c u = new c((Activity)this);
  
  public String v = null;
  
  public String w = null;
  
  public String x = null;
  
  public int y = 0;
  
  public final String z = System.getProperty("line.separator");
  
  public static boolean b5(k paramk, String paramString1, String paramString2) {
    return (paramk.d(paramString1) || (paramString2 != null && paramk.c(paramString2) == L.TEXT));
  }
  
  public static j e5(InputStream paramInputStream) throws IOException {
    j j = new j();
    h h = new h(0);
    h.j((q)new h(j));
    byte[] arrayOfByte = new byte[1024];
    a a1 = null;
    boolean bool1 = false;
    byte b2 = 0;
    int i = b2;
    boolean bool2 = true;
    byte b1 = 1;
    while (true) {
      int k = paramInputStream.read(arrayOfByte, 0, 1024);
      if (k != -1 && (!bool1 || !b2)) {
        Object object;
        byte b3 = 0;
        while (!b2 && b3 < k) {
          byte b4 = arrayOfByte[b3];
          if (b4 != 10) {
            if (b4 != 13) {
              Object object2 = object;
              if (object != null) {
                j.b = "\r";
              } else {
                continue;
              } 
            } else {
              b4 = 1;
              continue;
            } 
          } else if (object != null) {
            j.b = "\r\n";
          } else {
            j.b = "\n";
          } 
          b2 = 1;
          Object object1 = object;
          continue;
          b3++;
          object = SYNTHETIC_LOCAL_VARIABLE_5;
        } 
        a a2 = a1;
        b3 = b1;
        if (b1) {
          a a4 = a.d;
          a a3 = a.e;
          b1 = 0;
          while (true) {
            a2 = a1;
            if (b1 < 2) {
              (new a[2])[0] = a4;
              (new a[2])[1] = a3;
              a2 = (new a[2])[b1];
              byte[] arrayOfByte1 = a2.b();
              if (k >= arrayOfByte1.length && h5(arrayOfByte, arrayOfByte1))
                break; 
              b1++;
              continue;
            } 
            break;
          } 
          b3 = 0;
        } 
        boolean bool = bool2;
        if (bool2)
          bool = h.k(arrayOfByte, k); 
        bool2 = bool1;
        if (!bool) {
          bool2 = bool1;
          if (!bool1)
            bool2 = h.i(arrayOfByte, k, false); 
        } 
        a1 = a2;
        bool1 = bool2;
        bool2 = bool;
        b1 = b3;
        continue;
      } 
      break;
    } 
    h.a();
    String[] arrayOfString = h.g();
    if (a1 != null) {
      i = arrayOfString.length;
      for (b1 = 0; b1 < i; b1++) {
        String str = arrayOfString[b1];
        if (str.equals(a1.c())) {
          j.a = str;
          break;
        } 
      } 
    } 
    if (j.a == null)
      if (bool2) {
        a.j("Text Edit is using CHARSET = ASCII", new Object[0]);
        j.a = "us-ascii";
      } else {
        j.a = "UTF-8";
      }  
    return j;
  }
  
  public static <P extends Path> Intent g5(Context paramContext, b<P> paramb, LocalEntry<P> paramLocalEntry, String paramString) {
    Intent intent = new Intent(paramContext, TextEditActivity.class);
    intent.putExtra("SIS_LOCAL_ENTRY", (Parcelable)paramLocalEntry);
    intent.putExtra("SIS_USER_ID", paramString);
    Uri uri = paramb.e().f(paramLocalEntry.s()).d();
    intent.setAction("android.intent.action.VIEW");
    intent.setDataAndType(uri, paramLocalEntry.M());
    if (paramLocalEntry.c() != null)
      intent.putExtra("CHARACTER_SET", paramLocalEntry.c()); 
    c.b(intent, paramb);
    return intent;
  }
  
  public static boolean h5(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2) {
    if (paramArrayOfbyte1.length >= paramArrayOfbyte2.length) {
      for (byte b1 = 0; b1 < paramArrayOfbyte2.length; b1++) {
        if (paramArrayOfbyte1[b1] != paramArrayOfbyte2[b1])
          return false; 
      } 
      return true;
    } 
    return false;
  }
  
  public View C0() {
    return this.B.b();
  }
  
  public void V2() {
    this.B.a();
  }
  
  public final void c5(String paramString) {
    if (this.r && !this.s) {
      EditText editText = new EditText((Context)this);
      this.k = (TextView)editText;
      editText.setInputType(131073);
      this.k.requestFocus();
    } else {
      this.k = new TextView((Context)this);
      if (!this.s)
        o5(); 
    } 
    this.k.setTextAppearance(l.Body);
    this.k.setTextSize(2, 16.0F);
    Typeface typeface = h.h((Context)this, h.atlas_grotesk);
    this.k.setTypeface(typeface);
    if (this.s)
      invalidateOptionsMenu(); 
    this.k.setId(Q0.text);
    ViewGroup.LayoutParams layoutParams = new ViewGroup.LayoutParams(-1, -1);
    int i = getResources().getDimensionPixelSize(O0.textEditorTextViewPaddingTopBottom);
    int j = getResources().getDimensionPixelSize(O0.textEditorTextViewPaddingLeftRight);
    this.k.setPadding(j, i, j, i);
    this.k.setGravity(48);
    this.k.setSingleLine(false);
    this.k.setTextColor(getResources().getColor(e.color__standard__text));
    this.k.setBackgroundResource(17170445);
    this.k.setFilters(new InputFilter[] { (InputFilter)new InputFilter.LengthFilter(256000) });
    this.m.addView((View)this.k, layoutParams);
    this.k.setText(paramString);
    if (this.y > 0 && paramString.length() > 0) {
      f f = new f(this);
      this.k.addOnLayoutChangeListener((View.OnLayoutChangeListener)f);
    } 
    g g1 = new g(this);
    this.k.addTextChangedListener((TextWatcher)g1);
  }
  
  public final void d5(File paramFile) throws IOException {
    boolean bool;
    Exception exception;
    FileInputStream fileInputStream = h.b.a(new FileInputStream(paramFile), paramFile);
    try {
      j j = e5(fileInputStream);
      if (this.x == null)
        this.x = j.a; 
    } finally {}
    String str = ((j)exception).b;
    if (str != null)
      this.A = str; 
    if ((getIntent().getFlags() & 0x2) == 2) {
      bool = true;
    } else {
      bool = false;
    } 
    this.r = bool;
    e.b(fileInputStream);
  }
  
  public void f3(Snackbar paramSnackbar) {
    this.B.f(paramSnackbar);
  }
  
  public final void f5() {
    if (!(this.j instanceof DropboxPath)) {
      c5(this.l);
    } else {
      d0 d0 = z4().q((String)B4().k().c());
      if (d0 != null)
        d0.Q1().execute((Runnable)new e(this, d0)); 
    } 
  }
  
  public final void o5() {
    this.k.setTextIsSelectable(true);
  }
  
  @SuppressLint({"MissingSuperCall"})
  public void onBackPressed() {
    if (this.o) {
      ConfirmQuitDialog.x2(this);
    } else {
      finish();
    } 
  }
  
  public void onCreate(Bundle paramBundle) {
    boolean bool;
    super.onCreate(paramBundle);
    if (w4())
      return; 
    Intent intent = getIntent();
    String str2 = intent.getAction();
    b b1 = B4();
    this.g = b1.a();
    this.h = DropboxApplication.Z0((Context)this);
    this.i = DropboxApplication.Y0((Context)this);
    this.y = intent.getIntExtra("scroll_offset", 0);
    if ("android.intent.action.EDIT".equals(str2) || "android.intent.action.VIEW".equals(str2)) {
      Path path = b1.i();
      this.j = (P)path;
      this.v = path.getName();
      this.p = false;
    } 
    g3 g31 = (g3)(new t((z)this)).a(g3.class);
    this.C = g31;
    this.l = g31.F();
    if (paramBundle != null) {
      this.r = paramBundle.getBoolean("SIS_EDITABLE");
      if (this.j == null)
        this.j = (P)H.d(paramBundle, "SIS_PATH", Path.class); 
      this.w = paramBundle.getString("SIS_PROPOSED_FILENAME");
      if (this.j.q0()) {
        str1 = getString(V0.text_editor_default_title);
      } else {
        str1 = this.j.getName();
      } 
      this.v = str1;
      this.o = paramBundle.getBoolean("SIS_CHANGED");
    } else {
      String str = this.v;
      if (str == null || str.equals(""))
        if ("android.intent.action.GET_CONTENT".equals(str2)) {
          Path path = str1.i();
          this.j = (P)path;
          p.e(path.q0(), "Assert failed.");
          this.v = getString(V0.text_editor_default_title);
        } else {
          a.j("Exiting, unknown action: %s", new Object[] { str2 });
          finish();
          return;
        }  
    } 
    String str1 = intent.getStringExtra("CHARACTER_SET");
    if (str1 != null)
      this.x = str1; 
    setContentView(R0.text_editor);
    View view = findViewById(Q0.dbx_toolbar_layout);
    this.B.c(view);
    ScrollView scrollView = (ScrollView)findViewById(Q0.text_container);
    this.m = scrollView;
    scrollView.setOnTouchListener((View.OnTouchListener)new c(this));
    this.n = findViewById(Q0.savingView);
    if (this.p) {
      c5(this.l);
    } else {
      try {
        if (this.l == null) {
          String str = p5();
          this.l = str;
          this.C.G(str);
        } 
      } catch (i i) {
      
      } catch (RuntimeException runtimeException) {
      
      } catch (IOException iOException) {}
      f5();
      k k = B4().e().f((Path)this.j);
      this.u.b(k);
    } 
    DbxToolbar dbxToolbar = (DbxToolbar)findViewById(Q0.dbx_toolbar);
    dbxToolbar.a();
    setSupportActionBar((Toolbar)dbxToolbar);
    if (intent.getExtras() != null) {
      LocalEntry localEntry = (LocalEntry)H.d(intent.getExtras(), "SIS_LOCAL_ENTRY", LocalEntry.class);
    } else {
      dbxToolbar = null;
    } 
    boolean bool1 = dbxToolbar instanceof com.dropbox.product.dbapp.entry.SharedLinkLocalEntry;
    if (z4() != null) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool1) {
      boolean bool2 = B4().d().a();
      bool1 = b.a((LocalEntry)dbxToolbar);
      SharedLinkDocumentPreviewActionsView sharedLinkDocumentPreviewActionsView = (SharedLinkDocumentPreviewActionsView)findViewById(Q0.shared_link_document_preview_action_buttons);
      sharedLinkDocumentPreviewActionsView.setVisibility(0);
      sharedLinkDocumentPreviewActionsView.f(bool1, bool2, false);
      sharedLinkDocumentPreviewActionsView.setup((Context)this, (LocalEntry)dbxToolbar, this.E, null, bool);
    } 
    setTitle(this.v);
    A4(paramBundle);
  }
  
  public boolean onCreateOptionsMenu(Menu paramMenu) {
    super.onCreateOptionsMenu(paramMenu);
    if (this.r && !this.s)
      paramMenu.add(0, 0, 0, getString(V0.text_edit_save)).setShowAsAction(2); 
    return true;
  }
  
  public void onDestroy() {
    this.B.g();
    this.u.c();
    this.D.d();
    super.onDestroy();
  }
  
  public boolean onOptionsItemSelected(MenuItem paramMenuItem) {
    V2();
    int i = paramMenuItem.getItemId();
    if (i != 0) {
      if (i != 1 && i != 16908332)
        return false; 
      if (!this.o) {
        finish();
      } else {
        ConfirmQuitDialog.x2(this);
      } 
      return true;
    } 
    if (this.s)
      return true; 
    if (this.j.q0()) {
      NewFileNameDialogFragment.r2(a.FILE).l2(getSupportFragmentManager());
    } else if (!this.t) {
      u5();
      b.c(this.j, DropboxPath.class);
      a.p0().i(this.g);
      r5((DropboxPath)this.j, true, null);
    } 
    return true;
  }
  
  public boolean onPrepareOptionsMenu(Menu paramMenu) {
    if (paramMenu.size() > 0) {
      MenuItem menuItem = paramMenu.getItem(0);
      if (this.t) {
        menuItem.setEnabled(false);
        menuItem.setTitle(getString(V0.text_edit_saving_in_progress));
      } else {
        menuItem.setEnabled(true);
        menuItem.setTitle(getString(V0.text_edit_save));
      } 
    } 
    return super.onPrepareOptionsMenu(paramMenu);
  }
  
  public void onResumeFragments() {
    super.onResumeFragments();
    LocalEntry localEntry = (LocalEntry)c.b(getIntent(), "SIS_LOCAL_ENTRY", LocalEntry.class);
    this.h.A((FragmentActivity)this);
    if (localEntry instanceof com.dropbox.product.dbapp.entry.SharedLinkLocalEntry)
      this.h.E((FragmentActivity)this, h.e(localEntry.k())); 
  }
  
  public void onSaveInstanceState(Bundle paramBundle) {
    super.onSaveInstanceState(paramBundle);
    TextView textView = this.k;
    if (textView != null)
      this.C.G(textView.getText().toString()); 
    paramBundle.putParcelable("SIS_PATH", (Parcelable)this.j);
    paramBundle.putString("SIS_PROPOSED_FILENAME", this.w);
    paramBundle.putBoolean("SIS_CHANGED", this.o);
    paramBundle.putBoolean("SIS_EDITABLE", this.r);
  }
  
  public void p1(String paramString) {
    b.c(this.j, DropboxPath.class);
    this.w = paramString;
    d0 d0 = z4().q((String)B4().k().c());
    d0.B1().b((DropboxPath)this.j, (p.a)new a(this, d0));
  }
  
  public final String p5() throws i, FileNotFoundException, IOException {
    Exception exception;
    InputStream inputStream;
    File file = B4().e().f((Path)this.j).a();
    d5(file);
    try {
      FileInputStream fileInputStream = new FileInputStream();
      this(file);
    } finally {
      exception = null;
      file = null;
    } 
    e.b(inputStream);
    e.d((Reader)file);
    throw exception;
  }
  
  public final void q5(boolean paramBoolean) {
    this.t = paramBoolean;
    invalidateOptionsMenu();
  }
  
  public final void r5(DropboxPath paramDropboxPath, boolean paramBoolean, h<k<DropboxPath>, Void> paramh) {
    String str1 = this.x;
    if (str1 == null) {
      this.x = "UTF-8";
    } else {
      str1 = str1.toLowerCase(Locale.US);
      if (str1.equals("ascii") || str1.equals("us-ascii"))
        this.x = "UTF-8"; 
    } 
    String str2 = this.x;
    b b1 = B4();
    d0 d0 = z4().q((String)b1.k().c());
    b b2 = (b)b1.e();
    String str3 = this.A;
    this.n.setVisibility(0);
    c c1 = D.u((Callable)new Z2(this, str3, b2, paramDropboxPath, paramBoolean, str2, d0)).J(a.c()).z(AndroidSchedulers.a()).H((g)new a3(this, paramh), (g)new b3(this));
    this.D.a(c1);
  }
  
  public final void s5(DropboxPath paramDropboxPath, boolean paramBoolean) {
    r5(paramDropboxPath, paramBoolean, (h<k<DropboxPath>, Void>)new e3(this));
  }
  
  public void t1(int paramInt1, int paramInt2, Intent paramIntent) {
    if (paramInt1 == 101 && paramInt2 == -1)
      t5((DropboxPath)H.d(paramIntent.getExtras(), "ARG_PATH", DropboxPath.class)); 
  }
  
  public final void t5(DropboxPath paramDropboxPath) {
    DropboxPath dropboxPath = paramDropboxPath.k(this.w, false);
    b b1 = B4();
    r5(dropboxPath, false, (h<k<DropboxPath>, Void>)new b(this, z4().q((String)b1.k().c()), dropboxPath));
  }
  
  public final void u5() {
    q5(true);
    c c1 = c.E(1500L, TimeUnit.MILLISECONDS, AndroidSchedulers.a()).B((a)new c3(this), (g)new d3(this));
    this.D.a(c1);
  }
  
  class TextEditActivity {}
  
  class TextEditActivity {}
  
  class TextEditActivity {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\android\activity\TextEditActivity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */