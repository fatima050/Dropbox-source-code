package com.dropbox.android.activity;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.View;
import com.dropbox.android.DropboxApplication;
import com.dropbox.android.activity.dialog.ExportProgressDialogFrag;
import com.dropbox.product.android.dbapp.verifyemail.VerifyEmailActivity;
import com.dropbox.product.dbapp.entry.DropboxLocalEntry;
import com.dropbox.product.dbapp.entry.LocalEntry;
import com.dropbox.product.dbapp.path.DropboxPath;
import dbxyzptlk.Bf.b;
import dbxyzptlk.Bf.d;
import dbxyzptlk.CC.p;
import dbxyzptlk.CC.v;
import dbxyzptlk.Df.x;
import dbxyzptlk.E6.G;
import dbxyzptlk.E6.H;
import dbxyzptlk.E6.X;
import dbxyzptlk.Ec.a;
import dbxyzptlk.Ec.g;
import dbxyzptlk.Ec.m;
import dbxyzptlk.It.k;
import dbxyzptlk.K6.a;
import dbxyzptlk.Nk.d;
import dbxyzptlk.P6.c;
import dbxyzptlk.P6.j;
import dbxyzptlk.P6.m;
import dbxyzptlk.P6.n;
import dbxyzptlk.Zw.f;
import dbxyzptlk.rs.a;
import dbxyzptlk.x9.j;
import dbxyzptlk.x9.q;
import java.util.ArrayList;
import java.util.List;

public class DropboxChooserActivity extends DropboxEntryPickerActivity implements H {
  public g l;
  
  public ArrayList<String> m;
  
  public String n;
  
  public String o;
  
  public void F0(j paramj) {
    M4("EXTRA_CHOOSER_RESULTS", new Bundle[] { paramj.i() });
  }
  
  public boolean F1(DropboxLocalEntry paramDropboxLocalEntry) {
    return !(J4() == b.CHOOSER_FILE && a.b((LocalEntry)paramDropboxLocalEntry));
  }
  
  public void I0(q.a parama, String paramString) {
    K4(parama, paramString);
  }
  
  public void I2(j paramj) {
    M4("EXTRA_CHOOSER_RESULTS", new Bundle[] { paramj.i() });
  }
  
  public final b J4() {
    if ("com.dropbox.android.intent.action.GET_PREVIEW".equals(this.o))
      return b.CHOOSER_PREVIEW_LINK; 
    if ("com.dropbox.android.intent.action.GET_DIRECT".equals(this.o))
      return b.CHOOSER_DIRECT_LINK; 
    if ("com.dropbox.android.intent.action.GET_CONTENT".equals(this.o))
      return b.CHOOSER_FILE; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Unrecognized action: ");
    stringBuilder.append(this.o);
    throw new RuntimeException(stringBuilder.toString());
  }
  
  public final void K4(q.a parama, String paramString) {
    if (a.b[parama.ordinal()] != 1) {
      b.k((d)this, paramString);
    } else {
      f3(b.h((d)this, paramString, f.verify_email, (View.OnClickListener)new G(this)));
    } 
  }
  
  public final void M4(String paramString, Bundle[] paramArrayOfBundle) {
    ComponentName componentName = getCallingActivity();
    m m = a.r().o("action", this.o);
    if (componentName != null) {
      String str = componentName.flattenToShortString();
    } else {
      componentName = null;
    } 
    m.o("caller", (String)componentName).i(this.l);
    Intent intent = new Intent();
    intent.addFlags(3);
    intent.putExtra(paramString, (Parcelable[])paramArrayOfBundle);
    setResult(-1, intent);
    finish();
  }
  
  public void P3(DropboxLocalEntry paramDropboxLocalEntry) {
    c c;
    p.o(paramDropboxLocalEntry);
    p.e(paramDropboxLocalEntry.q0() ^ true, "Assert failed.");
    X x = C4();
    p.o(x);
    x.p2().j0(paramDropboxLocalEntry.P().g());
    d d = x.D();
    b b = J4();
    int i = a.a[b.ordinal()];
    if (i != 1) {
      if (i != 2) {
        if (i == 3) {
          c = new c((Context)this, x.r0(), paramDropboxLocalEntry, x.p(), x.D(), this.n);
          c.c();
          ExportProgressDialogFrag.x2((j)c).u2((Context)this, getSupportFragmentManager());
          c.execute((Object[])new Void[0]);
        } else {
          throw new IllegalStateException(v.c("Unexpected result type: %s", new Object[] { b }));
        } 
      } else {
        (new m((Context)this, d, c.P(), this.n)).execute((Object[])new Void[0]);
      } 
    } else {
      (new n((Context)this, d, c.P(), this.n, x.B0())).execute((Object[])new Void[0]);
    } 
  }
  
  public void Q1(List<DropboxLocalEntry> paramList) {}
  
  public void X3(Bundle paramBundle, boolean paramBoolean) {
    super.X3(paramBundle, paramBoolean);
    if (paramBundle == null || paramBoolean) {
      ComponentName componentName = getCallingActivity();
      m m = a.q().o("app_key", this.n).l("client_version", getIntent().getIntExtra("EXTRA_SDK_VERSION", -1)).p("extensions", this.m);
      if (componentName != null) {
        String str = componentName.flattenToShortString();
      } else {
        componentName = null;
      } 
      m.o("caller", (String)componentName).i(this.l);
    } 
  }
  
  public void j2() {
    startActivity(a.d((Context)this, getIntent(), true, null));
  }
  
  public void onCreate(Bundle paramBundle) {
    this.l = DropboxApplication.b0((Context)this);
    Intent intent = getIntent();
    this.o = intent.getAction();
    String str = intent.getStringExtra("EXTRA_APP_KEY");
    this.n = str;
    if (v.b(str)) {
      super.onCreate(paramBundle);
      x.g((Context)this, "DEVELOPER ERROR: Forgot to supply App Key.");
      setResult(0);
      finish();
      return;
    } 
    ArrayList<String> arrayList = intent.getStringArrayListExtra("EXTRA_EXTENSIONS");
    this.m = arrayList;
    E4(arrayList);
    super.onCreate(paramBundle);
  }
  
  public void p2(k<DropboxPath> paramk, Context paramContext, j paramj) {
    Bundle bundle = paramj.i();
    Uri uri = paramk.d();
    bundle.putParcelable(j.b.l(), (Parcelable)uri);
    M4("EXTRA_CHOOSER_RESULTS", new Bundle[] { bundle });
  }
  
  public void s1(q.a parama, String paramString) {
    K4(parama, paramString);
  }
  
  class DropboxChooserActivity {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\android\activity\DropboxChooserActivity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */