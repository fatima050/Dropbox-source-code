package com.dropbox.android.shortcuts;

import android.content.Context;
import android.os.Bundle;
import androidx.core.graphics.drawable.IconCompat;
import com.dropbox.android.activity.DropboxBrowser;
import com.dropbox.android.activity.DropboxDirectoryPickerActivity;
import com.dropbox.dbapp.android.util.UIHelpers;
import com.dropbox.product.dbapp.path.DropboxPath;
import com.dropbox.product.dbapp.path.Path;
import dbxyzptlk.Ak.a;
import dbxyzptlk.CC.p;
import dbxyzptlk.Df.x;
import dbxyzptlk.Fc.eh;
import dbxyzptlk.Fc.fh;
import dbxyzptlk.Fc.gh;
import dbxyzptlk.Fq.f;
import dbxyzptlk.K6.a;
import dbxyzptlk.W1.e;
import dbxyzptlk.W1.f;
import dbxyzptlk.w6.V0;

public class CreateFolderShortcutActivity extends DropboxDirectoryPickerActivity implements f {
  public CreateFolderShortcutActivity() {
    super(V0.directory_shortcut_button, false);
  }
  
  public void J4() {
    L4();
  }
  
  public final void M4(DropboxPath paramDropboxPath) {
    (new eh()).k(paramDropboxPath.f()).l(gh.FOLDER).g(D4());
  }
  
  public void h0(DropboxPath paramDropboxPath) {
    p.o(l());
    String str = paramDropboxPath.o(l()).toString();
    e e = (new e.b(getApplicationContext(), str)).c(DropboxBrowser.A4(paramDropboxPath, l())).e(UIHelpers.f(getResources(), (Path)paramDropboxPath)).b(IconCompat.m((Context)this, a.ic_dig_content_dropbox_large_default)).a();
    if ("android.intent.action.CREATE_SHORTCUT".equals(getIntent().getAction())) {
      M4(paramDropboxPath);
      setResult(-1, f.a((Context)this, e));
    } else if (f.b((Context)this)) {
      M4(paramDropboxPath);
      f.c(getApplicationContext(), e, null);
    } else {
      (new fh()).k(gh.FOLDER).g(D4());
      x.f(getApplicationContext(), V0.folder_shortcut_permission_error_message).show();
    } 
    finish();
  }
  
  public void j2() {
    startActivity(a.d((Context)this, getIntent(), true, null));
  }
  
  public void onCreate(Bundle paramBundle) {
    I4(getResources().getString(V0.directory_shortcut_title_caption));
    super.onCreate(paramBundle);
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\android\shortcuts\CreateFolderShortcutActivity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */