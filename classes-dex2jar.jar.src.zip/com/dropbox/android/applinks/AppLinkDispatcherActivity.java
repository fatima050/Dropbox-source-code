package com.dropbox.android.applinks;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import com.dropbox.android.DropboxApplication;
import com.dropbox.android.activity.base.BaseIdentityActivity;
import com.dropbox.android.filemanager.ApiManager;
import com.dropbox.android.user.a;
import com.dropbox.common.android.ui.dialogs.DbxAlertDialogFragment;
import com.dropbox.common.util.LifecycleExecutor;
import dbxyzptlk.Ec.g;
import dbxyzptlk.Fc.x9;
import dbxyzptlk.Fc.y9;
import dbxyzptlk.Fc.z9;
import dbxyzptlk.K6.a;
import dbxyzptlk.O6.a;
import dbxyzptlk.O6.b;
import dbxyzptlk.O6.c;
import dbxyzptlk.O6.d;
import dbxyzptlk.T1.z;
import dbxyzptlk.bf.a;
import dbxyzptlk.ca.c;
import dbxyzptlk.df.b;
import dbxyzptlk.eH.D;
import dbxyzptlk.iH.b;
import dbxyzptlk.kI.a;
import dbxyzptlk.lH.g;
import dbxyzptlk.pc.d0;
import dbxyzptlk.sk.c;
import dbxyzptlk.w6.R0;
import dbxyzptlk.w6.V0;
import io.reactivex.android.schedulers.AndroidSchedulers;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.Callable;

public class AppLinkDispatcherActivity extends BaseIdentityActivity implements DbxAlertDialogFragment.c, a$b, a {
  public boolean d = false;
  
  public ApiManager e;
  
  public Uri f;
  
  public g g;
  
  public b h;
  
  public LifecycleExecutor i;
  
  public final b j = new b();
  
  private d0 E4() {
    a a1 = z4();
    return (a1 == null) ? null : a1.h();
  }
  
  public static Intent F4(Context paramContext, Uri paramUri) {
    Intent intent = new Intent(paramContext, AppLinkDispatcherActivity.class);
    intent.setData(paramUri);
    return intent;
  }
  
  public final void J4(Uri paramUri) {
    if (paramUri == null || paramUri.getPath() == null) {
      (new y9()).k("null").l(x9.UNKNOWN_LINK).g(DropboxApplication.b0((Context)this));
      finish();
      return;
    } 
    if (paramUri.getScheme().equals("dbx-applink"))
      this.h.b((Context)this, paramUri); 
    if (paramUri.getPath().startsWith("/l/")) {
      (new a((Context)this, this.e, paramUri.toString())).execute((Object[])new Void[0]);
      return;
    } 
    if (paramUri.getPath().startsWith("/a/")) {
      (new a((Context)this, this.e, paramUri.toString())).execute((Object[])new Void[0]);
      return;
    } 
    d0 d0 = E4();
    if (d0 == null) {
      (new y9()).k(paramUri.toString()).l(x9.SIGNED_OUT).g(DropboxApplication.b0((Context)this));
      K4();
      return;
    } 
    c c1 = c.a((Context)this, d0.l());
    d d = new d((Context)this, d0, DropboxApplication.v0((Context)this), c1);
    this.j.a(D.u((Callable)new a(d, paramUri)).J(a.c()).z(AndroidSchedulers.a()).G((g)new b(this, paramUri, d0)));
  }
  
  public final void K4() {
    this.d = true;
    startActivityForResult(a.a(getApplicationContext(), null, true), 1);
  }
  
  public void L0() {
    finish();
  }
  
  public final void L4(Uri paramUri, x9 paramx9) {
    g g1;
    d0 d0 = E4();
    if (d0 == null) {
      g1 = this.g;
    } else {
      g1 = g1.e();
    } 
    (new y9()).k(paramUri.toString()).l(paramx9).g(g1);
    this.i.a((Runnable)new c(this));
  }
  
  public void V() {
    L4(this.f, x9.REDIRECT);
  }
  
  public void X3(Bundle paramBundle, boolean paramBoolean) {
    if (!this.d)
      J4(this.f); 
  }
  
  public boolean k3(a parama) {
    return true;
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    if (w4())
      return; 
    setContentView(R0.app_link_dispatcher_activity);
    if (paramBundle != null)
      this.d = paramBundle.getBoolean("SIS_KEY_AWAITING_AUTH", false); 
    this.i = new LifecycleExecutor(getLifecycle());
    this.e = DropboxApplication.T((Context)this);
    this.g = DropboxApplication.b0((Context)this);
    this.h = DropboxApplication.S((Context)this);
    this.f = getIntent().getData();
    A4(paramBundle);
  }
  
  public void onDestroy() {
    super.onDestroy();
    this.j.d();
  }
  
  public void onSaveInstanceState(Bundle paramBundle) {
    super.onSaveInstanceState(paramBundle);
    paramBundle.putBoolean("SIS_KEY_AWAITING_AUTH", this.d);
  }
  
  public void t1(int paramInt1, int paramInt2, Intent paramIntent) {
    if (paramInt1 == 1) {
      if (paramInt2 == 0) {
        finish();
      } else if (paramInt2 == -1) {
        J4(this.f);
      } 
      this.d = false;
    } 
  }
  
  public void y0(Uri paramUri) {
    J4(paramUri);
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\android\applinks\AppLinkDispatcherActivity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */