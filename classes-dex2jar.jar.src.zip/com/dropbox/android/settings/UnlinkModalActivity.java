package com.dropbox.android.settings;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.o;
import com.dropbox.android.DropboxApplication;
import com.dropbox.android.activity.base.BaseUserActivity;
import com.dropbox.android.preference.a;
import com.dropbox.common.activity.BaseActivity;
import dbxyzptlk.DI.s;
import dbxyzptlk.pc.d0;
import dbxyzptlk.qI.s;
import dbxyzptlk.w6.Q0;
import dbxyzptlk.w6.R0;
import java.util.ArrayList;
import kotlin.Metadata;

@Metadata(d1 = {"\000F\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\020\016\n\002\b\007\n\002\030\002\n\002\b\006\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\006\b\007\030\000 #2\0020\0012\0020\0022\0020\003:\001$B\007¢\006\004\b\004\020\005J\031\020\t\032\0020\b2\b\020\007\032\004\030\0010\006H\024¢\006\004\b\t\020\nJ\035\020\016\032\0020\b2\f\020\r\032\b\022\004\022\0020\f0\013H\026¢\006\004\b\016\020\017J\017\020\020\032\0020\bH\026¢\006\004\b\020\020\005J\035\020\021\032\0020\b2\f\020\r\032\b\022\004\022\0020\f0\013H\026¢\006\004\b\021\020\017J\017\020\022\032\0020\bH\026¢\006\004\b\022\020\005J\031\020\025\032\0020\0242\b\020\023\032\004\030\0010\fH\026¢\006\004\b\025\020\026J\017\020\027\032\0020\bH\002¢\006\004\b\027\020\005J\017\020\030\032\0020\bH\002¢\006\004\b\030\020\005R\026\020\023\032\0020\f8\002@\002X.¢\006\006\n\004\b\031\020\032R\034\020\036\032\b\022\004\022\0020\0000\0338\002@\002X.¢\006\006\n\004\b\034\020\035R\026\020\"\032\0020\0378\002@\002X.¢\006\006\n\004\b \020!¨\006%"}, d2 = {"Lcom/dropbox/android/settings/UnlinkModalActivity;", "Lcom/dropbox/android/activity/base/BaseUserActivity;", "Lcom/dropbox/android/settings/UnlinkDialog$b;", "Lcom/dropbox/android/preference/a$a;", "<init>", "()V", "Landroid/os/Bundle;", "savedInstanceState", "Ldbxyzptlk/pI/D;", "onCreate", "(Landroid/os/Bundle;)V", "Ljava/util/ArrayList;", "", "userIds", "k", "(Ljava/util/ArrayList;)V", "Z2", "n", "o", "userId", "Ldbxyzptlk/pc/d0;", "t", "(Ljava/lang/String;)Ldbxyzptlk/pc/d0;", "E4", "D4", "g", "Ljava/lang/String;", "Lcom/dropbox/android/preference/a;", "h", "Lcom/dropbox/android/preference/a;", "unlinkHelper", "Lcom/dropbox/android/settings/UnlinkDialog;", "i", "Lcom/dropbox/android/settings/UnlinkDialog;", "unlinkDialog", "j", "a", "Dropbox_normalRelease"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class UnlinkModalActivity extends BaseUserActivity implements UnlinkDialog$b, a.a {
  public static final a j = new a(null);
  
  public static final int k = 8;
  
  public String g;
  
  public a<UnlinkModalActivity> h;
  
  public UnlinkDialog i;
  
  public final void D4() {
    Fragment fragment = getSupportFragmentManager().m0(LogoutSpinnerDialogFragment.s.a());
    if (fragment != null) {
      FragmentManager fragmentManager = getSupportFragmentManager();
      s.g(fragmentManager, "getSupportFragmentManager(...)");
      o o = fragmentManager.q();
      s.g(o, "beginTransaction()");
      o.t(fragment);
      o.k();
    } 
  }
  
  public final void E4() {
    FragmentManager fragmentManager = getSupportFragmentManager();
    s.g(fragmentManager, "getSupportFragmentManager(...)");
    o o = fragmentManager.q();
    s.g(o, "beginTransaction()");
    o.c(Q0.fragment_container, (Fragment)new LogoutSpinnerDialogFragment(), LogoutSpinnerDialogFragment.s.a());
    o.k();
  }
  
  public void Z2() {
    UnlinkDialog unlinkDialog2 = this.i;
    UnlinkDialog unlinkDialog1 = unlinkDialog2;
    if (unlinkDialog2 == null) {
      s.u("unlinkDialog");
      unlinkDialog1 = null;
    } 
    unlinkDialog1.dismiss();
    finish();
  }
  
  public void k(ArrayList<String> paramArrayList) {
    s.h(paramArrayList, "userIds");
    E4();
    a<UnlinkModalActivity> a2 = this.h;
    a<UnlinkModalActivity> a1 = a2;
    if (a2 == null) {
      s.u("unlinkHelper");
      a1 = null;
    } 
    a1.g(paramArrayList);
  }
  
  public void n(ArrayList<String> paramArrayList) {
    s.h(paramArrayList, "userIds");
    a<UnlinkModalActivity> a2 = this.h;
    a<UnlinkModalActivity> a1 = a2;
    if (a2 == null) {
      s.u("unlinkHelper");
      a1 = null;
    } 
    a1.k(paramArrayList);
  }
  
  public void o() {
    a<UnlinkModalActivity> a2 = this.h;
    a<UnlinkModalActivity> a1 = a2;
    if (a2 == null) {
      s.u("unlinkHelper");
      a1 = null;
    } 
    a1.j();
    D4();
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    if (w4())
      return; 
    setContentView(R0.unlink_modal_activity);
    Bundle bundle = getIntent().getExtras();
    if (bundle != null) {
      String str = bundle.getString("EXTRA_USER_ID");
      if (str != null) {
        String str1;
        this.g = str;
        String str4 = bundle.getString("EXTRA_TITLE");
        String str5 = bundle.getString("EXTRA_MESSAGE");
        DropboxApplication.a a1 = DropboxApplication.h;
        this.h = new a((Activity)this, a1.q0((Context)this), a1.l((Context)this));
        UnlinkDialog.a a2 = UnlinkDialog.s;
        String str3 = this.g;
        str = null;
        String str2 = str3;
        if (str3 == null) {
          s.u("userId");
          str2 = null;
        } 
        this.i = a2.c((BaseActivity)this, s.g((Object[])new String[] { str2 }, ), str5, str4);
        A4(paramBundle);
        UnlinkDialog unlinkDialog = this.i;
        if (unlinkDialog == null) {
          s.u("unlinkDialog");
          str1 = str;
        } 
        str1.show(getSupportFragmentManager(), "com.dropbox.android.settings.UnlinkModalActivity.kt");
        return;
      } 
      throw new IllegalArgumentException("Required value was null.");
    } 
    throw new IllegalArgumentException("Required value was null.");
  }
  
  public d0 t(String paramString) {
    d0 d0 = z4().q(paramString);
    if (d0 != null)
      return d0; 
    throw new IllegalArgumentException("Required value was null.");
  }
  
  class UnlinkModalActivity {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\android\settings\UnlinkModalActivity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */