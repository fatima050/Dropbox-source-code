package com.dropbox.dbapp.android.send_to;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import androidx.activity.ComponentActivity;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.s;
import androidx.lifecycle.t;
import com.dropbox.common.android.ui.widgets.IndeterminateProgressBarDialogFragment;
import dbxyzptlk.CI.a;
import dbxyzptlk.CI.p;
import dbxyzptlk.DI.L;
import dbxyzptlk.DI.s;
import dbxyzptlk.U2.i;
import dbxyzptlk.V1.c;
import dbxyzptlk.bK.J;
import dbxyzptlk.bK.h;
import dbxyzptlk.dk.S;
import dbxyzptlk.mn.f;
import dbxyzptlk.mn.j;
import dbxyzptlk.mn.l;
import dbxyzptlk.pI.j;
import dbxyzptlk.yj.c;
import kotlin.Metadata;

@Metadata(d1 = {"\000*\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\007\n\002\030\002\n\002\b\007\b\007\030\000 \0272\0020\001:\002\n\022B\007¢\006\004\b\002\020\003J\031\020\007\032\0020\0062\b\020\005\032\004\030\0010\004H\024¢\006\004\b\007\020\bR\"\020\020\032\0020\t8\006@\006X.¢\006\022\n\004\b\n\020\013\032\004\b\f\020\r\"\004\b\016\020\017R\033\020\026\032\0020\0218BX\002¢\006\f\n\004\b\022\020\023\032\004\b\024\020\025¨\006\030"}, d2 = {"Lcom/dropbox/dbapp/android/send_to/ExternalFileUploadActivity;", "Landroidx/fragment/app/FragmentActivity;", "<init>", "()V", "Landroid/os/Bundle;", "savedInstanceState", "Ldbxyzptlk/pI/D;", "onCreate", "(Landroid/os/Bundle;)V", "Landroidx/lifecycle/t$b;", "a", "Landroidx/lifecycle/t$b;", "u4", "()Landroidx/lifecycle/t$b;", "setViewModelFactory", "(Landroidx/lifecycle/t$b;)V", "viewModelFactory", "Lcom/dropbox/dbapp/android/send_to/c;", "b", "Ldbxyzptlk/pI/j;", "t4", "()Lcom/dropbox/dbapp/android/send_to/c;", "viewModel", "c", "dbapp_send_to_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class ExternalFileUploadActivity extends FragmentActivity {
  public static final a c = new a(null);
  
  public static final int d = 8;
  
  public t.b a;
  
  public final j b;
  
  public ExternalFileUploadActivity() {
    f f = new f(this);
    this.b = (j)new s(L.b(c.class), (a)new d((ComponentActivity)this), (a)f, (a)new e(null, (ComponentActivity)this));
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    if (c.j((Activity)this, null, 1, null)) {
      ((b)c.b((Context)this, b.class, c.d((Activity)this), false)).r8(this);
      setContentView(j.external_file_upload_activity);
      IndeterminateProgressBarDialogFragment.a a1 = IndeterminateProgressBarDialogFragment.s;
      String str = getString(l.external_file_upload_wait);
      s.g(str, "getString(...)");
      IndeterminateProgressBarDialogFragment indeterminateProgressBarDialogFragment = a1.b(str);
      FragmentManager fragmentManager = getSupportFragmentManager();
      s.g(fragmentManager, "getSupportFragmentManager(...)");
      a1.c(fragmentManager, indeterminateProgressBarDialogFragment);
      h.d((J)i.a((LifecycleOwner)this), null, null, (p)new c(this, null), 3, null);
      Intent intent = getIntent();
      if (intent != null) {
        Object object = c.b(intent, "EXTRA_UPLOAD_CONTENT_URI", Uri.class);
        if (object != null) {
          object = object;
          f f = (f)S.b(intent, "EXTRA_POST_ACTION", f.class);
          t4().G((Context)this, (Uri)object, f);
        } else {
          throw new IllegalArgumentException("Required value was null.");
        } 
      } 
      return;
    } 
    finish();
  }
  
  public final c t4() {
    return (c)this.b.getValue();
  }
  
  public final t.b u4() {
    t.b b1 = this.a;
    if (b1 != null)
      return b1; 
    s.u("viewModelFactory");
    return null;
  }
  
  class ExternalFileUploadActivity {}
  
  class ExternalFileUploadActivity {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\dbapp\android\send_to\ExternalFileUploadActivity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */