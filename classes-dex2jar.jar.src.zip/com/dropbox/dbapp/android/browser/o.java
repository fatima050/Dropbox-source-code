package com.dropbox.dbapp.android.browser;

import com.dropbox.product.dbapp.path.SharedLinkPath;
import dbxyzptlk.Ec.g;
import dbxyzptlk.Ij.s;
import dbxyzptlk.Km.c;
import dbxyzptlk.Om.a;
import dbxyzptlk.Ow.g;
import dbxyzptlk.Ry.c;
import dbxyzptlk.Sq.k;
import dbxyzptlk.V6.c;
import dbxyzptlk.Zy.b;
import dbxyzptlk.dk.x;
import dbxyzptlk.ef.E;
import dbxyzptlk.iy.A;
import dbxyzptlk.iz.a;
import dbxyzptlk.sh.g;
import dbxyzptlk.xx.g;
import kotlin.Metadata;

@Metadata(d1 = {"\000\001\n\002\030\002\n\002\020\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\004\bf\030\0002\0020\001J\017\020\003\032\0020\002H&¢\006\004\b\003\020\004J\025\020\007\032\b\022\004\022\0020\0060\005H&¢\006\004\b\007\020\bJ\017\020\n\032\0020\tH&¢\006\004\b\n\020\013J\017\020\r\032\0020\fH&¢\006\004\b\r\020\016J\017\020\020\032\0020\017H&¢\006\004\b\020\020\021J\017\020\023\032\0020\022H&¢\006\004\b\023\020\024J\017\020\026\032\0020\025H&¢\006\004\b\026\020\027J\017\020\031\032\0020\030H&¢\006\004\b\031\020\032J\017\020\034\032\0020\033H&¢\006\004\b\034\020\035J\017\020\037\032\0020\036H&¢\006\004\b\037\020 J\017\020\"\032\0020!H&¢\006\004\b\"\020#J\017\020%\032\0020$H&¢\006\004\b%\020&J\017\020(\032\0020'H&¢\006\004\b(\020)R\024\020-\032\0020*8&X¦\004¢\006\006\032\004\b+\020,R\024\0201\032\0020.8&X¦\004¢\006\006\032\004\b/\0200R\024\0205\032\002028&X¦\004¢\006\006\032\004\b3\0204ø\001\000\002\006\n\004\b!0\001¨\0066À\006\001"}, d2 = {"Lcom/dropbox/dbapp/android/browser/o;", "", "Ldbxyzptlk/iy/A;", "O3", "()Ldbxyzptlk/iy/A;", "Ldbxyzptlk/Ow/g;", "Lcom/dropbox/product/dbapp/path/SharedLinkPath;", "X4", "()Ldbxyzptlk/Ow/g;", "Ldbxyzptlk/xx/g;", "Q", "()Ldbxyzptlk/xx/g;", "Ldbxyzptlk/Ec/g;", "d", "()Ldbxyzptlk/Ec/g;", "Ldbxyzptlk/ef/E;", "X", "()Ldbxyzptlk/ef/E;", "Lcom/dropbox/dbapp/android/browser/a$a;", "g3", "()Lcom/dropbox/dbapp/android/browser/a$a;", "Ldbxyzptlk/Sq/k;", "i3", "()Ldbxyzptlk/Sq/k;", "Ldbxyzptlk/Om/a;", "N1", "()Ldbxyzptlk/Om/a;", "Ldbxyzptlk/sh/g;", "M1", "()Ldbxyzptlk/sh/g;", "Ldbxyzptlk/iz/a;", "U8", "()Ldbxyzptlk/iz/a;", "Ldbxyzptlk/Zy/b;", "b2", "()Ldbxyzptlk/Zy/b;", "Ldbxyzptlk/dk/x;", "v0", "()Ldbxyzptlk/dk/x;", "Ldbxyzptlk/Ij/s;", "Z", "()Ldbxyzptlk/Ij/s;", "Ldbxyzptlk/Km/c;", "Z0", "()Ldbxyzptlk/Km/c;", "sharedLinkPathHelperFactory", "Ldbxyzptlk/Ry/c;", "M", "()Ldbxyzptlk/Ry/c;", "pathNameResolver", "Ldbxyzptlk/V6/c;", "I", "()Ldbxyzptlk/V6/c;", "browserIntentProvider", "dbapp_browser_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
public interface o {
  c I();
  
  c M();
  
  g M1();
  
  a N1();
  
  A O3();
  
  g Q();
  
  a U8();
  
  E X();
  
  g<SharedLinkPath> X4();
  
  s Z();
  
  c Z0();
  
  b b2();
  
  g d();
  
  a.a g3();
  
  k i3();
  
  x v0();
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\dbapp\android\browser\o.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */