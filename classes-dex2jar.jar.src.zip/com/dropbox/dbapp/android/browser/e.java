package com.dropbox.dbapp.android.browser;

import dbxyzptlk.DI.s;
import dbxyzptlk.rh.b;
import dbxyzptlk.rh.i;
import dbxyzptlk.sh.b;
import dbxyzptlk.wI.b;
import kotlin.Metadata;

@Metadata(d1 = {"\000\"\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\006\bÇ\002\030\0002\0020\001:\001\013B\t\b\002¢\006\004\b\002\020\003J\027\020\007\032\0020\0062\006\020\005\032\0020\004H\007¢\006\004\b\007\020\bR&\020\016\032\b\022\004\022\0020\0060\t8\006X\004¢\006\022\n\004\b\007\020\n\022\004\b\r\020\003\032\004\b\013\020\f¨\006\017"}, d2 = {"Lcom/dropbox/dbapp/android/browser/e;", "", "<init>", "()V", "Ldbxyzptlk/sh/b;", "interactor", "Lcom/dropbox/dbapp/android/browser/e$a;", "b", "(Ldbxyzptlk/sh/b;)Lcom/dropbox/dbapp/android/browser/e$a;", "Ldbxyzptlk/rh/a;", "Ldbxyzptlk/rh/a;", "a", "()Ldbxyzptlk/rh/a;", "getFocusedOnboardingEmptyFolderFeatureGates$annotations", "focusedOnboardingEmptyFolderFeatureGates", "dbapp_browser_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class e {
  public static final e a = new e();
  
  public static final dbxyzptlk.rh.a<a> b = new dbxyzptlk.rh.a("mobile_activation_android_focused_folder_creation", a.class);
  
  public static final int c = 8;
  
  public static final dbxyzptlk.rh.a<a> a() {
    return b;
  }
  
  public static final a b(b paramb) {
    a a1;
    s.h(paramb, "interactor");
    i i = paramb.k(b);
    if (i instanceof i.b) {
      a1 = (a)((i.b)i).a();
    } else {
      a1 = a.OFF;
    } 
    return a1;
  }
  
  @Metadata(d1 = {"\000\030\n\002\030\002\n\002\020\020\n\002\030\002\n\002\b\002\n\002\020\013\n\002\b\007\b\002\030\0002\b\022\004\022\0020\0000\0012\0020\002B\t\b\002¢\006\004\b\003\020\004J\r\020\006\032\0020\005¢\006\004\b\006\020\007j\002\b\bj\002\b\tj\002\b\nj\002\b\013¨\006\f"}, d2 = {"Lcom/dropbox/dbapp/android/browser/e$a;", "", "Ldbxyzptlk/rh/b;", "<init>", "(Ljava/lang/String;I)V", "", "isEnabled", "()Z", "CONTROL", "OFF", "V1", "V2", "dbapp_browser_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
  public enum a implements b {
    CONTROL, OFF, V1, V2;
    
    private static final dbxyzptlk.wI.a $ENTRIES;
    
    private static final a[] $VALUES;
    
    static {
      a[] arrayOfA = a();
      $VALUES = arrayOfA;
      $ENTRIES = b.a((Enum[])arrayOfA);
    }
    
    public static dbxyzptlk.wI.a<a> getEntries() {
      return $ENTRIES;
    }
    
    public String getCaseSensitiveVariantName() {
      return b.a.a(this);
    }
    
    public final boolean isEnabled() {
      return (this == V1 || this == V2);
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\dbapp\android\browser\e.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */