package com.dropbox.dbapp.android.client_deprecation.internal.devicefull;

import androidx.lifecycle.o;
import com.squareup.anvil.annotations.ContributesMultibinding;
import dbxyzptlk.CI.p;
import dbxyzptlk.DI.s;
import dbxyzptlk.Ec.d;
import dbxyzptlk.Ij.s;
import dbxyzptlk.Jh.d;
import dbxyzptlk.U2.v;
import dbxyzptlk.U2.w;
import dbxyzptlk.Xm.e;
import dbxyzptlk.eK.M;
import dbxyzptlk.eK.S;
import dbxyzptlk.eK.i;
import dbxyzptlk.eK.k;
import dbxyzptlk.hd.d;
import dbxyzptlk.hd.g;
import dbxyzptlk.hd.h;
import dbxyzptlk.hd.i;
import kotlin.Metadata;

@ContributesMultibinding(scope = d.class)
@Metadata(d1 = {"\0006\n\002\030\002\n\002\030\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\030\002\n\000\n\002\030\002\n\002\b\006\n\002\030\002\n\002\030\002\n\002\b\t\b\007\030\000 \0322\0020\001:\003\033\034\017B!\b\007\022\006\020\003\032\0020\002\022\006\020\005\032\0020\004\022\006\020\007\032\0020\006¢\006\004\b\b\020\tJ\025\020\r\032\0020\f2\006\020\013\032\0020\n¢\006\004\b\r\020\016R\024\020\005\032\0020\0048\002X\004¢\006\006\n\004\b\017\020\020R\024\020\007\032\0020\0068\002X\004¢\006\006\n\004\b\021\020\022R\035\020\031\032\b\022\004\022\0020\0240\0238\006¢\006\f\n\004\b\025\020\026\032\004\b\027\020\030¨\006\035"}, d2 = {"Lcom/dropbox/dbapp/android/client_deprecation/internal/devicefull/b;", "Ldbxyzptlk/U2/v;", "Landroidx/lifecycle/o;", "savedStateHandle", "Ldbxyzptlk/Xm/e;", "deviceStorageChecker", "Ldbxyzptlk/Ij/s;", "udcl", "<init>", "(Landroidx/lifecycle/o;Ldbxyzptlk/Xm/e;Ldbxyzptlk/Ij/s;)V", "Lcom/dropbox/dbapp/android/client_deprecation/internal/devicefull/b$b;", "event", "Ldbxyzptlk/pI/D;", "H", "(Lcom/dropbox/dbapp/android/client_deprecation/internal/devicefull/b$b;)V", "c", "Ldbxyzptlk/Xm/e;", "d", "Ldbxyzptlk/Ij/s;", "Ldbxyzptlk/eK/S;", "Lcom/dropbox/dbapp/android/client_deprecation/internal/devicefull/b$c;", "e", "Ldbxyzptlk/eK/S;", "G", "()Ldbxyzptlk/eK/S;", "state", "f", "a", "b", "dbapp_client_deprecation_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class b extends v {
  public static final a f = new a(null);
  
  public static final int g = 8;
  
  public final e c;
  
  public final s d;
  
  public final S<c> e;
  
  public b(o paramo, e parame, s params) {
    this.c = parame;
    this.d = params;
    this.e = k.m0((i)new d(k.a0(parame.a(), (p)new e(this, null))), w.a((v)this), M.a.d(), new c(true));
  }
  
  public final S<c> G() {
    return this.e;
  }
  
  public final void H(b paramb) {
    d d;
    s.h(paramb, "event");
    if (paramb instanceof b.b) {
      d = (new d()).k("device_storage_full").l(h.STORAGE_SETTINGS);
      s.m(this.d, (d)d, 0L, null, 6, null);
    } else if (d instanceof b.a) {
      g g = (new g()).k("device_storage_full").l(i.USER_EXITED);
      s.m(this.d, (d)g, 0L, null, 6, null);
    } 
  }
  
  class b {}
  
  class b {}
  
  class b {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\dbapp\android\client_deprecation\internal\devicefull\b.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */