package com.dropbox.dbapp.android.client_deprecation.internal.devicefull;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import androidx.activity.ComponentActivity;
import androidx.lifecycle.e;
import androidx.lifecycle.s;
import androidx.lifecycle.t;
import com.dropbox.common.activity.BaseActivity;
import dbxyzptlk.CI.a;
import dbxyzptlk.CI.p;
import dbxyzptlk.DI.L;
import dbxyzptlk.DI.s;
import dbxyzptlk.F0.c;
import dbxyzptlk.Xm.a;
import dbxyzptlk.e.r;
import dbxyzptlk.f.e;
import dbxyzptlk.pI.j;
import dbxyzptlk.pI.k;
import dbxyzptlk.yj.c;
import kotlin.Metadata;

@Metadata(d1 = {"\000>\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\007\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\006\n\002\030\002\n\002\b\002\b\007\030\0002\0020\0012\0020\002B\007¢\006\004\b\003\020\004J\031\020\b\032\0020\0072\b\020\006\032\004\030\0010\005H\024¢\006\004\b\b\020\tR\"\020\021\032\0020\n8\006@\006X.¢\006\022\n\004\b\013\020\f\032\004\b\r\020\016\"\004\b\017\020\020R\033\020\027\032\0020\0228BX\002¢\006\f\n\004\b\023\020\024\032\004\b\025\020\026R\033\020\034\032\0020\0308BX\002¢\006\f\n\004\b\031\020\024\032\004\b\032\020\033R\024\020\036\032\0020\n8VX\004¢\006\006\032\004\b\035\020\016¨\006!²\006\f\020 \032\0020\0378\nX\002"}, d2 = {"Lcom/dropbox/dbapp/android/client_deprecation/internal/devicefull/DeviceFullActivity;", "Lcom/dropbox/common/activity/BaseActivity;", "Landroidx/lifecycle/e;", "<init>", "()V", "Landroid/os/Bundle;", "savedInstanceState", "Ldbxyzptlk/pI/D;", "onCreate", "(Landroid/os/Bundle;)V", "Landroidx/lifecycle/t$b;", "c", "Landroidx/lifecycle/t$b;", "y4", "()Landroidx/lifecycle/t$b;", "B4", "(Landroidx/lifecycle/t$b;)V", "daggerViewModelProviderFactory", "Lcom/dropbox/dbapp/android/client_deprecation/internal/devicefull/b;", "d", "Ldbxyzptlk/pI/j;", "A4", "()Lcom/dropbox/dbapp/android/client_deprecation/internal/devicefull/b;", "viewModel", "Landroid/content/Intent;", "e", "z4", "()Landroid/content/Intent;", "launchAppIntent", "getDefaultViewModelProviderFactory", "defaultViewModelProviderFactory", "Lcom/dropbox/dbapp/android/client_deprecation/internal/devicefull/b$c;", "state", "dbapp_client_deprecation_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class DeviceFullActivity extends BaseActivity implements e {
  public t.b c;
  
  public final j d;
  
  public final j e;
  
  public DeviceFullActivity() {
    c c = new c((ComponentActivity)this);
    this.d = (j)new s(L.b(b.class), (a)new d((ComponentActivity)this), (a)c, (a)new e(null, (ComponentActivity)this));
    this.e = k.a((a)new a(this));
  }
  
  public final b A4() {
    return (b)this.d.getValue();
  }
  
  public final void B4(t.b paramb) {
    s.h(paramb, "<set-?>");
    this.c = paramb;
  }
  
  public t.b getDefaultViewModelProviderFactory() {
    return y4();
  }
  
  public void onCreate(Bundle paramBundle) {
    r.c((ComponentActivity)this, null, null, 3, null);
    super.onCreate(paramBundle);
    ((a)c.b((Context)this, a.class, c.d((Activity)this), false)).L0(this);
    e.b((ComponentActivity)this, null, (p)c.c(2111516849, true, new b(this)), 1, null);
  }
  
  public final t.b y4() {
    t.b b1 = this.c;
    if (b1 != null)
      return b1; 
    s.u("daggerViewModelProviderFactory");
    return null;
  }
  
  public final Intent z4() {
    return (Intent)this.e.getValue();
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\dbapp\android\client_deprecation\internal\devicefull\DeviceFullActivity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */