package com.dropbox.dbapp.android.client_deprecation.internal.alpha;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import androidx.activity.ComponentActivity;
import com.dropbox.common.activity.BaseActivity;
import dbxyzptlk.CI.p;
import dbxyzptlk.DI.s;
import dbxyzptlk.F0.c;
import dbxyzptlk.Oh.s;
import dbxyzptlk.Ym.e;
import dbxyzptlk.e.r;
import dbxyzptlk.f.e;
import dbxyzptlk.jj.a;
import dbxyzptlk.yj.c;
import kotlin.Metadata;

@Metadata(d1 = {"\0006\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\020\013\n\002\b\002\n\002\020\016\n\002\b\b\n\002\030\002\n\002\b\n\b\007\030\000 \0362\0020\0012\0020\002:\001\037B\007¢\006\004\b\003\020\004J\031\020\b\032\0020\0072\b\020\006\032\004\030\0010\005H\024¢\006\004\b\b\020\tJ\017\020\013\032\0020\nH\026¢\006\004\b\013\020\fR(\020\025\032\0020\r8\006@\006X.¢\006\030\n\004\b\016\020\017\022\004\b\024\020\004\032\004\b\020\020\021\"\004\b\022\020\023R\"\020\035\032\0020\0268\006@\006X.¢\006\022\n\004\b\027\020\030\032\004\b\031\020\032\"\004\b\033\020\034¨\006 "}, d2 = {"Lcom/dropbox/dbapp/android/client_deprecation/internal/alpha/AlphaBuildUpgradeActivity;", "Lcom/dropbox/common/activity/BaseActivity;", "Ldbxyzptlk/Oh/s;", "<init>", "()V", "Landroid/os/Bundle;", "savedInstanceState", "Ldbxyzptlk/pI/D;", "onCreate", "(Landroid/os/Bundle;)V", "", "a0", "()Z", "", "c", "Ljava/lang/String;", "w4", "()Ljava/lang/String;", "y4", "(Ljava/lang/String;)V", "getAppVersion$annotations", "appVersion", "Ldbxyzptlk/jj/a;", "d", "Ldbxyzptlk/jj/a;", "x4", "()Ldbxyzptlk/jj/a;", "z4", "(Ldbxyzptlk/jj/a;)V", "remoteConfig", "e", "a", "dbapp_client_deprecation_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class AlphaBuildUpgradeActivity extends BaseActivity implements s {
  public static final a e = new a(null);
  
  public static final int f = 8;
  
  public String c;
  
  public a d;
  
  public boolean a0() {
    return false;
  }
  
  public void onCreate(Bundle paramBundle) {
    r.c((ComponentActivity)this, null, null, 3, null);
    super.onCreate(paramBundle);
    ((e)c.b((Context)this, e.class, c.d((Activity)this), false)).u1(this);
    e.b((ComponentActivity)this, null, (p)c.c(-716326754, true, new b(this)), 1, null);
  }
  
  public final String w4() {
    String str = this.c;
    if (str != null)
      return str; 
    s.u("appVersion");
    return null;
  }
  
  public final a x4() {
    a a1 = this.d;
    if (a1 != null)
      return a1; 
    s.u("remoteConfig");
    return null;
  }
  
  public final void y4(String paramString) {
    s.h(paramString, "<set-?>");
    this.c = paramString;
  }
  
  public final void z4(a parama) {
    s.h(parama, "<set-?>");
    this.d = parama;
  }
  
  class AlphaBuildUpgradeActivity {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\dbapp\android\client_deprecation\internal\alpha\AlphaBuildUpgradeActivity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */