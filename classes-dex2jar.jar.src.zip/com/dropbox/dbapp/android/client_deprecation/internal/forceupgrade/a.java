package com.dropbox.dbapp.android.client_deprecation.internal.forceupgrade;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.RepeatOnLifecycleKt;
import androidx.lifecycle.f;
import com.dropbox.dbapp.android.client_deprecation.internal.alpha.AlphaBuildUpgradeActivity;
import com.dropbox.dbapp.android.client_deprecation.internal.devicefull.DeviceFullActivity;
import dbxyzptlk.CI.l;
import dbxyzptlk.CI.p;
import dbxyzptlk.DI.s;
import dbxyzptlk.U2.i;
import dbxyzptlk.Ym.c;
import dbxyzptlk.bK.J;
import dbxyzptlk.bK.h;
import dbxyzptlk.pI.D;
import dbxyzptlk.pI.p;
import dbxyzptlk.tI.d;
import dbxyzptlk.uI.c;
import dbxyzptlk.vI.f;
import dbxyzptlk.vI.l;
import kotlin.Metadata;

@Metadata(d1 = {"\000>\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\013\n\002\b\005\n\002\030\002\n\002\b\005\n\002\030\002\n\000\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\000\n\002\b\b\b\000\030\0002\0020\001B?\022\032\020\006\032\026\022\f\022\n\022\006\b\001\022\0020\0040\003\022\004\022\0020\0050\002\022\032\020\007\032\026\022\f\022\n\022\006\b\001\022\0020\0040\003\022\004\022\0020\0050\002¢\006\004\b\b\020\tJ\027\020\f\032\0020\0132\006\020\n\032\0020\004H\026¢\006\004\b\f\020\rJ\027\020\016\032\0020\0132\006\020\n\032\0020\004H\026¢\006\004\b\016\020\rJ\027\020\017\032\0020\0132\006\020\n\032\0020\004H\026¢\006\004\b\017\020\rJ\027\020\020\032\0020\0132\006\020\n\032\0020\004H\026¢\006\004\b\020\020\rJ;\020\030\032\0020\0132\006\020\022\032\0020\0212\"\020\027\032\036\b\001\022\004\022\0020\024\022\n\022\b\022\004\022\0020\0130\025\022\006\022\004\030\0010\0260\023H\026¢\006\004\b\030\020\031R.\020\006\032\026\022\f\022\n\022\006\b\001\022\0020\0040\003\022\004\022\0020\0050\0028\026X\004¢\006\f\n\004\b\020\020\032\032\004\b\033\020\034R.\020\007\032\026\022\f\022\n\022\006\b\001\022\0020\0040\003\022\004\022\0020\0050\0028\026X\004¢\006\f\n\004\b\017\020\032\032\004\b\035\020\034¨\006\036"}, d2 = {"Lcom/dropbox/dbapp/android/client_deprecation/internal/forceupgrade/a;", "Ldbxyzptlk/Ym/c;", "Lkotlin/Function1;", "Ljava/lang/Class;", "Landroid/app/Activity;", "", "shouldShowAlphaBuildLockout", "canShowDeprecationLockout", "<init>", "(Ldbxyzptlk/CI/l;Ldbxyzptlk/CI/l;)V", "activity", "Ldbxyzptlk/pI/D;", "d", "(Landroid/app/Activity;)V", "f", "b", "a", "Landroidx/lifecycle/LifecycleOwner;", "lifecycleOwner", "Lkotlin/Function2;", "Ldbxyzptlk/bK/J;", "Ldbxyzptlk/tI/d;", "", "action", "g", "(Landroidx/lifecycle/LifecycleOwner;Ldbxyzptlk/CI/p;)V", "Ldbxyzptlk/CI/l;", "e", "()Ldbxyzptlk/CI/l;", "c", "dbapp_client_deprecation_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class a implements c {
  public final l<Class<? extends Activity>, Boolean> a;
  
  public final l<Class<? extends Activity>, Boolean> b;
  
  public a(l<? super Class<? extends Activity>, Boolean> paraml1, l<? super Class<? extends Activity>, Boolean> paraml2) {
    this.a = (l)paraml1;
    this.b = (l)paraml2;
  }
  
  public void a(Activity paramActivity) {
    s.h(paramActivity, "activity");
    paramActivity.finish();
    paramActivity.startActivity(new Intent((Context)paramActivity, DeviceFullActivity.class));
  }
  
  public void b(Activity paramActivity) {
    s.h(paramActivity, "activity");
    paramActivity.finish();
    paramActivity.startActivity(new Intent((Context)paramActivity, AlphaBuildUpgradeActivity.class));
  }
  
  public l<Class<? extends Activity>, Boolean> c() {
    return this.b;
  }
  
  public void d(Activity paramActivity) {
    s.h(paramActivity, "activity");
    paramActivity.finish();
    paramActivity.startActivity(ClientDeprecationUpdateActivity.j.a((Context)paramActivity, true));
  }
  
  public l<Class<? extends Activity>, Boolean> e() {
    return this.a;
  }
  
  public void f(Activity paramActivity) {
    s.h(paramActivity, "activity");
    paramActivity.startActivity(ClientDeprecationUpdateActivity.j.a((Context)paramActivity, false));
  }
  
  public void g(LifecycleOwner paramLifecycleOwner, p<? super J, ? super d<? super D>, ? extends Object> paramp) {
    s.h(paramLifecycleOwner, "lifecycleOwner");
    s.h(paramp, "action");
    h.d((J)i.a(paramLifecycleOwner), null, null, new a(paramLifecycleOwner, paramp, null), 3, null);
  }
  
  @f(c = "com.dropbox.dbapp.android.client_deprecation.internal.forceupgrade.RealClientDeprecationActions$launchLifecycleScopeWhenCreated$1", f = "RealClientDeprecationActions.kt", l = {42}, m = "invokeSuspend")
  @Metadata(d1 = {"\000\f\n\002\030\002\n\002\030\002\n\002\b\002\020\002\032\0020\001*\0020\000H@¢\006\004\b\002\020\003"}, d2 = {"Ldbxyzptlk/bK/J;", "Ldbxyzptlk/pI/D;", "<anonymous>", "(Ldbxyzptlk/bK/J;)V"}, k = 3, mv = {1, 9, 0})
  public static final class a extends l implements p<J, d<? super D>, Object> {
    public int t;
    
    public final LifecycleOwner u;
    
    public final p<J, d<? super D>, Object> v;
    
    public a(LifecycleOwner param1LifecycleOwner, p<? super J, ? super d<? super D>, ? extends Object> param1p, d<? super a> param1d) {
      super(2, param1d);
    }
    
    public final d<D> create(Object param1Object, d<?> param1d) {
      return (d<D>)new a(this.u, this.v, (d)param1d);
    }
    
    public final Object invoke(J param1J, d<? super D> param1d) {
      return ((a)create(param1J, param1d)).invokeSuspend(D.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = c.g();
      int i = this.t;
      if (i != 0) {
        if (i == 1) {
          p.b(param1Object);
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        p.b(param1Object);
        LifecycleOwner lifecycleOwner = this.u;
        param1Object = f.b.CREATED;
        a a1 = new a(this.v, null);
        this.t = 1;
        if (RepeatOnLifecycleKt.b(lifecycleOwner, (f.b)param1Object, a1, (d)this) == object)
          return object; 
      } 
      return D.a;
    }
    
    @f(c = "com.dropbox.dbapp.android.client_deprecation.internal.forceupgrade.RealClientDeprecationActions$launchLifecycleScopeWhenCreated$1$1", f = "RealClientDeprecationActions.kt", l = {43}, m = "invokeSuspend")
    @Metadata(d1 = {"\000\f\n\002\030\002\n\002\030\002\n\002\b\002\020\002\032\0020\001*\0020\000H@¢\006\004\b\002\020\003"}, d2 = {"Ldbxyzptlk/bK/J;", "Ldbxyzptlk/pI/D;", "<anonymous>", "(Ldbxyzptlk/bK/J;)V"}, k = 3, mv = {1, 9, 0})
    public static final class a extends l implements p<J, d<? super D>, Object> {
      public int t;
      
      public Object u;
      
      public final p<J, d<? super D>, Object> v;
      
      public a(p<? super J, ? super d<? super D>, ? extends Object> param2p, d<? super a> param2d) {
        super(2, param2d);
      }
      
      public final d<D> create(Object param2Object, d<?> param2d) {
        a a1 = new a(this.v, (d)param2d);
        a1.u = param2Object;
        return (d<D>)a1;
      }
      
      public final Object invoke(J param2J, d<? super D> param2d) {
        return ((a)create(param2J, param2d)).invokeSuspend(D.a);
      }
      
      public final Object invokeSuspend(Object<J, d<? super D>, Object> param2Object) {
        Object object = c.g();
        int i = this.t;
        if (i != 0) {
          if (i == 1) {
            p.b(param2Object);
          } else {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
          } 
        } else {
          p.b(param2Object);
          J j = (J)this.u;
          param2Object = (Object<J, d<? super D>, Object>)this.v;
          this.t = 1;
          if (param2Object.invoke(j, this) == object)
            return object; 
        } 
        return D.a;
      }
    }
  }
  
  @f(c = "com.dropbox.dbapp.android.client_deprecation.internal.forceupgrade.RealClientDeprecationActions$launchLifecycleScopeWhenCreated$1$1", f = "RealClientDeprecationActions.kt", l = {43}, m = "invokeSuspend")
  @Metadata(d1 = {"\000\f\n\002\030\002\n\002\030\002\n\002\b\002\020\002\032\0020\001*\0020\000H@¢\006\004\b\002\020\003"}, d2 = {"Ldbxyzptlk/bK/J;", "Ldbxyzptlk/pI/D;", "<anonymous>", "(Ldbxyzptlk/bK/J;)V"}, k = 3, mv = {1, 9, 0})
  public static final class a extends l implements p<J, d<? super D>, Object> {
    public int t;
    
    public Object u;
    
    public final p<J, d<? super D>, Object> v;
    
    public a(p<? super J, ? super d<? super D>, ? extends Object> param1p, d<? super a> param1d) {
      super(2, param1d);
    }
    
    public final d<D> create(Object param1Object, d<?> param1d) {
      a a1 = new a(this.v, (d)param1d);
      a1.u = param1Object;
      return (d<D>)a1;
    }
    
    public final Object invoke(J param1J, d<? super D> param1d) {
      return ((a)create(param1J, param1d)).invokeSuspend(D.a);
    }
    
    public final Object invokeSuspend(Object<J, d<? super D>, Object> param1Object) {
      Object object = c.g();
      int i = this.t;
      if (i != 0) {
        if (i == 1) {
          p.b(param1Object);
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        p.b(param1Object);
        J j = (J)this.u;
        param1Object = (Object<J, d<? super D>, Object>)this.v;
        this.t = 1;
        if (param1Object.invoke(j, this) == object)
          return object; 
      } 
      return D.a;
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\dbapp\android\client_deprecation\internal\forceupgrade\a.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */