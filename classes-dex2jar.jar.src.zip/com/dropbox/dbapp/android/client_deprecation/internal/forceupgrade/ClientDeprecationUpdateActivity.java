package com.dropbox.dbapp.android.client_deprecation.internal.forceupgrade;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import androidx.activity.ComponentActivity;
import androidx.lifecycle.LifecycleOwner;
import com.dropbox.common.activity.BaseActivity;
import dbxyzptlk.CI.a;
import dbxyzptlk.CI.p;
import dbxyzptlk.DI.s;
import dbxyzptlk.Ec.g;
import dbxyzptlk.F0.c;
import dbxyzptlk.Oh.s;
import dbxyzptlk.Tm.a;
import dbxyzptlk.U2.i;
import dbxyzptlk.Ym.e;
import dbxyzptlk.Ym.g;
import dbxyzptlk.Zm.a;
import dbxyzptlk.bK.J;
import dbxyzptlk.bK.h;
import dbxyzptlk.e.E;
import dbxyzptlk.e.r;
import dbxyzptlk.f.e;
import dbxyzptlk.jj.a;
import dbxyzptlk.lf.k;
import dbxyzptlk.pI.j;
import dbxyzptlk.pI.k;
import dbxyzptlk.rk.b;
import dbxyzptlk.yj.c;
import kotlin.Metadata;

@Metadata(d1 = {"\000f\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\020\013\n\002\b\002\n\002\030\002\n\002\b\007\n\002\030\002\n\002\b\007\n\002\030\002\n\002\b\007\n\002\030\002\n\002\b\007\n\002\030\002\n\002\b\007\n\002\030\002\n\002\b\007\n\002\030\002\n\002\b\007\n\002\030\002\n\002\b\002\b\007\030\000 C2\0020\0012\0020\002:\001DB\007¢\006\004\b\003\020\004J\031\020\b\032\0020\0072\b\020\006\032\004\030\0010\005H\024¢\006\004\b\b\020\tJ\017\020\013\032\0020\nH\026¢\006\004\b\013\020\fR\"\020\024\032\0020\r8\006@\006X.¢\006\022\n\004\b\016\020\017\032\004\b\020\020\021\"\004\b\022\020\023R\"\020\034\032\0020\0258\006@\006X.¢\006\022\n\004\b\026\020\027\032\004\b\030\020\031\"\004\b\032\020\033R\"\020$\032\0020\0358\006@\006X.¢\006\022\n\004\b\036\020\037\032\004\b \020!\"\004\b\"\020#R\"\020,\032\0020%8\006@\006X.¢\006\022\n\004\b&\020'\032\004\b(\020)\"\004\b*\020+R\"\0204\032\0020-8\006@\006X.¢\006\022\n\004\b.\020/\032\004\b0\0201\"\004\b2\0203R\"\020<\032\002058\006@\006X.¢\006\022\n\004\b6\0207\032\004\b8\0209\"\004\b:\020;R\033\020B\032\0020=8BX\002¢\006\f\n\004\b>\020?\032\004\b@\020A¨\006G²\006\f\020F\032\0020E8\nX\002"}, d2 = {"Lcom/dropbox/dbapp/android/client_deprecation/internal/forceupgrade/ClientDeprecationUpdateActivity;", "Lcom/dropbox/common/activity/BaseActivity;", "Ldbxyzptlk/Oh/s;", "<init>", "()V", "Landroid/os/Bundle;", "savedInstanceState", "Ldbxyzptlk/pI/D;", "onCreate", "(Landroid/os/Bundle;)V", "", "a0", "()Z", "Ldbxyzptlk/lf/k;", "c", "Ldbxyzptlk/lf/k;", "A4", "()Ldbxyzptlk/lf/k;", "H4", "(Ldbxyzptlk/lf/k;)V", "emmHelper", "Ldbxyzptlk/Tm/a;", "d", "Ldbxyzptlk/Tm/a;", "y4", "()Ldbxyzptlk/Tm/a;", "F4", "(Ldbxyzptlk/Tm/a;)V", "appUpdateManager", "Ldbxyzptlk/rk/b;", "e", "Ldbxyzptlk/rk/b;", "z4", "()Ldbxyzptlk/rk/b;", "G4", "(Ldbxyzptlk/rk/b;)V", "buildInfo", "Ldbxyzptlk/Ec/g;", "f", "Ldbxyzptlk/Ec/g;", "getAnalyticsLogger", "()Ldbxyzptlk/Ec/g;", "E4", "(Ldbxyzptlk/Ec/g;)V", "analyticsLogger", "Ldbxyzptlk/jj/a;", "g", "Ldbxyzptlk/jj/a;", "B4", "()Ldbxyzptlk/jj/a;", "I4", "(Ldbxyzptlk/jj/a;)V", "remoteConfig", "Ldbxyzptlk/Ym/g;", "h", "Ldbxyzptlk/Ym/g;", "x4", "()Ldbxyzptlk/Ym/g;", "D4", "(Ldbxyzptlk/Ym/g;)V", "analytics", "Ldbxyzptlk/Zm/a;", "i", "Ldbxyzptlk/pI/j;", "C4", "()Ldbxyzptlk/Zm/a;", "viewModel", "j", "a", "Ldbxyzptlk/Zm/d;", "state", "dbapp_client_deprecation_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class ClientDeprecationUpdateActivity extends BaseActivity implements s {
  public static final a j = new a(null);
  
  public static final int k = 8;
  
  public k c;
  
  public a d;
  
  public b e;
  
  public g f;
  
  public a g;
  
  public g h;
  
  public final j i = k.a((a)new e(this));
  
  public final k A4() {
    k k1 = this.c;
    if (k1 != null)
      return k1; 
    s.u("emmHelper");
    return null;
  }
  
  public final a B4() {
    a a1 = this.g;
    if (a1 != null)
      return a1; 
    s.u("remoteConfig");
    return null;
  }
  
  public final a C4() {
    return (a)this.i.getValue();
  }
  
  public final void D4(g paramg) {
    s.h(paramg, "<set-?>");
    this.h = paramg;
  }
  
  public final void E4(g paramg) {
    s.h(paramg, "<set-?>");
    this.f = paramg;
  }
  
  public final void F4(a parama) {
    s.h(parama, "<set-?>");
    this.d = parama;
  }
  
  public final void G4(b paramb) {
    s.h(paramb, "<set-?>");
    this.e = paramb;
  }
  
  public final void H4(k paramk) {
    s.h(paramk, "<set-?>");
    this.c = paramk;
  }
  
  public final void I4(a parama) {
    s.h(parama, "<set-?>");
    this.g = parama;
  }
  
  public boolean a0() {
    return false;
  }
  
  public void onCreate(Bundle paramBundle) {
    r.c((ComponentActivity)this, null, null, 3, null);
    super.onCreate(paramBundle);
    ((e)c.b((Context)this, e.class, c.d((Activity)this), false)).r(this);
    getOnBackPressedDispatcher().h((LifecycleOwner)this, (E)new b(this));
    e.b((ComponentActivity)this, null, (p)c.c(-846433279, true, new c(this)), 1, null);
    h.d((J)i.a((LifecycleOwner)this), null, null, (p)new d(this, null), 3, null);
  }
  
  public final g x4() {
    g g1 = this.h;
    if (g1 != null)
      return g1; 
    s.u("analytics");
    return null;
  }
  
  public final a y4() {
    a a1 = this.d;
    if (a1 != null)
      return a1; 
    s.u("appUpdateManager");
    return null;
  }
  
  public final b z4() {
    b b1 = this.e;
    if (b1 != null)
      return b1; 
    s.u("buildInfo");
    return null;
  }
  
  class ClientDeprecationUpdateActivity {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\dbapp\android\client_deprecation\internal\forceupgrade\ClientDeprecationUpdateActivity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */