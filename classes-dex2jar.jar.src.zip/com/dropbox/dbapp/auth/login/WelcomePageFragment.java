package com.dropbox.dbapp.auth.login;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import androidx.compose.ui.platform.ComposeView;
import androidx.compose.ui.platform.j;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.t;
import com.dropbox.dbapp.auth.api.LoginSurface;
import dbxyzptlk.CI.l;
import dbxyzptlk.CI.p;
import dbxyzptlk.DI.s;
import dbxyzptlk.DI.u;
import dbxyzptlk.Df.E;
import dbxyzptlk.En.x;
import dbxyzptlk.Rf.s;
import dbxyzptlk.U2.v;
import dbxyzptlk.U2.w;
import dbxyzptlk.U2.z;
import dbxyzptlk.ih.o;
import dbxyzptlk.ih.x;
import dbxyzptlk.pI.D;
import dbxyzptlk.pI.j;
import dbxyzptlk.pI.k;
import dbxyzptlk.s0.J0;
import dbxyzptlk.s0.K0;
import dbxyzptlk.s0.L0;
import dbxyzptlk.x0.h1;
import dbxyzptlk.x0.k;
import dbxyzptlk.x0.n;
import java.util.concurrent.ConcurrentHashMap;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

@Metadata(d1 = {"\000D\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\005\n\002\020\000\n\002\b\b\b\007\030\000 \0362\0020\001:\001\037B\007¢\006\004\b\002\020\003J\027\020\007\032\0020\0062\006\020\005\032\0020\004H\026¢\006\004\b\007\020\bJ+\020\020\032\0020\0172\006\020\n\032\0020\t2\b\020\f\032\004\030\0010\0132\b\020\016\032\004\030\0010\rH\026¢\006\004\b\020\020\021R\032\020\027\032\0020\0228\026X\004¢\006\f\n\004\b\023\020\024\032\004\b\025\020\026R\033\020\035\032\0020\0308VX\002¢\006\f\n\004\b\031\020\032\032\004\b\033\020\034¨\006 "}, d2 = {"Lcom/dropbox/dbapp/auth/login/WelcomePageFragment;", "Lcom/dropbox/dbapp/auth/login/DbappLoginFragment;", "<init>", "()V", "Landroid/content/Context;", "context", "Ldbxyzptlk/pI/D;", "onAttach", "(Landroid/content/Context;)V", "Landroid/view/LayoutInflater;", "inflater", "Landroid/view/ViewGroup;", "container", "Landroid/os/Bundle;", "savedInstanceState", "Landroid/view/View;", "onCreateView", "(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)Landroid/view/View;", "Lcom/dropbox/dbapp/auth/api/LoginSurface;", "y", "Lcom/dropbox/dbapp/auth/api/LoginSurface;", "q2", "()Lcom/dropbox/dbapp/auth/api/LoginSurface;", "loginSurface", "", "z", "Ldbxyzptlk/pI/j;", "D3", "()Ljava/lang/Object;", "daggerComponent", "A", "a", "dbapp_auth_login_impl_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class WelcomePageFragment extends DbappLoginFragment {
  public static final a A = new a(null);
  
  public static final int B = 8;
  
  public static final String C;
  
  public final LoginSurface y = (LoginSurface)LoginSurface.Default.a;
  
  public final j z = k.a(new c((z)this, this));
  
  static {
    String str = WelcomePageFragment.class.getName();
    s.g(str, "getName(...)");
    C = str;
  }
  
  public Object D3() {
    return this.z.getValue();
  }
  
  public void onAttach(Context paramContext) {
    s.h(paramContext, "context");
    ((x)dbxyzptlk.yj.c.c(this, x.class, dbxyzptlk.yj.c.f(this), false)).a(this);
    super.onAttach(paramContext);
  }
  
  public View onCreateView(LayoutInflater paramLayoutInflater, ViewGroup paramViewGroup, Bundle paramBundle) {
    s.h(paramLayoutInflater, "inflater");
    Context context = paramLayoutInflater.getContext();
    s.g(context, "getContext(...)");
    ComposeView composeView = new ComposeView(context, null, 0, 6, null);
    composeView.setViewCompositionStrategy((j)j.d.b);
    composeView.setContent((p)dbxyzptlk.F0.c.c(1839740677, true, new b(this, composeView)));
    return (View)composeView;
  }
  
  public LoginSurface q2() {
    return this.y;
  }
  
  @Metadata(d1 = {"\000\034\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\b\002\n\002\020\016\n\002\b\005\b\003\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\r\020\005\032\0020\004¢\006\004\b\005\020\006R\027\020\b\032\0020\0078\006¢\006\f\n\004\b\b\020\t\032\004\b\n\020\013¨\006\f"}, d2 = {"Lcom/dropbox/dbapp/auth/login/WelcomePageFragment$a;", "", "<init>", "()V", "Lcom/dropbox/dbapp/auth/login/WelcomePageFragment;", "b", "()Lcom/dropbox/dbapp/auth/login/WelcomePageFragment;", "", "FRAG_TAG", "Ljava/lang/String;", "a", "()Ljava/lang/String;", "dbapp_auth_login_impl_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
  public static final class a {
    public a() {}
    
    public final String a() {
      return WelcomePageFragment.F2();
    }
    
    public final WelcomePageFragment b() {
      return new WelcomePageFragment();
    }
  }
  
  @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\013¢\006\004\b\001\020\002"}, d2 = {"Ldbxyzptlk/pI/D;", "a", "(Ldbxyzptlk/x0/k;I)V"}, k = 3, mv = {1, 9, 0})
  public static final class b extends u implements p<k, Integer, D> {
    public final WelcomePageFragment f;
    
    public final ComposeView g;
    
    public b(WelcomePageFragment param1WelcomePageFragment, ComposeView param1ComposeView) {
      super(2);
    }
    
    public final void a(k param1k, int param1Int) {
      if ((param1Int & 0xB) != 2 || !param1k.b()) {
        if (n.I())
          n.U(1839740677, param1Int, -1, "com.dropbox.dbapp.auth.login.WelcomePageFragment.onCreateView.<anonymous>.<anonymous> (WelcomePageFragment.kt:52)"); 
        h1<d.d> h1 = dbxyzptlk.V2.a.b(this.f.r2().y(), null, null, null, param1k, 8, 7);
        x.a(null, o.b(param1k, 0), null, (p)dbxyzptlk.F0.c.b(param1k, 2043499836, true, new a(h1, this.f, this.g)), param1k, 3072, 5);
        if (n.I())
          n.T(); 
        return;
      } 
      param1k.k();
    }
    
    @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\013¢\006\004\b\001\020\002"}, d2 = {"Ldbxyzptlk/pI/D;", "a", "(Ldbxyzptlk/x0/k;I)V"}, k = 3, mv = {1, 9, 0})
    public static final class a extends u implements p<k, Integer, D> {
      public final h1<d.d> f;
      
      public final WelcomePageFragment g;
      
      public final ComposeView h;
      
      public a(h1<d.d> param2h1, WelcomePageFragment param2WelcomePageFragment, ComposeView param2ComposeView) {
        super(2);
      }
      
      public final void a(k param2k, int param2Int) {
        if ((param2Int & 0xB) != 2 || !param2k.b()) {
          if (n.I())
            n.U(2043499836, param2Int, -1, "com.dropbox.dbapp.auth.login.WelcomePageFragment.onCreateView.<anonymous>.<anonymous>.<anonymous> (WelcomePageFragment.kt:54)"); 
          K0 k0 = J0.p(L0.Hidden, null, null, true, param2k, 3078, 6);
          androidx.compose.ui.d.a a1 = androidx.compose.ui.d.a;
          dbxyzptlk.Gn.g.a(io.sentry.compose.b.b((androidx.compose.ui.d)a1, "<anonymous>").g(androidx.compose.foundation.layout.g.f((androidx.compose.ui.d)a1, 0.0F, 1, null)), k0, ((d.d)this.f.getValue()).a(), ((d.d)this.f.getValue()).b(), new a(this.g), new b(this.g), new c(this.g), new d(this.g), new e(this.g), new f(this.g), new g(this.g), new h(this.g), new i(this.h, this.g), param2k, K0.f << 3 | 0x6, 0, 0);
          if (n.I())
            n.T(); 
          return;
        } 
        param2k.k();
      }
      
      @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"Ldbxyzptlk/pI/D;", "b", "()V"}, k = 3, mv = {1, 9, 0})
      public static final class a extends u implements dbxyzptlk.CI.a<D> {
        public final WelcomePageFragment f;
        
        public a(WelcomePageFragment param3WelcomePageFragment) {
          super(0);
        }
        
        public final void b() {
          this.f.r2().d0((d.c)new d.c.g(this.f.q2()));
        }
      }
      
      @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"Ldbxyzptlk/pI/D;", "b", "()V"}, k = 3, mv = {1, 9, 0})
      public static final class b extends u implements dbxyzptlk.CI.a<D> {
        public final WelcomePageFragment f;
        
        public b(WelcomePageFragment param3WelcomePageFragment) {
          super(0);
        }
        
        public final void b() {
          this.f.r2().d0((d.c)new d.c.d(this.f.q2()));
        }
      }
      
      @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"Ldbxyzptlk/pI/D;", "b", "()V"}, k = 3, mv = {1, 9, 0})
      public static final class c extends u implements dbxyzptlk.CI.a<D> {
        public final WelcomePageFragment f;
        
        public c(WelcomePageFragment param3WelcomePageFragment) {
          super(0);
        }
        
        public final void b() {
          this.f.r2().d0((d.c)d.c.b.a);
        }
      }
      
      @Metadata(d1 = {"\000\016\n\002\020\016\n\000\n\002\030\002\n\002\b\002\020\003\032\0020\0022\006\020\001\032\0020\000H\n¢\006\004\b\003\020\004"}, d2 = {"", "emailEntered", "Ldbxyzptlk/pI/D;", "a", "(Ljava/lang/String;)V"}, k = 3, mv = {1, 9, 0})
      public static final class d extends u implements l<String, D> {
        public final WelcomePageFragment f;
        
        public d(WelcomePageFragment param3WelcomePageFragment) {
          super(1);
        }
        
        public final void a(String param3String) {
          s.h(param3String, "emailEntered");
          E.f((Activity)this.f.requireActivity());
          this.f.r2().d0((d.c)new d.c.f(param3String));
        }
      }
      
      @Metadata(d1 = {"\000\016\n\002\020\016\n\000\n\002\030\002\n\002\b\002\020\003\032\0020\0022\006\020\001\032\0020\000H\n¢\006\004\b\003\020\004"}, d2 = {"", "emailEntered", "Ldbxyzptlk/pI/D;", "a", "(Ljava/lang/String;)V"}, k = 3, mv = {1, 9, 0})
      public static final class e extends u implements l<String, D> {
        public final WelcomePageFragment f;
        
        public e(WelcomePageFragment param3WelcomePageFragment) {
          super(1);
        }
        
        public final void a(String param3String) {
          s.h(param3String, "emailEntered");
          E.f((Activity)this.f.requireActivity());
          this.f.r2().d0((d.c)new d.c.h(param3String));
        }
      }
      
      @Metadata(d1 = {"\000\016\n\002\020\016\n\000\n\002\030\002\n\002\b\002\020\003\032\0020\0022\006\020\001\032\0020\000H\n¢\006\004\b\003\020\004"}, d2 = {"", "emailEntered", "Ldbxyzptlk/pI/D;", "a", "(Ljava/lang/String;)V"}, k = 3, mv = {1, 9, 0})
      public static final class f extends u implements l<String, D> {
        public final WelcomePageFragment f;
        
        public f(WelcomePageFragment param3WelcomePageFragment) {
          super(1);
        }
        
        public final void a(String param3String) {
          s.h(param3String, "emailEntered");
          this.f.r2().d0((d.c)new d.c.e(param3String));
        }
      }
      
      @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"Ldbxyzptlk/pI/D;", "b", "()V"}, k = 3, mv = {1, 9, 0})
      public static final class g extends u implements dbxyzptlk.CI.a<D> {
        public final WelcomePageFragment f;
        
        public g(WelcomePageFragment param3WelcomePageFragment) {
          super(0);
        }
        
        public final void b() {
          this.f.r2().d0((d.c)d.c.a.a);
        }
      }
      
      @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"Ldbxyzptlk/pI/D;", "b", "()V"}, k = 3, mv = {1, 9, 0})
      public static final class h extends u implements dbxyzptlk.CI.a<D> {
        public final WelcomePageFragment f;
        
        public h(WelcomePageFragment param3WelcomePageFragment) {
          super(0);
        }
        
        public final void b() {
          this.f.r2().d0((d.c)d.c.c.a);
        }
      }
      
      @Metadata(d1 = {"\000\016\n\002\030\002\n\000\n\002\030\002\n\002\b\002\020\003\032\0020\0022\006\020\001\032\0020\000H\n¢\006\004\b\003\020\004"}, d2 = {"Landroid/net/Uri;", "uri", "Ldbxyzptlk/pI/D;", "a", "(Landroid/net/Uri;)V"}, k = 3, mv = {1, 9, 0})
      public static final class i extends u implements l<Uri, D> {
        public final ComposeView f;
        
        public final WelcomePageFragment g;
        
        public i(ComposeView param3ComposeView, WelcomePageFragment param3WelcomePageFragment) {
          super(1);
        }
        
        public final void a(Uri param3Uri) {
          s.h(param3Uri, "uri");
          try {
            Context context = this.f.getContext();
            Intent intent = new Intent();
            this("android.intent.action.VIEW", param3Uri);
            context.startActivity(intent);
          } catch (ActivityNotFoundException activityNotFoundException) {
            dbxyzptlk.sL.a.b b = dbxyzptlk.sL.a.a;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Unable to launch intent to view deals uri: ");
            stringBuilder.append(param3Uri);
            b.f((Throwable)activityNotFoundException, stringBuilder.toString(), new Object[0]);
            Toast.makeText((Context)this.g.requireActivity(), s.auth_cannot_open_browser_error, 1).show();
          } 
        }
      }
    }
    
    @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"Ldbxyzptlk/pI/D;", "b", "()V"}, k = 3, mv = {1, 9, 0})
    public static final class a extends u implements dbxyzptlk.CI.a<D> {
      public final WelcomePageFragment f;
      
      public a(WelcomePageFragment param2WelcomePageFragment) {
        super(0);
      }
      
      public final void b() {
        this.f.r2().d0((d.c)new d.c.g(this.f.q2()));
      }
    }
    
    @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"Ldbxyzptlk/pI/D;", "b", "()V"}, k = 3, mv = {1, 9, 0})
    public static final class b extends u implements dbxyzptlk.CI.a<D> {
      public final WelcomePageFragment f;
      
      public b(WelcomePageFragment param2WelcomePageFragment) {
        super(0);
      }
      
      public final void b() {
        this.f.r2().d0((d.c)new d.c.d(this.f.q2()));
      }
    }
    
    @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"Ldbxyzptlk/pI/D;", "b", "()V"}, k = 3, mv = {1, 9, 0})
    public static final class c extends u implements dbxyzptlk.CI.a<D> {
      public final WelcomePageFragment f;
      
      public c(WelcomePageFragment param2WelcomePageFragment) {
        super(0);
      }
      
      public final void b() {
        this.f.r2().d0((d.c)d.c.b.a);
      }
    }
    
    @Metadata(d1 = {"\000\016\n\002\020\016\n\000\n\002\030\002\n\002\b\002\020\003\032\0020\0022\006\020\001\032\0020\000H\n¢\006\004\b\003\020\004"}, d2 = {"", "emailEntered", "Ldbxyzptlk/pI/D;", "a", "(Ljava/lang/String;)V"}, k = 3, mv = {1, 9, 0})
    public static final class d extends u implements l<String, D> {
      public final WelcomePageFragment f;
      
      public d(WelcomePageFragment param2WelcomePageFragment) {
        super(1);
      }
      
      public final void a(String param2String) {
        s.h(param2String, "emailEntered");
        E.f((Activity)this.f.requireActivity());
        this.f.r2().d0((d.c)new d.c.f(param2String));
      }
    }
    
    @Metadata(d1 = {"\000\016\n\002\020\016\n\000\n\002\030\002\n\002\b\002\020\003\032\0020\0022\006\020\001\032\0020\000H\n¢\006\004\b\003\020\004"}, d2 = {"", "emailEntered", "Ldbxyzptlk/pI/D;", "a", "(Ljava/lang/String;)V"}, k = 3, mv = {1, 9, 0})
    public static final class e extends u implements l<String, D> {
      public final WelcomePageFragment f;
      
      public e(WelcomePageFragment param2WelcomePageFragment) {
        super(1);
      }
      
      public final void a(String param2String) {
        s.h(param2String, "emailEntered");
        E.f((Activity)this.f.requireActivity());
        this.f.r2().d0((d.c)new d.c.h(param2String));
      }
    }
    
    @Metadata(d1 = {"\000\016\n\002\020\016\n\000\n\002\030\002\n\002\b\002\020\003\032\0020\0022\006\020\001\032\0020\000H\n¢\006\004\b\003\020\004"}, d2 = {"", "emailEntered", "Ldbxyzptlk/pI/D;", "a", "(Ljava/lang/String;)V"}, k = 3, mv = {1, 9, 0})
    public static final class f extends u implements l<String, D> {
      public final WelcomePageFragment f;
      
      public f(WelcomePageFragment param2WelcomePageFragment) {
        super(1);
      }
      
      public final void a(String param2String) {
        s.h(param2String, "emailEntered");
        this.f.r2().d0((d.c)new d.c.e(param2String));
      }
    }
    
    @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"Ldbxyzptlk/pI/D;", "b", "()V"}, k = 3, mv = {1, 9, 0})
    public static final class g extends u implements dbxyzptlk.CI.a<D> {
      public final WelcomePageFragment f;
      
      public g(WelcomePageFragment param2WelcomePageFragment) {
        super(0);
      }
      
      public final void b() {
        this.f.r2().d0((d.c)d.c.a.a);
      }
    }
    
    @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"Ldbxyzptlk/pI/D;", "b", "()V"}, k = 3, mv = {1, 9, 0})
    public static final class h extends u implements dbxyzptlk.CI.a<D> {
      public final WelcomePageFragment f;
      
      public h(WelcomePageFragment param2WelcomePageFragment) {
        super(0);
      }
      
      public final void b() {
        this.f.r2().d0((d.c)d.c.c.a);
      }
    }
    
    @Metadata(d1 = {"\000\016\n\002\030\002\n\000\n\002\030\002\n\002\b\002\020\003\032\0020\0022\006\020\001\032\0020\000H\n¢\006\004\b\003\020\004"}, d2 = {"Landroid/net/Uri;", "uri", "Ldbxyzptlk/pI/D;", "a", "(Landroid/net/Uri;)V"}, k = 3, mv = {1, 9, 0})
    public static final class i extends u implements l<Uri, D> {
      public final ComposeView f;
      
      public final WelcomePageFragment g;
      
      public i(ComposeView param2ComposeView, WelcomePageFragment param2WelcomePageFragment) {
        super(1);
      }
      
      public final void a(Uri param2Uri) {
        s.h(param2Uri, "uri");
        try {
          Context context = this.f.getContext();
          Intent intent = new Intent();
          this("android.intent.action.VIEW", param2Uri);
          context.startActivity(intent);
        } catch (ActivityNotFoundException activityNotFoundException) {
          dbxyzptlk.sL.a.b b = dbxyzptlk.sL.a.a;
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Unable to launch intent to view deals uri: ");
          stringBuilder.append(param2Uri);
          b.f((Throwable)activityNotFoundException, stringBuilder.toString(), new Object[0]);
          Toast.makeText((Context)this.g.requireActivity(), s.auth_cannot_open_browser_error, 1).show();
        } 
      }
    }
  }
  
  @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\013¢\006\004\b\001\020\002"}, d2 = {"Ldbxyzptlk/pI/D;", "a", "(Ldbxyzptlk/x0/k;I)V"}, k = 3, mv = {1, 9, 0})
  public static final class a extends u implements p<k, Integer, D> {
    public final h1<d.d> f;
    
    public final WelcomePageFragment g;
    
    public final ComposeView h;
    
    public a(h1<d.d> param1h1, WelcomePageFragment param1WelcomePageFragment, ComposeView param1ComposeView) {
      super(2);
    }
    
    public final void a(k param1k, int param1Int) {
      if ((param1Int & 0xB) != 2 || !param1k.b()) {
        if (n.I())
          n.U(2043499836, param1Int, -1, "com.dropbox.dbapp.auth.login.WelcomePageFragment.onCreateView.<anonymous>.<anonymous>.<anonymous> (WelcomePageFragment.kt:54)"); 
        K0 k0 = J0.p(L0.Hidden, null, null, true, param1k, 3078, 6);
        androidx.compose.ui.d.a a1 = androidx.compose.ui.d.a;
        dbxyzptlk.Gn.g.a(io.sentry.compose.b.b((androidx.compose.ui.d)a1, "<anonymous>").g(androidx.compose.foundation.layout.g.f((androidx.compose.ui.d)a1, 0.0F, 1, null)), k0, ((d.d)this.f.getValue()).a(), ((d.d)this.f.getValue()).b(), new a(this.g), new b(this.g), new c(this.g), new d(this.g), new e(this.g), new f(this.g), new g(this.g), new h(this.g), new i(this.h, this.g), param1k, K0.f << 3 | 0x6, 0, 0);
        if (n.I())
          n.T(); 
        return;
      } 
      param1k.k();
    }
    
    @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"Ldbxyzptlk/pI/D;", "b", "()V"}, k = 3, mv = {1, 9, 0})
    public static final class a extends u implements dbxyzptlk.CI.a<D> {
      public final WelcomePageFragment f;
      
      public a(WelcomePageFragment param3WelcomePageFragment) {
        super(0);
      }
      
      public final void b() {
        this.f.r2().d0((d.c)new d.c.g(this.f.q2()));
      }
    }
    
    @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"Ldbxyzptlk/pI/D;", "b", "()V"}, k = 3, mv = {1, 9, 0})
    public static final class b extends u implements dbxyzptlk.CI.a<D> {
      public final WelcomePageFragment f;
      
      public b(WelcomePageFragment param3WelcomePageFragment) {
        super(0);
      }
      
      public final void b() {
        this.f.r2().d0((d.c)new d.c.d(this.f.q2()));
      }
    }
    
    @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"Ldbxyzptlk/pI/D;", "b", "()V"}, k = 3, mv = {1, 9, 0})
    public static final class c extends u implements dbxyzptlk.CI.a<D> {
      public final WelcomePageFragment f;
      
      public c(WelcomePageFragment param3WelcomePageFragment) {
        super(0);
      }
      
      public final void b() {
        this.f.r2().d0((d.c)d.c.b.a);
      }
    }
    
    @Metadata(d1 = {"\000\016\n\002\020\016\n\000\n\002\030\002\n\002\b\002\020\003\032\0020\0022\006\020\001\032\0020\000H\n¢\006\004\b\003\020\004"}, d2 = {"", "emailEntered", "Ldbxyzptlk/pI/D;", "a", "(Ljava/lang/String;)V"}, k = 3, mv = {1, 9, 0})
    public static final class d extends u implements l<String, D> {
      public final WelcomePageFragment f;
      
      public d(WelcomePageFragment param3WelcomePageFragment) {
        super(1);
      }
      
      public final void a(String param3String) {
        s.h(param3String, "emailEntered");
        E.f((Activity)this.f.requireActivity());
        this.f.r2().d0((d.c)new d.c.f(param3String));
      }
    }
    
    @Metadata(d1 = {"\000\016\n\002\020\016\n\000\n\002\030\002\n\002\b\002\020\003\032\0020\0022\006\020\001\032\0020\000H\n¢\006\004\b\003\020\004"}, d2 = {"", "emailEntered", "Ldbxyzptlk/pI/D;", "a", "(Ljava/lang/String;)V"}, k = 3, mv = {1, 9, 0})
    public static final class e extends u implements l<String, D> {
      public final WelcomePageFragment f;
      
      public e(WelcomePageFragment param3WelcomePageFragment) {
        super(1);
      }
      
      public final void a(String param3String) {
        s.h(param3String, "emailEntered");
        E.f((Activity)this.f.requireActivity());
        this.f.r2().d0((d.c)new d.c.h(param3String));
      }
    }
    
    @Metadata(d1 = {"\000\016\n\002\020\016\n\000\n\002\030\002\n\002\b\002\020\003\032\0020\0022\006\020\001\032\0020\000H\n¢\006\004\b\003\020\004"}, d2 = {"", "emailEntered", "Ldbxyzptlk/pI/D;", "a", "(Ljava/lang/String;)V"}, k = 3, mv = {1, 9, 0})
    public static final class f extends u implements l<String, D> {
      public final WelcomePageFragment f;
      
      public f(WelcomePageFragment param3WelcomePageFragment) {
        super(1);
      }
      
      public final void a(String param3String) {
        s.h(param3String, "emailEntered");
        this.f.r2().d0((d.c)new d.c.e(param3String));
      }
    }
    
    @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"Ldbxyzptlk/pI/D;", "b", "()V"}, k = 3, mv = {1, 9, 0})
    public static final class g extends u implements dbxyzptlk.CI.a<D> {
      public final WelcomePageFragment f;
      
      public g(WelcomePageFragment param3WelcomePageFragment) {
        super(0);
      }
      
      public final void b() {
        this.f.r2().d0((d.c)d.c.a.a);
      }
    }
    
    @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"Ldbxyzptlk/pI/D;", "b", "()V"}, k = 3, mv = {1, 9, 0})
    public static final class h extends u implements dbxyzptlk.CI.a<D> {
      public final WelcomePageFragment f;
      
      public h(WelcomePageFragment param3WelcomePageFragment) {
        super(0);
      }
      
      public final void b() {
        this.f.r2().d0((d.c)d.c.c.a);
      }
    }
    
    @Metadata(d1 = {"\000\016\n\002\030\002\n\000\n\002\030\002\n\002\b\002\020\003\032\0020\0022\006\020\001\032\0020\000H\n¢\006\004\b\003\020\004"}, d2 = {"Landroid/net/Uri;", "uri", "Ldbxyzptlk/pI/D;", "a", "(Landroid/net/Uri;)V"}, k = 3, mv = {1, 9, 0})
    public static final class i extends u implements l<Uri, D> {
      public final ComposeView f;
      
      public final WelcomePageFragment g;
      
      public i(ComposeView param3ComposeView, WelcomePageFragment param3WelcomePageFragment) {
        super(1);
      }
      
      public final void a(Uri param3Uri) {
        s.h(param3Uri, "uri");
        try {
          Context context = this.f.getContext();
          Intent intent = new Intent();
          this("android.intent.action.VIEW", param3Uri);
          context.startActivity(intent);
        } catch (ActivityNotFoundException activityNotFoundException) {
          dbxyzptlk.sL.a.b b = dbxyzptlk.sL.a.a;
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Unable to launch intent to view deals uri: ");
          stringBuilder.append(param3Uri);
          b.f((Throwable)activityNotFoundException, stringBuilder.toString(), new Object[0]);
          Toast.makeText((Context)this.g.requireActivity(), s.auth_cannot_open_browser_error, 1).show();
        } 
      }
    }
  }
  
  @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"Ldbxyzptlk/pI/D;", "b", "()V"}, k = 3, mv = {1, 9, 0})
  public static final class a extends u implements dbxyzptlk.CI.a<D> {
    public final WelcomePageFragment f;
    
    public a(WelcomePageFragment param1WelcomePageFragment) {
      super(0);
    }
    
    public final void b() {
      this.f.r2().d0((d.c)new d.c.g(this.f.q2()));
    }
  }
  
  @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"Ldbxyzptlk/pI/D;", "b", "()V"}, k = 3, mv = {1, 9, 0})
  public static final class b extends u implements dbxyzptlk.CI.a<D> {
    public final WelcomePageFragment f;
    
    public b(WelcomePageFragment param1WelcomePageFragment) {
      super(0);
    }
    
    public final void b() {
      this.f.r2().d0((d.c)new d.c.d(this.f.q2()));
    }
  }
  
  @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"Ldbxyzptlk/pI/D;", "b", "()V"}, k = 3, mv = {1, 9, 0})
  public static final class c extends u implements dbxyzptlk.CI.a<D> {
    public final WelcomePageFragment f;
    
    public c(WelcomePageFragment param1WelcomePageFragment) {
      super(0);
    }
    
    public final void b() {
      this.f.r2().d0((d.c)d.c.b.a);
    }
  }
  
  @Metadata(d1 = {"\000\016\n\002\020\016\n\000\n\002\030\002\n\002\b\002\020\003\032\0020\0022\006\020\001\032\0020\000H\n¢\006\004\b\003\020\004"}, d2 = {"", "emailEntered", "Ldbxyzptlk/pI/D;", "a", "(Ljava/lang/String;)V"}, k = 3, mv = {1, 9, 0})
  public static final class d extends u implements l<String, D> {
    public final WelcomePageFragment f;
    
    public d(WelcomePageFragment param1WelcomePageFragment) {
      super(1);
    }
    
    public final void a(String param1String) {
      s.h(param1String, "emailEntered");
      E.f((Activity)this.f.requireActivity());
      this.f.r2().d0((d.c)new d.c.f(param1String));
    }
  }
  
  @Metadata(d1 = {"\000\016\n\002\020\016\n\000\n\002\030\002\n\002\b\002\020\003\032\0020\0022\006\020\001\032\0020\000H\n¢\006\004\b\003\020\004"}, d2 = {"", "emailEntered", "Ldbxyzptlk/pI/D;", "a", "(Ljava/lang/String;)V"}, k = 3, mv = {1, 9, 0})
  public static final class e extends u implements l<String, D> {
    public final WelcomePageFragment f;
    
    public e(WelcomePageFragment param1WelcomePageFragment) {
      super(1);
    }
    
    public final void a(String param1String) {
      s.h(param1String, "emailEntered");
      E.f((Activity)this.f.requireActivity());
      this.f.r2().d0((d.c)new d.c.h(param1String));
    }
  }
  
  @Metadata(d1 = {"\000\016\n\002\020\016\n\000\n\002\030\002\n\002\b\002\020\003\032\0020\0022\006\020\001\032\0020\000H\n¢\006\004\b\003\020\004"}, d2 = {"", "emailEntered", "Ldbxyzptlk/pI/D;", "a", "(Ljava/lang/String;)V"}, k = 3, mv = {1, 9, 0})
  public static final class f extends u implements l<String, D> {
    public final WelcomePageFragment f;
    
    public f(WelcomePageFragment param1WelcomePageFragment) {
      super(1);
    }
    
    public final void a(String param1String) {
      s.h(param1String, "emailEntered");
      this.f.r2().d0((d.c)new d.c.e(param1String));
    }
  }
  
  @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"Ldbxyzptlk/pI/D;", "b", "()V"}, k = 3, mv = {1, 9, 0})
  public static final class g extends u implements dbxyzptlk.CI.a<D> {
    public final WelcomePageFragment f;
    
    public g(WelcomePageFragment param1WelcomePageFragment) {
      super(0);
    }
    
    public final void b() {
      this.f.r2().d0((d.c)d.c.a.a);
    }
  }
  
  @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"Ldbxyzptlk/pI/D;", "b", "()V"}, k = 3, mv = {1, 9, 0})
  public static final class h extends u implements dbxyzptlk.CI.a<D> {
    public final WelcomePageFragment f;
    
    public h(WelcomePageFragment param1WelcomePageFragment) {
      super(0);
    }
    
    public final void b() {
      this.f.r2().d0((d.c)d.c.c.a);
    }
  }
  
  @Metadata(d1 = {"\000\016\n\002\030\002\n\000\n\002\030\002\n\002\b\002\020\003\032\0020\0022\006\020\001\032\0020\000H\n¢\006\004\b\003\020\004"}, d2 = {"Landroid/net/Uri;", "uri", "Ldbxyzptlk/pI/D;", "a", "(Landroid/net/Uri;)V"}, k = 3, mv = {1, 9, 0})
  public static final class i extends u implements l<Uri, D> {
    public final ComposeView f;
    
    public final WelcomePageFragment g;
    
    public i(ComposeView param1ComposeView, WelcomePageFragment param1WelcomePageFragment) {
      super(1);
    }
    
    public final void a(Uri param1Uri) {
      s.h(param1Uri, "uri");
      try {
        Context context = this.f.getContext();
        Intent intent = new Intent();
        this("android.intent.action.VIEW", param1Uri);
        context.startActivity(intent);
      } catch (ActivityNotFoundException activityNotFoundException) {
        dbxyzptlk.sL.a.b b = dbxyzptlk.sL.a.a;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Unable to launch intent to view deals uri: ");
        stringBuilder.append(param1Uri);
        b.f((Throwable)activityNotFoundException, stringBuilder.toString(), new Object[0]);
        Toast.makeText((Context)this.g.requireActivity(), s.auth_cannot_open_browser_error, 1).show();
      } 
    }
  }
  
  @Metadata(d1 = {"\000\b\n\002\020\000\n\002\b\004\020\004\032\0020\000\"\n\b\000\020\001\030\001*\0020\000H\n¢\006\004\b\002\020\003"}, d2 = {"", "T", "invoke", "()Ljava/lang/Object;", "<anonymous>"}, k = 3, mv = {1, 9, 0})
  public static final class c extends u implements dbxyzptlk.CI.a<Object> {
    public final z f;
    
    public final WelcomePageFragment g;
    
    public c(z param1z, WelcomePageFragment param1WelcomePageFragment) {
      super(0);
    }
    
    public final Object invoke() {
      dbxyzptlk.yj.d d = (dbxyzptlk.yj.d)(new t(this.f, dbxyzptlk.yj.d.d.a())).a(dbxyzptlk.yj.d.class);
      Class<c.a> clazz = c.a.class;
      if (dbxyzptlk.zj.h.a.class.isAssignableFrom(c.a.class))
        clazz = (Class)c.a.class.getEnclosingClass(); 
      ConcurrentHashMap<Class<c.a>, Object> concurrentHashMap = d.G();
      Object<c.a> object2 = (Object<c.a>)concurrentHashMap.get(clazz);
      Object<c.a> object1 = object2;
      if (object2 == null) {
        w.a((v)d);
        object1 = (Object<c.a>)this.g;
        object2 = (Object<c.a>)((c.b)dbxyzptlk.yj.c.c((Fragment)object1, c.b.class, dbxyzptlk.yj.c.f((Fragment)object1), true)).V();
        object1 = object2;
        if (object2 != null)
          object1 = (Object<c.a>)object2.a(w.a((v)d)); 
        clazz = (Class<c.a>)concurrentHashMap.putIfAbsent(clazz, object1);
        if (clazz != null)
          object1 = (Object<c.a>)clazz; 
      } 
      s.g(object1, "getOrPut(...)");
      return object1;
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\dbapp\auth\login\WelcomePageFragment.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */