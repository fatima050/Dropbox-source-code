package com.dropbox.dbapp.auth.login;

import android.content.Intent;
import android.net.Uri;
import com.dropbox.common.auth.login.wiring.Source;
import com.dropbox.dbapp.auth.api.LoginSurface;
import com.google.android.gms.auth.api.identity.BeginSignInResult;
import com.google.android.gms.auth.api.identity.SignInCredential;
import com.squareup.anvil.annotations.ContributesMultibinding;
import dbxyzptlk.C8.g;
import dbxyzptlk.C8.i;
import dbxyzptlk.CI.q;
import dbxyzptlk.DI.s;
import dbxyzptlk.En.m;
import dbxyzptlk.Rf.s;
import dbxyzptlk.U2.v;
import dbxyzptlk.U2.w;
import dbxyzptlk.Uf.c;
import dbxyzptlk.Uf.v;
import dbxyzptlk.YJ.u;
import dbxyzptlk.ag.g;
import dbxyzptlk.bK.J;
import dbxyzptlk.bK.w0;
import dbxyzptlk.eK.C;
import dbxyzptlk.eK.M;
import dbxyzptlk.eK.S;
import dbxyzptlk.eK.U;
import dbxyzptlk.eK.i;
import dbxyzptlk.eK.j;
import dbxyzptlk.eK.k;
import dbxyzptlk.gg.c;
import dbxyzptlk.ig.a;
import dbxyzptlk.ig.c;
import dbxyzptlk.jg.c;
import dbxyzptlk.kg.c;
import dbxyzptlk.lg.c;
import dbxyzptlk.mg.k;
import dbxyzptlk.pI.D;
import dbxyzptlk.uI.c;
import dbxyzptlk.ug.I;
import dbxyzptlk.vI.f;
import dbxyzptlk.wg.c;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

@ContributesMultibinding(boundType = v.class, scope = m.class)
@Metadata(d1 = {"\000è\001\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\006\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\030\002\n\000\n\002\030\002\n\002\b\006\n\002\030\002\n\002\b\004\n\002\020\016\n\002\b\006\n\002\030\002\n\002\b\002\n\002\020\013\n\002\b\t\n\002\030\002\n\000\n\002\030\002\n\002\b\006\n\002\020\b\n\002\b\021\n\002\030\002\n\000\n\002\030\002\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\036\n\002\030\002\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\004\n\002\030\002\n\002\b\003\n\002\030\002\n\000\n\002\030\002\n\002\b\004\b\007\030\0002\0020\0012\0020\0022\0020\0032\0020\0042\0020\0052\0020\006:\004SctvBq\b\007\022\006\020\b\032\0020\007\022\006\020\t\032\0020\006\022\006\020\n\032\0020\003\022\006\020\013\032\0020\002\022\006\020\f\032\0020\004\022\006\020\r\032\0020\005\022\006\020\017\032\0020\016\022\006\020\021\032\0020\020\022\006\020\023\032\0020\022\022\006\020\025\032\0020\024\022\006\020\027\032\0020\026\022\006\020\031\032\0020\030\022\006\020\033\032\0020\032¢\006\004\b\034\020\035J\027\020!\032\0020 2\006\020\037\032\0020\036H\002¢\006\004\b!\020\"J\027\020$\032\0020 2\006\020#\032\0020\036H\002¢\006\004\b$\020\"J\027\020&\032\0020 2\006\020%\032\0020\036H\002¢\006\004\b&\020\"J\027\020)\032\0020 2\006\020(\032\0020'H\002¢\006\004\b)\020*J\027\020+\032\0020 2\006\020(\032\0020'H\002¢\006\004\b+\020*J\027\020.\032\0020 2\006\020-\032\0020,H\002¢\006\004\b.\020/J\027\0200\032\0020 2\006\020-\032\0020,H\002¢\006\004\b0\020/J\027\0201\032\0020 2\006\020-\032\0020,H\002¢\006\004\b1\020/J\027\0202\032\0020 2\006\020-\032\0020,H\002¢\006\004\b2\020/J\030\0204\032\002032\006\020-\032\0020,H@¢\006\004\b4\0205J\027\0207\032\002062\006\020-\032\0020,H\002¢\006\004\b7\0208J\017\0209\032\0020 H\002¢\006\004\b9\020:J\017\020;\032\0020 H\002¢\006\004\b;\020:J\027\020=\032\0020 2\006\020<\032\00203H\002¢\006\004\b=\020>J\017\020?\032\0020 H\002¢\006\004\b?\020:J\027\020C\032\0020B2\006\020A\032\0020@H\002¢\006\004\bC\020DJ\037\020F\032\0020 2\006\020-\032\0020,2\006\020E\032\0020,H\002¢\006\004\bF\020GJ\017\020H\032\0020 H\002¢\006\004\bH\020:J\031\020K\032\0020 2\b\b\002\020J\032\0020IH\002¢\006\004\bK\020LJ\020\020M\032\0020\036H\001¢\006\004\bM\020NJ\030\020P\032\002062\006\020O\032\0020\036H\001¢\006\004\bP\020QJ\030\020S\032\002032\006\020R\032\0020,HA¢\006\004\bS\0205J\020\020T\032\0020\036H\001¢\006\004\bT\020NJ\034\020V\032\004\030\001032\b\020U\032\004\030\0010\036HA¢\006\004\bV\020WJ\030\020Y\032\002032\006\020X\032\0020@HA¢\006\004\bY\020ZJ4\020`\032\002032\n\020\\\032\0060,j\002`[2\n\020E\032\0060,j\002`]2\n\b\002\020_\032\004\030\0010^HA¢\006\004\b`\020aJ\030\020b\032\002032\006\020O\032\0020\036HA¢\006\004\bb\020WJ\030\020c\032\002062\006\020O\032\0020\036H\001¢\006\004\bc\020QJ\030\020f\032\002032\006\020e\032\0020dHA¢\006\004\bf\020gJ\034\020h\032\002032\n\020\\\032\0060,j\002`[HA¢\006\004\bh\0205J\r\020i\032\0020 ¢\006\004\bi\020:J\025\020l\032\0020 2\006\020k\032\0020j¢\006\004\bl\020mJ\025\020n\032\0020 2\006\020O\032\0020\036¢\006\004\bn\020\"J\027\020o\032\0020 2\b\020U\032\004\030\0010\036¢\006\004\bo\020\"J\025\020p\032\0020 2\006\020(\032\0020'¢\006\004\bp\020*J\025\020q\032\0020 2\006\020(\032\0020'¢\006\004\bq\020*J\r\020r\032\0020 ¢\006\004\br\020:J\025\020s\032\0020 2\006\020O\032\0020\036¢\006\004\bs\020\"R\024\020\b\032\0020\0078\002X\004¢\006\006\n\004\bt\020uR\024\020\t\032\0020\0068\002X\004¢\006\006\n\004\bv\020wR\024\020\n\032\0020\0038\002X\004¢\006\006\n\004\bx\020yR\024\020\013\032\0020\0028\002X\004¢\006\006\n\004\bT\020zR\024\020\f\032\0020\0048\002X\004¢\006\006\n\004\b{\020|R\024\020\r\032\0020\0058\002X\004¢\006\006\n\004\bf\020}R\024\020\017\032\0020\0168\002X\004¢\006\006\n\004\bV\020~R\025\020\021\032\0020\0208\002X\004¢\006\007\n\005\b\020\001R\025\020\023\032\0020\0228\002X\004¢\006\007\n\005\bb\020\001R\026\020\025\032\0020\0248\002X\004¢\006\b\n\006\b\001\020\001R\026\020\027\032\0020\0268\002X\004¢\006\b\n\006\b\001\020\001R\026\020\031\032\0020\0308\002X\004¢\006\b\n\006\b\001\020\001R\025\020\033\032\0020\0328\002X\004¢\006\007\n\005\bY\020\001R\037\020\001\032\n\022\005\022\0030\0010\0018\002X\004¢\006\b\n\006\b\001\020\001R$\020\001\032\n\022\005\022\0030\0010\0018\006¢\006\020\n\006\b\001\020\001\032\006\b\001\020\001R\037\020\001\032\n\022\005\022\0030\0010\0018\002X\004¢\006\b\n\006\b\001\020\001R#\020\001\032\n\022\005\022\0030\0010\0018\006¢\006\017\n\005\bP\020\001\032\006\b\001\020\001R\036\020\001\032\t\022\004\022\002060\0018\002X\004¢\006\b\n\006\b\001\020\001R \020\001\032\f\022\007\022\005\030\0010\0010\0018\002X\004¢\006\007\n\005\b`\020\001R$\020¢\001\032\n\022\005\022\0030\0010\0018\006¢\006\020\n\006\b \001\020\001\032\006\b¡\001\020\001¨\006£\001"}, d2 = {"Lcom/dropbox/dbapp/auth/login/d;", "Ldbxyzptlk/U2/v;", "Ldbxyzptlk/jg/c;", "Ldbxyzptlk/ig/c;", "Ldbxyzptlk/ig/a;", "Ldbxyzptlk/lg/c;", "Ldbxyzptlk/kg/c;", "Ldbxyzptlk/Cn/a;", "logger", "ssoDelegate", "googleSignInDelegate", "signInWithAppleDelegate", "googleOneTapDelegate", "userNamePasswordDelegate", "Ldbxyzptlk/dg/b;", "googleOneTapInteractor", "Ldbxyzptlk/ug/I;", "ssoStateInteractor", "Ldbxyzptlk/mg/k;", "magicLinkInteractor", "Ldbxyzptlk/Uf/v;", "signInLogger", "Ldbxyzptlk/Uf/b;", "checkUserWithEmailExistsUseCase", "Ldbxyzptlk/gg/c;", "kakaoSuSiGate", "Ldbxyzptlk/C8/g;", "noAuthPreloadDealsInteractor", "<init>", "(Ldbxyzptlk/Cn/a;Ldbxyzptlk/kg/c;Ldbxyzptlk/ig/c;Ldbxyzptlk/jg/c;Ldbxyzptlk/ig/a;Ldbxyzptlk/lg/c;Ldbxyzptlk/dg/b;Ldbxyzptlk/ug/I;Ldbxyzptlk/mg/k;Ldbxyzptlk/Uf/v;Ldbxyzptlk/Uf/b;Ldbxyzptlk/gg/c;Ldbxyzptlk/C8/g;)V", "Landroid/content/Intent;", "siaIntent", "Ldbxyzptlk/pI/D;", "W", "(Landroid/content/Intent;)V", "ssoIntent", "X", "magicLinkIntent", "U", "Lcom/dropbox/dbapp/auth/api/LoginSurface;", "loginSurface", "m0", "(Lcom/dropbox/dbapp/auth/api/LoginSurface;)V", "h0", "", "email", "i0", "(Ljava/lang/String;)V", "n0", "j0", "q0", "Ldbxyzptlk/og/a;", "p0", "(Ljava/lang/String;Ldbxyzptlk/tI/d;)Ljava/lang/Object;", "", "Z", "(Ljava/lang/String;)Z", "e0", "()V", "g0", "destination", "b0", "(Ldbxyzptlk/og/a;)V", "c0", "Lcom/google/android/gms/auth/api/identity/SignInCredential;", "signInCredential", "Ldbxyzptlk/bK/w0;", "S", "(Lcom/google/android/gms/auth/api/identity/SignInCredential;)Ldbxyzptlk/bK/w0;", "password", "a0", "(Ljava/lang/String;Ljava/lang/String;)V", "Y", "", "loadingMessage", "r0", "(I)V", "C", "()Landroid/content/Intent;", "intent", "s", "(Landroid/content/Intent;)Z", "callbackUri", "a", "f", "data", "i", "(Landroid/content/Intent;Ldbxyzptlk/tI/d;)Ljava/lang/Object;", "credential", "o", "(Lcom/google/android/gms/auth/api/identity/SignInCredential;Ldbxyzptlk/tI/d;)Ljava/lang/Object;", "Lcom/dropbox/common/auth/login/entities/Username;", "username", "Lcom/dropbox/common/auth/login/entities/Password;", "Lcom/dropbox/common/auth/login/wiring/Source;", "source", "u", "(Ljava/lang/String;Ljava/lang/String;Lcom/dropbox/common/auth/login/wiring/Source;Ldbxyzptlk/tI/d;)Ljava/lang/Object;", "k", "b", "Ldbxyzptlk/ag/g;", "ssoService", "h", "(Ldbxyzptlk/ag/g;Ldbxyzptlk/tI/d;)Ljava/lang/Object;", "E", "o0", "Lcom/dropbox/dbapp/auth/login/d$c;", "event", "d0", "(Lcom/dropbox/dbapp/auth/login/d$c;)V", "T", "f0", "l0", "k0", "t0", "V", "c", "Ldbxyzptlk/Cn/a;", "d", "Ldbxyzptlk/kg/c;", "e", "Ldbxyzptlk/ig/c;", "Ldbxyzptlk/jg/c;", "g", "Ldbxyzptlk/ig/a;", "Ldbxyzptlk/lg/c;", "Ldbxyzptlk/dg/b;", "j", "Ldbxyzptlk/ug/I;", "Ldbxyzptlk/mg/k;", "l", "Ldbxyzptlk/Uf/v;", "m", "Ldbxyzptlk/Uf/b;", "n", "Ldbxyzptlk/gg/c;", "Ldbxyzptlk/C8/g;", "Ldbxyzptlk/eK/C;", "Lcom/dropbox/dbapp/auth/login/d$b;", "p", "Ldbxyzptlk/eK/C;", "_transientState", "Ldbxyzptlk/eK/S;", "q", "Ldbxyzptlk/eK/S;", "R", "()Ldbxyzptlk/eK/S;", "transientState", "Lcom/dropbox/dbapp/auth/login/d$a;", "r", "_loadingState", "Q", "loadingState", "Ldbxyzptlk/eK/i;", "t", "Ldbxyzptlk/eK/i;", "kakaoSignInEnabled", "Ldbxyzptlk/C8/i;", "preloadDealType", "Lcom/dropbox/dbapp/auth/login/d$d;", "v", "y", "viewState", "dbapp_auth_login_impl_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class d extends v implements c, c, a, c, c {
  public final dbxyzptlk.Cn.a c;
  
  public final c d;
  
  public final c e;
  
  public final c f;
  
  public final a g;
  
  public final c h;
  
  public final dbxyzptlk.dg.b i;
  
  public final I j;
  
  public final k k;
  
  public final v l;
  
  public final dbxyzptlk.Uf.b m;
  
  public final c n;
  
  public final g o;
  
  public final C<b> p;
  
  public final S<b> q;
  
  public final C<a> r;
  
  public final S<a> s;
  
  public final i<Boolean> t;
  
  public final i<i> u;
  
  public final S<d> v;
  
  public d(dbxyzptlk.Cn.a parama, c paramc, c paramc1, c paramc2, a parama1, c paramc3, dbxyzptlk.dg.b paramb, I paramI, k paramk, v paramv, dbxyzptlk.Uf.b paramb1, c paramc4, g paramg) {
    this.c = parama;
    this.d = paramc;
    this.e = paramc1;
    this.f = paramc2;
    this.g = parama1;
    this.h = paramc3;
    this.i = paramb;
    this.j = paramI;
    this.k = paramk;
    this.l = paramv;
    this.m = paramb1;
    this.n = paramc4;
    this.o = paramg;
    C<b> c1 = U.a(b.d.a);
    this.p = c1;
    this.q = (S<b>)c1;
    c1 = U.a(a.a.a);
    this.r = (C)c1;
    this.s = (S)c1;
    i<Boolean> i1 = k.P(new h(this, null));
    this.t = i1;
    i<i> i2 = k.P(new l(this, null));
    this.u = i2;
    this.v = k.m0(k.n(i1, i2, p.h), w.a((v)this), M.a.b(M.a, 5000L, 0L, 2, null), new d(false, null, 3, null));
  }
  
  private final w0 S(SignInCredential paramSignInCredential) {
    return dbxyzptlk.bK.h.d(w.a((v)this), null, null, (dbxyzptlk.CI.p)new e(paramSignInCredential, this, null), 3, null);
  }
  
  private final void U(Intent paramIntent) {
    Uri uri = paramIntent.getData();
    if (uri != null)
      b0((dbxyzptlk.og.a)new dbxyzptlk.og.a.c(uri)); 
  }
  
  private final void W(Intent paramIntent) {
    s0(this, 0, 1, null);
    dbxyzptlk.bK.h.d(w.a((v)this), null, null, (dbxyzptlk.CI.p)new f(this, paramIntent, null), 3, null);
  }
  
  private final void X(Intent paramIntent) {
    s0(this, 0, 1, null);
    dbxyzptlk.bK.h.d(w.a((v)this), null, null, (dbxyzptlk.CI.p)new g(this, paramIntent, null), 3, null);
  }
  
  private final boolean Z(String paramString) {
    boolean bool;
    if (dbxyzptlk.He.p.h(paramString)) {
      this.l.b();
      bool = true;
    } else {
      this.l.f(c.INVALID_EMAIL_FORMAT);
      bool = false;
    } 
    return bool;
  }
  
  private final void a0(String paramString1, String paramString2) {
    if (!Z(paramString1)) {
      Y();
      b0((dbxyzptlk.og.a)new dbxyzptlk.og.a.r(0, s.auth_error_invalid_email, null, 5, null));
    } else {
      s0(this, 0, 1, null);
      dbxyzptlk.bK.h.d(w.a((v)this), null, null, (dbxyzptlk.CI.p)new i(this, paramString1, paramString2, null), 3, null);
    } 
  }
  
  private final void c0() {
    this.l.g();
  }
  
  private final void q0(String paramString) {
    paramString = u.m1(paramString).toString();
    if (!Z(paramString)) {
      b0((dbxyzptlk.og.a)new dbxyzptlk.og.a.r(0, s.auth_error_invalid_email, null, 5, null));
      return;
    } 
    s0(this, 0, 1, null);
    dbxyzptlk.bK.h.d(w.a((v)this), null, null, (dbxyzptlk.CI.p)new n(this, paramString, null), 3, null);
  }
  
  public Intent C() {
    return this.f.C();
  }
  
  public Object E(String paramString, dbxyzptlk.tI.d<? super dbxyzptlk.og.a> paramd) {
    return this.d.E(paramString, paramd);
  }
  
  public final S<a> Q() {
    return this.s;
  }
  
  public final S<b> R() {
    return this.q;
  }
  
  public final void T(Intent paramIntent) {
    s.h(paramIntent, "intent");
    if (s(paramIntent)) {
      W(paramIntent);
    } else if (b(paramIntent)) {
      X(paramIntent);
    } else if (this.k.b(paramIntent)) {
      U(paramIntent);
    } 
  }
  
  public final void V(Intent paramIntent) {
    s.h(paramIntent, "intent");
    SignInCredential signInCredential = this.i.d(paramIntent);
    if (signInCredential != null)
      S(signInCredential); 
  }
  
  public final void Y() {
    Object object;
    C<a> c1 = this.r;
    do {
      object = c1.getValue();
      a a1 = (a)object;
    } while (!c1.compareAndSet(object, a.a.a));
  }
  
  public Object a(String paramString, dbxyzptlk.tI.d<? super dbxyzptlk.og.a> paramd) {
    return this.f.a(paramString, paramd);
  }
  
  public boolean b(Intent paramIntent) {
    s.h(paramIntent, "intent");
    return this.d.b(paramIntent);
  }
  
  public final void b0(dbxyzptlk.og.a parama) {
    Object object;
    b.c c1 = new b.c(parama);
    C<b> c2 = this.p;
    do {
      object = c2.getValue();
      b b1 = (b)object;
    } while (!c2.compareAndSet(object, c1));
  }
  
  public final void d0(c paramc) {
    s.h(paramc, "event");
    if (paramc instanceof c.d) {
      h0(((c.d)paramc).a());
    } else if (paramc instanceof c.g) {
      m0(((c.g)paramc).a());
    } else if (paramc instanceof c.e) {
      i0(((c.e)paramc).a());
    } else if (paramc instanceof c.f) {
      j0(((c.f)paramc).a());
    } else if (paramc instanceof c.h) {
      n0(((c.h)paramc).a());
    } else if (s.c(paramc, c.b.a)) {
      e0();
    } else if (s.c(paramc, c.a.a)) {
      c0();
    } else if (s.c(paramc, c.c.a)) {
      g0();
    } 
  }
  
  public final void e0() {
    Object object;
    this.l.c();
    C<b> c1 = this.p;
    do {
      object = c1.getValue();
      b b1 = (b)object;
    } while (!c1.compareAndSet(object, b.b.a));
  }
  
  public Intent f() {
    return this.e.f();
  }
  
  public final void f0(Intent paramIntent) {
    s0(this, 0, 1, null);
    dbxyzptlk.bK.h.d(w.a((v)this), null, null, (dbxyzptlk.CI.p)new j(this, paramIntent, null), 3, null);
  }
  
  public final void g0() {
    this.l.d();
    s0(this, 0, 1, null);
    dbxyzptlk.bK.h.d(w.a((v)this), null, null, (dbxyzptlk.CI.p)new k(this, null), 3, null);
  }
  
  public Object h(g paramg, dbxyzptlk.tI.d<? super dbxyzptlk.og.a> paramd) {
    return this.d.h(paramg, paramd);
  }
  
  public final void h0(LoginSurface paramLoginSurface) {
    if (s.c(paramLoginSurface, LoginSurface.Default.a)) {
      this.c.e();
      this.c.c();
    } else {
      s.c(paramLoginSurface, LoginSurface.SignupSigninBottomSheet.a);
    } 
  }
  
  public Object i(Intent paramIntent, dbxyzptlk.tI.d<? super dbxyzptlk.og.a> paramd) {
    return this.e.i(paramIntent, paramd);
  }
  
  public final void i0(String paramString) {
    b0((dbxyzptlk.og.a)new dbxyzptlk.og.a.w(u.m1(paramString).toString(), c.SIGN_IN_PAGE));
  }
  
  public final void j0(String paramString) {
    q0(paramString);
  }
  
  public Object k(Intent paramIntent, dbxyzptlk.tI.d<? super dbxyzptlk.og.a> paramd) {
    return this.d.k(paramIntent, paramd);
  }
  
  public final void k0(LoginSurface paramLoginSurface) {
    s.h(paramLoginSurface, "loginSurface");
    if (!s.c(paramLoginSurface, LoginSurface.Default.a) && s.c(paramLoginSurface, LoginSurface.SignupSigninBottomSheet.a))
      this.c.b(); 
  }
  
  public final void l0(LoginSurface paramLoginSurface) {
    s.h(paramLoginSurface, "loginSurface");
    if (s.c(paramLoginSurface, LoginSurface.Default.a)) {
      this.l.a();
    } else if (s.c(paramLoginSurface, LoginSurface.SignupSigninBottomSheet.a)) {
      this.c.g();
    } 
  }
  
  public final void m0(LoginSurface paramLoginSurface) {
    if (s.c(paramLoginSurface, LoginSurface.Default.a)) {
      this.c.a();
      this.c.d();
    } else {
      s.c(paramLoginSurface, LoginSurface.SignupSigninBottomSheet.a);
    } 
  }
  
  public final void n0(String paramString) {
    q0(paramString);
  }
  
  public Object o(SignInCredential paramSignInCredential, dbxyzptlk.tI.d<? super dbxyzptlk.og.a> paramd) {
    return this.g.o(paramSignInCredential, paramd);
  }
  
  public final void o0() {
    Object object;
    C<b> c1 = this.p;
    do {
      object = c1.getValue();
      b b1 = (b)object;
    } while (!c1.compareAndSet(object, b.d.a));
  }
  
  public final Object p0(String paramString, dbxyzptlk.tI.d<? super dbxyzptlk.og.a> paramd) {
    // Byte code:
    //   0: aload_2
    //   1: instanceof com/dropbox/dbapp/auth/login/d$m
    //   4: ifeq -> 43
    //   7: aload_2
    //   8: checkcast com/dropbox/dbapp/auth/login/d$m
    //   11: astore #4
    //   13: aload #4
    //   15: getfield x : I
    //   18: istore_3
    //   19: iload_3
    //   20: ldc_w -2147483648
    //   23: iand
    //   24: ifeq -> 43
    //   27: aload #4
    //   29: iload_3
    //   30: ldc_w -2147483648
    //   33: iadd
    //   34: putfield x : I
    //   37: aload #4
    //   39: astore_2
    //   40: goto -> 53
    //   43: new com/dropbox/dbapp/auth/login/d$m
    //   46: dup
    //   47: aload_0
    //   48: aload_2
    //   49: invokespecial <init> : (Lcom/dropbox/dbapp/auth/login/d;Ldbxyzptlk/tI/d;)V
    //   52: astore_2
    //   53: aload_2
    //   54: getfield v : Ljava/lang/Object;
    //   57: astore #4
    //   59: invokestatic g : ()Ljava/lang/Object;
    //   62: astore #5
    //   64: aload_2
    //   65: getfield x : I
    //   68: istore_3
    //   69: iload_3
    //   70: ifeq -> 113
    //   73: iload_3
    //   74: iconst_1
    //   75: if_icmpne -> 102
    //   78: aload_2
    //   79: getfield u : Ljava/lang/Object;
    //   82: checkcast java/lang/String
    //   85: astore_1
    //   86: aload_2
    //   87: getfield t : Ljava/lang/Object;
    //   90: checkcast com/dropbox/dbapp/auth/login/d
    //   93: astore_2
    //   94: aload #4
    //   96: invokestatic b : (Ljava/lang/Object;)V
    //   99: goto -> 165
    //   102: new java/lang/IllegalStateException
    //   105: dup
    //   106: ldc_w 'call to 'resume' before 'invoke' with coroutine'
    //   109: invokespecial <init> : (Ljava/lang/String;)V
    //   112: athrow
    //   113: aload #4
    //   115: invokestatic b : (Ljava/lang/Object;)V
    //   118: aload_0
    //   119: getfield m : Ldbxyzptlk/Uf/b;
    //   122: astore #4
    //   124: aload_2
    //   125: aload_0
    //   126: putfield t : Ljava/lang/Object;
    //   129: aload_2
    //   130: aload_1
    //   131: putfield u : Ljava/lang/Object;
    //   134: aload_2
    //   135: iconst_1
    //   136: putfield x : I
    //   139: aload #4
    //   141: aload_1
    //   142: aload_2
    //   143: invokeinterface a : (Ljava/lang/String;Ldbxyzptlk/tI/d;)Ljava/lang/Object;
    //   148: astore #4
    //   150: aload #4
    //   152: aload #5
    //   154: if_acmpne -> 160
    //   157: aload #5
    //   159: areturn
    //   160: aload_0
    //   161: astore_2
    //   162: goto -> 99
    //   165: aload #4
    //   167: checkcast dbxyzptlk/ag/j
    //   170: astore #4
    //   172: aload_2
    //   173: getfield l : Ldbxyzptlk/Uf/v;
    //   176: invokeinterface e : ()V
    //   181: aload #4
    //   183: instanceof dbxyzptlk/ag/j$b
    //   186: ifeq -> 220
    //   189: aload_2
    //   190: getfield l : Ldbxyzptlk/Uf/v;
    //   193: invokeinterface h : ()V
    //   198: new dbxyzptlk/og/a$i
    //   201: dup
    //   202: iconst_0
    //   203: aload #4
    //   205: checkcast dbxyzptlk/ag/j$b
    //   208: invokevirtual a : ()Ljava/lang/String;
    //   211: iconst_1
    //   212: aconst_null
    //   213: invokespecial <init> : (ZLjava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V
    //   216: astore_1
    //   217: goto -> 415
    //   220: aload #4
    //   222: instanceof dbxyzptlk/ag/j$c
    //   225: ifeq -> 254
    //   228: aload_2
    //   229: getfield l : Ldbxyzptlk/Uf/v;
    //   232: invokeinterface h : ()V
    //   237: new dbxyzptlk/og/a$d
    //   240: dup
    //   241: aload_1
    //   242: aconst_null
    //   243: iconst_0
    //   244: bipush #6
    //   246: aconst_null
    //   247: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;ZILkotlin/jvm/internal/DefaultConstructorMarker;)V
    //   250: astore_1
    //   251: goto -> 415
    //   254: aload #4
    //   256: getstatic dbxyzptlk/ag/j$a.a : Ldbxyzptlk/ag/j$a;
    //   259: invokestatic c : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   262: ifeq -> 295
    //   265: aload_2
    //   266: getfield l : Ldbxyzptlk/Uf/v;
    //   269: getstatic dbxyzptlk/Uf/c.API : Ldbxyzptlk/Uf/c;
    //   272: invokeinterface f : (Ldbxyzptlk/Uf/c;)V
    //   277: new dbxyzptlk/og/a$r
    //   280: dup
    //   281: iconst_0
    //   282: getstatic dbxyzptlk/Rf/s.auth_error_unknown : I
    //   285: aconst_null
    //   286: iconst_5
    //   287: aconst_null
    //   288: invokespecial <init> : (IILjava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V
    //   291: astore_1
    //   292: goto -> 415
    //   295: aload #4
    //   297: getstatic dbxyzptlk/ag/j$e.a : Ldbxyzptlk/ag/j$e;
    //   300: invokestatic c : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   303: ifeq -> 336
    //   306: aload_2
    //   307: getfield l : Ldbxyzptlk/Uf/v;
    //   310: getstatic dbxyzptlk/Uf/c.NETWORK : Ldbxyzptlk/Uf/c;
    //   313: invokeinterface f : (Ldbxyzptlk/Uf/c;)V
    //   318: new dbxyzptlk/og/a$r
    //   321: dup
    //   322: iconst_0
    //   323: getstatic dbxyzptlk/Rf/s.auth_error_network_error : I
    //   326: aconst_null
    //   327: iconst_5
    //   328: aconst_null
    //   329: invokespecial <init> : (IILjava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V
    //   332: astore_1
    //   333: goto -> 415
    //   336: aload #4
    //   338: getstatic dbxyzptlk/ag/j$d.a : Ldbxyzptlk/ag/j$d;
    //   341: invokestatic c : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   344: ifeq -> 377
    //   347: aload_2
    //   348: getfield l : Ldbxyzptlk/Uf/v;
    //   351: getstatic dbxyzptlk/Uf/c.INVALID_EMAIL_FORMAT : Ldbxyzptlk/Uf/c;
    //   354: invokeinterface f : (Ldbxyzptlk/Uf/c;)V
    //   359: new dbxyzptlk/og/a$r
    //   362: dup
    //   363: iconst_0
    //   364: getstatic dbxyzptlk/Rf/s.auth_error_invalid_email : I
    //   367: aconst_null
    //   368: iconst_5
    //   369: aconst_null
    //   370: invokespecial <init> : (IILjava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V
    //   373: astore_1
    //   374: goto -> 415
    //   377: aload #4
    //   379: getstatic dbxyzptlk/ag/j$f.a : Ldbxyzptlk/ag/j$f;
    //   382: invokestatic c : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   385: ifeq -> 417
    //   388: aload_2
    //   389: getfield l : Ldbxyzptlk/Uf/v;
    //   392: getstatic dbxyzptlk/Uf/c.OTHER : Ldbxyzptlk/Uf/c;
    //   395: invokeinterface f : (Ldbxyzptlk/Uf/c;)V
    //   400: new dbxyzptlk/og/a$r
    //   403: dup
    //   404: iconst_0
    //   405: getstatic dbxyzptlk/Rf/s.auth_error_unknown : I
    //   408: aconst_null
    //   409: iconst_5
    //   410: aconst_null
    //   411: invokespecial <init> : (IILjava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V
    //   414: astore_1
    //   415: aload_1
    //   416: areturn
    //   417: new kotlin/NoWhenBranchMatchedException
    //   420: dup
    //   421: invokespecial <init> : ()V
    //   424: athrow
  }
  
  public final void r0(int paramInt) {
    a a1;
    Object object;
    C<a> c1 = this.r;
    do {
      object = c1.getValue();
      a1 = (a)object;
    } while (!c1.compareAndSet(object, new a.b(paramInt)));
  }
  
  public boolean s(Intent paramIntent) {
    s.h(paramIntent, "intent");
    return this.f.s(paramIntent);
  }
  
  public final void t0() {
    dbxyzptlk.bK.h.d(w.a((v)this), null, null, new o(this, null), 3, null);
  }
  
  public Object u(String paramString1, String paramString2, Source paramSource, dbxyzptlk.tI.d<? super dbxyzptlk.og.a> paramd) {
    return this.h.u(paramString1, paramString2, paramSource, paramd);
  }
  
  public final S<d> y() {
    return this.v;
  }
  
  @Metadata(d1 = {"\000\026\n\002\030\002\n\002\020\000\n\002\b\002\n\002\030\002\n\002\030\002\n\000\bv\030\0002\0020\001:\002\002\003\001\002\004\005ø\001\000\002\006\n\004\b!0\001¨\006\006À\006\001"}, d2 = {"Lcom/dropbox/dbapp/auth/login/d$a;", "", "a", "b", "Lcom/dropbox/dbapp/auth/login/d$a$a;", "Lcom/dropbox/dbapp/auth/login/d$a$b;", "dbapp_auth_login_impl_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
  public static interface a {
    @Metadata(d1 = {"\000*\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\016\n\002\b\002\n\002\020\b\n\002\b\002\n\002\020\000\n\000\n\002\020\013\n\002\b\003\bÇ\n\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\020\020\005\032\0020\004HÖ\001¢\006\004\b\005\020\006J\020\020\b\032\0020\007HÖ\001¢\006\004\b\b\020\tJ\032\020\r\032\0020\f2\b\020\013\032\004\030\0010\nHÖ\003¢\006\004\b\r\020\016¨\006\017"}, d2 = {"Lcom/dropbox/dbapp/auth/login/d$a$a;", "Lcom/dropbox/dbapp/auth/login/d$a;", "<init>", "()V", "", "toString", "()Ljava/lang/String;", "", "hashCode", "()I", "", "other", "", "equals", "(Ljava/lang/Object;)Z", "dbapp_auth_login_impl_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class a implements a {
      public static final a a = new a();
      
      public boolean equals(Object param2Object) {
        return (this == param2Object) ? true : (!!(param2Object instanceof a));
      }
      
      public int hashCode() {
        return -569202574;
      }
      
      public String toString() {
        return "Hidden";
      }
    }
    
    @Metadata(d1 = {"\000&\n\002\030\002\n\002\030\002\n\002\020\b\n\002\b\003\n\002\020\016\n\002\b\004\n\002\020\000\n\000\n\002\020\013\n\002\b\005\b\b\030\0002\0020\001B\021\022\b\b\001\020\003\032\0020\002¢\006\004\b\004\020\005J\020\020\007\032\0020\006HÖ\001¢\006\004\b\007\020\bJ\020\020\t\032\0020\002HÖ\001¢\006\004\b\t\020\nJ\032\020\016\032\0020\r2\b\020\f\032\004\030\0010\013HÖ\003¢\006\004\b\016\020\017R\027\020\003\032\0020\0028\006¢\006\f\n\004\b\020\020\021\032\004\b\020\020\n¨\006\022"}, d2 = {"Lcom/dropbox/dbapp/auth/login/d$a$b;", "Lcom/dropbox/dbapp/auth/login/d$a;", "", "msg", "<init>", "(I)V", "", "toString", "()Ljava/lang/String;", "hashCode", "()I", "", "other", "", "equals", "(Ljava/lang/Object;)Z", "a", "I", "dbapp_auth_login_impl_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class b implements a {
      public final int a;
      
      public b(int param2Int) {
        this.a = param2Int;
      }
      
      public final int a() {
        return this.a;
      }
      
      public boolean equals(Object param2Object) {
        if (this == param2Object)
          return true; 
        if (!(param2Object instanceof b))
          return false; 
        param2Object = param2Object;
        return !(this.a != ((b)param2Object).a);
      }
      
      public int hashCode() {
        return Integer.hashCode(this.a);
      }
      
      public String toString() {
        int i = this.a;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Visible(msg=");
        stringBuilder.append(i);
        stringBuilder.append(")");
        return stringBuilder.toString();
      }
    }
  }
  
  @Metadata(d1 = {"\000*\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\016\n\002\b\002\n\002\020\b\n\002\b\002\n\002\020\000\n\000\n\002\020\013\n\002\b\003\bÇ\n\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\020\020\005\032\0020\004HÖ\001¢\006\004\b\005\020\006J\020\020\b\032\0020\007HÖ\001¢\006\004\b\b\020\tJ\032\020\r\032\0020\f2\b\020\013\032\004\030\0010\nHÖ\003¢\006\004\b\r\020\016¨\006\017"}, d2 = {"Lcom/dropbox/dbapp/auth/login/d$a$a;", "Lcom/dropbox/dbapp/auth/login/d$a;", "<init>", "()V", "", "toString", "()Ljava/lang/String;", "", "hashCode", "()I", "", "other", "", "equals", "(Ljava/lang/Object;)Z", "dbapp_auth_login_impl_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
  public static final class a implements a {
    public static final a a = new a();
    
    public boolean equals(Object param1Object) {
      return (this == param1Object) ? true : (!!(param1Object instanceof a));
    }
    
    public int hashCode() {
      return -569202574;
    }
    
    public String toString() {
      return "Hidden";
    }
  }
  
  @Metadata(d1 = {"\000&\n\002\030\002\n\002\030\002\n\002\020\b\n\002\b\003\n\002\020\016\n\002\b\004\n\002\020\000\n\000\n\002\020\013\n\002\b\005\b\b\030\0002\0020\001B\021\022\b\b\001\020\003\032\0020\002¢\006\004\b\004\020\005J\020\020\007\032\0020\006HÖ\001¢\006\004\b\007\020\bJ\020\020\t\032\0020\002HÖ\001¢\006\004\b\t\020\nJ\032\020\016\032\0020\r2\b\020\f\032\004\030\0010\013HÖ\003¢\006\004\b\016\020\017R\027\020\003\032\0020\0028\006¢\006\f\n\004\b\020\020\021\032\004\b\020\020\n¨\006\022"}, d2 = {"Lcom/dropbox/dbapp/auth/login/d$a$b;", "Lcom/dropbox/dbapp/auth/login/d$a;", "", "msg", "<init>", "(I)V", "", "toString", "()Ljava/lang/String;", "hashCode", "()I", "", "other", "", "equals", "(Ljava/lang/Object;)Z", "a", "I", "dbapp_auth_login_impl_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
  public static final class b implements a {
    public final int a;
    
    public b(int param1Int) {
      this.a = param1Int;
    }
    
    public final int a() {
      return this.a;
    }
    
    public boolean equals(Object param1Object) {
      if (this == param1Object)
        return true; 
      if (!(param1Object instanceof b))
        return false; 
      param1Object = param1Object;
      return !(this.a != ((b)param1Object).a);
    }
    
    public int hashCode() {
      return Integer.hashCode(this.a);
    }
    
    public String toString() {
      int i = this.a;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Visible(msg=");
      stringBuilder.append(i);
      stringBuilder.append(")");
      return stringBuilder.toString();
    }
  }
  
  @Metadata(d1 = {"\000\036\n\002\030\002\n\002\020\000\n\002\b\004\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\000\bv\030\0002\0020\001:\004\002\003\004\005\001\004\006\007\b\tø\001\000\002\006\n\004\b!0\001¨\006\nÀ\006\001"}, d2 = {"Lcom/dropbox/dbapp/auth/login/d$b;", "", "a", "b", "c", "d", "Lcom/dropbox/dbapp/auth/login/d$b$a;", "Lcom/dropbox/dbapp/auth/login/d$b$b;", "Lcom/dropbox/dbapp/auth/login/d$b$c;", "Lcom/dropbox/dbapp/auth/login/d$b$d;", "dbapp_auth_login_impl_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
  public static interface b {
    class b {}
    
    class b {}
    
    class b {}
    
    @Metadata(d1 = {"\000*\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\016\n\002\b\002\n\002\020\b\n\002\b\002\n\002\020\000\n\000\n\002\020\013\n\002\b\003\bÇ\n\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\020\020\005\032\0020\004HÖ\001¢\006\004\b\005\020\006J\020\020\b\032\0020\007HÖ\001¢\006\004\b\b\020\tJ\032\020\r\032\0020\f2\b\020\013\032\004\030\0010\nHÖ\003¢\006\004\b\r\020\016¨\006\017"}, d2 = {"Lcom/dropbox/dbapp/auth/login/d$b$d;", "Lcom/dropbox/dbapp/auth/login/d$b;", "<init>", "()V", "", "toString", "()Ljava/lang/String;", "", "hashCode", "()I", "", "other", "", "equals", "(Ljava/lang/Object;)Z", "dbapp_auth_login_impl_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    public static final class d implements b {
      public static final d a = new d();
      
      public boolean equals(Object param2Object) {
        return (this == param2Object) ? true : (!!(param2Object instanceof d));
      }
      
      public int hashCode() {
        return 509623310;
      }
      
      public String toString() {
        return "None";
      }
    }
  }
  
  class d {}
  
  class d {}
  
  class d {}
  
  @Metadata(d1 = {"\000*\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\016\n\002\b\002\n\002\020\b\n\002\b\002\n\002\020\000\n\000\n\002\020\013\n\002\b\003\bÇ\n\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\020\020\005\032\0020\004HÖ\001¢\006\004\b\005\020\006J\020\020\b\032\0020\007HÖ\001¢\006\004\b\b\020\tJ\032\020\r\032\0020\f2\b\020\013\032\004\030\0010\nHÖ\003¢\006\004\b\r\020\016¨\006\017"}, d2 = {"Lcom/dropbox/dbapp/auth/login/d$b$d;", "Lcom/dropbox/dbapp/auth/login/d$b;", "<init>", "()V", "", "toString", "()Ljava/lang/String;", "", "hashCode", "()I", "", "other", "", "equals", "(Ljava/lang/Object;)Z", "dbapp_auth_login_impl_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
  public static final class d implements b {
    public static final d a = new d();
    
    public boolean equals(Object param1Object) {
      return (this == param1Object) ? true : (!!(param1Object instanceof d));
    }
    
    public int hashCode() {
      return 509623310;
    }
    
    public String toString() {
      return "None";
    }
  }
  
  class d {}
  
  @Metadata(d1 = {"\000&\n\002\030\002\n\002\020\000\n\002\020\013\n\000\n\002\030\002\n\002\b\003\n\002\020\016\n\002\b\002\n\002\020\b\n\002\b\f\b\b\030\0002\0020\001B\035\022\b\b\002\020\003\032\0020\002\022\n\b\002\020\005\032\004\030\0010\004¢\006\004\b\006\020\007J\020\020\t\032\0020\bHÖ\001¢\006\004\b\t\020\nJ\020\020\f\032\0020\013HÖ\001¢\006\004\b\f\020\rJ\032\020\017\032\0020\0022\b\020\016\032\004\030\0010\001HÖ\003¢\006\004\b\017\020\020R\027\020\003\032\0020\0028\006¢\006\f\n\004\b\021\020\022\032\004\b\023\020\024R\031\020\005\032\004\030\0010\0048\006¢\006\f\n\004\b\023\020\025\032\004\b\021\020\026¨\006\027"}, d2 = {"Lcom/dropbox/dbapp/auth/login/d$d;", "", "", "isKakaoSignInEnabled", "Ldbxyzptlk/C8/i;", "pendingDealType", "<init>", "(ZLdbxyzptlk/C8/i;)V", "", "toString", "()Ljava/lang/String;", "", "hashCode", "()I", "other", "equals", "(Ljava/lang/Object;)Z", "a", "Z", "b", "()Z", "Ldbxyzptlk/C8/i;", "()Ldbxyzptlk/C8/i;", "dbapp_auth_login_impl_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
  public static final class d {
    public final boolean a;
    
    public final i b;
    
    public d() {
      this(false, null, 3, null);
    }
    
    public d(boolean param1Boolean, i param1i) {
      this.a = param1Boolean;
      this.b = param1i;
    }
    
    public final i a() {
      return this.b;
    }
    
    public final boolean b() {
      return this.a;
    }
    
    public boolean equals(Object param1Object) {
      if (this == param1Object)
        return true; 
      if (!(param1Object instanceof d))
        return false; 
      param1Object = param1Object;
      return (this.a != ((d)param1Object).a) ? false : (!(this.b != ((d)param1Object).b));
    }
    
    public int hashCode() {
      int j;
      int k = Boolean.hashCode(this.a);
      i i1 = this.b;
      if (i1 == null) {
        j = 0;
      } else {
        j = i1.hashCode();
      } 
      return k * 31 + j;
    }
    
    public String toString() {
      boolean bool = this.a;
      i i1 = this.b;
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("ViewState(isKakaoSignInEnabled=");
      stringBuilder.append(bool);
      stringBuilder.append(", pendingDealType=");
      stringBuilder.append(i1);
      stringBuilder.append(")");
      return stringBuilder.toString();
    }
  }
  
  @f(c = "com.dropbox.dbapp.auth.login.DbappLoginViewModel$kakaoSignInEnabled$1", f = "DbappLoginViewModel.kt", l = {76, 76}, m = "invokeSuspend")
  @Metadata(d1 = {"\000\020\n\002\030\002\n\002\020\013\n\002\030\002\n\002\b\002\020\003\032\0020\002*\b\022\004\022\0020\0010\000H@¢\006\004\b\003\020\004"}, d2 = {"Ldbxyzptlk/eK/j;", "", "Ldbxyzptlk/pI/D;", "<anonymous>", "(Ldbxyzptlk/eK/j;)V"}, k = 3, mv = {1, 9, 0})
  public static final class h extends dbxyzptlk.vI.l implements dbxyzptlk.CI.p<j<? super Boolean>, dbxyzptlk.tI.d<? super D>, Object> {
    public int t;
    
    public Object u;
    
    public final d v;
    
    public h(d param1d, dbxyzptlk.tI.d<? super h> param1d1) {
      super(2, param1d1);
    }
    
    public final Object a(j<? super Boolean> param1j, dbxyzptlk.tI.d<? super D> param1d) {
      return ((h)create(param1j, param1d)).invokeSuspend(D.a);
    }
    
    public final dbxyzptlk.tI.d<D> create(Object param1Object, dbxyzptlk.tI.d<?> param1d) {
      h h1 = new h(this.v, (dbxyzptlk.tI.d)param1d);
      h1.u = param1Object;
      return (dbxyzptlk.tI.d<D>)h1;
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = c.g();
      int i = this.t;
      if (i != 0) {
        if (i != 1) {
          if (i == 2) {
            dbxyzptlk.pI.p.b(param1Object);
          } else {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
          } 
        } else {
          j j = (j)this.u;
          dbxyzptlk.pI.p.b(param1Object);
          this.u = null;
          this.t = 2;
        } 
      } else {
        dbxyzptlk.pI.p.b(param1Object);
        j j = (j)this.u;
        param1Object = d.G(this.v);
        this.u = j;
        this.t = 1;
        Object object1 = param1Object.a((dbxyzptlk.tI.d)this);
        param1Object = object1;
        if (object1 == object)
          return object; 
        this.u = null;
        this.t = 2;
      } 
      return D.a;
    }
  }
  
  @f(c = "com.dropbox.dbapp.auth.login.DbappLoginViewModel$preloadDealType$1", f = "DbappLoginViewModel.kt", l = {78, 79}, m = "invokeSuspend")
  @Metadata(d1 = {"\000\020\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\002\020\003\032\0020\002*\n\022\006\022\004\030\0010\0010\000H@¢\006\004\b\003\020\004"}, d2 = {"Ldbxyzptlk/eK/j;", "Ldbxyzptlk/C8/i;", "Ldbxyzptlk/pI/D;", "<anonymous>", "(Ldbxyzptlk/eK/j;)V"}, k = 3, mv = {1, 9, 0})
  public static final class l extends dbxyzptlk.vI.l implements dbxyzptlk.CI.p<j<? super i>, dbxyzptlk.tI.d<? super D>, Object> {
    public int t;
    
    public Object u;
    
    public final d v;
    
    public l(d param1d, dbxyzptlk.tI.d<? super l> param1d1) {
      super(2, param1d1);
    }
    
    public final Object a(j<? super i> param1j, dbxyzptlk.tI.d<? super D> param1d) {
      return ((l)create(param1j, param1d)).invokeSuspend(D.a);
    }
    
    public final dbxyzptlk.tI.d<D> create(Object param1Object, dbxyzptlk.tI.d<?> param1d) {
      l l1 = new l(this.v, (dbxyzptlk.tI.d)param1d);
      l1.u = param1Object;
      return (dbxyzptlk.tI.d<D>)l1;
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = c.g();
      int i = this.t;
      if (i != 0) {
        if (i != 1) {
          if (i == 2) {
            dbxyzptlk.pI.p.b(param1Object);
          } else {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
          } 
        } else {
          j j = (j)this.u;
          dbxyzptlk.pI.p.b(param1Object);
          param1Object = param1Object;
        } 
      } else {
        dbxyzptlk.pI.p.b(param1Object);
        j j = (j)this.u;
        param1Object = d.H(this.v);
        this.u = j;
        this.t = 1;
        Object object1 = param1Object.b((dbxyzptlk.tI.d)this);
        param1Object = object1;
        if (object1 == object)
          return object; 
        param1Object = param1Object;
      } 
      return D.a;
    }
  }
  
  @f(c = "com.dropbox.dbapp.auth.login.DbappLoginViewModel$startGoogleOneTap$1", f = "DbappLoginViewModel.kt", l = {294, 296}, m = "invokeSuspend")
  @Metadata(d1 = {"\000\f\n\002\030\002\n\002\030\002\n\002\b\002\020\002\032\0020\001*\0020\000H@¢\006\004\b\002\020\003"}, d2 = {"Ldbxyzptlk/bK/J;", "Ldbxyzptlk/pI/D;", "<anonymous>", "(Ldbxyzptlk/bK/J;)V"}, k = 3, mv = {1, 9, 0})
  public static final class o extends dbxyzptlk.vI.l implements dbxyzptlk.CI.p<J, dbxyzptlk.tI.d<? super D>, Object> {
    public int t;
    
    public final d u;
    
    public o(d param1d, dbxyzptlk.tI.d<? super o> param1d1) {
      super(2, param1d1);
    }
    
    public final dbxyzptlk.tI.d<D> create(Object param1Object, dbxyzptlk.tI.d<?> param1d) {
      return (dbxyzptlk.tI.d<D>)new o(this.u, (dbxyzptlk.tI.d)param1d);
    }
    
    public final Object invoke(J param1J, dbxyzptlk.tI.d<? super D> param1d) {
      return ((o)create(param1J, param1d)).invokeSuspend(D.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = c.g();
      int i = this.t;
      if (i != 0) {
        if (i != 1) {
          if (i == 2) {
            dbxyzptlk.pI.p.b(param1Object);
          } else {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
          } 
        } else {
          dbxyzptlk.pI.p.b(param1Object);
          BeginSignInResult beginSignInResult = (BeginSignInResult)param1Object;
        } 
      } else {
        dbxyzptlk.pI.p.b(param1Object);
        d.O(this.u, s.auth_please_wait);
        param1Object = d.F(this.u);
        this.t = 1;
        Object object1 = param1Object.b((dbxyzptlk.tI.d)this);
        param1Object = object1;
        if (object1 == object)
          return object; 
        object1 = param1Object;
      } 
      d.K(this.u);
      return D.a;
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\dbapp\auth\login\d.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */