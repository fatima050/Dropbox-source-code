package com.dropbox.dbapp.auth.login;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import androidx.activity.ComponentActivity;
import androidx.annotation.Keep;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.o;
import androidx.lifecycle.e;
import androidx.lifecycle.s;
import androidx.lifecycle.t;
import com.dropbox.common.activity.BaseActivity;
import com.dropbox.common.auth.login.api.AuthLaunchSource;
import dbxyzptlk.DI.L;
import dbxyzptlk.DI.s;
import dbxyzptlk.DI.u;
import dbxyzptlk.En.n;
import dbxyzptlk.En.r;
import dbxyzptlk.En.s;
import dbxyzptlk.Eq.d;
import dbxyzptlk.Fq.f;
import dbxyzptlk.Rf.g;
import dbxyzptlk.Rf.l;
import dbxyzptlk.U2.v;
import dbxyzptlk.U2.w;
import dbxyzptlk.U2.y;
import dbxyzptlk.U2.z;
import dbxyzptlk.pI.j;
import dbxyzptlk.pI.k;
import dbxyzptlk.yj.e;
import dbxyzptlk.zj.h;
import java.util.concurrent.ConcurrentHashMap;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;

@Metadata(d1 = {"\000~\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\007\n\002\030\002\n\002\b\005\n\002\030\002\n\002\b\007\n\002\030\002\n\002\b\007\n\002\030\002\n\002\b\007\n\002\020\000\n\002\b\004\n\002\030\002\n\002\b\006\b\007\030\000 G2\0020\0012\0020\0022\0020\0032\0020\0042\b\022\004\022\0020\0060\005:\001HB\007¢\006\004\b\007\020\bJ\031\020\f\032\0020\0132\b\020\n\032\004\030\0010\tH\024¢\006\004\b\f\020\rJ\027\020\020\032\0020\0132\006\020\017\032\0020\016H\024¢\006\004\b\020\020\021J\025\020\023\032\b\022\004\022\0020\0060\022H\026¢\006\004\b\023\020\024J\017\020\026\032\0020\025H\002¢\006\004\b\026\020\027R\"\020\037\032\0020\0308\006@\006X.¢\006\022\n\004\b\031\020\032\032\004\b\033\020\034\"\004\b\035\020\036R\033\020%\032\0020 8BX\002¢\006\f\n\004\b!\020\"\032\004\b#\020$R\"\020-\032\0020&8\006@\006X.¢\006\022\n\004\b'\020(\032\004\b)\020*\"\004\b+\020,R\"\0205\032\0020.8\006@\006X.¢\006\022\n\004\b/\0200\032\004\b1\0202\"\004\b3\0204R\"\020=\032\002068\006@\006X.¢\006\022\n\004\b7\0208\032\004\b9\020:\"\004\b;\020<R\033\020B\032\0020>8VX\002¢\006\f\n\004\b?\020\"\032\004\b@\020AR\024\020F\032\0020C8VX\004¢\006\006\032\004\bD\020E¨\006I"}, d2 = {"Lcom/dropbox/dbapp/auth/login/DbappLoginActivity;", "Lcom/dropbox/common/activity/BaseActivity;", "Landroidx/lifecycle/e;", "Ldbxyzptlk/yj/e;", "Ldbxyzptlk/Fq/f;", "Ldbxyzptlk/Eq/d;", "Lcom/dropbox/dbapp/auth/login/b;", "<init>", "()V", "Landroid/os/Bundle;", "savedInstanceState", "Ldbxyzptlk/pI/D;", "onCreate", "(Landroid/os/Bundle;)V", "Landroid/content/Intent;", "intent", "onNewIntent", "(Landroid/content/Intent;)V", "Ldbxyzptlk/Eq/b;", "i3", "()Ldbxyzptlk/Eq/b;", "Lcom/dropbox/common/auth/login/api/AuthLaunchSource;", "D4", "()Lcom/dropbox/common/auth/login/api/AuthLaunchSource;", "Ldbxyzptlk/En/n;", "c", "Ldbxyzptlk/En/n;", "C4", "()Ldbxyzptlk/En/n;", "setViewModelFactory", "(Ldbxyzptlk/En/n;)V", "viewModelFactory", "Ldbxyzptlk/Rf/g;", "d", "Ldbxyzptlk/pI/j;", "z4", "()Ldbxyzptlk/Rf/g;", "loginActivityViewModel", "Ldbxyzptlk/sg/c;", "e", "Ldbxyzptlk/sg/c;", "B4", "()Ldbxyzptlk/sg/c;", "setResultManager", "(Ldbxyzptlk/sg/c;)V", "resultManager", "Ldbxyzptlk/og/b;", "f", "Ldbxyzptlk/og/b;", "A4", "()Ldbxyzptlk/og/b;", "setLoginNavigator", "(Ldbxyzptlk/og/b;)V", "loginNavigator", "Ldbxyzptlk/zg/a;", "g", "Ldbxyzptlk/zg/a;", "x4", "()Ldbxyzptlk/zg/a;", "setAuthLaunchSourceProvider", "(Ldbxyzptlk/zg/a;)V", "authLaunchSourceProvider", "", "h", "D3", "()Ljava/lang/Object;", "daggerComponent", "Landroidx/lifecycle/t$b;", "getDefaultViewModelProviderFactory", "()Landroidx/lifecycle/t$b;", "defaultViewModelProviderFactory", "i", "Companion", "dbapp_auth_login_impl_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class DbappLoginActivity extends BaseActivity implements e, e, f, d<b> {
  public static final Companion i = new Companion(null);
  
  public static final int j = 8;
  
  public n c;
  
  public final j d;
  
  public dbxyzptlk.sg.c e;
  
  public dbxyzptlk.og.b f;
  
  public dbxyzptlk.zg.a g;
  
  public final j h;
  
  public DbappLoginActivity() {
    a a1 = new a(this);
    this.d = (j)new s(L.b(g.class), new c((ComponentActivity)this), a1, new d(null, (ComponentActivity)this));
    this.h = k.a(new b((z)this, this));
  }
  
  public static final b y4(DbappLoginActivity paramDbappLoginActivity) {
    s.h(paramDbappLoginActivity, "this$0");
    return a.a().a((l)paramDbappLoginActivity.s());
  }
  
  private final g z4() {
    return (g)this.d.getValue();
  }
  
  public final dbxyzptlk.og.b A4() {
    dbxyzptlk.og.b b1 = this.f;
    if (b1 != null)
      return b1; 
    s.u("loginNavigator");
    return null;
  }
  
  public final dbxyzptlk.sg.c B4() {
    dbxyzptlk.sg.c c1 = this.e;
    if (c1 != null)
      return c1; 
    s.u("resultManager");
    return null;
  }
  
  public final n C4() {
    n n1 = this.c;
    if (n1 != null)
      return n1; 
    s.u("viewModelFactory");
    return null;
  }
  
  public Object D3() {
    return this.h.getValue();
  }
  
  public final AuthLaunchSource D4() {
    AuthLaunchSource.Organic organic;
    AuthLaunchSource authLaunchSource2 = (AuthLaunchSource)dbxyzptlk.V1.c.b(getIntent(), "com.dropbox.dbapp.auth.login.EXTRA_LAUNCH_SOURCE", AuthLaunchSource.class);
    AuthLaunchSource authLaunchSource1 = authLaunchSource2;
    if (authLaunchSource2 == null)
      organic = AuthLaunchSource.Organic.a; 
    return (AuthLaunchSource)organic;
  }
  
  public t.b getDefaultViewModelProviderFactory() {
    return (t.b)C4();
  }
  
  public dbxyzptlk.Eq.b<b> i3() {
    return (dbxyzptlk.Eq.b<b>)new dbxyzptlk.En.c(this);
  }
  
  public void onCreate(Bundle paramBundle) {
    if (u())
      finish(); 
    ((dbxyzptlk.En.d)dbxyzptlk.yj.c.b((Context)this, dbxyzptlk.En.d.class, dbxyzptlk.yj.c.d((Activity)this), false)).c(this);
    super.onCreate(paramBundle);
    setContentView(s.dbapp_auth_activity);
    B4().b((FragmentActivity)this);
    x4().a(D4());
    if (paramBundle == null) {
      FragmentManager fragmentManager = getSupportFragmentManager();
      s.g(fragmentManager, "getSupportFragmentManager(...)");
      o o = fragmentManager.q();
      s.g(o, "beginTransaction()");
      int i = r.fragment_container;
      WelcomePageFragment.a a1 = WelcomePageFragment.A;
      o.c(i, a1.b(), a1.a());
      o.k();
    } 
  }
  
  public void onNewIntent(Intent paramIntent) {
    s.h(paramIntent, "intent");
    setIntent(paramIntent);
    dbxyzptlk.og.a a1 = z4().H(paramIntent, getSupportFragmentManager().C0().size());
    if (a1 != null)
      A4().a((FragmentActivity)this, a1); 
    super.onNewIntent(paramIntent);
  }
  
  public final dbxyzptlk.zg.a x4() {
    dbxyzptlk.zg.a a1 = this.g;
    if (a1 != null)
      return a1; 
    s.u("authLaunchSourceProvider");
    return null;
  }
  
  @Metadata(d1 = {"\000$\n\002\030\002\n\002\020\000\n\002\b\002\n\002\020\016\n\000\n\002\030\002\n\000\n\002\030\002\n\000\n\002\030\002\n\000\b\003\030\0002\0020\001B\007\b\002¢\006\002\020\002J\030\020\005\032\0020\0062\006\020\007\032\0020\b2\006\020\t\032\0020\nH\007R\016\020\003\032\0020\004XT¢\006\002\n\000¨\006\013"}, d2 = {"Lcom/dropbox/dbapp/auth/login/DbappLoginActivity$Companion;", "", "()V", "EXTRA_LAUNCH_SOURCE", "", "getLaunchIntent", "Landroid/content/Intent;", "context", "Landroid/content/Context;", "authLaunchSource", "Lcom/dropbox/common/auth/login/api/AuthLaunchSource;", "dbapp_auth_login_impl_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
  @Keep
  public static final class Companion {
    private Companion() {}
    
    public final Intent getLaunchIntent(Context param1Context, AuthLaunchSource param1AuthLaunchSource) {
      s.h(param1Context, "context");
      s.h(param1AuthLaunchSource, "authLaunchSource");
      Intent intent = new Intent(param1Context, DbappLoginActivity.class);
      intent.putExtra("com.dropbox.dbapp.auth.login.EXTRA_LAUNCH_SOURCE", (Parcelable)param1AuthLaunchSource);
      return intent;
    }
  }
  
  @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"Landroidx/lifecycle/t$b;", "b", "()Landroidx/lifecycle/t$b;"}, k = 3, mv = {1, 9, 0})
  public static final class a extends u implements dbxyzptlk.CI.a<t.b> {
    public final DbappLoginActivity f;
    
    public a(DbappLoginActivity param1DbappLoginActivity) {
      super(0);
    }
    
    public final t.b b() {
      return (t.b)this.f.C4();
    }
  }
  
  @Metadata(d1 = {"\000\b\n\002\020\000\n\002\b\004\020\004\032\0020\000\"\n\b\000\020\001\030\001*\0020\000H\n¢\006\004\b\002\020\003"}, d2 = {"", "T", "invoke", "()Ljava/lang/Object;", "<anonymous>"}, k = 3, mv = {1, 9, 0})
  public static final class b extends u implements dbxyzptlk.CI.a<Object> {
    public final z f;
    
    public final DbappLoginActivity g;
    
    public b(z param1z, DbappLoginActivity param1DbappLoginActivity) {
      super(0);
    }
    
    public final Object invoke() {
      dbxyzptlk.yj.d d = (dbxyzptlk.yj.d)(new t(this.f, dbxyzptlk.yj.d.d.a())).a(dbxyzptlk.yj.d.class);
      Class<c.a> clazz = c.a.class;
      if (h.a.class.isAssignableFrom(c.a.class))
        clazz = (Class)c.a.class.getEnclosingClass(); 
      ConcurrentHashMap<Class<c.a>, Object> concurrentHashMap = d.G();
      Object<c.a> object2 = (Object<c.a>)concurrentHashMap.get(clazz);
      Object<c.a> object1 = object2;
      if (object2 == null) {
        w.a((v)d);
        object1 = (Object<c.a>)this.g;
        object2 = (Object<c.a>)((c.b)dbxyzptlk.yj.c.b((Context)object1, c.b.class, dbxyzptlk.yj.c.d((Activity)object1), true)).V();
        object1 = object2;
        if (object2 != null)
          object1 = (Object<c.a>)object2.a(w.a((v)d)); 
        clazz = (Class<c.a>)concurrentHashMap.putIfAbsent(clazz, object1);
        if (clazz != null)
          object1 = (Object<c.a>)clazz; 
      } 
      s.g(object1, "getOrPut(...)");
      return object1;
    }
  }
  
  @Metadata(d1 = {"\000\016\n\002\030\002\n\000\n\002\030\002\n\002\b\002\020\003\032\0020\002\"\n\b\000\020\001\030\001*\0020\000H\n¢\006\004\b\003\020\004"}, d2 = {"Ldbxyzptlk/U2/v;", "VM", "Ldbxyzptlk/U2/y;", "b", "()Ldbxyzptlk/U2/y;"}, k = 3, mv = {1, 9, 0})
  public static final class c extends u implements dbxyzptlk.CI.a<y> {
    public final ComponentActivity f;
    
    public c(ComponentActivity param1ComponentActivity) {
      super(0);
    }
    
    public final y b() {
      return this.f.getViewModelStore();
    }
  }
  
  @Metadata(d1 = {"\000\016\n\002\030\002\n\000\n\002\030\002\n\002\b\002\020\003\032\0020\002\"\n\b\000\020\001\030\001*\0020\000H\n¢\006\004\b\003\020\004"}, d2 = {"Ldbxyzptlk/U2/v;", "VM", "Ldbxyzptlk/X2/a;", "b", "()Ldbxyzptlk/X2/a;"}, k = 3, mv = {1, 9, 0})
  public static final class d extends u implements dbxyzptlk.CI.a<dbxyzptlk.X2.a> {
    public final dbxyzptlk.CI.a f;
    
    public final ComponentActivity g;
    
    public d(dbxyzptlk.CI.a param1a, ComponentActivity param1ComponentActivity) {
      super(0);
    }
    
    public final dbxyzptlk.X2.a b() {
      dbxyzptlk.CI.a a1 = this.f;
      if (a1 != null) {
        dbxyzptlk.X2.a a3 = (dbxyzptlk.X2.a)a1.invoke();
        dbxyzptlk.X2.a a2 = a3;
        return (a3 == null) ? this.g.getDefaultViewModelCreationExtras() : a2;
      } 
      return this.g.getDefaultViewModelCreationExtras();
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\dbapp\auth\login\DbappLoginActivity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */