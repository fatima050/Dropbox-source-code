package com.dropbox.dbapp.auth.login;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.IntentSenderRequest;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.RepeatOnLifecycleKt;
import androidx.lifecycle.e;
import androidx.lifecycle.t;
import com.dropbox.dbapp.auth.api.LoginSurface;
import dbxyzptlk.CI.p;
import dbxyzptlk.DI.L;
import dbxyzptlk.DI.s;
import dbxyzptlk.DI.u;
import dbxyzptlk.Df.d;
import dbxyzptlk.En.n;
import dbxyzptlk.K2.E;
import dbxyzptlk.U2.y;
import dbxyzptlk.U2.z;
import dbxyzptlk.Yf.a;
import dbxyzptlk.bK.J;
import dbxyzptlk.eK.S;
import dbxyzptlk.i.e;
import dbxyzptlk.pI.D;
import dbxyzptlk.pI.m;
import dbxyzptlk.pI.p;
import dbxyzptlk.tI.d;
import dbxyzptlk.vI.l;
import dbxyzptlk.yj.e;
import kotlin.KotlinNothingValueException;
import kotlin.Metadata;

@Metadata(d1 = {"\000\001\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\003\n\002\020\013\n\002\b\004\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\007\n\002\030\002\n\002\b\007\n\002\030\002\n\002\b\007\n\002\030\002\n\002\b\004\n\002\030\002\n\002\020\000\n\002\b\003\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\005\b'\030\0002\0020\0012\0020\0022\0020\0032\0020\0042\0020\005:\001RB\007¢\006\004\b\006\020\007J\031\020\013\032\0020\n2\b\020\t\032\004\030\0010\bH\026¢\006\004\b\013\020\fJ\027\020\017\032\0020\n2\006\020\016\032\0020\rH\026¢\006\004\b\017\020\020J!\020\023\032\0020\n2\006\020\022\032\0020\0212\b\020\t\032\004\030\0010\bH\026¢\006\004\b\023\020\024J\017\020\026\032\0020\025H\026¢\006\004\b\026\020\027J\017\020\030\032\0020\nH\002¢\006\004\b\030\020\007J\017\020\031\032\0020\nH\002¢\006\004\b\031\020\007J\027\020\034\032\0020\n2\006\020\033\032\0020\032H\002¢\006\004\b\034\020\035J\027\020\037\032\0020\n2\006\020\033\032\0020\036H\002¢\006\004\b\037\020 J\027\020#\032\0020\n2\006\020\"\032\0020!H\002¢\006\004\b#\020$R\"\020,\032\0020%8\006@\006X.¢\006\022\n\004\b&\020'\032\004\b(\020)\"\004\b*\020+R\"\0204\032\0020-8\006@\006X.¢\006\022\n\004\b.\020/\032\004\b0\0201\"\004\b2\0203R\"\020<\032\002058\006@\006X.¢\006\022\n\004\b6\0207\032\004\b8\0209\"\004\b:\020;R\033\020A\032\0020=8FX\002¢\006\f\n\004\b\026\020>\032\004\b?\020@R\036\020F\032\n\022\006\022\004\030\0010C0B8\002@\002X.¢\006\006\n\004\bD\020ER\034\020I\032\b\022\004\022\0020G0B8\002@\002X.¢\006\006\n\004\bH\020ER\024\020M\032\0020J8VX\004¢\006\006\032\004\bK\020LR\024\020Q\032\0020N8&X¦\004¢\006\006\032\004\bO\020P¨\006S"}, d2 = {"Lcom/dropbox/dbapp/auth/login/DbappLoginFragment;", "Landroidx/fragment/app/Fragment;", "Landroidx/lifecycle/e;", "Ldbxyzptlk/yj/e;", "Ldbxyzptlk/Yf/a;", "Ldbxyzptlk/Df/d;", "<init>", "()V", "Landroid/os/Bundle;", "savedInstanceState", "Ldbxyzptlk/pI/D;", "onCreate", "(Landroid/os/Bundle;)V", "Landroid/content/Context;", "context", "onAttach", "(Landroid/content/Context;)V", "Landroid/view/View;", "view", "onViewCreated", "(Landroid/view/View;Landroid/os/Bundle;)V", "", "v", "()Z", "x2", "u2", "Lcom/dropbox/dbapp/auth/login/d$a;", "state", "D2", "(Lcom/dropbox/dbapp/auth/login/d$a;)V", "Lcom/dropbox/dbapp/auth/login/d$b;", "E2", "(Lcom/dropbox/dbapp/auth/login/d$b;)V", "Lcom/dropbox/dbapp/auth/login/d$b$a;", "oneTapState", "B2", "(Lcom/dropbox/dbapp/auth/login/d$b$a;)V", "Ldbxyzptlk/En/n;", "s", "Ldbxyzptlk/En/n;", "t2", "()Ldbxyzptlk/En/n;", "setViewModelFactory", "(Ldbxyzptlk/En/n;)V", "viewModelFactory", "Ldbxyzptlk/og/b;", "t", "Ldbxyzptlk/og/b;", "p2", "()Ldbxyzptlk/og/b;", "setLoginNavigator", "(Ldbxyzptlk/og/b;)V", "loginNavigator", "Ldbxyzptlk/hg/b;", "u", "Ldbxyzptlk/hg/b;", "o2", "()Ldbxyzptlk/hg/b;", "setIntentEventBus", "(Ldbxyzptlk/hg/b;)V", "intentEventBus", "Lcom/dropbox/dbapp/auth/login/d;", "Ldbxyzptlk/pI/j;", "r2", "()Lcom/dropbox/dbapp/auth/login/d;", "viewModel", "Ldbxyzptlk/h/b;", "", "w", "Ldbxyzptlk/h/b;", "googleSignInResult", "Landroidx/activity/result/IntentSenderRequest;", "x", "googleOneTapLauncher", "Landroidx/lifecycle/t$b;", "getDefaultViewModelProviderFactory", "()Landroidx/lifecycle/t$b;", "defaultViewModelProviderFactory", "Lcom/dropbox/dbapp/auth/api/LoginSurface;", "q2", "()Lcom/dropbox/dbapp/auth/api/LoginSurface;", "loginSurface", "a", "dbapp_auth_login_impl_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
public abstract class DbappLoginFragment extends Fragment implements e, e, a, d {
  public n s;
  
  public dbxyzptlk.og.b t;
  
  public dbxyzptlk.hg.b u;
  
  public final dbxyzptlk.pI.j v;
  
  public dbxyzptlk.h.b<Object> w;
  
  public dbxyzptlk.h.b<IntentSenderRequest> x;
  
  public DbappLoginFragment() {
    k k = new k(this);
    g g = new g(this);
    dbxyzptlk.pI.j j1 = dbxyzptlk.pI.k.b(m.NONE, new h(g));
    this.v = E.b(this, L.b(d.class), new i(j1), new j(null, j1), k);
  }
  
  public static final void y2(DbappLoginFragment paramDbappLoginFragment, Intent paramIntent) {
    s.h(paramDbappLoginFragment, "this$0");
    dbxyzptlk.U2.i.a((LifecycleOwner)paramDbappLoginFragment).c((p)new d(paramDbappLoginFragment, paramIntent, null));
  }
  
  public static final void z2(DbappLoginFragment paramDbappLoginFragment, ActivityResult paramActivityResult) {
    s.h(paramDbappLoginFragment, "this$0");
    s.h(paramActivityResult, "activityResult");
    dbxyzptlk.U2.i.a((LifecycleOwner)paramDbappLoginFragment).c((p)new e(paramActivityResult, paramDbappLoginFragment, null));
  }
  
  public final void B2(d.b.a parama) {
    IntentSenderRequest intentSenderRequest = (new IntentSenderRequest.a(parama.a())).a();
    dbxyzptlk.h.b<IntentSenderRequest> b2 = this.x;
    dbxyzptlk.h.b<IntentSenderRequest> b1 = b2;
    if (b2 == null) {
      s.u("googleOneTapLauncher");
      b1 = null;
    } 
    b1.a(intentSenderRequest);
  }
  
  public final void D2(d.a parama) {
    FragmentManager fragmentManager;
    if (s.c(parama, d.a.a.a)) {
      fragmentManager = getChildFragmentManager();
      s.g(fragmentManager, "getChildFragmentManager(...)");
      a.e1(this, fragmentManager, false, null, 2, null);
    } else if (fragmentManager instanceof d.a.b) {
      FragmentManager fragmentManager1 = getChildFragmentManager();
      s.g(fragmentManager1, "getChildFragmentManager(...)");
      h(fragmentManager1, true, getString(((d.a.b)fragmentManager).a()));
    } 
  }
  
  public final void E2(d.b paramb) {
    if (!s.c(paramb, d.b.d.a))
      if (paramb instanceof d.b.c) {
        dbxyzptlk.og.b b1 = p2();
        FragmentActivity fragmentActivity = requireActivity();
        s.g(fragmentActivity, "requireActivity(...)");
        b1.a(fragmentActivity, ((d.b.c)paramb).a());
      } else if (s.c(paramb, d.b.b.a)) {
        dbxyzptlk.h.b<Object> b2 = this.w;
        dbxyzptlk.h.b<Object> b1 = b2;
        if (b2 == null) {
          s.u("googleSignInResult");
          b1 = null;
        } 
        b1.a(new Object());
      } else if (paramb instanceof d.b.a) {
        B2((d.b.a)paramb);
      }  
    if (!(paramb instanceof d.b.d))
      r2().o0(); 
  }
  
  public t.b getDefaultViewModelProviderFactory() {
    return (t.b)t2();
  }
  
  public final dbxyzptlk.hg.b o2() {
    dbxyzptlk.hg.b b1 = this.u;
    if (b1 != null)
      return b1; 
    s.u("intentEventBus");
    return null;
  }
  
  public void onAttach(Context paramContext) {
    s.h(paramContext, "context");
    super.onAttach(paramContext);
    x2();
    u2();
    dbxyzptlk.h.b<Object> b1 = registerForActivityResult(new a(this), (dbxyzptlk.h.a)new dbxyzptlk.En.f(this));
    s.g(b1, "registerForActivityResult(...)");
    this.w = b1;
    b1 = registerForActivityResult((dbxyzptlk.i.a)new e(), (dbxyzptlk.h.a)new dbxyzptlk.En.g(this));
    s.g(b1, "registerForActivityResult(...)");
    this.x = (dbxyzptlk.h.b)b1;
    dbxyzptlk.U2.i.a((LifecycleOwner)this).c(new f(this, null));
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    if (paramBundle == null)
      r2().t0(); 
    FragmentActivity fragmentActivity = getActivity();
    if (fragmentActivity != null) {
      Intent intent = fragmentActivity.getIntent();
    } else {
      fragmentActivity = null;
    } 
    if (fragmentActivity != null)
      fragmentActivity.setData(null); 
  }
  
  public void onViewCreated(View paramView, Bundle paramBundle) {
    s.h(paramView, "view");
    super.onViewCreated(paramView, paramBundle);
    r2().l0(q2());
  }
  
  public final dbxyzptlk.og.b p2() {
    dbxyzptlk.og.b b1 = this.t;
    if (b1 != null)
      return b1; 
    s.u("loginNavigator");
    return null;
  }
  
  public abstract LoginSurface q2();
  
  public final d r2() {
    return (d)this.v.getValue();
  }
  
  public final n t2() {
    n n1 = this.s;
    if (n1 != null)
      return n1; 
    s.u("viewModelFactory");
    return null;
  }
  
  public final void u2() {
    dbxyzptlk.bK.h.d((J)dbxyzptlk.U2.i.a((LifecycleOwner)this), null, null, new b(this, null), 3, null);
  }
  
  public boolean v() {
    return false;
  }
  
  public final void x2() {
    dbxyzptlk.bK.h.d((J)dbxyzptlk.U2.i.a((LifecycleOwner)this), null, null, new c(this, null), 3, null);
  }
  
  @Metadata(d1 = {"\000(\n\002\030\002\n\002\030\002\n\002\020\000\n\002\030\002\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\004\n\002\020\b\n\002\b\007\b\007\030\0002\022\022\006\022\004\030\0010\002\022\006\022\004\030\0010\0030\001B\017\022\006\020\005\032\0020\004¢\006\004\b\006\020\007J!\020\013\032\0020\0032\006\020\t\032\0020\b2\b\020\n\032\004\030\0010\002H\026¢\006\004\b\013\020\fJ#\020\020\032\004\030\0010\0032\006\020\016\032\0020\r2\b\020\017\032\004\030\0010\003H\026¢\006\004\b\020\020\021R\024\020\005\032\0020\0048\002X\004¢\006\006\n\004\b\022\020\023¨\006\024"}, d2 = {"Lcom/dropbox/dbapp/auth/login/DbappLoginFragment$a;", "Ldbxyzptlk/i/a;", "", "Landroid/content/Intent;", "Lcom/dropbox/dbapp/auth/login/DbappLoginFragment;", "fragment", "<init>", "(Lcom/dropbox/dbapp/auth/login/DbappLoginFragment;)V", "Landroid/content/Context;", "context", "input", "createIntent", "(Landroid/content/Context;Ljava/lang/Object;)Landroid/content/Intent;", "", "resultCode", "intent", "a", "(ILandroid/content/Intent;)Landroid/content/Intent;", "c", "Lcom/dropbox/dbapp/auth/login/DbappLoginFragment;", "dbapp_auth_login_impl_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
  public static final class a extends dbxyzptlk.i.a<Object, Intent> {
    public final DbappLoginFragment c;
    
    public a(DbappLoginFragment param1DbappLoginFragment) {
      this.c = param1DbappLoginFragment;
    }
    
    public Intent a(int param1Int, Intent param1Intent) {
      return param1Intent;
    }
    
    public Intent createIntent(Context param1Context, Object param1Object) {
      s.h(param1Context, "context");
      return this.c.r2().f();
    }
  }
  
  @dbxyzptlk.vI.f(c = "com.dropbox.dbapp.auth.login.DbappLoginFragment$observeLoadingState$1", f = "DbappLoginFragment.kt", l = {110}, m = "invokeSuspend")
  @Metadata(d1 = {"\000\f\n\002\030\002\n\002\030\002\n\002\b\002\020\002\032\0020\001*\0020\000H@¢\006\004\b\002\020\003"}, d2 = {"Ldbxyzptlk/bK/J;", "Ldbxyzptlk/pI/D;", "<anonymous>", "(Ldbxyzptlk/bK/J;)V"}, k = 3, mv = {1, 9, 0})
  public static final class b extends l implements p<J, d<? super D>, Object> {
    public int t;
    
    public final DbappLoginFragment u;
    
    public b(DbappLoginFragment param1DbappLoginFragment, d<? super b> param1d) {
      super(2, param1d);
    }
    
    public final d<D> create(Object param1Object, d<?> param1d) {
      return (d<D>)new b(this.u, (d)param1d);
    }
    
    public final Object invoke(J param1J, d<? super D> param1d) {
      return ((b)create(param1J, param1d)).invokeSuspend(D.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = dbxyzptlk.uI.c.g();
      int i = this.t;
      if (i != 0) {
        if (i == 1) {
          p.b(param1Object);
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        p.b(param1Object);
        DbappLoginFragment dbappLoginFragment = this.u;
        param1Object = androidx.lifecycle.f.b.STARTED;
        a a = new a(dbappLoginFragment, null);
        this.t = 1;
        if (RepeatOnLifecycleKt.b((LifecycleOwner)dbappLoginFragment, (androidx.lifecycle.f.b)param1Object, a, (d)this) == object)
          return object; 
      } 
      return D.a;
    }
    
    @dbxyzptlk.vI.f(c = "com.dropbox.dbapp.auth.login.DbappLoginFragment$observeLoadingState$1$1", f = "DbappLoginFragment.kt", l = {111}, m = "invokeSuspend")
    @Metadata(d1 = {"\000\f\n\002\030\002\n\002\030\002\n\002\b\002\020\002\032\0020\001*\0020\000H@¢\006\004\b\002\020\003"}, d2 = {"Ldbxyzptlk/bK/J;", "Ldbxyzptlk/pI/D;", "<anonymous>", "(Ldbxyzptlk/bK/J;)V"}, k = 3, mv = {1, 9, 0})
    public static final class a extends l implements p<J, d<? super D>, Object> {
      public int t;
      
      public final DbappLoginFragment u;
      
      public a(DbappLoginFragment param2DbappLoginFragment, d<? super a> param2d) {
        super(2, param2d);
      }
      
      public final d<D> create(Object param2Object, d<?> param2d) {
        return (d<D>)new a(this.u, (d)param2d);
      }
      
      public final Object invoke(J param2J, d<? super D> param2d) {
        return ((a)create(param2J, param2d)).invokeSuspend(D.a);
      }
      
      public final Object invokeSuspend(Object<d.a> param2Object) {
        Object object = dbxyzptlk.uI.c.g();
        int i = this.t;
        if (i != 0) {
          if (i != 1)
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine"); 
          p.b(param2Object);
        } else {
          p.b(param2Object);
          param2Object = (Object<d.a>)this.u.r2().Q();
          a a1 = new a(this.u);
          this.t = 1;
          if (param2Object.a(a1, (d)this) == object)
            return object; 
        } 
        throw new KotlinNothingValueException();
      }
      
      @Metadata(d1 = {"\000\016\n\002\030\002\n\000\n\002\030\002\n\002\b\002\020\003\032\0020\0022\006\020\001\032\0020\000H@¢\006\004\b\003\020\004"}, d2 = {"Lcom/dropbox/dbapp/auth/login/d$a;", "state", "Ldbxyzptlk/pI/D;", "a", "(Lcom/dropbox/dbapp/auth/login/d$a;Ldbxyzptlk/tI/d;)Ljava/lang/Object;"}, k = 3, mv = {1, 9, 0})
      public static final class a<T> implements dbxyzptlk.eK.j {
        public final DbappLoginFragment a;
        
        public a(DbappLoginFragment param3DbappLoginFragment) {}
        
        public final Object a(d.a param3a, d<? super D> param3d) {
          DbappLoginFragment.m2(this.a, param3a);
          return D.a;
        }
      }
    }
    
    @Metadata(d1 = {"\000\016\n\002\030\002\n\000\n\002\030\002\n\002\b\002\020\003\032\0020\0022\006\020\001\032\0020\000H@¢\006\004\b\003\020\004"}, d2 = {"Lcom/dropbox/dbapp/auth/login/d$a;", "state", "Ldbxyzptlk/pI/D;", "a", "(Lcom/dropbox/dbapp/auth/login/d$a;Ldbxyzptlk/tI/d;)Ljava/lang/Object;"}, k = 3, mv = {1, 9, 0})
    public static final class a<T> implements dbxyzptlk.eK.j {
      public final DbappLoginFragment a;
      
      public a(DbappLoginFragment param2DbappLoginFragment) {}
      
      public final Object a(d.a param2a, d<? super D> param2d) {
        DbappLoginFragment.m2(this.a, param2a);
        return D.a;
      }
    }
  }
  
  @dbxyzptlk.vI.f(c = "com.dropbox.dbapp.auth.login.DbappLoginFragment$observeLoadingState$1$1", f = "DbappLoginFragment.kt", l = {111}, m = "invokeSuspend")
  @Metadata(d1 = {"\000\f\n\002\030\002\n\002\030\002\n\002\b\002\020\002\032\0020\001*\0020\000H@¢\006\004\b\002\020\003"}, d2 = {"Ldbxyzptlk/bK/J;", "Ldbxyzptlk/pI/D;", "<anonymous>", "(Ldbxyzptlk/bK/J;)V"}, k = 3, mv = {1, 9, 0})
  public static final class a extends l implements p<J, d<? super D>, Object> {
    public int t;
    
    public final DbappLoginFragment u;
    
    public a(DbappLoginFragment param1DbappLoginFragment, d<? super a> param1d) {
      super(2, param1d);
    }
    
    public final d<D> create(Object param1Object, d<?> param1d) {
      return (d<D>)new a(this.u, (d)param1d);
    }
    
    public final Object invoke(J param1J, d<? super D> param1d) {
      return ((a)create(param1J, param1d)).invokeSuspend(D.a);
    }
    
    public final Object invokeSuspend(Object<d.a> param1Object) {
      Object object = dbxyzptlk.uI.c.g();
      int i = this.t;
      if (i != 0) {
        if (i != 1)
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine"); 
        p.b(param1Object);
      } else {
        p.b(param1Object);
        param1Object = (Object<d.a>)this.u.r2().Q();
        a a1 = new a(this.u);
        this.t = 1;
        if (param1Object.a(a1, (d)this) == object)
          return object; 
      } 
      throw new KotlinNothingValueException();
    }
    
    @Metadata(d1 = {"\000\016\n\002\030\002\n\000\n\002\030\002\n\002\b\002\020\003\032\0020\0022\006\020\001\032\0020\000H@¢\006\004\b\003\020\004"}, d2 = {"Lcom/dropbox/dbapp/auth/login/d$a;", "state", "Ldbxyzptlk/pI/D;", "a", "(Lcom/dropbox/dbapp/auth/login/d$a;Ldbxyzptlk/tI/d;)Ljava/lang/Object;"}, k = 3, mv = {1, 9, 0})
    public static final class a<T> implements dbxyzptlk.eK.j {
      public final DbappLoginFragment a;
      
      public a(DbappLoginFragment param3DbappLoginFragment) {}
      
      public final Object a(d.a param3a, d<? super D> param3d) {
        DbappLoginFragment.m2(this.a, param3a);
        return D.a;
      }
    }
  }
  
  @Metadata(d1 = {"\000\016\n\002\030\002\n\000\n\002\030\002\n\002\b\002\020\003\032\0020\0022\006\020\001\032\0020\000H@¢\006\004\b\003\020\004"}, d2 = {"Lcom/dropbox/dbapp/auth/login/d$a;", "state", "Ldbxyzptlk/pI/D;", "a", "(Lcom/dropbox/dbapp/auth/login/d$a;Ldbxyzptlk/tI/d;)Ljava/lang/Object;"}, k = 3, mv = {1, 9, 0})
  public static final class a<T> implements dbxyzptlk.eK.j {
    public final DbappLoginFragment a;
    
    public a(DbappLoginFragment param1DbappLoginFragment) {}
    
    public final Object a(d.a param1a, d<? super D> param1d) {
      DbappLoginFragment.m2(this.a, param1a);
      return D.a;
    }
  }
  
  @dbxyzptlk.vI.f(c = "com.dropbox.dbapp.auth.login.DbappLoginFragment$observeTransientState$1", f = "DbappLoginFragment.kt", l = {100}, m = "invokeSuspend")
  @Metadata(d1 = {"\000\f\n\002\030\002\n\002\030\002\n\002\b\002\020\002\032\0020\001*\0020\000H@¢\006\004\b\002\020\003"}, d2 = {"Ldbxyzptlk/bK/J;", "Ldbxyzptlk/pI/D;", "<anonymous>", "(Ldbxyzptlk/bK/J;)V"}, k = 3, mv = {1, 9, 0})
  public static final class c extends l implements p<J, d<? super D>, Object> {
    public int t;
    
    public final DbappLoginFragment u;
    
    public c(DbappLoginFragment param1DbappLoginFragment, d<? super c> param1d) {
      super(2, param1d);
    }
    
    public final d<D> create(Object param1Object, d<?> param1d) {
      return (d<D>)new c(this.u, (d)param1d);
    }
    
    public final Object invoke(J param1J, d<? super D> param1d) {
      return ((c)create(param1J, param1d)).invokeSuspend(D.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = dbxyzptlk.uI.c.g();
      int i = this.t;
      if (i != 0) {
        if (i == 1) {
          p.b(param1Object);
        } else {
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        } 
      } else {
        p.b(param1Object);
        DbappLoginFragment dbappLoginFragment = this.u;
        param1Object = androidx.lifecycle.f.b.STARTED;
        a a = new a(dbappLoginFragment, null);
        this.t = 1;
        if (RepeatOnLifecycleKt.b((LifecycleOwner)dbappLoginFragment, (androidx.lifecycle.f.b)param1Object, a, (d)this) == object)
          return object; 
      } 
      return D.a;
    }
    
    @dbxyzptlk.vI.f(c = "com.dropbox.dbapp.auth.login.DbappLoginFragment$observeTransientState$1$1", f = "DbappLoginFragment.kt", l = {101}, m = "invokeSuspend")
    @Metadata(d1 = {"\000\f\n\002\030\002\n\002\030\002\n\002\b\002\020\002\032\0020\001*\0020\000H@¢\006\004\b\002\020\003"}, d2 = {"Ldbxyzptlk/bK/J;", "Ldbxyzptlk/pI/D;", "<anonymous>", "(Ldbxyzptlk/bK/J;)V"}, k = 3, mv = {1, 9, 0})
    public static final class a extends l implements p<J, d<? super D>, Object> {
      public int t;
      
      public final DbappLoginFragment u;
      
      public a(DbappLoginFragment param2DbappLoginFragment, d<? super a> param2d) {
        super(2, param2d);
      }
      
      public final d<D> create(Object param2Object, d<?> param2d) {
        return (d<D>)new a(this.u, (d)param2d);
      }
      
      public final Object invoke(J param2J, d<? super D> param2d) {
        return ((a)create(param2J, param2d)).invokeSuspend(D.a);
      }
      
      public final Object invokeSuspend(Object param2Object) {
        Object object = dbxyzptlk.uI.c.g();
        int i = this.t;
        if (i != 0) {
          if (i != 1)
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine"); 
          p.b(param2Object);
        } else {
          p.b(param2Object);
          S<d.b> s = this.u.r2().R();
          param2Object = new a(this.u);
          this.t = 1;
          if (s.a((dbxyzptlk.eK.j)param2Object, (d)this) == object)
            return object; 
        } 
        throw new KotlinNothingValueException();
      }
      
      @Metadata(d1 = {"\000\016\n\002\030\002\n\000\n\002\030\002\n\002\b\002\020\003\032\0020\0022\006\020\001\032\0020\000H@¢\006\004\b\003\020\004"}, d2 = {"Lcom/dropbox/dbapp/auth/login/d$b;", "transientState", "Ldbxyzptlk/pI/D;", "a", "(Lcom/dropbox/dbapp/auth/login/d$b;Ldbxyzptlk/tI/d;)Ljava/lang/Object;"}, k = 3, mv = {1, 9, 0})
      public static final class a<T> implements dbxyzptlk.eK.j {
        public final DbappLoginFragment a;
        
        public a(DbappLoginFragment param3DbappLoginFragment) {}
        
        public final Object a(d.b param3b, d<? super D> param3d) {
          DbappLoginFragment.n2(this.a, param3b);
          return D.a;
        }
      }
    }
    
    @Metadata(d1 = {"\000\016\n\002\030\002\n\000\n\002\030\002\n\002\b\002\020\003\032\0020\0022\006\020\001\032\0020\000H@¢\006\004\b\003\020\004"}, d2 = {"Lcom/dropbox/dbapp/auth/login/d$b;", "transientState", "Ldbxyzptlk/pI/D;", "a", "(Lcom/dropbox/dbapp/auth/login/d$b;Ldbxyzptlk/tI/d;)Ljava/lang/Object;"}, k = 3, mv = {1, 9, 0})
    public static final class a<T> implements dbxyzptlk.eK.j {
      public final DbappLoginFragment a;
      
      public a(DbappLoginFragment param2DbappLoginFragment) {}
      
      public final Object a(d.b param2b, d<? super D> param2d) {
        DbappLoginFragment.n2(this.a, param2b);
        return D.a;
      }
    }
  }
  
  @dbxyzptlk.vI.f(c = "com.dropbox.dbapp.auth.login.DbappLoginFragment$observeTransientState$1$1", f = "DbappLoginFragment.kt", l = {101}, m = "invokeSuspend")
  @Metadata(d1 = {"\000\f\n\002\030\002\n\002\030\002\n\002\b\002\020\002\032\0020\001*\0020\000H@¢\006\004\b\002\020\003"}, d2 = {"Ldbxyzptlk/bK/J;", "Ldbxyzptlk/pI/D;", "<anonymous>", "(Ldbxyzptlk/bK/J;)V"}, k = 3, mv = {1, 9, 0})
  public static final class a extends l implements p<J, d<? super D>, Object> {
    public int t;
    
    public final DbappLoginFragment u;
    
    public a(DbappLoginFragment param1DbappLoginFragment, d<? super a> param1d) {
      super(2, param1d);
    }
    
    public final d<D> create(Object param1Object, d<?> param1d) {
      return (d<D>)new a(this.u, (d)param1d);
    }
    
    public final Object invoke(J param1J, d<? super D> param1d) {
      return ((a)create(param1J, param1d)).invokeSuspend(D.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = dbxyzptlk.uI.c.g();
      int i = this.t;
      if (i != 0) {
        if (i != 1)
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine"); 
        p.b(param1Object);
      } else {
        p.b(param1Object);
        S<d.b> s = this.u.r2().R();
        param1Object = new a(this.u);
        this.t = 1;
        if (s.a((dbxyzptlk.eK.j)param1Object, (d)this) == object)
          return object; 
      } 
      throw new KotlinNothingValueException();
    }
    
    @Metadata(d1 = {"\000\016\n\002\030\002\n\000\n\002\030\002\n\002\b\002\020\003\032\0020\0022\006\020\001\032\0020\000H@¢\006\004\b\003\020\004"}, d2 = {"Lcom/dropbox/dbapp/auth/login/d$b;", "transientState", "Ldbxyzptlk/pI/D;", "a", "(Lcom/dropbox/dbapp/auth/login/d$b;Ldbxyzptlk/tI/d;)Ljava/lang/Object;"}, k = 3, mv = {1, 9, 0})
    public static final class a<T> implements dbxyzptlk.eK.j {
      public final DbappLoginFragment a;
      
      public a(DbappLoginFragment param3DbappLoginFragment) {}
      
      public final Object a(d.b param3b, d<? super D> param3d) {
        DbappLoginFragment.n2(this.a, param3b);
        return D.a;
      }
    }
  }
  
  @Metadata(d1 = {"\000\016\n\002\030\002\n\000\n\002\030\002\n\002\b\002\020\003\032\0020\0022\006\020\001\032\0020\000H@¢\006\004\b\003\020\004"}, d2 = {"Lcom/dropbox/dbapp/auth/login/d$b;", "transientState", "Ldbxyzptlk/pI/D;", "a", "(Lcom/dropbox/dbapp/auth/login/d$b;Ldbxyzptlk/tI/d;)Ljava/lang/Object;"}, k = 3, mv = {1, 9, 0})
  public static final class a<T> implements dbxyzptlk.eK.j {
    public final DbappLoginFragment a;
    
    public a(DbappLoginFragment param1DbappLoginFragment) {}
    
    public final Object a(d.b param1b, d<? super D> param1d) {
      DbappLoginFragment.n2(this.a, param1b);
      return D.a;
    }
  }
  
  @dbxyzptlk.vI.f(c = "com.dropbox.dbapp.auth.login.DbappLoginFragment$onAttach$3", f = "DbappLoginFragment.kt", l = {89}, m = "invokeSuspend")
  @Metadata(d1 = {"\000\f\n\002\030\002\n\002\030\002\n\002\b\002\020\002\032\0020\001*\0020\000H@¢\006\004\b\002\020\003"}, d2 = {"Ldbxyzptlk/bK/J;", "Ldbxyzptlk/pI/D;", "<anonymous>", "(Ldbxyzptlk/bK/J;)V"}, k = 3, mv = {1, 9, 0})
  public static final class f extends l implements p<J, d<? super D>, Object> {
    public int t;
    
    public final DbappLoginFragment u;
    
    public f(DbappLoginFragment param1DbappLoginFragment, d<? super f> param1d) {
      super(2, param1d);
    }
    
    public final d<D> create(Object param1Object, d<?> param1d) {
      return (d<D>)new f(this.u, (d)param1d);
    }
    
    public final Object invoke(J param1J, d<? super D> param1d) {
      return ((f)create(param1J, param1d)).invokeSuspend(D.a);
    }
    
    public final Object invokeSuspend(Object param1Object) {
      Object object = dbxyzptlk.uI.c.g();
      int i = this.t;
      if (i != 0) {
        if (i != 1)
          throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine"); 
        p.b(param1Object);
      } else {
        p.b(param1Object);
        S s = this.u.o2().a();
        param1Object = new a(this.u);
        this.t = 1;
        if (s.a((dbxyzptlk.eK.j)param1Object, (d)this) == object)
          return object; 
      } 
      throw new KotlinNothingValueException();
    }
    
    @Metadata(d1 = {"\000\016\n\002\030\002\n\000\n\002\030\002\n\002\b\002\020\003\032\0020\0022\b\020\001\032\004\030\0010\000H@¢\006\004\b\003\020\004"}, d2 = {"Landroid/content/Intent;", "it", "Ldbxyzptlk/pI/D;", "a", "(Landroid/content/Intent;Ldbxyzptlk/tI/d;)Ljava/lang/Object;"}, k = 3, mv = {1, 9, 0})
    public static final class a<T> implements dbxyzptlk.eK.j {
      public final DbappLoginFragment a;
      
      public a(DbappLoginFragment param2DbappLoginFragment) {}
      
      public final Object a(Intent param2Intent, d<? super D> param2d) {
        if (param2Intent != null) {
          DbappLoginFragment dbappLoginFragment = this.a;
          dbappLoginFragment.r2().T(param2Intent);
          Object object = dbappLoginFragment.o2().b(param2d);
          if (object == dbxyzptlk.uI.c.g())
            return object; 
        } 
        return D.a;
      }
    }
  }
  
  @Metadata(d1 = {"\000\016\n\002\030\002\n\000\n\002\030\002\n\002\b\002\020\003\032\0020\0022\b\020\001\032\004\030\0010\000H@¢\006\004\b\003\020\004"}, d2 = {"Landroid/content/Intent;", "it", "Ldbxyzptlk/pI/D;", "a", "(Landroid/content/Intent;Ldbxyzptlk/tI/d;)Ljava/lang/Object;"}, k = 3, mv = {1, 9, 0})
  public static final class a<T> implements dbxyzptlk.eK.j {
    public final DbappLoginFragment a;
    
    public a(DbappLoginFragment param1DbappLoginFragment) {}
    
    public final Object a(Intent param1Intent, d<? super D> param1d) {
      if (param1Intent != null) {
        DbappLoginFragment dbappLoginFragment = this.a;
        dbappLoginFragment.r2().T(param1Intent);
        Object object = dbappLoginFragment.o2().b(param1d);
        if (object == dbxyzptlk.uI.c.g())
          return object; 
      } 
      return D.a;
    }
  }
  
  @Metadata(d1 = {"\000\016\n\002\030\002\n\000\n\002\030\002\n\002\b\002\020\003\032\0020\002\"\n\b\000\020\001\030\001*\0020\000H\n¢\006\004\b\003\020\004"}, d2 = {"Ldbxyzptlk/U2/v;", "VM", "Landroidx/fragment/app/Fragment;", "b", "()Landroidx/fragment/app/Fragment;"}, k = 3, mv = {1, 9, 0})
  public static final class g extends u implements dbxyzptlk.CI.a<Fragment> {
    public final Fragment f;
    
    public g(Fragment param1Fragment) {
      super(0);
    }
    
    public final Fragment b() {
      return this.f;
    }
  }
  
  @Metadata(d1 = {"\000\016\n\002\030\002\n\000\n\002\030\002\n\002\b\002\020\003\032\0020\002\"\n\b\000\020\001\030\001*\0020\000H\n¢\006\004\b\003\020\004"}, d2 = {"Ldbxyzptlk/U2/v;", "VM", "Ldbxyzptlk/U2/z;", "b", "()Ldbxyzptlk/U2/z;"}, k = 3, mv = {1, 9, 0})
  public static final class h extends u implements dbxyzptlk.CI.a<z> {
    public final dbxyzptlk.CI.a f;
    
    public h(dbxyzptlk.CI.a param1a) {
      super(0);
    }
    
    public final z b() {
      return (z)this.f.invoke();
    }
  }
  
  @Metadata(d1 = {"\000\016\n\002\030\002\n\000\n\002\030\002\n\002\b\002\020\003\032\0020\002\"\n\b\000\020\001\030\001*\0020\000H\n¢\006\004\b\003\020\004"}, d2 = {"Ldbxyzptlk/U2/v;", "VM", "Ldbxyzptlk/U2/y;", "b", "()Ldbxyzptlk/U2/y;"}, k = 3, mv = {1, 9, 0})
  public static final class i extends u implements dbxyzptlk.CI.a<y> {
    public final dbxyzptlk.pI.j f;
    
    public i(dbxyzptlk.pI.j param1j) {
      super(0);
    }
    
    public final y b() {
      return E.a(this.f).getViewModelStore();
    }
  }
  
  @Metadata(d1 = {"\000\016\n\002\030\002\n\000\n\002\030\002\n\002\b\002\020\003\032\0020\002\"\n\b\000\020\001\030\001*\0020\000H\n¢\006\004\b\003\020\004"}, d2 = {"Ldbxyzptlk/U2/v;", "VM", "Ldbxyzptlk/X2/a;", "b", "()Ldbxyzptlk/X2/a;"}, k = 3, mv = {1, 9, 0})
  public static final class j extends u implements dbxyzptlk.CI.a<dbxyzptlk.X2.a> {
    public final dbxyzptlk.CI.a f;
    
    public final dbxyzptlk.pI.j g;
    
    public j(dbxyzptlk.CI.a param1a, dbxyzptlk.pI.j param1j) {
      super(0);
    }
    
    public final dbxyzptlk.X2.a b() {
      // Byte code:
      //   0: aload_0
      //   1: getfield f : Ldbxyzptlk/CI/a;
      //   4: astore_1
      //   5: aload_1
      //   6: ifnull -> 25
      //   9: aload_1
      //   10: invokeinterface invoke : ()Ljava/lang/Object;
      //   15: checkcast dbxyzptlk/X2/a
      //   18: astore_2
      //   19: aload_2
      //   20: astore_1
      //   21: aload_2
      //   22: ifnonnull -> 68
      //   25: aload_0
      //   26: getfield g : Ldbxyzptlk/pI/j;
      //   29: invokestatic a : (Ldbxyzptlk/pI/j;)Ldbxyzptlk/U2/z;
      //   32: astore_1
      //   33: aload_1
      //   34: instanceof androidx/lifecycle/e
      //   37: ifeq -> 48
      //   40: aload_1
      //   41: checkcast androidx/lifecycle/e
      //   44: astore_1
      //   45: goto -> 50
      //   48: aconst_null
      //   49: astore_1
      //   50: aload_1
      //   51: ifnull -> 64
      //   54: aload_1
      //   55: invokeinterface getDefaultViewModelCreationExtras : ()Ldbxyzptlk/X2/a;
      //   60: astore_1
      //   61: goto -> 68
      //   64: getstatic dbxyzptlk/X2/a$a.b : Ldbxyzptlk/X2/a$a;
      //   67: astore_1
      //   68: aload_1
      //   69: areturn
    }
  }
  
  @Metadata(d1 = {"\000\b\n\002\030\002\n\002\b\002\020\001\032\0020\000H\n¢\006\004\b\001\020\002"}, d2 = {"Landroidx/lifecycle/t$b;", "b", "()Landroidx/lifecycle/t$b;"}, k = 3, mv = {1, 9, 0})
  public static final class k extends u implements dbxyzptlk.CI.a<t.b> {
    public final DbappLoginFragment f;
    
    public k(DbappLoginFragment param1DbappLoginFragment) {
      super(0);
    }
    
    public final t.b b() {
      return (t.b)this.f.t2();
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\dbapp\auth\login\DbappLoginFragment.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */