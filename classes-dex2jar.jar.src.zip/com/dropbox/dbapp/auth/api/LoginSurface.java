package com.dropbox.dbapp.auth.api;

import android.os.Parcel;
import android.os.Parcelable;
import dbxyzptlk.DI.s;
import kotlin.Metadata;

@Metadata(d1 = {"\000\026\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\002\030\002\n\000\bv\030\0002\0020\001:\002\002\003\001\002\004\005ø\001\000\002\006\n\004\b!0\001¨\006\006À\006\001"}, d2 = {"Lcom/dropbox/dbapp/auth/api/LoginSurface;", "Landroid/os/Parcelable;", "Default", "SignupSigninBottomSheet", "Lcom/dropbox/dbapp/auth/api/LoginSurface$Default;", "Lcom/dropbox/dbapp/auth/api/LoginSurface$SignupSigninBottomSheet;", "dbapp_auth_login_api_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
public interface LoginSurface extends Parcelable {
  @Metadata(d1 = {"\000:\n\002\030\002\n\002\030\002\n\002\b\002\n\002\020\016\n\002\b\002\n\002\020\b\n\002\b\002\n\002\020\000\n\000\n\002\020\013\n\002\b\003\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\003\bÇ\n\030\0002\0020\001B\t\b\002¢\006\004\b\002\020\003J\020\020\005\032\0020\004HÖ\001¢\006\004\b\005\020\006J\020\020\b\032\0020\007HÖ\001¢\006\004\b\b\020\tJ\032\020\r\032\0020\f2\b\020\013\032\004\030\0010\nHÖ\003¢\006\004\b\r\020\016J\020\020\017\032\0020\007HÖ\001¢\006\004\b\017\020\tJ \020\024\032\0020\0232\006\020\021\032\0020\0202\006\020\022\032\0020\007HÖ\001¢\006\004\b\024\020\025¨\006\026"}, d2 = {"Lcom/dropbox/dbapp/auth/api/LoginSurface$Default;", "Lcom/dropbox/dbapp/auth/api/LoginSurface;", "<init>", "()V", "", "toString", "()Ljava/lang/String;", "", "hashCode", "()I", "", "other", "", "equals", "(Ljava/lang/Object;)Z", "describeContents", "Landroid/os/Parcel;", "parcel", "flags", "Ldbxyzptlk/pI/D;", "writeToParcel", "(Landroid/os/Parcel;I)V", "dbapp_auth_login_api_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
  public static final class Default implements LoginSurface {
    public static final Parcelable.Creator<Default> CREATOR = new a();
    
    public static final Default a = new Default();
    
    static {
    
    }
    
    public int describeContents() {
      return 0;
    }
    
    public boolean equals(Object param1Object) {
      return (this == param1Object) ? true : (!!(param1Object instanceof Default));
    }
    
    public int hashCode() {
      return 209510151;
    }
    
    public String toString() {
      return "Default";
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      s.h(param1Parcel, "out");
      param1Parcel.writeInt(1);
    }
    
    @Metadata(k = 3, mv = {1, 9, 0}, xi = 48)
    public static final class a implements Parcelable.Creator<Default> {
      public final LoginSurface.Default a(Parcel param2Parcel) {
        s.h(param2Parcel, "parcel");
        param2Parcel.readInt();
        return LoginSurface.Default.a;
      }
      
      public final LoginSurface.Default[] b(int param2Int) {
        return new LoginSurface.Default[param2Int];
      }
    }
  }
  
  @Metadata(k = 3, mv = {1, 9, 0}, xi = 48)
  public static final class a implements Parcelable.Creator<Default> {
    public final LoginSurface.Default a(Parcel param1Parcel) {
      s.h(param1Parcel, "parcel");
      param1Parcel.readInt();
      return LoginSurface.Default.a;
    }
    
    public final LoginSurface.Default[] b(int param1Int) {
      return new LoginSurface.Default[param1Int];
    }
  }
  
  class LoginSurface {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\dbapp\auth\api\LoginSurface.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */