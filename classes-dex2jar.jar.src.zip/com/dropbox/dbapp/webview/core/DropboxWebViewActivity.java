package com.dropbox.dbapp.webview.core;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import androidx.activity.ComponentActivity;
import androidx.appcompat.widget.Toolbar;
import com.dropbox.common.activity.BaseActivity;
import com.dropbox.common.android.ui.widgets.DbxToolbarLayout;
import dbxyzptlk.CC.p;
import dbxyzptlk.Fq.f;
import dbxyzptlk.e.r;
import dbxyzptlk.mq.a;
import dbxyzptlk.mq.b;
import dbxyzptlk.mq.c;
import dbxyzptlk.mq.e;
import dbxyzptlk.oj.c;
import dbxyzptlk.rf.g;
import dbxyzptlk.ye.K;

@SuppressLint({"SyntheticAccessor", "UnknownNullness"})
public class DropboxWebViewActivity extends BaseActivity implements f {
  public WebView c;
  
  public Button d = null;
  
  public String e = null;
  
  public String f = null;
  
  public boolean g = false;
  
  @SuppressLint({"SetJavaScriptEnabled"})
  public static WebView A4(BaseActivity paramBaseActivity, a parama, WebChromeClient paramWebChromeClient) {
    WebView webView = (WebView)paramBaseActivity.findViewById(b.webview);
    p.o(webView);
    webView.getSettings().setJavaScriptEnabled(true);
    if (paramWebChromeClient != null)
      webView.setWebChromeClient(paramWebChromeClient); 
    K.a(webView);
    webView.setWebViewClient((WebViewClient)parama);
    return webView;
  }
  
  public static WebView z4(BaseActivity paramBaseActivity, a parama) {
    return A4(paramBaseActivity, parama, null);
  }
  
  public final void B4() {
    p.e(this.g, "Assert failed.");
    findViewById(b.back_button).setOnClickListener((View.OnClickListener)new a(this));
    Button button = (Button)findViewById(b.accept_button);
    this.d = button;
    button.setEnabled(false);
    this.d.setOnClickListener((View.OnClickListener)new b(this));
  }
  
  public void onBackPressed() {
    if (this.c.canGoBack()) {
      this.c.goBack();
    } else {
      super.onBackPressed();
    } 
  }
  
  public void onCreate(Bundle paramBundle) {
    r.a((ComponentActivity)this);
    super.onCreate(paramBundle);
    if (u())
      return; 
    c c = ((e)s()).t();
    Intent intent = getIntent();
    boolean bool = intent.getBooleanExtra("EXTRA_HAS_BUTTONS", false);
    this.g = bool;
    if (bool) {
      setContentView(c.web_view_with_buttons);
      setSupportActionBar((Toolbar)findViewById(g.dbx_toolbar));
      B4();
    } else {
      setContentView(c.web_view_activity);
      setSupportActionBar((Toolbar)findViewById(g.dbx_toolbar));
      getSupportActionBar().u(true);
    } 
    ((DbxToolbarLayout)findViewById(b.dbx_toolbar_layout)).setFitsSystemWindows(true);
    this.c = z4((BaseActivity)this, (a)new c(this, c));
    if (paramBundle != null && paramBundle.getString("SIS_KEY_URL") != null) {
      this.e = paramBundle.getString("SIS_KEY_URL");
    } else if (intent.getData() != null) {
      this.e = intent.getData().toString();
    } else {
      throw new IllegalStateException("Expected a url to load");
    } 
    this.c.loadUrl(this.e);
    String str = intent.getStringExtra("EXTRA_TITLE");
    p.p(str, "EXTRA_TITLE is required");
    setTitle(str);
    this.f = intent.getStringExtra("EXTRA_CLOSE_ON_REDIRECT_PATH");
  }
  
  public void onSaveInstanceState(Bundle paramBundle) {
    super.onSaveInstanceState(paramBundle);
    paramBundle.putString("SIS_KEY_URL", this.e);
  }
  
  class DropboxWebViewActivity {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\dbapp\webview\core\DropboxWebViewActivity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */