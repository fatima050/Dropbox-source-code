package com.dropbox.dbapp.purchase_journey.impl.ui.view;

import android.app.Activity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.LifecycleOwner;
import androidx.navigation.fragment.NavHostFragment;
import com.dropbox.common.activity.BaseActivity;
import com.dropbox.common.android.ui.util.ViewBindingHolder;
import com.dropbox.common.android.ui.widgets.DbxToolbar;
import com.dropbox.dbapp.purchase_journey.api.entities.PlanSupported;
import dbxyzptlk.DI.s;
import dbxyzptlk.Dp.d;
import dbxyzptlk.Eq.b;
import dbxyzptlk.Eq.d;
import dbxyzptlk.Fq.h;
import dbxyzptlk.Fq.j;
import dbxyzptlk.K2.A;
import dbxyzptlk.Me.a;
import dbxyzptlk.V4.a;
import dbxyzptlk.Wp.b;
import dbxyzptlk.Wp.d;
import dbxyzptlk.Wp.k;
import dbxyzptlk.bp.g;
import dbxyzptlk.dk.S;
import dbxyzptlk.ip.g;
import dbxyzptlk.ip.i;
import dbxyzptlk.kp.h;
import dbxyzptlk.kq.d;
import dbxyzptlk.kq.g;
import dbxyzptlk.p4.I;
import dbxyzptlk.p4.p;
import dbxyzptlk.p4.x;
import dbxyzptlk.re.k;
import dbxyzptlk.ue.a;
import java.io.Serializable;
import kotlin.Metadata;

@Metadata(d1 = {"\000\001\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\000\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\003\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020\013\n\002\b\002\n\002\030\002\n\002\b\n\n\002\020\016\n\002\b\003\n\002\030\002\n\002\b\007\n\002\030\002\n\002\b\007\n\002\030\002\n\002\b\007\n\002\030\002\n\002\b\007\n\002\030\002\n\002\b\t\b\007\030\000 U2\0020\0012\0020\0022\0020\0032\b\022\004\022\0020\0050\0042\0020\0062\b\022\004\022\0020\b0\007:\001VB\007¢\006\004\b\t\020\nJ\017\020\f\032\0020\013H\002¢\006\004\b\f\020\nJ\031\020\017\032\0020\0132\b\020\016\032\004\030\0010\rH\024¢\006\004\b\017\020\020J\017\020\022\032\0020\021H\026¢\006\004\b\022\020\023J\025\020\025\032\b\022\004\022\0020\0050\024H\026¢\006\004\b\025\020\026J\017\020\027\032\0020\013H\027¢\006\004\b\027\020\nJ\037\020\035\032\0020\0342\006\020\031\032\0020\0302\006\020\033\032\0020\032H\026¢\006\004\b\035\020\036J\027\020!\032\0020\0342\006\020 \032\0020\037H\026¢\006\004\b!\020\"R$\020)\032\004\030\0010\b8\026@\026X\016¢\006\022\n\004\b#\020$\032\004\b%\020&\"\004\b'\020(R\026\020-\032\0020*8\002@\002X.¢\006\006\n\004\b+\020,R\"\0205\032\0020.8\026@\026X.¢\006\022\n\004\b/\0200\032\004\b1\0202\"\004\b3\0204R\"\020=\032\002068\026@\026X.¢\006\022\n\004\b7\0208\032\004\b9\020:\"\004\b;\020<R\"\020E\032\0020>8\026@\026X\016¢\006\022\n\004\b?\020@\032\004\bA\020B\"\004\bC\020DR\"\020M\032\0020F8\006@\006X.¢\006\022\n\004\bG\020H\032\004\bI\020J\"\004\bK\020LR\"\020T\032\0020N8\026@\026X.¢\006\022\n\004\bO\020P\032\004\b/\020Q\"\004\bR\020S¨\006W"}, d2 = {"Lcom/dropbox/dbapp/purchase_journey/impl/ui/view/HardcodedUpsellActivity;", "Lcom/dropbox/common/activity/BaseActivity;", "Ldbxyzptlk/Fq/h;", "Lcom/dropbox/common/android/ui/widgets/DbxToolbar$c;", "Ldbxyzptlk/Eq/d;", "Ldbxyzptlk/kq/d;", "", "Lcom/dropbox/common/android/ui/util/ViewBindingHolder;", "Ldbxyzptlk/kp/h;", "<init>", "()V", "Ldbxyzptlk/pI/D;", "B4", "Landroid/os/Bundle;", "savedInstanceState", "onCreate", "(Landroid/os/Bundle;)V", "Lcom/dropbox/common/android/ui/widgets/DbxToolbar;", "G", "()Lcom/dropbox/common/android/ui/widgets/DbxToolbar;", "Ldbxyzptlk/Eq/b;", "i3", "()Ldbxyzptlk/Eq/b;", "onBackPressed", "Ldbxyzptlk/Me/a;", "accountInfo", "Ldbxyzptlk/p4/p;", "navController", "", "a1", "(Ldbxyzptlk/Me/a;Ldbxyzptlk/p4/p;)Z", "Landroid/view/MenuItem;", "item", "onOptionsItemSelected", "(Landroid/view/MenuItem;)Z", "c", "Ldbxyzptlk/kp/h;", "x4", "()Ldbxyzptlk/kp/h;", "D4", "(Ldbxyzptlk/kp/h;)V", "binding", "", "d", "Ljava/lang/String;", "userId", "Ldbxyzptlk/ue/a;", "e", "Ldbxyzptlk/ue/a;", "A4", "()Ldbxyzptlk/ue/a;", "G4", "(Ldbxyzptlk/ue/a;)V", "upsell", "Ldbxyzptlk/re/k;", "f", "Ldbxyzptlk/re/k;", "z4", "()Ldbxyzptlk/re/k;", "F4", "(Ldbxyzptlk/re/k;)V", "upgradeSource", "Lcom/dropbox/dbapp/purchase_journey/api/entities/PlanSupported;", "g", "Lcom/dropbox/dbapp/purchase_journey/api/entities/PlanSupported;", "I", "()Lcom/dropbox/dbapp/purchase_journey/api/entities/PlanSupported;", "E4", "(Lcom/dropbox/dbapp/purchase_journey/api/entities/PlanSupported;)V", "plan", "Ldbxyzptlk/bp/g;", "h", "Ldbxyzptlk/bp/g;", "y4", "()Ldbxyzptlk/bp/g;", "setUpgradePageLogger", "(Ldbxyzptlk/bp/g;)V", "upgradePageLogger", "Ldbxyzptlk/Dp/d;", "i", "Ldbxyzptlk/Dp/d;", "()Ldbxyzptlk/Dp/d;", "setManager", "(Ldbxyzptlk/Dp/d;)V", "manager", "j", "a", "dbapp_purchase_journey_impl_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class HardcodedUpsellActivity extends BaseActivity implements h, DbxToolbar.c, d<d>, k, ViewBindingHolder<h> {
  public static final a j = new a(null);
  
  public static final int k = 8;
  
  public h c;
  
  public String d;
  
  public a e;
  
  public k f;
  
  public PlanSupported g = PlanSupported.Plus;
  
  public g h;
  
  public d i;
  
  private final void B4() {
    d.b(e(), (BaseActivity)this, z4(), null, false, 12, null);
  }
  
  public static final void C4(HardcodedUpsellActivity paramHardcodedUpsellActivity, String paramString, Bundle paramBundle) {
    s.h(paramHardcodedUpsellActivity, "this$0");
    s.h(paramString, "<anonymous parameter 0>");
    s.h(paramBundle, "bundle");
    int i = paramBundle.getInt("DropboxProductFamilyIntBundleKey");
    paramHardcodedUpsellActivity.E4(PlanSupported.Companion.a(i));
    paramHardcodedUpsellActivity.y4().L(i);
  }
  
  public a A4() {
    a a1 = this.e;
    if (a1 != null)
      return a1; 
    s.u("upsell");
    return null;
  }
  
  public void D4(h paramh) {
    this.c = paramh;
  }
  
  public void E4(PlanSupported paramPlanSupported) {
    s.h(paramPlanSupported, "<set-?>");
    this.g = paramPlanSupported;
  }
  
  public void F4(k paramk) {
    s.h(paramk, "<set-?>");
    this.f = paramk;
  }
  
  public DbxToolbar G() {
    DbxToolbar dbxToolbar = ((h)g3()).c;
    s.g(dbxToolbar, "dbxToolbar");
    return dbxToolbar;
  }
  
  public void G4(a parama) {
    s.h(parama, "<set-?>");
    this.e = parama;
  }
  
  public PlanSupported I() {
    return this.g;
  }
  
  public boolean a1(a parama, p paramp) {
    s.h(parama, "accountInfo");
    s.h(paramp, "navController");
    return e().d((BaseActivity)this, paramp, z4(), I());
  }
  
  public d e() {
    d d1 = this.i;
    if (d1 != null)
      return d1; 
    s.u("manager");
    return null;
  }
  
  public b<d> i3() {
    return g.d((j)this, z4());
  }
  
  public void onBackPressed() {
    B4();
    super.onBackPressed();
  }
  
  public void onCreate(Bundle paramBundle) {
    if (u())
      return; 
    Bundle bundle = getIntent().getExtras();
    if (bundle != null) {
      s.g(bundle, "requireNotNull(...)");
      Serializable serializable = S.a(bundle, "EXTRA_SOURCE", k.class);
      if (serializable != null) {
        F4((k)serializable);
        serializable = S.a(bundle, "EXTRA_HARDCODED_UPSELL", a.class);
        if (serializable != null) {
          G4((a)serializable);
          Serializable serializable1 = S.a(bundle, "EXTRA_USER_ID", String.class);
          if (serializable1 != null) {
            StringBuilder stringBuilder;
            this.d = (String)serializable1;
            super.onCreate(paramBundle);
            d.a(this);
            y4().D();
            y4().U(z4());
            D4(h.c(getLayoutInflater()));
            setContentView((View)((h)g3()).b());
            d d1 = e();
            serializable1 = this.d;
            Serializable serializable2 = serializable1;
            if (serializable1 == null) {
              s.u("userId");
              serializable2 = null;
            } 
            d1.c((BaseActivity)this, (String)serializable2, z4());
            Fragment fragment = getSupportFragmentManager().l0(g.hardcoded_upsell_nav_host_fragment);
            s.f(fragment, "null cannot be cast to non-null type androidx.navigation.fragment.NavHostFragment");
            NavHostFragment navHostFragment = (NavHostFragment)fragment;
            x x = navHostFragment.n2().F().b(i.iap_hardcoded_nav_graph);
            a a1 = A4();
            int i = b.a[a1.ordinal()];
            if (i != 1) {
              if (i == 2) {
                i = g.iap_device_paywall_frag;
              } else {
                String str = A4().name();
                stringBuilder = new StringBuilder();
                stringBuilder.append("Invalid hardcoded upsell start destination: ");
                stringBuilder.append(str);
                throw new IllegalArgumentException(stringBuilder.toString());
              } 
            } else {
              i = g.iap_survivor_v2_frag;
            } 
            x.b0(i);
            stringBuilder.n2().m0(x);
            setSupportActionBar((Toolbar)((h)g3()).c);
            ((h)g3()).c.a();
            ((h)g3()).b.setOutlineProvider(null);
            getSupportFragmentManager().K1("PLAN_PURCHASING_KEY", (LifecycleOwner)this, (A)new b(this));
            return;
          } 
          throw new IllegalArgumentException("Required value was null.");
        } 
        throw new IllegalArgumentException("Required value was null.");
      } 
      throw new IllegalArgumentException("Required value was null.");
    } 
    throw new IllegalArgumentException("Required value was null.");
  }
  
  public boolean onOptionsItemSelected(MenuItem paramMenuItem) {
    s.h(paramMenuItem, "item");
    if (paramMenuItem.getItemId() == 16908332) {
      if (I.b((Activity)this, g.hardcoded_upsell_nav_host_fragment).W())
        return true; 
      B4();
    } 
    return super.onOptionsItemSelected(paramMenuItem);
  }
  
  public h x4() {
    return this.c;
  }
  
  public final g y4() {
    g g1 = this.h;
    if (g1 != null)
      return g1; 
    s.u("upgradePageLogger");
    return null;
  }
  
  public k z4() {
    k k1 = this.f;
    if (k1 != null)
      return k1; 
    s.u("upgradeSource");
    return null;
  }
  
  class HardcodedUpsellActivity {}
  
  class HardcodedUpsellActivity {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\dbapp\purchase_journey\imp\\ui\view\HardcodedUpsellActivity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */