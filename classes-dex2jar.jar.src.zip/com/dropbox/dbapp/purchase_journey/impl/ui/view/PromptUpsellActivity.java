package com.dropbox.dbapp.purchase_journey.impl.ui.view;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import androidx.appcompat.widget.Toolbar;
import androidx.lifecycle.LifecycleOwner;
import com.dropbox.common.activity.BaseActivity;
import com.dropbox.common.android.ui.util.ViewBindingHolder;
import com.dropbox.common.android.ui.widgets.DbxToolbar;
import com.dropbox.dbapp.purchase_journey.api.entities.PlanSupported;
import dbxyzptlk.CI.l;
import dbxyzptlk.DI.s;
import dbxyzptlk.Dp.d;
import dbxyzptlk.Eq.b;
import dbxyzptlk.Eq.d;
import dbxyzptlk.Fq.h;
import dbxyzptlk.Fq.j;
import dbxyzptlk.K2.A;
import dbxyzptlk.Me.a;
import dbxyzptlk.V4.a;
import dbxyzptlk.Wp.f;
import dbxyzptlk.Wp.h;
import dbxyzptlk.Wp.k;
import dbxyzptlk.bp.g;
import dbxyzptlk.dk.H;
import dbxyzptlk.dk.S;
import dbxyzptlk.e.G;
import dbxyzptlk.kp.l;
import dbxyzptlk.kq.d;
import dbxyzptlk.kq.g;
import dbxyzptlk.p4.p;
import dbxyzptlk.qI.s;
import dbxyzptlk.re.k;
import java.io.Serializable;
import java.util.List;
import kotlin.Metadata;

@Metadata(d1 = {"\000\001\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\000\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\002\b\003\n\002\030\002\n\002\b\002\n\002\030\002\n\002\b\002\n\002\030\002\n\000\n\002\030\002\n\000\n\002\020\013\n\002\b\002\n\002\030\002\n\002\b\003\n\002\020\016\n\002\b\n\n\002\030\002\n\002\b\r\n\002\020\t\n\002\b\007\n\002\020 \n\002\030\002\n\002\b\016\n\002\030\002\n\002\b\007\n\002\030\002\n\002\b\t\b\007\030\000 b2\0020\0012\0020\0022\0020\0032\0020\0042\b\022\004\022\0020\0060\0052\b\022\004\022\0020\b0\007:\001cB\007¢\006\004\b\t\020\nJ\017\020\f\032\0020\013H\002¢\006\004\b\f\020\nJ\031\020\017\032\0020\0132\b\020\016\032\004\030\0010\rH\024¢\006\004\b\017\020\020J\017\020\022\032\0020\021H\026¢\006\004\b\022\020\023J\025\020\025\032\b\022\004\022\0020\0060\024H\026¢\006\004\b\025\020\026J\037\020\034\032\0020\0332\006\020\030\032\0020\0272\006\020\032\032\0020\031H\026¢\006\004\b\034\020\035J\027\020 \032\0020\0332\006\020\037\032\0020\036H\026¢\006\004\b \020!R\026\020%\032\0020\"8\002@\002X.¢\006\006\n\004\b#\020$R$\020,\032\004\030\0010\b8\026@\026X\016¢\006\022\n\004\b&\020'\032\004\b(\020)\"\004\b*\020+R\"\0204\032\0020-8\026@\026X.¢\006\022\n\004\b.\020/\032\004\b0\0201\"\004\b2\0203R$\020:\032\004\030\0010\"8\026@\026X\016¢\006\022\n\004\b5\020$\032\004\b6\0207\"\004\b8\0209R$\020B\032\004\030\0010;8\026@\026X\016¢\006\022\n\004\b<\020=\032\004\b>\020?\"\004\b@\020AR(\020K\032\b\022\004\022\0020D0C8\006@\006X.¢\006\022\n\004\bE\020F\032\004\bG\020H\"\004\bI\020JR\"\020R\032\0020D8\026@\026X\016¢\006\022\n\004\bL\020M\032\004\bN\020O\"\004\bP\020QR\"\020Z\032\0020S8\006@\006X.¢\006\022\n\004\bT\020U\032\004\bV\020W\"\004\bX\020YR\"\020a\032\0020[8\026@\026X.¢\006\022\n\004\b\\\020]\032\004\b.\020^\"\004\b_\020`¨\006d"}, d2 = {"Lcom/dropbox/dbapp/purchase_journey/impl/ui/view/PromptUpsellActivity;", "Lcom/dropbox/common/activity/BaseActivity;", "Ldbxyzptlk/Fq/h;", "", "Lcom/dropbox/common/android/ui/widgets/DbxToolbar$c;", "Ldbxyzptlk/Eq/d;", "Ldbxyzptlk/kq/d;", "Lcom/dropbox/common/android/ui/util/ViewBindingHolder;", "Ldbxyzptlk/kp/l;", "<init>", "()V", "Ldbxyzptlk/pI/D;", "E4", "Landroid/os/Bundle;", "savedInstanceState", "onCreate", "(Landroid/os/Bundle;)V", "Lcom/dropbox/common/android/ui/widgets/DbxToolbar;", "G", "()Lcom/dropbox/common/android/ui/widgets/DbxToolbar;", "Ldbxyzptlk/Eq/b;", "i3", "()Ldbxyzptlk/Eq/b;", "Ldbxyzptlk/Me/a;", "accountInfo", "Ldbxyzptlk/p4/p;", "navController", "", "a1", "(Ldbxyzptlk/Me/a;Ldbxyzptlk/p4/p;)Z", "Landroid/view/MenuItem;", "item", "onOptionsItemSelected", "(Landroid/view/MenuItem;)Z", "", "c", "Ljava/lang/String;", "userId", "d", "Ldbxyzptlk/kp/l;", "y4", "()Ldbxyzptlk/kp/l;", "G4", "(Ldbxyzptlk/kp/l;)V", "binding", "Ldbxyzptlk/re/k;", "e", "Ldbxyzptlk/re/k;", "D4", "()Ldbxyzptlk/re/k;", "L4", "(Ldbxyzptlk/re/k;)V", "upgradeSource", "f", "C4", "()Ljava/lang/String;", "K4", "(Ljava/lang/String;)V", "targetCampaignName", "", "g", "Ljava/lang/Long;", "B4", "()Ljava/lang/Long;", "J4", "(Ljava/lang/Long;)V", "referrerCampaignId", "", "Lcom/dropbox/dbapp/purchase_journey/api/entities/PlanSupported;", "h", "Ljava/util/List;", "A4", "()Ljava/util/List;", "I4", "(Ljava/util/List;)V", "prioritizedPlanList", "i", "Lcom/dropbox/dbapp/purchase_journey/api/entities/PlanSupported;", "I", "()Lcom/dropbox/dbapp/purchase_journey/api/entities/PlanSupported;", "H4", "(Lcom/dropbox/dbapp/purchase_journey/api/entities/PlanSupported;)V", "plan", "Ldbxyzptlk/bp/g;", "j", "Ldbxyzptlk/bp/g;", "z4", "()Ldbxyzptlk/bp/g;", "setLogger", "(Ldbxyzptlk/bp/g;)V", "logger", "Ldbxyzptlk/Dp/d;", "k", "Ldbxyzptlk/Dp/d;", "()Ldbxyzptlk/Dp/d;", "setManager", "(Ldbxyzptlk/Dp/d;)V", "manager", "l", "Companion", "dbapp_purchase_journey_impl_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class PromptUpsellActivity extends BaseActivity implements h, k, DbxToolbar.c, d<d>, ViewBindingHolder<l> {
  public static final Companion l = new Companion(null);
  
  public static final int m = 8;
  
  public String c;
  
  public l d;
  
  public k e;
  
  public String f;
  
  public Long g;
  
  public List<? extends PlanSupported> h;
  
  public PlanSupported i = PlanSupported.Plus;
  
  public g j;
  
  public d k;
  
  private final void E4() {
    d.b(e(), (BaseActivity)this, D4(), null, false, 12, null);
  }
  
  public static final void F4(PromptUpsellActivity paramPromptUpsellActivity, String paramString, Bundle paramBundle) {
    s.h(paramPromptUpsellActivity, "this$0");
    s.h(paramString, "<anonymous parameter 0>");
    s.h(paramBundle, "bundle");
    int i = paramBundle.getInt("DropboxProductFamilyIntBundleKey");
    paramPromptUpsellActivity.H4(PlanSupported.Companion.a(i));
    paramPromptUpsellActivity.z4().L(i);
  }
  
  public final List<PlanSupported> A4() {
    List<? extends PlanSupported> list = this.h;
    if (list != null)
      return (List)list; 
    s.u("prioritizedPlanList");
    return null;
  }
  
  public Long B4() {
    return this.g;
  }
  
  public String C4() {
    return this.f;
  }
  
  public k D4() {
    k k1 = this.e;
    if (k1 != null)
      return k1; 
    s.u("upgradeSource");
    return null;
  }
  
  public DbxToolbar G() {
    DbxToolbar dbxToolbar = ((l)g3()).c;
    s.g(dbxToolbar, "dbxToolbar");
    return dbxToolbar;
  }
  
  public void G4(l paraml) {
    this.d = paraml;
  }
  
  public void H4(PlanSupported paramPlanSupported) {
    s.h(paramPlanSupported, "<set-?>");
    this.i = paramPlanSupported;
  }
  
  public PlanSupported I() {
    return this.i;
  }
  
  public final void I4(List<? extends PlanSupported> paramList) {
    s.h(paramList, "<set-?>");
    this.h = paramList;
  }
  
  public void J4(Long paramLong) {
    this.g = paramLong;
  }
  
  public void K4(String paramString) {
    this.f = paramString;
  }
  
  public void L4(k paramk) {
    s.h(paramk, "<set-?>");
    this.e = paramk;
  }
  
  public boolean a1(a parama, p paramp) {
    s.h(parama, "accountInfo");
    s.h(paramp, "navController");
    return e().d((BaseActivity)this, paramp, D4(), I());
  }
  
  public d e() {
    d d1 = this.k;
    if (d1 != null)
      return d1; 
    s.u("manager");
    return null;
  }
  
  public b<d> i3() {
    return g.e((j)this, D4(), C4(), B4(), A4());
  }
  
  public void onCreate(Bundle paramBundle) {
    if (u())
      return; 
    Bundle bundle = getIntent().getExtras();
    if (bundle != null) {
      s.g(bundle, "requireNotNull(...)");
      Serializable serializable = S.a(bundle, "EXTRA_UPGRADE_SOURCE", k.class);
      if (serializable != null) {
        List<? extends PlanSupported> list;
        L4((k)serializable);
        K4(bundle.getString("EXTRA_TARGET_CAMPAIGN_NAME"));
        J4(Long.valueOf(bundle.getLong("EXTRA_REFERRER_CAMPAIGN_ID", -1L)));
        serializable = H.b(bundle, "EXTRA_PRIORITIZED_PLAN", PlanSupported.class);
        if (serializable == null)
          list = s.m(); 
        I4(list);
        super.onCreate(paramBundle);
        h.a(this);
        z4().U(D4());
        G4(l.c(getLayoutInflater()));
        setContentView((View)((l)g3()).b());
        String str = bundle.getString("EXTRA_USER_ID");
        if (str != null) {
          this.c = str;
          d d1 = e();
          String str1 = this.c;
          str = str1;
          if (str1 == null) {
            s.u("userId");
            str = null;
          } 
          d1.c((BaseActivity)this, str, D4());
          setSupportActionBar((Toolbar)((l)g3()).c);
          ((l)g3()).c.a();
          ((l)g3()).b.setOutlineProvider(null);
          getSupportFragmentManager().K1("PLAN_PURCHASING_KEY", (LifecycleOwner)this, (A)new f(this));
          G.b(getOnBackPressedDispatcher(), (LifecycleOwner)this, false, (l)new a(this), 2, null);
          return;
        } 
        throw new IllegalArgumentException("Required value was null.");
      } 
      throw new IllegalArgumentException("Required value was null.");
    } 
    throw new IllegalArgumentException("Required value was null.");
  }
  
  public boolean onOptionsItemSelected(MenuItem paramMenuItem) {
    s.h(paramMenuItem, "item");
    if (paramMenuItem.getItemId() == 16908332)
      getOnBackPressedDispatcher().l(); 
    return true;
  }
  
  public l y4() {
    return this.d;
  }
  
  public final g z4() {
    g g1 = this.j;
    if (g1 != null)
      return g1; 
    s.u("logger");
    return null;
  }
  
  class PromptUpsellActivity {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\dbapp\purchase_journey\imp\\ui\view\PromptUpsellActivity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */