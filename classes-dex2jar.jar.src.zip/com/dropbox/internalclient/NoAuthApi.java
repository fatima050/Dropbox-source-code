package com.dropbox.internalclient;

import android.net.Uri;
import com.dropbox.base.http.AccessTokenPair;
import com.dropbox.common.legacy_api.exception.DropboxException;
import com.dropbox.core.DbxException;
import com.dropbox.product.dbapp.path.SharedLinkPath;
import dbxyzptlk.CC.m;
import dbxyzptlk.Fe.c;
import dbxyzptlk.Kh.f;
import dbxyzptlk.Kh.g;
import dbxyzptlk.Nk.b;
import dbxyzptlk.fx.d;
import dbxyzptlk.mk.A0;
import dbxyzptlk.mk.u;
import dbxyzptlk.rx.c;
import dbxyzptlk.vw.m;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Collection;

public interface NoAuthApi {
  Uri A(String paramString1, String paramString2);
  
  u F(String paramString1, c paramc, String paramString2, String paramString3, String paramString4) throws DropboxException;
  
  u H(String paramString1, String paramString2, String paramString3) throws DropboxException;
  
  u I(String paramString1, String paramString2) throws DropboxException;
  
  u J(AccessTokenPair paramAccessTokenPair, String paramString1, String paramString2) throws DropboxException;
  
  void K(b paramb, String paramString) throws DbxException;
  
  String M(String paramString) throws DropboxException;
  
  u Q(b paramb, String paramString1, String paramString2, String paramString3) throws DbxException, AppleLoginRequiresSignupException;
  
  void T(String paramString1, a parama, Collection<String> paramCollection, String paramString2, String paramString3, String paramString4, long paramLong1, InputStream paramInputStream, long paramLong2, boolean paramBoolean) throws DropboxException;
  
  int a(String paramString) throws DropboxException;
  
  d b(SharedLinkPath paramSharedLinkPath, m<c> paramm) throws DropboxException;
  
  f c();
  
  String d(SharedLinkPath paramSharedLinkPath, m<c> paramm, OutputStream paramOutputStream, g paramg) throws DropboxException;
  
  c e(SharedLinkPath paramSharedLinkPath, m<c> paramm, OutputStream paramOutputStream, g paramg) throws DropboxException;
  
  String f(SharedLinkPath paramSharedLinkPath) throws DropboxException;
  
  Uri g(String paramString) throws DropboxException;
  
  m h(String paramString1, String paramString2, m<c> paramm, int paramInt, String paramString3, boolean paramBoolean) throws DropboxException;
  
  A0 k(String paramString) throws DropboxException;
  
  u o(String paramString1, c paramc, String paramString2, String paramString3, b paramb, boolean paramBoolean, String paramString4, String paramString5) throws DropboxException;
  
  u q(String paramString, b paramb, boolean paramBoolean) throws DropboxException;
  
  u r(c paramc, String paramString) throws DropboxException;
  
  u t(c paramc, String paramString1, String paramString2) throws DropboxException;
  
  u u(b paramb, String paramString) throws DbxException;
  
  InputStream x(SharedLinkPath paramSharedLinkPath, m<c> paramm, int paramInt) throws DropboxException;
  
  class NoAuthApi {}
  
  class NoAuthApi {}
  
  class NoAuthApi {}
  
  public enum a {
    ANALYTICS, ERROR, FATAL, INFO, WARN;
    
    private static final a[] $VALUES;
    
    static {
      ANALYTICS = new a("ANALYTICS", 4);
      $VALUES = a();
    }
  }
  
  class NoAuthApi {}
  
  class NoAuthApi {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\internalclient\NoAuthApi.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */