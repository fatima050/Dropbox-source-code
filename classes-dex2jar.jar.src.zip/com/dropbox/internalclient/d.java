package com.dropbox.internalclient;

import com.dropbox.common.legacy_api.exception.DropboxException;
import com.dropbox.core.DbxException;
import com.dropbox.product.dbapp.path.SharedLinkPath;
import dbxyzptlk.CC.m;
import dbxyzptlk.Fe.c;
import dbxyzptlk.Kh.g;
import dbxyzptlk.rx.c;
import dbxyzptlk.rx.h;
import dbxyzptlk.rx.i;
import dbxyzptlk.rx.j;
import dbxyzptlk.vw.m;
import java.io.OutputStream;

public interface d {
  int a(String paramString) throws DropboxException;
  
  dbxyzptlk.fx.d b(SharedLinkPath paramSharedLinkPath, m<c> paramm) throws DropboxException;
  
  void c(SharedLinkPath paramSharedLinkPath, m<c> paramm, OutputStream paramOutputStream, j paramj, h paramh, i parami, g paramg) throws DropboxException, DbxException;
  
  String d(SharedLinkPath paramSharedLinkPath, m<c> paramm, OutputStream paramOutputStream, g paramg) throws DropboxException, DbxException;
  
  c e(SharedLinkPath paramSharedLinkPath, m<c> paramm, OutputStream paramOutputStream, g paramg) throws DropboxException;
  
  String f(SharedLinkPath paramSharedLinkPath, c paramc) throws SharedLinkApiException;
  
  dbxyzptlk.A9.d g(SharedLinkPath paramSharedLinkPath, m<c> paramm, m<String> paramm1) throws SharedLinkApiException;
  
  m h(SharedLinkPath paramSharedLinkPath, m<c> paramm, String paramString) throws SharedLinkApiException;
  
  m i(SharedLinkPath paramSharedLinkPath, m<c> paramm) throws SharedLinkApiException;
  
  c j(SharedLinkPath paramSharedLinkPath, m<c> paramm, m<String> paramm1, OutputStream paramOutputStream, g paramg) throws SharedLinkApiException;
  
  m<String> l();
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\internalclient\d.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */