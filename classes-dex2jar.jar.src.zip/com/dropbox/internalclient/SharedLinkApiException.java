package com.dropbox.internalclient;

import kotlin.Metadata;

@Metadata(d1 = {"\000\032\n\002\030\002\n\002\030\002\n\002\030\002\n\002\020\016\n\000\n\002\030\002\n\002\b\r\b\007\030\0002\0060\001j\002`\002:\001\nB!\022\b\020\004\032\004\030\0010\003\022\006\020\006\032\0020\005\022\006\020\007\032\0020\003¢\006\004\b\b\020\tR\031\020\004\032\004\030\0010\0038\006¢\006\f\n\004\b\n\020\013\032\004\b\n\020\fR\027\020\006\032\0020\0058\006¢\006\f\n\004\b\r\020\016\032\004\b\r\020\017R\027\020\007\032\0020\0038\006¢\006\f\n\004\b\020\020\013\032\004\b\021\020\f¨\006\022"}, d2 = {"Lcom/dropbox/internalclient/SharedLinkApiException;", "Ljava/lang/Exception;", "Lkotlin/Exception;", "", "errorCode", "Lcom/dropbox/internalclient/SharedLinkApiException$a;", "errorType", "errorMessage", "<init>", "(Ljava/lang/String;Lcom/dropbox/internalclient/SharedLinkApiException$a;Ljava/lang/String;)V", "a", "Ljava/lang/String;", "()Ljava/lang/String;", "b", "Lcom/dropbox/internalclient/SharedLinkApiException$a;", "()Lcom/dropbox/internalclient/SharedLinkApiException$a;", "c", "getErrorMessage", "Dropbox_normalRelease"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class SharedLinkApiException extends Exception {
  public final String a;
  
  public final a b;
  
  public final String c;
  
  public SharedLinkApiException(String paramString1, a parama, String paramString2) {
    super(paramString2);
    this.a = paramString1;
    this.b = parama;
    this.c = paramString2;
  }
  
  public final String a() {
    return this.a;
  }
  
  public final a b() {
    return this.b;
  }
  
  class SharedLinkApiException {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\internalclient\SharedLinkApiException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */