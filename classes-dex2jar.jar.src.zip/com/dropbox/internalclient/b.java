package com.dropbox.internalclient;

import android.net.Uri;
import com.dropbox.base.http.AccessTokenPair;
import com.dropbox.base.http.Oauth2AccessToken;
import com.dropbox.common.json.JsonExtractionException;
import com.dropbox.common.legacy_api.exception.DropboxException;
import com.dropbox.core.DbxException;
import com.dropbox.product.dbapp.path.SharedLinkPath;
import com.google.common.collect.q;
import dbxyzptlk.Bq.g;
import dbxyzptlk.CC.m;
import dbxyzptlk.CC.p;
import dbxyzptlk.Ce.a;
import dbxyzptlk.Cg.a;
import dbxyzptlk.Cq.a;
import dbxyzptlk.EC.G;
import dbxyzptlk.Fe.c;
import dbxyzptlk.Kh.f;
import dbxyzptlk.Kh.g;
import dbxyzptlk.Kh.i;
import dbxyzptlk.Kh.n;
import dbxyzptlk.Kh.p;
import dbxyzptlk.Kh.q;
import dbxyzptlk.Kh.r;
import dbxyzptlk.Lh.i;
import dbxyzptlk.Nl.d;
import dbxyzptlk.Ok.A;
import dbxyzptlk.Ok.F0;
import dbxyzptlk.Ok.a;
import dbxyzptlk.Ok.i;
import dbxyzptlk.Ok.p0;
import dbxyzptlk.Ok.r0;
import dbxyzptlk.XK.a;
import dbxyzptlk.XK.c;
import dbxyzptlk.YJ.t;
import dbxyzptlk.fx.d;
import dbxyzptlk.mk.A0;
import dbxyzptlk.mk.B0;
import dbxyzptlk.mk.e;
import dbxyzptlk.mk.u;
import dbxyzptlk.rx.c;
import dbxyzptlk.vw.m;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Locale;
import okhttp3.MediaType;
import okhttp3.Request;

public class b extends g implements NoAuthApi {
  public final dbxyzptlk.ok.b c;
  
  public final a d;
  
  public b(f paramf, dbxyzptlk.ok.b paramb, a parama) {
    super(paramf, parama);
    this.c = paramb;
    this.d = parama;
  }
  
  public Uri A(String paramString1, String paramString2) {
    p.o(paramString1);
    p.o(paramString2);
    return (new Uri.Builder()).scheme("https").authority(this.d.m()).appendPath("profile_services/redirect_to_identity_provider").appendQueryParameter("action", "login_user").appendQueryParameter("cont", "dbx-sia://login").appendQueryParameter("is_desktop", "false").appendQueryParameter("is_android", "true").appendQueryParameter("is_popup", "false").appendQueryParameter("pair_user", "false").appendQueryParameter("referrer", "login_form").appendQueryParameter("service", "13").appendQueryParameter("host_nonce", paramString1).appendQueryParameter("pkce_challenge", paramString2).build();
  }
  
  public u F(String paramString1, c paramc, String paramString2, String paramString3, String paramString4) throws DropboxException {
    p.d(t.C(paramString1) ^ true);
    ArrayList<String> arrayList = G.k((Object[])new String[] { "email", paramString1, "password", paramc.a(), "device_info", W(), "anew", "true" });
    if (paramString2 != null) {
      arrayList.add("team_emm_token");
      arrayList.add(paramString2);
    } 
    if (paramString3 != null) {
      arrayList.add("recaptcha_v2_response");
      arrayList.add(paramString3);
    } 
    if (paramString4 != null) {
      arrayList.add("android_integrity_token");
      arrayList.add(paramString4);
    } 
    String[] arrayOfString = new String[arrayList.size()];
    arrayList.toArray(arrayOfString);
    i i = U("/api_login", arrayOfString);
    try {
      return (u)u.k.a(i);
    } catch (JsonExtractionException jsonExtractionException) {
      throw new RuntimeException(jsonExtractionException);
    } 
  }
  
  public u H(String paramString1, String paramString2, String paramString3) throws DropboxException {
    ArrayList<String> arrayList = G.k((Object[])new String[] { "auth_code", paramString2, "email", paramString1, "device_info", W() });
    if (paramString3 != null) {
      arrayList.add("team_emm_token");
      arrayList.add(paramString3);
    } 
    String[] arrayOfString = new String[arrayList.size()];
    arrayList.toArray(arrayOfString);
    i i = U("/api_google_login", arrayOfString);
    try {
      return (u)u.k.a(i);
    } catch (JsonExtractionException jsonExtractionException) {
      throw new RuntimeException(jsonExtractionException);
    } 
  }
  
  public u I(String paramString1, String paramString2) throws DropboxException {
    i i = U("/twofactor_verify", new String[] { "checkpoint_token", paramString1, "twofactor_code", paramString2, "device_info", W() });
    try {
      return (u)u.k.a(i);
    } catch (JsonExtractionException jsonExtractionException) {
      throw new RuntimeException(jsonExtractionException);
    } 
  }
  
  public u J(AccessTokenPair paramAccessTokenPair, String paramString1, String paramString2) throws DropboxException {
    r r = c().s();
    String str = r.t(paramAccessTokenPair, paramString1, W(), paramString2);
    try {
      long l = Long.parseLong(str);
      return new u(l, r.b());
    } catch (NumberFormatException numberFormatException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Bad user id retrieving access token. Got: ");
      stringBuilder.append(str);
      throw new DropboxException(stringBuilder.toString(), numberFormatException);
    } 
  }
  
  public void K(dbxyzptlk.Nk.b paramb, String paramString) throws DbxException {
    p.d(t.C(paramString) ^ true);
    paramb.h().d(paramString, W());
  }
  
  public String M(String paramString) throws DropboxException {
    i i = U("/twofactor_resend", new String[] { "checkpoint_token", paramString });
    try {
      return i.p().j("twofactor_desc").v();
    } catch (JsonExtractionException jsonExtractionException) {
      throw new RuntimeException(jsonExtractionException);
    } 
  }
  
  public u Q(dbxyzptlk.Nk.b paramb, String paramString1, String paramString2, String paramString3) throws DbxException, NoAuthApi.AppleLoginRequiresSignupException {
    p.o(paramb);
    p.o(paramString1);
    p.o(paramString2);
    i i = paramb.a().b(paramString1).c(paramString2).d(paramString3).b(A.a().b(this.c.c()).c(this.c.k()).d(Locale.getDefault().toString()).e(this.c.b()).g(this.c.f()).h(this.c.g()).a()).a();
    if (!i.i()) {
      p0 p0;
      r0 r0;
      if (i.h()) {
        p0 = i.e();
        return new u(p0.c(), new e(p0.a(), p0.b()));
      } 
      if (p0.j()) {
        r0 = p0.f();
        F0.c c = r0.c().e();
        return new u(new B0(r0.a(), r0.b(), r0.d(), B0.a.fromString(c.name())));
      } 
      if (r0.k()) {
        a a1 = r0.g();
        return new u(a1.b(), (a)new Oauth2AccessToken(a1.a()));
      } 
      throw new RuntimeException("Unknown result for SIA.");
    } 
    throw new NoAuthApi.AppleLoginRequiresSignupException();
  }
  
  public void T(String paramString1, NoAuthApi.a parama, Collection<String> paramCollection, String paramString2, String paramString3, String paramString4, long paramLong1, InputStream paramInputStream, long paramLong2, boolean paramBoolean) throws DropboxException {
    f f = c();
    ArrayList<String> arrayList = new ArrayList<>(paramCollection);
    String str3 = a.q.toString();
    String str2 = a.g.toString();
    String str1 = parama.name();
    String str4 = a.k.toString();
    String str6 = a.e(arrayList);
    String str8 = a.p.toString();
    String str7 = a.e.toString();
    String str5 = a.d.toString();
    paramString1 = i.c(this.d.i(), "r19", a.o.toString(), new String[] { 
          str3, "android", str2, paramString1, "log_level", str1, str4, str6, str8, paramString2, 
          str7, paramString3, str5, paramString4, "ts", String.valueOf(paramLong1) });
    Request.Builder builder = (new Request.Builder()).url(paramString1);
    if (paramBoolean) {
      paramString1 = "gzip";
    } else {
      paramString1 = "application/octet-stream";
    } 
    i.d((q)f, f.p(builder.header("Content-Encoding", paramString1).put(p.a(MediaType.parse("text/plain"), paramInputStream, paramLong2))), false).b().close();
  }
  
  public final String W() {
    HashMap<String, String> hashMap = q.g();
    hashMap.put(a.g.toString(), this.c.c());
    hashMap.put(a.p.toString(), this.c.b());
    hashMap.put(a.e.toString(), this.c.f());
    hashMap.put(a.d.toString(), this.c.g());
    hashMap.put(a.h.toString(), this.c.k());
    hashMap.put(a.j.toString(), Locale.getDefault().toString());
    hashMap.put(a.m.toString(), Boolean.valueOf(this.c.j()));
    hashMap.put(a.c.toString(), Boolean.valueOf(this.c.h()));
    return c.c(hashMap);
  }
  
  public int a(String paramString) throws DropboxException {
    return this.a.d(paramString);
  }
  
  public d b(SharedLinkPath paramSharedLinkPath, m<c> paramm) throws DropboxException {
    throw new IllegalStateException();
  }
  
  public String d(SharedLinkPath paramSharedLinkPath, m<c> paramm, OutputStream paramOutputStream, g paramg) throws DropboxException {
    return this.a.p(paramSharedLinkPath, paramm, paramOutputStream, paramg);
  }
  
  public c e(SharedLinkPath paramSharedLinkPath, m<c> paramm, OutputStream paramOutputStream, g paramg) throws DropboxException {
    return this.a.k(paramSharedLinkPath, paramm, paramOutputStream, paramg);
  }
  
  public String f(SharedLinkPath paramSharedLinkPath) throws DropboxException {
    return this.a.m(paramSharedLinkPath);
  }
  
  public Uri g(String paramString) throws DropboxException {
    p.o(paramString);
    return (new n((q)c())).g(paramString);
  }
  
  public m h(String paramString1, String paramString2, m<c> paramm, int paramInt, String paramString3, boolean paramBoolean) throws DropboxException {
    return this.a.o(paramString1, paramString2, paramm, paramInt, paramString3, paramBoolean);
  }
  
  public A0 k(String paramString) throws DropboxException {
    r.a a1 = c().s().s("dbx-sso://");
    Uri uri = (new Uri.Builder()).scheme("https").authority(this.d.m()).appendPath("sso").appendQueryParameter("from_mobile", "true").appendQueryParameter("login_email", paramString).appendQueryParameter("cont", a1.a).build();
    AccessTokenPair accessTokenPair = a1.b;
    return new A0(paramString, uri, accessTokenPair.key, accessTokenPair.secret);
  }
  
  public u o(String paramString1, c paramc, String paramString2, String paramString3, NoAuthApi.b paramb, boolean paramBoolean, String paramString4, String paramString5) throws DropboxException {
    p.d(t.C(paramString1) ^ true);
    p.o(paramc);
    p.e(paramc.b() ^ true, "Assert failed.");
    p.o(paramb);
    ArrayList<String> arrayList = G.k((Object[])new String[] { 
          a.f.toString(), paramString1, a.l.toString(), paramc.a(), "first_name", paramString2, "last_name", paramString3, "source", paramb.toString(), 
          "marketing_opt_in", Boolean.toString(paramBoolean), "device_info", W(), "anew", "true" });
    if (paramString4 != null) {
      arrayList.add("recaptcha_v2_response");
      arrayList.add(paramString4);
    } 
    if (paramString5 != null) {
      arrayList.add("android_integrity_token");
      arrayList.add(paramString5);
    } 
    String[] arrayOfString = new String[arrayList.size()];
    arrayList.toArray(arrayOfString);
    i i = U("/api_account", arrayOfString);
    try {
      return (u)u.k.a(i);
    } catch (JsonExtractionException jsonExtractionException) {
      throw new RuntimeException(jsonExtractionException);
    } 
  }
  
  public u q(String paramString, NoAuthApi.b paramb, boolean paramBoolean) throws DropboxException {
    p.d(t.C(paramString) ^ true);
    p.o(paramb);
    i i = U("/api_google_signup", new String[] { "source", paramb.toString(), "marketing_opt_in", Boolean.toString(paramBoolean), "encrypted_google_data", paramString, "device_info", W() });
    try {
      return (u)u.k.a(i);
    } catch (JsonExtractionException jsonExtractionException) {
      throw new RuntimeException(jsonExtractionException);
    } 
  }
  
  public u r(c paramc, String paramString) throws DropboxException {
    i i = U("/api_login", new String[] { "password", paramc.a(), "apple_checkpoint_token", paramString, "device_info", W() });
    try {
      return (u)u.k.a(i);
    } catch (JsonExtractionException jsonExtractionException) {
      throw new RuntimeException(jsonExtractionException);
    } 
  }
  
  public u t(c paramc, String paramString1, String paramString2) throws DropboxException {
    i i = U("/api_login", new String[] { "email", paramString2, "password", paramc.a(), "google_checkpoint_token", paramString1, "device_info", W() });
    try {
      return (u)u.k.a(i);
    } catch (JsonExtractionException jsonExtractionException) {
      throw new RuntimeException(jsonExtractionException);
    } 
  }
  
  public u u(dbxyzptlk.Nk.b paramb, String paramString) throws DbxException {
    d d = paramb.h().b(paramString, W());
    return d.a() ? new u(d.c()) : new u(d.b());
  }
  
  public InputStream x(SharedLinkPath paramSharedLinkPath, m<c> paramm, int paramInt) throws DropboxException {
    return (InputStream)this.a.l(paramSharedLinkPath, paramm, paramInt);
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\dropbox\internalclient\b.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */