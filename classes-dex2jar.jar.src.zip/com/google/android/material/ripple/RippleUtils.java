package com.google.android.material.ripple;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.StateSet;
import dbxyzptlk.Y1.d;
import io.sentry.android.core.r0;

public class RippleUtils {
  private static final int[] ENABLED_PRESSED_STATE_SET;
  
  private static final int[] FOCUSED_STATE_SET;
  
  private static final int[] HOVERED_FOCUSED_STATE_SET;
  
  private static final int[] HOVERED_STATE_SET;
  
  static final String LOG_TAG;
  
  private static final int[] PRESSED_STATE_SET;
  
  private static final int[] SELECTED_FOCUSED_STATE_SET;
  
  private static final int[] SELECTED_HOVERED_FOCUSED_STATE_SET;
  
  private static final int[] SELECTED_HOVERED_STATE_SET;
  
  private static final int[] SELECTED_PRESSED_STATE_SET;
  
  private static final int[] SELECTED_STATE_SET;
  
  static final String TRANSPARENT_DEFAULT_COLOR_WARNING = "Use a non-transparent color for the default color as it will be used to finish ripple animations.";
  
  public static final boolean USE_FRAMEWORK_RIPPLE = true;
  
  static {
    PRESSED_STATE_SET = new int[] { 16842919 };
    HOVERED_FOCUSED_STATE_SET = new int[] { 16843623, 16842908 };
    FOCUSED_STATE_SET = new int[] { 16842908 };
    HOVERED_STATE_SET = new int[] { 16843623 };
    SELECTED_PRESSED_STATE_SET = new int[] { 16842913, 16842919 };
    SELECTED_HOVERED_FOCUSED_STATE_SET = new int[] { 16842913, 16843623, 16842908 };
    SELECTED_FOCUSED_STATE_SET = new int[] { 16842913, 16842908 };
    SELECTED_HOVERED_STATE_SET = new int[] { 16842913, 16843623 };
    SELECTED_STATE_SET = new int[] { 16842913 };
    ENABLED_PRESSED_STATE_SET = new int[] { 16842910, 16842919 };
    LOG_TAG = RippleUtils.class.getSimpleName();
  }
  
  public static ColorStateList convertToRippleDrawableColor(ColorStateList paramColorStateList) {
    if (USE_FRAMEWORK_RIPPLE) {
      int[] arrayOfInt10 = SELECTED_STATE_SET;
      int i4 = getColorForState(paramColorStateList, SELECTED_PRESSED_STATE_SET);
      int[] arrayOfInt12 = FOCUSED_STATE_SET;
      int i5 = getColorForState(paramColorStateList, arrayOfInt12);
      int[] arrayOfInt11 = StateSet.NOTHING;
      int i6 = getColorForState(paramColorStateList, PRESSED_STATE_SET);
      return new ColorStateList(new int[][] { arrayOfInt10, arrayOfInt12, arrayOfInt11 }, new int[] { i4, i5, i6 });
    } 
    int[] arrayOfInt9 = SELECTED_PRESSED_STATE_SET;
    int k = getColorForState(paramColorStateList, arrayOfInt9);
    int[] arrayOfInt8 = SELECTED_HOVERED_FOCUSED_STATE_SET;
    int i1 = getColorForState(paramColorStateList, arrayOfInt8);
    int[] arrayOfInt7 = SELECTED_FOCUSED_STATE_SET;
    int i2 = getColorForState(paramColorStateList, arrayOfInt7);
    int[] arrayOfInt6 = SELECTED_HOVERED_STATE_SET;
    int m = getColorForState(paramColorStateList, arrayOfInt6);
    int[] arrayOfInt4 = SELECTED_STATE_SET;
    int[] arrayOfInt5 = PRESSED_STATE_SET;
    int i3 = getColorForState(paramColorStateList, arrayOfInt5);
    int[] arrayOfInt2 = HOVERED_FOCUSED_STATE_SET;
    int n = getColorForState(paramColorStateList, arrayOfInt2);
    int[] arrayOfInt3 = FOCUSED_STATE_SET;
    int i = getColorForState(paramColorStateList, arrayOfInt3);
    int[] arrayOfInt1 = HOVERED_STATE_SET;
    int j = getColorForState(paramColorStateList, arrayOfInt1);
    return new ColorStateList(new int[][] { arrayOfInt9, arrayOfInt8, arrayOfInt7, arrayOfInt6, arrayOfInt4, arrayOfInt5, arrayOfInt2, arrayOfInt3, arrayOfInt1, StateSet.NOTHING }, new int[] { k, i1, i2, m, 0, i3, n, i, j, 0 });
  }
  
  public static Drawable createOvalRippleLollipop(Context paramContext, int paramInt) {
    return RippleUtilsLollipop.access$000(paramContext, paramInt);
  }
  
  @TargetApi(21)
  private static int doubleAlpha(int paramInt) {
    return d.v(paramInt, Math.min(Color.alpha(paramInt) * 2, 255));
  }
  
  private static int getColorForState(ColorStateList paramColorStateList, int[] paramArrayOfint) {
    byte b;
    if (paramColorStateList != null) {
      b = paramColorStateList.getColorForState(paramArrayOfint, paramColorStateList.getDefaultColor());
    } else {
      b = 0;
    } 
    int i = b;
    if (USE_FRAMEWORK_RIPPLE)
      i = doubleAlpha(b); 
    return i;
  }
  
  public static ColorStateList sanitizeRippleDrawableColor(ColorStateList paramColorStateList) {
    if (paramColorStateList != null) {
      if (Build.VERSION.SDK_INT <= 27 && Color.alpha(paramColorStateList.getDefaultColor()) == 0 && Color.alpha(paramColorStateList.getColorForState(ENABLED_PRESSED_STATE_SET, 0)) != 0)
        r0.f(LOG_TAG, "Use a non-transparent color for the default color as it will be used to finish ripple animations."); 
      return paramColorStateList;
    } 
    return ColorStateList.valueOf(0);
  }
  
  public static boolean shouldDrawRippleCompat(int[] paramArrayOfint) {
    // Byte code:
    //   0: aload_0
    //   1: arraylength
    //   2: istore #5
    //   4: iconst_0
    //   5: istore #8
    //   7: iconst_0
    //   8: istore_3
    //   9: iconst_0
    //   10: istore_2
    //   11: iload_2
    //   12: istore_1
    //   13: iload_3
    //   14: iload #5
    //   16: if_icmpge -> 84
    //   19: aload_0
    //   20: iload_3
    //   21: iaload
    //   22: istore #6
    //   24: iload #6
    //   26: ldc 16842910
    //   28: if_icmpne -> 37
    //   31: iconst_1
    //   32: istore #4
    //   34: goto -> 75
    //   37: iload #6
    //   39: ldc 16842908
    //   41: if_icmpne -> 52
    //   44: iconst_1
    //   45: istore_1
    //   46: iload_2
    //   47: istore #4
    //   49: goto -> 75
    //   52: iload #6
    //   54: ldc 16842919
    //   56: if_icmpne -> 62
    //   59: goto -> 44
    //   62: iload_2
    //   63: istore #4
    //   65: iload #6
    //   67: ldc 16843623
    //   69: if_icmpne -> 75
    //   72: goto -> 44
    //   75: iinc #3, 1
    //   78: iload #4
    //   80: istore_2
    //   81: goto -> 13
    //   84: iload #8
    //   86: istore #7
    //   88: iload_2
    //   89: ifeq -> 103
    //   92: iload #8
    //   94: istore #7
    //   96: iload_1
    //   97: ifeq -> 103
    //   100: iconst_1
    //   101: istore #7
    //   103: iload #7
    //   105: ireturn
  }
  
  class RippleUtils {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\google\android\material\ripple\RippleUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */