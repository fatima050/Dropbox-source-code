package com.google.android.material.internal;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.ColorDrawable;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewTreeObserver;
import android.view.inputmethod.InputMethodManager;
import com.google.android.material.R;
import dbxyzptlk.V1.b;
import dbxyzptlk.h2.J0;
import dbxyzptlk.h2.O;
import dbxyzptlk.h2.h0;
import dbxyzptlk.h2.k1;
import dbxyzptlk.mC.b;
import java.util.ArrayList;
import java.util.List;

public class ViewUtils {
  public static final int EDGE_TO_EDGE_FLAGS = 768;
  
  public static void addOnGlobalLayoutListener(View paramView, ViewTreeObserver.OnGlobalLayoutListener paramOnGlobalLayoutListener) {
    if (paramView != null)
      paramView.getViewTreeObserver().addOnGlobalLayoutListener(paramOnGlobalLayoutListener); 
  }
  
  public static Rect calculateOffsetRectFromBounds(View paramView1, View paramView2) {
    int[] arrayOfInt = new int[2];
    paramView2.getLocationOnScreen(arrayOfInt);
    int m = arrayOfInt[0];
    int j = arrayOfInt[1];
    arrayOfInt = new int[2];
    paramView1.getLocationOnScreen(arrayOfInt);
    int k = arrayOfInt[0];
    int i = arrayOfInt[1];
    k = m - k;
    i = j - i;
    return new Rect(k, i, paramView2.getWidth() + k, paramView2.getHeight() + i);
  }
  
  public static Rect calculateRectFromBounds(View paramView) {
    return calculateRectFromBounds(paramView, 0);
  }
  
  public static Rect calculateRectFromBounds(View paramView, int paramInt) {
    return new Rect(paramView.getLeft(), paramView.getTop() + paramInt, paramView.getRight(), paramView.getBottom() + paramInt);
  }
  
  public static void doOnApplyWindowInsets(View paramView, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    doOnApplyWindowInsets(paramView, paramAttributeSet, paramInt1, paramInt2, null);
  }
  
  public static void doOnApplyWindowInsets(View paramView, AttributeSet paramAttributeSet, int paramInt1, int paramInt2, OnApplyWindowInsetsListener paramOnApplyWindowInsetsListener) {
    TypedArray typedArray = paramView.getContext().obtainStyledAttributes(paramAttributeSet, R.styleable.Insets, paramInt1, paramInt2);
    boolean bool3 = typedArray.getBoolean(R.styleable.Insets_paddingBottomSystemWindowInsets, false);
    boolean bool1 = typedArray.getBoolean(R.styleable.Insets_paddingLeftSystemWindowInsets, false);
    boolean bool2 = typedArray.getBoolean(R.styleable.Insets_paddingRightSystemWindowInsets, false);
    typedArray.recycle();
    doOnApplyWindowInsets(paramView, (OnApplyWindowInsetsListener)new Object(bool3, bool1, bool2, paramOnApplyWindowInsetsListener));
  }
  
  public static void doOnApplyWindowInsets(View paramView, OnApplyWindowInsetsListener paramOnApplyWindowInsetsListener) {
    h0.G0(paramView, (O)new Object(paramOnApplyWindowInsetsListener, new RelativePadding(h0.F(paramView), paramView.getPaddingTop(), h0.E(paramView), paramView.getPaddingBottom())));
    requestApplyInsetsWhenAttached(paramView);
  }
  
  public static float dpToPx(Context paramContext, int paramInt) {
    Resources resources = paramContext.getResources();
    return TypedValue.applyDimension(1, paramInt, resources.getDisplayMetrics());
  }
  
  public static Integer getBackgroundColor(View paramView) {
    if (paramView.getBackground() instanceof ColorDrawable) {
      Integer integer = Integer.valueOf(((ColorDrawable)paramView.getBackground()).getColor());
    } else {
      paramView = null;
    } 
    return (Integer)paramView;
  }
  
  public static List<View> getChildren(View paramView) {
    ArrayList<View> arrayList = new ArrayList();
    if (paramView instanceof ViewGroup) {
      ViewGroup viewGroup = (ViewGroup)paramView;
      for (byte b = 0; b < viewGroup.getChildCount(); b++)
        arrayList.add(viewGroup.getChildAt(b)); 
    } 
    return arrayList;
  }
  
  public static ViewGroup getContentView(View paramView) {
    if (paramView == null)
      return null; 
    View view = paramView.getRootView();
    ViewGroup viewGroup = (ViewGroup)view.findViewById(16908290);
    return (viewGroup != null) ? viewGroup : ((view != paramView && view instanceof ViewGroup) ? (ViewGroup)view : null);
  }
  
  public static ViewOverlayImpl getContentViewOverlay(View paramView) {
    return getOverlay((View)getContentView(paramView));
  }
  
  private static InputMethodManager getInputMethodManager(View paramView) {
    return (InputMethodManager)b.j(paramView.getContext(), InputMethodManager.class);
  }
  
  public static ViewOverlayImpl getOverlay(View paramView) {
    return (ViewOverlayImpl)((paramView == null) ? null : new ViewOverlayApi18(paramView));
  }
  
  public static float getParentAbsoluteElevation(View paramView) {
    ViewParent viewParent = paramView.getParent();
    float f = 0.0F;
    while (viewParent instanceof View) {
      f += h0.v((View)viewParent);
      viewParent = viewParent.getParent();
    } 
    return f;
  }
  
  public static void hideKeyboard(View paramView) {
    hideKeyboard(paramView, true);
  }
  
  public static void hideKeyboard(View paramView, boolean paramBoolean) {
    if (paramBoolean) {
      k1 k1 = h0.M(paramView);
      if (k1 != null) {
        k1.a(J0.m.c());
        return;
      } 
    } 
    InputMethodManager inputMethodManager = getInputMethodManager(paramView);
    if (inputMethodManager != null)
      inputMethodManager.hideSoftInputFromWindow(paramView.getWindowToken(), 0); 
  }
  
  public static boolean isLayoutRtl(View paramView) {
    int i = h0.A(paramView);
    boolean bool = true;
    if (i != 1)
      bool = false; 
    return bool;
  }
  
  public static PorterDuff.Mode parseTintMode(int paramInt, PorterDuff.Mode paramMode) {
    if (paramInt != 3) {
      if (paramInt != 5) {
        if (paramInt != 9) {
          switch (paramInt) {
            default:
              return paramMode;
            case 16:
              return PorterDuff.Mode.ADD;
            case 15:
              return PorterDuff.Mode.SCREEN;
            case 14:
              break;
          } 
          return PorterDuff.Mode.MULTIPLY;
        } 
        return PorterDuff.Mode.SRC_ATOP;
      } 
      return PorterDuff.Mode.SRC_IN;
    } 
    return PorterDuff.Mode.SRC_OVER;
  }
  
  public static void removeOnGlobalLayoutListener(View paramView, ViewTreeObserver.OnGlobalLayoutListener paramOnGlobalLayoutListener) {
    if (paramView != null)
      removeOnGlobalLayoutListener(paramView.getViewTreeObserver(), paramOnGlobalLayoutListener); 
  }
  
  public static void removeOnGlobalLayoutListener(ViewTreeObserver paramViewTreeObserver, ViewTreeObserver.OnGlobalLayoutListener paramOnGlobalLayoutListener) {
    paramViewTreeObserver.removeOnGlobalLayoutListener(paramOnGlobalLayoutListener);
  }
  
  public static void requestApplyInsetsWhenAttached(View paramView) {
    if (h0.T(paramView)) {
      h0.n0(paramView);
    } else {
      paramView.addOnAttachStateChangeListener((View.OnAttachStateChangeListener)new Object());
    } 
  }
  
  public static void requestFocusAndShowKeyboard(View paramView) {
    requestFocusAndShowKeyboard(paramView, true);
  }
  
  public static void requestFocusAndShowKeyboard(View paramView, boolean paramBoolean) {
    paramView.requestFocus();
    paramView.post((Runnable)new b(paramView, paramBoolean));
  }
  
  public static void setBoundsFromRect(View paramView, Rect paramRect) {
    paramView.setLeft(paramRect.left);
    paramView.setTop(paramRect.top);
    paramView.setRight(paramRect.right);
    paramView.setBottom(paramRect.bottom);
  }
  
  public static void showKeyboard(View paramView) {
    showKeyboard(paramView, true);
  }
  
  public static void showKeyboard(View paramView, boolean paramBoolean) {
    if (paramBoolean) {
      k1 k1 = h0.M(paramView);
      if (k1 != null) {
        k1.f(J0.m.c());
        return;
      } 
    } 
    getInputMethodManager(paramView).showSoftInput(paramView, 1);
  }
  
  class ViewUtils {}
  
  class ViewUtils {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\google\android\material\internal\ViewUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */