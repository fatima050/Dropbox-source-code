package com.google.android.material.shape;

import android.graphics.RectF;

public interface CornerSize {
  float getCornerSize(RectF paramRectF);
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\google\android\material\shape\CornerSize.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */