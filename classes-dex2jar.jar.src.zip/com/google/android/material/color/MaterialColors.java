package com.google.android.material.color;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.util.TypedValue;
import android.view.View;
import com.google.android.material.R;
import com.google.android.material.color.utilities.Blend;
import com.google.android.material.color.utilities.Hct;
import com.google.android.material.resources.MaterialAttributes;
import dbxyzptlk.V1.b;
import dbxyzptlk.Y1.d;

public class MaterialColors {
  public static final float ALPHA_DISABLED = 0.38F;
  
  public static final float ALPHA_DISABLED_LOW = 0.12F;
  
  public static final float ALPHA_FULL = 1.0F;
  
  public static final float ALPHA_LOW = 0.32F;
  
  public static final float ALPHA_MEDIUM = 0.54F;
  
  private static final int CHROMA_NEUTRAL = 6;
  
  private static final int TONE_ACCENT_CONTAINER_DARK = 30;
  
  private static final int TONE_ACCENT_CONTAINER_LIGHT = 90;
  
  private static final int TONE_ACCENT_DARK = 80;
  
  private static final int TONE_ACCENT_LIGHT = 40;
  
  private static final int TONE_ON_ACCENT_CONTAINER_DARK = 90;
  
  private static final int TONE_ON_ACCENT_CONTAINER_LIGHT = 10;
  
  private static final int TONE_ON_ACCENT_DARK = 20;
  
  private static final int TONE_ON_ACCENT_LIGHT = 100;
  
  private static final int TONE_SURFACE_CONTAINER_DARK = 12;
  
  private static final int TONE_SURFACE_CONTAINER_HIGH_DARK = 17;
  
  private static final int TONE_SURFACE_CONTAINER_HIGH_LIGHT = 92;
  
  private static final int TONE_SURFACE_CONTAINER_LIGHT = 94;
  
  public static int compositeARGBWithAlpha(int paramInt1, int paramInt2) {
    return d.v(paramInt1, Color.alpha(paramInt1) * paramInt2 / 255);
  }
  
  public static int getColor(Context paramContext, int paramInt1, int paramInt2) {
    TypedValue typedValue = MaterialAttributes.resolve(paramContext, paramInt1);
    return (typedValue != null) ? resolveColor(paramContext, typedValue) : paramInt2;
  }
  
  public static int getColor(Context paramContext, int paramInt, String paramString) {
    return resolveColor(paramContext, MaterialAttributes.resolveTypedValueOrThrow(paramContext, paramInt, paramString));
  }
  
  public static int getColor(View paramView, int paramInt) {
    return resolveColor(paramView.getContext(), MaterialAttributes.resolveTypedValueOrThrow(paramView, paramInt));
  }
  
  public static int getColor(View paramView, int paramInt1, int paramInt2) {
    return getColor(paramView.getContext(), paramInt1, paramInt2);
  }
  
  private static int getColorRole(int paramInt1, int paramInt2) {
    Hct hct = Hct.fromInt(paramInt1);
    hct.setTone(paramInt2);
    return hct.toInt();
  }
  
  private static int getColorRole(int paramInt1, int paramInt2, int paramInt3) {
    Hct hct = Hct.fromInt(getColorRole(paramInt1, paramInt2));
    hct.setChroma(paramInt3);
    return hct.toInt();
  }
  
  public static ColorRoles getColorRoles(int paramInt, boolean paramBoolean) {
    ColorRoles colorRoles;
    if (paramBoolean) {
      colorRoles = new ColorRoles(getColorRole(paramInt, 40), getColorRole(paramInt, 100), getColorRole(paramInt, 90), getColorRole(paramInt, 10));
    } else {
      colorRoles = new ColorRoles(getColorRole(paramInt, 80), getColorRole(paramInt, 20), getColorRole(paramInt, 30), getColorRole(paramInt, 90));
    } 
    return colorRoles;
  }
  
  public static ColorRoles getColorRoles(Context paramContext, int paramInt) {
    return getColorRoles(paramInt, isLightTheme(paramContext));
  }
  
  public static ColorStateList getColorStateList(Context paramContext, int paramInt, ColorStateList paramColorStateList) {
    Context context;
    TypedValue typedValue = MaterialAttributes.resolve(paramContext, paramInt);
    if (typedValue != null) {
      ColorStateList colorStateList = resolveColorStateList(paramContext, typedValue);
    } else {
      paramContext = null;
    } 
    if (paramContext != null)
      context = paramContext; 
    return (ColorStateList)context;
  }
  
  public static ColorStateList getColorStateListOrNull(Context paramContext, int paramInt) {
    TypedValue typedValue = MaterialAttributes.resolve(paramContext, paramInt);
    if (typedValue == null)
      return null; 
    paramInt = typedValue.resourceId;
    if (paramInt != 0)
      return b.d(paramContext, paramInt); 
    paramInt = typedValue.data;
    return (paramInt != 0) ? ColorStateList.valueOf(paramInt) : null;
  }
  
  public static int getSurfaceContainerFromSeed(Context paramContext, int paramInt) {
    byte b;
    if (isLightTheme(paramContext)) {
      b = 94;
    } else {
      b = 12;
    } 
    return getColorRole(paramInt, b, 6);
  }
  
  public static int getSurfaceContainerHighFromSeed(Context paramContext, int paramInt) {
    byte b;
    if (isLightTheme(paramContext)) {
      b = 92;
    } else {
      b = 17;
    } 
    return getColorRole(paramInt, b, 6);
  }
  
  public static int harmonize(int paramInt1, int paramInt2) {
    return Blend.harmonize(paramInt1, paramInt2);
  }
  
  public static int harmonizeWithPrimary(Context paramContext, int paramInt) {
    return harmonize(paramInt, getColor(paramContext, R.attr.colorPrimary, MaterialColors.class.getCanonicalName()));
  }
  
  public static boolean isColorLight(int paramInt) {
    boolean bool;
    if (paramInt != 0 && d.k(paramInt) > 0.5D) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public static boolean isLightTheme(Context paramContext) {
    return MaterialAttributes.resolveBoolean(paramContext, R.attr.isLightTheme, true);
  }
  
  public static int layer(int paramInt1, int paramInt2) {
    return d.p(paramInt2, paramInt1);
  }
  
  public static int layer(int paramInt1, int paramInt2, float paramFloat) {
    return layer(paramInt1, d.v(paramInt2, Math.round(Color.alpha(paramInt2) * paramFloat)));
  }
  
  public static int layer(View paramView, int paramInt1, int paramInt2) {
    return layer(paramView, paramInt1, paramInt2, 1.0F);
  }
  
  public static int layer(View paramView, int paramInt1, int paramInt2, float paramFloat) {
    return layer(getColor(paramView, paramInt1), getColor(paramView, paramInt2), paramFloat);
  }
  
  private static int resolveColor(Context paramContext, TypedValue paramTypedValue) {
    int i = paramTypedValue.resourceId;
    return (i != 0) ? b.c(paramContext, i) : paramTypedValue.data;
  }
  
  private static ColorStateList resolveColorStateList(Context paramContext, TypedValue paramTypedValue) {
    int i = paramTypedValue.resourceId;
    return (i != 0) ? b.d(paramContext, i) : ColorStateList.valueOf(paramTypedValue.data);
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\google\android\material\color\MaterialColors.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */