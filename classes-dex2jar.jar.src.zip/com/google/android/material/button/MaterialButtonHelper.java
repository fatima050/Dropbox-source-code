package com.google.android.material.button;

import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.InsetDrawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.RippleDrawable;
import android.view.View;
import com.google.android.material.R;
import com.google.android.material.color.MaterialColors;
import com.google.android.material.internal.ViewUtils;
import com.google.android.material.resources.MaterialResources;
import com.google.android.material.ripple.RippleDrawableCompat;
import com.google.android.material.ripple.RippleUtils;
import com.google.android.material.shape.MaterialShapeDrawable;
import com.google.android.material.shape.ShapeAppearanceModel;
import com.google.android.material.shape.Shapeable;
import dbxyzptlk.Z1.a;
import dbxyzptlk.h2.h0;

class MaterialButtonHelper {
  private static final boolean IS_LOLLIPOP;
  
  private static final boolean IS_MIN_LOLLIPOP = true;
  
  private boolean backgroundOverwritten = false;
  
  private ColorStateList backgroundTint;
  
  private PorterDuff.Mode backgroundTintMode;
  
  private boolean checkable;
  
  private int cornerRadius;
  
  private boolean cornerRadiusSet = false;
  
  private int elevation;
  
  private int insetBottom;
  
  private int insetLeft;
  
  private int insetRight;
  
  private int insetTop;
  
  private Drawable maskDrawable;
  
  private final MaterialButton materialButton;
  
  private ColorStateList rippleColor;
  
  private LayerDrawable rippleDrawable;
  
  private ShapeAppearanceModel shapeAppearanceModel;
  
  private boolean shouldDrawSurfaceColorStroke = false;
  
  private ColorStateList strokeColor;
  
  private int strokeWidth;
  
  private boolean toggleCheckedStateOnClick = true;
  
  static {
    IS_LOLLIPOP = false;
  }
  
  public MaterialButtonHelper(MaterialButton paramMaterialButton, ShapeAppearanceModel paramShapeAppearanceModel) {
    this.materialButton = paramMaterialButton;
    this.shapeAppearanceModel = paramShapeAppearanceModel;
  }
  
  private Drawable createBackground() {
    boolean bool;
    RippleDrawable rippleDrawable;
    MaterialShapeDrawable materialShapeDrawable1 = new MaterialShapeDrawable(this.shapeAppearanceModel);
    materialShapeDrawable1.initializeElevationOverlay(this.materialButton.getContext());
    a.o((Drawable)materialShapeDrawable1, this.backgroundTint);
    PorterDuff.Mode mode = this.backgroundTintMode;
    if (mode != null)
      a.p((Drawable)materialShapeDrawable1, mode); 
    materialShapeDrawable1.setStroke(this.strokeWidth, this.strokeColor);
    MaterialShapeDrawable materialShapeDrawable2 = new MaterialShapeDrawable(this.shapeAppearanceModel);
    materialShapeDrawable2.setTint(0);
    float f = this.strokeWidth;
    if (this.shouldDrawSurfaceColorStroke) {
      bool = MaterialColors.getColor((View)this.materialButton, R.attr.colorSurface);
    } else {
      bool = false;
    } 
    materialShapeDrawable2.setStroke(f, bool);
    if (IS_MIN_LOLLIPOP) {
      MaterialShapeDrawable materialShapeDrawable = new MaterialShapeDrawable(this.shapeAppearanceModel);
      this.maskDrawable = (Drawable)materialShapeDrawable;
      a.n((Drawable)materialShapeDrawable, -1);
      rippleDrawable = new RippleDrawable(RippleUtils.sanitizeRippleDrawableColor(this.rippleColor), (Drawable)wrapDrawableWithInset((Drawable)new LayerDrawable(new Drawable[] { (Drawable)materialShapeDrawable2, (Drawable)materialShapeDrawable1 }, )), this.maskDrawable);
      this.rippleDrawable = (LayerDrawable)rippleDrawable;
      return (Drawable)rippleDrawable;
    } 
    RippleDrawableCompat rippleDrawableCompat = new RippleDrawableCompat(this.shapeAppearanceModel);
    this.maskDrawable = (Drawable)rippleDrawableCompat;
    a.o((Drawable)rippleDrawableCompat, RippleUtils.sanitizeRippleDrawableColor(this.rippleColor));
    LayerDrawable layerDrawable = new LayerDrawable(new Drawable[] { (Drawable)materialShapeDrawable2, (Drawable)rippleDrawable, this.maskDrawable });
    this.rippleDrawable = layerDrawable;
    return (Drawable)wrapDrawableWithInset((Drawable)layerDrawable);
  }
  
  private MaterialShapeDrawable getMaterialShapeDrawable(boolean paramBoolean) {
    LayerDrawable layerDrawable = this.rippleDrawable;
    return (layerDrawable != null && layerDrawable.getNumberOfLayers() > 0) ? (IS_MIN_LOLLIPOP ? (MaterialShapeDrawable)((LayerDrawable)((InsetDrawable)this.rippleDrawable.getDrawable(0)).getDrawable()).getDrawable(paramBoolean ^ true) : (MaterialShapeDrawable)this.rippleDrawable.getDrawable(paramBoolean ^ true)) : null;
  }
  
  private MaterialShapeDrawable getSurfaceColorStrokeDrawable() {
    return getMaterialShapeDrawable(true);
  }
  
  private void setVerticalInsets(int paramInt1, int paramInt2) {
    int i = h0.F((View)this.materialButton);
    int i1 = this.materialButton.getPaddingTop();
    int n = h0.E((View)this.materialButton);
    int m = this.materialButton.getPaddingBottom();
    int j = this.insetTop;
    int k = this.insetBottom;
    this.insetBottom = paramInt2;
    this.insetTop = paramInt1;
    if (!this.backgroundOverwritten)
      updateBackground(); 
    h0.I0((View)this.materialButton, i, i1 + paramInt1 - j, n, m + paramInt2 - k);
  }
  
  private void updateBackground() {
    this.materialButton.setInternalBackground(createBackground());
    MaterialShapeDrawable materialShapeDrawable = getMaterialShapeDrawable();
    if (materialShapeDrawable != null) {
      materialShapeDrawable.setElevation(this.elevation);
      materialShapeDrawable.setState(this.materialButton.getDrawableState());
    } 
  }
  
  private void updateButtonShape(ShapeAppearanceModel paramShapeAppearanceModel) {
    if (IS_LOLLIPOP && !this.backgroundOverwritten) {
      int j = h0.F((View)this.materialButton);
      int i = this.materialButton.getPaddingTop();
      int m = h0.E((View)this.materialButton);
      int k = this.materialButton.getPaddingBottom();
      updateBackground();
      h0.I0((View)this.materialButton, j, i, m, k);
    } else {
      if (getMaterialShapeDrawable() != null)
        getMaterialShapeDrawable().setShapeAppearanceModel(paramShapeAppearanceModel); 
      if (getSurfaceColorStrokeDrawable() != null)
        getSurfaceColorStrokeDrawable().setShapeAppearanceModel(paramShapeAppearanceModel); 
      if (getMaskDrawable() != null)
        getMaskDrawable().setShapeAppearanceModel(paramShapeAppearanceModel); 
    } 
  }
  
  private void updateStroke() {
    MaterialShapeDrawable materialShapeDrawable1 = getMaterialShapeDrawable();
    MaterialShapeDrawable materialShapeDrawable2 = getSurfaceColorStrokeDrawable();
    if (materialShapeDrawable1 != null) {
      materialShapeDrawable1.setStroke(this.strokeWidth, this.strokeColor);
      if (materialShapeDrawable2 != null) {
        boolean bool;
        float f = this.strokeWidth;
        if (this.shouldDrawSurfaceColorStroke) {
          bool = MaterialColors.getColor((View)this.materialButton, R.attr.colorSurface);
        } else {
          bool = false;
        } 
        materialShapeDrawable2.setStroke(f, bool);
      } 
    } 
  }
  
  private InsetDrawable wrapDrawableWithInset(Drawable paramDrawable) {
    return new InsetDrawable(paramDrawable, this.insetLeft, this.insetTop, this.insetRight, this.insetBottom);
  }
  
  public int getCornerRadius() {
    return this.cornerRadius;
  }
  
  public int getInsetBottom() {
    return this.insetBottom;
  }
  
  public int getInsetTop() {
    return this.insetTop;
  }
  
  public Shapeable getMaskDrawable() {
    LayerDrawable layerDrawable = this.rippleDrawable;
    return (layerDrawable != null && layerDrawable.getNumberOfLayers() > 1) ? ((this.rippleDrawable.getNumberOfLayers() > 2) ? (Shapeable)this.rippleDrawable.getDrawable(2) : (Shapeable)this.rippleDrawable.getDrawable(1)) : null;
  }
  
  public MaterialShapeDrawable getMaterialShapeDrawable() {
    return getMaterialShapeDrawable(false);
  }
  
  public ColorStateList getRippleColor() {
    return this.rippleColor;
  }
  
  public ShapeAppearanceModel getShapeAppearanceModel() {
    return this.shapeAppearanceModel;
  }
  
  public ColorStateList getStrokeColor() {
    return this.strokeColor;
  }
  
  public int getStrokeWidth() {
    return this.strokeWidth;
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    return this.backgroundTint;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    return this.backgroundTintMode;
  }
  
  public boolean isBackgroundOverwritten() {
    return this.backgroundOverwritten;
  }
  
  public boolean isCheckable() {
    return this.checkable;
  }
  
  public boolean isToggleCheckedStateOnClick() {
    return this.toggleCheckedStateOnClick;
  }
  
  public void loadFromAttributes(TypedArray paramTypedArray) {
    this.insetLeft = paramTypedArray.getDimensionPixelOffset(R.styleable.MaterialButton_android_insetLeft, 0);
    this.insetRight = paramTypedArray.getDimensionPixelOffset(R.styleable.MaterialButton_android_insetRight, 0);
    this.insetTop = paramTypedArray.getDimensionPixelOffset(R.styleable.MaterialButton_android_insetTop, 0);
    this.insetBottom = paramTypedArray.getDimensionPixelOffset(R.styleable.MaterialButton_android_insetBottom, 0);
    if (paramTypedArray.hasValue(R.styleable.MaterialButton_cornerRadius)) {
      int n = paramTypedArray.getDimensionPixelSize(R.styleable.MaterialButton_cornerRadius, -1);
      this.cornerRadius = n;
      setShapeAppearanceModel(this.shapeAppearanceModel.withCornerSize(n));
      this.cornerRadiusSet = true;
    } 
    this.strokeWidth = paramTypedArray.getDimensionPixelSize(R.styleable.MaterialButton_strokeWidth, 0);
    this.backgroundTintMode = ViewUtils.parseTintMode(paramTypedArray.getInt(R.styleable.MaterialButton_backgroundTintMode, -1), PorterDuff.Mode.SRC_IN);
    this.backgroundTint = MaterialResources.getColorStateList(this.materialButton.getContext(), paramTypedArray, R.styleable.MaterialButton_backgroundTint);
    this.strokeColor = MaterialResources.getColorStateList(this.materialButton.getContext(), paramTypedArray, R.styleable.MaterialButton_strokeColor);
    this.rippleColor = MaterialResources.getColorStateList(this.materialButton.getContext(), paramTypedArray, R.styleable.MaterialButton_rippleColor);
    this.checkable = paramTypedArray.getBoolean(R.styleable.MaterialButton_android_checkable, false);
    this.elevation = paramTypedArray.getDimensionPixelSize(R.styleable.MaterialButton_elevation, 0);
    this.toggleCheckedStateOnClick = paramTypedArray.getBoolean(R.styleable.MaterialButton_toggleCheckedStateOnClick, true);
    int j = h0.F((View)this.materialButton);
    int k = this.materialButton.getPaddingTop();
    int i = h0.E((View)this.materialButton);
    int m = this.materialButton.getPaddingBottom();
    if (paramTypedArray.hasValue(R.styleable.MaterialButton_android_background)) {
      setBackgroundOverwritten();
    } else {
      updateBackground();
    } 
    h0.I0((View)this.materialButton, j + this.insetLeft, k + this.insetTop, i + this.insetRight, m + this.insetBottom);
  }
  
  public void setBackgroundColor(int paramInt) {
    if (getMaterialShapeDrawable() != null)
      getMaterialShapeDrawable().setTint(paramInt); 
  }
  
  public void setBackgroundOverwritten() {
    this.backgroundOverwritten = true;
    this.materialButton.setSupportBackgroundTintList(this.backgroundTint);
    this.materialButton.setSupportBackgroundTintMode(this.backgroundTintMode);
  }
  
  public void setCheckable(boolean paramBoolean) {
    this.checkable = paramBoolean;
  }
  
  public void setCornerRadius(int paramInt) {
    if (!this.cornerRadiusSet || this.cornerRadius != paramInt) {
      this.cornerRadius = paramInt;
      this.cornerRadiusSet = true;
      setShapeAppearanceModel(this.shapeAppearanceModel.withCornerSize(paramInt));
    } 
  }
  
  public void setInsetBottom(int paramInt) {
    setVerticalInsets(this.insetTop, paramInt);
  }
  
  public void setInsetTop(int paramInt) {
    setVerticalInsets(paramInt, this.insetBottom);
  }
  
  public void setRippleColor(ColorStateList paramColorStateList) {
    if (this.rippleColor != paramColorStateList) {
      this.rippleColor = paramColorStateList;
      boolean bool = IS_MIN_LOLLIPOP;
      if (bool && this.materialButton.getBackground() instanceof RippleDrawable) {
        ((RippleDrawable)this.materialButton.getBackground()).setColor(RippleUtils.sanitizeRippleDrawableColor(paramColorStateList));
      } else if (!bool && this.materialButton.getBackground() instanceof RippleDrawableCompat) {
        ((RippleDrawableCompat)this.materialButton.getBackground()).setTintList(RippleUtils.sanitizeRippleDrawableColor(paramColorStateList));
      } 
    } 
  }
  
  public void setShapeAppearanceModel(ShapeAppearanceModel paramShapeAppearanceModel) {
    this.shapeAppearanceModel = paramShapeAppearanceModel;
    updateButtonShape(paramShapeAppearanceModel);
  }
  
  public void setShouldDrawSurfaceColorStroke(boolean paramBoolean) {
    this.shouldDrawSurfaceColorStroke = paramBoolean;
    updateStroke();
  }
  
  public void setStrokeColor(ColorStateList paramColorStateList) {
    if (this.strokeColor != paramColorStateList) {
      this.strokeColor = paramColorStateList;
      updateStroke();
    } 
  }
  
  public void setStrokeWidth(int paramInt) {
    if (this.strokeWidth != paramInt) {
      this.strokeWidth = paramInt;
      updateStroke();
    } 
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    if (this.backgroundTint != paramColorStateList) {
      this.backgroundTint = paramColorStateList;
      if (getMaterialShapeDrawable() != null)
        a.o((Drawable)getMaterialShapeDrawable(), this.backgroundTint); 
    } 
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    if (this.backgroundTintMode != paramMode) {
      this.backgroundTintMode = paramMode;
      if (getMaterialShapeDrawable() != null && this.backgroundTintMode != null)
        a.p((Drawable)getMaterialShapeDrawable(), this.backgroundTintMode); 
    } 
  }
  
  public void setToggleCheckedStateOnClick(boolean paramBoolean) {
    this.toggleCheckedStateOnClick = paramBoolean;
  }
  
  public void updateMaskBounds(int paramInt1, int paramInt2) {
    Drawable drawable = this.maskDrawable;
    if (drawable != null)
      drawable.setBounds(this.insetLeft, this.insetTop, paramInt2 - this.insetRight, paramInt1 - this.insetBottom); 
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\google\android\material\button\MaterialButtonHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */