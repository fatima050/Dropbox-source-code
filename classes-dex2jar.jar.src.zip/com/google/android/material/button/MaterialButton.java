package com.google.android.material.button;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Parcelable;
import android.text.Layout;
import android.text.TextPaint;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;
import android.widget.Checkable;
import android.widget.CompoundButton;
import android.widget.TextView;
import androidx.appcompat.widget.AppCompatButton;
import com.google.android.material.R;
import com.google.android.material.internal.ThemeEnforcement;
import com.google.android.material.internal.ViewUtils;
import com.google.android.material.resources.MaterialResources;
import com.google.android.material.shape.MaterialShapeUtils;
import com.google.android.material.shape.ShapeAppearanceModel;
import com.google.android.material.shape.Shapeable;
import com.google.android.material.theme.overlay.MaterialThemeOverlay;
import dbxyzptlk.Z1.a;
import dbxyzptlk.h2.h0;
import dbxyzptlk.l.a;
import dbxyzptlk.n2.l;
import io.sentry.android.core.r0;
import java.util.Iterator;
import java.util.LinkedHashSet;

public class MaterialButton extends AppCompatButton implements Checkable, Shapeable {
  private static final int[] CHECKABLE_STATE_SET = new int[] { 16842911 };
  
  private static final int[] CHECKED_STATE_SET = new int[] { 16842912 };
  
  private static final int DEF_STYLE_RES = R.style.Widget_MaterialComponents_Button;
  
  public static final int ICON_GRAVITY_END = 3;
  
  public static final int ICON_GRAVITY_START = 1;
  
  public static final int ICON_GRAVITY_TEXT_END = 4;
  
  public static final int ICON_GRAVITY_TEXT_START = 2;
  
  public static final int ICON_GRAVITY_TEXT_TOP = 32;
  
  public static final int ICON_GRAVITY_TOP = 16;
  
  private static final String LOG_TAG = "MaterialButton";
  
  private String accessibilityClassName;
  
  private boolean broadcasting;
  
  private boolean checked;
  
  private Drawable icon;
  
  private int iconGravity;
  
  private int iconLeft;
  
  private int iconPadding;
  
  private int iconSize;
  
  private ColorStateList iconTint;
  
  private PorterDuff.Mode iconTintMode;
  
  private int iconTop;
  
  private final MaterialButtonHelper materialButtonHelper;
  
  private final LinkedHashSet<OnCheckedChangeListener> onCheckedChangeListeners = new LinkedHashSet<>();
  
  private OnPressedChangeListener onPressedChangeListenerInternal;
  
  public MaterialButton(Context paramContext) {
    this(paramContext, null);
  }
  
  public MaterialButton(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, R.attr.materialButtonStyle);
  }
  
  public MaterialButton(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(MaterialThemeOverlay.wrap(paramContext, paramAttributeSet, paramInt, i), paramAttributeSet, paramInt);
    boolean bool = false;
    this.checked = false;
    this.broadcasting = false;
    Context context = getContext();
    TypedArray typedArray = ThemeEnforcement.obtainStyledAttributes(context, paramAttributeSet, R.styleable.MaterialButton, paramInt, i, new int[0]);
    this.iconPadding = typedArray.getDimensionPixelSize(R.styleable.MaterialButton_iconPadding, 0);
    this.iconTintMode = ViewUtils.parseTintMode(typedArray.getInt(R.styleable.MaterialButton_iconTintMode, -1), PorterDuff.Mode.SRC_IN);
    this.iconTint = MaterialResources.getColorStateList(getContext(), typedArray, R.styleable.MaterialButton_iconTint);
    this.icon = MaterialResources.getDrawable(getContext(), typedArray, R.styleable.MaterialButton_icon);
    this.iconGravity = typedArray.getInteger(R.styleable.MaterialButton_iconGravity, 1);
    this.iconSize = typedArray.getDimensionPixelSize(R.styleable.MaterialButton_iconSize, 0);
    MaterialButtonHelper materialButtonHelper = new MaterialButtonHelper(this, ShapeAppearanceModel.builder(context, paramAttributeSet, paramInt, i).build());
    this.materialButtonHelper = materialButtonHelper;
    materialButtonHelper.loadFromAttributes(typedArray);
    typedArray.recycle();
    setCompoundDrawablePadding(this.iconPadding);
    if (this.icon != null)
      bool = true; 
    updateIcon(bool);
  }
  
  private Layout.Alignment getActualTextAlignment() {
    int i = getTextAlignment();
    return (i != 1) ? ((i != 6 && i != 3) ? ((i != 4) ? Layout.Alignment.ALIGN_NORMAL : Layout.Alignment.ALIGN_CENTER) : Layout.Alignment.ALIGN_OPPOSITE) : getGravityTextAlignment();
  }
  
  private Layout.Alignment getGravityTextAlignment() {
    int i = getGravity() & 0x800007;
    return (i != 1) ? ((i != 5 && i != 8388613) ? Layout.Alignment.ALIGN_NORMAL : Layout.Alignment.ALIGN_OPPOSITE) : Layout.Alignment.ALIGN_CENTER;
  }
  
  private int getTextHeight() {
    if (getLineCount() > 1)
      return getLayout().getHeight(); 
    TextPaint textPaint = getPaint();
    String str2 = getText().toString();
    String str1 = str2;
    if (getTransformationMethod() != null)
      str1 = getTransformationMethod().getTransformation(str2, (View)this).toString(); 
    Rect rect = new Rect();
    textPaint.getTextBounds(str1, 0, str1.length(), rect);
    return Math.min(rect.height(), getLayout().getHeight());
  }
  
  private int getTextLayoutWidth() {
    int i = getLineCount();
    float f = 0.0F;
    for (byte b = 0; b < i; b++)
      f = Math.max(f, getLayout().getLineWidth(b)); 
    return (int)Math.ceil(f);
  }
  
  private boolean isIconEnd() {
    int i = this.iconGravity;
    return (i == 3 || i == 4);
  }
  
  private boolean isIconStart() {
    int i = this.iconGravity;
    boolean bool2 = true;
    boolean bool1 = bool2;
    if (i != 1)
      if (i == 2) {
        bool1 = bool2;
      } else {
        bool1 = false;
      }  
    return bool1;
  }
  
  private boolean isIconTop() {
    int i = this.iconGravity;
    return (i == 16 || i == 32);
  }
  
  private boolean isLayoutRTL() {
    int i = h0.A((View)this);
    boolean bool = true;
    if (i != 1)
      bool = false; 
    return bool;
  }
  
  private boolean isUsingOriginalBackground() {
    boolean bool;
    MaterialButtonHelper materialButtonHelper = this.materialButtonHelper;
    if (materialButtonHelper != null && !materialButtonHelper.isBackgroundOverwritten()) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  private void resetIconDrawable() {
    if (isIconStart()) {
      l.k((TextView)this, this.icon, null, null, null);
    } else if (isIconEnd()) {
      l.k((TextView)this, null, null, this.icon, null);
    } else if (isIconTop()) {
      l.k((TextView)this, null, this.icon, null, null);
    } 
  }
  
  private void updateIcon(boolean paramBoolean) {
    Drawable drawable1 = this.icon;
    if (drawable1 != null) {
      drawable1 = a.r(drawable1).mutate();
      this.icon = drawable1;
      a.o(drawable1, this.iconTint);
      PorterDuff.Mode mode = this.iconTintMode;
      if (mode != null)
        a.p(this.icon, mode); 
      int i = this.iconSize;
      if (i == 0)
        i = this.icon.getIntrinsicWidth(); 
      int j = this.iconSize;
      if (j == 0)
        j = this.icon.getIntrinsicHeight(); 
      Drawable drawable = this.icon;
      int m = this.iconLeft;
      int k = this.iconTop;
      drawable.setBounds(m, k, i + m, j + k);
      this.icon.setVisible(true, paramBoolean);
    } 
    if (paramBoolean) {
      resetIconDrawable();
      return;
    } 
    Drawable[] arrayOfDrawable = l.a((TextView)this);
    Drawable drawable2 = arrayOfDrawable[0];
    drawable1 = arrayOfDrawable[1];
    Drawable drawable3 = arrayOfDrawable[2];
    if ((isIconStart() && drawable2 != this.icon) || (isIconEnd() && drawable3 != this.icon) || (isIconTop() && drawable1 != this.icon))
      resetIconDrawable(); 
  }
  
  private void updateIconPosition(int paramInt1, int paramInt2) {
    if (this.icon == null || getLayout() == null)
      return; 
    if (isIconStart() || isIconEnd()) {
      this.iconTop = 0;
      Layout.Alignment alignment = getActualTextAlignment();
      paramInt2 = this.iconGravity;
      boolean bool1 = true;
      if (paramInt2 == 1 || paramInt2 == 3 || (paramInt2 == 2 && alignment == Layout.Alignment.ALIGN_NORMAL) || (paramInt2 == 4 && alignment == Layout.Alignment.ALIGN_OPPOSITE)) {
        this.iconLeft = 0;
        updateIcon(false);
        return;
      } 
      int i = this.iconSize;
      paramInt2 = i;
      if (i == 0)
        paramInt2 = this.icon.getIntrinsicWidth(); 
      paramInt2 = paramInt1 - getTextLayoutWidth() - h0.E((View)this) - paramInt2 - this.iconPadding - h0.F((View)this);
      paramInt1 = paramInt2;
      if (alignment == Layout.Alignment.ALIGN_CENTER)
        paramInt1 = paramInt2 / 2; 
      boolean bool2 = isLayoutRTL();
      if (this.iconGravity != 4)
        bool1 = false; 
      paramInt2 = paramInt1;
      if (bool2 != bool1)
        paramInt2 = -paramInt1; 
      if (this.iconLeft != paramInt2) {
        this.iconLeft = paramInt2;
        updateIcon(false);
      } 
      return;
    } 
    if (isIconTop()) {
      this.iconLeft = 0;
      if (this.iconGravity == 16) {
        this.iconTop = 0;
        updateIcon(false);
        return;
      } 
      int i = this.iconSize;
      paramInt1 = i;
      if (i == 0)
        paramInt1 = this.icon.getIntrinsicHeight(); 
      paramInt1 = Math.max(0, (paramInt2 - getTextHeight() - getPaddingTop() - paramInt1 - this.iconPadding - getPaddingBottom()) / 2);
      if (this.iconTop != paramInt1) {
        this.iconTop = paramInt1;
        updateIcon(false);
      } 
    } 
  }
  
  public void addOnCheckedChangeListener(OnCheckedChangeListener paramOnCheckedChangeListener) {
    this.onCheckedChangeListeners.add(paramOnCheckedChangeListener);
  }
  
  public void clearOnCheckedChangeListeners() {
    this.onCheckedChangeListeners.clear();
  }
  
  public String getA11yClassName() {
    Class<Button> clazz;
    if (!TextUtils.isEmpty(this.accessibilityClassName))
      return this.accessibilityClassName; 
    if (isCheckable()) {
      Class<CompoundButton> clazz1 = CompoundButton.class;
    } else {
      clazz = Button.class;
    } 
    return clazz.getName();
  }
  
  public ColorStateList getBackgroundTintList() {
    return getSupportBackgroundTintList();
  }
  
  public PorterDuff.Mode getBackgroundTintMode() {
    return getSupportBackgroundTintMode();
  }
  
  public int getCornerRadius() {
    boolean bool;
    if (isUsingOriginalBackground()) {
      bool = this.materialButtonHelper.getCornerRadius();
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public Drawable getIcon() {
    return this.icon;
  }
  
  public int getIconGravity() {
    return this.iconGravity;
  }
  
  public int getIconPadding() {
    return this.iconPadding;
  }
  
  public int getIconSize() {
    return this.iconSize;
  }
  
  public ColorStateList getIconTint() {
    return this.iconTint;
  }
  
  public PorterDuff.Mode getIconTintMode() {
    return this.iconTintMode;
  }
  
  public int getInsetBottom() {
    return this.materialButtonHelper.getInsetBottom();
  }
  
  public int getInsetTop() {
    return this.materialButtonHelper.getInsetTop();
  }
  
  public ColorStateList getRippleColor() {
    ColorStateList colorStateList;
    if (isUsingOriginalBackground()) {
      colorStateList = this.materialButtonHelper.getRippleColor();
    } else {
      colorStateList = null;
    } 
    return colorStateList;
  }
  
  public ShapeAppearanceModel getShapeAppearanceModel() {
    if (isUsingOriginalBackground())
      return this.materialButtonHelper.getShapeAppearanceModel(); 
    throw new IllegalStateException("Attempted to get ShapeAppearanceModel from a MaterialButton which has an overwritten background.");
  }
  
  public ColorStateList getStrokeColor() {
    ColorStateList colorStateList;
    if (isUsingOriginalBackground()) {
      colorStateList = this.materialButtonHelper.getStrokeColor();
    } else {
      colorStateList = null;
    } 
    return colorStateList;
  }
  
  public int getStrokeWidth() {
    boolean bool;
    if (isUsingOriginalBackground()) {
      bool = this.materialButtonHelper.getStrokeWidth();
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    return isUsingOriginalBackground() ? this.materialButtonHelper.getSupportBackgroundTintList() : super.getSupportBackgroundTintList();
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    return isUsingOriginalBackground() ? this.materialButtonHelper.getSupportBackgroundTintMode() : super.getSupportBackgroundTintMode();
  }
  
  public boolean isCheckable() {
    boolean bool;
    MaterialButtonHelper materialButtonHelper = this.materialButtonHelper;
    if (materialButtonHelper != null && materialButtonHelper.isCheckable()) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public boolean isChecked() {
    return this.checked;
  }
  
  public boolean isToggleCheckedStateOnClick() {
    return this.materialButtonHelper.isToggleCheckedStateOnClick();
  }
  
  public void onAttachedToWindow() {
    super.onAttachedToWindow();
    if (isUsingOriginalBackground())
      MaterialShapeUtils.setParentAbsoluteElevation((View)this, this.materialButtonHelper.getMaterialShapeDrawable()); 
  }
  
  public int[] onCreateDrawableState(int paramInt) {
    int[] arrayOfInt = super.onCreateDrawableState(paramInt + 2);
    if (isCheckable())
      View.mergeDrawableStates(arrayOfInt, CHECKABLE_STATE_SET); 
    if (isChecked())
      View.mergeDrawableStates(arrayOfInt, CHECKED_STATE_SET); 
    return arrayOfInt;
  }
  
  public void onInitializeAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent) {
    super.onInitializeAccessibilityEvent(paramAccessibilityEvent);
    paramAccessibilityEvent.setClassName(getA11yClassName());
    paramAccessibilityEvent.setChecked(isChecked());
  }
  
  public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo paramAccessibilityNodeInfo) {
    super.onInitializeAccessibilityNodeInfo(paramAccessibilityNodeInfo);
    paramAccessibilityNodeInfo.setClassName(getA11yClassName());
    paramAccessibilityNodeInfo.setCheckable(isCheckable());
    paramAccessibilityNodeInfo.setChecked(isChecked());
    paramAccessibilityNodeInfo.setClickable(isClickable());
  }
  
  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
    updateIconPosition(getMeasuredWidth(), getMeasuredHeight());
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable) {
    if (!(paramParcelable instanceof SavedState)) {
      super.onRestoreInstanceState(paramParcelable);
      return;
    } 
    SavedState savedState = (SavedState)paramParcelable;
    super.onRestoreInstanceState(savedState.getSuperState());
    setChecked(savedState.checked);
  }
  
  public Parcelable onSaveInstanceState() {
    SavedState savedState = new SavedState(super.onSaveInstanceState());
    savedState.checked = this.checked;
    return (Parcelable)savedState;
  }
  
  public void onTextChanged(CharSequence paramCharSequence, int paramInt1, int paramInt2, int paramInt3) {
    super.onTextChanged(paramCharSequence, paramInt1, paramInt2, paramInt3);
    updateIconPosition(getMeasuredWidth(), getMeasuredHeight());
  }
  
  public boolean performClick() {
    if (this.materialButtonHelper.isToggleCheckedStateOnClick())
      toggle(); 
    return super.performClick();
  }
  
  public void refreshDrawableState() {
    super.refreshDrawableState();
    if (this.icon != null) {
      int[] arrayOfInt = getDrawableState();
      if (this.icon.setState(arrayOfInt))
        invalidate(); 
    } 
  }
  
  public void removeOnCheckedChangeListener(OnCheckedChangeListener paramOnCheckedChangeListener) {
    this.onCheckedChangeListeners.remove(paramOnCheckedChangeListener);
  }
  
  public void setA11yClassName(String paramString) {
    this.accessibilityClassName = paramString;
  }
  
  public void setBackground(Drawable paramDrawable) {
    setBackgroundDrawable(paramDrawable);
  }
  
  public void setBackgroundColor(int paramInt) {
    if (isUsingOriginalBackground()) {
      this.materialButtonHelper.setBackgroundColor(paramInt);
    } else {
      super.setBackgroundColor(paramInt);
    } 
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    if (isUsingOriginalBackground()) {
      if (paramDrawable != getBackground()) {
        r0.f("MaterialButton", "MaterialButton manages its own background to control elevation, shape, color and states. Consider using backgroundTint, shapeAppearance and other attributes where available. A custom background will ignore these attributes and you should consider handling interaction states such as pressed, focused and disabled");
        this.materialButtonHelper.setBackgroundOverwritten();
        super.setBackgroundDrawable(paramDrawable);
      } else {
        getBackground().setState(paramDrawable.getState());
      } 
    } else {
      super.setBackgroundDrawable(paramDrawable);
    } 
  }
  
  public void setBackgroundResource(int paramInt) {
    Drawable drawable;
    if (paramInt != 0) {
      drawable = a.b(getContext(), paramInt);
    } else {
      drawable = null;
    } 
    setBackgroundDrawable(drawable);
  }
  
  public void setBackgroundTintList(ColorStateList paramColorStateList) {
    setSupportBackgroundTintList(paramColorStateList);
  }
  
  public void setBackgroundTintMode(PorterDuff.Mode paramMode) {
    setSupportBackgroundTintMode(paramMode);
  }
  
  public void setCheckable(boolean paramBoolean) {
    if (isUsingOriginalBackground())
      this.materialButtonHelper.setCheckable(paramBoolean); 
  }
  
  public void setChecked(boolean paramBoolean) {
    if (isCheckable() && isEnabled() && this.checked != paramBoolean) {
      this.checked = paramBoolean;
      refreshDrawableState();
      if (getParent() instanceof MaterialButtonToggleGroup)
        ((MaterialButtonToggleGroup)getParent()).onButtonCheckedStateChanged(this, this.checked); 
      if (this.broadcasting)
        return; 
      this.broadcasting = true;
      Iterator<OnCheckedChangeListener> iterator = this.onCheckedChangeListeners.iterator();
      while (iterator.hasNext())
        ((OnCheckedChangeListener)iterator.next()).onCheckedChanged(this, this.checked); 
      this.broadcasting = false;
    } 
  }
  
  public void setCornerRadius(int paramInt) {
    if (isUsingOriginalBackground())
      this.materialButtonHelper.setCornerRadius(paramInt); 
  }
  
  public void setCornerRadiusResource(int paramInt) {
    if (isUsingOriginalBackground())
      setCornerRadius(getResources().getDimensionPixelSize(paramInt)); 
  }
  
  public void setElevation(float paramFloat) {
    super.setElevation(paramFloat);
    if (isUsingOriginalBackground())
      this.materialButtonHelper.getMaterialShapeDrawable().setElevation(paramFloat); 
  }
  
  public void setIcon(Drawable paramDrawable) {
    if (this.icon != paramDrawable) {
      this.icon = paramDrawable;
      updateIcon(true);
      updateIconPosition(getMeasuredWidth(), getMeasuredHeight());
    } 
  }
  
  public void setIconGravity(int paramInt) {
    if (this.iconGravity != paramInt) {
      this.iconGravity = paramInt;
      updateIconPosition(getMeasuredWidth(), getMeasuredHeight());
    } 
  }
  
  public void setIconPadding(int paramInt) {
    if (this.iconPadding != paramInt) {
      this.iconPadding = paramInt;
      setCompoundDrawablePadding(paramInt);
    } 
  }
  
  public void setIconResource(int paramInt) {
    Drawable drawable;
    if (paramInt != 0) {
      drawable = a.b(getContext(), paramInt);
    } else {
      drawable = null;
    } 
    setIcon(drawable);
  }
  
  public void setIconSize(int paramInt) {
    if (paramInt >= 0) {
      if (this.iconSize != paramInt) {
        this.iconSize = paramInt;
        updateIcon(true);
      } 
      return;
    } 
    throw new IllegalArgumentException("iconSize cannot be less than 0");
  }
  
  public void setIconTint(ColorStateList paramColorStateList) {
    if (this.iconTint != paramColorStateList) {
      this.iconTint = paramColorStateList;
      updateIcon(false);
    } 
  }
  
  public void setIconTintMode(PorterDuff.Mode paramMode) {
    if (this.iconTintMode != paramMode) {
      this.iconTintMode = paramMode;
      updateIcon(false);
    } 
  }
  
  public void setIconTintResource(int paramInt) {
    setIconTint(a.a(getContext(), paramInt));
  }
  
  public void setInsetBottom(int paramInt) {
    this.materialButtonHelper.setInsetBottom(paramInt);
  }
  
  public void setInsetTop(int paramInt) {
    this.materialButtonHelper.setInsetTop(paramInt);
  }
  
  public void setInternalBackground(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
  }
  
  public void setOnPressedChangeListenerInternal(OnPressedChangeListener paramOnPressedChangeListener) {
    this.onPressedChangeListenerInternal = paramOnPressedChangeListener;
  }
  
  public void setPressed(boolean paramBoolean) {
    OnPressedChangeListener onPressedChangeListener = this.onPressedChangeListenerInternal;
    if (onPressedChangeListener != null)
      onPressedChangeListener.onPressedChanged(this, paramBoolean); 
    super.setPressed(paramBoolean);
  }
  
  public void setRippleColor(ColorStateList paramColorStateList) {
    if (isUsingOriginalBackground())
      this.materialButtonHelper.setRippleColor(paramColorStateList); 
  }
  
  public void setRippleColorResource(int paramInt) {
    if (isUsingOriginalBackground())
      setRippleColor(a.a(getContext(), paramInt)); 
  }
  
  public void setShapeAppearanceModel(ShapeAppearanceModel paramShapeAppearanceModel) {
    if (isUsingOriginalBackground()) {
      this.materialButtonHelper.setShapeAppearanceModel(paramShapeAppearanceModel);
      return;
    } 
    throw new IllegalStateException("Attempted to set ShapeAppearanceModel on a MaterialButton which has an overwritten background.");
  }
  
  public void setShouldDrawSurfaceColorStroke(boolean paramBoolean) {
    if (isUsingOriginalBackground())
      this.materialButtonHelper.setShouldDrawSurfaceColorStroke(paramBoolean); 
  }
  
  public void setStrokeColor(ColorStateList paramColorStateList) {
    if (isUsingOriginalBackground())
      this.materialButtonHelper.setStrokeColor(paramColorStateList); 
  }
  
  public void setStrokeColorResource(int paramInt) {
    if (isUsingOriginalBackground())
      setStrokeColor(a.a(getContext(), paramInt)); 
  }
  
  public void setStrokeWidth(int paramInt) {
    if (isUsingOriginalBackground())
      this.materialButtonHelper.setStrokeWidth(paramInt); 
  }
  
  public void setStrokeWidthResource(int paramInt) {
    if (isUsingOriginalBackground())
      setStrokeWidth(getResources().getDimensionPixelSize(paramInt)); 
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    if (isUsingOriginalBackground()) {
      this.materialButtonHelper.setSupportBackgroundTintList(paramColorStateList);
    } else {
      super.setSupportBackgroundTintList(paramColorStateList);
    } 
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    if (isUsingOriginalBackground()) {
      this.materialButtonHelper.setSupportBackgroundTintMode(paramMode);
    } else {
      super.setSupportBackgroundTintMode(paramMode);
    } 
  }
  
  public void setTextAlignment(int paramInt) {
    super.setTextAlignment(paramInt);
    updateIconPosition(getMeasuredWidth(), getMeasuredHeight());
  }
  
  public void setToggleCheckedStateOnClick(boolean paramBoolean) {
    this.materialButtonHelper.setToggleCheckedStateOnClick(paramBoolean);
  }
  
  public void toggle() {
    setChecked(this.checked ^ true);
  }
  
  class MaterialButton {}
  
  class MaterialButton {}
  
  class MaterialButton {}
  
  class MaterialButton {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\google\android\material\button\MaterialButton.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */