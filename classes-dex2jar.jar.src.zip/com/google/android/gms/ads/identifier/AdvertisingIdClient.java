package com.google.android.gms.ads.identifier;

import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.os.RemoteException;
import android.os.SystemClock;
import android.util.Log;
import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.google.android.gms.common.util.VisibleForTesting;
import dbxyzptlk.EB.f;
import dbxyzptlk.dB.a;
import dbxyzptlk.oB.a;
import dbxyzptlk.oB.d;
import dbxyzptlk.sB.l;
import dbxyzptlk.yB.b;
import java.io.IOException;
import java.util.HashMap;

public class AdvertisingIdClient {
  public a a;
  
  public f b;
  
  public boolean c;
  
  public final Object d = new Object();
  
  public a e;
  
  public final Context f;
  
  public final long g;
  
  @VisibleForTesting
  public AdvertisingIdClient(Context paramContext, long paramLong, boolean paramBoolean1, boolean paramBoolean2) {
    l.m(paramContext);
    Context context = paramContext;
    if (paramBoolean1) {
      Context context1 = paramContext.getApplicationContext();
      context = paramContext;
      if (context1 != null)
        context = context1; 
    } 
    this.f = context;
    this.c = false;
    this.g = paramLong;
  }
  
  public static void a(boolean paramBoolean) {}
  
  public static Info getAdvertisingIdInfo(Context paramContext) throws IOException, IllegalStateException, GooglePlayServicesNotAvailableException, GooglePlayServicesRepairableException {
    AdvertisingIdClient advertisingIdClient = new AdvertisingIdClient(paramContext, -1L, true, false);
    try {
      long l = SystemClock.elapsedRealtime();
      advertisingIdClient.c(false);
      Info info = advertisingIdClient.e(-1);
      advertisingIdClient.d(info, true, 0.0F, SystemClock.elapsedRealtime() - l, "", null);
      return info;
    } finally {
      null = null;
    } 
  }
  
  public final void b() {
    l.l("Calling this from your main thread can lead to deadlock");
    /* monitor enter ThisExpression{ObjectType{com/google/android/gms/ads/identifier/AdvertisingIdClient}} */
    try {
      if (this.f != null) {
        a a1 = this.a;
        if (a1 != null) {
          try {
            if (this.c)
              b.b().c(this.f, (ServiceConnection)this.a); 
          } finally {
            a1 = null;
          } 
          this.b = null;
          this.a = null;
          /* monitor exit ThisExpression{ObjectType{com/google/android/gms/ads/identifier/AdvertisingIdClient}} */
          return;
        } 
      } 
    } finally {
      Exception exception;
    } 
    /* monitor exit ThisExpression{ObjectType{com/google/android/gms/ads/identifier/AdvertisingIdClient}} */
  }
  
  @VisibleForTesting
  public final void c(boolean paramBoolean) throws IOException, IllegalStateException, GooglePlayServicesNotAvailableException, GooglePlayServicesRepairableException {
    l.l("Calling this from your main thread can lead to deadlock");
    /* monitor enter ThisExpression{ObjectType{com/google/android/gms/ads/identifier/AdvertisingIdClient}} */
    try {
      if (this.c)
        b(); 
    } finally {
      Exception exception;
    } 
    Context context = this.f;
    try {
      context.getPackageManager().getPackageInfo("com.android.vending", 0);
      int i = d.h().j(context, 12451000);
      if (i == 0 || i == 2) {
        a a1 = new a();
        this();
        Intent intent = new Intent();
        this("com.google.android.gms.ads.identifier.service.START");
        intent.setPackage("com.google.android.gms");
        try {
          boolean bool = b.b().a(context, intent, (ServiceConnection)a1, 1);
          if (bool) {
            this.a = a1;
            try {
              return;
            } catch (InterruptedException interruptedException) {
              IOException iOException2 = new IOException();
              this("Interrupted exception");
              throw iOException2;
            } finally {
              a1 = null;
              IOException iOException2 = new IOException();
              this((Throwable)a1);
            } 
          } 
          IOException iOException1 = new IOException();
          this("Connection failure");
          throw iOException1;
        } finally {
          a1 = null;
          IOException iOException1 = new IOException();
          this((Throwable)a1);
        } 
      } 
      IOException iOException = new IOException();
      this("Google Play services not available");
      throw iOException;
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
      GooglePlayServicesNotAvailableException googlePlayServicesNotAvailableException = new GooglePlayServicesNotAvailableException();
      this(9);
      throw googlePlayServicesNotAvailableException;
    } 
  }
  
  @VisibleForTesting
  public final boolean d(Info paramInfo, boolean paramBoolean, float paramFloat, long paramLong, String paramString, Throwable paramThrowable) {
    if (Math.random() <= 0.0D) {
      HashMap<Object, Object> hashMap = new HashMap<>();
      paramString = "1";
      hashMap.put("app_context", "1");
      if (paramInfo != null) {
        if (true != paramInfo.isLimitAdTrackingEnabled())
          paramString = "0"; 
        hashMap.put("limit_ad_tracking", paramString);
        String str = paramInfo.getId();
        if (str != null)
          hashMap.put("ad_id_size", Integer.toString(str.length())); 
      } 
      if (paramThrowable != null)
        hashMap.put("error", paramThrowable.getClass().getName()); 
      hashMap.put("tag", "AdvertisingIdClient");
      hashMap.put("time_spent", Long.toString(paramLong));
      (new a(this, hashMap)).start();
      return true;
    } 
    return false;
  }
  
  public final Info e(int paramInt) throws IOException {
    l.l("Calling this from your main thread can lead to deadlock");
    /* monitor enter ThisExpression{ObjectType{com/google/android/gms/ads/identifier/AdvertisingIdClient}} */
    try {
      if (!this.c)
        synchronized (this.d) {
          a a1 = this.e;
          if (a1 != null && a1.d) {
            try {
              c(false);
              if (!this.c) {
                null = new IOException();
                super("AdvertisingIdClient cannot reconnect.");
                throw null;
              } 
            } catch (Exception null) {
              IOException iOException = new IOException();
              this("AdvertisingIdClient cannot reconnect.", (Throwable)null);
              throw iOException;
            } 
          } else {
            IOException iOException = new IOException();
            this("AdvertisingIdClient is not connected.");
            throw iOException;
          } 
        }  
    } finally {
      Exception exception;
    } 
    l.m(this.a);
    l.m(this.b);
    try {
      Info info = new Info();
      this(this.b.f(), this.b.P(true));
      /* monitor exit ThisExpression{ObjectType{com/google/android/gms/ads/identifier/AdvertisingIdClient}} */
      f();
      return info;
    } catch (RemoteException remoteException) {
      Log.i("AdvertisingIdClient", "GMS remote exception ", (Throwable)remoteException);
      IOException iOException = new IOException();
      this("Remote exception");
      throw iOException;
    } 
  }
  
  public final void f() {
    Object object = this.d;
    /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
    try {
      a a1 = this.e;
      if (a1 != null) {
        a1.c.countDown();
        try {
          this.e.join();
        } catch (InterruptedException interruptedException) {}
      } 
    } finally {
      Exception exception;
    } 
    long l = this.g;
    if (l > 0L) {
      a a1 = new a();
      this(this, l);
      this.e = a1;
    } 
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
  }
  
  public final void finalize() throws Throwable {
    b();
    super.finalize();
  }
  
  public static final class Info {
    public final String a;
    
    public final boolean b;
    
    @Deprecated
    public Info(String param1String, boolean param1Boolean) {
      this.a = param1String;
      this.b = param1Boolean;
    }
    
    public String getId() {
      return this.a;
    }
    
    public boolean isLimitAdTrackingEnabled() {
      return this.b;
    }
    
    public String toString() {
      String str = this.a;
      boolean bool = this.b;
      StringBuilder stringBuilder = new StringBuilder(String.valueOf(str).length() + 7);
      stringBuilder.append("{");
      stringBuilder.append(str);
      stringBuilder.append("}");
      stringBuilder.append(bool);
      return stringBuilder.toString();
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\google\android\gms\ads\identifier\AdvertisingIdClient.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */