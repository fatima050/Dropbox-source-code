package com.google.android.gms.common.internal;

import android.accounts.Account;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.Feature;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import dbxyzptlk.sB.i0;

public class GetServiceRequest extends AbstractSafeParcelable {
  public static final Parcelable.Creator<GetServiceRequest> CREATOR = (Parcelable.Creator<GetServiceRequest>)new i0();
  
  public static final Scope[] o = new Scope[0];
  
  public static final Feature[] p = new Feature[0];
  
  public final int a;
  
  public final int b;
  
  public final int c;
  
  public String d;
  
  public IBinder e;
  
  public Scope[] f;
  
  public Bundle g;
  
  public Account h;
  
  public Feature[] i;
  
  public Feature[] j;
  
  public final boolean k;
  
  public final int l;
  
  public boolean m;
  
  public final String n;
  
  public GetServiceRequest(int paramInt1, int paramInt2, int paramInt3, String paramString1, IBinder paramIBinder, Scope[] paramArrayOfScope, Bundle paramBundle, Account paramAccount, Feature[] paramArrayOfFeature1, Feature[] paramArrayOfFeature2, boolean paramBoolean1, int paramInt4, boolean paramBoolean2, String paramString2) {
    Scope[] arrayOfScope = paramArrayOfScope;
    if (paramArrayOfScope == null)
      arrayOfScope = o; 
    Bundle bundle = paramBundle;
    if (paramBundle == null)
      bundle = new Bundle(); 
    Feature[] arrayOfFeature = paramArrayOfFeature1;
    if (paramArrayOfFeature1 == null)
      arrayOfFeature = p; 
    paramArrayOfFeature1 = paramArrayOfFeature2;
    if (paramArrayOfFeature2 == null)
      paramArrayOfFeature1 = p; 
    this.a = paramInt1;
    this.b = paramInt2;
    this.c = paramInt3;
    if ("com.google.android.gms".equals(paramString1)) {
      this.d = "com.google.android.gms";
    } else {
      this.d = paramString1;
    } 
    if (paramInt1 < 2) {
      if (paramIBinder != null) {
        Account account = a.h(b.a.e(paramIBinder));
      } else {
        paramString1 = null;
      } 
      this.h = (Account)paramString1;
    } else {
      this.e = paramIBinder;
      this.h = paramAccount;
    } 
    this.f = arrayOfScope;
    this.g = bundle;
    this.i = arrayOfFeature;
    this.j = paramArrayOfFeature1;
    this.k = paramBoolean1;
    this.l = paramInt4;
    this.m = paramBoolean2;
    this.n = paramString2;
  }
  
  public final String A() {
    return this.n;
  }
  
  public final void writeToParcel(Parcel paramParcel, int paramInt) {
    i0.a(this, paramParcel, paramInt);
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\google\android\gms\common\internal\GetServiceRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */