package com.google.android.gms.common.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import dbxyzptlk.sB.Z;
import dbxyzptlk.tB.a;

public class RootTelemetryConfiguration extends AbstractSafeParcelable {
  public static final Parcelable.Creator<RootTelemetryConfiguration> CREATOR = (Parcelable.Creator<RootTelemetryConfiguration>)new Z();
  
  public final int a;
  
  public final boolean b;
  
  public final boolean c;
  
  public final int d;
  
  public final int e;
  
  public RootTelemetryConfiguration(int paramInt1, boolean paramBoolean1, boolean paramBoolean2, int paramInt2, int paramInt3) {
    this.a = paramInt1;
    this.b = paramBoolean1;
    this.c = paramBoolean2;
    this.d = paramInt2;
    this.e = paramInt3;
  }
  
  public int A() {
    return this.d;
  }
  
  public int O() {
    return this.e;
  }
  
  public boolean Q() {
    return this.b;
  }
  
  public boolean Y() {
    return this.c;
  }
  
  public int i0() {
    return this.a;
  }
  
  public final void writeToParcel(Parcel paramParcel, int paramInt) {
    paramInt = a.a(paramParcel);
    a.k(paramParcel, 1, i0());
    a.c(paramParcel, 2, Q());
    a.c(paramParcel, 3, Y());
    a.k(paramParcel, 4, A());
    a.k(paramParcel, 5, O());
    a.b(paramParcel, paramInt);
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\google\android\gms\common\internal\RootTelemetryConfiguration.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */