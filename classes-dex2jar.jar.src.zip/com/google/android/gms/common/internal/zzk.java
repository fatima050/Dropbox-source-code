package com.google.android.gms.common.internal;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.Feature;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import dbxyzptlk.sB.g0;
import dbxyzptlk.tB.a;

public final class zzk extends AbstractSafeParcelable {
  public static final Parcelable.Creator<zzk> CREATOR = (Parcelable.Creator<zzk>)new g0();
  
  public Bundle a;
  
  public Feature[] b;
  
  public int c;
  
  public ConnectionTelemetryConfiguration d;
  
  public zzk() {}
  
  public zzk(Bundle paramBundle, Feature[] paramArrayOfFeature, int paramInt, ConnectionTelemetryConfiguration paramConnectionTelemetryConfiguration) {
    this.a = paramBundle;
    this.b = paramArrayOfFeature;
    this.c = paramInt;
    this.d = paramConnectionTelemetryConfiguration;
  }
  
  public final void writeToParcel(Parcel paramParcel, int paramInt) {
    int i = a.a(paramParcel);
    a.e(paramParcel, 1, this.a, false);
    a.s(paramParcel, 2, (Parcelable[])this.b, paramInt, false);
    a.k(paramParcel, 3, this.c);
    a.o(paramParcel, 4, (Parcelable)this.d, paramInt, false);
    a.b(paramParcel, i);
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\google\android\gms\common\internal\zzk.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */