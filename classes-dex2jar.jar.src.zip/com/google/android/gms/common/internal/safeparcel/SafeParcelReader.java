package com.google.android.gms.common.internal.safeparcel;

import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import java.util.ArrayList;

public class SafeParcelReader {
  public static Bundle a(Parcel paramParcel, int paramInt) {
    paramInt = v(paramParcel, paramInt);
    int i = paramParcel.dataPosition();
    if (paramInt == 0)
      return null; 
    Bundle bundle = paramParcel.readBundle();
    paramParcel.setDataPosition(i + paramInt);
    return bundle;
  }
  
  public static byte[] b(Parcel paramParcel, int paramInt) {
    int i = v(paramParcel, paramInt);
    paramInt = paramParcel.dataPosition();
    if (i == 0)
      return null; 
    byte[] arrayOfByte = paramParcel.createByteArray();
    paramParcel.setDataPosition(paramInt + i);
    return arrayOfByte;
  }
  
  public static int[] c(Parcel paramParcel, int paramInt) {
    int i = v(paramParcel, paramInt);
    paramInt = paramParcel.dataPosition();
    if (i == 0)
      return null; 
    int[] arrayOfInt = paramParcel.createIntArray();
    paramParcel.setDataPosition(paramInt + i);
    return arrayOfInt;
  }
  
  public static <T extends Parcelable> T d(Parcel paramParcel, int paramInt, Parcelable.Creator<T> paramCreator) {
    int i = v(paramParcel, paramInt);
    paramInt = paramParcel.dataPosition();
    if (i == 0)
      return null; 
    Parcelable parcelable = (Parcelable)paramCreator.createFromParcel(paramParcel);
    paramParcel.setDataPosition(paramInt + i);
    return (T)parcelable;
  }
  
  public static String e(Parcel paramParcel, int paramInt) {
    int i = v(paramParcel, paramInt);
    paramInt = paramParcel.dataPosition();
    if (i == 0)
      return null; 
    String str = paramParcel.readString();
    paramParcel.setDataPosition(paramInt + i);
    return str;
  }
  
  public static String[] f(Parcel paramParcel, int paramInt) {
    int i = v(paramParcel, paramInt);
    paramInt = paramParcel.dataPosition();
    if (i == 0)
      return null; 
    String[] arrayOfString = paramParcel.createStringArray();
    paramParcel.setDataPosition(paramInt + i);
    return arrayOfString;
  }
  
  public static ArrayList<String> g(Parcel paramParcel, int paramInt) {
    int i = v(paramParcel, paramInt);
    paramInt = paramParcel.dataPosition();
    if (i == 0)
      return null; 
    ArrayList<String> arrayList = paramParcel.createStringArrayList();
    paramParcel.setDataPosition(paramInt + i);
    return arrayList;
  }
  
  public static <T> T[] h(Parcel paramParcel, int paramInt, Parcelable.Creator<T> paramCreator) {
    paramInt = v(paramParcel, paramInt);
    int i = paramParcel.dataPosition();
    if (paramInt == 0)
      return null; 
    Object[] arrayOfObject = paramParcel.createTypedArray(paramCreator);
    paramParcel.setDataPosition(i + paramInt);
    return (T[])arrayOfObject;
  }
  
  public static <T> ArrayList<T> i(Parcel paramParcel, int paramInt, Parcelable.Creator<T> paramCreator) {
    int i = v(paramParcel, paramInt);
    paramInt = paramParcel.dataPosition();
    if (i == 0)
      return null; 
    ArrayList<T> arrayList = paramParcel.createTypedArrayList(paramCreator);
    paramParcel.setDataPosition(paramInt + i);
    return arrayList;
  }
  
  public static void j(Parcel paramParcel, int paramInt) {
    if (paramParcel.dataPosition() == paramInt)
      return; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Overread allowed size end=");
    stringBuilder.append(paramInt);
    throw new ParseException(stringBuilder.toString(), paramParcel);
  }
  
  public static int k(int paramInt) {
    return (char)paramInt;
  }
  
  public static boolean l(Parcel paramParcel, int paramInt) {
    z(paramParcel, paramInt, 4);
    return (paramParcel.readInt() != 0);
  }
  
  public static Boolean m(Parcel paramParcel, int paramInt) {
    boolean bool;
    int i = v(paramParcel, paramInt);
    if (i == 0)
      return null; 
    y(paramParcel, paramInt, i, 4);
    if (paramParcel.readInt() != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    return Boolean.valueOf(bool);
  }
  
  public static double n(Parcel paramParcel, int paramInt) {
    z(paramParcel, paramInt, 8);
    return paramParcel.readDouble();
  }
  
  public static Double o(Parcel paramParcel, int paramInt) {
    int i = v(paramParcel, paramInt);
    if (i == 0)
      return null; 
    y(paramParcel, paramInt, i, 8);
    return Double.valueOf(paramParcel.readDouble());
  }
  
  public static Float p(Parcel paramParcel, int paramInt) {
    int i = v(paramParcel, paramInt);
    if (i == 0)
      return null; 
    y(paramParcel, paramInt, i, 4);
    return Float.valueOf(paramParcel.readFloat());
  }
  
  public static int q(Parcel paramParcel) {
    return paramParcel.readInt();
  }
  
  public static IBinder r(Parcel paramParcel, int paramInt) {
    int i = v(paramParcel, paramInt);
    paramInt = paramParcel.dataPosition();
    if (i == 0)
      return null; 
    IBinder iBinder = paramParcel.readStrongBinder();
    paramParcel.setDataPosition(paramInt + i);
    return iBinder;
  }
  
  public static int s(Parcel paramParcel, int paramInt) {
    z(paramParcel, paramInt, 4);
    return paramParcel.readInt();
  }
  
  public static long t(Parcel paramParcel, int paramInt) {
    z(paramParcel, paramInt, 8);
    return paramParcel.readLong();
  }
  
  public static Long u(Parcel paramParcel, int paramInt) {
    int i = v(paramParcel, paramInt);
    if (i == 0)
      return null; 
    y(paramParcel, paramInt, i, 8);
    return Long.valueOf(paramParcel.readLong());
  }
  
  public static int v(Parcel paramParcel, int paramInt) {
    return ((paramInt & 0xFFFF0000) != -65536) ? (char)(paramInt >> 16) : paramParcel.readInt();
  }
  
  public static void w(Parcel paramParcel, int paramInt) {
    paramInt = v(paramParcel, paramInt);
    paramParcel.setDataPosition(paramParcel.dataPosition() + paramInt);
  }
  
  public static int x(Parcel paramParcel) {
    int k = q(paramParcel);
    int m = v(paramParcel, k);
    int j = k(k);
    int i = paramParcel.dataPosition();
    if (j == 20293) {
      j = m + i;
      if (j >= i && j <= paramParcel.dataSize())
        return j; 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Size read is invalid start=");
      stringBuilder.append(i);
      stringBuilder.append(" end=");
      stringBuilder.append(j);
      throw new ParseException(stringBuilder.toString(), paramParcel);
    } 
    throw new ParseException("Expected object header. Got 0x".concat(String.valueOf(Integer.toHexString(k))), paramParcel);
  }
  
  public static void y(Parcel paramParcel, int paramInt1, int paramInt2, int paramInt3) {
    if (paramInt2 == paramInt3)
      return; 
    String str = Integer.toHexString(paramInt2);
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Expected size ");
    stringBuilder.append(paramInt3);
    stringBuilder.append(" got ");
    stringBuilder.append(paramInt2);
    stringBuilder.append(" (0x");
    stringBuilder.append(str);
    stringBuilder.append(")");
    throw new ParseException(stringBuilder.toString(), paramParcel);
  }
  
  public static void z(Parcel paramParcel, int paramInt1, int paramInt2) {
    paramInt1 = v(paramParcel, paramInt1);
    if (paramInt1 == paramInt2)
      return; 
    String str = Integer.toHexString(paramInt1);
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Expected size ");
    stringBuilder.append(paramInt2);
    stringBuilder.append(" got ");
    stringBuilder.append(paramInt1);
    stringBuilder.append(" (0x");
    stringBuilder.append(str);
    stringBuilder.append(")");
    throw new ParseException(stringBuilder.toString(), paramParcel);
  }
  
  public static class ParseException extends RuntimeException {
    public ParseException(String param1String, Parcel param1Parcel) {
      super(stringBuilder.toString());
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\google\android\gms\common\internal\safeparcel\SafeParcelReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */