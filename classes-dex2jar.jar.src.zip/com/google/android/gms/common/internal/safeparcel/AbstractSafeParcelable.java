package com.google.android.gms.common.internal.safeparcel;

public abstract class AbstractSafeParcelable implements SafeParcelable {
  public final int describeContents() {
    return 0;
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\google\android\gms\common\internal\safeparcel\AbstractSafeParcelable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */