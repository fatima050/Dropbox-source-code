package com.google.android.gms.common.internal.safeparcel;

import android.os.Parcelable;

public interface SafeParcelable extends Parcelable {
  public static final String NULL = "SAFE_PARCELABLE_NULL_STRING";
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\google\android\gms\common\internal\safeparcel\SafeParcelable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */