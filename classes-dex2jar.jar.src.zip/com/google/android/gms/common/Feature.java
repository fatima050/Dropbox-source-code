package com.google.android.gms.common;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import dbxyzptlk.oB.k;
import dbxyzptlk.sB.j;
import dbxyzptlk.tB.a;

public class Feature extends AbstractSafeParcelable {
  public static final Parcelable.Creator<Feature> CREATOR = (Parcelable.Creator<Feature>)new k();
  
  public final String a;
  
  @Deprecated
  public final int b;
  
  public final long c;
  
  public Feature(String paramString, int paramInt, long paramLong) {
    this.a = paramString;
    this.b = paramInt;
    this.c = paramLong;
  }
  
  public Feature(String paramString, long paramLong) {
    this.a = paramString;
    this.c = paramLong;
    this.b = -1;
  }
  
  public long A() {
    long l2 = this.c;
    long l1 = l2;
    if (l2 == -1L)
      l1 = this.b; 
    return l1;
  }
  
  public final boolean equals(Object paramObject) {
    if (paramObject instanceof Feature) {
      paramObject = paramObject;
      if (((getName() != null && getName().equals(paramObject.getName())) || (getName() == null && paramObject.getName() == null)) && A() == paramObject.A())
        return true; 
    } 
    return false;
  }
  
  public String getName() {
    return this.a;
  }
  
  public final int hashCode() {
    return j.c(new Object[] { getName(), Long.valueOf(A()) });
  }
  
  public final String toString() {
    j.a a = j.d(this);
    a.a("name", getName());
    a.a("version", Long.valueOf(A()));
    return a.toString();
  }
  
  public final void writeToParcel(Parcel paramParcel, int paramInt) {
    paramInt = a.a(paramParcel);
    a.p(paramParcel, 1, getName(), false);
    a.k(paramParcel, 2, this.b);
    a.m(paramParcel, 3, A());
    a.b(paramParcel, paramInt);
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\google\android\gms\common\Feature.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */