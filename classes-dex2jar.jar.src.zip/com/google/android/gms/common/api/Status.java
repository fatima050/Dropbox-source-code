package com.google.android.gms.common.api;

import android.app.PendingIntent;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.internal.ReflectedParcelable;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import com.google.errorprone.annotations.ResultIgnorabilityUnspecified;
import dbxyzptlk.pB.a;
import dbxyzptlk.pB.h;
import dbxyzptlk.pB.q;
import dbxyzptlk.sB.j;
import dbxyzptlk.tB.a;

public final class Status extends AbstractSafeParcelable implements h, ReflectedParcelable {
  public static final Parcelable.Creator<Status> CREATOR;
  
  public static final Status e = new Status(-1);
  
  public static final Status f = new Status(0);
  
  public static final Status g = new Status(14);
  
  public static final Status h = new Status(8);
  
  public static final Status i = new Status(15);
  
  public static final Status j = new Status(16);
  
  public static final Status k;
  
  public static final Status l = new Status(17);
  
  public final int a;
  
  public final String b;
  
  public final PendingIntent c;
  
  public final ConnectionResult d;
  
  static {
    k = new Status(18);
    CREATOR = (Parcelable.Creator<Status>)new q();
  }
  
  public Status(int paramInt) {
    this(paramInt, (String)null);
  }
  
  public Status(int paramInt, String paramString) {
    this(paramInt, paramString, (PendingIntent)null);
  }
  
  public Status(int paramInt, String paramString, PendingIntent paramPendingIntent) {
    this(paramInt, paramString, paramPendingIntent, null);
  }
  
  public Status(int paramInt, String paramString, PendingIntent paramPendingIntent, ConnectionResult paramConnectionResult) {
    this.a = paramInt;
    this.b = paramString;
    this.c = paramPendingIntent;
    this.d = paramConnectionResult;
  }
  
  public Status(ConnectionResult paramConnectionResult, String paramString) {
    this(paramConnectionResult, paramString, 17);
  }
  
  @Deprecated
  public Status(ConnectionResult paramConnectionResult, String paramString, int paramInt) {
    this(paramInt, paramString, paramConnectionResult.Q(), paramConnectionResult);
  }
  
  public ConnectionResult A() {
    return this.d;
  }
  
  @ResultIgnorabilityUnspecified
  public int O() {
    return this.a;
  }
  
  public String Q() {
    return this.b;
  }
  
  public boolean Y() {
    return (this.c != null);
  }
  
  public Status b() {
    return this;
  }
  
  public boolean equals(Object paramObject) {
    if (!(paramObject instanceof Status))
      return false; 
    paramObject = paramObject;
    return (this.a == ((Status)paramObject).a && j.b(this.b, ((Status)paramObject).b) && j.b(this.c, ((Status)paramObject).c) && j.b(this.d, ((Status)paramObject).d));
  }
  
  public int hashCode() {
    return j.c(new Object[] { Integer.valueOf(this.a), this.b, this.c, this.d });
  }
  
  public boolean i0() {
    return (this.a <= 0);
  }
  
  public final String s0() {
    String str = this.b;
    return (str != null) ? str : a.a(this.a);
  }
  
  public String toString() {
    j.a a = j.d(this);
    a.a("statusCode", s0());
    a.a("resolution", this.c);
    return a.toString();
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    int i = a.a(paramParcel);
    a.k(paramParcel, 1, O());
    a.p(paramParcel, 2, Q(), false);
    a.o(paramParcel, 3, (Parcelable)this.c, paramInt, false);
    a.o(paramParcel, 4, (Parcelable)A(), paramInt, false);
    a.b(paramParcel, i);
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\google\android\gms\common\api\Status.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */