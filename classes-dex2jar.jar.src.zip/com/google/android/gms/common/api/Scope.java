package com.google.android.gms.common.api;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.ReflectedParcelable;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import dbxyzptlk.pB.p;
import dbxyzptlk.sB.l;
import dbxyzptlk.tB.a;

public final class Scope extends AbstractSafeParcelable implements ReflectedParcelable {
  public static final Parcelable.Creator<Scope> CREATOR = (Parcelable.Creator<Scope>)new p();
  
  public final int a;
  
  public final String b;
  
  public Scope(int paramInt, String paramString) {
    l.h(paramString, "scopeUri must not be null or empty");
    this.a = paramInt;
    this.b = paramString;
  }
  
  public Scope(String paramString) {
    this(1, paramString);
  }
  
  public String A() {
    return this.b;
  }
  
  public boolean equals(Object paramObject) {
    return (this == paramObject) ? true : (!(paramObject instanceof Scope) ? false : this.b.equals(((Scope)paramObject).b));
  }
  
  public int hashCode() {
    return this.b.hashCode();
  }
  
  public String toString() {
    return this.b;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    paramInt = this.a;
    int i = a.a(paramParcel);
    a.k(paramParcel, 1, paramInt);
    a.p(paramParcel, 2, A(), false);
    a.b(paramParcel, i);
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\google\android\gms\common\api\Scope.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */