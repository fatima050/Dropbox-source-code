package com.google.android.gms.common.api;

import android.accounts.Account;
import android.app.Activity;
import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import com.google.android.gms.common.api.internal.a;
import com.google.errorprone.annotations.ResultIgnorabilityUnspecified;
import dbxyzptlk.bC.j;
import dbxyzptlk.bC.k;
import dbxyzptlk.pB.n;
import dbxyzptlk.qB.J0;
import dbxyzptlk.qB.e;
import dbxyzptlk.qB.i;
import dbxyzptlk.qB.j;
import dbxyzptlk.qB.j0;
import dbxyzptlk.qB.k;
import dbxyzptlk.qB.m;
import dbxyzptlk.qB.n;
import dbxyzptlk.qB.o0;
import dbxyzptlk.qB.q;
import dbxyzptlk.qB.s;
import dbxyzptlk.qB.u;
import dbxyzptlk.qB.z;
import dbxyzptlk.sB.c;
import dbxyzptlk.sB.l;

public abstract class b<O extends a.d> {
  public final Context a;
  
  public final String b;
  
  public final a c;
  
  public final a.d d;
  
  public final dbxyzptlk.qB.b e;
  
  public final Looper f;
  
  public final int g;
  
  public final c h;
  
  public final q i;
  
  public final e j;
  
  public b(Context paramContext, Activity paramActivity, a parama, a.d paramd, a parama1) {
    String str;
    l.n(paramContext, "Null context is not permitted.");
    l.n(parama, "Api must not be null.");
    l.n(parama1, "Settings must not be null; use Settings.DEFAULT_SETTINGS instead.");
    Context context = (Context)l.n(paramContext.getApplicationContext(), "The provided context did not have an application context.");
    this.a = context;
    if (Build.VERSION.SDK_INT >= 30) {
      str = dbxyzptlk.pB.b.a(paramContext);
    } else {
      str = q((Context)str);
    } 
    this.b = str;
    this.c = parama;
    this.d = paramd;
    this.f = parama1.b;
    dbxyzptlk.qB.b b1 = dbxyzptlk.qB.b.a(parama, paramd, str);
    this.e = b1;
    this.h = (c)new o0(this);
    e e1 = e.u(context);
    this.j = e1;
    this.g = e1.l();
    this.i = parama1.a;
    if (paramActivity != null && !(paramActivity instanceof GoogleApiActivity) && Looper.myLooper() == Looper.getMainLooper())
      z.u(paramActivity, e1, b1); 
    e1.H(this);
  }
  
  public b(Context paramContext, a<O> parama, O paramO, a parama1) {
    this(paramContext, null, parama, (a.d)paramO, parama1);
  }
  
  @Deprecated
  public b(Context paramContext, a<O> parama, O paramO, q paramq) {
    this(paramContext, parama, paramO, a1.a());
  }
  
  public final a A(int paramInt, a parama) {
    parama.l();
    this.j.C(this, paramInt, parama);
    return parama;
  }
  
  public final j B(int paramInt, s params) {
    k k = new k();
    q q1 = this.i;
    this.j.D(this, paramInt, params, k, q1);
    return k.a();
  }
  
  public c h() {
    return this.h;
  }
  
  public c.a i() {
    // Byte code:
    //   0: new dbxyzptlk/sB/c$a
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore_2
    //   8: aload_0
    //   9: getfield d : Lcom/google/android/gms/common/api/a$d;
    //   12: astore_1
    //   13: aload_1
    //   14: instanceof com/google/android/gms/common/api/a$d$b
    //   17: ifeq -> 42
    //   20: aload_1
    //   21: checkcast com/google/android/gms/common/api/a$d$b
    //   24: invokeinterface x : ()Lcom/google/android/gms/auth/api/signin/GoogleSignInAccount;
    //   29: astore_1
    //   30: aload_1
    //   31: ifnull -> 42
    //   34: aload_1
    //   35: invokevirtual e : ()Landroid/accounts/Account;
    //   38: astore_1
    //   39: goto -> 69
    //   42: aload_0
    //   43: getfield d : Lcom/google/android/gms/common/api/a$d;
    //   46: astore_1
    //   47: aload_1
    //   48: instanceof com/google/android/gms/common/api/a$d$a
    //   51: ifeq -> 67
    //   54: aload_1
    //   55: checkcast com/google/android/gms/common/api/a$d$a
    //   58: invokeinterface e : ()Landroid/accounts/Account;
    //   63: astore_1
    //   64: goto -> 69
    //   67: aconst_null
    //   68: astore_1
    //   69: aload_2
    //   70: aload_1
    //   71: invokevirtual d : (Landroid/accounts/Account;)Ldbxyzptlk/sB/c$a;
    //   74: pop
    //   75: aload_0
    //   76: getfield d : Lcom/google/android/gms/common/api/a$d;
    //   79: astore_1
    //   80: aload_1
    //   81: instanceof com/google/android/gms/common/api/a$d$b
    //   84: ifeq -> 116
    //   87: aload_1
    //   88: checkcast com/google/android/gms/common/api/a$d$b
    //   91: invokeinterface x : ()Lcom/google/android/gms/auth/api/signin/GoogleSignInAccount;
    //   96: astore_1
    //   97: aload_1
    //   98: ifnonnull -> 108
    //   101: invokestatic emptySet : ()Ljava/util/Set;
    //   104: astore_1
    //   105: goto -> 120
    //   108: aload_1
    //   109: invokevirtual s0 : ()Ljava/util/Set;
    //   112: astore_1
    //   113: goto -> 120
    //   116: invokestatic emptySet : ()Ljava/util/Set;
    //   119: astore_1
    //   120: aload_2
    //   121: aload_1
    //   122: invokevirtual c : (Ljava/util/Collection;)Ldbxyzptlk/sB/c$a;
    //   125: pop
    //   126: aload_2
    //   127: aload_0
    //   128: getfield a : Landroid/content/Context;
    //   131: invokevirtual getClass : ()Ljava/lang/Class;
    //   134: invokevirtual getName : ()Ljava/lang/String;
    //   137: invokevirtual e : (Ljava/lang/String;)Ldbxyzptlk/sB/c$a;
    //   140: pop
    //   141: aload_2
    //   142: aload_0
    //   143: getfield a : Landroid/content/Context;
    //   146: invokevirtual getPackageName : ()Ljava/lang/String;
    //   149: invokevirtual b : (Ljava/lang/String;)Ldbxyzptlk/sB/c$a;
    //   152: pop
    //   153: aload_2
    //   154: areturn
  }
  
  @ResultIgnorabilityUnspecified
  public <TResult, A extends a.b> j<TResult> j(s<A, TResult> params) {
    return B(2, params);
  }
  
  public <A extends a.b, T extends a<? extends dbxyzptlk.pB.h, A>> T k(T paramT) {
    A(0, (a)paramT);
    return paramT;
  }
  
  @ResultIgnorabilityUnspecified
  public <TResult, A extends a.b> j<TResult> l(s<A, TResult> params) {
    return B(0, params);
  }
  
  @ResultIgnorabilityUnspecified
  public <A extends a.b> j<Void> m(n<A, ?> paramn) {
    l.m(paramn);
    l.n(paramn.a.b(), "Listener has already been released.");
    l.n(paramn.b.a(), "Listener has already been released.");
    m m = paramn.a;
    u u = paramn.b;
    Runnable runnable = paramn.c;
    return this.j.w(this, m, u, runnable);
  }
  
  @ResultIgnorabilityUnspecified
  public j<Boolean> n(i.a<?> parama, int paramInt) {
    l.n(parama, "Listener key cannot be null.");
    return this.j.x(this, parama, paramInt);
  }
  
  public <A extends a.b, T extends a<? extends dbxyzptlk.pB.h, A>> T o(T paramT) {
    A(1, (a)paramT);
    return paramT;
  }
  
  @ResultIgnorabilityUnspecified
  public <TResult, A extends a.b> j<TResult> p(s<A, TResult> params) {
    return B(1, params);
  }
  
  public String q(Context paramContext) {
    return null;
  }
  
  public final dbxyzptlk.qB.b<O> r() {
    return this.e;
  }
  
  public O s() {
    return (O)this.d;
  }
  
  public Context t() {
    return this.a;
  }
  
  public String u() {
    return this.b;
  }
  
  public Looper v() {
    return this.f;
  }
  
  public <L> i<L> w(L paramL, String paramString) {
    return j.a(paramL, this.f, paramString);
  }
  
  public final int x() {
    return this.g;
  }
  
  public final a.f y(Looper paramLooper, j0 paramj0) {
    c c1 = i().a();
    a.a<j0, a.d> a1 = (a.a)l.m(this.c.a());
    a.d d1 = this.d;
    paramj0 = a1.c(this.a, paramLooper, c1, d1, (c.b)paramj0, (c.c)paramj0);
    String str = u();
    if (str != null && paramj0 instanceof dbxyzptlk.sB.b)
      ((dbxyzptlk.sB.b)paramj0).U(str); 
    if (str != null && paramj0 instanceof k)
      ((k)paramj0).w(str); 
    return (a.f)paramj0;
  }
  
  public final J0 z(Context paramContext, Handler paramHandler) {
    return new J0(paramContext, paramHandler, i().a());
  }
  
  public static class a {
    public static final a c = (new a()).a();
    
    public final q a;
    
    public final Looper b;
    
    public a(q param1q, Account param1Account, Looper param1Looper) {
      this.a = param1q;
      this.b = param1Looper;
    }
    
    public static class a {
      public q a;
      
      public Looper b;
      
      public b.a a() {
        if (this.a == null)
          this.a = (q)new dbxyzptlk.qB.a(); 
        if (this.b == null)
          this.b = Looper.getMainLooper(); 
        return new b.a(this.a, null, this.b, null);
      }
      
      public a b(q param2q) {
        l.n(param2q, "StatusExceptionMapper must not be null.");
        this.a = param2q;
        return this;
      }
    }
  }
  
  public static class a {
    public q a;
    
    public Looper b;
    
    public b.a a() {
      if (this.a == null)
        this.a = (q)new dbxyzptlk.qB.a(); 
      if (this.b == null)
        this.b = Looper.getMainLooper(); 
      return new b.a(this.a, null, this.b, null);
    }
    
    public a b(q param1q) {
      l.n(param1q, "StatusExceptionMapper must not be null.");
      this.a = param1q;
      return this;
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\google\android\gms\common\api\b.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */