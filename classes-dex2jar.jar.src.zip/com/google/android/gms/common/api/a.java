package com.google.android.gms.common.api;

import android.accounts.Account;
import android.content.Context;
import android.content.Intent;
import android.os.Looper;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.common.Feature;
import dbxyzptlk.qB.l;
import dbxyzptlk.sB.l;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.Collections;
import java.util.List;
import java.util.Set;

public final class a<O extends a.d> {
  public final a a;
  
  public final g b;
  
  public final String c;
  
  public <C extends f> a(String paramString, a<C, O> parama, g<C> paramg) {
    l.n(parama, "Cannot construct an Api with a null ClientBuilder");
    l.n(paramg, "Cannot construct an Api with a null ClientKey");
    this.c = paramString;
    this.a = parama;
    this.b = paramg;
  }
  
  public final a a() {
    return this.a;
  }
  
  public final c b() {
    return this.b;
  }
  
  public final e c() {
    return this.a;
  }
  
  public final String d() {
    return this.c;
  }
  
  public static abstract class a<T extends f, O> extends e<T, O> {
    @Deprecated
    public T c(Context param1Context, Looper param1Looper, dbxyzptlk.sB.c param1c, O param1O, c.b param1b, c.c param1c1) {
      return d(param1Context, param1Looper, param1c, param1O, param1b, param1c1);
    }
    
    public T d(Context param1Context, Looper param1Looper, dbxyzptlk.sB.c param1c, O param1O, dbxyzptlk.qB.d param1d, l param1l) {
      throw new UnsupportedOperationException("buildClient must be implemented");
    }
  }
  
  public static interface b {}
  
  public static class c<C extends b> {}
  
  public static interface d {
    public static final d t0 = new d(null);
    
    public static interface a extends c, d {
      Account e();
    }
    
    public static interface b extends c {
      GoogleSignInAccount x();
    }
    
    public static interface c extends d {}
    
    class d {}
  }
  
  public static interface a extends d.c, d {
    Account e();
  }
  
  public static interface b extends d.c {
    GoogleSignInAccount x();
  }
  
  public static interface c extends d {}
  
  class a {}
  
  public static abstract class e<T extends b, O> {
    public List<Scope> a(O param1O) {
      return Collections.emptyList();
    }
    
    public int b() {
      return Integer.MAX_VALUE;
    }
  }
  
  public static interface f extends b {
    boolean a();
    
    Intent b();
    
    boolean c();
    
    void d(String param1String);
    
    void e();
    
    boolean f();
    
    boolean h();
    
    Set<Scope> j();
    
    void k(com.google.android.gms.common.internal.b param1b, Set<Scope> param1Set);
    
    void l(String param1String, FileDescriptor param1FileDescriptor, PrintWriter param1PrintWriter, String[] param1ArrayOfString);
    
    int m();
    
    String o();
    
    void p(dbxyzptlk.sB.b.c param1c);
    
    boolean q();
    
    void r(dbxyzptlk.sB.b.e param1e);
    
    Feature[] t();
    
    String u();
  }
  
  public static final class g<C extends f> extends c<C> {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\google\android\gms\common\api\a.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */