package com.google.android.gms.common.api;

public class ApiException extends Exception {
  @Deprecated
  public final Status a;
  
  public ApiException(Status paramStatus) {
    super(stringBuilder.toString());
    String str;
    this.a = paramStatus;
  }
  
  public Status a() {
    return this.a;
  }
  
  public int b() {
    return this.a.O();
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\google\android\gms\common\api\ApiException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */