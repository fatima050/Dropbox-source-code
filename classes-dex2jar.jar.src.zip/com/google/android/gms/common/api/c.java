package com.google.android.gms.common.api;

import android.content.Context;
import android.os.Looper;
import com.google.errorprone.annotations.ResultIgnorabilityUnspecified;
import dbxyzptlk.qB.P0;
import dbxyzptlk.qB.d;
import dbxyzptlk.qB.l;
import dbxyzptlk.qB.p;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.Collections;
import java.util.Set;
import java.util.WeakHashMap;

@Deprecated
public abstract class c {
  public static final Set a = Collections.newSetFromMap(new WeakHashMap<>());
  
  public static Set<c> i() {
    synchronized (a) {
      return null;
    } 
  }
  
  public abstract void d();
  
  public abstract void e();
  
  public abstract void f(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString);
  
  @ResultIgnorabilityUnspecified
  public <A extends a.b, R extends dbxyzptlk.pB.h, T extends com.google.android.gms.common.api.internal.a<R, A>> T g(T paramT) {
    throw new UnsupportedOperationException();
  }
  
  @ResultIgnorabilityUnspecified
  public <A extends a.b, T extends com.google.android.gms.common.api.internal.a<? extends dbxyzptlk.pB.h, A>> T h(T paramT) {
    throw new UnsupportedOperationException();
  }
  
  public <C extends a.f> C j(a.c<C> paramc) {
    throw new UnsupportedOperationException();
  }
  
  public Context k() {
    throw new UnsupportedOperationException();
  }
  
  public Looper l() {
    throw new UnsupportedOperationException();
  }
  
  public abstract boolean m();
  
  public abstract boolean n();
  
  public boolean o(p paramp) {
    throw new UnsupportedOperationException();
  }
  
  public void p() {
    throw new UnsupportedOperationException();
  }
  
  public abstract void q(c paramc);
  
  public abstract void r(b paramb);
  
  public abstract void s(c paramc);
  
  public void t(P0 paramP0) {
    throw new UnsupportedOperationException();
  }
  
  class c {}
  
  @Deprecated
  public static interface b extends d {}
  
  @Deprecated
  public static interface c extends l {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\google\android\gms\common\api\c.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */