package com.google.android.gms.measurement.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import dbxyzptlk.WB.b6;
import dbxyzptlk.WB.c6;
import dbxyzptlk.sB.l;
import dbxyzptlk.tB.a;

public final class zznt extends AbstractSafeParcelable {
  public static final Parcelable.Creator<zznt> CREATOR = (Parcelable.Creator<zznt>)new c6();
  
  public final int a;
  
  public final String b;
  
  public final long c;
  
  public final Long d;
  
  public final Float e;
  
  public final String f;
  
  public final String g;
  
  public final Double h;
  
  public zznt(int paramInt, String paramString1, long paramLong, Long paramLong1, Float paramFloat, String paramString2, String paramString3, Double paramDouble) {
    this.a = paramInt;
    this.b = paramString1;
    this.c = paramLong;
    this.d = paramLong1;
    paramString1 = null;
    this.e = null;
    if (paramInt == 1) {
      Double double_;
      if (paramFloat != null)
        double_ = Double.valueOf(paramFloat.doubleValue()); 
      this.h = double_;
    } else {
      this.h = paramDouble;
    } 
    this.f = paramString2;
    this.g = paramString3;
  }
  
  public zznt(b6 paramb6) {
    this(paramb6.c, paramb6.d, paramb6.e, paramb6.b);
  }
  
  public zznt(String paramString1, long paramLong, Object paramObject, String paramString2) {
    l.g(paramString1);
    this.a = 2;
    this.b = paramString1;
    this.c = paramLong;
    this.g = paramString2;
    if (paramObject == null) {
      this.d = null;
      this.e = null;
      this.h = null;
      this.f = null;
      return;
    } 
    if (paramObject instanceof Long) {
      this.d = (Long)paramObject;
      this.e = null;
      this.h = null;
      this.f = null;
      return;
    } 
    if (paramObject instanceof String) {
      this.d = null;
      this.e = null;
      this.h = null;
      this.f = (String)paramObject;
      return;
    } 
    if (paramObject instanceof Double) {
      this.d = null;
      this.e = null;
      this.h = (Double)paramObject;
      this.f = null;
      return;
    } 
    throw new IllegalArgumentException("User attribute given of un-supported type");
  }
  
  public final Object A() {
    Long long_ = this.d;
    if (long_ != null)
      return long_; 
    Double double_ = this.h;
    if (double_ != null)
      return double_; 
    String str = this.f;
    return (str != null) ? str : null;
  }
  
  public final void writeToParcel(Parcel paramParcel, int paramInt) {
    paramInt = a.a(paramParcel);
    a.k(paramParcel, 1, this.a);
    a.p(paramParcel, 2, this.b, false);
    a.m(paramParcel, 3, this.c);
    a.n(paramParcel, 4, this.d, false);
    a.i(paramParcel, 5, null, false);
    a.p(paramParcel, 6, this.f, false);
    a.p(paramParcel, 7, this.g, false);
    a.h(paramParcel, 8, this.h, false);
    a.b(paramParcel, paramInt);
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\google\android\gms\measurement\internal\zznt.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */