package com.google.android.gms.measurement.internal;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import dbxyzptlk.WB.B;
import dbxyzptlk.WB.C;
import dbxyzptlk.tB.a;
import java.util.Iterator;

public final class zzbc extends AbstractSafeParcelable implements Iterable<String> {
  public static final Parcelable.Creator<zzbc> CREATOR = (Parcelable.Creator<zzbc>)new C();
  
  public final Bundle a;
  
  public zzbc(Bundle paramBundle) {
    this.a = paramBundle;
  }
  
  public final int A() {
    return this.a.size();
  }
  
  public final Double Q(String paramString) {
    return Double.valueOf(this.a.getDouble(paramString));
  }
  
  public final String Q1(String paramString) {
    return this.a.getString(paramString);
  }
  
  public final Bundle Y() {
    return new Bundle(this.a);
  }
  
  public final Long i0(String paramString) {
    return Long.valueOf(this.a.getLong(paramString));
  }
  
  public final Iterator<String> iterator() {
    return (Iterator<String>)new B(this);
  }
  
  public final Object s0(String paramString) {
    return this.a.get(paramString);
  }
  
  public final String toString() {
    return this.a.toString();
  }
  
  public final void writeToParcel(Parcel paramParcel, int paramInt) {
    paramInt = a.a(paramParcel);
    a.e(paramParcel, 2, Y(), false);
    a.b(paramParcel, paramInt);
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\google\android\gms\measurement\internal\zzbc.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */