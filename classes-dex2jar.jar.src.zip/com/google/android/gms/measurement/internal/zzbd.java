package com.google.android.gms.measurement.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import dbxyzptlk.WB.E;
import dbxyzptlk.sB.l;
import dbxyzptlk.tB.a;

public final class zzbd extends AbstractSafeParcelable {
  public static final Parcelable.Creator<zzbd> CREATOR = (Parcelable.Creator<zzbd>)new E();
  
  public final String a;
  
  public final zzbc b;
  
  public final String c;
  
  public final long d;
  
  public zzbd(zzbd paramzzbd, long paramLong) {
    l.m(paramzzbd);
    this.a = paramzzbd.a;
    this.b = paramzzbd.b;
    this.c = paramzzbd.c;
    this.d = paramLong;
  }
  
  public zzbd(String paramString1, zzbc paramzzbc, String paramString2, long paramLong) {
    this.a = paramString1;
    this.b = paramzzbc;
    this.c = paramString2;
    this.d = paramLong;
  }
  
  public final String toString() {
    String str2 = this.c;
    String str3 = this.a;
    String str1 = String.valueOf(this.b);
    StringBuilder stringBuilder = new StringBuilder("origin=");
    stringBuilder.append(str2);
    stringBuilder.append(",name=");
    stringBuilder.append(str3);
    stringBuilder.append(",params=");
    stringBuilder.append(str1);
    return stringBuilder.toString();
  }
  
  public final void writeToParcel(Parcel paramParcel, int paramInt) {
    int i = a.a(paramParcel);
    a.p(paramParcel, 2, this.a, false);
    a.o(paramParcel, 3, (Parcelable)this.b, paramInt, false);
    a.p(paramParcel, 4, this.c, false);
    a.m(paramParcel, 5, this.d);
    a.b(paramParcel, i);
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\google\android\gms\measurement\internal\zzbd.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */