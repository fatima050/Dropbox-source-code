package com.google.android.gms.measurement.internal;

import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import dbxyzptlk.WB.H5;
import dbxyzptlk.sB.l;
import dbxyzptlk.tB.a;
import java.util.List;

public final class zzo extends AbstractSafeParcelable {
  public static final Parcelable.Creator<zzo> CREATOR = (Parcelable.Creator<zzo>)new H5();
  
  public final int A;
  
  public final String B;
  
  public final int C;
  
  public final long D;
  
  public final String E;
  
  public final String F;
  
  public final String a;
  
  public final String b;
  
  public final String c;
  
  public final String d;
  
  public final long e;
  
  public final long f;
  
  public final String g;
  
  public final boolean h;
  
  public final boolean i;
  
  public final long j;
  
  public final String k;
  
  @Deprecated
  public final long l;
  
  public final long m;
  
  public final int n;
  
  public final boolean o;
  
  public final boolean p;
  
  public final String q;
  
  public final Boolean r;
  
  public final long s;
  
  public final List<String> t;
  
  public final String u;
  
  public final String v;
  
  public final String w;
  
  public final String x;
  
  public final boolean y;
  
  public final long z;
  
  public zzo(String paramString1, String paramString2, String paramString3, long paramLong1, String paramString4, long paramLong2, long paramLong3, String paramString5, boolean paramBoolean1, boolean paramBoolean2, String paramString6, long paramLong4, long paramLong5, int paramInt1, boolean paramBoolean3, boolean paramBoolean4, String paramString7, Boolean paramBoolean, long paramLong6, List<String> paramList, String paramString8, String paramString9, String paramString10, String paramString11, boolean paramBoolean5, long paramLong7, int paramInt2, String paramString12, int paramInt3, long paramLong8, String paramString13, String paramString14) {
    l.g(paramString1);
    this.a = paramString1;
    if (TextUtils.isEmpty(paramString2))
      paramString2 = null; 
    this.b = paramString2;
    this.c = paramString3;
    this.j = paramLong1;
    this.d = paramString4;
    this.e = paramLong2;
    this.f = paramLong3;
    this.g = paramString5;
    this.h = paramBoolean1;
    this.i = paramBoolean2;
    this.k = paramString6;
    this.l = paramLong4;
    this.m = paramLong5;
    this.n = paramInt1;
    this.o = paramBoolean3;
    this.p = paramBoolean4;
    this.q = paramString7;
    this.r = paramBoolean;
    this.s = paramLong6;
    this.t = paramList;
    this.u = null;
    this.v = paramString9;
    this.w = paramString10;
    this.x = paramString11;
    this.y = paramBoolean5;
    this.z = paramLong7;
    this.A = paramInt2;
    this.B = paramString12;
    this.C = paramInt3;
    this.D = paramLong8;
    this.E = paramString13;
    this.F = paramString14;
  }
  
  public zzo(String paramString1, String paramString2, String paramString3, String paramString4, long paramLong1, long paramLong2, String paramString5, boolean paramBoolean1, boolean paramBoolean2, long paramLong3, String paramString6, long paramLong4, long paramLong5, int paramInt1, boolean paramBoolean3, boolean paramBoolean4, String paramString7, Boolean paramBoolean, long paramLong6, List<String> paramList, String paramString8, String paramString9, String paramString10, String paramString11, boolean paramBoolean5, long paramLong7, int paramInt2, String paramString12, int paramInt3, long paramLong8, String paramString13, String paramString14) {
    this.a = paramString1;
    this.b = paramString2;
    this.c = paramString3;
    this.j = paramLong3;
    this.d = paramString4;
    this.e = paramLong1;
    this.f = paramLong2;
    this.g = paramString5;
    this.h = paramBoolean1;
    this.i = paramBoolean2;
    this.k = paramString6;
    this.l = paramLong4;
    this.m = paramLong5;
    this.n = paramInt1;
    this.o = paramBoolean3;
    this.p = paramBoolean4;
    this.q = paramString7;
    this.r = paramBoolean;
    this.s = paramLong6;
    this.t = paramList;
    this.u = paramString8;
    this.v = paramString9;
    this.w = paramString10;
    this.x = paramString11;
    this.y = paramBoolean5;
    this.z = paramLong7;
    this.A = paramInt2;
    this.B = paramString12;
    this.C = paramInt3;
    this.D = paramLong8;
    this.E = paramString13;
    this.F = paramString14;
  }
  
  public final void writeToParcel(Parcel paramParcel, int paramInt) {
    paramInt = a.a(paramParcel);
    a.p(paramParcel, 2, this.a, false);
    a.p(paramParcel, 3, this.b, false);
    a.p(paramParcel, 4, this.c, false);
    a.p(paramParcel, 5, this.d, false);
    a.m(paramParcel, 6, this.e);
    a.m(paramParcel, 7, this.f);
    a.p(paramParcel, 8, this.g, false);
    a.c(paramParcel, 9, this.h);
    a.c(paramParcel, 10, this.i);
    a.m(paramParcel, 11, this.j);
    a.p(paramParcel, 12, this.k, false);
    a.m(paramParcel, 13, this.l);
    a.m(paramParcel, 14, this.m);
    a.k(paramParcel, 15, this.n);
    a.c(paramParcel, 16, this.o);
    a.c(paramParcel, 18, this.p);
    a.p(paramParcel, 19, this.q, false);
    a.d(paramParcel, 21, this.r, false);
    a.m(paramParcel, 22, this.s);
    a.r(paramParcel, 23, this.t, false);
    a.p(paramParcel, 24, this.u, false);
    a.p(paramParcel, 25, this.v, false);
    a.p(paramParcel, 26, this.w, false);
    a.p(paramParcel, 27, this.x, false);
    a.c(paramParcel, 28, this.y);
    a.m(paramParcel, 29, this.z);
    a.k(paramParcel, 30, this.A);
    a.p(paramParcel, 31, this.B, false);
    a.k(paramParcel, 32, this.C);
    a.m(paramParcel, 34, this.D);
    a.p(paramParcel, 35, this.E, false);
    a.p(paramParcel, 36, this.F, false);
    a.b(paramParcel, paramInt);
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\google\android\gms\measurement\internal\zzo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */