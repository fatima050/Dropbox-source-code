package com.google.android.gms.measurement.internal;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.RemoteException;
import android.text.TextUtils;
import com.google.android.gms.common.util.DynamiteApi;
import com.google.android.gms.internal.measurement.zzdq;
import dbxyzptlk.CB.a;
import dbxyzptlk.CB.b;
import dbxyzptlk.LB.J0;
import dbxyzptlk.LB.K7;
import dbxyzptlk.LB.L0;
import dbxyzptlk.LB.M0;
import dbxyzptlk.LB.Q0;
import dbxyzptlk.V.a;
import dbxyzptlk.WB.C3;
import dbxyzptlk.WB.D;
import dbxyzptlk.WB.D3;
import dbxyzptlk.WB.E2;
import dbxyzptlk.WB.G4;
import dbxyzptlk.WB.I3;
import dbxyzptlk.WB.L3;
import dbxyzptlk.WB.O3;
import dbxyzptlk.WB.P3;
import dbxyzptlk.WB.Q2;
import dbxyzptlk.WB.V3;
import dbxyzptlk.WB.X3;
import dbxyzptlk.WB.e3;
import dbxyzptlk.WB.e6;
import dbxyzptlk.WB.f4;
import dbxyzptlk.WB.g4;
import dbxyzptlk.WB.g5;
import dbxyzptlk.WB.j4;
import dbxyzptlk.WB.r3;
import dbxyzptlk.WB.u4;
import dbxyzptlk.sB.l;
import java.util.Map;

@DynamiteApi
public class AppMeasurementDynamiteService extends J0 {
  public Q2 g = null;
  
  public final Map<Integer, C3> h = (Map<Integer, C3>)new a();
  
  public void beginAdUnitExposure(String paramString, long paramLong) throws RemoteException {
    e();
    this.g.v().w(paramString, paramLong);
  }
  
  public void clearConditionalUserProperty(String paramString1, String paramString2, Bundle paramBundle) throws RemoteException {
    e();
    this.g.F().X(paramString1, paramString2, paramBundle);
  }
  
  public void clearMeasurementEnabled(long paramLong) throws RemoteException {
    e();
    this.g.F().R(null);
  }
  
  public final void e() {
    if (this.g != null)
      return; 
    throw new IllegalStateException("Attempting to perform action before initialize.");
  }
  
  public void endAdUnitExposure(String paramString, long paramLong) throws RemoteException {
    e();
    this.g.v().B(paramString, paramLong);
  }
  
  public void generateEventId(L0 paramL0) throws RemoteException {
    e();
    long l = this.g.J().P0();
    e();
    this.g.J().O(paramL0, l);
  }
  
  public void getAppInstanceId(L0 paramL0) throws RemoteException {
    e();
    this.g.y().B((Runnable)new e3(this, paramL0));
  }
  
  public void getCachedAppInstanceId(L0 paramL0) throws RemoteException {
    e();
    h(paramL0, this.g.F().i0());
  }
  
  public void getConditionalUserProperties(String paramString1, String paramString2, L0 paramL0) throws RemoteException {
    e();
    this.g.y().B((Runnable)new g5(this, paramL0, paramString1, paramString2));
  }
  
  public void getCurrentScreenClass(L0 paramL0) throws RemoteException {
    e();
    h(paramL0, this.g.F().j0());
  }
  
  public void getCurrentScreenName(L0 paramL0) throws RemoteException {
    e();
    h(paramL0, this.g.F().k0());
  }
  
  public void getGmpAppId(L0 paramL0) throws RemoteException {
    e();
    h(paramL0, this.g.F().l0());
  }
  
  public void getMaxUserProperties(String paramString, L0 paramL0) throws RemoteException {
    e();
    this.g.F();
    l.g(paramString);
    e();
    this.g.J().N(paramL0, 25);
  }
  
  public void getSessionId(L0 paramL0) throws RemoteException {
    e();
    I3 i3 = this.g.F();
    i3.y().B((Runnable)new j4(i3, paramL0));
  }
  
  public void getTestFlag(L0 paramL0, int paramInt) throws RemoteException {
    e();
    if (paramInt != 0) {
      if (paramInt != 1) {
        if (paramInt != 2) {
          if (paramInt != 3) {
            if (paramInt == 4)
              this.g.J().S(paramL0, this.g.F().e0().booleanValue()); 
            return;
          } 
          this.g.J().N(paramL0, this.g.F().g0().intValue());
          return;
        } 
        e6 e6 = this.g.J();
        double d = this.g.F().f0().doubleValue();
        Bundle bundle = new Bundle();
        bundle.putDouble("r", d);
        try {
          paramL0.g(bundle);
          return;
        } catch (RemoteException remoteException) {
          ((r3)e6).a.l().J().b("Error returning double value to wrapper", remoteException);
          return;
        } 
      } 
      this.g.J().O((L0)remoteException, this.g.F().h0().longValue());
      return;
    } 
    this.g.J().Q((L0)remoteException, this.g.F().m0());
  }
  
  public void getUserProperties(String paramString1, String paramString2, boolean paramBoolean, L0 paramL0) throws RemoteException {
    e();
    this.g.y().B((Runnable)new f4(this, paramL0, paramString1, paramString2, paramBoolean));
  }
  
  public final void h(L0 paramL0, String paramString) {
    e();
    this.g.J().Q(paramL0, paramString);
  }
  
  public void initForTests(Map paramMap) throws RemoteException {
    e();
  }
  
  public void initialize(a parama, zzdq paramzzdq, long paramLong) throws RemoteException {
    Q2 q2 = this.g;
    if (q2 == null) {
      this.g = Q2.a((Context)l.m(b.h(parama)), paramzzdq, Long.valueOf(paramLong));
      return;
    } 
    q2.l().J().a("Attempting to initialize multiple times");
  }
  
  public void isDataCollectionEnabled(L0 paramL0) throws RemoteException {
    e();
    this.g.y().B((Runnable)new G4(this, paramL0));
  }
  
  public void logEvent(String paramString1, String paramString2, Bundle paramBundle, boolean paramBoolean1, boolean paramBoolean2, long paramLong) throws RemoteException {
    e();
    this.g.F().Z(paramString1, paramString2, paramBundle, paramBoolean1, paramBoolean2, paramLong);
  }
  
  public void logEventAndBundle(String paramString1, String paramString2, Bundle paramBundle, L0 paramL0, long paramLong) throws RemoteException {
    e();
    l.g(paramString2);
    Bundle bundle = new Bundle();
    if (paramBundle != null) {
      this(paramBundle);
    } else {
      this();
    } 
    bundle.putString("_o", "app");
    zzbd zzbd = new zzbd(paramString2, new zzbc(paramBundle), "app", paramLong);
    this.g.y().B((Runnable)new E2(this, paramL0, zzbd, paramString1));
  }
  
  public void logHealthData(int paramInt, String paramString, a parama1, a parama2, a parama3) throws RemoteException {
    Object object1;
    Object object2;
    Object object3;
    e();
    a a1 = null;
    if (parama1 == null) {
      parama1 = null;
    } else {
      object1 = b.h(parama1);
    } 
    if (parama2 == null) {
      parama2 = null;
    } else {
      object2 = b.h(parama2);
    } 
    if (parama3 == null) {
      parama3 = a1;
    } else {
      object3 = b.h(parama3);
    } 
    this.g.l().w(paramInt, true, false, paramString, object1, object2, object3);
  }
  
  public void onActivityCreated(a parama, Bundle paramBundle, long paramLong) throws RemoteException {
    e();
    u4 u4 = (this.g.F()).c;
    if (u4 != null) {
      this.g.F().p0();
      u4.onActivityCreated((Activity)b.h(parama), paramBundle);
    } 
  }
  
  public void onActivityDestroyed(a parama, long paramLong) throws RemoteException {
    e();
    u4 u4 = (this.g.F()).c;
    if (u4 != null) {
      this.g.F().p0();
      u4.onActivityDestroyed((Activity)b.h(parama));
    } 
  }
  
  public void onActivityPaused(a parama, long paramLong) throws RemoteException {
    e();
    u4 u4 = (this.g.F()).c;
    if (u4 != null) {
      this.g.F().p0();
      u4.onActivityPaused((Activity)b.h(parama));
    } 
  }
  
  public void onActivityResumed(a parama, long paramLong) throws RemoteException {
    e();
    u4 u4 = (this.g.F()).c;
    if (u4 != null) {
      this.g.F().p0();
      u4.onActivityResumed((Activity)b.h(parama));
    } 
  }
  
  public void onActivitySaveInstanceState(a parama, L0 paramL0, long paramLong) throws RemoteException {
    e();
    u4 u4 = (this.g.F()).c;
    Bundle bundle = new Bundle();
    if (u4 != null) {
      this.g.F().p0();
      u4.onActivitySaveInstanceState((Activity)b.h(parama), bundle);
    } 
    try {
      paramL0.g(bundle);
      return;
    } catch (RemoteException remoteException) {
      this.g.l().J().b("Error returning bundle value to wrapper", remoteException);
      return;
    } 
  }
  
  public void onActivityStarted(a parama, long paramLong) throws RemoteException {
    e();
    u4 u4 = (this.g.F()).c;
    if (u4 != null) {
      this.g.F().p0();
      u4.onActivityStarted((Activity)b.h(parama));
    } 
  }
  
  public void onActivityStopped(a parama, long paramLong) throws RemoteException {
    e();
    u4 u4 = (this.g.F()).c;
    if (u4 != null) {
      this.g.F().p0();
      u4.onActivityStopped((Activity)b.h(parama));
    } 
  }
  
  public void performAction(Bundle paramBundle, L0 paramL0, long paramLong) throws RemoteException {
    e();
    paramL0.g(null);
  }
  
  public void registerOnMeasurementEventListener(M0 paramM0) throws RemoteException {
    a a;
    e();
    Map<Integer, C3> map = this.h;
    /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{java/util/Map<[ObjectType{java/lang/Integer}, ObjectType{dbxyzptlk/WB/C3}]>}, name=null} */
    try {
      C3 c32 = this.h.get(Integer.valueOf(paramM0.zza()));
      C3 c31 = c32;
      if (c32 == null) {
        a = new a();
        this(this, paramM0);
        this.h.put(Integer.valueOf(paramM0.zza()), a);
      } 
    } finally {}
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/util/Map<[ObjectType{java/lang/Integer}, ObjectType{dbxyzptlk/WB/C3}]>}, name=null} */
    this.g.F().K((C3)a);
  }
  
  public void resetAnalyticsData(long paramLong) throws RemoteException {
    e();
    I3 i3 = this.g.F();
    i3.T(null);
    i3.y().B((Runnable)new g4(i3, paramLong));
  }
  
  public void setConditionalUserProperty(Bundle paramBundle, long paramLong) throws RemoteException {
    e();
    if (paramBundle == null) {
      this.g.l().E().a("Conditional user property must not be null");
      return;
    } 
    this.g.F().G(paramBundle, paramLong);
  }
  
  public void setConsent(Bundle paramBundle, long paramLong) throws RemoteException {
    e();
    I3 i3 = this.g.F();
    i3.y().E((Runnable)new O3(i3, paramBundle, paramLong));
  }
  
  public void setConsentThirdParty(Bundle paramBundle, long paramLong) throws RemoteException {
    e();
    this.g.F().F(paramBundle, -20, paramLong);
  }
  
  public void setCurrentScreen(a parama, String paramString1, String paramString2, long paramLong) throws RemoteException {
    e();
    this.g.G().F((Activity)b.h(parama), paramString1, paramString2);
  }
  
  public void setDataCollectionEnabled(boolean paramBoolean) throws RemoteException {
    e();
    I3 i3 = this.g.F();
    i3.s();
    i3.y().B((Runnable)new V3(i3, paramBoolean));
  }
  
  public void setDefaultEventParameters(Bundle paramBundle) {
    e();
    I3 i3 = this.g.F();
    if (paramBundle == null) {
      paramBundle = null;
    } else {
      paramBundle = new Bundle(paramBundle);
    } 
    i3.y().B((Runnable)new L3(i3, paramBundle));
  }
  
  public void setEventInterceptor(M0 paramM0) throws RemoteException {
    e();
    b b = new b(this, paramM0);
    if (this.g.y().H()) {
      this.g.F().L((D3)b);
      return;
    } 
    this.g.y().B((Runnable)new a(this, b));
  }
  
  public void setInstanceIdProvider(Q0 paramQ0) throws RemoteException {
    e();
  }
  
  public void setMeasurementEnabled(boolean paramBoolean, long paramLong) throws RemoteException {
    e();
    this.g.F().R(Boolean.valueOf(paramBoolean));
  }
  
  public void setMinimumSessionDuration(long paramLong) throws RemoteException {
    e();
  }
  
  public void setSessionTimeoutDuration(long paramLong) throws RemoteException {
    e();
    I3 i3 = this.g.F();
    i3.y().B((Runnable)new X3(i3, paramLong));
  }
  
  public void setSgtmDebugInfo(Intent paramIntent) throws RemoteException {
    e();
    I3 i3 = this.g.F();
    if (K7.a() && i3.a().D(null, D.w0)) {
      Uri uri = paramIntent.getData();
      if (uri == null) {
        i3.l().H().a("Activity intent has no data. Preview Mode was not enabled.");
        return;
      } 
      String str2 = uri.getQueryParameter("sgtm_debug_enable");
      if (str2 == null || !str2.equals("1")) {
        i3.l().H().a("Preview Mode was not enabled.");
        i3.a().I(null);
        return;
      } 
      String str1 = uri.getQueryParameter("sgtm_preview_key");
      if (!TextUtils.isEmpty(str1)) {
        i3.l().H().b("Preview Mode was enabled. Using the sgtmPreviewKey: ", str1);
        i3.a().I(str1);
      } 
    } 
  }
  
  public void setUserId(String paramString, long paramLong) throws RemoteException {
    e();
    I3 i3 = this.g.F();
    if (paramString != null && TextUtils.isEmpty(paramString)) {
      ((r3)i3).a.l().J().a("User ID must be non-empty or null");
      return;
    } 
    i3.y().B((Runnable)new P3(i3, paramString));
    i3.c0(null, "_id", paramString, true, paramLong);
  }
  
  public void setUserProperty(String paramString1, String paramString2, a parama, boolean paramBoolean, long paramLong) throws RemoteException {
    e();
    Object object = b.h(parama);
    this.g.F().c0(paramString1, paramString2, object, paramBoolean, paramLong);
  }
  
  public void unregisterOnMeasurementEventListener(M0 paramM0) throws RemoteException {
    Map<Integer, C3> map;
    a a;
    e();
    synchronized (this.h) {
      C3 c32 = this.h.remove(Integer.valueOf(paramM0.zza()));
      C3 c31 = c32;
      if (c32 == null)
        a = new a(this, paramM0); 
      this.g.F().y0((C3)a);
      return;
    } 
  }
  
  class AppMeasurementDynamiteService {}
  
  class AppMeasurementDynamiteService {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\google\android\gms\measurement\internal\AppMeasurementDynamiteService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */