package com.google.android.gms.dynamite;

import android.content.Context;

public final class f implements DynamiteModule.a {
  public final DynamiteModule.a.b a(Context paramContext, String paramString, DynamiteModule.a.a parama) throws DynamiteModule.LoadingException {
    DynamiteModule.a.b b1 = new DynamiteModule.a.b();
    int i = parama.b(paramContext, paramString);
    b1.a = i;
    byte b = 1;
    int j = 0;
    if (i != 0) {
      i = parama.a(paramContext, paramString, false);
      b1.b = i;
    } else {
      i = parama.a(paramContext, paramString, true);
      b1.b = i;
    } 
    int k = b1.a;
    if (k == 0) {
      if (i == 0) {
        b = 0;
        b1.c = b;
        return b1;
      } 
    } else {
      j = k;
    } 
    if (j >= i)
      b = -1; 
    b1.c = b;
    return b1;
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\google\android\gms\dynamite\f.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */