package com.google.android.gms.dynamite.descriptors.com.google.android.gms.measurement.dynamite;

import com.google.android.gms.common.util.DynamiteApi;

@DynamiteApi
public class ModuleDescriptor {
  public static final String MODULE_ID = "com.google.android.gms.measurement.dynamite";
  
  public static final int MODULE_VERSION = 112;
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\google\android\gms\dynamite\descriptors\com\google\android\gms\measurement\dynamite\ModuleDescriptor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */