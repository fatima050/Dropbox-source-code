package com.google.android.gms.dynamite;

import android.content.ContentResolver;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.ProviderInfo;
import android.database.Cursor;
import android.net.Uri;
import android.os.IBinder;
import android.os.IInterface;
import android.util.Log;
import com.google.android.gms.common.util.DynamiteApi;
import com.google.errorprone.annotations.ResultIgnorabilityUnspecified;
import dbxyzptlk.DB.f;
import dbxyzptlk.DB.h;
import dbxyzptlk.DB.i;
import dbxyzptlk.DB.j;
import dbxyzptlk.DB.k;
import dbxyzptlk.oB.d;
import dbxyzptlk.sB.j;
import dbxyzptlk.sB.l;
import io.sentry.android.core.r0;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;

public final class DynamiteModule {
  public static final a b;
  
  public static final a c;
  
  public static final a d;
  
  public static final a e;
  
  public static final a f;
  
  public static final a g;
  
  public static Boolean h;
  
  public static String i;
  
  public static boolean j = false;
  
  public static int k = -1;
  
  public static Boolean l;
  
  public static final ThreadLocal m = new ThreadLocal();
  
  public static final ThreadLocal n = (ThreadLocal)new f();
  
  public static final a.a o = new a();
  
  public static final a p;
  
  public static j q;
  
  public static k r;
  
  public final Context a;
  
  static {
    b = new b();
    c = new c();
    d = new d();
    e = new e();
    f = new f();
    g = new g();
    p = new h();
  }
  
  public DynamiteModule(Context paramContext) {
    l.m(paramContext);
    this.a = paramContext;
  }
  
  public static int a(Context paramContext, String paramString) {
    try {
      StringBuilder stringBuilder1;
      ClassLoader classLoader = paramContext.getApplicationContext().getClassLoader();
      StringBuilder stringBuilder2 = new StringBuilder();
      this();
      stringBuilder2.append("com.google.android.gms.dynamite.descriptors.");
      stringBuilder2.append(paramString);
      stringBuilder2.append(".ModuleDescriptor");
      Class<?> clazz = classLoader.loadClass(stringBuilder2.toString());
      Field field1 = clazz.getDeclaredField("MODULE_ID");
      Field field2 = clazz.getDeclaredField("MODULE_VERSION");
      if (!j.b(field1.get(null), paramString)) {
        String str = String.valueOf(field1.get(null));
        stringBuilder1 = new StringBuilder();
        this();
        stringBuilder1.append("Module descriptor id '");
        stringBuilder1.append(str);
        stringBuilder1.append("' didn't match expected id '");
        stringBuilder1.append(paramString);
        stringBuilder1.append("'");
        r0.d("DynamiteModule", stringBuilder1.toString());
        return 0;
      } 
      return stringBuilder1.getInt(null);
    } catch (ClassNotFoundException classNotFoundException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Local module descriptor class for ");
      stringBuilder.append(paramString);
      stringBuilder.append(" not found.");
      r0.f("DynamiteModule", stringBuilder.toString());
    } catch (Exception exception) {
      r0.d("DynamiteModule", "Failed to load module descriptor class: ".concat(String.valueOf(exception.getMessage())));
    } 
    return 0;
  }
  
  public static int b(Context paramContext, String paramString) {
    return e(paramContext, paramString, false);
  }
  
  @ResultIgnorabilityUnspecified
  public static DynamiteModule d(Context paramContext, a parama, String paramString) throws LoadingException {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual getApplicationContext : ()Landroid/content/Context;
    //   4: astore #15
    //   6: aload #15
    //   8: ifnull -> 2233
    //   11: getstatic com/google/android/gms/dynamite/DynamiteModule.m : Ljava/lang/ThreadLocal;
    //   14: astore #12
    //   16: aload #12
    //   18: invokevirtual get : ()Ljava/lang/Object;
    //   21: checkcast dbxyzptlk/DB/h
    //   24: astore #7
    //   26: new dbxyzptlk/DB/h
    //   29: dup
    //   30: aconst_null
    //   31: invokespecial <init> : (Ldbxyzptlk/DB/g;)V
    //   34: astore #13
    //   36: aload #12
    //   38: aload #13
    //   40: invokevirtual set : (Ljava/lang/Object;)V
    //   43: getstatic com/google/android/gms/dynamite/DynamiteModule.n : Ljava/lang/ThreadLocal;
    //   46: astore #9
    //   48: aload #9
    //   50: invokevirtual get : ()Ljava/lang/Object;
    //   53: checkcast java/lang/Long
    //   56: astore #14
    //   58: aload #14
    //   60: invokevirtual longValue : ()J
    //   63: lstore #5
    //   65: aload #7
    //   67: astore #8
    //   69: aload #9
    //   71: invokestatic elapsedRealtime : ()J
    //   74: invokestatic valueOf : (J)Ljava/lang/Long;
    //   77: invokevirtual set : (Ljava/lang/Object;)V
    //   80: aload #7
    //   82: astore #8
    //   84: aload_1
    //   85: aload_0
    //   86: aload_2
    //   87: getstatic com/google/android/gms/dynamite/DynamiteModule.o : Lcom/google/android/gms/dynamite/DynamiteModule$a$a;
    //   90: invokeinterface a : (Landroid/content/Context;Ljava/lang/String;Lcom/google/android/gms/dynamite/DynamiteModule$a$a;)Lcom/google/android/gms/dynamite/DynamiteModule$a$b;
    //   95: astore #16
    //   97: aload #7
    //   99: astore #8
    //   101: aload #16
    //   103: getfield a : I
    //   106: istore #4
    //   108: aload #7
    //   110: astore #8
    //   112: aload #16
    //   114: getfield b : I
    //   117: istore_3
    //   118: aload #7
    //   120: astore #8
    //   122: new java/lang/StringBuilder
    //   125: astore #9
    //   127: aload #7
    //   129: astore #8
    //   131: aload #9
    //   133: invokespecial <init> : ()V
    //   136: aload #7
    //   138: astore #8
    //   140: aload #9
    //   142: ldc 'Considering local module '
    //   144: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   147: pop
    //   148: aload #7
    //   150: astore #8
    //   152: aload #9
    //   154: aload_2
    //   155: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   158: pop
    //   159: aload #7
    //   161: astore #8
    //   163: aload #9
    //   165: ldc ':'
    //   167: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   170: pop
    //   171: aload #7
    //   173: astore #8
    //   175: aload #9
    //   177: iload #4
    //   179: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   182: pop
    //   183: aload #7
    //   185: astore #8
    //   187: aload #9
    //   189: ldc ' and remote module '
    //   191: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   194: pop
    //   195: aload #7
    //   197: astore #8
    //   199: aload #9
    //   201: aload_2
    //   202: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   205: pop
    //   206: aload #7
    //   208: astore #8
    //   210: aload #9
    //   212: ldc ':'
    //   214: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   217: pop
    //   218: aload #7
    //   220: astore #8
    //   222: aload #9
    //   224: iload_3
    //   225: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   228: pop
    //   229: aload #7
    //   231: astore #8
    //   233: ldc 'DynamiteModule'
    //   235: aload #9
    //   237: invokevirtual toString : ()Ljava/lang/String;
    //   240: invokestatic i : (Ljava/lang/String;Ljava/lang/String;)I
    //   243: pop
    //   244: aload #7
    //   246: astore #8
    //   248: aload #16
    //   250: getfield c : I
    //   253: istore #4
    //   255: iload #4
    //   257: ifeq -> 2040
    //   260: iload #4
    //   262: istore_3
    //   263: iload #4
    //   265: iconst_m1
    //   266: if_icmpne -> 294
    //   269: aload #7
    //   271: astore #8
    //   273: aload #16
    //   275: getfield a : I
    //   278: ifeq -> 2040
    //   281: iconst_m1
    //   282: istore_3
    //   283: goto -> 294
    //   286: astore_0
    //   287: aload #8
    //   289: astore #7
    //   291: goto -> 2183
    //   294: iload_3
    //   295: iconst_1
    //   296: if_icmpne -> 311
    //   299: aload #7
    //   301: astore #8
    //   303: aload #16
    //   305: getfield b : I
    //   308: ifeq -> 2040
    //   311: iload_3
    //   312: iconst_m1
    //   313: if_icmpne -> 334
    //   316: aload #7
    //   318: astore #8
    //   320: aload #15
    //   322: aload_2
    //   323: invokestatic g : (Landroid/content/Context;Ljava/lang/String;)Lcom/google/android/gms/dynamite/DynamiteModule;
    //   326: astore_0
    //   327: aload #7
    //   329: astore #8
    //   331: goto -> 1897
    //   334: iload_3
    //   335: iconst_1
    //   336: if_icmpne -> 1975
    //   339: aload #16
    //   341: getfield b : I
    //   344: istore #4
    //   346: ldc com/google/android/gms/dynamite/DynamiteModule
    //   348: monitorenter
    //   349: aload_0
    //   350: invokestatic j : (Landroid/content/Context;)Z
    //   353: ifeq -> 1579
    //   356: getstatic com/google/android/gms/dynamite/DynamiteModule.h : Ljava/lang/Boolean;
    //   359: astore #8
    //   361: ldc com/google/android/gms/dynamite/DynamiteModule
    //   363: monitorexit
    //   364: aload #8
    //   366: ifnull -> 1513
    //   369: aload #8
    //   371: invokevirtual booleanValue : ()Z
    //   374: ifeq -> 944
    //   377: new java/lang/StringBuilder
    //   380: astore #8
    //   382: aload #8
    //   384: invokespecial <init> : ()V
    //   387: aload #8
    //   389: ldc_w 'Selected remote version of '
    //   392: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   395: pop
    //   396: aload #8
    //   398: aload_2
    //   399: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   402: pop
    //   403: aload #8
    //   405: ldc_w ', version >= '
    //   408: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   411: pop
    //   412: aload #8
    //   414: iload #4
    //   416: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   419: pop
    //   420: ldc 'DynamiteModule'
    //   422: aload #8
    //   424: invokevirtual toString : ()Ljava/lang/String;
    //   427: invokestatic i : (Ljava/lang/String;Ljava/lang/String;)I
    //   430: pop
    //   431: ldc com/google/android/gms/dynamite/DynamiteModule
    //   433: monitorenter
    //   434: getstatic com/google/android/gms/dynamite/DynamiteModule.r : Ldbxyzptlk/DB/k;
    //   437: astore #17
    //   439: ldc com/google/android/gms/dynamite/DynamiteModule
    //   441: monitorexit
    //   442: aload #17
    //   444: ifnull -> 866
    //   447: aload #12
    //   449: invokevirtual get : ()Ljava/lang/Object;
    //   452: checkcast dbxyzptlk/DB/h
    //   455: astore #8
    //   457: aload #8
    //   459: ifnull -> 813
    //   462: aload #8
    //   464: getfield a : Landroid/database/Cursor;
    //   467: ifnull -> 813
    //   470: aload_0
    //   471: invokevirtual getApplicationContext : ()Landroid/content/Context;
    //   474: astore #12
    //   476: aload #8
    //   478: getfield a : Landroid/database/Cursor;
    //   481: astore #18
    //   483: aconst_null
    //   484: invokestatic Z2 : (Ljava/lang/Object;)Ldbxyzptlk/CB/a;
    //   487: pop
    //   488: ldc com/google/android/gms/dynamite/DynamiteModule
    //   490: monitorenter
    //   491: aload #7
    //   493: astore #11
    //   495: getstatic com/google/android/gms/dynamite/DynamiteModule.k : I
    //   498: iconst_2
    //   499: if_icmplt -> 507
    //   502: iconst_1
    //   503: istore_3
    //   504: goto -> 509
    //   507: iconst_0
    //   508: istore_3
    //   509: ldc com/google/android/gms/dynamite/DynamiteModule
    //   511: monitorexit
    //   512: iload_3
    //   513: ifeq -> 587
    //   516: aload #11
    //   518: astore #9
    //   520: aload #11
    //   522: astore #8
    //   524: aload #11
    //   526: astore #10
    //   528: ldc 'DynamiteModule'
    //   530: ldc_w 'Dynamite loader version >= 2, using loadModule2NoCrashUtils'
    //   533: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   536: pop
    //   537: aload #11
    //   539: astore #9
    //   541: aload #11
    //   543: astore #8
    //   545: aload #11
    //   547: astore #10
    //   549: aload #17
    //   551: aload #12
    //   553: invokestatic Z2 : (Ljava/lang/Object;)Ldbxyzptlk/CB/a;
    //   556: aload_2
    //   557: iload #4
    //   559: aload #18
    //   561: invokestatic Z2 : (Ljava/lang/Object;)Ldbxyzptlk/CB/a;
    //   564: invokevirtual Z2 : (Ldbxyzptlk/CB/a;Ljava/lang/String;ILdbxyzptlk/CB/a;)Ldbxyzptlk/CB/a;
    //   567: astore #12
    //   569: goto -> 640
    //   572: astore #10
    //   574: goto -> 1632
    //   577: astore #9
    //   579: goto -> 1699
    //   582: astore #9
    //   584: goto -> 1706
    //   587: aload #11
    //   589: astore #9
    //   591: aload #11
    //   593: astore #8
    //   595: aload #11
    //   597: astore #10
    //   599: ldc 'DynamiteModule'
    //   601: ldc_w 'Dynamite loader version < 2, falling back to loadModule2'
    //   604: invokestatic f : (Ljava/lang/String;Ljava/lang/String;)I
    //   607: pop
    //   608: aload #11
    //   610: astore #9
    //   612: aload #11
    //   614: astore #8
    //   616: aload #11
    //   618: astore #10
    //   620: aload #17
    //   622: aload #12
    //   624: invokestatic Z2 : (Ljava/lang/Object;)Ldbxyzptlk/CB/a;
    //   627: aload_2
    //   628: iload #4
    //   630: aload #18
    //   632: invokestatic Z2 : (Ljava/lang/Object;)Ldbxyzptlk/CB/a;
    //   635: invokevirtual h : (Ldbxyzptlk/CB/a;Ljava/lang/String;ILdbxyzptlk/CB/a;)Ldbxyzptlk/CB/a;
    //   638: astore #12
    //   640: aload #11
    //   642: astore #9
    //   644: aload #11
    //   646: astore #8
    //   648: aload #11
    //   650: astore #10
    //   652: aload #12
    //   654: invokestatic h : (Ldbxyzptlk/CB/a;)Ljava/lang/Object;
    //   657: checkcast android/content/Context
    //   660: astore #17
    //   662: aload #17
    //   664: ifnull -> 713
    //   667: aload #11
    //   669: astore #9
    //   671: aload #11
    //   673: astore #8
    //   675: aload #11
    //   677: astore #10
    //   679: new com/google/android/gms/dynamite/DynamiteModule
    //   682: astore #12
    //   684: aload #11
    //   686: astore #9
    //   688: aload #11
    //   690: astore #8
    //   692: aload #11
    //   694: astore #10
    //   696: aload #12
    //   698: aload #17
    //   700: invokespecial <init> : (Landroid/content/Context;)V
    //   703: aload #12
    //   705: astore_0
    //   706: aload #7
    //   708: astore #8
    //   710: goto -> 331
    //   713: aload #11
    //   715: astore #9
    //   717: aload #11
    //   719: astore #8
    //   721: aload #11
    //   723: astore #10
    //   725: new com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   728: astore #7
    //   730: aload #11
    //   732: astore #9
    //   734: aload #11
    //   736: astore #8
    //   738: aload #11
    //   740: astore #10
    //   742: aload #7
    //   744: ldc_w 'Failed to get module context'
    //   747: aconst_null
    //   748: invokespecial <init> : (Ljava/lang/String;Ldbxyzptlk/DB/i;)V
    //   751: aload #11
    //   753: astore #9
    //   755: aload #11
    //   757: astore #8
    //   759: aload #11
    //   761: astore #10
    //   763: aload #7
    //   765: athrow
    //   766: astore #7
    //   768: ldc com/google/android/gms/dynamite/DynamiteModule
    //   770: monitorexit
    //   771: aload #11
    //   773: astore #9
    //   775: aload #11
    //   777: astore #8
    //   779: aload #11
    //   781: astore #10
    //   783: aload #7
    //   785: athrow
    //   786: astore #10
    //   788: aload #7
    //   790: astore #9
    //   792: goto -> 1632
    //   795: astore #9
    //   797: aload #7
    //   799: astore #8
    //   801: goto -> 1699
    //   804: astore #9
    //   806: aload #7
    //   808: astore #10
    //   810: goto -> 1706
    //   813: aload #7
    //   815: astore #9
    //   817: aload #7
    //   819: astore #8
    //   821: aload #7
    //   823: astore #10
    //   825: new com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   828: astore #11
    //   830: aload #7
    //   832: astore #9
    //   834: aload #7
    //   836: astore #8
    //   838: aload #7
    //   840: astore #10
    //   842: aload #11
    //   844: ldc_w 'No result cursor'
    //   847: aconst_null
    //   848: invokespecial <init> : (Ljava/lang/String;Ldbxyzptlk/DB/i;)V
    //   851: aload #7
    //   853: astore #9
    //   855: aload #7
    //   857: astore #8
    //   859: aload #7
    //   861: astore #10
    //   863: aload #11
    //   865: athrow
    //   866: aload #7
    //   868: astore #9
    //   870: aload #7
    //   872: astore #8
    //   874: aload #7
    //   876: astore #10
    //   878: new com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   881: astore #11
    //   883: aload #7
    //   885: astore #9
    //   887: aload #7
    //   889: astore #8
    //   891: aload #7
    //   893: astore #10
    //   895: aload #11
    //   897: ldc_w 'DynamiteLoaderV2 was not cached.'
    //   900: aconst_null
    //   901: invokespecial <init> : (Ljava/lang/String;Ldbxyzptlk/DB/i;)V
    //   904: aload #7
    //   906: astore #9
    //   908: aload #7
    //   910: astore #8
    //   912: aload #7
    //   914: astore #10
    //   916: aload #11
    //   918: athrow
    //   919: astore #11
    //   921: ldc com/google/android/gms/dynamite/DynamiteModule
    //   923: monitorexit
    //   924: aload #7
    //   926: astore #9
    //   928: aload #7
    //   930: astore #8
    //   932: aload #7
    //   934: astore #10
    //   936: aload #11
    //   938: athrow
    //   939: astore #11
    //   941: goto -> 921
    //   944: aload #7
    //   946: astore #11
    //   948: aload #11
    //   950: astore #9
    //   952: aload #11
    //   954: astore #8
    //   956: aload #11
    //   958: astore #10
    //   960: new java/lang/StringBuilder
    //   963: astore #17
    //   965: aload #11
    //   967: astore #9
    //   969: aload #11
    //   971: astore #8
    //   973: aload #11
    //   975: astore #10
    //   977: aload #17
    //   979: invokespecial <init> : ()V
    //   982: aload #11
    //   984: astore #9
    //   986: aload #11
    //   988: astore #8
    //   990: aload #11
    //   992: astore #10
    //   994: aload #17
    //   996: ldc_w 'Selected remote version of '
    //   999: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1002: pop
    //   1003: aload #11
    //   1005: astore #9
    //   1007: aload #11
    //   1009: astore #8
    //   1011: aload #11
    //   1013: astore #10
    //   1015: aload #17
    //   1017: aload_2
    //   1018: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1021: pop
    //   1022: aload #11
    //   1024: astore #9
    //   1026: aload #11
    //   1028: astore #8
    //   1030: aload #11
    //   1032: astore #10
    //   1034: aload #17
    //   1036: ldc_w ', version >= '
    //   1039: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1042: pop
    //   1043: aload #11
    //   1045: astore #9
    //   1047: aload #11
    //   1049: astore #8
    //   1051: aload #11
    //   1053: astore #10
    //   1055: aload #17
    //   1057: iload #4
    //   1059: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   1062: pop
    //   1063: aload #11
    //   1065: astore #9
    //   1067: aload #11
    //   1069: astore #8
    //   1071: aload #11
    //   1073: astore #10
    //   1075: ldc 'DynamiteModule'
    //   1077: aload #17
    //   1079: invokevirtual toString : ()Ljava/lang/String;
    //   1082: invokestatic i : (Ljava/lang/String;Ljava/lang/String;)I
    //   1085: pop
    //   1086: aload #11
    //   1088: astore #9
    //   1090: aload #11
    //   1092: astore #8
    //   1094: aload #11
    //   1096: astore #10
    //   1098: aload_0
    //   1099: invokestatic k : (Landroid/content/Context;)Ldbxyzptlk/DB/j;
    //   1102: astore #17
    //   1104: aload #17
    //   1106: ifnull -> 1460
    //   1109: aload #11
    //   1111: astore #9
    //   1113: aload #11
    //   1115: astore #8
    //   1117: aload #11
    //   1119: astore #10
    //   1121: aload #17
    //   1123: invokevirtual h : ()I
    //   1126: istore_3
    //   1127: iload_3
    //   1128: iconst_3
    //   1129: if_icmplt -> 1249
    //   1132: aload #11
    //   1134: astore #9
    //   1136: aload #11
    //   1138: astore #8
    //   1140: aload #11
    //   1142: astore #10
    //   1144: aload #12
    //   1146: invokevirtual get : ()Ljava/lang/Object;
    //   1149: checkcast dbxyzptlk/DB/h
    //   1152: astore #12
    //   1154: aload #12
    //   1156: ifnull -> 1196
    //   1159: aload #11
    //   1161: astore #9
    //   1163: aload #11
    //   1165: astore #8
    //   1167: aload #11
    //   1169: astore #10
    //   1171: aload #17
    //   1173: aload_0
    //   1174: invokestatic Z2 : (Ljava/lang/Object;)Ldbxyzptlk/CB/a;
    //   1177: aload_2
    //   1178: iload #4
    //   1180: aload #12
    //   1182: getfield a : Landroid/database/Cursor;
    //   1185: invokestatic Z2 : (Ljava/lang/Object;)Ldbxyzptlk/CB/a;
    //   1188: invokevirtual v3 : (Ldbxyzptlk/CB/a;Ljava/lang/String;ILdbxyzptlk/CB/a;)Ldbxyzptlk/CB/a;
    //   1191: astore #12
    //   1193: goto -> 1351
    //   1196: aload #11
    //   1198: astore #9
    //   1200: aload #11
    //   1202: astore #8
    //   1204: aload #11
    //   1206: astore #10
    //   1208: new com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   1211: astore #7
    //   1213: aload #11
    //   1215: astore #9
    //   1217: aload #11
    //   1219: astore #8
    //   1221: aload #11
    //   1223: astore #10
    //   1225: aload #7
    //   1227: ldc_w 'No cached result cursor holder'
    //   1230: aconst_null
    //   1231: invokespecial <init> : (Ljava/lang/String;Ldbxyzptlk/DB/i;)V
    //   1234: aload #11
    //   1236: astore #9
    //   1238: aload #11
    //   1240: astore #8
    //   1242: aload #11
    //   1244: astore #10
    //   1246: aload #7
    //   1248: athrow
    //   1249: iload_3
    //   1250: iconst_2
    //   1251: if_icmpne -> 1304
    //   1254: aload #11
    //   1256: astore #9
    //   1258: aload #11
    //   1260: astore #8
    //   1262: aload #11
    //   1264: astore #10
    //   1266: ldc 'DynamiteModule'
    //   1268: ldc_w 'IDynamite loader version = 2'
    //   1271: invokestatic f : (Ljava/lang/String;Ljava/lang/String;)I
    //   1274: pop
    //   1275: aload #11
    //   1277: astore #9
    //   1279: aload #11
    //   1281: astore #8
    //   1283: aload #11
    //   1285: astore #10
    //   1287: aload #17
    //   1289: aload_0
    //   1290: invokestatic Z2 : (Ljava/lang/Object;)Ldbxyzptlk/CB/a;
    //   1293: aload_2
    //   1294: iload #4
    //   1296: invokevirtual w3 : (Ldbxyzptlk/CB/a;Ljava/lang/String;I)Ldbxyzptlk/CB/a;
    //   1299: astore #12
    //   1301: goto -> 1351
    //   1304: aload #11
    //   1306: astore #9
    //   1308: aload #11
    //   1310: astore #8
    //   1312: aload #11
    //   1314: astore #10
    //   1316: ldc 'DynamiteModule'
    //   1318: ldc_w 'Dynamite loader version < 2, falling back to createModuleContext'
    //   1321: invokestatic f : (Ljava/lang/String;Ljava/lang/String;)I
    //   1324: pop
    //   1325: aload #11
    //   1327: astore #9
    //   1329: aload #11
    //   1331: astore #8
    //   1333: aload #11
    //   1335: astore #10
    //   1337: aload #17
    //   1339: aload_0
    //   1340: invokestatic Z2 : (Ljava/lang/Object;)Ldbxyzptlk/CB/a;
    //   1343: aload_2
    //   1344: iload #4
    //   1346: invokevirtual u3 : (Ldbxyzptlk/CB/a;Ljava/lang/String;I)Ldbxyzptlk/CB/a;
    //   1349: astore #12
    //   1351: aload #11
    //   1353: astore #9
    //   1355: aload #11
    //   1357: astore #8
    //   1359: aload #11
    //   1361: astore #10
    //   1363: aload #12
    //   1365: invokestatic h : (Ldbxyzptlk/CB/a;)Ljava/lang/Object;
    //   1368: astore #12
    //   1370: aload #12
    //   1372: ifnull -> 1407
    //   1375: aload #11
    //   1377: astore #9
    //   1379: aload #11
    //   1381: astore #8
    //   1383: aload #11
    //   1385: astore #10
    //   1387: new com/google/android/gms/dynamite/DynamiteModule
    //   1390: dup
    //   1391: aload #12
    //   1393: checkcast android/content/Context
    //   1396: invokespecial <init> : (Landroid/content/Context;)V
    //   1399: astore #11
    //   1401: aload #11
    //   1403: astore_0
    //   1404: goto -> 706
    //   1407: aload #11
    //   1409: astore #9
    //   1411: aload #11
    //   1413: astore #8
    //   1415: aload #11
    //   1417: astore #10
    //   1419: new com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   1422: astore #7
    //   1424: aload #11
    //   1426: astore #9
    //   1428: aload #11
    //   1430: astore #8
    //   1432: aload #11
    //   1434: astore #10
    //   1436: aload #7
    //   1438: ldc_w 'Failed to load remote module.'
    //   1441: aconst_null
    //   1442: invokespecial <init> : (Ljava/lang/String;Ldbxyzptlk/DB/i;)V
    //   1445: aload #11
    //   1447: astore #9
    //   1449: aload #11
    //   1451: astore #8
    //   1453: aload #11
    //   1455: astore #10
    //   1457: aload #7
    //   1459: athrow
    //   1460: aload #11
    //   1462: astore #9
    //   1464: aload #11
    //   1466: astore #8
    //   1468: aload #11
    //   1470: astore #10
    //   1472: new com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   1475: astore #7
    //   1477: aload #11
    //   1479: astore #9
    //   1481: aload #11
    //   1483: astore #8
    //   1485: aload #11
    //   1487: astore #10
    //   1489: aload #7
    //   1491: ldc_w 'Failed to create IDynamiteLoader.'
    //   1494: aconst_null
    //   1495: invokespecial <init> : (Ljava/lang/String;Ldbxyzptlk/DB/i;)V
    //   1498: aload #11
    //   1500: astore #9
    //   1502: aload #11
    //   1504: astore #8
    //   1506: aload #11
    //   1508: astore #10
    //   1510: aload #7
    //   1512: athrow
    //   1513: aload #7
    //   1515: astore #9
    //   1517: aload #7
    //   1519: astore #8
    //   1521: aload #7
    //   1523: astore #10
    //   1525: new com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   1528: astore #11
    //   1530: aload #7
    //   1532: astore #9
    //   1534: aload #7
    //   1536: astore #8
    //   1538: aload #7
    //   1540: astore #10
    //   1542: aload #11
    //   1544: ldc_w 'Failed to determine which loading route to use.'
    //   1547: aconst_null
    //   1548: invokespecial <init> : (Ljava/lang/String;Ldbxyzptlk/DB/i;)V
    //   1551: aload #7
    //   1553: astore #9
    //   1555: aload #7
    //   1557: astore #8
    //   1559: aload #7
    //   1561: astore #10
    //   1563: aload #11
    //   1565: athrow
    //   1566: astore #8
    //   1568: aload #7
    //   1570: astore #10
    //   1572: aload #8
    //   1574: astore #7
    //   1576: goto -> 1614
    //   1579: aload #7
    //   1581: astore #8
    //   1583: new com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   1586: astore #9
    //   1588: aload #7
    //   1590: astore #8
    //   1592: aload #9
    //   1594: ldc_w 'Remote loading disabled'
    //   1597: aconst_null
    //   1598: invokespecial <init> : (Ljava/lang/String;Ldbxyzptlk/DB/i;)V
    //   1601: aload #7
    //   1603: astore #8
    //   1605: aload #9
    //   1607: athrow
    //   1608: astore #7
    //   1610: aload #8
    //   1612: astore #10
    //   1614: aload #10
    //   1616: astore #8
    //   1618: ldc com/google/android/gms/dynamite/DynamiteModule
    //   1620: monitorexit
    //   1621: aload #10
    //   1623: astore #9
    //   1625: aload #10
    //   1627: astore #8
    //   1629: aload #7
    //   1631: athrow
    //   1632: aload #9
    //   1634: astore #7
    //   1636: aload #9
    //   1638: astore #8
    //   1640: aload_0
    //   1641: aload #10
    //   1643: invokestatic a : (Landroid/content/Context;Ljava/lang/Throwable;)Z
    //   1646: pop
    //   1647: aload #9
    //   1649: astore #7
    //   1651: aload #9
    //   1653: astore #8
    //   1655: new com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   1658: astore #11
    //   1660: aload #9
    //   1662: astore #7
    //   1664: aload #9
    //   1666: astore #8
    //   1668: aload #11
    //   1670: ldc_w 'Failed to load remote module.'
    //   1673: aload #10
    //   1675: aconst_null
    //   1676: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Throwable;Ldbxyzptlk/DB/i;)V
    //   1679: aload #9
    //   1681: astore #7
    //   1683: aload #9
    //   1685: astore #8
    //   1687: aload #11
    //   1689: athrow
    //   1690: astore_0
    //   1691: goto -> 291
    //   1694: astore #9
    //   1696: goto -> 1759
    //   1699: aload #8
    //   1701: astore #7
    //   1703: aload #9
    //   1705: athrow
    //   1706: aload #10
    //   1708: astore #7
    //   1710: aload #10
    //   1712: astore #8
    //   1714: new com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   1717: astore #11
    //   1719: aload #10
    //   1721: astore #7
    //   1723: aload #10
    //   1725: astore #8
    //   1727: aload #11
    //   1729: ldc_w 'Failed to load remote module.'
    //   1732: aload #9
    //   1734: aconst_null
    //   1735: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Throwable;Ldbxyzptlk/DB/i;)V
    //   1738: aload #10
    //   1740: astore #7
    //   1742: aload #10
    //   1744: astore #8
    //   1746: aload #11
    //   1748: athrow
    //   1749: astore_0
    //   1750: goto -> 291
    //   1753: astore #9
    //   1755: aload #7
    //   1757: astore #8
    //   1759: aload #8
    //   1761: astore #7
    //   1763: aload #9
    //   1765: invokevirtual getMessage : ()Ljava/lang/String;
    //   1768: astore #11
    //   1770: aload #8
    //   1772: astore #7
    //   1774: new java/lang/StringBuilder
    //   1777: astore #10
    //   1779: aload #8
    //   1781: astore #7
    //   1783: aload #10
    //   1785: invokespecial <init> : ()V
    //   1788: aload #8
    //   1790: astore #7
    //   1792: aload #10
    //   1794: ldc_w 'Failed to load remote module: '
    //   1797: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1800: pop
    //   1801: aload #8
    //   1803: astore #7
    //   1805: aload #10
    //   1807: aload #11
    //   1809: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1812: pop
    //   1813: aload #8
    //   1815: astore #7
    //   1817: ldc 'DynamiteModule'
    //   1819: aload #10
    //   1821: invokevirtual toString : ()Ljava/lang/String;
    //   1824: invokestatic f : (Ljava/lang/String;Ljava/lang/String;)I
    //   1827: pop
    //   1828: aload #8
    //   1830: astore #7
    //   1832: aload #16
    //   1834: getfield a : I
    //   1837: istore_3
    //   1838: iload_3
    //   1839: ifeq -> 1947
    //   1842: aload #8
    //   1844: astore #7
    //   1846: new com/google/android/gms/dynamite/i
    //   1849: astore #10
    //   1851: aload #8
    //   1853: astore #7
    //   1855: aload #10
    //   1857: iload_3
    //   1858: iconst_0
    //   1859: invokespecial <init> : (II)V
    //   1862: aload #8
    //   1864: astore #7
    //   1866: aload_1
    //   1867: aload_0
    //   1868: aload_2
    //   1869: aload #10
    //   1871: invokeinterface a : (Landroid/content/Context;Ljava/lang/String;Lcom/google/android/gms/dynamite/DynamiteModule$a$a;)Lcom/google/android/gms/dynamite/DynamiteModule$a$b;
    //   1876: getfield c : I
    //   1879: iconst_m1
    //   1880: if_icmpne -> 1947
    //   1883: aload #8
    //   1885: astore #7
    //   1887: aload #15
    //   1889: aload_2
    //   1890: invokestatic g : (Landroid/content/Context;Ljava/lang/String;)Lcom/google/android/gms/dynamite/DynamiteModule;
    //   1893: astore_0
    //   1894: goto -> 331
    //   1897: lload #5
    //   1899: lconst_0
    //   1900: lcmp
    //   1901: ifne -> 1913
    //   1904: getstatic com/google/android/gms/dynamite/DynamiteModule.n : Ljava/lang/ThreadLocal;
    //   1907: invokevirtual remove : ()V
    //   1910: goto -> 1921
    //   1913: getstatic com/google/android/gms/dynamite/DynamiteModule.n : Ljava/lang/ThreadLocal;
    //   1916: aload #14
    //   1918: invokevirtual set : (Ljava/lang/Object;)V
    //   1921: aload #13
    //   1923: getfield a : Landroid/database/Cursor;
    //   1926: astore_1
    //   1927: aload_1
    //   1928: ifnull -> 1937
    //   1931: aload_1
    //   1932: invokeinterface close : ()V
    //   1937: getstatic com/google/android/gms/dynamite/DynamiteModule.m : Ljava/lang/ThreadLocal;
    //   1940: aload #8
    //   1942: invokevirtual set : (Ljava/lang/Object;)V
    //   1945: aload_0
    //   1946: areturn
    //   1947: aload #8
    //   1949: astore_0
    //   1950: aload_0
    //   1951: astore #8
    //   1953: new com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   1956: astore_1
    //   1957: aload_0
    //   1958: astore #8
    //   1960: aload_1
    //   1961: ldc_w 'Remote load failed. No local fallback found.'
    //   1964: aload #9
    //   1966: aconst_null
    //   1967: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Throwable;Ldbxyzptlk/DB/i;)V
    //   1970: aload_0
    //   1971: astore #8
    //   1973: aload_1
    //   1974: athrow
    //   1975: aload #7
    //   1977: astore #8
    //   1979: new com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   1982: astore_0
    //   1983: aload #7
    //   1985: astore #8
    //   1987: new java/lang/StringBuilder
    //   1990: astore_1
    //   1991: aload #7
    //   1993: astore #8
    //   1995: aload_1
    //   1996: invokespecial <init> : ()V
    //   1999: aload #7
    //   2001: astore #8
    //   2003: aload_1
    //   2004: ldc_w 'VersionPolicy returned invalid code:'
    //   2007: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2010: pop
    //   2011: aload #7
    //   2013: astore #8
    //   2015: aload_1
    //   2016: iload_3
    //   2017: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   2020: pop
    //   2021: aload #7
    //   2023: astore #8
    //   2025: aload_0
    //   2026: aload_1
    //   2027: invokevirtual toString : ()Ljava/lang/String;
    //   2030: aconst_null
    //   2031: invokespecial <init> : (Ljava/lang/String;Ldbxyzptlk/DB/i;)V
    //   2034: aload #7
    //   2036: astore #8
    //   2038: aload_0
    //   2039: athrow
    //   2040: aload #7
    //   2042: astore #8
    //   2044: new com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   2047: astore_0
    //   2048: aload #7
    //   2050: astore #8
    //   2052: aload #16
    //   2054: getfield a : I
    //   2057: istore #4
    //   2059: aload #7
    //   2061: astore #8
    //   2063: aload #16
    //   2065: getfield b : I
    //   2068: istore_3
    //   2069: aload #7
    //   2071: astore #8
    //   2073: new java/lang/StringBuilder
    //   2076: astore_1
    //   2077: aload #7
    //   2079: astore #8
    //   2081: aload_1
    //   2082: invokespecial <init> : ()V
    //   2085: aload #7
    //   2087: astore #8
    //   2089: aload_1
    //   2090: ldc_w 'No acceptable module '
    //   2093: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2096: pop
    //   2097: aload #7
    //   2099: astore #8
    //   2101: aload_1
    //   2102: aload_2
    //   2103: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2106: pop
    //   2107: aload #7
    //   2109: astore #8
    //   2111: aload_1
    //   2112: ldc_w ' found. Local version is '
    //   2115: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2118: pop
    //   2119: aload #7
    //   2121: astore #8
    //   2123: aload_1
    //   2124: iload #4
    //   2126: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   2129: pop
    //   2130: aload #7
    //   2132: astore #8
    //   2134: aload_1
    //   2135: ldc_w ' and remote version is '
    //   2138: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2141: pop
    //   2142: aload #7
    //   2144: astore #8
    //   2146: aload_1
    //   2147: iload_3
    //   2148: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   2151: pop
    //   2152: aload #7
    //   2154: astore #8
    //   2156: aload_1
    //   2157: ldc_w '.'
    //   2160: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2163: pop
    //   2164: aload #7
    //   2166: astore #8
    //   2168: aload_0
    //   2169: aload_1
    //   2170: invokevirtual toString : ()Ljava/lang/String;
    //   2173: aconst_null
    //   2174: invokespecial <init> : (Ljava/lang/String;Ldbxyzptlk/DB/i;)V
    //   2177: aload #7
    //   2179: astore #8
    //   2181: aload_0
    //   2182: athrow
    //   2183: lload #5
    //   2185: lconst_0
    //   2186: lcmp
    //   2187: ifne -> 2199
    //   2190: getstatic com/google/android/gms/dynamite/DynamiteModule.n : Ljava/lang/ThreadLocal;
    //   2193: invokevirtual remove : ()V
    //   2196: goto -> 2207
    //   2199: getstatic com/google/android/gms/dynamite/DynamiteModule.n : Ljava/lang/ThreadLocal;
    //   2202: aload #14
    //   2204: invokevirtual set : (Ljava/lang/Object;)V
    //   2207: aload #13
    //   2209: getfield a : Landroid/database/Cursor;
    //   2212: astore_1
    //   2213: aload_1
    //   2214: ifnull -> 2223
    //   2217: aload_1
    //   2218: invokeinterface close : ()V
    //   2223: getstatic com/google/android/gms/dynamite/DynamiteModule.m : Ljava/lang/ThreadLocal;
    //   2226: aload #7
    //   2228: invokevirtual set : (Ljava/lang/Object;)V
    //   2231: aload_0
    //   2232: athrow
    //   2233: new com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   2236: dup
    //   2237: ldc_w 'null application Context'
    //   2240: aconst_null
    //   2241: invokespecial <init> : (Ljava/lang/String;Ldbxyzptlk/DB/i;)V
    //   2244: athrow
    // Exception table:
    //   from	to	target	type
    //   69	80	286	finally
    //   84	97	286	finally
    //   101	108	286	finally
    //   112	118	286	finally
    //   122	127	286	finally
    //   131	136	286	finally
    //   140	148	286	finally
    //   152	159	286	finally
    //   163	171	286	finally
    //   175	183	286	finally
    //   187	195	286	finally
    //   199	206	286	finally
    //   210	218	286	finally
    //   222	229	286	finally
    //   233	244	286	finally
    //   248	255	286	finally
    //   273	281	286	finally
    //   303	311	286	finally
    //   320	327	286	finally
    //   339	346	1753	com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   339	346	1749	finally
    //   346	349	804	android/os/RemoteException
    //   346	349	795	com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   346	349	786	finally
    //   349	364	1566	finally
    //   369	434	804	android/os/RemoteException
    //   369	434	795	com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   369	434	786	finally
    //   434	442	919	finally
    //   447	457	804	android/os/RemoteException
    //   447	457	795	com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   447	457	786	finally
    //   462	491	804	android/os/RemoteException
    //   462	491	795	com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   462	491	786	finally
    //   495	502	766	finally
    //   509	512	766	finally
    //   528	537	582	android/os/RemoteException
    //   528	537	577	com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   528	537	572	finally
    //   549	569	582	android/os/RemoteException
    //   549	569	577	com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   549	569	572	finally
    //   599	608	582	android/os/RemoteException
    //   599	608	577	com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   599	608	572	finally
    //   620	640	582	android/os/RemoteException
    //   620	640	577	com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   620	640	572	finally
    //   652	662	582	android/os/RemoteException
    //   652	662	577	com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   652	662	572	finally
    //   679	684	582	android/os/RemoteException
    //   679	684	577	com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   679	684	572	finally
    //   696	703	582	android/os/RemoteException
    //   696	703	577	com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   696	703	572	finally
    //   725	730	582	android/os/RemoteException
    //   725	730	577	com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   725	730	572	finally
    //   742	751	582	android/os/RemoteException
    //   742	751	577	com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   742	751	572	finally
    //   763	766	582	android/os/RemoteException
    //   763	766	577	com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   763	766	572	finally
    //   768	771	766	finally
    //   783	786	582	android/os/RemoteException
    //   783	786	577	com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   783	786	572	finally
    //   825	830	582	android/os/RemoteException
    //   825	830	577	com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   825	830	572	finally
    //   842	851	582	android/os/RemoteException
    //   842	851	577	com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   842	851	572	finally
    //   863	866	582	android/os/RemoteException
    //   863	866	577	com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   863	866	572	finally
    //   878	883	582	android/os/RemoteException
    //   878	883	577	com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   878	883	572	finally
    //   895	904	582	android/os/RemoteException
    //   895	904	577	com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   895	904	572	finally
    //   916	919	582	android/os/RemoteException
    //   916	919	577	com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   916	919	572	finally
    //   921	924	939	finally
    //   936	939	582	android/os/RemoteException
    //   936	939	577	com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   936	939	572	finally
    //   960	965	582	android/os/RemoteException
    //   960	965	577	com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   960	965	572	finally
    //   977	982	582	android/os/RemoteException
    //   977	982	577	com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   977	982	572	finally
    //   994	1003	582	android/os/RemoteException
    //   994	1003	577	com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   994	1003	572	finally
    //   1015	1022	582	android/os/RemoteException
    //   1015	1022	577	com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   1015	1022	572	finally
    //   1034	1043	582	android/os/RemoteException
    //   1034	1043	577	com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   1034	1043	572	finally
    //   1055	1063	582	android/os/RemoteException
    //   1055	1063	577	com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   1055	1063	572	finally
    //   1075	1086	582	android/os/RemoteException
    //   1075	1086	577	com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   1075	1086	572	finally
    //   1098	1104	582	android/os/RemoteException
    //   1098	1104	577	com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   1098	1104	572	finally
    //   1121	1127	582	android/os/RemoteException
    //   1121	1127	577	com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   1121	1127	572	finally
    //   1144	1154	582	android/os/RemoteException
    //   1144	1154	577	com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   1144	1154	572	finally
    //   1171	1193	582	android/os/RemoteException
    //   1171	1193	577	com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   1171	1193	572	finally
    //   1208	1213	582	android/os/RemoteException
    //   1208	1213	577	com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   1208	1213	572	finally
    //   1225	1234	582	android/os/RemoteException
    //   1225	1234	577	com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   1225	1234	572	finally
    //   1246	1249	582	android/os/RemoteException
    //   1246	1249	577	com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   1246	1249	572	finally
    //   1266	1275	582	android/os/RemoteException
    //   1266	1275	577	com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   1266	1275	572	finally
    //   1287	1301	582	android/os/RemoteException
    //   1287	1301	577	com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   1287	1301	572	finally
    //   1316	1325	582	android/os/RemoteException
    //   1316	1325	577	com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   1316	1325	572	finally
    //   1337	1351	582	android/os/RemoteException
    //   1337	1351	577	com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   1337	1351	572	finally
    //   1363	1370	582	android/os/RemoteException
    //   1363	1370	577	com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   1363	1370	572	finally
    //   1387	1401	582	android/os/RemoteException
    //   1387	1401	577	com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   1387	1401	572	finally
    //   1419	1424	582	android/os/RemoteException
    //   1419	1424	577	com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   1419	1424	572	finally
    //   1436	1445	582	android/os/RemoteException
    //   1436	1445	577	com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   1436	1445	572	finally
    //   1457	1460	582	android/os/RemoteException
    //   1457	1460	577	com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   1457	1460	572	finally
    //   1472	1477	582	android/os/RemoteException
    //   1472	1477	577	com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   1472	1477	572	finally
    //   1489	1498	582	android/os/RemoteException
    //   1489	1498	577	com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   1489	1498	572	finally
    //   1510	1513	582	android/os/RemoteException
    //   1510	1513	577	com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   1510	1513	572	finally
    //   1525	1530	582	android/os/RemoteException
    //   1525	1530	577	com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   1525	1530	572	finally
    //   1542	1551	582	android/os/RemoteException
    //   1542	1551	577	com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   1542	1551	572	finally
    //   1563	1566	582	android/os/RemoteException
    //   1563	1566	577	com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   1563	1566	572	finally
    //   1583	1588	1608	finally
    //   1592	1601	1608	finally
    //   1605	1608	1608	finally
    //   1618	1621	1608	finally
    //   1629	1632	582	android/os/RemoteException
    //   1629	1632	577	com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   1629	1632	572	finally
    //   1640	1647	1694	com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   1640	1647	1690	finally
    //   1655	1660	1694	com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   1655	1660	1690	finally
    //   1668	1679	1694	com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   1668	1679	1690	finally
    //   1687	1690	1694	com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   1687	1690	1690	finally
    //   1703	1706	1694	com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   1703	1706	1690	finally
    //   1714	1719	1694	com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   1714	1719	1690	finally
    //   1727	1738	1694	com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   1727	1738	1690	finally
    //   1746	1749	1694	com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   1746	1749	1690	finally
    //   1763	1770	1690	finally
    //   1774	1779	1690	finally
    //   1783	1788	1690	finally
    //   1792	1801	1690	finally
    //   1805	1813	1690	finally
    //   1817	1828	1690	finally
    //   1832	1838	1690	finally
    //   1846	1851	1690	finally
    //   1855	1862	1690	finally
    //   1866	1883	1690	finally
    //   1887	1894	1690	finally
    //   1953	1957	286	finally
    //   1960	1970	286	finally
    //   1973	1975	286	finally
    //   1979	1983	286	finally
    //   1987	1991	286	finally
    //   1995	1999	286	finally
    //   2003	2011	286	finally
    //   2015	2021	286	finally
    //   2025	2034	286	finally
    //   2038	2040	286	finally
    //   2044	2048	286	finally
    //   2052	2059	286	finally
    //   2063	2069	286	finally
    //   2073	2077	286	finally
    //   2081	2085	286	finally
    //   2089	2097	286	finally
    //   2101	2107	286	finally
    //   2111	2119	286	finally
    //   2123	2130	286	finally
    //   2134	2142	286	finally
    //   2146	2152	286	finally
    //   2156	2164	286	finally
    //   2168	2177	286	finally
    //   2181	2183	286	finally
  }
  
  public static int e(Context paramContext, String paramString, boolean paramBoolean) {
    // Byte code:
    //   0: ldc com/google/android/gms/dynamite/DynamiteModule
    //   2: monitorenter
    //   3: getstatic com/google/android/gms/dynamite/DynamiteModule.h : Ljava/lang/Boolean;
    //   6: astore #10
    //   8: aconst_null
    //   9: astore #8
    //   11: aconst_null
    //   12: astore #9
    //   14: aconst_null
    //   15: astore #7
    //   17: iconst_0
    //   18: istore #4
    //   20: aload #10
    //   22: astore #6
    //   24: aload #10
    //   26: ifnonnull -> 406
    //   29: aload_0
    //   30: invokevirtual getApplicationContext : ()Landroid/content/Context;
    //   33: invokevirtual getClassLoader : ()Ljava/lang/ClassLoader;
    //   36: ldc com/google/android/gms/dynamite/DynamiteModule$DynamiteLoaderClassLoader
    //   38: invokevirtual getName : ()Ljava/lang/String;
    //   41: invokevirtual loadClass : (Ljava/lang/String;)Ljava/lang/Class;
    //   44: ldc_w 'sClassLoader'
    //   47: invokevirtual getDeclaredField : (Ljava/lang/String;)Ljava/lang/reflect/Field;
    //   50: astore #11
    //   52: aload #11
    //   54: invokevirtual getDeclaringClass : ()Ljava/lang/Class;
    //   57: astore #10
    //   59: aload #10
    //   61: monitorenter
    //   62: aload #11
    //   64: aconst_null
    //   65: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   68: checkcast java/lang/ClassLoader
    //   71: astore #6
    //   73: aload #6
    //   75: invokestatic getSystemClassLoader : ()Ljava/lang/ClassLoader;
    //   78: if_acmpne -> 94
    //   81: getstatic java/lang/Boolean.FALSE : Ljava/lang/Boolean;
    //   84: astore #6
    //   86: goto -> 327
    //   89: astore #6
    //   91: goto -> 333
    //   94: aload #6
    //   96: ifnull -> 112
    //   99: aload #6
    //   101: invokestatic h : (Ljava/lang/ClassLoader;)V
    //   104: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
    //   107: astore #6
    //   109: goto -> 327
    //   112: aload_0
    //   113: invokestatic j : (Landroid/content/Context;)Z
    //   116: ifne -> 131
    //   119: aload #10
    //   121: monitorexit
    //   122: ldc com/google/android/gms/dynamite/DynamiteModule
    //   124: monitorexit
    //   125: iconst_0
    //   126: ireturn
    //   127: astore_1
    //   128: goto -> 884
    //   131: getstatic com/google/android/gms/dynamite/DynamiteModule.j : Z
    //   134: ifne -> 313
    //   137: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
    //   140: astore #12
    //   142: aload #12
    //   144: aconst_null
    //   145: invokevirtual equals : (Ljava/lang/Object;)Z
    //   148: istore #5
    //   150: iload #5
    //   152: ifeq -> 158
    //   155: goto -> 313
    //   158: aload_0
    //   159: aload_1
    //   160: iload_2
    //   161: iconst_1
    //   162: invokestatic f : (Landroid/content/Context;Ljava/lang/String;ZZ)I
    //   165: istore_3
    //   166: getstatic com/google/android/gms/dynamite/DynamiteModule.i : Ljava/lang/String;
    //   169: astore #6
    //   171: aload #6
    //   173: ifnull -> 286
    //   176: aload #6
    //   178: invokevirtual isEmpty : ()Z
    //   181: ifeq -> 187
    //   184: goto -> 286
    //   187: invokestatic a : ()Ljava/lang/ClassLoader;
    //   190: astore #6
    //   192: aload #6
    //   194: ifnull -> 200
    //   197: goto -> 260
    //   200: getstatic android/os/Build$VERSION.SDK_INT : I
    //   203: bipush #29
    //   205: if_icmplt -> 235
    //   208: invokestatic a : ()V
    //   211: getstatic com/google/android/gms/dynamite/DynamiteModule.i : Ljava/lang/String;
    //   214: astore #6
    //   216: aload #6
    //   218: invokestatic m : (Ljava/lang/Object;)Ljava/lang/Object;
    //   221: pop
    //   222: aload #6
    //   224: invokestatic getSystemClassLoader : ()Ljava/lang/ClassLoader;
    //   227: invokestatic a : (Ljava/lang/String;Ljava/lang/ClassLoader;)Ldalvik/system/DelegateLastClassLoader;
    //   230: astore #6
    //   232: goto -> 260
    //   235: getstatic com/google/android/gms/dynamite/DynamiteModule.i : Ljava/lang/String;
    //   238: astore #6
    //   240: aload #6
    //   242: invokestatic m : (Ljava/lang/Object;)Ljava/lang/Object;
    //   245: pop
    //   246: new dbxyzptlk/DB/e
    //   249: dup
    //   250: aload #6
    //   252: invokestatic getSystemClassLoader : ()Ljava/lang/ClassLoader;
    //   255: invokespecial <init> : (Ljava/lang/String;Ljava/lang/ClassLoader;)V
    //   258: astore #6
    //   260: aload #6
    //   262: invokestatic h : (Ljava/lang/ClassLoader;)V
    //   265: aload #11
    //   267: aconst_null
    //   268: aload #6
    //   270: invokevirtual set : (Ljava/lang/Object;Ljava/lang/Object;)V
    //   273: aload #12
    //   275: putstatic com/google/android/gms/dynamite/DynamiteModule.h : Ljava/lang/Boolean;
    //   278: aload #10
    //   280: monitorexit
    //   281: ldc com/google/android/gms/dynamite/DynamiteModule
    //   283: monitorexit
    //   284: iload_3
    //   285: ireturn
    //   286: aload #10
    //   288: monitorexit
    //   289: ldc com/google/android/gms/dynamite/DynamiteModule
    //   291: monitorexit
    //   292: iload_3
    //   293: ireturn
    //   294: astore #6
    //   296: aload #11
    //   298: aconst_null
    //   299: invokestatic getSystemClassLoader : ()Ljava/lang/ClassLoader;
    //   302: invokevirtual set : (Ljava/lang/Object;Ljava/lang/Object;)V
    //   305: getstatic java/lang/Boolean.FALSE : Ljava/lang/Boolean;
    //   308: astore #6
    //   310: goto -> 327
    //   313: aload #11
    //   315: aconst_null
    //   316: invokestatic getSystemClassLoader : ()Ljava/lang/ClassLoader;
    //   319: invokevirtual set : (Ljava/lang/Object;Ljava/lang/Object;)V
    //   322: getstatic java/lang/Boolean.FALSE : Ljava/lang/Boolean;
    //   325: astore #6
    //   327: aload #10
    //   329: monitorexit
    //   330: goto -> 401
    //   333: aload #10
    //   335: monitorexit
    //   336: aload #6
    //   338: athrow
    //   339: astore #6
    //   341: goto -> 351
    //   344: astore #6
    //   346: goto -> 351
    //   349: astore #6
    //   351: aload #6
    //   353: invokevirtual toString : ()Ljava/lang/String;
    //   356: astore #10
    //   358: new java/lang/StringBuilder
    //   361: astore #6
    //   363: aload #6
    //   365: invokespecial <init> : ()V
    //   368: aload #6
    //   370: ldc_w 'Failed to load module via V2: '
    //   373: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   376: pop
    //   377: aload #6
    //   379: aload #10
    //   381: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   384: pop
    //   385: ldc 'DynamiteModule'
    //   387: aload #6
    //   389: invokevirtual toString : ()Ljava/lang/String;
    //   392: invokestatic f : (Ljava/lang/String;Ljava/lang/String;)I
    //   395: pop
    //   396: getstatic java/lang/Boolean.FALSE : Ljava/lang/Boolean;
    //   399: astore #6
    //   401: aload #6
    //   403: putstatic com/google/android/gms/dynamite/DynamiteModule.h : Ljava/lang/Boolean;
    //   406: ldc com/google/android/gms/dynamite/DynamiteModule
    //   408: monitorexit
    //   409: aload #6
    //   411: invokevirtual booleanValue : ()Z
    //   414: istore #5
    //   416: iload #5
    //   418: ifeq -> 477
    //   421: aload_0
    //   422: aload_1
    //   423: iload_2
    //   424: iconst_0
    //   425: invokestatic f : (Landroid/content/Context;Ljava/lang/String;ZZ)I
    //   428: istore_3
    //   429: iload_3
    //   430: ireturn
    //   431: astore_1
    //   432: goto -> 889
    //   435: astore_1
    //   436: aload_1
    //   437: invokevirtual getMessage : ()Ljava/lang/String;
    //   440: astore #6
    //   442: new java/lang/StringBuilder
    //   445: astore_1
    //   446: aload_1
    //   447: invokespecial <init> : ()V
    //   450: aload_1
    //   451: ldc_w 'Failed to retrieve remote module version: '
    //   454: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   457: pop
    //   458: aload_1
    //   459: aload #6
    //   461: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   464: pop
    //   465: ldc 'DynamiteModule'
    //   467: aload_1
    //   468: invokevirtual toString : ()Ljava/lang/String;
    //   471: invokestatic f : (Ljava/lang/String;Ljava/lang/String;)I
    //   474: pop
    //   475: iconst_0
    //   476: ireturn
    //   477: aload_0
    //   478: invokestatic k : (Landroid/content/Context;)Ldbxyzptlk/DB/j;
    //   481: astore #10
    //   483: aload #10
    //   485: ifnonnull -> 494
    //   488: iload #4
    //   490: istore_3
    //   491: goto -> 864
    //   494: aload #9
    //   496: astore #6
    //   498: aload #10
    //   500: invokevirtual h : ()I
    //   503: istore_3
    //   504: iload_3
    //   505: iconst_3
    //   506: if_icmplt -> 710
    //   509: aload #9
    //   511: astore #6
    //   513: getstatic com/google/android/gms/dynamite/DynamiteModule.m : Ljava/lang/ThreadLocal;
    //   516: invokevirtual get : ()Ljava/lang/Object;
    //   519: checkcast dbxyzptlk/DB/h
    //   522: astore #11
    //   524: aload #11
    //   526: ifnull -> 566
    //   529: aload #9
    //   531: astore #6
    //   533: aload #11
    //   535: getfield a : Landroid/database/Cursor;
    //   538: astore #11
    //   540: aload #11
    //   542: ifnull -> 566
    //   545: aload #9
    //   547: astore #6
    //   549: aload #11
    //   551: iconst_0
    //   552: invokeinterface getInt : (I)I
    //   557: istore_3
    //   558: goto -> 864
    //   561: astore #7
    //   563: goto -> 782
    //   566: aload #9
    //   568: astore #6
    //   570: aload #10
    //   572: aload_0
    //   573: invokestatic Z2 : (Ljava/lang/Object;)Ldbxyzptlk/CB/a;
    //   576: aload_1
    //   577: iload_2
    //   578: getstatic com/google/android/gms/dynamite/DynamiteModule.n : Ljava/lang/ThreadLocal;
    //   581: invokevirtual get : ()Ljava/lang/Object;
    //   584: checkcast java/lang/Long
    //   587: invokevirtual longValue : ()J
    //   590: invokevirtual x3 : (Ldbxyzptlk/CB/a;Ljava/lang/String;ZJ)Ldbxyzptlk/CB/a;
    //   593: invokestatic h : (Ldbxyzptlk/CB/a;)Ljava/lang/Object;
    //   596: checkcast android/database/Cursor
    //   599: astore_1
    //   600: aload_1
    //   601: ifnull -> 666
    //   604: aload_1
    //   605: invokeinterface moveToFirst : ()Z
    //   610: ifne -> 616
    //   613: goto -> 666
    //   616: aload_1
    //   617: iconst_0
    //   618: invokeinterface getInt : (I)I
    //   623: istore_3
    //   624: iload_3
    //   625: ifle -> 653
    //   628: aload_1
    //   629: invokestatic i : (Landroid/database/Cursor;)Z
    //   632: istore_2
    //   633: iload_2
    //   634: ifeq -> 653
    //   637: aload #7
    //   639: astore_1
    //   640: goto -> 653
    //   643: astore #7
    //   645: goto -> 694
    //   648: astore #6
    //   650: goto -> 703
    //   653: aload_1
    //   654: ifnull -> 663
    //   657: aload_1
    //   658: invokeinterface close : ()V
    //   663: goto -> 864
    //   666: ldc 'DynamiteModule'
    //   668: ldc_w 'Failed to retrieve remote module version.'
    //   671: invokestatic f : (Ljava/lang/String;Ljava/lang/String;)I
    //   674: pop
    //   675: iload #4
    //   677: istore_3
    //   678: aload_1
    //   679: ifnull -> 864
    //   682: aload_1
    //   683: invokeinterface close : ()V
    //   688: iload #4
    //   690: istore_3
    //   691: goto -> 864
    //   694: aload_1
    //   695: astore #6
    //   697: aload #7
    //   699: astore_1
    //   700: goto -> 870
    //   703: aload #6
    //   705: astore #7
    //   707: goto -> 785
    //   710: iload_3
    //   711: iconst_2
    //   712: if_icmpne -> 747
    //   715: aload #9
    //   717: astore #6
    //   719: ldc 'DynamiteModule'
    //   721: ldc_w 'IDynamite loader version = 2, no high precision latency measurement.'
    //   724: invokestatic f : (Ljava/lang/String;Ljava/lang/String;)I
    //   727: pop
    //   728: aload #9
    //   730: astore #6
    //   732: aload #10
    //   734: aload_0
    //   735: invokestatic Z2 : (Ljava/lang/Object;)Ldbxyzptlk/CB/a;
    //   738: aload_1
    //   739: iload_2
    //   740: invokevirtual t3 : (Ldbxyzptlk/CB/a;Ljava/lang/String;Z)I
    //   743: istore_3
    //   744: goto -> 864
    //   747: aload #9
    //   749: astore #6
    //   751: ldc 'DynamiteModule'
    //   753: ldc_w 'IDynamite loader version < 2, falling back to getModuleVersion2'
    //   756: invokestatic f : (Ljava/lang/String;Ljava/lang/String;)I
    //   759: pop
    //   760: aload #9
    //   762: astore #6
    //   764: aload #10
    //   766: aload_0
    //   767: invokestatic Z2 : (Ljava/lang/Object;)Ldbxyzptlk/CB/a;
    //   770: aload_1
    //   771: iload_2
    //   772: invokevirtual Z2 : (Ldbxyzptlk/CB/a;Ljava/lang/String;Z)I
    //   775: istore_3
    //   776: goto -> 864
    //   779: goto -> 870
    //   782: aload #8
    //   784: astore_1
    //   785: aload_1
    //   786: astore #6
    //   788: aload #7
    //   790: invokevirtual getMessage : ()Ljava/lang/String;
    //   793: astore #7
    //   795: aload_1
    //   796: astore #6
    //   798: new java/lang/StringBuilder
    //   801: astore #8
    //   803: aload_1
    //   804: astore #6
    //   806: aload #8
    //   808: invokespecial <init> : ()V
    //   811: aload_1
    //   812: astore #6
    //   814: aload #8
    //   816: ldc_w 'Failed to retrieve remote module version: '
    //   819: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   822: pop
    //   823: aload_1
    //   824: astore #6
    //   826: aload #8
    //   828: aload #7
    //   830: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   833: pop
    //   834: aload_1
    //   835: astore #6
    //   837: ldc 'DynamiteModule'
    //   839: aload #8
    //   841: invokevirtual toString : ()Ljava/lang/String;
    //   844: invokestatic f : (Ljava/lang/String;Ljava/lang/String;)I
    //   847: pop
    //   848: iload #4
    //   850: istore_3
    //   851: aload_1
    //   852: ifnull -> 864
    //   855: aload_1
    //   856: invokeinterface close : ()V
    //   861: iload #4
    //   863: istore_3
    //   864: iload_3
    //   865: ireturn
    //   866: astore_1
    //   867: goto -> 779
    //   870: aload #6
    //   872: ifnull -> 882
    //   875: aload #6
    //   877: invokeinterface close : ()V
    //   882: aload_1
    //   883: athrow
    //   884: ldc com/google/android/gms/dynamite/DynamiteModule
    //   886: monitorexit
    //   887: aload_1
    //   888: athrow
    //   889: aload_0
    //   890: aload_1
    //   891: invokestatic a : (Landroid/content/Context;Ljava/lang/Throwable;)Z
    //   894: pop
    //   895: aload_1
    //   896: athrow
    //   897: astore #6
    //   899: goto -> 104
    // Exception table:
    //   from	to	target	type
    //   0	3	431	finally
    //   3	8	127	finally
    //   29	62	349	java/lang/ClassNotFoundException
    //   29	62	344	java/lang/IllegalAccessException
    //   29	62	339	java/lang/NoSuchFieldException
    //   29	62	127	finally
    //   62	86	89	finally
    //   99	104	897	com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   99	104	89	finally
    //   104	109	89	finally
    //   112	122	89	finally
    //   122	125	127	finally
    //   131	150	89	finally
    //   158	171	294	com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   158	171	89	finally
    //   176	184	294	com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   176	184	89	finally
    //   187	192	294	com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   187	192	89	finally
    //   200	232	294	com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   200	232	89	finally
    //   235	260	294	com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   235	260	89	finally
    //   260	278	294	com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   260	278	89	finally
    //   278	281	89	finally
    //   281	284	127	finally
    //   286	289	89	finally
    //   289	292	127	finally
    //   296	310	89	finally
    //   313	327	89	finally
    //   327	330	89	finally
    //   333	336	89	finally
    //   336	339	349	java/lang/ClassNotFoundException
    //   336	339	344	java/lang/IllegalAccessException
    //   336	339	339	java/lang/NoSuchFieldException
    //   336	339	127	finally
    //   351	401	127	finally
    //   401	406	127	finally
    //   406	409	127	finally
    //   409	416	431	finally
    //   421	429	435	com/google/android/gms/dynamite/DynamiteModule$LoadingException
    //   421	429	431	finally
    //   436	475	431	finally
    //   477	483	431	finally
    //   498	504	561	android/os/RemoteException
    //   498	504	866	finally
    //   513	524	561	android/os/RemoteException
    //   513	524	866	finally
    //   533	540	561	android/os/RemoteException
    //   533	540	866	finally
    //   549	558	561	android/os/RemoteException
    //   549	558	866	finally
    //   570	600	561	android/os/RemoteException
    //   570	600	866	finally
    //   604	613	648	android/os/RemoteException
    //   604	613	643	finally
    //   616	624	648	android/os/RemoteException
    //   616	624	643	finally
    //   628	633	648	android/os/RemoteException
    //   628	633	643	finally
    //   657	663	431	finally
    //   666	675	648	android/os/RemoteException
    //   666	675	643	finally
    //   682	688	431	finally
    //   719	728	561	android/os/RemoteException
    //   719	728	866	finally
    //   732	744	561	android/os/RemoteException
    //   732	744	866	finally
    //   751	760	561	android/os/RemoteException
    //   751	760	866	finally
    //   764	776	561	android/os/RemoteException
    //   764	776	866	finally
    //   788	795	866	finally
    //   798	803	866	finally
    //   806	811	866	finally
    //   814	823	866	finally
    //   826	834	866	finally
    //   837	848	866	finally
    //   855	861	431	finally
    //   875	882	431	finally
    //   882	884	431	finally
    //   884	887	127	finally
    //   887	889	431	finally
  }
  
  public static int f(Context paramContext, String paramString, boolean paramBoolean1, boolean paramBoolean2) throws LoadingException {
    Cursor cursor1;
    Cursor cursor2 = null;
    try {
      LoadingException loadingException4;
      ContentResolver contentResolver = paramContext.getContentResolver();
      long l = ((Long)n.get()).longValue();
      String str = "api_force_staging";
      boolean bool = true;
      if (true != paramBoolean1)
        str = "api"; 
      Uri.Builder builder = new Uri.Builder();
      this();
      Cursor cursor = contentResolver.query(builder.scheme("content").authority("com.google.android.gms.chimera").path(str).appendPath(paramString).appendQueryParameter("requestStartTime", String.valueOf(l)).build(), null, null, null, null);
      if (cursor != null) {
        cursor1 = cursor;
        cursor2 = cursor;
        try {
          if (cursor.moveToFirst()) {
            boolean bool1 = false;
            paramBoolean1 = false;
            cursor1 = cursor;
            cursor2 = cursor;
            int i = cursor.getInt(0);
            Cursor cursor3 = cursor;
            if (i > 0) {
              cursor1 = cursor;
              cursor2 = cursor;
              /* monitor enter TypeReferenceDotClassExpression{ObjectType{com/google/android/gms/dynamite/DynamiteModule}} */
              try {
                i = cursor.getString(2);
                int n = cursor.getColumnIndex("loaderVersion");
                if (n >= 0)
                  k = cursor.getInt(n); 
              } finally {}
              int m = cursor.getColumnIndex("disableStandaloneDynamiteLoader2");
              if (m >= 0) {
                if (cursor.getInt(m) != 0) {
                  paramBoolean1 = bool;
                } else {
                  paramBoolean1 = false;
                } 
                j = paramBoolean1;
              } 
              /* monitor exit TypeReferenceDotClassExpression{ObjectType{com/google/android/gms/dynamite/DynamiteModule}} */
              cursor1 = cursor;
              cursor2 = cursor;
              bool = i(cursor);
              cursor3 = cursor;
              bool1 = paramBoolean1;
              if (bool) {
                cursor3 = null;
                bool1 = paramBoolean1;
              } 
            } 
            if (!paramBoolean2 || !bool1)
              return i; 
            cursor1 = cursor3;
            cursor2 = cursor3;
            loadingException4 = new LoadingException();
            cursor1 = cursor3;
            cursor2 = cursor3;
            this("forcing fallback to container DynamiteLoader impl", null);
            cursor1 = cursor3;
            cursor2 = cursor3;
            throw loadingException4;
          } 
        } catch (Exception exception) {
        
        } finally {}
      } 
      LoadingException loadingException1 = loadingException4;
      LoadingException loadingException3 = loadingException4;
      r0.f("DynamiteModule", "Failed to retrieve remote module version.");
      loadingException1 = loadingException4;
      loadingException3 = loadingException4;
      LoadingException loadingException2 = new LoadingException();
      loadingException1 = loadingException4;
      loadingException3 = loadingException4;
      this("Failed to connect to dynamite module ContentResolver.", null);
      loadingException1 = loadingException4;
      loadingException3 = loadingException4;
      throw loadingException2;
    } catch (Exception exception) {
      cursor2 = null;
      cursor1 = cursor2;
      if (exception instanceof LoadingException) {
        cursor1 = cursor2;
        throw exception;
      } 
      cursor1 = cursor2;
      LoadingException loadingException = new LoadingException();
      cursor1 = cursor2;
      String str = exception.getMessage();
      cursor1 = cursor2;
      StringBuilder stringBuilder = new StringBuilder();
      cursor1 = cursor2;
      this();
      cursor1 = cursor2;
      stringBuilder.append("V2 version check failed: ");
      cursor1 = cursor2;
      stringBuilder.append(str);
      cursor1 = cursor2;
      this(stringBuilder.toString(), exception, null);
      cursor1 = cursor2;
      throw loadingException;
    } finally {
      paramString = null;
    } 
    if (cursor1 != null)
      cursor1.close(); 
    throw paramString;
  }
  
  public static DynamiteModule g(Context paramContext, String paramString) {
    Log.i("DynamiteModule", "Selected local version of ".concat(String.valueOf(paramString)));
    return new DynamiteModule(paramContext);
  }
  
  public static void h(ClassLoader paramClassLoader) throws LoadingException {
    try {
      IBinder iBinder = paramClassLoader.loadClass("com.google.android.gms.dynamiteloader.DynamiteLoaderV2").getConstructor(null).newInstance(null);
      if (iBinder == null) {
        iBinder = null;
      } else {
        k k1;
        IInterface iInterface = iBinder.queryLocalInterface("com.google.android.gms.dynamite.IDynamiteLoaderV2");
        if (iInterface instanceof k) {
          k1 = (k)iInterface;
        } else {
          k1 = new k((IBinder)k1);
        } 
      } 
    } catch (ClassNotFoundException classNotFoundException) {
    
    } catch (IllegalAccessException illegalAccessException) {
    
    } catch (InstantiationException instantiationException) {
    
    } catch (InvocationTargetException invocationTargetException) {
    
    } catch (NoSuchMethodException noSuchMethodException) {}
    r = (k)noSuchMethodException;
  }
  
  public static boolean i(Cursor paramCursor) {
    h h = m.get();
    if (h != null && h.a == null) {
      h.a = paramCursor;
      return true;
    } 
    return false;
  }
  
  public static boolean j(Context paramContext) {
    Boolean bool = Boolean.TRUE;
    if (bool.equals(null))
      return true; 
    if (bool.equals(l))
      return true; 
    bool = l;
    boolean bool1 = false;
    boolean bool2 = false;
    if (bool == null) {
      ProviderInfo providerInfo = paramContext.getPackageManager().resolveContentProvider("com.google.android.gms.chimera", 0);
      boolean bool3 = bool2;
      if (d.h().j(paramContext, 10000000) == 0) {
        bool3 = bool2;
        if (providerInfo != null) {
          bool3 = bool2;
          if ("com.google.android.gms".equals(providerInfo.packageName))
            bool3 = true; 
        } 
      } 
      l = Boolean.valueOf(bool3);
      bool1 = bool3;
      if (bool3) {
        ApplicationInfo applicationInfo = providerInfo.applicationInfo;
        bool1 = bool3;
        if (applicationInfo != null) {
          bool1 = bool3;
          if ((applicationInfo.flags & 0x81) == 0) {
            Log.i("DynamiteModule", "Non-system-image GmsCore APK, forcing V1");
            j = true;
            bool1 = bool3;
          } 
        } 
      } 
    } 
    if (!bool1)
      r0.d("DynamiteModule", "Invalid GmsCore APK, remote loading disabled."); 
    return bool1;
  }
  
  public static j k(Context paramContext) {
    /* monitor enter TypeReferenceDotClassExpression{ObjectType{com/google/android/gms/dynamite/DynamiteModule}} */
    try {
      j j1 = q;
      if (j1 != null) {
        /* monitor exit TypeReferenceDotClassExpression{ObjectType{com/google/android/gms/dynamite/DynamiteModule}} */
        return j1;
      } 
    } finally {}
    try {
      IBinder iBinder = (IBinder)paramContext.createPackageContext("com.google.android.gms", 3).getClassLoader().loadClass("com.google.android.gms.chimera.container.DynamiteLoaderImpl").newInstance();
      if (iBinder == null) {
        iBinder = null;
      } else {
        j j1;
        IInterface iInterface = iBinder.queryLocalInterface("com.google.android.gms.dynamite.IDynamiteLoader");
        if (iInterface instanceof j) {
          j1 = (j)iInterface;
        } else {
          j1 = new j((IBinder)j1);
        } 
      } 
    } catch (Exception exception) {}
    if (exception != null) {
      q = (j)exception;
      /* monitor exit TypeReferenceDotClassExpression{ObjectType{com/google/android/gms/dynamite/DynamiteModule}} */
      return (j)exception;
    } 
    /* monitor exit TypeReferenceDotClassExpression{ObjectType{com/google/android/gms/dynamite/DynamiteModule}} */
    return null;
  }
  
  public IBinder c(String paramString) throws LoadingException {
    try {
      return (IBinder)this.a.getClassLoader().loadClass(paramString).newInstance();
    } catch (ClassNotFoundException classNotFoundException) {
    
    } catch (InstantiationException instantiationException) {
    
    } catch (IllegalAccessException illegalAccessException) {}
    throw new LoadingException("Failed to instantiate module class: ".concat(String.valueOf(paramString)), illegalAccessException, null);
  }
  
  @DynamiteApi
  public static class DynamiteLoaderClassLoader {
    public static ClassLoader sClassLoader;
  }
  
  public static class LoadingException extends Exception {}
  
  public static interface a {
    b a(Context param1Context, String param1String, a param1a) throws DynamiteModule.LoadingException;
    
    public static interface a {
      int a(Context param2Context, String param2String, boolean param2Boolean) throws DynamiteModule.LoadingException;
      
      int b(Context param2Context, String param2String);
    }
    
    public static class b {
      public int a = 0;
      
      public int b = 0;
      
      public int c = 0;
    }
  }
  
  public static interface a {
    int a(Context param1Context, String param1String, boolean param1Boolean) throws DynamiteModule.LoadingException;
    
    int b(Context param1Context, String param1String);
  }
  
  public static class b {
    public int a = 0;
    
    public int b = 0;
    
    public int c = 0;
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\google\android\gms\dynamite\DynamiteModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */