package com.google.android.gms.dynamite;

import android.content.Context;

public final class e implements DynamiteModule.a {
  public final DynamiteModule.a.b a(Context paramContext, String paramString, DynamiteModule.a.a parama) throws DynamiteModule.LoadingException {
    DynamiteModule.a.b b1 = new DynamiteModule.a.b();
    b1.a = parama.b(paramContext, paramString);
    byte b = 1;
    int k = parama.a(paramContext, paramString, true);
    b1.b = k;
    int j = b1.a;
    int i = j;
    if (j == 0) {
      i = 0;
      if (k == 0) {
        b = 0;
        b1.c = b;
        return b1;
      } 
    } 
    if (i >= k)
      b = -1; 
    b1.c = b;
    return b1;
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\google\android\gms\dynamite\e.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */