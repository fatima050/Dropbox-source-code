package com.google.android.gms.dynamite;

import android.content.Context;

public final class c implements DynamiteModule.a {
  public final DynamiteModule.a.b a(Context paramContext, String paramString, DynamiteModule.a.a parama) throws DynamiteModule.LoadingException {
    DynamiteModule.a.b b = new DynamiteModule.a.b();
    int i = parama.b(paramContext, paramString);
    b.a = i;
    if (i != 0) {
      b.c = -1;
    } else {
      i = parama.a(paramContext, paramString, true);
      b.b = i;
      if (i != 0)
        b.c = 1; 
    } 
    return b;
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\google\android\gms\dynamite\c.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */