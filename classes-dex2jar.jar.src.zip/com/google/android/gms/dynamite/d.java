package com.google.android.gms.dynamite;

import android.content.Context;

public final class d implements DynamiteModule.a {
  public final DynamiteModule.a.b a(Context paramContext, String paramString, DynamiteModule.a.a parama) throws DynamiteModule.LoadingException {
    DynamiteModule.a.b b = new DynamiteModule.a.b();
    boolean bool = false;
    int i = parama.a(paramContext, paramString, false);
    b.b = i;
    if (i != 0)
      bool = true; 
    b.c = bool;
    return b;
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\google\android\gms\dynamite\d.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */