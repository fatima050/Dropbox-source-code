package com.google.android.gms.dynamite;

import android.content.Context;

public final class b implements DynamiteModule.a {
  public final DynamiteModule.a.b a(Context paramContext, String paramString, DynamiteModule.a.a parama) throws DynamiteModule.LoadingException {
    DynamiteModule.a.b b1 = new DynamiteModule.a.b();
    int i = parama.a(paramContext, paramString, true);
    b1.b = i;
    if (i != 0) {
      b1.c = 1;
    } else {
      i = parama.b(paramContext, paramString);
      b1.a = i;
      if (i != 0)
        b1.c = -1; 
    } 
    return b1;
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\google\android\gms\dynamite\b.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */