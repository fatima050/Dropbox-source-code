package com.google.android.gms.dynamite;

import android.content.Context;

public final class a implements DynamiteModule.a.a {
  public final int a(Context paramContext, String paramString, boolean paramBoolean) throws DynamiteModule.LoadingException {
    return DynamiteModule.e(paramContext, paramString, paramBoolean);
  }
  
  public final int b(Context paramContext, String paramString) {
    return DynamiteModule.a(paramContext, paramString);
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\google\android\gms\dynamite\a.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */