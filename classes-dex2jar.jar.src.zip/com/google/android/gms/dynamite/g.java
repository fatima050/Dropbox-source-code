package com.google.android.gms.dynamite;

import android.content.Context;

public final class g implements DynamiteModule.a {
  public final DynamiteModule.a.b a(Context paramContext, String paramString, DynamiteModule.a.a parama) throws DynamiteModule.LoadingException {
    DynamiteModule.a.b b = new DynamiteModule.a.b();
    b.a = parama.b(paramContext, paramString);
    boolean bool = true;
    int k = parama.a(paramContext, paramString, true);
    b.b = k;
    int j = b.a;
    int i = j;
    if (j == 0) {
      i = 0;
      if (k == 0) {
        i = 0;
        b.c = i;
        return b;
      } 
    } 
    if (k >= i) {
      i = bool;
    } else {
      i = -1;
    } 
    b.c = i;
    return b;
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\google\android\gms\dynamite\g.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */