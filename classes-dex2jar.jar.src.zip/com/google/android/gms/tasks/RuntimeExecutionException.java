package com.google.android.gms.tasks;

public class RuntimeExecutionException extends RuntimeException {
  public RuntimeExecutionException(Throwable paramThrowable) {
    super(paramThrowable);
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\google\android\gms\tasks\RuntimeExecutionException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */