package com.google.android.gms.internal.measurement;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import dbxyzptlk.LB.R0;
import dbxyzptlk.tB.a;

public final class zzdq extends AbstractSafeParcelable {
  public static final Parcelable.Creator<zzdq> CREATOR = (Parcelable.Creator<zzdq>)new R0();
  
  public final long a;
  
  public final long b;
  
  public final boolean c;
  
  public final String d;
  
  public final String e;
  
  public final String f;
  
  public final Bundle g;
  
  public final String h;
  
  public zzdq(long paramLong1, long paramLong2, boolean paramBoolean, String paramString1, String paramString2, String paramString3, Bundle paramBundle, String paramString4) {
    this.a = paramLong1;
    this.b = paramLong2;
    this.c = paramBoolean;
    this.d = paramString1;
    this.e = paramString2;
    this.f = paramString3;
    this.g = paramBundle;
    this.h = paramString4;
  }
  
  public final void writeToParcel(Parcel paramParcel, int paramInt) {
    paramInt = a.a(paramParcel);
    a.m(paramParcel, 1, this.a);
    a.m(paramParcel, 2, this.b);
    a.c(paramParcel, 3, this.c);
    a.p(paramParcel, 4, this.d, false);
    a.p(paramParcel, 5, this.e, false);
    a.p(paramParcel, 6, this.f, false);
    a.e(paramParcel, 7, this.g, false);
    a.p(paramParcel, 8, this.h, false);
    a.b(paramParcel, paramInt);
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\google\android\gms\internal\measurement\zzdq.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */