package com.google.android.gms.auth.api.identity;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import dbxyzptlk.sB.j;
import dbxyzptlk.sB.l;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class BeginSignInRequest extends AbstractSafeParcelable {
  public static final Parcelable.Creator<BeginSignInRequest> CREATOR = new a();
  
  public final PasswordRequestOptions a;
  
  public final GoogleIdTokenRequestOptions b;
  
  public final String c;
  
  public final boolean d;
  
  public final int e;
  
  public BeginSignInRequest(PasswordRequestOptions paramPasswordRequestOptions, GoogleIdTokenRequestOptions paramGoogleIdTokenRequestOptions, String paramString, boolean paramBoolean, int paramInt) {
    this.a = (PasswordRequestOptions)l.m(paramPasswordRequestOptions);
    this.b = (GoogleIdTokenRequestOptions)l.m(paramGoogleIdTokenRequestOptions);
    this.c = paramString;
    this.d = paramBoolean;
    this.e = paramInt;
  }
  
  public static a A() {
    return new a();
  }
  
  public static a i0(BeginSignInRequest paramBeginSignInRequest) {
    l.m(paramBeginSignInRequest);
    a a = A();
    a.c(paramBeginSignInRequest.O());
    a.d(paramBeginSignInRequest.Q());
    a.b(paramBeginSignInRequest.d);
    a.f(paramBeginSignInRequest.e);
    String str = paramBeginSignInRequest.c;
    if (str != null)
      a.e(str); 
    return a;
  }
  
  public GoogleIdTokenRequestOptions O() {
    return this.b;
  }
  
  public PasswordRequestOptions Q() {
    return this.a;
  }
  
  public boolean Y() {
    return this.d;
  }
  
  public boolean equals(Object paramObject) {
    if (!(paramObject instanceof BeginSignInRequest))
      return false; 
    paramObject = paramObject;
    return (j.b(this.a, ((BeginSignInRequest)paramObject).a) && j.b(this.b, ((BeginSignInRequest)paramObject).b) && j.b(this.c, ((BeginSignInRequest)paramObject).c) && this.d == ((BeginSignInRequest)paramObject).d && this.e == ((BeginSignInRequest)paramObject).e);
  }
  
  public int hashCode() {
    return j.c(new Object[] { this.a, this.b, this.c, Boolean.valueOf(this.d) });
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    int i = dbxyzptlk.tB.a.a(paramParcel);
    dbxyzptlk.tB.a.o(paramParcel, 1, (Parcelable)Q(), paramInt, false);
    dbxyzptlk.tB.a.o(paramParcel, 2, (Parcelable)O(), paramInt, false);
    dbxyzptlk.tB.a.p(paramParcel, 3, this.c, false);
    dbxyzptlk.tB.a.c(paramParcel, 4, Y());
    dbxyzptlk.tB.a.k(paramParcel, 5, this.e);
    dbxyzptlk.tB.a.b(paramParcel, i);
  }
  
  public static final class GoogleIdTokenRequestOptions extends AbstractSafeParcelable {
    public static final Parcelable.Creator<GoogleIdTokenRequestOptions> CREATOR = new b();
    
    public final boolean a;
    
    public final String b;
    
    public final String c;
    
    public final boolean d;
    
    public final String e;
    
    public final List f;
    
    public final boolean g;
    
    public GoogleIdTokenRequestOptions(boolean param1Boolean1, String param1String1, String param1String2, boolean param1Boolean2, String param1String3, List<?> param1List, boolean param1Boolean3) {
      ArrayList<Comparable> arrayList;
      boolean bool2 = true;
      boolean bool1 = bool2;
      if (param1Boolean2)
        if (!param1Boolean3) {
          bool1 = bool2;
        } else {
          bool1 = false;
        }  
      l.b(bool1, "filterByAuthorizedAccounts and requestVerifiedPhoneNumber must not both be true; the Verified Phone Number feature only works in sign-ups.");
      this.a = param1Boolean1;
      if (param1Boolean1)
        l.n(param1String1, "serverClientId must be provided if Google ID tokens are requested"); 
      this.b = param1String1;
      this.c = param1String2;
      this.d = param1Boolean2;
      Parcelable.Creator<BeginSignInRequest> creator = BeginSignInRequest.CREATOR;
      param1String2 = null;
      String str = param1String2;
      if (param1List != null)
        if (param1List.isEmpty()) {
          str = param1String2;
        } else {
          arrayList = new ArrayList(param1List);
          Collections.sort(arrayList);
        }  
      this.f = arrayList;
      this.e = param1String3;
      this.g = param1Boolean3;
    }
    
    public static a A() {
      return new a();
    }
    
    public boolean O() {
      return this.d;
    }
    
    public List<String> Q() {
      return this.f;
    }
    
    public boolean Q1() {
      return this.a;
    }
    
    public String Y() {
      return this.e;
    }
    
    public boolean equals(Object param1Object) {
      if (!(param1Object instanceof GoogleIdTokenRequestOptions))
        return false; 
      param1Object = param1Object;
      return (this.a == ((GoogleIdTokenRequestOptions)param1Object).a && j.b(this.b, ((GoogleIdTokenRequestOptions)param1Object).b) && j.b(this.c, ((GoogleIdTokenRequestOptions)param1Object).c) && this.d == ((GoogleIdTokenRequestOptions)param1Object).d && j.b(this.e, ((GoogleIdTokenRequestOptions)param1Object).e) && j.b(this.f, ((GoogleIdTokenRequestOptions)param1Object).f) && this.g == ((GoogleIdTokenRequestOptions)param1Object).g);
    }
    
    public boolean f2() {
      return this.g;
    }
    
    public int hashCode() {
      return j.c(new Object[] { Boolean.valueOf(this.a), this.b, this.c, Boolean.valueOf(this.d), this.e, this.f, Boolean.valueOf(this.g) });
    }
    
    public String i0() {
      return this.c;
    }
    
    public String s0() {
      return this.b;
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      param1Int = dbxyzptlk.tB.a.a(param1Parcel);
      dbxyzptlk.tB.a.c(param1Parcel, 1, Q1());
      dbxyzptlk.tB.a.p(param1Parcel, 2, s0(), false);
      dbxyzptlk.tB.a.p(param1Parcel, 3, i0(), false);
      dbxyzptlk.tB.a.c(param1Parcel, 4, O());
      dbxyzptlk.tB.a.p(param1Parcel, 5, Y(), false);
      dbxyzptlk.tB.a.r(param1Parcel, 6, Q(), false);
      dbxyzptlk.tB.a.c(param1Parcel, 7, f2());
      dbxyzptlk.tB.a.b(param1Parcel, param1Int);
    }
    
    public static final class a {
      public boolean a = false;
      
      public String b = null;
      
      public String c = null;
      
      public boolean d = true;
      
      public String e = null;
      
      public List f = null;
      
      public boolean g = false;
      
      public BeginSignInRequest.GoogleIdTokenRequestOptions a() {
        return new BeginSignInRequest.GoogleIdTokenRequestOptions(this.a, this.b, this.c, this.d, this.e, this.f, this.g);
      }
      
      public a b(boolean param2Boolean) {
        this.d = param2Boolean;
        return this;
      }
      
      public a c(String param2String) {
        this.b = l.g(param2String);
        return this;
      }
      
      public a d(boolean param2Boolean) {
        this.a = param2Boolean;
        return this;
      }
    }
  }
  
  public static final class a {
    public boolean a = false;
    
    public String b = null;
    
    public String c = null;
    
    public boolean d = true;
    
    public String e = null;
    
    public List f = null;
    
    public boolean g = false;
    
    public BeginSignInRequest.GoogleIdTokenRequestOptions a() {
      return new BeginSignInRequest.GoogleIdTokenRequestOptions(this.a, this.b, this.c, this.d, this.e, this.f, this.g);
    }
    
    public a b(boolean param1Boolean) {
      this.d = param1Boolean;
      return this;
    }
    
    public a c(String param1String) {
      this.b = l.g(param1String);
      return this;
    }
    
    public a d(boolean param1Boolean) {
      this.a = param1Boolean;
      return this;
    }
  }
  
  public static final class PasswordRequestOptions extends AbstractSafeParcelable {
    public static final Parcelable.Creator<PasswordRequestOptions> CREATOR = new c();
    
    public final boolean a;
    
    public PasswordRequestOptions(boolean param1Boolean) {
      this.a = param1Boolean;
    }
    
    public static a A() {
      return new a();
    }
    
    public boolean O() {
      return this.a;
    }
    
    public boolean equals(Object param1Object) {
      if (!(param1Object instanceof PasswordRequestOptions))
        return false; 
      param1Object = param1Object;
      return (this.a == ((PasswordRequestOptions)param1Object).a);
    }
    
    public int hashCode() {
      return j.c(new Object[] { Boolean.valueOf(this.a) });
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      param1Int = dbxyzptlk.tB.a.a(param1Parcel);
      dbxyzptlk.tB.a.c(param1Parcel, 1, O());
      dbxyzptlk.tB.a.b(param1Parcel, param1Int);
    }
    
    public static final class a {
      public boolean a = false;
      
      public BeginSignInRequest.PasswordRequestOptions a() {
        return new BeginSignInRequest.PasswordRequestOptions(this.a);
      }
      
      public a b(boolean param2Boolean) {
        this.a = param2Boolean;
        return this;
      }
    }
  }
  
  public static final class a {
    public boolean a = false;
    
    public BeginSignInRequest.PasswordRequestOptions a() {
      return new BeginSignInRequest.PasswordRequestOptions(this.a);
    }
    
    public a b(boolean param1Boolean) {
      this.a = param1Boolean;
      return this;
    }
  }
  
  public static final class a {
    public BeginSignInRequest.PasswordRequestOptions a;
    
    public BeginSignInRequest.GoogleIdTokenRequestOptions b;
    
    public String c;
    
    public boolean d;
    
    public int e;
    
    public a() {
      BeginSignInRequest.PasswordRequestOptions.a a2 = BeginSignInRequest.PasswordRequestOptions.A();
      a2.b(false);
      this.a = a2.a();
      BeginSignInRequest.GoogleIdTokenRequestOptions.a a1 = BeginSignInRequest.GoogleIdTokenRequestOptions.A();
      a1.d(false);
      this.b = a1.a();
    }
    
    public BeginSignInRequest a() {
      return new BeginSignInRequest(this.a, this.b, this.c, this.d, this.e);
    }
    
    public a b(boolean param1Boolean) {
      this.d = param1Boolean;
      return this;
    }
    
    public a c(BeginSignInRequest.GoogleIdTokenRequestOptions param1GoogleIdTokenRequestOptions) {
      this.b = (BeginSignInRequest.GoogleIdTokenRequestOptions)l.m(param1GoogleIdTokenRequestOptions);
      return this;
    }
    
    public a d(BeginSignInRequest.PasswordRequestOptions param1PasswordRequestOptions) {
      this.a = (BeginSignInRequest.PasswordRequestOptions)l.m(param1PasswordRequestOptions);
      return this;
    }
    
    public final a e(String param1String) {
      this.c = param1String;
      return this;
    }
    
    public final a f(int param1Int) {
      this.e = param1Int;
      return this;
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\google\android\gms\auth\api\identity\BeginSignInRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */