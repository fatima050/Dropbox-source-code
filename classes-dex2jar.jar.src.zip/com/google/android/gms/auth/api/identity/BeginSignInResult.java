package com.google.android.gms.auth.api.identity;

import android.app.PendingIntent;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import dbxyzptlk.hB.c;
import dbxyzptlk.sB.l;
import dbxyzptlk.tB.a;

public final class BeginSignInResult extends AbstractSafeParcelable {
  public static final Parcelable.Creator<BeginSignInResult> CREATOR = (Parcelable.Creator<BeginSignInResult>)new c();
  
  public final PendingIntent a;
  
  public BeginSignInResult(PendingIntent paramPendingIntent) {
    this.a = (PendingIntent)l.m(paramPendingIntent);
  }
  
  public PendingIntent A() {
    return this.a;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    int i = a.a(paramParcel);
    a.o(paramParcel, 1, (Parcelable)A(), paramInt, false);
    a.b(paramParcel, i);
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\google\android\gms\auth\api\identity\BeginSignInResult.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */