package com.fasterxml.jackson.core;

import java.io.IOException;

public abstract class JacksonException extends IOException {
  private static final long serialVersionUID = 123L;
  
  public JacksonException(String paramString) {
    super(paramString);
  }
  
  public JacksonException(String paramString, Throwable paramThrowable) {
    super(paramString, paramThrowable);
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\fasterxml\jackson\core\JacksonException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */