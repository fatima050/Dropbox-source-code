package com.fasterxml.jackson.core;

import dbxyzptlk.wA.f;

public class JsonProcessingException extends JacksonException {
  private static final long serialVersionUID = 123L;
  
  public f a;
  
  public JsonProcessingException(String paramString) {
    super(paramString);
  }
  
  public JsonProcessingException(String paramString, f paramf) {
    this(paramString, paramf, null);
  }
  
  public JsonProcessingException(String paramString, f paramf, Throwable paramThrowable) {
    super(paramString, paramThrowable);
    this.a = paramf;
  }
  
  public f a() {
    return this.a;
  }
  
  public String b() {
    return null;
  }
  
  public String getMessage() {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial getMessage : ()Ljava/lang/String;
    //   4: astore_2
    //   5: aload_2
    //   6: astore_1
    //   7: aload_2
    //   8: ifnonnull -> 14
    //   11: ldc 'N/A'
    //   13: astore_1
    //   14: aload_0
    //   15: invokevirtual a : ()Ldbxyzptlk/wA/f;
    //   18: astore_3
    //   19: aload_0
    //   20: invokevirtual b : ()Ljava/lang/String;
    //   23: astore #4
    //   25: aload_3
    //   26: ifnonnull -> 36
    //   29: aload_1
    //   30: astore_2
    //   31: aload #4
    //   33: ifnull -> 96
    //   36: new java/lang/StringBuilder
    //   39: dup
    //   40: bipush #100
    //   42: invokespecial <init> : (I)V
    //   45: astore_2
    //   46: aload_2
    //   47: aload_1
    //   48: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   51: pop
    //   52: aload #4
    //   54: ifnull -> 64
    //   57: aload_2
    //   58: aload #4
    //   60: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   63: pop
    //   64: aload_3
    //   65: ifnull -> 91
    //   68: aload_2
    //   69: bipush #10
    //   71: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   74: pop
    //   75: aload_2
    //   76: ldc ' at '
    //   78: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   81: pop
    //   82: aload_2
    //   83: aload_3
    //   84: invokevirtual toString : ()Ljava/lang/String;
    //   87: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   90: pop
    //   91: aload_2
    //   92: invokevirtual toString : ()Ljava/lang/String;
    //   95: astore_2
    //   96: aload_2
    //   97: areturn
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(getClass().getName());
    stringBuilder.append(": ");
    stringBuilder.append(getMessage());
    return stringBuilder.toString();
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\fasterxml\jackson\core\JsonProcessingException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */