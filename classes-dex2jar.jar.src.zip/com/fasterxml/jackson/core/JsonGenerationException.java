package com.fasterxml.jackson.core;

import com.fasterxml.jackson.core.exc.StreamWriteException;
import dbxyzptlk.wA.e;

public class JsonGenerationException extends StreamWriteException {
  private static final long serialVersionUID = 123L;
  
  public JsonGenerationException(String paramString, e parame) {
    super(paramString, parame);
    this.b = parame;
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\fasterxml\jackson\core\JsonGenerationException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */