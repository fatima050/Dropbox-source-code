package com.fasterxml.jackson.core.exc;

import com.fasterxml.jackson.core.JsonProcessingException;
import dbxyzptlk.wA.f;
import dbxyzptlk.wA.g;

public abstract class StreamReadException extends JsonProcessingException {
  static final long serialVersionUID = 2L;
  
  public transient g b;
  
  public StreamReadException(g paramg, String paramString) {
    super(paramString, f);
    f f;
    this.b = paramg;
  }
  
  public StreamReadException(g paramg, String paramString, Throwable paramThrowable) {
    super(paramString, f, paramThrowable);
    f f;
    this.b = paramg;
  }
  
  public String getMessage() {
    return super.getMessage();
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\fasterxml\jackson\core\exc\StreamReadException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */