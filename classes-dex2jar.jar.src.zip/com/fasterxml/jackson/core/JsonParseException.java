package com.fasterxml.jackson.core;

import com.fasterxml.jackson.core.exc.StreamReadException;
import dbxyzptlk.DA.j;
import dbxyzptlk.wA.g;

public class JsonParseException extends StreamReadException {
  private static final long serialVersionUID = 2L;
  
  public JsonParseException(g paramg, String paramString) {
    super(paramg, paramString);
  }
  
  public JsonParseException(g paramg, String paramString, Throwable paramThrowable) {
    super(paramg, paramString, paramThrowable);
  }
  
  public JsonParseException c(j paramj) {
    return this;
  }
  
  public String getMessage() {
    return super.getMessage();
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\fasterxml\jackson\core\JsonParseException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */