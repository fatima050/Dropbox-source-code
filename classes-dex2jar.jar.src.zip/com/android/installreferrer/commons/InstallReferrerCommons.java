package com.android.installreferrer.commons;

import android.util.Log;
import io.sentry.android.core.r0;

public final class InstallReferrerCommons {
  public static void logVerbose(String paramString1, String paramString2) {
    if (Log.isLoggable(paramString1, 2))
      Log.v(paramString1, paramString2); 
  }
  
  public static void logWarn(String paramString1, String paramString2) {
    if (Log.isLoggable(paramString1, 5))
      r0.f(paramString1, paramString2); 
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\android\installreferrer\commons\InstallReferrerCommons.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */