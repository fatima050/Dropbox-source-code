package com.android.installreferrer.api;

import android.content.Context;
import android.os.RemoteException;

public abstract class InstallReferrerClient {
  public static Builder newBuilder(Context paramContext) {
    return new Builder(paramContext, null);
  }
  
  public abstract void endConnection();
  
  public abstract ReferrerDetails getInstallReferrer() throws RemoteException;
  
  public abstract boolean isReady();
  
  public abstract void startConnection(InstallReferrerStateListener paramInstallReferrerStateListener);
  
  public static final class Builder {
    private final Context mContext;
    
    private Builder(Context param1Context) {
      this.mContext = param1Context;
    }
    
    public InstallReferrerClient build() {
      Context context = this.mContext;
      if (context != null)
        return new InstallReferrerClientImpl(context); 
      throw new IllegalArgumentException("Please provide a valid Context.");
    }
  }
  
  class InstallReferrerClient {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\android\installreferrer\api\InstallReferrerClient.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */