package com.android.installreferrer.api;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.pm.ServiceInfo;
import android.os.Bundle;
import android.os.RemoteException;
import com.android.installreferrer.commons.InstallReferrerCommons;
import dbxyzptlk.cB.a;
import java.util.List;

public class InstallReferrerClientImpl extends InstallReferrerClient {
  public int a = 0;
  
  public final Context b;
  
  public a c;
  
  public ServiceConnection d;
  
  public InstallReferrerClientImpl(Context paramContext) {
    this.b = paramContext.getApplicationContext();
  }
  
  public final boolean c() {
    PackageManager packageManager = this.b.getPackageManager();
    try {
      int i = (packageManager.getPackageInfo("com.android.vending", 128)).versionCode;
      if (i >= 80837300)
        return true; 
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {}
    return false;
  }
  
  public void endConnection() {
    this.a = 3;
    if (this.d != null) {
      InstallReferrerCommons.logVerbose("InstallReferrerClient", "Unbinding from service.");
      this.b.unbindService(this.d);
      this.d = null;
    } 
    this.c = null;
  }
  
  public ReferrerDetails getInstallReferrer() throws RemoteException {
    if (isReady()) {
      Bundle bundle = new Bundle();
      bundle.putString("package_name", this.b.getPackageName());
      try {
        return new ReferrerDetails(this.c.Y(bundle));
      } catch (RemoteException remoteException) {
        InstallReferrerCommons.logWarn("InstallReferrerClient", "RemoteException getting install referrer information");
        this.a = 0;
        throw remoteException;
      } 
    } 
    throw new IllegalStateException("Service not connected. Please start a connection before using the service.");
  }
  
  public boolean isReady() {
    return (this.a == 2 && this.c != null && this.d != null);
  }
  
  public void startConnection(InstallReferrerStateListener paramInstallReferrerStateListener) {
    if (isReady()) {
      InstallReferrerCommons.logVerbose("InstallReferrerClient", "Service connection is valid. No need to re-initialize.");
      paramInstallReferrerStateListener.onInstallReferrerSetupFinished(0);
      return;
    } 
    int i = this.a;
    if (i == 1) {
      InstallReferrerCommons.logWarn("InstallReferrerClient", "Client is already in the process of connecting to the service.");
      paramInstallReferrerStateListener.onInstallReferrerSetupFinished(3);
      return;
    } 
    if (i == 3) {
      InstallReferrerCommons.logWarn("InstallReferrerClient", "Client was already closed and can't be reused. Please create another instance.");
      paramInstallReferrerStateListener.onInstallReferrerSetupFinished(3);
      return;
    } 
    InstallReferrerCommons.logVerbose("InstallReferrerClient", "Starting install referrer service setup.");
    Intent intent = new Intent("com.google.android.finsky.BIND_GET_INSTALL_REFERRER_SERVICE");
    intent.setComponent(new ComponentName("com.android.vending", "com.google.android.finsky.externalreferrer.GetInstallReferrerService"));
    List list = this.b.getPackageManager().queryIntentServices(intent, 0);
    if (list != null && !list.isEmpty()) {
      ServiceInfo serviceInfo = ((ResolveInfo)list.get(0)).serviceInfo;
      if (serviceInfo != null) {
        String str1 = serviceInfo.packageName;
        String str2 = serviceInfo.name;
        if ("com.android.vending".equals(str1) && str2 != null && c()) {
          intent = new Intent(intent);
          b b = new b(this, paramInstallReferrerStateListener, null);
          this.d = (ServiceConnection)b;
          try {
            boolean bool = this.b.bindService(intent, (ServiceConnection)b, 1);
            if (bool) {
              InstallReferrerCommons.logVerbose("InstallReferrerClient", "Service was bonded successfully.");
              return;
            } 
            InstallReferrerCommons.logWarn("InstallReferrerClient", "Connection to service is blocked.");
            this.a = 0;
            paramInstallReferrerStateListener.onInstallReferrerSetupFinished(1);
            return;
          } catch (SecurityException securityException) {
            InstallReferrerCommons.logWarn("InstallReferrerClient", "No permission to connect to service.");
            this.a = 0;
            paramInstallReferrerStateListener.onInstallReferrerSetupFinished(4);
            return;
          } 
        } 
        InstallReferrerCommons.logWarn("InstallReferrerClient", "Play Store missing or incompatible. Version 8.3.73 or later required.");
        this.a = 0;
        paramInstallReferrerStateListener.onInstallReferrerSetupFinished(2);
        return;
      } 
    } 
    this.a = 0;
    InstallReferrerCommons.logVerbose("InstallReferrerClient", "Install Referrer service unavailable on device.");
    paramInstallReferrerStateListener.onInstallReferrerSetupFinished(2);
  }
  
  class InstallReferrerClientImpl {}
  
  class InstallReferrerClientImpl {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\android\installreferrer\api\InstallReferrerClientImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */