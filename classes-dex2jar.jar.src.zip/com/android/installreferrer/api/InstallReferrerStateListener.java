package com.android.installreferrer.api;

public interface InstallReferrerStateListener {
  void onInstallReferrerServiceDisconnected();
  
  void onInstallReferrerSetupFinished(int paramInt);
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\android\installreferrer\api\InstallReferrerStateListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */