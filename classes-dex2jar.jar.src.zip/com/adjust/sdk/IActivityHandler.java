package com.adjust.sdk;

import android.content.Context;
import android.net.Uri;
import dbxyzptlk.WK.b;

public interface IActivityHandler {
  void addSessionCallbackParameter(String paramString1, String paramString2);
  
  void addSessionPartnerParameter(String paramString1, String paramString2);
  
  void disableThirdPartySharing();
  
  void finishedTrackingActivity(ResponseData paramResponseData);
  
  void gdprForgetMe();
  
  ActivityState getActivityState();
  
  String getAdid();
  
  AdjustConfig getAdjustConfig();
  
  AdjustAttribution getAttribution();
  
  Context getContext();
  
  a getDeviceInfo();
  
  SessionParameters getSessionParameters();
  
  void gotOptOutResponse();
  
  void init(AdjustConfig paramAdjustConfig);
  
  boolean isEnabled();
  
  void launchAttributionResponseTasks(AttributionResponseData paramAttributionResponseData);
  
  void launchEventResponseTasks(EventResponseData paramEventResponseData);
  
  void launchSdkClickResponseTasks(SdkClickResponseData paramSdkClickResponseData);
  
  void launchSessionResponseTasks(SessionResponseData paramSessionResponseData);
  
  void onPause();
  
  void onResume();
  
  void readOpenUrl(Uri paramUri, long paramLong);
  
  void removeSessionCallbackParameter(String paramString);
  
  void removeSessionPartnerParameter(String paramString);
  
  void resetSessionCallbackParameters();
  
  void resetSessionPartnerParameters();
  
  void sendFirstPackages();
  
  void sendInstallReferrer(ReferrerDetails paramReferrerDetails, String paramString);
  
  void sendPreinstallReferrer();
  
  void sendReftagReferrer();
  
  void setAskingAttribution(boolean paramBoolean);
  
  void setEnabled(boolean paramBoolean);
  
  void setOfflineMode(boolean paramBoolean);
  
  void setPushToken(String paramString, boolean paramBoolean);
  
  void teardown();
  
  void trackAdRevenue(AdjustAdRevenue paramAdjustAdRevenue);
  
  void trackAdRevenue(String paramString, b paramb);
  
  void trackEvent(AdjustEvent paramAdjustEvent);
  
  void trackMeasurementConsent(boolean paramBoolean);
  
  void trackPlayStoreSubscription(AdjustPlayStoreSubscription paramAdjustPlayStoreSubscription);
  
  void trackThirdPartySharing(AdjustThirdPartySharing paramAdjustThirdPartySharing);
  
  boolean updateAttributionI(AdjustAttribution paramAdjustAttribution);
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\adjust\sdk\IActivityHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */