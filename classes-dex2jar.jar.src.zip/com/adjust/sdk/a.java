package com.adjust.sdk;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.Signature;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.util.DisplayMetrics;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public final class a {
  public String A;
  
  public String B;
  
  public int C;
  
  public String a;
  
  public String b;
  
  public int c = -1;
  
  public Boolean d;
  
  public boolean e = false;
  
  public String f;
  
  public String g;
  
  public String h;
  
  public String i;
  
  public String j;
  
  public String k;
  
  public String l;
  
  public String m;
  
  public String n;
  
  public String o;
  
  public String p;
  
  public String q;
  
  public String r;
  
  public String s;
  
  public String t;
  
  public String u;
  
  public String v;
  
  public String w;
  
  public String x;
  
  public String y;
  
  public String z;
  
  public a(Context paramContext, String paramString) {
    Resources resources = paramContext.getResources();
    DisplayMetrics displayMetrics = resources.getDisplayMetrics();
    Configuration configuration = resources.getConfiguration();
    Locale locale = Util.getLocale(configuration);
    int i = configuration.screenLayout;
    this.i = e(paramContext);
    this.j = c(paramContext);
    this.k = a(configuration);
    e();
    this.l = Build.MODEL;
    d();
    this.m = Build.MANUFACTURER;
    this.n = "android";
    g();
    this.o = Build.VERSION.RELEASE;
    this.p = b();
    this.q = b(locale);
    this.r = a(locale);
    this.s = b(i);
    this.t = a(i);
    this.u = c(displayMetrics);
    this.v = b(displayMetrics);
    this.w = a(displayMetrics);
    this.h = a(paramString);
    this.g = d(paramContext);
    f();
    this.x = Build.DISPLAY;
    this.y = a();
    this.z = c();
    this.A = a(paramContext);
    this.B = b(paramContext);
    this.C = b(configuration);
  }
  
  public final String a() {
    String[] arrayOfString = Util.getSupportedAbis();
    return (arrayOfString == null || arrayOfString.length == 0) ? Util.getCpuAbi() : arrayOfString[0];
  }
  
  public final String a(int paramInt) {
    paramInt &= 0x30;
    return (paramInt != 16) ? ((paramInt != 32) ? null : "long") : "normal";
  }
  
  public final String a(Context paramContext) {
    try {
      PackageInfo packageInfo = paramContext.getPackageManager().getPackageInfo(paramContext.getPackageName(), 4096);
      SimpleDateFormat simpleDateFormat = Util.dateFormatter;
      Date date = new Date();
      this(packageInfo.firstInstallTime);
      return simpleDateFormat.format(date);
    } catch (Exception exception) {
      return null;
    } 
  }
  
  public final String a(Configuration paramConfiguration) {
    if ((paramConfiguration.uiMode & 0xF) == 4)
      return "tv"; 
    int i = paramConfiguration.screenLayout & 0xF;
    return (i != 1 && i != 2) ? ((i != 3 && i != 4) ? null : "tablet") : "phone";
  }
  
  public final String a(DisplayMetrics paramDisplayMetrics) {
    return String.valueOf(paramDisplayMetrics.heightPixels);
  }
  
  public final String a(String paramString) {
    return (paramString == null) ? "android4.33.3" : Util.formatString("%s@%s", new Object[] { paramString, "android4.33.3" });
  }
  
  public final String a(Locale paramLocale) {
    return paramLocale.getCountry();
  }
  
  public final void a(AdjustConfig paramAdjustConfig) {
    if (!Util.canReadNonPlayIds(paramAdjustConfig))
      return; 
    if (this.e)
      return; 
    this.f = Util.getAndroidId(paramAdjustConfig.context);
    this.e = true;
  }
  
  public final int b(Configuration paramConfiguration) {
    return paramConfiguration.uiMode & 0xF;
  }
  
  public final String b() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("");
    stringBuilder.append(Build.VERSION.SDK_INT);
    return stringBuilder.toString();
  }
  
  public final String b(int paramInt) {
    paramInt &= 0xF;
    return (paramInt != 1) ? ((paramInt != 2) ? ((paramInt != 3) ? ((paramInt != 4) ? null : "xlarge") : "large") : "normal") : "small";
  }
  
  public final String b(Context paramContext) {
    try {
      PackageInfo packageInfo = paramContext.getPackageManager().getPackageInfo(paramContext.getPackageName(), 4096);
      SimpleDateFormat simpleDateFormat = Util.dateFormatter;
      Date date = new Date();
      this(packageInfo.lastUpdateTime);
      return simpleDateFormat.format(date);
    } catch (Exception exception) {
      return null;
    } 
  }
  
  public final String b(DisplayMetrics paramDisplayMetrics) {
    return String.valueOf(paramDisplayMetrics.widthPixels);
  }
  
  public final String b(Locale paramLocale) {
    return paramLocale.getLanguage();
  }
  
  public final void b(AdjustConfig paramAdjustConfig) {
    if (!Util.canReadPlayIds(paramAdjustConfig))
      return; 
    Context context = paramAdjustConfig.context;
    String str = this.a;
    Boolean bool = this.d;
    this.a = null;
    this.d = null;
    this.b = null;
    this.c = -1;
    byte b2 = 1;
    byte b1 = 1;
    while (true) {
      byte b = b2;
      if (b1 <= 3) {
        long l = (b1 * 3000);
        try {
          GooglePlayServicesClient.GooglePlayServicesInfo googlePlayServicesInfo = GooglePlayServicesClient.getGooglePlayServicesInfo(context, l);
          if (this.a == null)
            this.a = googlePlayServicesInfo.getGpsAdid(); 
          if (this.d == null)
            this.d = googlePlayServicesInfo.isTrackingEnabled(); 
          if (this.a != null && this.d != null) {
            this.b = "service";
            this.c = b1;
            return;
          } 
        } catch (Exception exception) {}
        b1++;
        continue;
      } 
      while (b <= 3) {
        Object object = Util.getAdvertisingInfoObject(context, 11000L);
        if (object != null) {
          if (this.a == null)
            this.a = Util.getPlayAdId(context, object, 1000L); 
          if (this.d == null)
            this.d = Util.isPlayTrackingEnabled(context, object, 1000L); 
          if (this.a != null && this.d != null) {
            this.b = "library";
            this.c = b;
            return;
          } 
        } 
        b++;
      } 
      if (this.a == null)
        this.a = str; 
      if (this.d == null)
        this.d = bool; 
      return;
    } 
  }
  
  public final String c() {
    return Build.ID;
  }
  
  public final String c(Context paramContext) {
    try {
      return (paramContext.getPackageManager().getPackageInfo(paramContext.getPackageName(), 0)).versionName;
    } catch (Exception exception) {
      return null;
    } 
  }
  
  public final String c(DisplayMetrics paramDisplayMetrics) {
    int i = paramDisplayMetrics.densityDpi;
    return (i == 0) ? null : ((i < 140) ? "low" : ((i > 200) ? "high" : "medium"));
  }
  
  public final String d(Context paramContext) {
    try {
      Signature[] arrayOfSignature = (paramContext.getPackageManager().getPackageInfo("com.facebook.katana", 64)).signatures;
      if (arrayOfSignature != null && arrayOfSignature.length == 1) {
        if (!"30820268308201d102044a9c4610300d06092a864886f70d0101040500307a310b3009060355040613025553310b3009060355040813024341311230100603550407130950616c6f20416c746f31183016060355040a130f46616365626f6f6b204d6f62696c653111300f060355040b130846616365626f6f6b311d301b0603550403131446616365626f6f6b20436f72706f726174696f6e3020170d3039303833313231353231365a180f32303530303932353231353231365a307a310b3009060355040613025553310b3009060355040813024341311230100603550407130950616c6f20416c746f31183016060355040a130f46616365626f6f6b204d6f62696c653111300f060355040b130846616365626f6f6b311d301b0603550403131446616365626f6f6b20436f72706f726174696f6e30819f300d06092a864886f70d010101050003818d0030818902818100c207d51df8eb8c97d93ba0c8c1002c928fab00dc1b42fca5e66e99cc3023ed2d214d822bc59e8e35ddcf5f44c7ae8ade50d7e0c434f500e6c131f4a2834f987fc46406115de2018ebbb0d5a3c261bd97581ccfef76afc7135a6d59e8855ecd7eacc8f8737e794c60a761c536b72b11fac8e603f5da1a2d54aa103b8a13c0dbc10203010001300d06092a864886f70d0101040500038181005ee9be8bcbb250648d3b741290a82a1c9dc2e76a0af2f2228f1d9f9c4007529c446a70175c5a900d5141812866db46be6559e2141616483998211f4a673149fb2232a10d247663b26a9031e15f84bc1c74d141ff98a02d76f85b2c8ab2571b6469b232d8e768a7f7ca04f7abe4a775615916c07940656b58717457b42bd928a2".equals(arrayOfSignature[0].toCharsString()))
          return null; 
        Cursor cursor = paramContext.getContentResolver().query(Uri.parse("content://com.facebook.katana.provider.AttributionIdProvider"), new String[] { "aid" }, null, null, null);
        if (cursor == null)
          return null; 
        if (!cursor.moveToFirst()) {
          cursor.close();
          return null;
        } 
        String str = cursor.getString(cursor.getColumnIndex("aid"));
        cursor.close();
        return str;
      } 
    } catch (Exception exception) {}
    return null;
  }
  
  public final void d() {
    String str = Build.MANUFACTURER;
  }
  
  public final String e(Context paramContext) {
    return paramContext.getPackageName();
  }
  
  public final void e() {
    String str = Build.MODEL;
  }
  
  public final void f() {
    String str = Build.DISPLAY;
  }
  
  public final void g() {
    String str = Build.VERSION.RELEASE;
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\adjust\sdk\a.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */