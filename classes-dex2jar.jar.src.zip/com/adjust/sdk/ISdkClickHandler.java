package com.adjust.sdk;

import com.adjust.sdk.network.IActivityPackageSender;

public interface ISdkClickHandler {
  void init(IActivityHandler paramIActivityHandler, boolean paramBoolean, IActivityPackageSender paramIActivityPackageSender);
  
  void pauseSending();
  
  void resumeSending();
  
  void sendPreinstallPayload(String paramString1, String paramString2);
  
  void sendReftagReferrers();
  
  void sendSdkClick(ActivityPackage paramActivityPackage);
  
  void teardown();
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\adjust\sdk\ISdkClickHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */