package com.adjust.sdk;

public enum LogLevel {
  ASSERT, DEBUG, ERROR, INFO, SUPRESS, VERBOSE, WARN;
  
  private static final LogLevel[] $VALUES;
  
  public final int androidLogLevel;
  
  static {
    LogLevel logLevel7 = new LogLevel("VERBOSE", 0, 2);
    VERBOSE = logLevel7;
    LogLevel logLevel6 = new LogLevel("DEBUG", 1, 3);
    DEBUG = logLevel6;
    LogLevel logLevel1 = new LogLevel("INFO", 2, 4);
    INFO = logLevel1;
    LogLevel logLevel2 = new LogLevel("WARN", 3, 5);
    WARN = logLevel2;
    LogLevel logLevel4 = new LogLevel("ERROR", 4, 6);
    ERROR = logLevel4;
    LogLevel logLevel5 = new LogLevel("ASSERT", 5, 7);
    ASSERT = logLevel5;
    LogLevel logLevel3 = new LogLevel("SUPRESS", 6, 8);
    SUPRESS = logLevel3;
    $VALUES = new LogLevel[] { logLevel7, logLevel6, logLevel1, logLevel2, logLevel4, logLevel5, logLevel3 };
  }
  
  LogLevel(int paramInt1) {
    this.androidLogLevel = paramInt1;
  }
  
  public int getAndroidLogLevel() {
    return this.androidLogLevel;
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\adjust\sdk\LogLevel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */