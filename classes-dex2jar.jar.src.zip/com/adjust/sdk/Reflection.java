package com.adjust.sdk;

import android.content.Context;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Map;

public class Reflection {
  public static Object createDefaultInstance(Class<Class<?>> paramClass) {
    try {
      return paramClass.newInstance();
    } finally {
      paramClass = null;
    } 
  }
  
  public static Object createDefaultInstance(String paramString) {
    Class clazz = forName(paramString);
    return (clazz == null) ? null : createDefaultInstance(clazz);
  }
  
  public static Object createInstance(String paramString, Class[] paramArrayOfClass, Object... paramVarArgs) {
    try {
      return Class.forName(paramString).getConstructor(paramArrayOfClass).newInstance(paramVarArgs);
    } finally {
      paramString = null;
    } 
  }
  
  public static Class forName(String paramString) {
    try {
      return Class.forName(paramString);
    } finally {
      paramString = null;
    } 
  }
  
  public static Object getAdvertisingInfoObject(Context paramContext) {
    return invokeStaticMethod("com.google.android.gms.ads.identifier.AdvertisingIdClient", "getAdvertisingIdInfo", new Class[] { Context.class }, new Object[] { paramContext });
  }
  
  public static Map<String, String> getImeiParameters(Context paramContext, ILogger paramILogger) {
    try {
      Object object = invokeStaticMethod("com.adjust.sdk.imei.Util", "getImeiParameters", new Class[] { Context.class, ILogger.class }, new Object[] { paramContext, paramILogger });
      if (object != null && Map.class.isInstance(object))
        return (Map)object; 
    } catch (Exception exception) {}
    return null;
  }
  
  public static Map<String, String> getOaidParameters(Context paramContext, ILogger paramILogger) {
    try {
      Object object = invokeStaticMethod("com.adjust.sdk.oaid.Util", "getOaidParameters", new Class[] { Context.class, ILogger.class }, new Object[] { paramContext, paramILogger });
      if (object != null && Map.class.isInstance(object))
        return (Map)object; 
    } catch (Exception exception) {}
    return null;
  }
  
  public static String getPlayAdId(Context paramContext, Object paramObject) {
    try {
      return (String)invokeInstanceMethod(paramObject, "getId", null, new Object[0]);
    } finally {
      paramContext = null;
    } 
  }
  
  public static ReferrerDetails getSamsungReferrer(Context paramContext, ILogger paramILogger) {
    StringBuilder stringBuilder;
    try {
      ReferrerDetails referrerDetails = (ReferrerDetails)invokeStaticMethod("com.adjust.sdk.samsung.Util", "getSamsungInstallReferrerDetails", new Class[] { Context.class, ILogger.class }, new Object[] { paramContext, paramILogger });
    } catch (Exception exception) {
      stringBuilder = new StringBuilder();
      stringBuilder.append("invoke getSamsungInstallReferrerDetails : ");
      stringBuilder.append(exception.getMessage());
      paramILogger.info(stringBuilder.toString(), new Object[0]);
      stringBuilder = null;
    } 
    return (ReferrerDetails)stringBuilder;
  }
  
  public static ReferrerDetails getVivoReferrer(Context paramContext, ILogger paramILogger) {
    StringBuilder stringBuilder;
    try {
      ReferrerDetails referrerDetails = (ReferrerDetails)invokeStaticMethod("com.adjust.sdk.vivo.Util", "getVivoInstallReferrerDetails", new Class[] { Context.class, ILogger.class }, new Object[] { paramContext, paramILogger });
    } catch (Exception exception) {
      stringBuilder = new StringBuilder();
      stringBuilder.append("invoke getVivoInstallReferrerDetails : ");
      stringBuilder.append(exception.getMessage());
      paramILogger.info(stringBuilder.toString(), new Object[0]);
      stringBuilder = null;
    } 
    return (ReferrerDetails)stringBuilder;
  }
  
  public static ReferrerDetails getXiaomiReferrer(Context paramContext, ILogger paramILogger) {
    try {
      ReferrerDetails referrerDetails = (ReferrerDetails)invokeStaticMethod("com.adjust.sdk.xiaomi.Util", "getXiaomiInstallReferrerDetails", new Class[] { Context.class, ILogger.class }, new Object[] { paramContext, paramILogger });
    } catch (Exception exception) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("invoke getXiaomiInstallReferrerDetails : ");
      stringBuilder.append(exception.getMessage());
      paramILogger.info(stringBuilder.toString(), new Object[0]);
      exception = null;
    } 
    return (ReferrerDetails)exception;
  }
  
  public static Object invokeInstanceMethod(Object paramObject, String paramString, Class[] paramArrayOfClass, Object... paramVarArgs) {
    return invokeMethod(paramObject.getClass(), paramString, paramObject, paramArrayOfClass, paramVarArgs);
  }
  
  public static Object invokeMethod(Class paramClass, String paramString, Object paramObject, Class[] paramArrayOfClass, Object... paramVarArgs) {
    Method method = paramClass.getMethod(paramString, paramArrayOfClass);
    return (method == null) ? null : method.invoke(paramObject, paramVarArgs);
  }
  
  public static Object invokeStaticMethod(String paramString1, String paramString2, Class[] paramArrayOfClass, Object... paramVarArgs) {
    return invokeMethod(Class.forName(paramString1), paramString2, null, paramArrayOfClass, paramVarArgs);
  }
  
  public static Boolean isPlayTrackingEnabled(Context paramContext, Object paramObject) {
    Object object;
    paramContext = null;
    try {
      paramObject = invokeInstanceMethod(paramObject, "isLimitAdTrackingEnabled", null, new Object[0]);
      if (paramObject != null) {
        paramObject = Boolean.valueOf(paramObject.booleanValue() ^ true);
        object = paramObject;
      } 
    } finally {}
    return (Boolean)object;
  }
  
  public static Object readField(String paramString1, String paramString2) {
    return readField(paramString1, paramString2, null);
  }
  
  public static Object readField(String paramString1, String paramString2, Object paramObject) {
    Class clazz = forName(paramString1);
    if (clazz == null)
      return null; 
    Field field = clazz.getField(paramString2);
    return (field == null) ? null : field.get(paramObject);
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\adjust\sdk\Reflection.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */