package com.adjust.sdk;

import android.net.Uri;
import com.adjust.sdk.network.IActivityPackageSender;
import com.adjust.sdk.scheduler.SingleThreadCachedScheduler;
import com.adjust.sdk.scheduler.ThreadScheduler;
import com.adjust.sdk.scheduler.TimerOnce;
import dbxyzptlk.WK.b;
import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.Map;

public class AttributionHandler implements IAttributionHandler, IActivityPackageSender.ResponseDataCallbackSubscriber {
  private static final String ATTRIBUTION_TIMER_NAME = "Attribution timer";
  
  private WeakReference<IActivityHandler> activityHandlerWeakRef;
  
  private IActivityPackageSender activityPackageSender;
  
  private String lastInitiatedBy;
  
  private ILogger logger = AdjustFactory.getLogger();
  
  private boolean paused;
  
  private ThreadScheduler scheduler = (ThreadScheduler)new SingleThreadCachedScheduler("AttributionHandler");
  
  private TimerOnce timer = new TimerOnce(new a(this), "Attribution timer");
  
  public AttributionHandler(IActivityHandler paramIActivityHandler, boolean paramBoolean, IActivityPackageSender paramIActivityPackageSender) {
    init(paramIActivityHandler, paramBoolean, paramIActivityPackageSender);
  }
  
  private ActivityPackage buildAndGetAttributionPackage() {
    long l = System.currentTimeMillis();
    IActivityHandler iActivityHandler = this.activityHandlerWeakRef.get();
    ActivityPackage activityPackage = (new PackageBuilder(iActivityHandler.getAdjustConfig(), iActivityHandler.getDeviceInfo(), iActivityHandler.getActivityState(), iActivityHandler.getSessionParameters(), l)).buildAttributionPackage(this.lastInitiatedBy);
    this.lastInitiatedBy = null;
    return activityPackage;
  }
  
  private void checkAttributionI(IActivityHandler paramIActivityHandler, ResponseData paramResponseData) {
    if (paramResponseData.jsonResponse == null)
      return; 
    Long long_ = paramResponseData.askIn;
    if (long_ != null && long_.longValue() >= 0L) {
      paramIActivityHandler.setAskingAttribution(true);
      this.lastInitiatedBy = "backend";
      getAttributionI(long_.longValue());
      return;
    } 
    paramIActivityHandler.setAskingAttribution(false);
  }
  
  private void checkAttributionResponseI(IActivityHandler paramIActivityHandler, AttributionResponseData paramAttributionResponseData) {
    checkAttributionI(paramIActivityHandler, (ResponseData)paramAttributionResponseData);
    checkDeeplinkI(paramAttributionResponseData);
    paramIActivityHandler.launchAttributionResponseTasks(paramAttributionResponseData);
  }
  
  private void checkDeeplinkI(AttributionResponseData paramAttributionResponseData) {
    b b = ((ResponseData)paramAttributionResponseData).jsonResponse;
    if (b == null)
      return; 
    b = b.z("attribution");
    if (b == null)
      return; 
    String str = b.D("deeplink", null);
    if (str == null)
      return; 
    paramAttributionResponseData.deeplink = Uri.parse(str);
  }
  
  private void checkSdkClickResponseI(IActivityHandler paramIActivityHandler, SdkClickResponseData paramSdkClickResponseData) {
    checkAttributionI(paramIActivityHandler, (ResponseData)paramSdkClickResponseData);
    paramIActivityHandler.launchSdkClickResponseTasks(paramSdkClickResponseData);
  }
  
  private void checkSessionResponseI(IActivityHandler paramIActivityHandler, SessionResponseData paramSessionResponseData) {
    checkAttributionI(paramIActivityHandler, (ResponseData)paramSessionResponseData);
    paramIActivityHandler.launchSessionResponseTasks(paramSessionResponseData);
  }
  
  private Map<String, String> generateSendingParametersI() {
    HashMap<Object, Object> hashMap = new HashMap<>();
    long l = System.currentTimeMillis();
    PackageBuilder.addString((Map)hashMap, "sent_at", Util.dateFormatter.format(Long.valueOf(l)));
    return (Map)hashMap;
  }
  
  private void getAttributionI(long paramLong) {
    if (this.timer.getFireIn() > paramLong)
      return; 
    if (paramLong != 0L) {
      double d = paramLong / 1000.0D;
      String str = Util.SecondsDisplayFormat.format(d);
      this.logger.debug("Waiting to query attribution in %s seconds", new Object[] { str });
    } 
    this.timer.startIn(paramLong);
  }
  
  private void sendAttributionRequest() {
    this.scheduler.submit((Runnable)new f(this));
  }
  
  private void sendAttributionRequestI() {
    if ((((IActivityHandler)this.activityHandlerWeakRef.get()).getActivityState()).isGdprForgotten)
      return; 
    if (this.paused) {
      this.logger.debug("Attribution handler is paused", new Object[0]);
      return;
    } 
    ActivityPackage activityPackage = buildAndGetAttributionPackage();
    this.logger.verbose("%s", new Object[] { activityPackage.getExtendedString() });
    Map<String, String> map = generateSendingParametersI();
    this.activityPackageSender.sendActivityPackage(activityPackage, map, this);
  }
  
  public void checkAttributionResponse(AttributionResponseData paramAttributionResponseData) {
    this.scheduler.submit((Runnable)new e(this, paramAttributionResponseData));
  }
  
  public void checkSdkClickResponse(SdkClickResponseData paramSdkClickResponseData) {
    this.scheduler.submit((Runnable)new d(this, paramSdkClickResponseData));
  }
  
  public void checkSessionResponse(SessionResponseData paramSessionResponseData) {
    this.scheduler.submit((Runnable)new c(this, paramSessionResponseData));
  }
  
  public void getAttribution() {
    this.scheduler.submit((Runnable)new b(this));
  }
  
  public void init(IActivityHandler paramIActivityHandler, boolean paramBoolean, IActivityPackageSender paramIActivityPackageSender) {
    this.activityHandlerWeakRef = new WeakReference<>(paramIActivityHandler);
    this.paused = paramBoolean ^ true;
    this.activityPackageSender = paramIActivityPackageSender;
  }
  
  public void onResponseDataCallback(ResponseData paramResponseData) {
    this.scheduler.submit((Runnable)new g(this, paramResponseData));
  }
  
  public void pauseSending() {
    this.paused = true;
  }
  
  public void resumeSending() {
    this.paused = false;
  }
  
  public void teardown() {
    this.logger.verbose("AttributionHandler teardown", new Object[0]);
    TimerOnce timerOnce = this.timer;
    if (timerOnce != null)
      timerOnce.teardown(); 
    ThreadScheduler threadScheduler = this.scheduler;
    if (threadScheduler != null)
      threadScheduler.teardown(); 
    WeakReference<IActivityHandler> weakReference = this.activityHandlerWeakRef;
    if (weakReference != null)
      weakReference.clear(); 
    this.timer = null;
    this.logger = null;
    this.scheduler = null;
    this.activityHandlerWeakRef = null;
  }
  
  public final class a implements Runnable {
    public final AttributionHandler a;
    
    public a(AttributionHandler this$0) {}
    
    public final void run() {
      this.a.sendAttributionRequest();
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\adjust\sdk\AttributionHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */