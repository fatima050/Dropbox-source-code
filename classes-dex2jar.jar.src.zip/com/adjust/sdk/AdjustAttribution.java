package com.adjust.sdk;

import dbxyzptlk.WK.b;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectStreamField;
import java.io.Serializable;

public class AdjustAttribution implements Serializable {
  private static final ObjectStreamField[] serialPersistentFields = new ObjectStreamField[] { 
      new ObjectStreamField("trackerToken", String.class), new ObjectStreamField("trackerName", String.class), new ObjectStreamField("network", String.class), new ObjectStreamField("campaign", String.class), new ObjectStreamField("adgroup", String.class), new ObjectStreamField("creative", String.class), new ObjectStreamField("clickLabel", String.class), new ObjectStreamField("adid", String.class), new ObjectStreamField("costType", String.class), new ObjectStreamField("costAmount", Double.class), 
      new ObjectStreamField("costCurrency", String.class), new ObjectStreamField("fbInstallReferrer", String.class) };
  
  private static final long serialVersionUID = 1L;
  
  public String adgroup;
  
  public String adid;
  
  public String campaign;
  
  public String clickLabel;
  
  public Double costAmount;
  
  public String costCurrency;
  
  public String costType;
  
  public String creative;
  
  public String fbInstallReferrer;
  
  public String network;
  
  public String trackerName;
  
  public String trackerToken;
  
  public static AdjustAttribution fromJson(b paramb, String paramString1, String paramString2) {
    String str;
    if (paramb == null)
      return null; 
    AdjustAttribution adjustAttribution = new AdjustAttribution();
    if ("unity".equals(paramString2)) {
      adjustAttribution.trackerToken = paramb.D("tracker_token", "");
      adjustAttribution.trackerName = paramb.D("tracker_name", "");
      adjustAttribution.network = paramb.D("network", "");
      adjustAttribution.campaign = paramb.D("campaign", "");
      adjustAttribution.adgroup = paramb.D("adgroup", "");
      adjustAttribution.creative = paramb.D("creative", "");
      adjustAttribution.clickLabel = paramb.D("click_label", "");
      if (paramString1 == null)
        paramString1 = ""; 
      adjustAttribution.adid = paramString1;
      adjustAttribution.costType = paramb.D("cost_type", "");
      adjustAttribution.costAmount = Double.valueOf(paramb.v("cost_amount", 0.0D));
      adjustAttribution.costCurrency = paramb.D("cost_currency", "");
      str = paramb.D("fb_install_referrer", "");
    } else {
      adjustAttribution.trackerToken = str.C("tracker_token");
      adjustAttribution.trackerName = str.C("tracker_name");
      adjustAttribution.network = str.C("network");
      adjustAttribution.campaign = str.C("campaign");
      adjustAttribution.adgroup = str.C("adgroup");
      adjustAttribution.creative = str.C("creative");
      adjustAttribution.clickLabel = str.C("click_label");
      adjustAttribution.adid = paramString1;
      adjustAttribution.costType = str.C("cost_type");
      adjustAttribution.costAmount = Double.valueOf(str.u("cost_amount"));
      adjustAttribution.costCurrency = str.C("cost_currency");
      str = str.C("fb_install_referrer");
    } 
    adjustAttribution.fbInstallReferrer = str;
    return adjustAttribution;
  }
  
  private void readObject(ObjectInputStream paramObjectInputStream) {
    paramObjectInputStream.defaultReadObject();
  }
  
  private void writeObject(ObjectOutputStream paramObjectOutputStream) {
    paramObjectOutputStream.defaultWriteObject();
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (paramObject == null)
      return false; 
    if (getClass() != paramObject.getClass())
      return false; 
    paramObject = paramObject;
    return !Util.equalString(this.trackerToken, ((AdjustAttribution)paramObject).trackerToken) ? false : (!Util.equalString(this.trackerName, ((AdjustAttribution)paramObject).trackerName) ? false : (!Util.equalString(this.network, ((AdjustAttribution)paramObject).network) ? false : (!Util.equalString(this.campaign, ((AdjustAttribution)paramObject).campaign) ? false : (!Util.equalString(this.adgroup, ((AdjustAttribution)paramObject).adgroup) ? false : (!Util.equalString(this.creative, ((AdjustAttribution)paramObject).creative) ? false : (!Util.equalString(this.clickLabel, ((AdjustAttribution)paramObject).clickLabel) ? false : (!Util.equalString(this.adid, ((AdjustAttribution)paramObject).adid) ? false : (!Util.equalString(this.costType, ((AdjustAttribution)paramObject).costType) ? false : (!Util.equalsDouble(this.costAmount, ((AdjustAttribution)paramObject).costAmount) ? false : (!Util.equalString(this.costCurrency, ((AdjustAttribution)paramObject).costCurrency) ? false : (!!Util.equalString(this.fbInstallReferrer, ((AdjustAttribution)paramObject).fbInstallReferrer))))))))))));
  }
  
  public int hashCode() {
    int i = Util.hashString(this.trackerToken, 17);
    i = Util.hashString(this.trackerName, i);
    i = Util.hashString(this.network, i);
    i = Util.hashString(this.campaign, i);
    i = Util.hashString(this.adgroup, i);
    i = Util.hashString(this.creative, i);
    i = Util.hashString(this.clickLabel, i);
    i = Util.hashString(this.adid, i);
    i = Util.hashString(this.costType, i);
    i = Util.hashDouble(this.costAmount, i);
    i = Util.hashString(this.costCurrency, i);
    return Util.hashString(this.fbInstallReferrer, i);
  }
  
  public String toString() {
    return Util.formatString("tt:%s tn:%s net:%s cam:%s adg:%s cre:%s cl:%s adid:%s ct:%s ca:%.2f cc:%s fir:%s", new Object[] { 
          this.trackerToken, this.trackerName, this.network, this.campaign, this.adgroup, this.creative, this.clickLabel, this.adid, this.costType, this.costAmount, 
          this.costCurrency, this.fbInstallReferrer });
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\adjust\sdk\AdjustAttribution.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */