package com.adjust.sdk;

import android.content.ContentResolver;
import android.content.Context;
import android.content.pm.ProviderInfo;
import android.content.res.Configuration;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.os.Build;
import android.os.LocaleList;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import com.adjust.sdk.scheduler.SingleThreadFutureScheduler;
import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.NotSerializableException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

public class Util {
  private static final String DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'Z";
  
  public static final DecimalFormat SecondsDisplayFormat = newLocalDecimalFormat();
  
  public static final SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'Z", Locale.US);
  
  private static final String fieldReadErrorMessage = "Unable to read '%s' field in migration device with message (%s)";
  
  private static volatile SingleThreadFutureScheduler playAdIdScheduler = null;
  
  public static boolean canReadNonPlayIds(AdjustConfig paramAdjustConfig) {
    return paramAdjustConfig.playStoreKidsAppEnabled ? false : (!paramAdjustConfig.coppaCompliantEnabled);
  }
  
  public static boolean canReadPlayIds(AdjustConfig paramAdjustConfig) {
    return paramAdjustConfig.playStoreKidsAppEnabled ? false : (!paramAdjustConfig.coppaCompliantEnabled);
  }
  
  public static boolean checkPermission(Context paramContext, String paramString) {
    boolean bool = false;
    try {
      int i = paramContext.checkCallingOrSelfPermission(paramString);
      if (i == 0)
        bool = true; 
      return bool;
    } catch (Exception exception) {
      getLogger().debug("Unable to check permission '%s' with message (%s)", new Object[] { paramString, exception.getMessage() });
      return false;
    } 
  }
  
  public static String convertToHex(byte[] paramArrayOfbyte) {
    BigInteger bigInteger = new BigInteger(1, paramArrayOfbyte);
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("%0");
    stringBuilder.append(paramArrayOfbyte.length << 1);
    stringBuilder.append("x");
    return formatString(stringBuilder.toString(), new Object[] { bigInteger });
  }
  
  public static String createUuid() {
    return UUID.randomUUID().toString();
  }
  
  public static boolean equalBoolean(Boolean paramBoolean1, Boolean paramBoolean2) {
    return equalObject(paramBoolean1, paramBoolean2);
  }
  
  public static boolean equalEnum(Enum paramEnum1, Enum paramEnum2) {
    return equalObject(paramEnum1, paramEnum2);
  }
  
  public static boolean equalInt(Integer paramInteger1, Integer paramInteger2) {
    return equalObject(paramInteger1, paramInteger2);
  }
  
  public static boolean equalLong(Long paramLong1, Long paramLong2) {
    return equalObject(paramLong1, paramLong2);
  }
  
  public static boolean equalObject(Object paramObject1, Object paramObject2) {
    if (paramObject1 == null || paramObject2 == null) {
      boolean bool;
      if (paramObject1 == null && paramObject2 == null) {
        bool = true;
      } else {
        bool = false;
      } 
      return bool;
    } 
    return paramObject1.equals(paramObject2);
  }
  
  public static boolean equalString(String paramString1, String paramString2) {
    return equalObject(paramString1, paramString2);
  }
  
  public static boolean equalsDouble(Double paramDouble1, Double paramDouble2) {
    boolean bool2 = false;
    boolean bool1 = false;
    if (paramDouble1 == null || paramDouble2 == null) {
      bool1 = bool2;
      if (paramDouble1 == null) {
        bool1 = bool2;
        if (paramDouble2 == null)
          bool1 = true; 
      } 
      return bool1;
    } 
    if (Double.doubleToLongBits(paramDouble1.doubleValue()) == Double.doubleToLongBits(paramDouble2.doubleValue()))
      bool1 = true; 
    return bool1;
  }
  
  public static String formatString(String paramString, Object... paramVarArgs) {
    return String.format(Locale.US, paramString, paramVarArgs);
  }
  
  public static Object getAdvertisingInfoObject(Context paramContext, long paramLong) {
    return runSyncInPlayAdIdSchedulerWithTimeout(paramContext, (Callable<?>)new a(paramContext), paramLong);
  }
  
  public static String getAndroidId(Context paramContext) {
    return AndroidIdUtil.getAndroidId(paramContext);
  }
  
  public static int getConnectivityType(Context paramContext) {
    try {
      ConnectivityManager connectivityManager = (ConnectivityManager)paramContext.getSystemService("connectivity");
      if (connectivityManager == null)
        return -1; 
      int i = Build.VERSION.SDK_INT;
      Network network = connectivityManager.getActiveNetwork();
      if (network == null)
        return -1; 
      NetworkCapabilities networkCapabilities = connectivityManager.getNetworkCapabilities(network);
      if (networkCapabilities == null)
        return -1; 
      if (networkCapabilities.hasTransport(1))
        return 1; 
      if (networkCapabilities.hasTransport(0))
        return 0; 
      if (networkCapabilities.hasTransport(3))
        return 3; 
      if (networkCapabilities.hasTransport(4))
        return 4; 
      if (networkCapabilities.hasTransport(2))
        return 2; 
      if (networkCapabilities.hasTransport(5))
        return 5; 
      if (i < 27)
        return -1; 
      boolean bool = networkCapabilities.hasTransport(6);
      if (bool)
        return 6; 
    } catch (Exception exception) {
      getLogger().warn("Couldn't read connectivity type (%s)", new Object[] { exception.getMessage() });
    } 
    return -1;
  }
  
  public static String getCpuAbi() {
    return null;
  }
  
  public static String getFireAdvertisingId(ContentResolver paramContentResolver) {
    if (paramContentResolver == null)
      return null; 
    try {
      return Settings.Secure.getString(paramContentResolver, "advertising_id");
    } catch (Exception exception) {
      return null;
    } 
  }
  
  public static String getFireAdvertisingId(AdjustConfig paramAdjustConfig) {
    return paramAdjustConfig.coppaCompliantEnabled ? null : getFireAdvertisingId(paramAdjustConfig.context.getContentResolver());
  }
  
  public static Boolean getFireTrackingEnabled(ContentResolver paramContentResolver) {
    try {
      boolean bool;
      if (Settings.Secure.getInt(paramContentResolver, "limit_ad_tracking") == 0) {
        bool = true;
      } else {
        bool = false;
      } 
      return Boolean.valueOf(bool);
    } catch (Exception exception) {
      return null;
    } 
  }
  
  public static Boolean getFireTrackingEnabled(AdjustConfig paramAdjustConfig) {
    return paramAdjustConfig.coppaCompliantEnabled ? null : getFireTrackingEnabled(paramAdjustConfig.context.getContentResolver());
  }
  
  private static String getGoogleAdId(Context paramContext) {
    // Byte code:
    //   0: aload_0
    //   1: ldc2_w 11000
    //   4: invokestatic getGooglePlayServicesInfo : (Landroid/content/Context;J)Lcom/adjust/sdk/GooglePlayServicesClient$GooglePlayServicesInfo;
    //   7: astore_1
    //   8: aload_1
    //   9: ifnull -> 20
    //   12: aload_1
    //   13: invokevirtual getGpsAdid : ()Ljava/lang/String;
    //   16: astore_1
    //   17: goto -> 22
    //   20: aconst_null
    //   21: astore_1
    //   22: aload_1
    //   23: astore_2
    //   24: aload_1
    //   25: ifnonnull -> 51
    //   28: aload_0
    //   29: ldc2_w 11000
    //   32: invokestatic getAdvertisingInfoObject : (Landroid/content/Context;J)Ljava/lang/Object;
    //   35: astore_3
    //   36: aload_1
    //   37: astore_2
    //   38: aload_3
    //   39: ifnull -> 51
    //   42: aload_0
    //   43: aload_3
    //   44: ldc2_w 1000
    //   47: invokestatic getPlayAdId : (Landroid/content/Context;Ljava/lang/Object;J)Ljava/lang/String;
    //   50: astore_2
    //   51: aload_2
    //   52: areturn
    //   53: astore_1
    //   54: goto -> 20
    // Exception table:
    //   from	to	target	type
    //   0	8	53	java/lang/Exception
    //   12	17	53	java/lang/Exception
  }
  
  public static void getGoogleAdId(Context paramContext, OnDeviceIdsRead paramOnDeviceIdsRead) {
    (new d(paramOnDeviceIdsRead)).execute((Object[])new Context[] { paramContext });
  }
  
  public static Map<String, String> getImeiParameters(AdjustConfig paramAdjustConfig, ILogger paramILogger) {
    return paramAdjustConfig.coppaCompliantEnabled ? null : Reflection.getImeiParameters(paramAdjustConfig.context, paramILogger);
  }
  
  public static Locale getLocale(Configuration paramConfiguration) {
    LocaleList localeList = paramConfiguration.getLocales();
    return (localeList != null && !localeList.isEmpty()) ? localeList.get(0) : null;
  }
  
  private static ILogger getLogger() {
    return AdjustFactory.getLogger();
  }
  
  public static String getMcc(Context paramContext) {
    try {
      null = ((TelephonyManager)paramContext.getSystemService("phone")).getNetworkOperator();
      if (TextUtils.isEmpty(null)) {
        AdjustFactory.getLogger().warn("Couldn't receive networkOperator string to read MCC", new Object[0]);
        return null;
      } 
      return null.substring(0, 3);
    } catch (Exception exception) {
      AdjustFactory.getLogger().warn("Couldn't return mcc", new Object[0]);
      return null;
    } 
  }
  
  public static String getMnc(Context paramContext) {
    try {
      null = ((TelephonyManager)paramContext.getSystemService("phone")).getNetworkOperator();
      if (TextUtils.isEmpty(null)) {
        AdjustFactory.getLogger().warn("Couldn't receive networkOperator string to read MNC", new Object[0]);
        return null;
      } 
      return null.substring(3);
    } catch (Exception exception) {
      AdjustFactory.getLogger().warn("Couldn't return mnc", new Object[0]);
      return null;
    } 
  }
  
  public static Map<String, String> getOaidParameters(AdjustConfig paramAdjustConfig, ILogger paramILogger) {
    return paramAdjustConfig.coppaCompliantEnabled ? null : Reflection.getOaidParameters(paramAdjustConfig.context, paramILogger);
  }
  
  public static String getPlayAdId(Context paramContext, Object paramObject, long paramLong) {
    return runSyncInPlayAdIdSchedulerWithTimeout(paramContext, (Callable<String>)new b(paramContext, paramObject), paramLong);
  }
  
  public static String getReasonString(String paramString, Throwable paramThrowable) {
    return (paramThrowable != null) ? formatString("%s: %s", new Object[] { paramString, paramThrowable }) : formatString("%s", new Object[] { paramString });
  }
  
  public static String getRootCause(Exception paramException) {
    if (!hasRootCause(paramException))
      return null; 
    StringWriter stringWriter = new StringWriter();
    paramException.printStackTrace(new PrintWriter(stringWriter));
    String str = stringWriter.toString();
    int i = str.indexOf("Caused by:");
    return str.substring(i, str.indexOf("\n", i));
  }
  
  private static String getSdkPrefix(String paramString) {
    if (paramString == null)
      return null; 
    if (!paramString.contains("@"))
      return null; 
    String[] arrayOfString = paramString.split("@");
    return (arrayOfString == null) ? null : ((arrayOfString.length != 2) ? null : arrayOfString[0]);
  }
  
  public static String getSdkPrefixPlatform(String paramString) {
    paramString = getSdkPrefix(paramString);
    if (paramString == null)
      return null; 
    String[] arrayOfString = paramString.split("\\d+", 2);
    return (arrayOfString == null) ? null : ((arrayOfString.length == 0) ? null : arrayOfString[0]);
  }
  
  public static String getSdkVersion() {
    return "android4.33.3";
  }
  
  public static String[] getSupportedAbis() {
    return Build.SUPPORTED_ABIS;
  }
  
  public static long getWaitingTime(int paramInt, BackoffStrategy paramBackoffStrategy) {
    int i = paramBackoffStrategy.minRetries;
    if (paramInt < i)
      return 0L; 
    long l = Math.min((long)Math.pow(2.0D, (paramInt - i)) * paramBackoffStrategy.milliSecondMultiplier, paramBackoffStrategy.maxWait);
    double d = randomInRange(paramBackoffStrategy.minRange, paramBackoffStrategy.maxRange);
    return (long)(l * d);
  }
  
  public static boolean hasRootCause(Exception paramException) {
    StringWriter stringWriter = new StringWriter();
    paramException.printStackTrace(new PrintWriter(stringWriter));
    return stringWriter.toString().contains("Caused by:");
  }
  
  public static String hash(String paramString1, String paramString2) {
    try {
      byte[] arrayOfByte = paramString1.getBytes("UTF-8");
      MessageDigest messageDigest = MessageDigest.getInstance(paramString2);
      messageDigest.update(arrayOfByte, 0, arrayOfByte.length);
      String str = convertToHex(messageDigest.digest());
    } catch (Exception exception) {
      exception = null;
    } 
    return (String)exception;
  }
  
  public static int hashBoolean(Boolean paramBoolean, int paramInt) {
    paramInt *= 37;
    return (paramBoolean == null) ? paramInt : (paramBoolean.hashCode() + paramInt);
  }
  
  public static int hashDouble(Double paramDouble, int paramInt) {
    paramInt *= 37;
    return (paramDouble == null) ? paramInt : (paramDouble.hashCode() + paramInt);
  }
  
  public static int hashEnum(Enum paramEnum, int paramInt) {
    paramInt *= 37;
    return (paramEnum == null) ? paramInt : (paramEnum.hashCode() + paramInt);
  }
  
  public static int hashLong(Long paramLong, int paramInt) {
    paramInt *= 37;
    return (paramLong == null) ? paramInt : (paramLong.hashCode() + paramInt);
  }
  
  public static int hashObject(Object paramObject, int paramInt) {
    paramInt *= 37;
    return (paramObject == null) ? paramInt : (paramObject.hashCode() + paramInt);
  }
  
  public static int hashString(String paramString, int paramInt) {
    paramInt *= 37;
    return (paramString == null) ? paramInt : (paramString.hashCode() + paramInt);
  }
  
  public static boolean isAdjustUninstallDetectionPayload(Map<String, String> paramMap) {
    boolean bool2 = false;
    if (paramMap == null)
      return false; 
    boolean bool1 = bool2;
    if (paramMap.size() == 1) {
      bool1 = bool2;
      if (Objects.equals(paramMap.get("adjust_purpose"), "uninstall detection"))
        bool1 = true; 
    } 
    return bool1;
  }
  
  private static boolean isEqualGoogleReferrerDetails(ReferrerDetails paramReferrerDetails, ActivityState paramActivityState) {
    boolean bool;
    if (paramReferrerDetails.referrerClickTimestampSeconds == paramActivityState.clickTime && paramReferrerDetails.installBeginTimestampSeconds == paramActivityState.installBegin && paramReferrerDetails.referrerClickTimestampServerSeconds == paramActivityState.clickTimeServer && paramReferrerDetails.installBeginTimestampServerSeconds == paramActivityState.installBeginServer && equalString(paramReferrerDetails.installReferrer, paramActivityState.installReferrer) && equalString(paramReferrerDetails.installVersion, paramActivityState.installVersion) && equalBoolean(paramReferrerDetails.googlePlayInstant, paramActivityState.googlePlayInstant)) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  private static boolean isEqualHuaweiReferrerAdsDetails(ReferrerDetails paramReferrerDetails, ActivityState paramActivityState) {
    boolean bool;
    if (paramReferrerDetails.referrerClickTimestampSeconds == paramActivityState.clickTimeHuawei && paramReferrerDetails.installBeginTimestampSeconds == paramActivityState.installBeginHuawei && equalString(paramReferrerDetails.installReferrer, paramActivityState.installReferrerHuawei)) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  private static boolean isEqualHuaweiReferrerAppGalleryDetails(ReferrerDetails paramReferrerDetails, ActivityState paramActivityState) {
    boolean bool;
    if (paramReferrerDetails.referrerClickTimestampSeconds == paramActivityState.clickTimeHuawei && paramReferrerDetails.installBeginTimestampSeconds == paramActivityState.installBeginHuawei && equalString(paramReferrerDetails.installReferrer, paramActivityState.installReferrerHuaweiAppGallery)) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public static boolean isEqualReferrerDetails(ReferrerDetails paramReferrerDetails, String paramString, ActivityState paramActivityState) {
    return paramString.equals("google") ? isEqualGoogleReferrerDetails(paramReferrerDetails, paramActivityState) : (paramString.equals("huawei_ads") ? isEqualHuaweiReferrerAdsDetails(paramReferrerDetails, paramActivityState) : (paramString.equals("huawei_app_gallery") ? isEqualHuaweiReferrerAppGalleryDetails(paramReferrerDetails, paramActivityState) : (paramString.equals("samsung") ? isEqualSamsungReferrerDetails(paramReferrerDetails, paramActivityState) : (paramString.equals("xiaomi") ? isEqualXiaomiReferrerDetails(paramReferrerDetails, paramActivityState) : (paramString.equals("vivo") ? isEqualVivoReferrerDetails(paramReferrerDetails, paramActivityState) : false)))));
  }
  
  private static boolean isEqualSamsungReferrerDetails(ReferrerDetails paramReferrerDetails, ActivityState paramActivityState) {
    boolean bool;
    if (paramReferrerDetails.referrerClickTimestampSeconds == paramActivityState.clickTimeSamsung && paramReferrerDetails.installBeginTimestampSeconds == paramActivityState.installBeginSamsung && equalString(paramReferrerDetails.installReferrer, paramActivityState.installReferrerSamsung)) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  private static boolean isEqualVivoReferrerDetails(ReferrerDetails paramReferrerDetails, ActivityState paramActivityState) {
    boolean bool;
    if (paramReferrerDetails.referrerClickTimestampSeconds == paramActivityState.clickTimeVivo && paramReferrerDetails.installBeginTimestampSeconds == paramActivityState.installBeginVivo && equalString(paramReferrerDetails.installReferrer, paramActivityState.installReferrerVivo) && equalString(paramReferrerDetails.installVersion, paramActivityState.installVersionVivo)) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  private static boolean isEqualXiaomiReferrerDetails(ReferrerDetails paramReferrerDetails, ActivityState paramActivityState) {
    boolean bool;
    if (paramReferrerDetails.referrerClickTimestampSeconds == paramActivityState.clickTimeXiaomi && paramReferrerDetails.installBeginTimestampSeconds == paramActivityState.installBeginXiaomi && paramReferrerDetails.referrerClickTimestampServerSeconds == paramActivityState.clickTimeServerXiaomi && paramReferrerDetails.installBeginTimestampServerSeconds == paramActivityState.installBeginServerXiaomi && equalString(paramReferrerDetails.installReferrer, paramActivityState.installReferrerXiaomi) && equalString(paramReferrerDetails.installVersion, paramActivityState.installVersionXiaomi)) {
      bool = true;
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public static Boolean isPlayTrackingEnabled(Context paramContext, Object paramObject, long paramLong) {
    return runSyncInPlayAdIdSchedulerWithTimeout(paramContext, (Callable<Boolean>)new c(paramContext, paramObject), paramLong);
  }
  
  public static boolean isUrlFilteredOut(Uri paramUri) {
    if (paramUri == null)
      return true; 
    String str = paramUri.toString();
    return (str == null || str.length() == 0) ? true : (str.matches("^(fb|vk)[0-9]{5,}[^:]*://authorize.*access_token=.*"));
  }
  
  public static boolean isValidParameter(String paramString1, String paramString2, String paramString3) {
    if (paramString1 == null) {
      getLogger().error("%s parameter %s is missing", new Object[] { paramString3, paramString2 });
      return false;
    } 
    if (paramString1.equals("")) {
      getLogger().error("%s parameter %s is empty", new Object[] { paramString3, paramString2 });
      return false;
    } 
    return true;
  }
  
  public static Map<String, String> mergeParameters(Map<String, String> paramMap1, Map<String, String> paramMap2, String paramString) {
    if (paramMap1 == null)
      return paramMap2; 
    if (paramMap2 == null)
      return paramMap1; 
    paramMap1 = new HashMap<>(paramMap1);
    ILogger iLogger = getLogger();
    for (Map.Entry<String, String> entry : paramMap2.entrySet()) {
      String str = paramMap1.put((String)entry.getKey(), (String)entry.getValue());
      if (str != null)
        iLogger.warn("Key %s with value %s from %s parameter was replaced by value %s", new Object[] { entry.getKey(), str, paramString, entry.getValue() }); 
    } 
    return paramMap1;
  }
  
  private static DecimalFormat newLocalDecimalFormat() {
    return new DecimalFormat("0.0", new DecimalFormatSymbols(Locale.US));
  }
  
  public static String quote(String paramString) {
    return (paramString == null) ? null : (!Pattern.compile("\\s").matcher(paramString).find() ? paramString : formatString("'%s'", new Object[] { paramString }));
  }
  
  private static double randomInRange(double paramDouble1, double paramDouble2) {
    return (new Random()).nextDouble() * (paramDouble2 - paramDouble1) + paramDouble1;
  }
  
  public static boolean readBooleanField(ObjectInputStream.GetField paramGetField, String paramString, boolean paramBoolean) {
    try {
      return paramGetField.get(paramString, paramBoolean);
    } catch (Exception exception) {
      getLogger().debug("Unable to read '%s' field in migration device with message (%s)", new Object[] { paramString, exception.getMessage() });
      return paramBoolean;
    } 
  }
  
  public static int readIntField(ObjectInputStream.GetField paramGetField, String paramString, int paramInt) {
    try {
      return paramGetField.get(paramString, paramInt);
    } catch (Exception exception) {
      getLogger().debug("Unable to read '%s' field in migration device with message (%s)", new Object[] { paramString, exception.getMessage() });
      return paramInt;
    } 
  }
  
  public static long readLongField(ObjectInputStream.GetField paramGetField, String paramString, long paramLong) {
    try {
      return paramGetField.get(paramString, paramLong);
    } catch (Exception exception) {
      getLogger().debug("Unable to read '%s' field in migration device with message (%s)", new Object[] { paramString, exception.getMessage() });
      return paramLong;
    } 
  }
  
  public static <T> T readObject(Context paramContext, String paramString1, String paramString2, Class<T> paramClass) {
    // Byte code:
    //   0: aconst_null
    //   1: astore #12
    //   3: aconst_null
    //   4: astore #6
    //   6: aconst_null
    //   7: astore #9
    //   9: aconst_null
    //   10: astore #14
    //   12: aconst_null
    //   13: astore #4
    //   15: aconst_null
    //   16: astore #10
    //   18: aconst_null
    //   19: astore #7
    //   21: aconst_null
    //   22: astore #11
    //   24: aconst_null
    //   25: astore #13
    //   27: aload_0
    //   28: aload_1
    //   29: invokevirtual openFileInput : (Ljava/lang/String;)Ljava/io/FileInputStream;
    //   32: astore #5
    //   34: aload #9
    //   36: astore_0
    //   37: aload #5
    //   39: astore #7
    //   41: aload #14
    //   43: astore_1
    //   44: aload #5
    //   46: astore #8
    //   48: new java/io/BufferedInputStream
    //   51: astore #4
    //   53: aload #9
    //   55: astore_0
    //   56: aload #5
    //   58: astore #7
    //   60: aload #14
    //   62: astore_1
    //   63: aload #5
    //   65: astore #8
    //   67: aload #4
    //   69: aload #5
    //   71: invokespecial <init> : (Ljava/io/InputStream;)V
    //   74: new java/io/ObjectInputStream
    //   77: astore #9
    //   79: aload #9
    //   81: aload #4
    //   83: invokespecial <init> : (Ljava/io/InputStream;)V
    //   86: aload #13
    //   88: astore #4
    //   90: aload #12
    //   92: astore #5
    //   94: aload_3
    //   95: aload #9
    //   97: invokevirtual readObject : ()Ljava/lang/Object;
    //   100: invokevirtual cast : (Ljava/lang/Object;)Ljava/lang/Object;
    //   103: astore_0
    //   104: aload_0
    //   105: astore #4
    //   107: aload_0
    //   108: astore #5
    //   110: aload_0
    //   111: astore #6
    //   113: invokestatic getLogger : ()Lcom/adjust/sdk/ILogger;
    //   116: ldc_w 'Read %s: %s'
    //   119: iconst_2
    //   120: anewarray java/lang/Object
    //   123: dup
    //   124: iconst_0
    //   125: aload_2
    //   126: aastore
    //   127: dup
    //   128: iconst_1
    //   129: aload_0
    //   130: aastore
    //   131: invokeinterface debug : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   136: aload_0
    //   137: astore #4
    //   139: aload #9
    //   141: astore_1
    //   142: goto -> 403
    //   145: astore_3
    //   146: goto -> 157
    //   149: astore_3
    //   150: goto -> 221
    //   153: astore_3
    //   154: goto -> 271
    //   157: aload #4
    //   159: astore_0
    //   160: aload #9
    //   162: astore #7
    //   164: aload #4
    //   166: astore_1
    //   167: aload #9
    //   169: astore #8
    //   171: invokestatic getLogger : ()Lcom/adjust/sdk/ILogger;
    //   174: ldc_w 'Failed to read %s object (%s)'
    //   177: iconst_2
    //   178: anewarray java/lang/Object
    //   181: dup
    //   182: iconst_0
    //   183: aload_2
    //   184: aastore
    //   185: dup
    //   186: iconst_1
    //   187: aload_3
    //   188: invokevirtual getMessage : ()Ljava/lang/String;
    //   191: aastore
    //   192: invokeinterface error : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   197: aload #9
    //   199: astore_1
    //   200: goto -> 403
    //   203: astore_1
    //   204: aload_0
    //   205: astore_3
    //   206: aload #7
    //   208: astore_0
    //   209: goto -> 338
    //   212: astore_0
    //   213: aload_1
    //   214: astore_0
    //   215: aload #8
    //   217: astore_1
    //   218: goto -> 381
    //   221: aload #5
    //   223: astore_0
    //   224: aload #9
    //   226: astore #7
    //   228: aload #5
    //   230: astore_1
    //   231: aload #9
    //   233: astore #8
    //   235: invokestatic getLogger : ()Lcom/adjust/sdk/ILogger;
    //   238: ldc_w 'Failed to cast %s object (%s)'
    //   241: iconst_2
    //   242: anewarray java/lang/Object
    //   245: dup
    //   246: iconst_0
    //   247: aload_2
    //   248: aastore
    //   249: dup
    //   250: iconst_1
    //   251: aload_3
    //   252: invokevirtual getMessage : ()Ljava/lang/String;
    //   255: aastore
    //   256: invokeinterface error : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   261: aload #5
    //   263: astore #4
    //   265: aload #9
    //   267: astore_1
    //   268: goto -> 403
    //   271: aload #6
    //   273: astore_0
    //   274: aload #9
    //   276: astore #7
    //   278: aload #6
    //   280: astore_1
    //   281: aload #9
    //   283: astore #8
    //   285: invokestatic getLogger : ()Lcom/adjust/sdk/ILogger;
    //   288: ldc_w 'Failed to find %s class (%s)'
    //   291: iconst_2
    //   292: anewarray java/lang/Object
    //   295: dup
    //   296: iconst_0
    //   297: aload_2
    //   298: aastore
    //   299: dup
    //   300: iconst_1
    //   301: aload_3
    //   302: invokevirtual getMessage : ()Ljava/lang/String;
    //   305: aastore
    //   306: invokeinterface error : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   311: aload #6
    //   313: astore #4
    //   315: aload #9
    //   317: astore_1
    //   318: goto -> 403
    //   321: astore #5
    //   323: aload #10
    //   325: astore_0
    //   326: aload #4
    //   328: astore_1
    //   329: goto -> 345
    //   332: astore_1
    //   333: aconst_null
    //   334: astore_3
    //   335: aload #4
    //   337: astore_0
    //   338: aload_1
    //   339: astore #5
    //   341: aload_0
    //   342: astore_1
    //   343: aload_3
    //   344: astore_0
    //   345: invokestatic getLogger : ()Lcom/adjust/sdk/ILogger;
    //   348: ldc_w 'Failed to open %s file for reading (%s)'
    //   351: iconst_2
    //   352: anewarray java/lang/Object
    //   355: dup
    //   356: iconst_0
    //   357: aload_2
    //   358: aastore
    //   359: dup
    //   360: iconst_1
    //   361: aload #5
    //   363: aastore
    //   364: invokeinterface error : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   369: aload_0
    //   370: astore #4
    //   372: goto -> 403
    //   375: astore_0
    //   376: aconst_null
    //   377: astore_0
    //   378: aload #7
    //   380: astore_1
    //   381: invokestatic getLogger : ()Lcom/adjust/sdk/ILogger;
    //   384: ldc_w '%s file not found'
    //   387: iconst_1
    //   388: anewarray java/lang/Object
    //   391: dup
    //   392: iconst_0
    //   393: aload_2
    //   394: aastore
    //   395: invokeinterface debug : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   400: goto -> 369
    //   403: aload_1
    //   404: ifnull -> 440
    //   407: aload_1
    //   408: invokeinterface close : ()V
    //   413: goto -> 440
    //   416: astore_0
    //   417: invokestatic getLogger : ()Lcom/adjust/sdk/ILogger;
    //   420: ldc_w 'Failed to close %s file for reading (%s)'
    //   423: iconst_2
    //   424: anewarray java/lang/Object
    //   427: dup
    //   428: iconst_0
    //   429: aload_2
    //   430: aastore
    //   431: dup
    //   432: iconst_1
    //   433: aload_0
    //   434: aastore
    //   435: invokeinterface error : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   440: aload #4
    //   442: areturn
    //   443: astore_0
    //   444: aload #11
    //   446: astore_0
    //   447: aload #4
    //   449: astore_1
    //   450: goto -> 381
    // Exception table:
    //   from	to	target	type
    //   27	34	375	java/io/FileNotFoundException
    //   27	34	332	java/lang/Exception
    //   48	53	212	java/io/FileNotFoundException
    //   48	53	203	java/lang/Exception
    //   67	74	212	java/io/FileNotFoundException
    //   67	74	203	java/lang/Exception
    //   74	86	443	java/io/FileNotFoundException
    //   74	86	321	java/lang/Exception
    //   94	104	153	java/lang/ClassNotFoundException
    //   94	104	149	java/lang/ClassCastException
    //   94	104	145	java/lang/Exception
    //   113	136	153	java/lang/ClassNotFoundException
    //   113	136	149	java/lang/ClassCastException
    //   113	136	145	java/lang/Exception
    //   171	197	212	java/io/FileNotFoundException
    //   171	197	203	java/lang/Exception
    //   235	261	212	java/io/FileNotFoundException
    //   235	261	203	java/lang/Exception
    //   285	311	212	java/io/FileNotFoundException
    //   285	311	203	java/lang/Exception
    //   407	413	416	java/lang/Exception
  }
  
  public static <T> T readObjectField(ObjectInputStream.GetField paramGetField, String paramString, T paramT) {
    try {
      return (T)paramGetField.get(paramString, paramT);
    } catch (Exception exception) {
      getLogger().debug("Unable to read '%s' field in migration device with message (%s)", new Object[] { paramString, exception.getMessage() });
      return paramT;
    } 
  }
  
  public static String readStringField(ObjectInputStream.GetField paramGetField, String paramString1, String paramString2) {
    return readObjectField(paramGetField, paramString1, paramString2);
  }
  
  public static boolean resolveContentProvider(Context paramContext, String paramString) {
    boolean bool = false;
    try {
      ProviderInfo providerInfo = paramContext.getPackageManager().resolveContentProvider(paramString, 0);
      if (providerInfo != null)
        bool = true; 
    } catch (Exception exception) {}
    return bool;
  }
  
  private static <R> R runSyncInPlayAdIdSchedulerWithTimeout(Context paramContext, Callable<R> paramCallable, long paramLong) {
    /* monitor enter TypeReferenceDotClassExpression{ObjectType{com/adjust/sdk/Util}} */
    if (playAdIdScheduler == null) {
      try {
        if (playAdIdScheduler == null) {
          SingleThreadFutureScheduler singleThreadFutureScheduler = new SingleThreadFutureScheduler();
          this("PlayAdIdLibrary", true);
          playAdIdScheduler = singleThreadFutureScheduler;
        } 
      } finally {}
      /* monitor exit TypeReferenceDotClassExpression{ObjectType{com/adjust/sdk/Util}} */
    } 
    ScheduledFuture<ScheduledFuture> scheduledFuture = playAdIdScheduler.scheduleFutureWithReturn(paramCallable, 0L);
    try {
      return (R)scheduledFuture.get(paramLong, TimeUnit.MILLISECONDS);
    } catch (ExecutionException|InterruptedException|java.util.concurrent.TimeoutException executionException) {
      return null;
    } 
  }
  
  public static String sha256(String paramString) {
    return hash(paramString, "SHA-256");
  }
  
  public static <T> void writeObject(T paramT, Context paramContext, String paramString1, String paramString2) {
    try {
      FileOutputStream fileOutputStream2 = paramContext.openFileOutput(paramString1, 0);
      FileOutputStream fileOutputStream1 = fileOutputStream2;
      try {
        BufferedOutputStream bufferedOutputStream = new BufferedOutputStream();
        fileOutputStream1 = fileOutputStream2;
        this(fileOutputStream2);
        try {
          ObjectOutputStream objectOutputStream2 = new ObjectOutputStream();
          this(bufferedOutputStream);
          ObjectOutputStream objectOutputStream1 = objectOutputStream2;
          try {
            objectOutputStream2.writeObject(paramT);
            objectOutputStream1 = objectOutputStream2;
            getLogger().debug("Wrote %s: %s", new Object[] { paramString2, paramT });
            objectOutputStream1 = objectOutputStream2;
          } catch (NotSerializableException null) {
            objectOutputStream1 = objectOutputStream2;
            getLogger().error("Failed to serialize %s", new Object[] { paramString2 });
            objectOutputStream1 = objectOutputStream2;
          } 
        } catch (Exception null) {
          BufferedOutputStream bufferedOutputStream1 = bufferedOutputStream;
        } 
      } catch (Exception null) {}
    } catch (Exception exception) {
      paramContext = null;
    } 
    getLogger().error("Failed to open %s for writing (%s)", new Object[] { paramString2, exception });
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\adjust\sdk\Util.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */