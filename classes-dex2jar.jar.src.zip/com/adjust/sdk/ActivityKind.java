package com.adjust.sdk;

public enum ActivityKind {
  AD_REVENUE, ATTRIBUTION, CLICK, DISABLE_THIRD_PARTY_SHARING, EVENT, GDPR, INFO, MEASUREMENT_CONSENT, REATTRIBUTION, REVENUE, SESSION, SUBSCRIPTION, THIRD_PARTY_SHARING, UNKNOWN;
  
  private static final ActivityKind[] $VALUES;
  
  static {
    ActivityKind activityKind7 = new ActivityKind("UNKNOWN", 0);
    UNKNOWN = activityKind7;
    ActivityKind activityKind1 = new ActivityKind("SESSION", 1);
    SESSION = activityKind1;
    ActivityKind activityKind2 = new ActivityKind("EVENT", 2);
    EVENT = activityKind2;
    ActivityKind activityKind13 = new ActivityKind("CLICK", 3);
    CLICK = activityKind13;
    ActivityKind activityKind6 = new ActivityKind("ATTRIBUTION", 4);
    ATTRIBUTION = activityKind6;
    ActivityKind activityKind12 = new ActivityKind("REVENUE", 5);
    REVENUE = activityKind12;
    ActivityKind activityKind3 = new ActivityKind("REATTRIBUTION", 6);
    REATTRIBUTION = activityKind3;
    ActivityKind activityKind10 = new ActivityKind("INFO", 7);
    INFO = activityKind10;
    ActivityKind activityKind11 = new ActivityKind("GDPR", 8);
    GDPR = activityKind11;
    ActivityKind activityKind9 = new ActivityKind("AD_REVENUE", 9);
    AD_REVENUE = activityKind9;
    ActivityKind activityKind4 = new ActivityKind("DISABLE_THIRD_PARTY_SHARING", 10);
    DISABLE_THIRD_PARTY_SHARING = activityKind4;
    ActivityKind activityKind8 = new ActivityKind("SUBSCRIPTION", 11);
    SUBSCRIPTION = activityKind8;
    ActivityKind activityKind14 = new ActivityKind("THIRD_PARTY_SHARING", 12);
    THIRD_PARTY_SHARING = activityKind14;
    ActivityKind activityKind5 = new ActivityKind("MEASUREMENT_CONSENT", 13);
    MEASUREMENT_CONSENT = activityKind5;
    $VALUES = new ActivityKind[] { 
        activityKind7, activityKind1, activityKind2, activityKind13, activityKind6, activityKind12, activityKind3, activityKind10, activityKind11, activityKind9, 
        activityKind4, activityKind8, activityKind14, activityKind5 };
  }
  
  public static ActivityKind fromString(String paramString) {
    return "session".equals(paramString) ? SESSION : ("event".equals(paramString) ? EVENT : ("click".equals(paramString) ? CLICK : ("attribution".equals(paramString) ? ATTRIBUTION : ("info".equals(paramString) ? INFO : ("gdpr".equals(paramString) ? GDPR : ("disable_third_party_sharing".equals(paramString) ? DISABLE_THIRD_PARTY_SHARING : ("ad_revenue".equals(paramString) ? AD_REVENUE : ("subscription".equals(paramString) ? SUBSCRIPTION : ("third_party_sharing".equals(paramString) ? THIRD_PARTY_SHARING : ("measurement_consent".equals(paramString) ? MEASUREMENT_CONSENT : UNKNOWN))))))))));
  }
  
  public String toString() {
    switch (a.a[ordinal()]) {
      default:
        return "unknown";
      case 11:
        return "measurement_consent";
      case 10:
        return "third_party_sharing";
      case 9:
        return "subscription";
      case 8:
        return "ad_revenue";
      case 7:
        return "disable_third_party_sharing";
      case 6:
        return "gdpr";
      case 5:
        return "info";
      case 4:
        return "attribution";
      case 3:
        return "click";
      case 2:
        return "event";
      case 1:
        break;
    } 
    return "session";
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\adjust\sdk\ActivityKind.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */