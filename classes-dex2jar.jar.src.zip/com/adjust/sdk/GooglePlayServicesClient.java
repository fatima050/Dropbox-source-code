package com.adjust.sdk;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.os.IBinder;
import android.os.Looper;
import android.os.Parcel;
import java.io.IOException;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

public class GooglePlayServicesClient {
  public static GooglePlayServicesInfo getGooglePlayServicesInfo(Context paramContext, long paramLong) {
    if (Looper.myLooper() != Looper.getMainLooper()) {
      PackageManager packageManager = paramContext.getPackageManager();
      boolean bool = false;
      packageManager.getPackageInfo("com.android.vending", 0);
      a a = new a(paramLong);
      Intent intent = new Intent("com.google.android.gms.ads.identifier.service.START");
      intent.setPackage("com.google.android.gms");
      if (paramContext.bindService(intent, a, 1)) {
        Parcel parcel1;
        Parcel parcel2;
        try {
          IBinder iBinder = a.a();
          parcel1 = Parcel.obtain();
          parcel2 = Parcel.obtain();
          try {
            parcel1.writeInterfaceToken("com.google.android.gms.ads.identifier.internal.IAdvertisingIdService");
            iBinder.transact(1, parcel1, parcel2, 0);
            parcel2.readException();
            null = parcel2.readString();
            parcel2.recycle();
            parcel1.recycle();
            parcel2 = Parcel.obtain();
            parcel1 = Parcel.obtain();
            try {
              parcel2.writeInterfaceToken("com.google.android.gms.ads.identifier.internal.IAdvertisingIdService");
              parcel2.writeInt(1);
              iBinder.transact(2, parcel2, parcel1, 0);
              parcel1.readException();
              int i = parcel1.readInt();
              if (i != 0)
                bool = true; 
              parcel1.recycle();
              parcel2.recycle();
              return googlePlayServicesInfo;
            } finally {
              parcel1.recycle();
              parcel2.recycle();
            } 
          } finally {}
        } catch (Exception exception) {
        
        } finally {}
        parcel2.recycle();
        parcel1.recycle();
        throw intent;
      } 
      throw new IOException("Google Play connection failed");
    } 
    throw new IllegalStateException("Google Play Services info can't be accessed from the main thread");
  }
  
  public static final class GooglePlayServicesInfo {
    private final String gpsAdid;
    
    private final Boolean trackingEnabled;
    
    public GooglePlayServicesInfo(String param1String, Boolean param1Boolean) {
      this.gpsAdid = param1String;
      this.trackingEnabled = param1Boolean;
    }
    
    public String getGpsAdid() {
      return this.gpsAdid;
    }
    
    public Boolean isTrackingEnabled() {
      return this.trackingEnabled;
    }
  }
  
  public static final class a implements ServiceConnection {
    public long a;
    
    public boolean b = false;
    
    public final LinkedBlockingQueue<IBinder> c = new LinkedBlockingQueue<>(1);
    
    public a(long param1Long) {
      this.a = param1Long;
    }
    
    public final IBinder a() {
      if (!this.b) {
        this.b = true;
        return this.c.poll(this.a, TimeUnit.MILLISECONDS);
      } 
      throw new IllegalStateException();
    }
    
    public final void onServiceConnected(ComponentName param1ComponentName, IBinder param1IBinder) {
      try {
        this.c.put(param1IBinder);
      } catch (InterruptedException interruptedException) {}
    }
    
    public final void onServiceDisconnected(ComponentName param1ComponentName) {}
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\adjust\sdk\GooglePlayServicesClient.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */