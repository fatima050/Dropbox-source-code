package com.adjust.sdk;

import java.util.HashMap;
import java.util.Map;

public class SessionParameters {
  public Map<String, String> callbackParameters;
  
  public Map<String, String> partnerParameters;
  
  public SessionParameters deepCopy() {
    SessionParameters sessionParameters = new SessionParameters();
    if (this.callbackParameters != null)
      sessionParameters.callbackParameters = new HashMap<>(this.callbackParameters); 
    if (this.partnerParameters != null)
      sessionParameters.partnerParameters = new HashMap<>(this.partnerParameters); 
    return sessionParameters;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (paramObject == null)
      return false; 
    if (getClass() != paramObject.getClass())
      return false; 
    paramObject = paramObject;
    return !Util.equalObject(this.callbackParameters, ((SessionParameters)paramObject).callbackParameters) ? false : (!!Util.equalObject(this.partnerParameters, ((SessionParameters)paramObject).partnerParameters));
  }
  
  public int hashCode() {
    int i = Util.hashObject(this.callbackParameters, 17);
    return Util.hashObject(this.partnerParameters, i);
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\adjust\sdk\SessionParameters.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */