package com.adjust.sdk;

import android.content.Context;
import android.net.Uri;
import dbxyzptlk.WK.b;
import java.util.Map;

public class Adjust {
  private static AdjustInstance defaultInstance;
  
  public static void addSessionCallbackParameter(String paramString1, String paramString2) {
    getDefaultInstance().addSessionCallbackParameter(paramString1, paramString2);
  }
  
  public static void addSessionPartnerParameter(String paramString1, String paramString2) {
    getDefaultInstance().addSessionPartnerParameter(paramString1, paramString2);
  }
  
  @Deprecated
  public static void appWillOpenUrl(Uri paramUri) {
    getDefaultInstance().appWillOpenUrl(paramUri);
  }
  
  public static void appWillOpenUrl(Uri paramUri, Context paramContext) {
    getDefaultInstance().appWillOpenUrl(paramUri, extractApplicationContext(paramContext));
  }
  
  public static void disableThirdPartySharing(Context paramContext) {
    getDefaultInstance().disableThirdPartySharing(extractApplicationContext(paramContext));
  }
  
  private static Context extractApplicationContext(Context paramContext) {
    return (paramContext == null) ? null : paramContext.getApplicationContext();
  }
  
  public static void gdprForgetMe(Context paramContext) {
    getDefaultInstance().gdprForgetMe(extractApplicationContext(paramContext));
  }
  
  public static String getAdid() {
    return getDefaultInstance().getAdid();
  }
  
  public static String getAmazonAdId(Context paramContext) {
    paramContext = extractApplicationContext(paramContext);
    return (paramContext != null) ? Util.getFireAdvertisingId(paramContext.getContentResolver()) : null;
  }
  
  public static AdjustAttribution getAttribution() {
    return getDefaultInstance().getAttribution();
  }
  
  public static AdjustInstance getDefaultInstance() {
    /* monitor enter TypeReferenceDotClassExpression{ObjectType{com/adjust/sdk/Adjust}} */
    try {
      if (defaultInstance == null) {
        AdjustInstance adjustInstance1 = new AdjustInstance();
        this();
        defaultInstance = adjustInstance1;
      } 
    } finally {
      Exception exception;
    } 
    AdjustInstance adjustInstance = defaultInstance;
    /* monitor exit TypeReferenceDotClassExpression{ObjectType{com/adjust/sdk/Adjust}} */
    return adjustInstance;
  }
  
  public static void getGoogleAdId(Context paramContext, OnDeviceIdsRead paramOnDeviceIdsRead) {
    if (paramContext != null) {
      paramContext = paramContext.getApplicationContext();
    } else {
      paramContext = null;
    } 
    Util.getGoogleAdId(paramContext, paramOnDeviceIdsRead);
  }
  
  public static String getSdkVersion() {
    return getDefaultInstance().getSdkVersion();
  }
  
  public static boolean isAdjustUninstallDetectionPayload(Map<String, String> paramMap) {
    return Util.isAdjustUninstallDetectionPayload(paramMap);
  }
  
  public static boolean isEnabled() {
    return getDefaultInstance().isEnabled();
  }
  
  public static void onCreate(AdjustConfig paramAdjustConfig) {
    getDefaultInstance().onCreate(paramAdjustConfig);
  }
  
  public static void onPause() {
    getDefaultInstance().onPause();
  }
  
  public static void onResume() {
    getDefaultInstance().onResume();
  }
  
  public static void removeSessionCallbackParameter(String paramString) {
    getDefaultInstance().removeSessionCallbackParameter(paramString);
  }
  
  public static void removeSessionPartnerParameter(String paramString) {
    getDefaultInstance().removeSessionPartnerParameter(paramString);
  }
  
  public static void resetSessionCallbackParameters() {
    getDefaultInstance().resetSessionCallbackParameters();
  }
  
  public static void resetSessionPartnerParameters() {
    getDefaultInstance().resetSessionPartnerParameters();
  }
  
  public static void sendFirstPackages() {
    getDefaultInstance().sendFirstPackages();
  }
  
  public static void setEnabled(boolean paramBoolean) {
    getDefaultInstance().setEnabled(paramBoolean);
  }
  
  public static void setOfflineMode(boolean paramBoolean) {
    getDefaultInstance().setOfflineMode(paramBoolean);
  }
  
  public static void setPushToken(String paramString) {
    getDefaultInstance().setPushToken(paramString);
  }
  
  public static void setPushToken(String paramString, Context paramContext) {
    getDefaultInstance().setPushToken(paramString, extractApplicationContext(paramContext));
  }
  
  public static void setReferrer(String paramString, Context paramContext) {
    getDefaultInstance().sendReferrer(paramString, extractApplicationContext(paramContext));
  }
  
  public static void setTestOptions(AdjustTestOptions paramAdjustTestOptions) {
    Boolean bool = paramAdjustTestOptions.teardown;
    if (bool != null && bool.booleanValue()) {
      AdjustInstance adjustInstance = defaultInstance;
      if (adjustInstance != null)
        adjustInstance.teardown(); 
      defaultInstance = null;
      AdjustFactory.teardown(paramAdjustTestOptions.context);
    } 
    getDefaultInstance().setTestOptions(paramAdjustTestOptions);
  }
  
  public static void trackAdRevenue(AdjustAdRevenue paramAdjustAdRevenue) {
    getDefaultInstance().trackAdRevenue(paramAdjustAdRevenue);
  }
  
  public static void trackAdRevenue(String paramString, b paramb) {
    getDefaultInstance().trackAdRevenue(paramString, paramb);
  }
  
  public static void trackEvent(AdjustEvent paramAdjustEvent) {
    getDefaultInstance().trackEvent(paramAdjustEvent);
  }
  
  public static void trackMeasurementConsent(boolean paramBoolean) {
    getDefaultInstance().trackMeasurementConsent(paramBoolean);
  }
  
  public static void trackPlayStoreSubscription(AdjustPlayStoreSubscription paramAdjustPlayStoreSubscription) {
    getDefaultInstance().trackPlayStoreSubscription(paramAdjustPlayStoreSubscription);
  }
  
  public static void trackThirdPartySharing(AdjustThirdPartySharing paramAdjustThirdPartySharing) {
    getDefaultInstance().trackThirdPartySharing(paramAdjustThirdPartySharing);
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\adjust\sdk\Adjust.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */