package com.adjust.sdk;

import com.adjust.sdk.network.IActivityPackageSender;

public interface IAttributionHandler {
  void checkSdkClickResponse(SdkClickResponseData paramSdkClickResponseData);
  
  void checkSessionResponse(SessionResponseData paramSessionResponseData);
  
  void getAttribution();
  
  void init(IActivityHandler paramIActivityHandler, boolean paramBoolean, IActivityPackageSender paramIActivityPackageSender);
  
  void pauseSending();
  
  void resumeSending();
  
  void teardown();
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\adjust\sdk\IAttributionHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */