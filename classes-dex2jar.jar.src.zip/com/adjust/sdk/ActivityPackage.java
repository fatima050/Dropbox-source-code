package com.adjust.sdk;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectStreamField;
import java.io.Serializable;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class ActivityPackage implements Serializable {
  private static final ObjectStreamField[] serialPersistentFields = new ObjectStreamField[] { new ObjectStreamField("path", String.class), new ObjectStreamField("clientSdk", String.class), new ObjectStreamField("parameters", Map.class), new ObjectStreamField("activityKind", ActivityKind.class), new ObjectStreamField("suffix", String.class), new ObjectStreamField("callbackParameters", Map.class), new ObjectStreamField("partnerParameters", Map.class) };
  
  private static final long serialVersionUID = -35935556512024097L;
  
  private ActivityKind activityKind;
  
  private Map<String, String> callbackParameters;
  
  private long clickTimeInMilliseconds;
  
  private long clickTimeInSeconds;
  
  private long clickTimeServerInSeconds;
  
  private String clientSdk;
  
  private Boolean googlePlayInstant;
  
  private transient int hashCode;
  
  private long installBeginTimeInSeconds;
  
  private long installBeginTimeServerInSeconds;
  
  private String installVersion;
  
  private Map<String, String> parameters;
  
  private Map<String, String> partnerParameters;
  
  private String path;
  
  private int retries;
  
  private String suffix;
  
  public ActivityPackage(ActivityKind paramActivityKind) {
    ActivityKind activityKind = ActivityKind.UNKNOWN;
    this.activityKind = paramActivityKind;
  }
  
  private void readObject(ObjectInputStream paramObjectInputStream) {
    ObjectInputStream.GetField getField = paramObjectInputStream.readFields();
    this.path = Util.readStringField(getField, "path", null);
    this.clientSdk = Util.readStringField(getField, "clientSdk", null);
    this.parameters = Util.<Map<String, String>>readObjectField(getField, "parameters", null);
    this.activityKind = Util.<ActivityKind>readObjectField(getField, "activityKind", ActivityKind.UNKNOWN);
    this.suffix = Util.readStringField(getField, "suffix", null);
    this.callbackParameters = Util.<Map<String, String>>readObjectField(getField, "callbackParameters", null);
    this.partnerParameters = Util.<Map<String, String>>readObjectField(getField, "partnerParameters", null);
  }
  
  private void writeObject(ObjectOutputStream paramObjectOutputStream) {
    paramObjectOutputStream.defaultWriteObject();
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (paramObject == null)
      return false; 
    if (getClass() != paramObject.getClass())
      return false; 
    paramObject = paramObject;
    return !Util.equalString(this.path, ((ActivityPackage)paramObject).path) ? false : (!Util.equalString(this.clientSdk, ((ActivityPackage)paramObject).clientSdk) ? false : (!Util.equalObject(this.parameters, ((ActivityPackage)paramObject).parameters) ? false : (!Util.equalEnum(this.activityKind, ((ActivityPackage)paramObject).activityKind) ? false : (!Util.equalString(this.suffix, ((ActivityPackage)paramObject).suffix) ? false : (!Util.equalObject(this.callbackParameters, ((ActivityPackage)paramObject).callbackParameters) ? false : (!!Util.equalObject(this.partnerParameters, ((ActivityPackage)paramObject).partnerParameters)))))));
  }
  
  public ActivityKind getActivityKind() {
    return this.activityKind;
  }
  
  public Map<String, String> getCallbackParameters() {
    return this.callbackParameters;
  }
  
  public long getClickTimeInMilliseconds() {
    return this.clickTimeInMilliseconds;
  }
  
  public long getClickTimeInSeconds() {
    return this.clickTimeInSeconds;
  }
  
  public long getClickTimeServerInSeconds() {
    return this.clickTimeServerInSeconds;
  }
  
  public String getClientSdk() {
    return this.clientSdk;
  }
  
  public String getExtendedString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(Util.formatString("Path:      %s\n", new Object[] { this.path }));
    stringBuilder.append(Util.formatString("ClientSdk: %s\n", new Object[] { this.clientSdk }));
    if (this.parameters != null) {
      stringBuilder.append("Parameters:");
      TreeMap<String, String> treeMap = new TreeMap<>(this.parameters);
      List<String> list = Arrays.asList(new String[] { "app_secret", "secret_id", "event_callback_id" });
      for (Map.Entry<String, String> entry : treeMap.entrySet()) {
        String str = (String)entry.getKey();
        if (list.contains(str))
          continue; 
        stringBuilder.append(Util.formatString("\n\t%-16s %s", new Object[] { str, entry.getValue() }));
      } 
    } 
    return stringBuilder.toString();
  }
  
  public String getFailureMessage() {
    return Util.formatString("Failed to track %s%s", new Object[] { this.activityKind.toString(), this.suffix });
  }
  
  public Boolean getGooglePlayInstant() {
    return this.googlePlayInstant;
  }
  
  public long getInstallBeginTimeInSeconds() {
    return this.installBeginTimeInSeconds;
  }
  
  public long getInstallBeginTimeServerInSeconds() {
    return this.installBeginTimeServerInSeconds;
  }
  
  public String getInstallVersion() {
    return this.installVersion;
  }
  
  public Map<String, String> getParameters() {
    return this.parameters;
  }
  
  public Map<String, String> getPartnerParameters() {
    return this.partnerParameters;
  }
  
  public String getPath() {
    return this.path;
  }
  
  public int getRetries() {
    return this.retries;
  }
  
  public String getSuffix() {
    return this.suffix;
  }
  
  public int hashCode() {
    if (this.hashCode == 0) {
      this.hashCode = 17;
      int i = Util.hashString(this.path, 17);
      this.hashCode = i;
      i = Util.hashString(this.clientSdk, i);
      this.hashCode = i;
      i = Util.hashObject(this.parameters, i);
      this.hashCode = i;
      i = Util.hashEnum(this.activityKind, i);
      this.hashCode = i;
      i = Util.hashString(this.suffix, i);
      this.hashCode = i;
      i = Util.hashObject(this.callbackParameters, i);
      this.hashCode = i;
      this.hashCode = Util.hashObject(this.partnerParameters, i);
    } 
    return this.hashCode;
  }
  
  public int increaseRetries() {
    int i = this.retries + 1;
    this.retries = i;
    return i;
  }
  
  public void setCallbackParameters(Map<String, String> paramMap) {
    this.callbackParameters = paramMap;
  }
  
  public void setClickTimeInMilliseconds(long paramLong) {
    this.clickTimeInMilliseconds = paramLong;
  }
  
  public void setClickTimeInSeconds(long paramLong) {
    this.clickTimeInSeconds = paramLong;
  }
  
  public void setClickTimeServerInSeconds(long paramLong) {
    this.clickTimeServerInSeconds = paramLong;
  }
  
  public void setClientSdk(String paramString) {
    this.clientSdk = paramString;
  }
  
  public void setGooglePlayInstant(Boolean paramBoolean) {
    this.googlePlayInstant = paramBoolean;
  }
  
  public void setInstallBeginTimeInSeconds(long paramLong) {
    this.installBeginTimeInSeconds = paramLong;
  }
  
  public void setInstallBeginTimeServerInSeconds(long paramLong) {
    this.installBeginTimeServerInSeconds = paramLong;
  }
  
  public void setInstallVersion(String paramString) {
    this.installVersion = paramString;
  }
  
  public void setParameters(Map<String, String> paramMap) {
    this.parameters = paramMap;
  }
  
  public void setPartnerParameters(Map<String, String> paramMap) {
    this.partnerParameters = paramMap;
  }
  
  public void setPath(String paramString) {
    this.path = paramString;
  }
  
  public void setSuffix(String paramString) {
    this.suffix = paramString;
  }
  
  public String toString() {
    return Util.formatString("%s%s", new Object[] { this.activityKind.toString(), this.suffix });
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\adjust\sdk\ActivityPackage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */