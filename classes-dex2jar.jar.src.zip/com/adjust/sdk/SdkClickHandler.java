package com.adjust.sdk;

import com.adjust.sdk.network.IActivityPackageSender;
import com.adjust.sdk.scheduler.SingleThreadCachedScheduler;
import com.adjust.sdk.scheduler.ThreadScheduler;
import dbxyzptlk.WK.a;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.json.JSONException;

public class SdkClickHandler implements ISdkClickHandler {
  private static final double MILLISECONDS_TO_SECONDS_DIVISOR = 1000.0D;
  
  private static final String SCHEDULED_EXECUTOR_SOURCE = "SdkClickHandler";
  
  private static final String SOURCE_INSTALL_REFERRER = "install_referrer";
  
  private static final String SOURCE_REFTAG = "reftag";
  
  private WeakReference<IActivityHandler> activityHandlerWeakRef;
  
  private IActivityPackageSender activityPackageSender;
  
  private BackoffStrategy backoffStrategy;
  
  private ILogger logger;
  
  private List<ActivityPackage> packageQueue;
  
  private boolean paused;
  
  private ThreadScheduler scheduler;
  
  public SdkClickHandler(IActivityHandler paramIActivityHandler, boolean paramBoolean, IActivityPackageSender paramIActivityPackageSender) {
    init(paramIActivityHandler, paramBoolean, paramIActivityPackageSender);
    this.logger = AdjustFactory.getLogger();
    this.backoffStrategy = AdjustFactory.getSdkClickBackoffStrategy();
    this.scheduler = (ThreadScheduler)new SingleThreadCachedScheduler("SdkClickHandler");
  }
  
  private Map<String, String> generateSendingParametersI() {
    HashMap<Object, Object> hashMap = new HashMap<>();
    long l = System.currentTimeMillis();
    PackageBuilder.addString((Map)hashMap, "sent_at", Util.dateFormatter.format(Long.valueOf(l)));
    int i = this.packageQueue.size() - 1;
    if (i > 0)
      PackageBuilder.addLong((Map)hashMap, "queue_size", i); 
    return (Map)hashMap;
  }
  
  private void logErrorMessageI(ActivityPackage paramActivityPackage, String paramString, Throwable paramThrowable) {
    String str = Util.formatString("%s. (%s)", new Object[] { paramActivityPackage.getFailureMessage(), Util.getReasonString(paramString, paramThrowable) });
    this.logger.error(str, new Object[0]);
  }
  
  private void retrySendingI(ActivityPackage paramActivityPackage) {
    int i = paramActivityPackage.increaseRetries();
    this.logger.error("Retrying sdk_click package for the %d time", new Object[] { Integer.valueOf(i) });
    sendSdkClick(paramActivityPackage);
  }
  
  private void sendNextSdkClick() {
    this.scheduler.submit(new d(this));
  }
  
  private void sendNextSdkClickI() {
    IActivityHandler iActivityHandler = this.activityHandlerWeakRef.get();
    if (iActivityHandler.getActivityState() == null)
      return; 
    if ((iActivityHandler.getActivityState()).isGdprForgotten)
      return; 
    if (this.paused)
      return; 
    if (this.packageQueue.isEmpty())
      return; 
    ActivityPackage activityPackage = this.packageQueue.remove(0);
    int i = activityPackage.getRetries();
    e e = new e(this, activityPackage);
    if (i <= 0) {
      e.run();
      return;
    } 
    long l = Util.getWaitingTime(i, this.backoffStrategy);
    double d = l / 1000.0D;
    String str = Util.SecondsDisplayFormat.format(d);
    this.logger.verbose("Waiting for %s seconds before retrying sdk_click for the %d time", new Object[] { str, Integer.valueOf(i) });
    this.scheduler.schedule((Runnable)e, l);
  }
  
  private void sendSdkClickI(ActivityPackage paramActivityPackage) {
    boolean bool1;
    boolean bool2;
    boolean bool3;
    long l1;
    long l2;
    long l3;
    long l4;
    String str1;
    Boolean bool4;
    String str2;
    Boolean bool5;
    IActivityHandler iActivityHandler = this.activityHandlerWeakRef.get();
    String str4 = paramActivityPackage.getParameters().get("source");
    if (str4 != null && str4.equals("reftag")) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    String str3 = paramActivityPackage.getParameters().get("raw_referrer");
    if (bool1 && SharedPreferencesManager.getDefaultInstance(iActivityHandler.getContext()).getRawReferrer(str3, paramActivityPackage.getClickTimeInMilliseconds()) == null)
      return; 
    if (str4 != null && str4.equals("install_referrer")) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    if (bool2) {
      l2 = paramActivityPackage.getClickTimeInSeconds();
      l1 = paramActivityPackage.getInstallBeginTimeInSeconds();
      str2 = paramActivityPackage.getParameters().get("referrer");
      l4 = paramActivityPackage.getClickTimeServerInSeconds();
      l3 = paramActivityPackage.getInstallBeginTimeServerInSeconds();
      str1 = paramActivityPackage.getInstallVersion();
      bool4 = paramActivityPackage.getGooglePlayInstant();
      String str = paramActivityPackage.getParameters().get("referrer_api");
    } else {
      str2 = null;
      l2 = -1L;
      l3 = -1L;
      l1 = -1L;
      l4 = l1;
      str1 = null;
      bool5 = null;
      bool4 = bool5;
    } 
    if (str4 != null && str4.equals("preinstall")) {
      bool3 = true;
    } else {
      bool3 = false;
    } 
    Map<String, String> map = generateSendingParametersI();
    ResponseData responseData = this.activityPackageSender.sendActivityPackageSync(paramActivityPackage, map);
    if (!(responseData instanceof SdkClickResponseData))
      return; 
    SdkClickResponseData sdkClickResponseData = (SdkClickResponseData)responseData;
    if (((ResponseData)sdkClickResponseData).willRetry) {
      retrySendingI(paramActivityPackage);
      return;
    } 
    if (iActivityHandler == null)
      return; 
    if (((ResponseData)sdkClickResponseData).trackingState == TrackingState.OPTED_OUT) {
      iActivityHandler.gotOptOutResponse();
      return;
    } 
    if (bool1)
      SharedPreferencesManager.getDefaultInstance(iActivityHandler.getContext()).removeRawReferrer(str3, paramActivityPackage.getClickTimeInMilliseconds()); 
    if (bool2) {
      sdkClickResponseData.clickTime = l2;
      sdkClickResponseData.installBegin = l1;
      sdkClickResponseData.installReferrer = str2;
      sdkClickResponseData.clickTimeServer = l4;
      sdkClickResponseData.installBeginServer = l3;
      sdkClickResponseData.installVersion = str1;
      sdkClickResponseData.googlePlayInstant = bool4;
      sdkClickResponseData.referrerApi = (String)bool5;
      sdkClickResponseData.isInstallReferrer = true;
    } 
    if (bool3) {
      String str = paramActivityPackage.getParameters().get("found_location");
      if (str != null && !str.isEmpty()) {
        SharedPreferencesManager sharedPreferencesManager = SharedPreferencesManager.getDefaultInstance(iActivityHandler.getContext());
        if ("system_installer_referrer".equalsIgnoreCase(str)) {
          sharedPreferencesManager.removePreinstallReferrer();
        } else {
          sharedPreferencesManager.setPreinstallPayloadReadStatus(PreinstallUtil.markAsRead(str, sharedPreferencesManager.getPreinstallPayloadReadStatus()));
        } 
      } 
    } 
    iActivityHandler.finishedTrackingActivity((ResponseData)sdkClickResponseData);
  }
  
  public void init(IActivityHandler paramIActivityHandler, boolean paramBoolean, IActivityPackageSender paramIActivityPackageSender) {
    this.paused = paramBoolean ^ true;
    this.packageQueue = new ArrayList<>();
    this.activityHandlerWeakRef = new WeakReference<>(paramIActivityHandler);
    this.activityPackageSender = paramIActivityPackageSender;
  }
  
  public void pauseSending() {
    this.paused = true;
  }
  
  public void resumeSending() {
    this.paused = false;
    sendNextSdkClick();
  }
  
  public void sendPreinstallPayload(String paramString1, String paramString2) {
    this.scheduler.submit((Runnable)new c(this, paramString1, paramString2));
  }
  
  public void sendReftagReferrers() {
    this.scheduler.submit(new b(this));
  }
  
  public void sendSdkClick(ActivityPackage paramActivityPackage) {
    this.scheduler.submit((Runnable)new a(this, paramActivityPackage));
  }
  
  public void teardown() {
    this.logger.verbose("SdkClickHandler teardown", new Object[0]);
    ThreadScheduler threadScheduler = this.scheduler;
    if (threadScheduler != null)
      threadScheduler.teardown(); 
    List<ActivityPackage> list = this.packageQueue;
    if (list != null)
      list.clear(); 
    WeakReference<IActivityHandler> weakReference = this.activityHandlerWeakRef;
    if (weakReference != null)
      weakReference.clear(); 
    this.logger = null;
    this.packageQueue = null;
    this.backoffStrategy = null;
    this.scheduler = null;
  }
  
  public final class b implements Runnable {
    public final SdkClickHandler a;
    
    public b(SdkClickHandler this$0) {}
    
    public final void run() {
      boolean bool;
      a a;
      IActivityHandler iActivityHandler = this.a.activityHandlerWeakRef.get();
      SharedPreferencesManager sharedPreferencesManager = SharedPreferencesManager.getDefaultInstance(iActivityHandler.getContext());
      try {
        a = sharedPreferencesManager.getRawReferrerArray();
        byte b1 = 0;
        bool = false;
        while (b1 < a.p()) {
          a a1 = a.j(b1);
          if (a1.w(2, -1) == 0) {
            String str = a1.B(0, null);
            bool = true;
            long l = a1.z(1, -1L);
            a1.E(2, 1);
            ActivityPackage activityPackage = PackageFactory.buildReftagSdkClickPackage(str, l, iActivityHandler.getActivityState(), iActivityHandler.getAdjustConfig(), iActivityHandler.getDeviceInfo(), iActivityHandler.getSessionParameters());
            this.a.sendSdkClick(activityPackage);
          } 
          b1++;
        } 
      } catch (JSONException jSONException) {}
      if (bool)
        sharedPreferencesManager.saveRawReferrerArray(a); 
    }
  }
  
  public final class d implements Runnable {
    public final SdkClickHandler a;
    
    public d(SdkClickHandler this$0) {}
    
    public final void run() {
      this.a.sendNextSdkClickI();
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\adjust\sdk\SdkClickHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */