package com.adjust.sdk;

public enum BackoffStrategy {
  LONG_WAIT, NO_WAIT, SHORT_WAIT, TEST_WAIT;
  
  private static final BackoffStrategy[] $VALUES;
  
  public double maxRange;
  
  public long maxWait;
  
  public long milliSecondMultiplier;
  
  public double minRange;
  
  public int minRetries;
  
  static {
    BackoffStrategy backoffStrategy2 = new BackoffStrategy("LONG_WAIT", 0, 1, 120000L, 86400000L, 0.5D, 1.0D);
    LONG_WAIT = backoffStrategy2;
    BackoffStrategy backoffStrategy3 = new BackoffStrategy("SHORT_WAIT", 1, 1, 200L, 3600000L, 0.5D, 1.0D);
    SHORT_WAIT = backoffStrategy3;
    BackoffStrategy backoffStrategy4 = new BackoffStrategy("TEST_WAIT", 2, 1, 200L, 1000L, 0.5D, 1.0D);
    TEST_WAIT = backoffStrategy4;
    BackoffStrategy backoffStrategy1 = new BackoffStrategy("NO_WAIT", 3, 100, 1L, 1000L, 1.0D, 1.0D);
    NO_WAIT = backoffStrategy1;
    $VALUES = new BackoffStrategy[] { backoffStrategy2, backoffStrategy3, backoffStrategy4, backoffStrategy1 };
  }
  
  BackoffStrategy(int paramInt1, long paramLong1, long paramLong2, double paramDouble1, double paramDouble2) {
    this.minRetries = paramInt1;
    this.milliSecondMultiplier = paramLong1;
    this.maxWait = paramLong2;
    this.minRange = paramDouble1;
    this.maxRange = paramDouble2;
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\adjust\sdk\BackoffStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */