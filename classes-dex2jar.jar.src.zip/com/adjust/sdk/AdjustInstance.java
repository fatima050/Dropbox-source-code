package com.adjust.sdk;

import android.content.Context;
import android.net.Uri;
import dbxyzptlk.WK.b;
import java.util.ArrayList;
import java.util.List;

public class AdjustInstance {
  private IActivityHandler activityHandler;
  
  private String basePath;
  
  private String gdprPath;
  
  private PreLaunchActions preLaunchActions = new PreLaunchActions();
  
  private String pushToken;
  
  private Boolean startEnabled = null;
  
  private boolean startOffline = false;
  
  private String subscriptionPath;
  
  private boolean checkActivityHandler(String paramString) {
    return checkActivityHandler(paramString, false);
  }
  
  private boolean checkActivityHandler(String paramString, boolean paramBoolean) {
    if (this.activityHandler != null)
      return true; 
    if (paramString == null) {
      AdjustFactory.getLogger().error("Adjust not initialized correctly", new Object[0]);
      return false;
    } 
    if (paramBoolean) {
      AdjustFactory.getLogger().warn("Adjust not initialized, but %s saved for launch", new Object[] { paramString });
    } else {
      AdjustFactory.getLogger().warn("Adjust not initialized, can't perform %s", new Object[] { paramString });
    } 
    return false;
  }
  
  private boolean checkActivityHandler(boolean paramBoolean, String paramString1, String paramString2) {
    return paramBoolean ? checkActivityHandler(paramString1, true) : checkActivityHandler(paramString2, true);
  }
  
  private boolean isInstanceEnabled() {
    Boolean bool = this.startEnabled;
    return (bool == null || bool.booleanValue());
  }
  
  private void saveDeeplink(Uri paramUri, long paramLong, Context paramContext) {
    SharedPreferencesManager.getDefaultInstance(paramContext).saveDeeplink(paramUri, paramLong);
  }
  
  private void saveDisableThirdPartySharing(Context paramContext) {
    SharedPreferencesManager.getDefaultInstance(paramContext).setDisableThirdPartySharing();
  }
  
  private void saveGdprForgetMe(Context paramContext) {
    SharedPreferencesManager.getDefaultInstance(paramContext).setGdprForgetMe();
  }
  
  private void savePreinstallReferrer(String paramString, Context paramContext) {
    SharedPreferencesManager.getDefaultInstance(paramContext).savePreinstallReferrer(paramString);
  }
  
  private void savePushToken(String paramString, Context paramContext) {
    SharedPreferencesManager.getDefaultInstance(paramContext).savePushToken(paramString);
  }
  
  private void saveRawReferrer(String paramString, long paramLong, Context paramContext) {
    SharedPreferencesManager.getDefaultInstance(paramContext).saveRawReferrer(paramString, paramLong);
  }
  
  private void setSendingReferrersAsNotSent(Context paramContext) {
    SharedPreferencesManager.getDefaultInstance(paramContext).setSendingReferrersAsNotSent();
  }
  
  public void addSessionCallbackParameter(String paramString1, String paramString2) {
    if (checkActivityHandler("adding session callback parameter", true)) {
      this.activityHandler.addSessionCallbackParameter(paramString1, paramString2);
      return;
    } 
    this.preLaunchActions.preLaunchActionsArray.add(new a(paramString1, paramString2));
  }
  
  public void addSessionPartnerParameter(String paramString1, String paramString2) {
    if (checkActivityHandler("adding session partner parameter", true)) {
      this.activityHandler.addSessionPartnerParameter(paramString1, paramString2);
      return;
    } 
    this.preLaunchActions.preLaunchActionsArray.add(new b(paramString1, paramString2));
  }
  
  public void appWillOpenUrl(Uri paramUri) {
    if (!checkActivityHandler("appWillOpenUrl"))
      return; 
    long l = System.currentTimeMillis();
    this.activityHandler.readOpenUrl(paramUri, l);
  }
  
  public void appWillOpenUrl(Uri paramUri, Context paramContext) {
    if (paramUri == null || paramUri.toString().length() == 0) {
      AdjustFactory.getLogger().warn("Skipping deep link processing (null or empty)", new Object[0]);
      return;
    } 
    long l = System.currentTimeMillis();
    if (!checkActivityHandler("appWillOpenUrl", true)) {
      saveDeeplink(paramUri, l, paramContext);
      return;
    } 
    this.activityHandler.readOpenUrl(paramUri, l);
  }
  
  public void disableThirdPartySharing(Context paramContext) {
    if (!checkActivityHandler("disable third party sharing", true)) {
      saveDisableThirdPartySharing(paramContext);
      return;
    } 
    this.activityHandler.disableThirdPartySharing();
  }
  
  public void gdprForgetMe(Context paramContext) {
    saveGdprForgetMe(paramContext);
    if (checkActivityHandler("gdpr", true) && this.activityHandler.isEnabled())
      this.activityHandler.gdprForgetMe(); 
  }
  
  public String getAdid() {
    return !checkActivityHandler("getAdid") ? null : this.activityHandler.getAdid();
  }
  
  public AdjustAttribution getAttribution() {
    return !checkActivityHandler("getAttribution") ? null : this.activityHandler.getAttribution();
  }
  
  public String getSdkVersion() {
    return Util.getSdkVersion();
  }
  
  public boolean isEnabled() {
    return !checkActivityHandler("isEnabled") ? isInstanceEnabled() : this.activityHandler.isEnabled();
  }
  
  public void onCreate(AdjustConfig paramAdjustConfig) {
    if (paramAdjustConfig == null) {
      AdjustFactory.getLogger().error("AdjustConfig missing", new Object[0]);
      return;
    } 
    if (!paramAdjustConfig.isValid()) {
      AdjustFactory.getLogger().error("AdjustConfig not initialized correctly", new Object[0]);
      return;
    } 
    if (this.activityHandler != null) {
      AdjustFactory.getLogger().error("Adjust already initialized", new Object[0]);
      return;
    } 
    paramAdjustConfig.preLaunchActions = this.preLaunchActions;
    paramAdjustConfig.pushToken = this.pushToken;
    paramAdjustConfig.startEnabled = this.startEnabled;
    paramAdjustConfig.startOffline = this.startOffline;
    paramAdjustConfig.basePath = this.basePath;
    paramAdjustConfig.gdprPath = this.gdprPath;
    paramAdjustConfig.subscriptionPath = this.subscriptionPath;
    this.activityHandler = AdjustFactory.getActivityHandler(paramAdjustConfig);
    setSendingReferrersAsNotSent(paramAdjustConfig.context);
  }
  
  public void onPause() {
    if (!checkActivityHandler("onPause"))
      return; 
    this.activityHandler.onPause();
  }
  
  public void onResume() {
    if (!checkActivityHandler("onResume"))
      return; 
    this.activityHandler.onResume();
  }
  
  public void removeSessionCallbackParameter(String paramString) {
    if (checkActivityHandler("removing session callback parameter", true)) {
      this.activityHandler.removeSessionCallbackParameter(paramString);
      return;
    } 
    this.preLaunchActions.preLaunchActionsArray.add(new c(paramString));
  }
  
  public void removeSessionPartnerParameter(String paramString) {
    if (checkActivityHandler("removing session partner parameter", true)) {
      this.activityHandler.removeSessionPartnerParameter(paramString);
      return;
    } 
    this.preLaunchActions.preLaunchActionsArray.add(new d(paramString));
  }
  
  public void resetSessionCallbackParameters() {
    if (checkActivityHandler("resetting session callback parameters", true)) {
      this.activityHandler.resetSessionCallbackParameters();
      return;
    } 
    this.preLaunchActions.preLaunchActionsArray.add(new e());
  }
  
  public void resetSessionPartnerParameters() {
    if (checkActivityHandler("resetting session partner parameters", true)) {
      this.activityHandler.resetSessionPartnerParameters();
      return;
    } 
    this.preLaunchActions.preLaunchActionsArray.add(new f());
  }
  
  public void sendFirstPackages() {
    if (!checkActivityHandler("sendFirstPackages"))
      return; 
    this.activityHandler.sendFirstPackages();
  }
  
  public void sendPreinstallReferrer(String paramString, Context paramContext) {
    if (paramString == null || paramString.length() == 0) {
      AdjustFactory.getLogger().warn("Skipping SYSTEM_INSTALLER_REFERRER preinstall referrer processing (null or empty)", new Object[0]);
      return;
    } 
    savePreinstallReferrer(paramString, paramContext);
    if (checkActivityHandler("preinstall referrer", true) && this.activityHandler.isEnabled())
      this.activityHandler.sendPreinstallReferrer(); 
  }
  
  public void sendReferrer(String paramString, Context paramContext) {
    long l = System.currentTimeMillis();
    if (paramString == null || paramString.length() == 0) {
      AdjustFactory.getLogger().warn("Skipping INSTALL_REFERRER intent referrer processing (null or empty)", new Object[0]);
      return;
    } 
    saveRawReferrer(paramString, l, paramContext);
    if (checkActivityHandler("referrer", true) && this.activityHandler.isEnabled())
      this.activityHandler.sendReftagReferrer(); 
  }
  
  public void setEnabled(boolean paramBoolean) {
    this.startEnabled = Boolean.valueOf(paramBoolean);
    if (checkActivityHandler(paramBoolean, "enabled mode", "disabled mode"))
      this.activityHandler.setEnabled(paramBoolean); 
  }
  
  public void setOfflineMode(boolean paramBoolean) {
    if (!checkActivityHandler(paramBoolean, "offline mode", "online mode")) {
      this.startOffline = paramBoolean;
    } else {
      this.activityHandler.setOfflineMode(paramBoolean);
    } 
  }
  
  public void setPushToken(String paramString) {
    if (!checkActivityHandler("push token", true)) {
      this.pushToken = paramString;
    } else {
      this.activityHandler.setPushToken(paramString, false);
    } 
  }
  
  public void setPushToken(String paramString, Context paramContext) {
    savePushToken(paramString, paramContext);
    if (checkActivityHandler("push token", true) && this.activityHandler.isEnabled())
      this.activityHandler.setPushToken(paramString, true); 
  }
  
  public void setTestOptions(AdjustTestOptions paramAdjustTestOptions) {
    String str = paramAdjustTestOptions.basePath;
    if (str != null)
      this.basePath = str; 
    str = paramAdjustTestOptions.gdprPath;
    if (str != null)
      this.gdprPath = str; 
    str = paramAdjustTestOptions.subscriptionPath;
    if (str != null)
      this.subscriptionPath = str; 
    str = paramAdjustTestOptions.baseUrl;
    if (str != null)
      AdjustFactory.setBaseUrl(str); 
    str = paramAdjustTestOptions.gdprUrl;
    if (str != null)
      AdjustFactory.setGdprUrl(str); 
    str = paramAdjustTestOptions.subscriptionUrl;
    if (str != null)
      AdjustFactory.setSubscriptionUrl(str); 
    Long long_ = paramAdjustTestOptions.timerIntervalInMilliseconds;
    if (long_ != null)
      AdjustFactory.setTimerInterval(long_.longValue()); 
    if (paramAdjustTestOptions.timerStartInMilliseconds != null)
      AdjustFactory.setTimerStart(paramAdjustTestOptions.timerIntervalInMilliseconds.longValue()); 
    long_ = paramAdjustTestOptions.sessionIntervalInMilliseconds;
    if (long_ != null)
      AdjustFactory.setSessionInterval(long_.longValue()); 
    long_ = paramAdjustTestOptions.subsessionIntervalInMilliseconds;
    if (long_ != null)
      AdjustFactory.setSubsessionInterval(long_.longValue()); 
    Boolean bool2 = paramAdjustTestOptions.tryInstallReferrer;
    if (bool2 != null)
      AdjustFactory.setTryInstallReferrer(bool2.booleanValue()); 
    if (paramAdjustTestOptions.noBackoffWait != null) {
      BackoffStrategy backoffStrategy = BackoffStrategy.NO_WAIT;
      AdjustFactory.setPackageHandlerBackoffStrategy(backoffStrategy);
      AdjustFactory.setSdkClickBackoffStrategy(backoffStrategy);
    } 
    bool2 = paramAdjustTestOptions.enableSigning;
    if (bool2 != null && bool2.booleanValue())
      AdjustFactory.enableSigning(); 
    Boolean bool1 = paramAdjustTestOptions.disableSigning;
    if (bool1 != null && bool1.booleanValue())
      AdjustFactory.disableSigning(); 
  }
  
  public void teardown() {
    if (!checkActivityHandler("teardown"))
      return; 
    this.activityHandler.teardown();
    this.activityHandler = null;
  }
  
  public void trackAdRevenue(AdjustAdRevenue paramAdjustAdRevenue) {
    if (!checkActivityHandler("trackAdRevenue"))
      return; 
    this.activityHandler.trackAdRevenue(paramAdjustAdRevenue);
  }
  
  public void trackAdRevenue(String paramString, b paramb) {
    if (!checkActivityHandler("trackAdRevenue"))
      return; 
    this.activityHandler.trackAdRevenue(paramString, paramb);
  }
  
  public void trackEvent(AdjustEvent paramAdjustEvent) {
    if (!checkActivityHandler("trackEvent"))
      return; 
    this.activityHandler.trackEvent(paramAdjustEvent);
  }
  
  public void trackMeasurementConsent(boolean paramBoolean) {
    if (!checkActivityHandler("measurement consent", true)) {
      this.preLaunchActions.lastMeasurementConsentTracked = Boolean.valueOf(paramBoolean);
      return;
    } 
    this.activityHandler.trackMeasurementConsent(paramBoolean);
  }
  
  public void trackPlayStoreSubscription(AdjustPlayStoreSubscription paramAdjustPlayStoreSubscription) {
    if (!checkActivityHandler("trackPlayStoreSubscription"))
      return; 
    this.activityHandler.trackPlayStoreSubscription(paramAdjustPlayStoreSubscription);
  }
  
  public void trackThirdPartySharing(AdjustThirdPartySharing paramAdjustThirdPartySharing) {
    if (!checkActivityHandler("third party sharing", true)) {
      this.preLaunchActions.preLaunchAdjustThirdPartySharingArray.add(paramAdjustThirdPartySharing);
      return;
    } 
    this.activityHandler.trackThirdPartySharing(paramAdjustThirdPartySharing);
  }
  
  public static class PreLaunchActions {
    public Boolean lastMeasurementConsentTracked = null;
    
    public List<IRunActivityHandler> preLaunchActionsArray = new ArrayList<>();
    
    public List<AdjustThirdPartySharing> preLaunchAdjustThirdPartySharingArray = new ArrayList<>();
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\adjust\sdk\AdjustInstance.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */