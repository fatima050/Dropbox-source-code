package com.adjust.sdk;

import android.content.Context;
import com.adjust.sdk.network.IActivityPackageSender;

public interface IPackageHandler {
  void addPackage(ActivityPackage paramActivityPackage);
  
  void flush();
  
  void init(IActivityHandler paramIActivityHandler, Context paramContext, boolean paramBoolean, IActivityPackageSender paramIActivityPackageSender);
  
  void pauseSending();
  
  void resumeSending();
  
  void sendFirstPackage();
  
  void teardown();
  
  void updatePackages(SessionParameters paramSessionParameters);
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\adjust\sdk\IPackageHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */