package com.adjust.sdk;

import android.content.Context;
import java.util.Map;

public class AdjustSigner {
  private static volatile Object signerInstance;
  
  public static void disableSigning(ILogger paramILogger) {
    getSignerInstance();
    if (signerInstance == null)
      return; 
    try {
      Reflection.invokeInstanceMethod(signerInstance, "disableSigning", null, new Object[0]);
    } catch (Exception exception) {
      paramILogger.warn("Invoking Signer disableSigning() received an error [%s]", new Object[] { exception.getMessage() });
    } 
  }
  
  public static void enableSigning(ILogger paramILogger) {
    getSignerInstance();
    if (signerInstance == null)
      return; 
    try {
      Reflection.invokeInstanceMethod(signerInstance, "enableSigning", null, new Object[0]);
    } catch (Exception exception) {
      paramILogger.warn("Invoking Signer enableSigning() received an error [%s]", new Object[] { exception.getMessage() });
    } 
  }
  
  private static void getSignerInstance() {
    /* monitor enter TypeReferenceDotClassExpression{ObjectType{com/adjust/sdk/AdjustSigner}} */
    if (signerInstance == null) {
      try {
        if (signerInstance == null)
          signerInstance = Reflection.createDefaultInstance("com.adjust.sdk.sig.Signer"); 
      } finally {
        Exception exception;
      } 
      /* monitor exit TypeReferenceDotClassExpression{ObjectType{com/adjust/sdk/AdjustSigner}} */
    } 
  }
  
  public static void onResume(ILogger paramILogger) {
    getSignerInstance();
    if (signerInstance == null)
      return; 
    try {
      Reflection.invokeInstanceMethod(signerInstance, "onResume", null, new Object[0]);
    } catch (Exception exception) {
      paramILogger.warn("Invoking Signer onResume() received an error [%s]", new Object[] { exception.getMessage() });
    } 
  }
  
  public static void sign(Map<String, String> paramMap, String paramString1, String paramString2, Context paramContext, ILogger paramILogger) {
    getSignerInstance();
    if (signerInstance == null)
      return; 
    try {
      Reflection.invokeInstanceMethod(signerInstance, "sign", new Class[] { Context.class, Map.class, String.class, String.class }, new Object[] { paramContext, paramMap, paramString1, paramString2 });
    } catch (Exception exception) {
      paramILogger.warn("Invoking Signer sign() for %s received an error [%s]", new Object[] { paramString1, exception.getMessage() });
    } 
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\adjust\sdk\AdjustSigner.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */