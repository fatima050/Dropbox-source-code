package com.adjust.sdk;

import android.text.TextUtils;
import dbxyzptlk.WK.b;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class PackageBuilder {
  private static ILogger logger = AdjustFactory.getLogger();
  
  private a activityStateCopy;
  
  private AdjustConfig adjustConfig;
  
  public AdjustAttribution attribution;
  
  public long clickTimeInMilliseconds = -1L;
  
  public long clickTimeInSeconds = -1L;
  
  public long clickTimeServerInSeconds = -1L;
  
  private long createdAt;
  
  public String deeplink;
  
  private a deviceInfo;
  
  public Map<String, String> extraParameters;
  
  public Boolean googlePlayInstant;
  
  public long installBeginTimeInSeconds = -1L;
  
  public long installBeginTimeServerInSeconds = -1L;
  
  public String installVersion;
  
  public String preinstallLocation;
  
  public String preinstallPayload;
  
  public String rawReferrer;
  
  public String referrer;
  
  public String referrerApi;
  
  public String reftag;
  
  private SessionParameters sessionParameters;
  
  public PackageBuilder(AdjustConfig paramAdjustConfig, a parama, ActivityState paramActivityState, SessionParameters paramSessionParameters, long paramLong) {
    this.createdAt = paramLong;
    this.deviceInfo = parama;
    this.adjustConfig = paramAdjustConfig;
    this.activityStateCopy = new a(paramActivityState);
    this.sessionParameters = paramSessionParameters;
  }
  
  public static void addBoolean(Map<String, String> paramMap, String paramString, Boolean paramBoolean) {
    if (paramBoolean == null)
      return; 
    addLong(paramMap, paramString, paramBoolean.booleanValue());
  }
  
  private static void addDate(Map<String, String> paramMap, String paramString, Date paramDate) {
    if (paramDate == null)
      return; 
    addString(paramMap, paramString, Util.dateFormatter.format(paramDate));
  }
  
  private static void addDateInMilliseconds(Map<String, String> paramMap, String paramString, long paramLong) {
    if (paramLong <= 0L)
      return; 
    addDate(paramMap, paramString, new Date(paramLong));
  }
  
  private static void addDateInSeconds(Map<String, String> paramMap, String paramString, long paramLong) {
    if (paramLong <= 0L)
      return; 
    addDate(paramMap, paramString, new Date(paramLong * 1000L));
  }
  
  private static void addDouble(Map<String, String> paramMap, String paramString, Double paramDouble) {
    if (paramDouble == null)
      return; 
    addString(paramMap, paramString, Util.formatString("%.5f", new Object[] { paramDouble }));
  }
  
  private static void addDoubleWithoutRounding(Map<String, String> paramMap, String paramString, Double paramDouble) {
    if (paramDouble == null)
      return; 
    addString(paramMap, paramString, Double.toString(paramDouble.doubleValue()));
  }
  
  private static void addDuration(Map<String, String> paramMap, String paramString, long paramLong) {
    if (paramLong < 0L)
      return; 
    addLong(paramMap, paramString, (paramLong + 500L) / 1000L);
  }
  
  private static void addInteger(Map<String, String> paramMap, String paramString, Integer paramInteger) {
    if (paramInteger == null)
      return; 
    addString(paramMap, paramString, Integer.toString(paramInteger.intValue()));
  }
  
  public static void addJsonObject(Map<String, String> paramMap, String paramString, b paramb) {
    if (paramb == null)
      return; 
    addString(paramMap, paramString, paramb.toString());
  }
  
  public static void addLong(Map<String, String> paramMap, String paramString, long paramLong) {
    if (paramLong < 0L)
      return; 
    addString(paramMap, paramString, Long.toString(paramLong));
  }
  
  public static void addMapJson(Map<String, String> paramMap, String paramString, Map paramMap1) {
    if (paramMap1 == null)
      return; 
    if (paramMap1.size() == 0)
      return; 
    addString(paramMap, paramString, (new b(paramMap1)).toString());
  }
  
  public static void addString(Map<String, String> paramMap, String paramString1, String paramString2) {
    if (TextUtils.isEmpty(paramString2))
      return; 
    paramMap.put(paramString1, paramString2);
  }
  
  private void checkDeviceIds(Map<String, String> paramMap) {
    if (paramMap != null && !paramMap.containsKey("android_id") && !paramMap.containsKey("gps_adid") && !paramMap.containsKey("fire_adid") && !paramMap.containsKey("oaid") && !paramMap.containsKey("imei") && !paramMap.containsKey("meid") && !paramMap.containsKey("device_id") && !paramMap.containsKey("imeis") && !paramMap.containsKey("meids") && !paramMap.containsKey("device_ids"))
      if (this.adjustConfig.coppaCompliantEnabled) {
        logger.info("Missing Device IDs. COPPA enabled.", new Object[0]);
      } else {
        logger.error("Missing Device IDs. Please check if Proguard is correctly set with Adjust SDK", new Object[0]);
      }  
  }
  
  private boolean containsFireIds(Map<String, String> paramMap) {
    return (paramMap == null) ? false : paramMap.containsKey("fire_adid");
  }
  
  private boolean containsPlayIds(Map<String, String> paramMap) {
    return (paramMap == null) ? false : paramMap.containsKey("gps_adid");
  }
  
  private Map<String, String> getAdRevenueParameters(AdjustAdRevenue paramAdjustAdRevenue, boolean paramBoolean) {
    HashMap<Object, Object> hashMap = new HashMap<>();
    Map<String, String> map = Util.getImeiParameters(this.adjustConfig, logger);
    if (map != null)
      hashMap.putAll(map); 
    map = Util.getOaidParameters(this.adjustConfig, logger);
    if (map != null)
      hashMap.putAll(map); 
    if (!paramBoolean) {
      addMapJson((Map)hashMap, "callback_params", Util.mergeParameters(this.sessionParameters.callbackParameters, paramAdjustAdRevenue.callbackParameters, "Callback"));
      addMapJson((Map)hashMap, "partner_params", Util.mergeParameters(this.sessionParameters.partnerParameters, paramAdjustAdRevenue.partnerParameters, "Partner"));
    } 
    this.deviceInfo.b(this.adjustConfig);
    addString((Map)hashMap, "android_uuid", this.activityStateCopy.g);
    addString((Map)hashMap, "gps_adid", this.deviceInfo.a);
    addLong((Map)hashMap, "gps_adid_attempt", this.deviceInfo.c);
    addString((Map)hashMap, "gps_adid_src", this.deviceInfo.b);
    addBoolean((Map)hashMap, "tracking_enabled", this.deviceInfo.d);
    addString((Map)hashMap, "fire_adid", Util.getFireAdvertisingId(this.adjustConfig));
    addBoolean((Map)hashMap, "fire_tracking_enabled", Util.getFireTrackingEnabled(this.adjustConfig));
    if (!containsPlayIds((Map)hashMap) && !containsFireIds((Map)hashMap)) {
      logger.warn("Google Advertising ID or Fire Advertising ID not detected, fallback to non Google Play and Fire identifiers will take place", new Object[0]);
      this.deviceInfo.a(this.adjustConfig);
      addString((Map)hashMap, "android_id", this.deviceInfo.f);
    } 
    addString((Map)hashMap, "api_level", this.deviceInfo.p);
    addString((Map)hashMap, "app_secret", this.adjustConfig.appSecret);
    addString((Map)hashMap, "app_token", this.adjustConfig.appToken);
    addString((Map)hashMap, "app_version", this.deviceInfo.j);
    Boolean bool = Boolean.TRUE;
    addBoolean((Map)hashMap, "attribution_deeplink", bool);
    addLong((Map)hashMap, "connectivity_type", Util.getConnectivityType(this.adjustConfig.context));
    addString((Map)hashMap, "country", this.deviceInfo.r);
    addString((Map)hashMap, "cpu_type", this.deviceInfo.y);
    addDateInMilliseconds((Map)hashMap, "created_at", this.createdAt);
    addString((Map)hashMap, "default_tracker", this.adjustConfig.defaultTracker);
    addBoolean((Map)hashMap, "device_known", this.adjustConfig.deviceKnown);
    addBoolean((Map)hashMap, "needs_cost", this.adjustConfig.needsCost);
    addString((Map)hashMap, "device_manufacturer", this.deviceInfo.m);
    addString((Map)hashMap, "device_name", this.deviceInfo.l);
    addString((Map)hashMap, "device_type", this.deviceInfo.k);
    addLong((Map)hashMap, "ui_mode", this.deviceInfo.C);
    addString((Map)hashMap, "display_height", this.deviceInfo.w);
    addString((Map)hashMap, "display_width", this.deviceInfo.v);
    addString((Map)hashMap, "environment", this.adjustConfig.environment);
    addBoolean((Map)hashMap, "event_buffering_enabled", Boolean.valueOf(this.adjustConfig.eventBufferingEnabled));
    addString((Map)hashMap, "external_device_id", this.adjustConfig.externalDeviceId);
    addString((Map)hashMap, "fb_id", this.deviceInfo.g);
    addString((Map)hashMap, "hardware_name", this.deviceInfo.x);
    addString((Map)hashMap, "installed_at", this.deviceInfo.A);
    addString((Map)hashMap, "language", this.deviceInfo.q);
    addDuration((Map)hashMap, "last_interval", this.activityStateCopy.e);
    addString((Map)hashMap, "mcc", Util.getMcc(this.adjustConfig.context));
    addString((Map)hashMap, "mnc", Util.getMnc(this.adjustConfig.context));
    addBoolean((Map)hashMap, "needs_response_details", bool);
    addString((Map)hashMap, "os_build", this.deviceInfo.z);
    addString((Map)hashMap, "os_name", this.deviceInfo.n);
    addString((Map)hashMap, "os_version", this.deviceInfo.o);
    addString((Map)hashMap, "package_name", this.deviceInfo.i);
    addString((Map)hashMap, "push_token", this.activityStateCopy.h);
    addString((Map)hashMap, "screen_density", this.deviceInfo.u);
    addString((Map)hashMap, "screen_format", this.deviceInfo.t);
    addString((Map)hashMap, "screen_size", this.deviceInfo.s);
    addString((Map)hashMap, "secret_id", this.adjustConfig.secretId);
    addString((Map)hashMap, "source", paramAdjustAdRevenue.source);
    addDoubleWithoutRounding((Map)hashMap, "revenue", paramAdjustAdRevenue.revenue);
    addString((Map)hashMap, "currency", paramAdjustAdRevenue.currency);
    addInteger((Map)hashMap, "ad_impressions_count", paramAdjustAdRevenue.adImpressionsCount);
    addString((Map)hashMap, "ad_revenue_network", paramAdjustAdRevenue.adRevenueNetwork);
    addString((Map)hashMap, "ad_revenue_unit", paramAdjustAdRevenue.adRevenueUnit);
    addString((Map)hashMap, "ad_revenue_placement", paramAdjustAdRevenue.adRevenuePlacement);
    addLong((Map)hashMap, "session_count", this.activityStateCopy.b);
    addDuration((Map)hashMap, "session_length", this.activityStateCopy.f);
    addLong((Map)hashMap, "subsession_count", this.activityStateCopy.c);
    addDuration((Map)hashMap, "time_spent", this.activityStateCopy.d);
    addString((Map)hashMap, "updated_at", this.deviceInfo.B);
    injectFeatureFlagsWithParameters((Map)hashMap);
    checkDeviceIds((Map)hashMap);
    return (Map)hashMap;
  }
  
  private Map<String, String> getAdRevenueParameters(String paramString, b paramb) {
    HashMap<Object, Object> hashMap = new HashMap<>();
    Map<String, String> map = Util.getImeiParameters(this.adjustConfig, logger);
    if (map != null)
      hashMap.putAll(map); 
    map = Util.getOaidParameters(this.adjustConfig, logger);
    if (map != null)
      hashMap.putAll(map); 
    this.deviceInfo.b(this.adjustConfig);
    addString((Map)hashMap, "android_uuid", this.activityStateCopy.g);
    addString((Map)hashMap, "gps_adid", this.deviceInfo.a);
    addLong((Map)hashMap, "gps_adid_attempt", this.deviceInfo.c);
    addString((Map)hashMap, "gps_adid_src", this.deviceInfo.b);
    addBoolean((Map)hashMap, "tracking_enabled", this.deviceInfo.d);
    addString((Map)hashMap, "fire_adid", Util.getFireAdvertisingId(this.adjustConfig));
    addBoolean((Map)hashMap, "fire_tracking_enabled", Util.getFireTrackingEnabled(this.adjustConfig));
    if (!containsPlayIds((Map)hashMap) && !containsFireIds((Map)hashMap)) {
      logger.warn("Google Advertising ID or Fire Advertising ID not detected, fallback to non Google Play and Fire identifiers will take place", new Object[0]);
      this.deviceInfo.a(this.adjustConfig);
      addString((Map)hashMap, "android_id", this.deviceInfo.f);
    } 
    addString((Map)hashMap, "api_level", this.deviceInfo.p);
    addString((Map)hashMap, "app_secret", this.adjustConfig.appSecret);
    addString((Map)hashMap, "app_token", this.adjustConfig.appToken);
    addString((Map)hashMap, "app_version", this.deviceInfo.j);
    Boolean bool = Boolean.TRUE;
    addBoolean((Map)hashMap, "attribution_deeplink", bool);
    addLong((Map)hashMap, "connectivity_type", Util.getConnectivityType(this.adjustConfig.context));
    addString((Map)hashMap, "country", this.deviceInfo.r);
    addString((Map)hashMap, "cpu_type", this.deviceInfo.y);
    addDateInMilliseconds((Map)hashMap, "created_at", this.createdAt);
    addString((Map)hashMap, "default_tracker", this.adjustConfig.defaultTracker);
    addBoolean((Map)hashMap, "device_known", this.adjustConfig.deviceKnown);
    addBoolean((Map)hashMap, "needs_cost", this.adjustConfig.needsCost);
    addString((Map)hashMap, "device_manufacturer", this.deviceInfo.m);
    addString((Map)hashMap, "device_name", this.deviceInfo.l);
    addString((Map)hashMap, "device_type", this.deviceInfo.k);
    addLong((Map)hashMap, "ui_mode", this.deviceInfo.C);
    addString((Map)hashMap, "display_height", this.deviceInfo.w);
    addString((Map)hashMap, "display_width", this.deviceInfo.v);
    addString((Map)hashMap, "environment", this.adjustConfig.environment);
    addBoolean((Map)hashMap, "event_buffering_enabled", Boolean.valueOf(this.adjustConfig.eventBufferingEnabled));
    addString((Map)hashMap, "external_device_id", this.adjustConfig.externalDeviceId);
    addString((Map)hashMap, "fb_id", this.deviceInfo.g);
    addString((Map)hashMap, "hardware_name", this.deviceInfo.x);
    addString((Map)hashMap, "installed_at", this.deviceInfo.A);
    addString((Map)hashMap, "language", this.deviceInfo.q);
    addDuration((Map)hashMap, "last_interval", this.activityStateCopy.e);
    addString((Map)hashMap, "mcc", Util.getMcc(this.adjustConfig.context));
    addString((Map)hashMap, "mnc", Util.getMnc(this.adjustConfig.context));
    addBoolean((Map)hashMap, "needs_response_details", bool);
    addString((Map)hashMap, "os_build", this.deviceInfo.z);
    addString((Map)hashMap, "os_name", this.deviceInfo.n);
    addString((Map)hashMap, "os_version", this.deviceInfo.o);
    addString((Map)hashMap, "package_name", this.deviceInfo.i);
    addString((Map)hashMap, "push_token", this.activityStateCopy.h);
    addString((Map)hashMap, "screen_density", this.deviceInfo.u);
    addString((Map)hashMap, "screen_format", this.deviceInfo.t);
    addString((Map)hashMap, "screen_size", this.deviceInfo.s);
    addString((Map)hashMap, "secret_id", this.adjustConfig.secretId);
    addString((Map)hashMap, "source", paramString);
    addJsonObject((Map)hashMap, "payload", paramb);
    addLong((Map)hashMap, "session_count", this.activityStateCopy.b);
    addDuration((Map)hashMap, "session_length", this.activityStateCopy.f);
    addLong((Map)hashMap, "subsession_count", this.activityStateCopy.c);
    addDuration((Map)hashMap, "time_spent", this.activityStateCopy.d);
    addString((Map)hashMap, "updated_at", this.deviceInfo.B);
    injectFeatureFlagsWithParameters((Map)hashMap);
    checkDeviceIds((Map)hashMap);
    return (Map)hashMap;
  }
  
  private Map<String, String> getAttributionParameters(String paramString) {
    HashMap<Object, Object> hashMap = new HashMap<>();
    Map<String, String> map = Util.getImeiParameters(this.adjustConfig, logger);
    if (map != null)
      hashMap.putAll(map); 
    map = Util.getOaidParameters(this.adjustConfig, logger);
    if (map != null)
      hashMap.putAll(map); 
    this.deviceInfo.b(this.adjustConfig);
    addString((Map)hashMap, "android_uuid", this.activityStateCopy.g);
    addString((Map)hashMap, "gps_adid", this.deviceInfo.a);
    addLong((Map)hashMap, "gps_adid_attempt", this.deviceInfo.c);
    addString((Map)hashMap, "gps_adid_src", this.deviceInfo.b);
    addBoolean((Map)hashMap, "tracking_enabled", this.deviceInfo.d);
    addString((Map)hashMap, "fire_adid", Util.getFireAdvertisingId(this.adjustConfig));
    addBoolean((Map)hashMap, "fire_tracking_enabled", Util.getFireTrackingEnabled(this.adjustConfig));
    if (!containsPlayIds((Map)hashMap) && !containsFireIds((Map)hashMap)) {
      logger.warn("Google Advertising ID or Fire Advertising ID not detected, fallback to non Google Play and Fire identifiers will take place", new Object[0]);
      this.deviceInfo.a(this.adjustConfig);
      addString((Map)hashMap, "android_id", this.deviceInfo.f);
    } 
    addString((Map)hashMap, "api_level", this.deviceInfo.p);
    addString((Map)hashMap, "app_secret", this.adjustConfig.appSecret);
    addString((Map)hashMap, "app_token", this.adjustConfig.appToken);
    addString((Map)hashMap, "app_version", this.deviceInfo.j);
    Boolean bool = Boolean.TRUE;
    addBoolean((Map)hashMap, "attribution_deeplink", bool);
    addDateInMilliseconds((Map)hashMap, "created_at", this.createdAt);
    addBoolean((Map)hashMap, "device_known", this.adjustConfig.deviceKnown);
    addBoolean((Map)hashMap, "needs_cost", this.adjustConfig.needsCost);
    addString((Map)hashMap, "device_name", this.deviceInfo.l);
    addString((Map)hashMap, "device_type", this.deviceInfo.k);
    addLong((Map)hashMap, "ui_mode", this.deviceInfo.C);
    addString((Map)hashMap, "environment", this.adjustConfig.environment);
    addBoolean((Map)hashMap, "event_buffering_enabled", Boolean.valueOf(this.adjustConfig.eventBufferingEnabled));
    addString((Map)hashMap, "external_device_id", this.adjustConfig.externalDeviceId);
    addString((Map)hashMap, "initiated_by", paramString);
    addBoolean((Map)hashMap, "needs_response_details", bool);
    addString((Map)hashMap, "os_name", this.deviceInfo.n);
    addString((Map)hashMap, "os_version", this.deviceInfo.o);
    addString((Map)hashMap, "package_name", this.deviceInfo.i);
    addString((Map)hashMap, "push_token", this.activityStateCopy.h);
    addString((Map)hashMap, "secret_id", this.adjustConfig.secretId);
    injectFeatureFlagsWithParameters((Map)hashMap);
    checkDeviceIds((Map)hashMap);
    return (Map)hashMap;
  }
  
  private Map<String, String> getClickParameters(String paramString) {
    HashMap<Object, Object> hashMap = new HashMap<>();
    Map<String, String> map = Util.getImeiParameters(this.adjustConfig, logger);
    if (map != null)
      hashMap.putAll(map); 
    map = Util.getOaidParameters(this.adjustConfig, logger);
    if (map != null)
      hashMap.putAll(map); 
    this.deviceInfo.b(this.adjustConfig);
    addString((Map)hashMap, "android_uuid", this.activityStateCopy.g);
    addString((Map)hashMap, "gps_adid", this.deviceInfo.a);
    addLong((Map)hashMap, "gps_adid_attempt", this.deviceInfo.c);
    addString((Map)hashMap, "gps_adid_src", this.deviceInfo.b);
    addBoolean((Map)hashMap, "tracking_enabled", this.deviceInfo.d);
    addString((Map)hashMap, "fire_adid", Util.getFireAdvertisingId(this.adjustConfig));
    addBoolean((Map)hashMap, "fire_tracking_enabled", Util.getFireTrackingEnabled(this.adjustConfig));
    if (!containsPlayIds((Map)hashMap) && !containsFireIds((Map)hashMap)) {
      logger.warn("Google Advertising ID or Fire Advertising ID not detected, fallback to non Google Play and Fire identifiers will take place", new Object[0]);
      this.deviceInfo.a(this.adjustConfig);
      addString((Map)hashMap, "android_id", this.deviceInfo.f);
    } 
    AdjustAttribution adjustAttribution = this.attribution;
    if (adjustAttribution != null) {
      addString((Map)hashMap, "tracker", adjustAttribution.trackerName);
      addString((Map)hashMap, "campaign", this.attribution.campaign);
      addString((Map)hashMap, "adgroup", this.attribution.adgroup);
      addString((Map)hashMap, "creative", this.attribution.creative);
    } 
    addString((Map)hashMap, "api_level", this.deviceInfo.p);
    addString((Map)hashMap, "app_secret", this.adjustConfig.appSecret);
    addString((Map)hashMap, "app_token", this.adjustConfig.appToken);
    addString((Map)hashMap, "app_version", this.deviceInfo.j);
    Boolean bool = Boolean.TRUE;
    addBoolean((Map)hashMap, "attribution_deeplink", bool);
    addMapJson((Map)hashMap, "callback_params", this.sessionParameters.callbackParameters);
    addDateInMilliseconds((Map)hashMap, "click_time", this.clickTimeInMilliseconds);
    addDateInSeconds((Map)hashMap, "click_time", this.clickTimeInSeconds);
    addDateInSeconds((Map)hashMap, "click_time_server", this.clickTimeServerInSeconds);
    addLong((Map)hashMap, "connectivity_type", Util.getConnectivityType(this.adjustConfig.context));
    addString((Map)hashMap, "country", this.deviceInfo.r);
    addString((Map)hashMap, "cpu_type", this.deviceInfo.y);
    addDateInMilliseconds((Map)hashMap, "created_at", this.createdAt);
    addString((Map)hashMap, "deeplink", this.deeplink);
    addBoolean((Map)hashMap, "device_known", this.adjustConfig.deviceKnown);
    addBoolean((Map)hashMap, "needs_cost", this.adjustConfig.needsCost);
    addString((Map)hashMap, "device_manufacturer", this.deviceInfo.m);
    addString((Map)hashMap, "device_name", this.deviceInfo.l);
    addString((Map)hashMap, "device_type", this.deviceInfo.k);
    addLong((Map)hashMap, "ui_mode", this.deviceInfo.C);
    addString((Map)hashMap, "display_height", this.deviceInfo.w);
    addString((Map)hashMap, "display_width", this.deviceInfo.v);
    addString((Map)hashMap, "environment", this.adjustConfig.environment);
    addBoolean((Map)hashMap, "event_buffering_enabled", Boolean.valueOf(this.adjustConfig.eventBufferingEnabled));
    addString((Map)hashMap, "external_device_id", this.adjustConfig.externalDeviceId);
    addString((Map)hashMap, "fb_id", this.deviceInfo.g);
    addBoolean((Map)hashMap, "google_play_instant", this.googlePlayInstant);
    addString((Map)hashMap, "hardware_name", this.deviceInfo.x);
    addDateInSeconds((Map)hashMap, "install_begin_time", this.installBeginTimeInSeconds);
    addDateInSeconds((Map)hashMap, "install_begin_time_server", this.installBeginTimeServerInSeconds);
    addString((Map)hashMap, "install_version", this.installVersion);
    addString((Map)hashMap, "installed_at", this.deviceInfo.A);
    addString((Map)hashMap, "language", this.deviceInfo.q);
    addDuration((Map)hashMap, "last_interval", this.activityStateCopy.e);
    addString((Map)hashMap, "mcc", Util.getMcc(this.adjustConfig.context));
    addString((Map)hashMap, "mnc", Util.getMnc(this.adjustConfig.context));
    addBoolean((Map)hashMap, "needs_response_details", bool);
    addString((Map)hashMap, "os_build", this.deviceInfo.z);
    addString((Map)hashMap, "os_name", this.deviceInfo.n);
    addString((Map)hashMap, "os_version", this.deviceInfo.o);
    addString((Map)hashMap, "package_name", this.deviceInfo.i);
    addMapJson((Map)hashMap, "params", this.extraParameters);
    addMapJson((Map)hashMap, "partner_params", this.sessionParameters.partnerParameters);
    addString((Map)hashMap, "push_token", this.activityStateCopy.h);
    addString((Map)hashMap, "raw_referrer", this.rawReferrer);
    addString((Map)hashMap, "referrer", this.referrer);
    addString((Map)hashMap, "referrer_api", this.referrerApi);
    addString((Map)hashMap, "reftag", this.reftag);
    addString((Map)hashMap, "screen_density", this.deviceInfo.u);
    addString((Map)hashMap, "screen_format", this.deviceInfo.t);
    addString((Map)hashMap, "screen_size", this.deviceInfo.s);
    addString((Map)hashMap, "secret_id", this.adjustConfig.secretId);
    addLong((Map)hashMap, "session_count", this.activityStateCopy.b);
    addDuration((Map)hashMap, "session_length", this.activityStateCopy.f);
    addString((Map)hashMap, "source", paramString);
    addLong((Map)hashMap, "subsession_count", this.activityStateCopy.c);
    addDuration((Map)hashMap, "time_spent", this.activityStateCopy.d);
    addString((Map)hashMap, "updated_at", this.deviceInfo.B);
    addString((Map)hashMap, "payload", this.preinstallPayload);
    addString((Map)hashMap, "found_location", this.preinstallLocation);
    injectFeatureFlagsWithParameters((Map)hashMap);
    checkDeviceIds((Map)hashMap);
    return (Map)hashMap;
  }
  
  private ActivityPackage getDefaultActivityPackage(ActivityKind paramActivityKind) {
    ActivityPackage activityPackage = new ActivityPackage(paramActivityKind);
    activityPackage.setClientSdk(this.deviceInfo.h);
    return activityPackage;
  }
  
  private Map<String, String> getDisableThirdPartySharingParameters() {
    HashMap<Object, Object> hashMap = new HashMap<>();
    Map<String, String> map = Util.getImeiParameters(this.adjustConfig, logger);
    if (map != null)
      hashMap.putAll(map); 
    map = Util.getOaidParameters(this.adjustConfig, logger);
    if (map != null)
      hashMap.putAll(map); 
    this.deviceInfo.b(this.adjustConfig);
    addString((Map)hashMap, "android_uuid", this.activityStateCopy.g);
    addString((Map)hashMap, "gps_adid", this.deviceInfo.a);
    addLong((Map)hashMap, "gps_adid_attempt", this.deviceInfo.c);
    addString((Map)hashMap, "gps_adid_src", this.deviceInfo.b);
    addBoolean((Map)hashMap, "tracking_enabled", this.deviceInfo.d);
    addString((Map)hashMap, "fire_adid", Util.getFireAdvertisingId(this.adjustConfig));
    addBoolean((Map)hashMap, "fire_tracking_enabled", Util.getFireTrackingEnabled(this.adjustConfig));
    if (!containsPlayIds((Map)hashMap) && !containsFireIds((Map)hashMap)) {
      logger.warn("Google Advertising ID or Fire Advertising ID not detected, fallback to non Google Play and Fire identifiers will take place", new Object[0]);
      this.deviceInfo.a(this.adjustConfig);
      addString((Map)hashMap, "android_id", this.deviceInfo.f);
    } 
    addString((Map)hashMap, "api_level", this.deviceInfo.p);
    addString((Map)hashMap, "app_secret", this.adjustConfig.appSecret);
    addString((Map)hashMap, "app_token", this.adjustConfig.appToken);
    addString((Map)hashMap, "app_version", this.deviceInfo.j);
    Boolean bool = Boolean.TRUE;
    addBoolean((Map)hashMap, "attribution_deeplink", bool);
    addDateInMilliseconds((Map)hashMap, "created_at", this.createdAt);
    addBoolean((Map)hashMap, "device_known", this.adjustConfig.deviceKnown);
    addBoolean((Map)hashMap, "needs_cost", this.adjustConfig.needsCost);
    addString((Map)hashMap, "device_name", this.deviceInfo.l);
    addString((Map)hashMap, "device_type", this.deviceInfo.k);
    addLong((Map)hashMap, "ui_mode", this.deviceInfo.C);
    addString((Map)hashMap, "environment", this.adjustConfig.environment);
    addBoolean((Map)hashMap, "event_buffering_enabled", Boolean.valueOf(this.adjustConfig.eventBufferingEnabled));
    addString((Map)hashMap, "external_device_id", this.adjustConfig.externalDeviceId);
    addBoolean((Map)hashMap, "needs_response_details", bool);
    addString((Map)hashMap, "os_name", this.deviceInfo.n);
    addString((Map)hashMap, "os_version", this.deviceInfo.o);
    addString((Map)hashMap, "package_name", this.deviceInfo.i);
    addString((Map)hashMap, "push_token", this.activityStateCopy.h);
    addString((Map)hashMap, "secret_id", this.adjustConfig.secretId);
    injectFeatureFlagsWithParameters((Map)hashMap);
    checkDeviceIds((Map)hashMap);
    return (Map)hashMap;
  }
  
  private String getEventSuffix(AdjustEvent paramAdjustEvent) {
    Double double_ = paramAdjustEvent.revenue;
    return (double_ == null) ? Util.formatString("'%s'", new Object[] { paramAdjustEvent.eventToken }) : Util.formatString("(%.5f %s, '%s')", new Object[] { double_, paramAdjustEvent.currency, paramAdjustEvent.eventToken });
  }
  
  private Map<String, String> getGdprParameters() {
    HashMap<Object, Object> hashMap = new HashMap<>();
    Map<String, String> map = Util.getImeiParameters(this.adjustConfig, logger);
    if (map != null)
      hashMap.putAll(map); 
    map = Util.getOaidParameters(this.adjustConfig, logger);
    if (map != null)
      hashMap.putAll(map); 
    this.deviceInfo.b(this.adjustConfig);
    addString((Map)hashMap, "android_uuid", this.activityStateCopy.g);
    addString((Map)hashMap, "gps_adid", this.deviceInfo.a);
    addLong((Map)hashMap, "gps_adid_attempt", this.deviceInfo.c);
    addString((Map)hashMap, "gps_adid_src", this.deviceInfo.b);
    addBoolean((Map)hashMap, "tracking_enabled", this.deviceInfo.d);
    addString((Map)hashMap, "fire_adid", Util.getFireAdvertisingId(this.adjustConfig));
    addBoolean((Map)hashMap, "fire_tracking_enabled", Util.getFireTrackingEnabled(this.adjustConfig));
    if (!containsPlayIds((Map)hashMap) && !containsFireIds((Map)hashMap)) {
      logger.warn("Google Advertising ID or Fire Advertising ID not detected, fallback to non Google Play and Fire identifiers will take place", new Object[0]);
      this.deviceInfo.a(this.adjustConfig);
      addString((Map)hashMap, "android_id", this.deviceInfo.f);
    } 
    addString((Map)hashMap, "api_level", this.deviceInfo.p);
    addString((Map)hashMap, "app_secret", this.adjustConfig.appSecret);
    addString((Map)hashMap, "app_token", this.adjustConfig.appToken);
    addString((Map)hashMap, "app_version", this.deviceInfo.j);
    Boolean bool = Boolean.TRUE;
    addBoolean((Map)hashMap, "attribution_deeplink", bool);
    addDateInMilliseconds((Map)hashMap, "created_at", this.createdAt);
    addBoolean((Map)hashMap, "device_known", this.adjustConfig.deviceKnown);
    addBoolean((Map)hashMap, "needs_cost", this.adjustConfig.needsCost);
    addString((Map)hashMap, "device_name", this.deviceInfo.l);
    addString((Map)hashMap, "device_type", this.deviceInfo.k);
    addLong((Map)hashMap, "ui_mode", this.deviceInfo.C);
    addString((Map)hashMap, "environment", this.adjustConfig.environment);
    addBoolean((Map)hashMap, "event_buffering_enabled", Boolean.valueOf(this.adjustConfig.eventBufferingEnabled));
    addString((Map)hashMap, "external_device_id", this.adjustConfig.externalDeviceId);
    addBoolean((Map)hashMap, "needs_response_details", bool);
    addString((Map)hashMap, "os_name", this.deviceInfo.n);
    addString((Map)hashMap, "os_version", this.deviceInfo.o);
    addString((Map)hashMap, "package_name", this.deviceInfo.i);
    addString((Map)hashMap, "push_token", this.activityStateCopy.h);
    addString((Map)hashMap, "secret_id", this.adjustConfig.secretId);
    injectFeatureFlagsWithParameters((Map)hashMap);
    checkDeviceIds((Map)hashMap);
    return (Map)hashMap;
  }
  
  private Map<String, String> getInfoParameters(String paramString) {
    HashMap<Object, Object> hashMap = new HashMap<>();
    Map<String, String> map = Util.getImeiParameters(this.adjustConfig, logger);
    if (map != null)
      hashMap.putAll(map); 
    map = Util.getOaidParameters(this.adjustConfig, logger);
    if (map != null)
      hashMap.putAll(map); 
    this.deviceInfo.b(this.adjustConfig);
    addString((Map)hashMap, "android_uuid", this.activityStateCopy.g);
    addString((Map)hashMap, "gps_adid", this.deviceInfo.a);
    addLong((Map)hashMap, "gps_adid_attempt", this.deviceInfo.c);
    addString((Map)hashMap, "gps_adid_src", this.deviceInfo.b);
    addBoolean((Map)hashMap, "tracking_enabled", this.deviceInfo.d);
    addString((Map)hashMap, "fire_adid", Util.getFireAdvertisingId(this.adjustConfig));
    addBoolean((Map)hashMap, "fire_tracking_enabled", Util.getFireTrackingEnabled(this.adjustConfig));
    if (!containsPlayIds((Map)hashMap) && !containsFireIds((Map)hashMap)) {
      logger.warn("Google Advertising ID or Fire Advertising ID not detected, fallback to non Google Play and Fire identifiers will take place", new Object[0]);
      this.deviceInfo.a(this.adjustConfig);
      addString((Map)hashMap, "android_id", this.deviceInfo.f);
    } 
    addString((Map)hashMap, "app_secret", this.adjustConfig.appSecret);
    addString((Map)hashMap, "app_token", this.adjustConfig.appToken);
    Boolean bool = Boolean.TRUE;
    addBoolean((Map)hashMap, "attribution_deeplink", bool);
    addDateInMilliseconds((Map)hashMap, "created_at", this.createdAt);
    addBoolean((Map)hashMap, "device_known", this.adjustConfig.deviceKnown);
    addBoolean((Map)hashMap, "needs_cost", this.adjustConfig.needsCost);
    addString((Map)hashMap, "environment", this.adjustConfig.environment);
    addBoolean((Map)hashMap, "event_buffering_enabled", Boolean.valueOf(this.adjustConfig.eventBufferingEnabled));
    addString((Map)hashMap, "external_device_id", this.adjustConfig.externalDeviceId);
    addBoolean((Map)hashMap, "needs_response_details", bool);
    addString((Map)hashMap, "push_token", this.activityStateCopy.h);
    addString((Map)hashMap, "secret_id", this.adjustConfig.secretId);
    addString((Map)hashMap, "source", paramString);
    injectFeatureFlagsWithParameters((Map)hashMap);
    checkDeviceIds((Map)hashMap);
    return (Map)hashMap;
  }
  
  private Map<String, String> getMeasurementConsentParameters(boolean paramBoolean) {
    String str;
    HashMap<Object, Object> hashMap = new HashMap<>();
    Map<String, String> map = Util.getImeiParameters(this.adjustConfig, logger);
    if (map != null)
      hashMap.putAll(map); 
    map = Util.getOaidParameters(this.adjustConfig, logger);
    if (map != null)
      hashMap.putAll(map); 
    if (paramBoolean) {
      str = "enable";
    } else {
      str = "disable";
    } 
    addString((Map)hashMap, "measurement", str);
    this.deviceInfo.b(this.adjustConfig);
    addString((Map)hashMap, "android_uuid", this.activityStateCopy.g);
    addString((Map)hashMap, "gps_adid", this.deviceInfo.a);
    addLong((Map)hashMap, "gps_adid_attempt", this.deviceInfo.c);
    addString((Map)hashMap, "gps_adid_src", this.deviceInfo.b);
    addBoolean((Map)hashMap, "tracking_enabled", this.deviceInfo.d);
    addString((Map)hashMap, "fire_adid", Util.getFireAdvertisingId(this.adjustConfig));
    addBoolean((Map)hashMap, "fire_tracking_enabled", Util.getFireTrackingEnabled(this.adjustConfig));
    if (!containsPlayIds((Map)hashMap) && !containsFireIds((Map)hashMap)) {
      logger.warn("Google Advertising ID or Fire Advertising ID not detected, fallback to non Google Play and Fire identifiers will take place", new Object[0]);
      this.deviceInfo.a(this.adjustConfig);
      addString((Map)hashMap, "android_id", this.deviceInfo.f);
    } 
    addString((Map)hashMap, "api_level", this.deviceInfo.p);
    addString((Map)hashMap, "app_secret", this.adjustConfig.appSecret);
    addString((Map)hashMap, "app_token", this.adjustConfig.appToken);
    addString((Map)hashMap, "app_version", this.deviceInfo.j);
    Boolean bool = Boolean.TRUE;
    addBoolean((Map)hashMap, "attribution_deeplink", bool);
    addDateInMilliseconds((Map)hashMap, "created_at", this.createdAt);
    addBoolean((Map)hashMap, "device_known", this.adjustConfig.deviceKnown);
    addString((Map)hashMap, "device_name", this.deviceInfo.l);
    addString((Map)hashMap, "device_type", this.deviceInfo.k);
    addLong((Map)hashMap, "ui_mode", this.deviceInfo.C);
    addString((Map)hashMap, "environment", this.adjustConfig.environment);
    addBoolean((Map)hashMap, "event_buffering_enabled", Boolean.valueOf(this.adjustConfig.eventBufferingEnabled));
    addString((Map)hashMap, "external_device_id", this.adjustConfig.externalDeviceId);
    addBoolean((Map)hashMap, "needs_response_details", bool);
    addString((Map)hashMap, "os_name", this.deviceInfo.n);
    addString((Map)hashMap, "os_version", this.deviceInfo.o);
    addString((Map)hashMap, "package_name", this.deviceInfo.i);
    addString((Map)hashMap, "push_token", this.activityStateCopy.h);
    addString((Map)hashMap, "secret_id", this.adjustConfig.secretId);
    injectFeatureFlagsWithParameters((Map)hashMap);
    checkDeviceIds((Map)hashMap);
    return (Map)hashMap;
  }
  
  private Map<String, String> getSessionParameters(boolean paramBoolean) {
    HashMap<Object, Object> hashMap = new HashMap<>();
    Map<String, String> map = Util.getImeiParameters(this.adjustConfig, logger);
    if (map != null)
      hashMap.putAll(map); 
    map = Util.getOaidParameters(this.adjustConfig, logger);
    if (map != null)
      hashMap.putAll(map); 
    if (!paramBoolean) {
      addMapJson((Map)hashMap, "callback_params", this.sessionParameters.callbackParameters);
      addMapJson((Map)hashMap, "partner_params", this.sessionParameters.partnerParameters);
    } 
    this.deviceInfo.b(this.adjustConfig);
    addString((Map)hashMap, "android_uuid", this.activityStateCopy.g);
    addString((Map)hashMap, "gps_adid", this.deviceInfo.a);
    addLong((Map)hashMap, "gps_adid_attempt", this.deviceInfo.c);
    addString((Map)hashMap, "gps_adid_src", this.deviceInfo.b);
    addBoolean((Map)hashMap, "tracking_enabled", this.deviceInfo.d);
    addString((Map)hashMap, "fire_adid", Util.getFireAdvertisingId(this.adjustConfig));
    addBoolean((Map)hashMap, "fire_tracking_enabled", Util.getFireTrackingEnabled(this.adjustConfig));
    if (!containsPlayIds((Map)hashMap) && !containsFireIds((Map)hashMap)) {
      logger.warn("Google Advertising ID or Fire Advertising ID not detected, fallback to non Google Play and Fire identifiers will take place", new Object[0]);
      this.deviceInfo.a(this.adjustConfig);
      addString((Map)hashMap, "android_id", this.deviceInfo.f);
    } 
    addString((Map)hashMap, "api_level", this.deviceInfo.p);
    addString((Map)hashMap, "app_secret", this.adjustConfig.appSecret);
    addString((Map)hashMap, "app_token", this.adjustConfig.appToken);
    addString((Map)hashMap, "app_version", this.deviceInfo.j);
    Boolean bool = Boolean.TRUE;
    addBoolean((Map)hashMap, "attribution_deeplink", bool);
    addLong((Map)hashMap, "connectivity_type", Util.getConnectivityType(this.adjustConfig.context));
    addString((Map)hashMap, "country", this.deviceInfo.r);
    addString((Map)hashMap, "cpu_type", this.deviceInfo.y);
    addDateInMilliseconds((Map)hashMap, "created_at", this.createdAt);
    addString((Map)hashMap, "default_tracker", this.adjustConfig.defaultTracker);
    addBoolean((Map)hashMap, "device_known", this.adjustConfig.deviceKnown);
    addBoolean((Map)hashMap, "needs_cost", this.adjustConfig.needsCost);
    addString((Map)hashMap, "device_manufacturer", this.deviceInfo.m);
    addString((Map)hashMap, "device_name", this.deviceInfo.l);
    addString((Map)hashMap, "device_type", this.deviceInfo.k);
    addLong((Map)hashMap, "ui_mode", this.deviceInfo.C);
    addString((Map)hashMap, "display_height", this.deviceInfo.w);
    addString((Map)hashMap, "display_width", this.deviceInfo.v);
    addString((Map)hashMap, "environment", this.adjustConfig.environment);
    addBoolean((Map)hashMap, "event_buffering_enabled", Boolean.valueOf(this.adjustConfig.eventBufferingEnabled));
    addString((Map)hashMap, "external_device_id", this.adjustConfig.externalDeviceId);
    addString((Map)hashMap, "fb_id", this.deviceInfo.g);
    addString((Map)hashMap, "hardware_name", this.deviceInfo.x);
    addString((Map)hashMap, "installed_at", this.deviceInfo.A);
    addString((Map)hashMap, "language", this.deviceInfo.q);
    addDuration((Map)hashMap, "last_interval", this.activityStateCopy.e);
    addString((Map)hashMap, "mcc", Util.getMcc(this.adjustConfig.context));
    addString((Map)hashMap, "mnc", Util.getMnc(this.adjustConfig.context));
    addBoolean((Map)hashMap, "needs_response_details", bool);
    addString((Map)hashMap, "os_build", this.deviceInfo.z);
    addString((Map)hashMap, "os_name", this.deviceInfo.n);
    addString((Map)hashMap, "os_version", this.deviceInfo.o);
    addString((Map)hashMap, "package_name", this.deviceInfo.i);
    addString((Map)hashMap, "push_token", this.activityStateCopy.h);
    addString((Map)hashMap, "screen_density", this.deviceInfo.u);
    addString((Map)hashMap, "screen_format", this.deviceInfo.t);
    addString((Map)hashMap, "screen_size", this.deviceInfo.s);
    addString((Map)hashMap, "secret_id", this.adjustConfig.secretId);
    addLong((Map)hashMap, "session_count", this.activityStateCopy.b);
    addDuration((Map)hashMap, "session_length", this.activityStateCopy.f);
    addLong((Map)hashMap, "subsession_count", this.activityStateCopy.c);
    addDuration((Map)hashMap, "time_spent", this.activityStateCopy.d);
    addString((Map)hashMap, "updated_at", this.deviceInfo.B);
    injectFeatureFlagsWithParameters((Map)hashMap);
    checkDeviceIds((Map)hashMap);
    return (Map)hashMap;
  }
  
  private Map<String, String> getSubscriptionParameters(AdjustPlayStoreSubscription paramAdjustPlayStoreSubscription, boolean paramBoolean) {
    HashMap<Object, Object> hashMap = new HashMap<>();
    Map<String, String> map = Util.getImeiParameters(this.adjustConfig, logger);
    if (map != null)
      hashMap.putAll(map); 
    map = Util.getOaidParameters(this.adjustConfig, logger);
    if (map != null)
      hashMap.putAll(map); 
    this.deviceInfo.b(this.adjustConfig);
    addString((Map)hashMap, "android_uuid", this.activityStateCopy.g);
    addString((Map)hashMap, "gps_adid", this.deviceInfo.a);
    addLong((Map)hashMap, "gps_adid_attempt", this.deviceInfo.c);
    addString((Map)hashMap, "gps_adid_src", this.deviceInfo.b);
    addBoolean((Map)hashMap, "tracking_enabled", this.deviceInfo.d);
    addString((Map)hashMap, "fire_adid", Util.getFireAdvertisingId(this.adjustConfig));
    addBoolean((Map)hashMap, "fire_tracking_enabled", Util.getFireTrackingEnabled(this.adjustConfig));
    if (!containsPlayIds((Map)hashMap) && !containsFireIds((Map)hashMap)) {
      logger.warn("Google Advertising ID or Fire Advertising ID not detected, fallback to non Google Play and Fire identifiers will take place", new Object[0]);
      this.deviceInfo.a(this.adjustConfig);
      addString((Map)hashMap, "android_id", this.deviceInfo.f);
    } 
    if (!paramBoolean) {
      addMapJson((Map)hashMap, "callback_params", Util.mergeParameters(this.sessionParameters.callbackParameters, paramAdjustPlayStoreSubscription.getCallbackParameters(), "Callback"));
      addMapJson((Map)hashMap, "partner_params", Util.mergeParameters(this.sessionParameters.partnerParameters, paramAdjustPlayStoreSubscription.getPartnerParameters(), "Partner"));
    } 
    addString((Map)hashMap, "api_level", this.deviceInfo.p);
    addString((Map)hashMap, "app_secret", this.adjustConfig.appSecret);
    addString((Map)hashMap, "app_token", this.adjustConfig.appToken);
    addString((Map)hashMap, "app_version", this.deviceInfo.j);
    Boolean bool = Boolean.TRUE;
    addBoolean((Map)hashMap, "attribution_deeplink", bool);
    addLong((Map)hashMap, "connectivity_type", Util.getConnectivityType(this.adjustConfig.context));
    addString((Map)hashMap, "country", this.deviceInfo.r);
    addString((Map)hashMap, "cpu_type", this.deviceInfo.y);
    addDateInMilliseconds((Map)hashMap, "created_at", this.createdAt);
    addString((Map)hashMap, "default_tracker", this.adjustConfig.defaultTracker);
    addBoolean((Map)hashMap, "device_known", this.adjustConfig.deviceKnown);
    addBoolean((Map)hashMap, "needs_cost", this.adjustConfig.needsCost);
    addString((Map)hashMap, "device_manufacturer", this.deviceInfo.m);
    addString((Map)hashMap, "device_name", this.deviceInfo.l);
    addString((Map)hashMap, "device_type", this.deviceInfo.k);
    addLong((Map)hashMap, "ui_mode", this.deviceInfo.C);
    addString((Map)hashMap, "display_height", this.deviceInfo.w);
    addString((Map)hashMap, "display_width", this.deviceInfo.v);
    addString((Map)hashMap, "environment", this.adjustConfig.environment);
    addBoolean((Map)hashMap, "event_buffering_enabled", Boolean.valueOf(this.adjustConfig.eventBufferingEnabled));
    addString((Map)hashMap, "external_device_id", this.adjustConfig.externalDeviceId);
    addString((Map)hashMap, "fb_id", this.deviceInfo.g);
    addString((Map)hashMap, "hardware_name", this.deviceInfo.x);
    addString((Map)hashMap, "installed_at", this.deviceInfo.A);
    addString((Map)hashMap, "language", this.deviceInfo.q);
    addDuration((Map)hashMap, "last_interval", this.activityStateCopy.e);
    addString((Map)hashMap, "mcc", Util.getMcc(this.adjustConfig.context));
    addString((Map)hashMap, "mnc", Util.getMnc(this.adjustConfig.context));
    addBoolean((Map)hashMap, "needs_response_details", bool);
    addString((Map)hashMap, "os_build", this.deviceInfo.z);
    addString((Map)hashMap, "os_name", this.deviceInfo.n);
    addString((Map)hashMap, "os_version", this.deviceInfo.o);
    addString((Map)hashMap, "package_name", this.deviceInfo.i);
    addString((Map)hashMap, "push_token", this.activityStateCopy.h);
    addString((Map)hashMap, "screen_density", this.deviceInfo.u);
    addString((Map)hashMap, "screen_format", this.deviceInfo.t);
    addString((Map)hashMap, "screen_size", this.deviceInfo.s);
    addString((Map)hashMap, "secret_id", this.adjustConfig.secretId);
    addLong((Map)hashMap, "session_count", this.activityStateCopy.b);
    addDuration((Map)hashMap, "session_length", this.activityStateCopy.f);
    addLong((Map)hashMap, "subsession_count", this.activityStateCopy.c);
    addDuration((Map)hashMap, "time_spent", this.activityStateCopy.d);
    addString((Map)hashMap, "updated_at", this.deviceInfo.B);
    addString((Map)hashMap, "billing_store", paramAdjustPlayStoreSubscription.getBillingStore());
    addString((Map)hashMap, "currency", paramAdjustPlayStoreSubscription.getCurrency());
    addString((Map)hashMap, "product_id", paramAdjustPlayStoreSubscription.getSku());
    addString((Map)hashMap, "purchase_token", paramAdjustPlayStoreSubscription.getPurchaseToken());
    addString((Map)hashMap, "receipt", paramAdjustPlayStoreSubscription.getSignature());
    addLong((Map)hashMap, "revenue", paramAdjustPlayStoreSubscription.getPrice());
    addDateInMilliseconds((Map)hashMap, "transaction_date", paramAdjustPlayStoreSubscription.getPurchaseTime());
    addString((Map)hashMap, "transaction_id", paramAdjustPlayStoreSubscription.getOrderId());
    injectFeatureFlagsWithParameters((Map)hashMap);
    checkDeviceIds((Map)hashMap);
    return (Map)hashMap;
  }
  
  private Map<String, String> getThirdPartySharingParameters(AdjustThirdPartySharing paramAdjustThirdPartySharing) {
    HashMap<Object, Object> hashMap = new HashMap<>();
    Map<String, String> map = Util.getImeiParameters(this.adjustConfig, logger);
    if (map != null)
      hashMap.putAll(map); 
    map = Util.getOaidParameters(this.adjustConfig, logger);
    if (map != null)
      hashMap.putAll(map); 
    Boolean bool2 = paramAdjustThirdPartySharing.isEnabled;
    if (bool2 != null) {
      String str;
      if (bool2.booleanValue()) {
        str = "enable";
      } else {
        str = "disable";
      } 
      addString((Map)hashMap, "sharing", str);
    } 
    addMapJson((Map)hashMap, "granular_third_party_sharing_options", paramAdjustThirdPartySharing.granularOptions);
    addMapJson((Map)hashMap, "partner_sharing_settings", paramAdjustThirdPartySharing.partnerSharingSettings);
    this.deviceInfo.b(this.adjustConfig);
    addString((Map)hashMap, "android_uuid", this.activityStateCopy.g);
    addString((Map)hashMap, "gps_adid", this.deviceInfo.a);
    addLong((Map)hashMap, "gps_adid_attempt", this.deviceInfo.c);
    addString((Map)hashMap, "gps_adid_src", this.deviceInfo.b);
    addBoolean((Map)hashMap, "tracking_enabled", this.deviceInfo.d);
    addString((Map)hashMap, "fire_adid", Util.getFireAdvertisingId(this.adjustConfig));
    addBoolean((Map)hashMap, "fire_tracking_enabled", Util.getFireTrackingEnabled(this.adjustConfig));
    if (!containsPlayIds((Map)hashMap) && !containsFireIds((Map)hashMap)) {
      logger.warn("Google Advertising ID or Fire Advertising ID not detected, fallback to non Google Play and Fire identifiers will take place", new Object[0]);
      this.deviceInfo.a(this.adjustConfig);
      addString((Map)hashMap, "android_id", this.deviceInfo.f);
    } 
    addString((Map)hashMap, "api_level", this.deviceInfo.p);
    addString((Map)hashMap, "app_secret", this.adjustConfig.appSecret);
    addString((Map)hashMap, "app_token", this.adjustConfig.appToken);
    addString((Map)hashMap, "app_version", this.deviceInfo.j);
    Boolean bool1 = Boolean.TRUE;
    addBoolean((Map)hashMap, "attribution_deeplink", bool1);
    addDateInMilliseconds((Map)hashMap, "created_at", this.createdAt);
    addBoolean((Map)hashMap, "device_known", this.adjustConfig.deviceKnown);
    addString((Map)hashMap, "device_name", this.deviceInfo.l);
    addString((Map)hashMap, "device_type", this.deviceInfo.k);
    addLong((Map)hashMap, "ui_mode", this.deviceInfo.C);
    addString((Map)hashMap, "environment", this.adjustConfig.environment);
    addBoolean((Map)hashMap, "event_buffering_enabled", Boolean.valueOf(this.adjustConfig.eventBufferingEnabled));
    addString((Map)hashMap, "external_device_id", this.adjustConfig.externalDeviceId);
    addBoolean((Map)hashMap, "needs_response_details", bool1);
    addString((Map)hashMap, "os_name", this.deviceInfo.n);
    addString((Map)hashMap, "os_version", this.deviceInfo.o);
    addString((Map)hashMap, "package_name", this.deviceInfo.i);
    addString((Map)hashMap, "push_token", this.activityStateCopy.h);
    addString((Map)hashMap, "secret_id", this.adjustConfig.secretId);
    injectFeatureFlagsWithParameters((Map)hashMap);
    checkDeviceIds((Map)hashMap);
    return (Map)hashMap;
  }
  
  private void injectFeatureFlagsWithParameters(Map<String, String> paramMap) {
    if (this.adjustConfig.coppaCompliantEnabled)
      addLong(paramMap, "ff_coppa", 1L); 
    if (this.adjustConfig.playStoreKidsAppEnabled)
      addLong(paramMap, "ff_play_store_kids_app", 1L); 
  }
  
  public ActivityPackage buildAdRevenuePackage(AdjustAdRevenue paramAdjustAdRevenue, boolean paramBoolean) {
    Map<String, String> map = getAdRevenueParameters(paramAdjustAdRevenue, paramBoolean);
    ActivityKind activityKind = ActivityKind.AD_REVENUE;
    ActivityPackage activityPackage = getDefaultActivityPackage(activityKind);
    activityPackage.setPath("/ad_revenue");
    activityPackage.setSuffix("");
    String str1 = activityKind.toString();
    String str2 = activityPackage.getClientSdk();
    AdjustConfig adjustConfig = this.adjustConfig;
    AdjustSigner.sign(map, str1, str2, adjustConfig.context, adjustConfig.logger);
    activityPackage.setParameters(map);
    if (paramBoolean) {
      activityPackage.setCallbackParameters(paramAdjustAdRevenue.callbackParameters);
      activityPackage.setPartnerParameters(paramAdjustAdRevenue.partnerParameters);
    } 
    return activityPackage;
  }
  
  public ActivityPackage buildAdRevenuePackage(String paramString, b paramb) {
    Map<String, String> map = getAdRevenueParameters(paramString, paramb);
    ActivityKind activityKind = ActivityKind.AD_REVENUE;
    ActivityPackage activityPackage = getDefaultActivityPackage(activityKind);
    activityPackage.setPath("/ad_revenue");
    activityPackage.setSuffix("");
    String str1 = activityKind.toString();
    String str2 = activityPackage.getClientSdk();
    AdjustConfig adjustConfig = this.adjustConfig;
    AdjustSigner.sign(map, str1, str2, adjustConfig.context, adjustConfig.logger);
    activityPackage.setParameters(map);
    return activityPackage;
  }
  
  public ActivityPackage buildAttributionPackage(String paramString) {
    Map<String, String> map = getAttributionParameters(paramString);
    ActivityKind activityKind = ActivityKind.ATTRIBUTION;
    ActivityPackage activityPackage = getDefaultActivityPackage(activityKind);
    activityPackage.setPath("attribution");
    activityPackage.setSuffix("");
    String str2 = activityKind.toString();
    String str1 = activityPackage.getClientSdk();
    AdjustConfig adjustConfig = this.adjustConfig;
    AdjustSigner.sign(map, str2, str1, adjustConfig.context, adjustConfig.logger);
    activityPackage.setParameters(map);
    return activityPackage;
  }
  
  public ActivityPackage buildClickPackage(String paramString) {
    Map<String, String> map = getClickParameters(paramString);
    ActivityKind activityKind = ActivityKind.CLICK;
    ActivityPackage activityPackage = getDefaultActivityPackage(activityKind);
    activityPackage.setPath("/sdk_click");
    activityPackage.setSuffix("");
    activityPackage.setClickTimeInMilliseconds(this.clickTimeInMilliseconds);
    activityPackage.setClickTimeInSeconds(this.clickTimeInSeconds);
    activityPackage.setInstallBeginTimeInSeconds(this.installBeginTimeInSeconds);
    activityPackage.setClickTimeServerInSeconds(this.clickTimeServerInSeconds);
    activityPackage.setInstallBeginTimeServerInSeconds(this.installBeginTimeServerInSeconds);
    activityPackage.setInstallVersion(this.installVersion);
    activityPackage.setGooglePlayInstant(this.googlePlayInstant);
    String str1 = activityKind.toString();
    String str2 = activityPackage.getClientSdk();
    AdjustConfig adjustConfig = this.adjustConfig;
    AdjustSigner.sign(map, str1, str2, adjustConfig.context, adjustConfig.logger);
    activityPackage.setParameters(map);
    return activityPackage;
  }
  
  public ActivityPackage buildDisableThirdPartySharingPackage() {
    Map<String, String> map = getDisableThirdPartySharingParameters();
    ActivityKind activityKind = ActivityKind.DISABLE_THIRD_PARTY_SHARING;
    ActivityPackage activityPackage = getDefaultActivityPackage(activityKind);
    activityPackage.setPath("/disable_third_party_sharing");
    activityPackage.setSuffix("");
    String str1 = activityKind.toString();
    String str2 = activityPackage.getClientSdk();
    AdjustConfig adjustConfig = this.adjustConfig;
    AdjustSigner.sign(map, str1, str2, adjustConfig.context, adjustConfig.logger);
    activityPackage.setParameters(map);
    return activityPackage;
  }
  
  public ActivityPackage buildEventPackage(AdjustEvent paramAdjustEvent, boolean paramBoolean) {
    Map<String, String> map = getEventParameters(paramAdjustEvent, paramBoolean);
    ActivityKind activityKind = ActivityKind.EVENT;
    ActivityPackage activityPackage = getDefaultActivityPackage(activityKind);
    activityPackage.setPath("/event");
    activityPackage.setSuffix(getEventSuffix(paramAdjustEvent));
    String str1 = activityKind.toString();
    String str2 = activityPackage.getClientSdk();
    AdjustConfig adjustConfig = this.adjustConfig;
    AdjustSigner.sign(map, str1, str2, adjustConfig.context, adjustConfig.logger);
    activityPackage.setParameters(map);
    if (paramBoolean) {
      activityPackage.setCallbackParameters(paramAdjustEvent.callbackParameters);
      activityPackage.setPartnerParameters(paramAdjustEvent.partnerParameters);
    } 
    return activityPackage;
  }
  
  public ActivityPackage buildGdprPackage() {
    Map<String, String> map = getGdprParameters();
    ActivityKind activityKind = ActivityKind.GDPR;
    ActivityPackage activityPackage = getDefaultActivityPackage(activityKind);
    activityPackage.setPath("/gdpr_forget_device");
    activityPackage.setSuffix("");
    String str2 = activityKind.toString();
    String str1 = activityPackage.getClientSdk();
    AdjustConfig adjustConfig = this.adjustConfig;
    AdjustSigner.sign(map, str2, str1, adjustConfig.context, adjustConfig.logger);
    activityPackage.setParameters(map);
    return activityPackage;
  }
  
  public ActivityPackage buildInfoPackage(String paramString) {
    Map<String, String> map = getInfoParameters(paramString);
    ActivityKind activityKind = ActivityKind.INFO;
    ActivityPackage activityPackage = getDefaultActivityPackage(activityKind);
    activityPackage.setPath("/sdk_info");
    activityPackage.setSuffix("");
    String str1 = activityKind.toString();
    String str2 = activityPackage.getClientSdk();
    AdjustConfig adjustConfig = this.adjustConfig;
    AdjustSigner.sign(map, str1, str2, adjustConfig.context, adjustConfig.logger);
    activityPackage.setParameters(map);
    return activityPackage;
  }
  
  public ActivityPackage buildMeasurementConsentPackage(boolean paramBoolean) {
    Map<String, String> map = getMeasurementConsentParameters(paramBoolean);
    ActivityKind activityKind = ActivityKind.MEASUREMENT_CONSENT;
    ActivityPackage activityPackage = getDefaultActivityPackage(activityKind);
    activityPackage.setPath("/measurement_consent");
    activityPackage.setSuffix("");
    String str2 = activityKind.toString();
    String str1 = activityPackage.getClientSdk();
    AdjustConfig adjustConfig = this.adjustConfig;
    AdjustSigner.sign(map, str2, str1, adjustConfig.context, adjustConfig.logger);
    activityPackage.setParameters(map);
    return activityPackage;
  }
  
  public ActivityPackage buildSessionPackage(boolean paramBoolean) {
    Map<String, String> map = getSessionParameters(paramBoolean);
    ActivityKind activityKind = ActivityKind.SESSION;
    ActivityPackage activityPackage = getDefaultActivityPackage(activityKind);
    activityPackage.setPath("/session");
    activityPackage.setSuffix("");
    String str1 = activityKind.toString();
    String str2 = activityPackage.getClientSdk();
    AdjustConfig adjustConfig = this.adjustConfig;
    AdjustSigner.sign(map, str1, str2, adjustConfig.context, adjustConfig.logger);
    activityPackage.setParameters(map);
    return activityPackage;
  }
  
  public ActivityPackage buildSubscriptionPackage(AdjustPlayStoreSubscription paramAdjustPlayStoreSubscription, boolean paramBoolean) {
    Map<String, String> map = getSubscriptionParameters(paramAdjustPlayStoreSubscription, paramBoolean);
    ActivityKind activityKind = ActivityKind.SUBSCRIPTION;
    ActivityPackage activityPackage = getDefaultActivityPackage(activityKind);
    activityPackage.setPath("/v2/purchase");
    activityPackage.setSuffix("");
    String str1 = activityKind.toString();
    String str2 = activityPackage.getClientSdk();
    AdjustConfig adjustConfig = this.adjustConfig;
    AdjustSigner.sign(map, str1, str2, adjustConfig.context, adjustConfig.logger);
    activityPackage.setParameters(map);
    return activityPackage;
  }
  
  public ActivityPackage buildThirdPartySharingPackage(AdjustThirdPartySharing paramAdjustThirdPartySharing) {
    Map<String, String> map = getThirdPartySharingParameters(paramAdjustThirdPartySharing);
    ActivityKind activityKind = ActivityKind.THIRD_PARTY_SHARING;
    ActivityPackage activityPackage = getDefaultActivityPackage(activityKind);
    activityPackage.setPath("/third_party_sharing");
    activityPackage.setSuffix("");
    String str2 = activityKind.toString();
    String str1 = activityPackage.getClientSdk();
    AdjustConfig adjustConfig = this.adjustConfig;
    AdjustSigner.sign(map, str2, str1, adjustConfig.context, adjustConfig.logger);
    activityPackage.setParameters(map);
    return activityPackage;
  }
  
  public Map<String, String> getEventParameters(AdjustEvent paramAdjustEvent, boolean paramBoolean) {
    HashMap<Object, Object> hashMap = new HashMap<>();
    Map<String, String> map = Util.getImeiParameters(this.adjustConfig, logger);
    if (map != null)
      hashMap.putAll(map); 
    map = Util.getOaidParameters(this.adjustConfig, logger);
    if (map != null)
      hashMap.putAll(map); 
    if (!paramBoolean) {
      addMapJson((Map)hashMap, "callback_params", Util.mergeParameters(this.sessionParameters.callbackParameters, paramAdjustEvent.callbackParameters, "Callback"));
      addMapJson((Map)hashMap, "partner_params", Util.mergeParameters(this.sessionParameters.partnerParameters, paramAdjustEvent.partnerParameters, "Partner"));
    } 
    this.deviceInfo.b(this.adjustConfig);
    addString((Map)hashMap, "android_uuid", this.activityStateCopy.g);
    addString((Map)hashMap, "gps_adid", this.deviceInfo.a);
    addLong((Map)hashMap, "gps_adid_attempt", this.deviceInfo.c);
    addString((Map)hashMap, "gps_adid_src", this.deviceInfo.b);
    addBoolean((Map)hashMap, "tracking_enabled", this.deviceInfo.d);
    addString((Map)hashMap, "fire_adid", Util.getFireAdvertisingId(this.adjustConfig));
    addBoolean((Map)hashMap, "fire_tracking_enabled", Util.getFireTrackingEnabled(this.adjustConfig));
    if (!containsPlayIds((Map)hashMap) && !containsFireIds((Map)hashMap)) {
      logger.warn("Google Advertising ID or Fire Advertising ID not detected, fallback to non Google Play and Fire identifiers will take place", new Object[0]);
      this.deviceInfo.a(this.adjustConfig);
      addString((Map)hashMap, "android_id", this.deviceInfo.f);
    } 
    addString((Map)hashMap, "api_level", this.deviceInfo.p);
    addString((Map)hashMap, "app_secret", this.adjustConfig.appSecret);
    addString((Map)hashMap, "app_token", this.adjustConfig.appToken);
    addString((Map)hashMap, "app_version", this.deviceInfo.j);
    Boolean bool = Boolean.TRUE;
    addBoolean((Map)hashMap, "attribution_deeplink", bool);
    addLong((Map)hashMap, "connectivity_type", Util.getConnectivityType(this.adjustConfig.context));
    addString((Map)hashMap, "country", this.deviceInfo.r);
    addString((Map)hashMap, "cpu_type", this.deviceInfo.y);
    addDateInMilliseconds((Map)hashMap, "created_at", this.createdAt);
    addString((Map)hashMap, "currency", paramAdjustEvent.currency);
    addBoolean((Map)hashMap, "device_known", this.adjustConfig.deviceKnown);
    addBoolean((Map)hashMap, "needs_cost", this.adjustConfig.needsCost);
    addString((Map)hashMap, "device_manufacturer", this.deviceInfo.m);
    addString((Map)hashMap, "device_name", this.deviceInfo.l);
    addString((Map)hashMap, "device_type", this.deviceInfo.k);
    addLong((Map)hashMap, "ui_mode", this.deviceInfo.C);
    addString((Map)hashMap, "display_height", this.deviceInfo.w);
    addString((Map)hashMap, "display_width", this.deviceInfo.v);
    addString((Map)hashMap, "environment", this.adjustConfig.environment);
    addString((Map)hashMap, "event_callback_id", paramAdjustEvent.callbackId);
    addLong((Map)hashMap, "event_count", this.activityStateCopy.a);
    addBoolean((Map)hashMap, "event_buffering_enabled", Boolean.valueOf(this.adjustConfig.eventBufferingEnabled));
    addString((Map)hashMap, "event_token", paramAdjustEvent.eventToken);
    addString((Map)hashMap, "external_device_id", this.adjustConfig.externalDeviceId);
    addString((Map)hashMap, "fb_id", this.deviceInfo.g);
    addString((Map)hashMap, "hardware_name", this.deviceInfo.x);
    addString((Map)hashMap, "language", this.deviceInfo.q);
    addString((Map)hashMap, "mcc", Util.getMcc(this.adjustConfig.context));
    addString((Map)hashMap, "mnc", Util.getMnc(this.adjustConfig.context));
    addBoolean((Map)hashMap, "needs_response_details", bool);
    addString((Map)hashMap, "os_build", this.deviceInfo.z);
    addString((Map)hashMap, "os_name", this.deviceInfo.n);
    addString((Map)hashMap, "os_version", this.deviceInfo.o);
    addString((Map)hashMap, "package_name", this.deviceInfo.i);
    addString((Map)hashMap, "push_token", this.activityStateCopy.h);
    addDouble((Map)hashMap, "revenue", paramAdjustEvent.revenue);
    addString((Map)hashMap, "deduplication_id", paramAdjustEvent.orderId);
    addString((Map)hashMap, "screen_density", this.deviceInfo.u);
    addString((Map)hashMap, "screen_format", this.deviceInfo.t);
    addString((Map)hashMap, "screen_size", this.deviceInfo.s);
    addString((Map)hashMap, "secret_id", this.adjustConfig.secretId);
    addLong((Map)hashMap, "session_count", this.activityStateCopy.b);
    addDuration((Map)hashMap, "session_length", this.activityStateCopy.f);
    addLong((Map)hashMap, "subsession_count", this.activityStateCopy.c);
    addDuration((Map)hashMap, "time_spent", this.activityStateCopy.d);
    injectFeatureFlagsWithParameters((Map)hashMap);
    checkDeviceIds((Map)hashMap);
    return (Map)hashMap;
  }
  
  public final class a {
    public int a = -1;
    
    public int b = -1;
    
    public int c = -1;
    
    public long d = -1L;
    
    public long e = -1L;
    
    public long f = -1L;
    
    public String g = null;
    
    public String h = null;
    
    public a(PackageBuilder this$0) {
      if (this$0 == null)
        return; 
      this.a = ((ActivityState)this$0).eventCount;
      this.b = ((ActivityState)this$0).sessionCount;
      this.c = ((ActivityState)this$0).subsessionCount;
      this.d = ((ActivityState)this$0).timeSpent;
      this.e = ((ActivityState)this$0).lastInterval;
      this.f = ((ActivityState)this$0).sessionLength;
      this.g = ((ActivityState)this$0).uuid;
      this.h = ((ActivityState)this$0).pushToken;
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\adjust\sdk\PackageBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */