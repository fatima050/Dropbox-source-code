package com.adjust.sdk.scheduler;

public class RunnableWrapper implements Runnable {
  private Runnable runnable;
  
  public RunnableWrapper(Runnable paramRunnable) {
    this.runnable = paramRunnable;
  }
  
  public void run() {
    try {
      this.runnable.run();
    } finally {
      Exception exception = null;
    } 
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\adjust\sdk\scheduler\RunnableWrapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */