package com.adjust.sdk.scheduler;

import com.adjust.sdk.AdjustFactory;
import com.adjust.sdk.ILogger;
import com.adjust.sdk.Util;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

public class TimerOnce {
  private Runnable command;
  
  private ILogger logger;
  
  private String name;
  
  private FutureScheduler scheduler;
  
  private ScheduledFuture waitingTask;
  
  public TimerOnce(Runnable paramRunnable, String paramString) {
    this.name = paramString;
    this.scheduler = new SingleThreadFutureScheduler(paramString, true);
    this.command = paramRunnable;
    this.logger = AdjustFactory.getLogger();
  }
  
  private void cancel(boolean paramBoolean) {
    ScheduledFuture scheduledFuture = this.waitingTask;
    if (scheduledFuture != null)
      scheduledFuture.cancel(paramBoolean); 
    this.waitingTask = null;
    this.logger.verbose("%s canceled", new Object[] { this.name });
  }
  
  public void cancel() {
    cancel(false);
  }
  
  public long getFireIn() {
    ScheduledFuture scheduledFuture = this.waitingTask;
    return (scheduledFuture == null) ? 0L : scheduledFuture.getDelay(TimeUnit.MILLISECONDS);
  }
  
  public void startIn(long paramLong) {
    cancel(false);
    String str = Util.SecondsDisplayFormat.format(paramLong / 1000.0D);
    this.logger.verbose("%s starting. Launching in %s seconds", new Object[] { this.name, str });
    this.waitingTask = this.scheduler.scheduleFuture(new a(this), paramLong);
  }
  
  public void teardown() {
    cancel(true);
    FutureScheduler futureScheduler = this.scheduler;
    if (futureScheduler != null)
      futureScheduler.teardown(); 
    this.scheduler = null;
  }
  
  public final class a implements Runnable {
    public final TimerOnce a;
    
    public a(TimerOnce this$0) {}
    
    public final void run() {
      this.a.logger.verbose("%s fired", new Object[] { TimerOnce.access$000(this.a) });
      this.a.command.run();
      TimerOnce.access$302(this.a, null);
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\adjust\sdk\scheduler\TimerOnce.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */