package com.adjust.sdk.scheduler;

import com.adjust.sdk.AdjustFactory;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;

public class ThreadFactoryWrapper implements ThreadFactory {
  private String source;
  
  public ThreadFactoryWrapper(String paramString) {
    this.source = paramString;
  }
  
  public Thread newThread(Runnable paramRunnable) {
    paramRunnable = Executors.defaultThreadFactory().newThread(paramRunnable);
    paramRunnable.setPriority(9);
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Adjust-");
    stringBuilder.append(paramRunnable.getName());
    stringBuilder.append("-");
    stringBuilder.append(this.source);
    paramRunnable.setName(stringBuilder.toString());
    paramRunnable.setDaemon(true);
    paramRunnable.setUncaughtExceptionHandler(new a());
    return (Thread)paramRunnable;
  }
  
  public final class a implements Thread.UncaughtExceptionHandler {
    public final void uncaughtException(Thread param1Thread, Throwable param1Throwable) {
      AdjustFactory.getLogger().error("Thread [%s] with error [%s]", new Object[] { param1Thread.getName(), param1Throwable.getMessage() });
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\adjust\sdk\scheduler\ThreadFactoryWrapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */