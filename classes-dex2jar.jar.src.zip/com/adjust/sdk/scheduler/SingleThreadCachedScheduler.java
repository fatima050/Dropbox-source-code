package com.adjust.sdk.scheduler;

import com.adjust.sdk.AdjustFactory;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class SingleThreadCachedScheduler implements ThreadScheduler {
  private boolean isTeardown = false;
  
  private boolean isThreadProcessing = false;
  
  private final List<Runnable> queue = new ArrayList<>();
  
  private ThreadPoolExecutor threadPoolExecutor;
  
  public SingleThreadCachedScheduler(String paramString) {
    this.threadPoolExecutor = new ThreadPoolExecutor(0, 2147483647, 60L, TimeUnit.SECONDS, new SynchronousQueue<>(), new ThreadFactoryWrapper(paramString), new a(paramString));
  }
  
  private void processQueue(Runnable paramRunnable) {
    this.threadPoolExecutor.submit(new c(this, paramRunnable));
  }
  
  private void tryExecuteRunnable(Runnable paramRunnable) {
    try {
      if (this.isTeardown)
        return; 
    } finally {
      paramRunnable = null;
    } 
  }
  
  public void schedule(Runnable paramRunnable, long paramLong) {
    List<Runnable> list = this.queue;
    /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{java/util/List<ObjectType{java/lang/Runnable}>}, name=null} */
    try {
      if (this.isTeardown) {
        /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/util/List<ObjectType{java/lang/Runnable}>}, name=null} */
        return;
      } 
    } finally {}
    ThreadPoolExecutor threadPoolExecutor = this.threadPoolExecutor;
    b b = new b();
    this(this, paramLong, paramRunnable);
    threadPoolExecutor.submit((Runnable)b);
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/util/List<ObjectType{java/lang/Runnable}>}, name=null} */
  }
  
  public void submit(Runnable paramRunnable) {
    List<Runnable> list = this.queue;
    /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{java/util/List<ObjectType{java/lang/Runnable}>}, name=null} */
    try {
      if (this.isTeardown) {
        /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/util/List<ObjectType{java/lang/Runnable}>}, name=null} */
        return;
      } 
    } finally {}
    if (!this.isThreadProcessing) {
      this.isThreadProcessing = true;
      processQueue(paramRunnable);
    } else {
      this.queue.add(paramRunnable);
    } 
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/util/List<ObjectType{java/lang/Runnable}>}, name=null} */
  }
  
  public void teardown() {
    synchronized (this.queue) {
      this.isTeardown = true;
      this.queue.clear();
      this.threadPoolExecutor.shutdown();
      return;
    } 
  }
  
  public final class a implements RejectedExecutionHandler {
    public final String a;
    
    public a(SingleThreadCachedScheduler this$0) {}
    
    public final void rejectedExecution(Runnable param1Runnable, ThreadPoolExecutor param1ThreadPoolExecutor) {
      AdjustFactory.getLogger().warn("Runnable [%s] rejected from [%s] ", new Object[] { param1Runnable.toString(), this.a });
    }
  }
  
  public final class c implements Runnable {
    public final Runnable a;
    
    public final SingleThreadCachedScheduler b;
    
    public c(SingleThreadCachedScheduler this$0, Runnable param1Runnable) {}
    
    public final void run() {
      SingleThreadCachedScheduler singleThreadCachedScheduler = this.b;
      Runnable runnable = this.a;
      while (true) {
        singleThreadCachedScheduler.tryExecuteRunnable(runnable);
        List list = this.b.queue;
        /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{java/util/List}, name=null} */
        try {
          if (this.b.isTeardown) {
            /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/util/List}, name=null} */
            return;
          } 
        } finally {}
        if (this.b.queue.isEmpty()) {
          SingleThreadCachedScheduler.access$302(this.b, false);
          /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/util/List}, name=null} */
          return;
        } 
        runnable = this.b.queue.get(0);
        this.b.queue.remove(0);
        /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/util/List}, name=null} */
        SingleThreadCachedScheduler singleThreadCachedScheduler1 = this.b;
      } 
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\adjust\sdk\scheduler\SingleThreadCachedScheduler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */