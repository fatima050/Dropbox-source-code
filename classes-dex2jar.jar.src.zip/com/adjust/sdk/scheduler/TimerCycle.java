package com.adjust.sdk.scheduler;

import com.adjust.sdk.AdjustFactory;
import com.adjust.sdk.ILogger;
import com.adjust.sdk.Util;
import java.text.DecimalFormat;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

public class TimerCycle {
  private Runnable command;
  
  private long cycleDelay;
  
  private long initialDelay;
  
  private boolean isPaused;
  
  private ILogger logger;
  
  private String name;
  
  private FutureScheduler scheduler;
  
  private ScheduledFuture waitingTask;
  
  public TimerCycle(Runnable paramRunnable, long paramLong1, long paramLong2, String paramString) {
    this.scheduler = new SingleThreadFutureScheduler(paramString, true);
    this.name = paramString;
    this.command = paramRunnable;
    this.initialDelay = paramLong1;
    this.cycleDelay = paramLong2;
    this.isPaused = true;
    this.logger = AdjustFactory.getLogger();
    DecimalFormat decimalFormat = Util.SecondsDisplayFormat;
    String str1 = decimalFormat.format(paramLong2 / 1000.0D);
    String str2 = decimalFormat.format(paramLong1 / 1000.0D);
    this.logger.verbose("%s configured to fire after %s seconds of starting and cycles every %s seconds", new Object[] { paramString, str2, str1 });
  }
  
  private void cancel(boolean paramBoolean) {
    ScheduledFuture scheduledFuture = this.waitingTask;
    if (scheduledFuture != null)
      scheduledFuture.cancel(paramBoolean); 
    this.waitingTask = null;
  }
  
  public void start() {
    if (!this.isPaused) {
      this.logger.verbose("%s is already started", new Object[] { this.name });
      return;
    } 
    this.logger.verbose("%s starting", new Object[] { this.name });
    this.waitingTask = this.scheduler.scheduleFutureWithFixedDelay(new a(this), this.initialDelay, this.cycleDelay);
    this.isPaused = false;
  }
  
  public void suspend() {
    if (this.isPaused) {
      this.logger.verbose("%s is already suspended", new Object[] { this.name });
      return;
    } 
    this.initialDelay = this.waitingTask.getDelay(TimeUnit.MILLISECONDS);
    this.waitingTask.cancel(false);
    String str = Util.SecondsDisplayFormat.format(this.initialDelay / 1000.0D);
    this.logger.verbose("%s suspended with %s seconds left", new Object[] { this.name, str });
    this.isPaused = true;
  }
  
  public void teardown() {
    cancel(true);
    FutureScheduler futureScheduler = this.scheduler;
    if (futureScheduler != null)
      futureScheduler.teardown(); 
    this.scheduler = null;
  }
  
  public final class a implements Runnable {
    public final TimerCycle a;
    
    public a(TimerCycle this$0) {}
    
    public final void run() {
      this.a.logger.verbose("%s fired", new Object[] { TimerCycle.access$000(this.a) });
      this.a.command.run();
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\adjust\sdk\scheduler\TimerCycle.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */