package com.adjust.sdk.scheduler;

import com.adjust.sdk.AdjustFactory;
import java.util.concurrent.Callable;
import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class SingleThreadFutureScheduler implements FutureScheduler {
  private ScheduledThreadPoolExecutor scheduledThreadPoolExecutor;
  
  public SingleThreadFutureScheduler(String paramString, boolean paramBoolean) {
    ScheduledThreadPoolExecutor scheduledThreadPoolExecutor = new ScheduledThreadPoolExecutor(1, new ThreadFactoryWrapper(paramString), new a(paramString));
    this.scheduledThreadPoolExecutor = scheduledThreadPoolExecutor;
    if (!paramBoolean) {
      scheduledThreadPoolExecutor.setKeepAliveTime(10L, TimeUnit.MILLISECONDS);
      this.scheduledThreadPoolExecutor.allowCoreThreadTimeOut(true);
    } 
  }
  
  public ScheduledFuture<?> scheduleFuture(Runnable paramRunnable, long paramLong) {
    return this.scheduledThreadPoolExecutor.schedule(new RunnableWrapper(paramRunnable), paramLong, TimeUnit.MILLISECONDS);
  }
  
  public ScheduledFuture<?> scheduleFutureWithFixedDelay(Runnable paramRunnable, long paramLong1, long paramLong2) {
    return this.scheduledThreadPoolExecutor.scheduleWithFixedDelay(new RunnableWrapper(paramRunnable), paramLong1, paramLong2, TimeUnit.MILLISECONDS);
  }
  
  public <V> ScheduledFuture<V> scheduleFutureWithReturn(Callable<V> paramCallable, long paramLong) {
    return this.scheduledThreadPoolExecutor.schedule((Callable<V>)new b(paramCallable), paramLong, TimeUnit.MILLISECONDS);
  }
  
  public void teardown() {
    this.scheduledThreadPoolExecutor.shutdownNow();
  }
  
  public final class a implements RejectedExecutionHandler {
    public final String a;
    
    public a(SingleThreadFutureScheduler this$0) {}
    
    public final void rejectedExecution(Runnable param1Runnable, ThreadPoolExecutor param1ThreadPoolExecutor) {
      AdjustFactory.getLogger().warn("Runnable [%s] rejected from [%s] ", new Object[] { param1Runnable.toString(), this.a });
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\adjust\sdk\scheduler\SingleThreadFutureScheduler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */