package com.adjust.sdk.scheduler;

public interface ThreadScheduler extends ThreadExecutor {
  void schedule(Runnable paramRunnable, long paramLong);
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\adjust\sdk\scheduler\ThreadScheduler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */