package com.adjust.sdk;

import android.content.Context;
import com.adjust.sdk.network.IActivityPackageSender;
import com.adjust.sdk.network.UtilNetworking;

public class AdjustFactory {
  private static IActivityHandler activityHandler;
  
  private static IAttributionHandler attributionHandler;
  
  private static String baseUrl;
  
  private static UtilNetworking.IConnectionOptions connectionOptions;
  
  private static String gdprUrl;
  
  private static UtilNetworking.IHttpsURLConnectionProvider httpsURLConnectionProvider;
  
  private static BackoffStrategy installSessionBackoffStrategy;
  
  private static ILogger logger;
  
  private static long maxDelayStart = -1L;
  
  private static IPackageHandler packageHandler;
  
  private static BackoffStrategy packageHandlerBackoffStrategy;
  
  private static BackoffStrategy sdkClickBackoffStrategy;
  
  private static ISdkClickHandler sdkClickHandler;
  
  private static long sessionInterval = -1L;
  
  private static String subscriptionUrl;
  
  private static long subsessionInterval = -1L;
  
  private static long timerInterval = -1L;
  
  private static long timerStart = -1L;
  
  private static boolean tryInstallReferrer = true;
  
  private static String byte2HexFormatted(byte[] paramArrayOfbyte) {
    StringBuilder stringBuilder = new StringBuilder(paramArrayOfbyte.length * 2);
    for (byte b = 0; b < paramArrayOfbyte.length; b++) {
      String str2 = Integer.toHexString(paramArrayOfbyte[b]);
      int i = str2.length();
      String str1 = str2;
      if (i == 1) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("0");
        stringBuilder1.append(str2);
        str1 = stringBuilder1.toString();
      } 
      str2 = str1;
      if (i > 2)
        str2 = str1.substring(i - 2, i); 
      stringBuilder.append(str2.toUpperCase());
    } 
    return stringBuilder.toString();
  }
  
  public static void disableSigning() {
    AdjustSigner.disableSigning(getLogger());
  }
  
  public static void enableSigning() {
    AdjustSigner.enableSigning(getLogger());
  }
  
  public static IActivityHandler getActivityHandler(AdjustConfig paramAdjustConfig) {
    IActivityHandler iActivityHandler = activityHandler;
    if (iActivityHandler == null)
      return ActivityHandler.getInstance(paramAdjustConfig); 
    iActivityHandler.init(paramAdjustConfig);
    return activityHandler;
  }
  
  public static IAttributionHandler getAttributionHandler(IActivityHandler paramIActivityHandler, boolean paramBoolean, IActivityPackageSender paramIActivityPackageSender) {
    IAttributionHandler iAttributionHandler = attributionHandler;
    if (iAttributionHandler == null)
      return new AttributionHandler(paramIActivityHandler, paramBoolean, paramIActivityPackageSender); 
    iAttributionHandler.init(paramIActivityHandler, paramBoolean, paramIActivityPackageSender);
    return attributionHandler;
  }
  
  public static String getBaseUrl() {
    return baseUrl;
  }
  
  public static UtilNetworking.IConnectionOptions getConnectionOptions() {
    UtilNetworking.IConnectionOptions iConnectionOptions2 = connectionOptions;
    UtilNetworking.IConnectionOptions iConnectionOptions1 = iConnectionOptions2;
    if (iConnectionOptions2 == null)
      iConnectionOptions1 = UtilNetworking.createDefaultConnectionOptions(); 
    return iConnectionOptions1;
  }
  
  public static String getGdprUrl() {
    return gdprUrl;
  }
  
  public static UtilNetworking.IHttpsURLConnectionProvider getHttpsURLConnectionProvider() {
    UtilNetworking.IHttpsURLConnectionProvider iHttpsURLConnectionProvider2 = httpsURLConnectionProvider;
    UtilNetworking.IHttpsURLConnectionProvider iHttpsURLConnectionProvider1 = iHttpsURLConnectionProvider2;
    if (iHttpsURLConnectionProvider2 == null)
      iHttpsURLConnectionProvider1 = UtilNetworking.createDefaultHttpsURLConnectionProvider(); 
    return iHttpsURLConnectionProvider1;
  }
  
  public static BackoffStrategy getInstallSessionBackoffStrategy() {
    BackoffStrategy backoffStrategy2 = installSessionBackoffStrategy;
    BackoffStrategy backoffStrategy1 = backoffStrategy2;
    if (backoffStrategy2 == null)
      backoffStrategy1 = BackoffStrategy.SHORT_WAIT; 
    return backoffStrategy1;
  }
  
  public static ILogger getLogger() {
    if (logger == null)
      logger = new Logger(); 
    return logger;
  }
  
  public static long getMaxDelayStart() {
    long l2 = maxDelayStart;
    long l1 = l2;
    if (l2 == -1L)
      l1 = 10000L; 
    return l1;
  }
  
  public static IPackageHandler getPackageHandler(IActivityHandler paramIActivityHandler, Context paramContext, boolean paramBoolean, IActivityPackageSender paramIActivityPackageSender) {
    IPackageHandler iPackageHandler = packageHandler;
    if (iPackageHandler == null)
      return new PackageHandler(paramIActivityHandler, paramContext, paramBoolean, paramIActivityPackageSender); 
    iPackageHandler.init(paramIActivityHandler, paramContext, paramBoolean, paramIActivityPackageSender);
    return packageHandler;
  }
  
  public static BackoffStrategy getPackageHandlerBackoffStrategy() {
    BackoffStrategy backoffStrategy2 = packageHandlerBackoffStrategy;
    BackoffStrategy backoffStrategy1 = backoffStrategy2;
    if (backoffStrategy2 == null)
      backoffStrategy1 = BackoffStrategy.LONG_WAIT; 
    return backoffStrategy1;
  }
  
  public static BackoffStrategy getSdkClickBackoffStrategy() {
    BackoffStrategy backoffStrategy2 = sdkClickBackoffStrategy;
    BackoffStrategy backoffStrategy1 = backoffStrategy2;
    if (backoffStrategy2 == null)
      backoffStrategy1 = BackoffStrategy.SHORT_WAIT; 
    return backoffStrategy1;
  }
  
  public static ISdkClickHandler getSdkClickHandler(IActivityHandler paramIActivityHandler, boolean paramBoolean, IActivityPackageSender paramIActivityPackageSender) {
    ISdkClickHandler iSdkClickHandler = sdkClickHandler;
    if (iSdkClickHandler == null)
      return new SdkClickHandler(paramIActivityHandler, paramBoolean, paramIActivityPackageSender); 
    iSdkClickHandler.init(paramIActivityHandler, paramBoolean, paramIActivityPackageSender);
    return sdkClickHandler;
  }
  
  public static long getSessionInterval() {
    long l2 = sessionInterval;
    long l1 = l2;
    if (l2 == -1L)
      l1 = 1800000L; 
    return l1;
  }
  
  public static String getSubscriptionUrl() {
    return subscriptionUrl;
  }
  
  public static long getSubsessionInterval() {
    long l2 = subsessionInterval;
    long l1 = l2;
    if (l2 == -1L)
      l1 = 1000L; 
    return l1;
  }
  
  public static long getTimerInterval() {
    long l2 = timerInterval;
    long l1 = l2;
    if (l2 == -1L)
      l1 = 60000L; 
    return l1;
  }
  
  public static long getTimerStart() {
    long l2 = timerStart;
    long l1 = l2;
    if (l2 == -1L)
      l1 = 60000L; 
    return l1;
  }
  
  public static boolean getTryInstallReferrer() {
    return tryInstallReferrer;
  }
  
  public static void setActivityHandler(IActivityHandler paramIActivityHandler) {
    activityHandler = paramIActivityHandler;
  }
  
  public static void setAttributionHandler(IAttributionHandler paramIAttributionHandler) {
    attributionHandler = paramIAttributionHandler;
  }
  
  public static void setBaseUrl(String paramString) {
    baseUrl = paramString;
  }
  
  public static void setConnectionOptions(UtilNetworking.IConnectionOptions paramIConnectionOptions) {
    connectionOptions = paramIConnectionOptions;
  }
  
  public static void setGdprUrl(String paramString) {
    gdprUrl = paramString;
  }
  
  public static void setHttpsURLConnectionProvider(UtilNetworking.IHttpsURLConnectionProvider paramIHttpsURLConnectionProvider) {
    httpsURLConnectionProvider = paramIHttpsURLConnectionProvider;
  }
  
  public static void setLogger(ILogger paramILogger) {
    logger = paramILogger;
  }
  
  public static void setPackageHandler(IPackageHandler paramIPackageHandler) {
    packageHandler = paramIPackageHandler;
  }
  
  public static void setPackageHandlerBackoffStrategy(BackoffStrategy paramBackoffStrategy) {
    packageHandlerBackoffStrategy = paramBackoffStrategy;
  }
  
  public static void setSdkClickBackoffStrategy(BackoffStrategy paramBackoffStrategy) {
    sdkClickBackoffStrategy = paramBackoffStrategy;
  }
  
  public static void setSdkClickHandler(ISdkClickHandler paramISdkClickHandler) {
    sdkClickHandler = paramISdkClickHandler;
  }
  
  public static void setSessionInterval(long paramLong) {
    sessionInterval = paramLong;
  }
  
  public static void setSubscriptionUrl(String paramString) {
    subscriptionUrl = paramString;
  }
  
  public static void setSubsessionInterval(long paramLong) {
    subsessionInterval = paramLong;
  }
  
  public static void setTimerInterval(long paramLong) {
    timerInterval = paramLong;
  }
  
  public static void setTimerStart(long paramLong) {
    timerStart = paramLong;
  }
  
  public static void setTryInstallReferrer(boolean paramBoolean) {
    tryInstallReferrer = paramBoolean;
  }
  
  public static void teardown(Context paramContext) {
    if (paramContext != null) {
      ActivityHandler.deleteState(paramContext);
      PackageHandler.deleteState(paramContext);
    } 
    packageHandler = null;
    attributionHandler = null;
    activityHandler = null;
    logger = null;
    sdkClickHandler = null;
    timerInterval = -1L;
    timerStart = -1L;
    sessionInterval = -1L;
    subsessionInterval = -1L;
    sdkClickBackoffStrategy = null;
    packageHandlerBackoffStrategy = null;
    maxDelayStart = -1L;
    baseUrl = "https://app.adjust.com";
    gdprUrl = "https://gdpr.adjust.com";
    subscriptionUrl = "https://subscription.adjust.com";
    connectionOptions = null;
    httpsURLConnectionProvider = null;
    tryInstallReferrer = true;
  }
  
  class AdjustFactory {}
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\adjust\sdk\AdjustFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */