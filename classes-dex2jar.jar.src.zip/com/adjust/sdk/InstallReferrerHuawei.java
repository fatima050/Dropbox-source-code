package com.adjust.sdk;

import android.content.Context;
import java.util.concurrent.atomic.AtomicBoolean;

public class InstallReferrerHuawei {
  private static final int COLUMN_INDEX_CLICK_TIME = 1;
  
  private static final int COLUMN_INDEX_INSTALL_TIME = 2;
  
  private static final int COLUMN_INDEX_REFERRER = 0;
  
  private static final int COLUMN_INDEX_TRACK_ID = 4;
  
  private static final String REFERRER_PROVIDER_AUTHORITY = "com.huawei.appmarket.commondata";
  
  private static final String REFERRER_PROVIDER_URI = "content://com.huawei.appmarket.commondata/item/5";
  
  private Context context;
  
  private ILogger logger = AdjustFactory.getLogger();
  
  private final InstallReferrerReadListener referrerCallback;
  
  private final AtomicBoolean shouldTryToRead;
  
  public InstallReferrerHuawei(Context paramContext, InstallReferrerReadListener paramInstallReferrerReadListener) {
    this.context = paramContext;
    this.referrerCallback = paramInstallReferrerReadListener;
    this.shouldTryToRead = new AtomicBoolean(true);
  }
  
  private boolean isValidReferrerHuaweiAds(String paramString) {
    return (paramString == null) ? false : (!paramString.isEmpty());
  }
  
  private boolean isValidReferrerHuaweiAppGallery(String paramString) {
    return (paramString == null) ? false : (!paramString.isEmpty());
  }
  
  public void readReferrer() {
    // Byte code:
    //   0: aload_0
    //   1: getfield shouldTryToRead : Ljava/util/concurrent/atomic/AtomicBoolean;
    //   4: invokevirtual get : ()Z
    //   7: ifne -> 26
    //   10: aload_0
    //   11: getfield logger : Lcom/adjust/sdk/ILogger;
    //   14: ldc 'Should not try to read Install referrer Huawei'
    //   16: iconst_0
    //   17: anewarray java/lang/Object
    //   20: invokeinterface debug : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   25: return
    //   26: aload_0
    //   27: getfield context : Landroid/content/Context;
    //   30: ldc 'com.huawei.appmarket.commondata'
    //   32: invokestatic resolveContentProvider : (Landroid/content/Context;Ljava/lang/String;)Z
    //   35: ifne -> 39
    //   38: return
    //   39: ldc 'content://com.huawei.appmarket.commondata/item/5'
    //   41: invokestatic parse : (Ljava/lang/String;)Landroid/net/Uri;
    //   44: astore #8
    //   46: aload_0
    //   47: getfield context : Landroid/content/Context;
    //   50: invokevirtual getContentResolver : ()Landroid/content/ContentResolver;
    //   53: astore #9
    //   55: aload_0
    //   56: getfield context : Landroid/content/Context;
    //   59: invokevirtual getPackageName : ()Ljava/lang/String;
    //   62: astore #7
    //   64: aconst_null
    //   65: astore #5
    //   67: aconst_null
    //   68: astore #6
    //   70: aload #9
    //   72: aload #8
    //   74: aconst_null
    //   75: aconst_null
    //   76: iconst_1
    //   77: anewarray java/lang/String
    //   80: dup
    //   81: iconst_0
    //   82: aload #7
    //   84: aastore
    //   85: aconst_null
    //   86: invokevirtual query : (Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    //   89: astore #7
    //   91: aload #7
    //   93: ifnull -> 432
    //   96: aload #7
    //   98: astore #6
    //   100: aload #7
    //   102: astore #5
    //   104: aload #7
    //   106: invokeinterface moveToFirst : ()Z
    //   111: ifeq -> 432
    //   114: aload #7
    //   116: astore #6
    //   118: aload #7
    //   120: astore #5
    //   122: aload #7
    //   124: iconst_0
    //   125: invokeinterface getString : (I)Ljava/lang/String;
    //   130: astore #9
    //   132: aload #7
    //   134: astore #6
    //   136: aload #7
    //   138: astore #5
    //   140: aload #7
    //   142: iconst_4
    //   143: invokeinterface getString : (I)Ljava/lang/String;
    //   148: astore #8
    //   150: aload #7
    //   152: astore #6
    //   154: aload #7
    //   156: astore #5
    //   158: aload_0
    //   159: getfield logger : Lcom/adjust/sdk/ILogger;
    //   162: ldc 'InstallReferrerHuawei reads index_referrer[%s] index_track_id[%s]'
    //   164: iconst_2
    //   165: anewarray java/lang/Object
    //   168: dup
    //   169: iconst_0
    //   170: aload #9
    //   172: aastore
    //   173: dup
    //   174: iconst_1
    //   175: aload #8
    //   177: aastore
    //   178: invokeinterface debug : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   183: aload #7
    //   185: astore #6
    //   187: aload #7
    //   189: astore #5
    //   191: aload #7
    //   193: iconst_1
    //   194: invokeinterface getString : (I)Ljava/lang/String;
    //   199: astore #11
    //   201: aload #7
    //   203: astore #6
    //   205: aload #7
    //   207: astore #5
    //   209: aload #7
    //   211: iconst_2
    //   212: invokeinterface getString : (I)Ljava/lang/String;
    //   217: astore #10
    //   219: aload #7
    //   221: astore #6
    //   223: aload #7
    //   225: astore #5
    //   227: aload_0
    //   228: getfield logger : Lcom/adjust/sdk/ILogger;
    //   231: ldc 'InstallReferrerHuawei reads clickTime[%s] installTime[%s]'
    //   233: iconst_2
    //   234: anewarray java/lang/Object
    //   237: dup
    //   238: iconst_0
    //   239: aload #11
    //   241: aastore
    //   242: dup
    //   243: iconst_1
    //   244: aload #10
    //   246: aastore
    //   247: invokeinterface debug : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   252: aload #7
    //   254: astore #6
    //   256: aload #7
    //   258: astore #5
    //   260: aload #11
    //   262: invokestatic parseLong : (Ljava/lang/String;)J
    //   265: lstore_3
    //   266: aload #7
    //   268: astore #6
    //   270: aload #7
    //   272: astore #5
    //   274: aload #10
    //   276: invokestatic parseLong : (Ljava/lang/String;)J
    //   279: lstore_1
    //   280: aload #7
    //   282: astore #6
    //   284: aload #7
    //   286: astore #5
    //   288: aload_0
    //   289: aload #9
    //   291: invokespecial isValidReferrerHuaweiAds : (Ljava/lang/String;)Z
    //   294: ifeq -> 361
    //   297: aload #7
    //   299: astore #6
    //   301: aload #7
    //   303: astore #5
    //   305: new com/adjust/sdk/ReferrerDetails
    //   308: astore #10
    //   310: aload #7
    //   312: astore #6
    //   314: aload #7
    //   316: astore #5
    //   318: aload #10
    //   320: aload #9
    //   322: lload_3
    //   323: lload_1
    //   324: invokespecial <init> : (Ljava/lang/String;JJ)V
    //   327: aload #7
    //   329: astore #6
    //   331: aload #7
    //   333: astore #5
    //   335: aload_0
    //   336: getfield referrerCallback : Lcom/adjust/sdk/InstallReferrerReadListener;
    //   339: aload #10
    //   341: ldc 'huawei_ads'
    //   343: invokeinterface onInstallReferrerRead : (Lcom/adjust/sdk/ReferrerDetails;Ljava/lang/String;)V
    //   348: goto -> 361
    //   351: astore #5
    //   353: goto -> 533
    //   356: astore #7
    //   358: goto -> 485
    //   361: aload #7
    //   363: astore #6
    //   365: aload #7
    //   367: astore #5
    //   369: aload_0
    //   370: aload #8
    //   372: invokespecial isValidReferrerHuaweiAppGallery : (Ljava/lang/String;)Z
    //   375: ifeq -> 473
    //   378: aload #7
    //   380: astore #6
    //   382: aload #7
    //   384: astore #5
    //   386: new com/adjust/sdk/ReferrerDetails
    //   389: astore #9
    //   391: aload #7
    //   393: astore #6
    //   395: aload #7
    //   397: astore #5
    //   399: aload #9
    //   401: aload #8
    //   403: lload_3
    //   404: lload_1
    //   405: invokespecial <init> : (Ljava/lang/String;JJ)V
    //   408: aload #7
    //   410: astore #6
    //   412: aload #7
    //   414: astore #5
    //   416: aload_0
    //   417: getfield referrerCallback : Lcom/adjust/sdk/InstallReferrerReadListener;
    //   420: aload #9
    //   422: ldc 'huawei_app_gallery'
    //   424: invokeinterface onInstallReferrerRead : (Lcom/adjust/sdk/ReferrerDetails;Ljava/lang/String;)V
    //   429: goto -> 473
    //   432: aload #7
    //   434: astore #6
    //   436: aload #7
    //   438: astore #5
    //   440: aload_0
    //   441: getfield logger : Lcom/adjust/sdk/ILogger;
    //   444: ldc 'InstallReferrerHuawei fail to read referrer for package [%s] and content uri [%s]'
    //   446: iconst_2
    //   447: anewarray java/lang/Object
    //   450: dup
    //   451: iconst_0
    //   452: aload_0
    //   453: getfield context : Landroid/content/Context;
    //   456: invokevirtual getPackageName : ()Ljava/lang/String;
    //   459: aastore
    //   460: dup
    //   461: iconst_1
    //   462: aload #8
    //   464: invokevirtual toString : ()Ljava/lang/String;
    //   467: aastore
    //   468: invokeinterface debug : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   473: aload #7
    //   475: ifnull -> 524
    //   478: aload #7
    //   480: astore #5
    //   482: goto -> 517
    //   485: aload #5
    //   487: astore #6
    //   489: aload_0
    //   490: getfield logger : Lcom/adjust/sdk/ILogger;
    //   493: ldc 'InstallReferrerHuawei error [%s]'
    //   495: iconst_1
    //   496: anewarray java/lang/Object
    //   499: dup
    //   500: iconst_0
    //   501: aload #7
    //   503: invokevirtual getMessage : ()Ljava/lang/String;
    //   506: aastore
    //   507: invokeinterface debug : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   512: aload #5
    //   514: ifnull -> 524
    //   517: aload #5
    //   519: invokeinterface close : ()V
    //   524: aload_0
    //   525: getfield shouldTryToRead : Ljava/util/concurrent/atomic/AtomicBoolean;
    //   528: iconst_0
    //   529: invokevirtual set : (Z)V
    //   532: return
    //   533: aload #6
    //   535: ifnull -> 545
    //   538: aload #6
    //   540: invokeinterface close : ()V
    //   545: aload #5
    //   547: athrow
    // Exception table:
    //   from	to	target	type
    //   70	91	356	java/lang/Exception
    //   70	91	351	finally
    //   104	114	356	java/lang/Exception
    //   104	114	351	finally
    //   122	132	356	java/lang/Exception
    //   122	132	351	finally
    //   140	150	356	java/lang/Exception
    //   140	150	351	finally
    //   158	183	356	java/lang/Exception
    //   158	183	351	finally
    //   191	201	356	java/lang/Exception
    //   191	201	351	finally
    //   209	219	356	java/lang/Exception
    //   209	219	351	finally
    //   227	252	356	java/lang/Exception
    //   227	252	351	finally
    //   260	266	356	java/lang/Exception
    //   260	266	351	finally
    //   274	280	356	java/lang/Exception
    //   274	280	351	finally
    //   288	297	356	java/lang/Exception
    //   288	297	351	finally
    //   305	310	356	java/lang/Exception
    //   305	310	351	finally
    //   318	327	356	java/lang/Exception
    //   318	327	351	finally
    //   335	348	356	java/lang/Exception
    //   335	348	351	finally
    //   369	378	356	java/lang/Exception
    //   369	378	351	finally
    //   386	391	356	java/lang/Exception
    //   386	391	351	finally
    //   399	408	356	java/lang/Exception
    //   399	408	351	finally
    //   416	429	356	java/lang/Exception
    //   416	429	351	finally
    //   440	473	356	java/lang/Exception
    //   440	473	351	finally
    //   489	512	351	finally
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\adjust\sdk\InstallReferrerHuawei.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */