package com.adjust.sdk.network;

import android.net.Uri;
import com.adjust.sdk.ActivityKind;
import com.adjust.sdk.ActivityPackage;
import com.adjust.sdk.AdjustAttribution;
import com.adjust.sdk.AdjustFactory;
import com.adjust.sdk.ILogger;
import com.adjust.sdk.ResponseData;
import com.adjust.sdk.TrackingState;
import com.adjust.sdk.Util;
import com.adjust.sdk.scheduler.SingleThreadCachedScheduler;
import com.adjust.sdk.scheduler.ThreadExecutor;
import dbxyzptlk.WK.b;
import java.io.DataOutputStream;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import javax.net.ssl.HttpsURLConnection;
import org.json.JSONException;

public class ActivityPackageSender implements IActivityPackageSender {
  private String basePath;
  
  private String clientSdk;
  
  private UtilNetworking.IConnectionOptions connectionOptions;
  
  private ThreadExecutor executor;
  
  private String gdprPath;
  
  private UtilNetworking.IHttpsURLConnectionProvider httpsURLConnectionProvider;
  
  private ILogger logger;
  
  private String subscriptionPath;
  
  private UrlStrategy urlStrategy;
  
  public ActivityPackageSender(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5) {
    this.basePath = paramString2;
    this.gdprPath = paramString3;
    this.subscriptionPath = paramString4;
    this.clientSdk = paramString5;
    this.logger = AdjustFactory.getLogger();
    this.executor = (ThreadExecutor)new SingleThreadCachedScheduler("ActivityPackageSender");
    this.urlStrategy = new UrlStrategy(AdjustFactory.getBaseUrl(), AdjustFactory.getGdprUrl(), AdjustFactory.getSubscriptionUrl(), paramString1);
    this.httpsURLConnectionProvider = AdjustFactory.getHttpsURLConnectionProvider();
    this.connectionOptions = AdjustFactory.getConnectionOptions();
  }
  
  private String buildAndExtractAuthorizationHeader(Map<String, String> paramMap, ActivityKind paramActivityKind) {
    String str1 = paramActivityKind.toString();
    String str2 = extractSecretId(paramMap);
    String str3 = extractHeadersId(paramMap);
    str3 = buildAuthorizationHeaderV2(extractSignature(paramMap), str2, str3, extractAlgorithm(paramMap), extractNativeVersion(paramMap));
    return (str3 != null) ? str3 : buildAuthorizationHeaderV1(paramMap, extractAppSecret(paramMap), str2, str1);
  }
  
  private String buildAuthorizationHeaderV1(Map<String, String> paramMap, String paramString1, String paramString2, String paramString3) {
    if (paramString1 == null || paramString1.length() == 0)
      return null; 
    Map<String, String> map = getSignature(paramMap, paramString3, paramString1);
    String str1 = Util.sha256(map.get("clear_signature"));
    String str2 = map.get("fields");
    str1 = Util.formatString("Signature %s,%s,%s,%s", new Object[] { Util.formatString("secret_id=\"%s\"", new Object[] { paramString2 }), Util.formatString("signature=\"%s\"", new Object[] { str1 }), Util.formatString("algorithm=\"%s\"", new Object[] { "sha256" }), Util.formatString("headers=\"%s\"", new Object[] { str2 }) });
    this.logger.verbose("authorizationHeader: %s", new Object[] { str1 });
    return str1;
  }
  
  private String buildAuthorizationHeaderV2(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5) {
    if (paramString2 == null || paramString1 == null || paramString3 == null)
      return null; 
    paramString1 = Util.formatString("signature=\"%s\"", new Object[] { paramString1 });
    paramString2 = Util.formatString("secret_id=\"%s\"", new Object[] { paramString2 });
    paramString3 = Util.formatString("headers_id=\"%s\"", new Object[] { paramString3 });
    if (paramString4 == null)
      paramString4 = "adj1"; 
    paramString4 = Util.formatString("algorithm=\"%s\"", new Object[] { paramString4 });
    if (paramString5 == null)
      paramString5 = ""; 
    paramString1 = Util.formatString("Signature %s,%s,%s,%s,%s", new Object[] { paramString1, paramString2, paramString4, paramString3, Util.formatString("native_version=\"%s\"", new Object[] { paramString5 }) });
    this.logger.verbose("authorizationHeader: %s", new Object[] { paramString1 });
    return paramString1;
  }
  
  private DataOutputStream configConnectionForGET(HttpsURLConnection paramHttpsURLConnection) {
    paramHttpsURLConnection.setRequestMethod("GET");
    return null;
  }
  
  private DataOutputStream configConnectionForPOST(HttpsURLConnection paramHttpsURLConnection, Map<String, String> paramMap1, Map<String, String> paramMap2) {
    paramHttpsURLConnection.setRequestMethod("POST");
    paramHttpsURLConnection.setUseCaches(false);
    paramHttpsURLConnection.setDoInput(true);
    paramHttpsURLConnection.setDoOutput(true);
    String str = generatePOSTBodyString(paramMap1, paramMap2);
    if (str == null)
      return null; 
    DataOutputStream dataOutputStream = new DataOutputStream(paramHttpsURLConnection.getOutputStream());
    dataOutputStream.writeBytes(str);
    return dataOutputStream;
  }
  
  private String errorMessage(Throwable paramThrowable, String paramString, ActivityPackage paramActivityPackage) {
    return Util.formatString("%s. (%s)", new Object[] { paramActivityPackage.getFailureMessage(), Util.getReasonString(paramString, paramThrowable) });
  }
  
  private static String extractAlgorithm(Map<String, String> paramMap) {
    return paramMap.remove("algorithm");
  }
  
  private static String extractAppSecret(Map<String, String> paramMap) {
    return paramMap.remove("app_secret");
  }
  
  private static void extractEventCallbackId(Map<String, String> paramMap) {
    paramMap.remove("event_callback_id");
  }
  
  private static String extractHeadersId(Map<String, String> paramMap) {
    return paramMap.remove("headers_id");
  }
  
  private static String extractNativeVersion(Map<String, String> paramMap) {
    return paramMap.remove("native_version");
  }
  
  private static String extractSecretId(Map<String, String> paramMap) {
    return paramMap.remove("secret_id");
  }
  
  private static String extractSignature(Map<String, String> paramMap) {
    return paramMap.remove("signature");
  }
  
  private String generatePOSTBodyString(Map<String, String> paramMap1, Map<String, String> paramMap2) {
    if (paramMap1.isEmpty())
      return null; 
    StringBuilder stringBuilder = new StringBuilder();
    injectParametersToPOSTStringBuilder(paramMap1, stringBuilder);
    injectParametersToPOSTStringBuilder(paramMap2, stringBuilder);
    if (stringBuilder.length() > 0 && stringBuilder.charAt(stringBuilder.length() - 1) == '&')
      stringBuilder.deleteCharAt(stringBuilder.length() - 1); 
    return stringBuilder.toString();
  }
  
  private String generateUrlStringForGET(ActivityKind paramActivityKind, String paramString, Map<String, String> paramMap1, Map<String, String> paramMap2) {
    URL uRL = new URL(urlWithExtraPathByActivityKind(paramActivityKind, this.urlStrategy.targetUrlByActivityKind(paramActivityKind)));
    Uri.Builder builder = new Uri.Builder();
    builder.scheme(uRL.getProtocol());
    builder.encodedAuthority(uRL.getAuthority());
    builder.path(uRL.getPath());
    builder.appendPath(paramString);
    this.logger.debug("Making request to url: %s", new Object[] { builder.toString() });
    for (Map.Entry<String, String> entry : paramMap1.entrySet())
      builder.appendQueryParameter((String)entry.getKey(), (String)entry.getValue()); 
    if (paramMap2 != null)
      for (Map.Entry<String, String> entry : paramMap2.entrySet())
        builder.appendQueryParameter((String)entry.getKey(), (String)entry.getValue());  
    return builder.build().toString();
  }
  
  private String generateUrlStringForPOST(ActivityKind paramActivityKind, String paramString) {
    String str = Util.formatString("%s%s", new Object[] { urlWithExtraPathByActivityKind(paramActivityKind, this.urlStrategy.targetUrlByActivityKind(paramActivityKind)), paramString });
    this.logger.debug("Making request to url : %s", new Object[] { str });
    return str;
  }
  
  private Map<String, String> getSignature(Map<String, String> paramMap, String paramString1, String paramString2) {
    String str3 = paramMap.get("created_at");
    String str4 = getValidIdentifier(paramMap);
    String str2 = paramMap.get(str4);
    String str5 = paramMap.get("source");
    String str1 = paramMap.get("payload");
    HashMap<Object, Object> hashMap2 = new HashMap<>();
    hashMap2.put("app_secret", paramString2);
    hashMap2.put("created_at", str3);
    hashMap2.put("activity_kind", paramString1);
    hashMap2.put(str4, str2);
    if (str5 != null)
      hashMap2.put("source", str5); 
    if (str1 != null)
      hashMap2.put("payload", str1); 
    Iterator<Map.Entry> iterator = hashMap2.entrySet().iterator();
    paramString1 = "";
    str1 = "";
    while (iterator.hasNext()) {
      Map.Entry entry = iterator.next();
      if (entry.getValue() != null) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(paramString1);
        stringBuilder.append((String)entry.getKey());
        stringBuilder.append(" ");
        paramString1 = stringBuilder.toString();
        stringBuilder = new StringBuilder();
        stringBuilder.append(str1);
        stringBuilder.append((String)entry.getValue());
        str1 = stringBuilder.toString();
      } 
    } 
    paramString1 = paramString1.substring(0, paramString1.length() - 1);
    HashMap<Object, Object> hashMap1 = new HashMap<>();
    hashMap1.put("clear_signature", str1);
    hashMap1.put("fields", paramString1);
    return (Map)hashMap1;
  }
  
  private String getValidIdentifier(Map<String, String> paramMap) {
    return (paramMap.get("gps_adid") != null) ? "gps_adid" : ((paramMap.get("fire_adid") != null) ? "fire_adid" : ((paramMap.get("android_id") != null) ? "android_id" : ((paramMap.get("android_uuid") != null) ? "android_uuid" : null)));
  }
  
  private void injectParametersToPOSTStringBuilder(Map<String, String> paramMap, StringBuilder paramStringBuilder) {
    if (paramMap != null && !paramMap.isEmpty())
      for (Map.Entry<String, String> entry : paramMap.entrySet()) {
        String str2 = URLEncoder.encode((String)entry.getKey(), "UTF-8");
        String str1 = (String)entry.getValue();
        if (str1 != null) {
          str1 = URLEncoder.encode(str1, "UTF-8");
        } else {
          str1 = "";
        } 
        paramStringBuilder.append(str2);
        paramStringBuilder.append("=");
        paramStringBuilder.append(str1);
        paramStringBuilder.append("&");
      }  
  }
  
  private void localError(Throwable paramThrowable, String paramString, ResponseData paramResponseData) {
    String str = errorMessage(paramThrowable, paramString, paramResponseData.activityPackage);
    this.logger.error(str, new Object[0]);
    paramResponseData.message = str;
    paramResponseData.willRetry = false;
  }
  
  private void parseResponse(ResponseData paramResponseData, String paramString) {
    String str1;
    if (paramString.length() == 0) {
      this.logger.error("Empty response string", new Object[0]);
      return;
    } 
    try {
      b b2 = new b();
      this(paramString);
      b b1 = b2;
    } catch (JSONException jSONException) {
      str1 = errorMessage((Throwable)jSONException, "Failed to parse JSON response", paramResponseData.activityPackage);
      this.logger.error(str1, new Object[0]);
      str1 = null;
    } 
    if (str1 == null)
      return; 
    paramResponseData.jsonResponse = (b)str1;
    paramResponseData.message = UtilNetworking.extractJsonString((b)str1, "message");
    paramResponseData.adid = UtilNetworking.extractJsonString((b)str1, "adid");
    paramResponseData.timestamp = UtilNetworking.extractJsonString((b)str1, "timestamp");
    String str2 = UtilNetworking.extractJsonString((b)str1, "tracking_state");
    if (str2 != null && str2.equals("opted_out"))
      paramResponseData.trackingState = TrackingState.OPTED_OUT; 
    paramResponseData.askIn = UtilNetworking.extractJsonLong((b)str1, "ask_in");
    paramResponseData.retryIn = UtilNetworking.extractJsonLong((b)str1, "retry_in");
    paramResponseData.continueIn = UtilNetworking.extractJsonLong((b)str1, "continue_in");
    paramResponseData.attribution = AdjustAttribution.fromJson(str1.z("attribution"), paramResponseData.adid, Util.getSdkPrefixPlatform(this.clientSdk));
  }
  
  private void remoteError(Throwable paramThrowable, String paramString, ResponseData paramResponseData) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(errorMessage(paramThrowable, paramString, paramResponseData.activityPackage));
    stringBuilder.append(" Will retry later");
    String str = stringBuilder.toString();
    this.logger.error(str, new Object[0]);
    paramResponseData.message = str;
    paramResponseData.willRetry = true;
  }
  
  private boolean shouldRetryToSend(ResponseData paramResponseData) {
    if (!paramResponseData.willRetry) {
      this.logger.debug("Will not retry with current url strategy", new Object[0]);
      this.urlStrategy.resetAfterSuccess();
      return false;
    } 
    if (this.urlStrategy.shouldRetryAfterFailure(paramResponseData.activityKind)) {
      this.logger.error("Failed with current url strategy, but it will retry with new", new Object[0]);
      return true;
    } 
    this.logger.error("Failed with current url strategy and it will not retry", new Object[0]);
    return false;
  }
  
  private void tryToGetResponse(ResponseData paramResponseData) {
    // Byte code:
    //   0: aconst_null
    //   1: astore #18
    //   3: aconst_null
    //   4: astore #13
    //   6: aconst_null
    //   7: astore #17
    //   9: aconst_null
    //   10: astore #16
    //   12: aconst_null
    //   13: astore #15
    //   15: aconst_null
    //   16: astore #14
    //   18: aconst_null
    //   19: astore #19
    //   21: aload #19
    //   23: astore #6
    //   25: aload #18
    //   27: astore #7
    //   29: aload #13
    //   31: astore #11
    //   33: aload #17
    //   35: astore #9
    //   37: aload #16
    //   39: astore #8
    //   41: aload #15
    //   43: astore #10
    //   45: aload #14
    //   47: astore #12
    //   49: aload_1
    //   50: getfield activityPackage : Lcom/adjust/sdk/ActivityPackage;
    //   53: astore #23
    //   55: aload #19
    //   57: astore #6
    //   59: aload #18
    //   61: astore #7
    //   63: aload #13
    //   65: astore #11
    //   67: aload #17
    //   69: astore #9
    //   71: aload #16
    //   73: astore #8
    //   75: aload #15
    //   77: astore #10
    //   79: aload #14
    //   81: astore #12
    //   83: new java/util/HashMap
    //   86: astore #22
    //   88: aload #19
    //   90: astore #6
    //   92: aload #18
    //   94: astore #7
    //   96: aload #13
    //   98: astore #11
    //   100: aload #17
    //   102: astore #9
    //   104: aload #16
    //   106: astore #8
    //   108: aload #15
    //   110: astore #10
    //   112: aload #14
    //   114: astore #12
    //   116: aload #22
    //   118: aload #23
    //   120: invokevirtual getParameters : ()Ljava/util/Map;
    //   123: invokespecial <init> : (Ljava/util/Map;)V
    //   126: aload #19
    //   128: astore #6
    //   130: aload #18
    //   132: astore #7
    //   134: aload #13
    //   136: astore #11
    //   138: aload #17
    //   140: astore #9
    //   142: aload #16
    //   144: astore #8
    //   146: aload #15
    //   148: astore #10
    //   150: aload #14
    //   152: astore #12
    //   154: aload_1
    //   155: getfield sendingParameters : Ljava/util/Map;
    //   158: astore #20
    //   160: aload #19
    //   162: astore #6
    //   164: aload #18
    //   166: astore #7
    //   168: aload #13
    //   170: astore #11
    //   172: aload #17
    //   174: astore #9
    //   176: aload #16
    //   178: astore #8
    //   180: aload #15
    //   182: astore #10
    //   184: aload #14
    //   186: astore #12
    //   188: aload_0
    //   189: aload #22
    //   191: aload #23
    //   193: invokevirtual getActivityKind : ()Lcom/adjust/sdk/ActivityKind;
    //   196: invokespecial buildAndExtractAuthorizationHeader : (Ljava/util/Map;Lcom/adjust/sdk/ActivityKind;)Ljava/lang/String;
    //   199: astore #21
    //   201: aload #19
    //   203: astore #6
    //   205: aload #18
    //   207: astore #7
    //   209: aload #13
    //   211: astore #11
    //   213: aload #17
    //   215: astore #9
    //   217: aload #16
    //   219: astore #8
    //   221: aload #15
    //   223: astore #10
    //   225: aload #14
    //   227: astore #12
    //   229: aload_1
    //   230: getfield activityPackage : Lcom/adjust/sdk/ActivityPackage;
    //   233: invokevirtual getActivityKind : ()Lcom/adjust/sdk/ActivityKind;
    //   236: astore #5
    //   238: aload #19
    //   240: astore #6
    //   242: aload #18
    //   244: astore #7
    //   246: aload #13
    //   248: astore #11
    //   250: aload #17
    //   252: astore #9
    //   254: aload #16
    //   256: astore #8
    //   258: aload #15
    //   260: astore #10
    //   262: aload #14
    //   264: astore #12
    //   266: getstatic com/adjust/sdk/ActivityKind.ATTRIBUTION : Lcom/adjust/sdk/ActivityKind;
    //   269: astore #24
    //   271: iconst_1
    //   272: istore #4
    //   274: aload #5
    //   276: aload #24
    //   278: if_acmpne -> 286
    //   281: iconst_1
    //   282: istore_2
    //   283: goto -> 288
    //   286: iconst_0
    //   287: istore_2
    //   288: iload_2
    //   289: ifeq -> 411
    //   292: aload #19
    //   294: astore #6
    //   296: aload #18
    //   298: astore #7
    //   300: aload #13
    //   302: astore #11
    //   304: aload #17
    //   306: astore #9
    //   308: aload #16
    //   310: astore #8
    //   312: aload #15
    //   314: astore #10
    //   316: aload #14
    //   318: astore #12
    //   320: aload #22
    //   322: invokestatic extractEventCallbackId : (Ljava/util/Map;)V
    //   325: aload #19
    //   327: astore #6
    //   329: aload #18
    //   331: astore #7
    //   333: aload #13
    //   335: astore #11
    //   337: aload #17
    //   339: astore #9
    //   341: aload #16
    //   343: astore #8
    //   345: aload #15
    //   347: astore #10
    //   349: aload #14
    //   351: astore #12
    //   353: aload_0
    //   354: aload #23
    //   356: invokevirtual getActivityKind : ()Lcom/adjust/sdk/ActivityKind;
    //   359: aload #23
    //   361: invokevirtual getPath : ()Ljava/lang/String;
    //   364: aload #22
    //   366: aload #20
    //   368: invokespecial generateUrlStringForGET : (Lcom/adjust/sdk/ActivityKind;Ljava/lang/String;Ljava/util/Map;Ljava/util/Map;)Ljava/lang/String;
    //   371: astore #5
    //   373: goto -> 455
    //   376: astore #7
    //   378: goto -> 1123
    //   381: astore #6
    //   383: goto -> 1193
    //   386: astore #6
    //   388: goto -> 1258
    //   391: astore #6
    //   393: goto -> 1323
    //   396: astore #6
    //   398: goto -> 1388
    //   401: astore #6
    //   403: goto -> 1453
    //   406: astore #6
    //   408: goto -> 1518
    //   411: aload #19
    //   413: astore #6
    //   415: aload #18
    //   417: astore #7
    //   419: aload #13
    //   421: astore #11
    //   423: aload #17
    //   425: astore #9
    //   427: aload #16
    //   429: astore #8
    //   431: aload #15
    //   433: astore #10
    //   435: aload #14
    //   437: astore #12
    //   439: aload_0
    //   440: aload #23
    //   442: invokevirtual getActivityKind : ()Lcom/adjust/sdk/ActivityKind;
    //   445: aload #23
    //   447: invokevirtual getPath : ()Ljava/lang/String;
    //   450: invokespecial generateUrlStringForPOST : (Lcom/adjust/sdk/ActivityKind;Ljava/lang/String;)Ljava/lang/String;
    //   453: astore #5
    //   455: aload #19
    //   457: astore #6
    //   459: aload #18
    //   461: astore #7
    //   463: aload #13
    //   465: astore #11
    //   467: aload #17
    //   469: astore #9
    //   471: aload #16
    //   473: astore #8
    //   475: aload #15
    //   477: astore #10
    //   479: aload #14
    //   481: astore #12
    //   483: new java/net/URL
    //   486: astore #24
    //   488: aload #19
    //   490: astore #6
    //   492: aload #18
    //   494: astore #7
    //   496: aload #13
    //   498: astore #11
    //   500: aload #17
    //   502: astore #9
    //   504: aload #16
    //   506: astore #8
    //   508: aload #15
    //   510: astore #10
    //   512: aload #14
    //   514: astore #12
    //   516: aload #24
    //   518: aload #5
    //   520: invokespecial <init> : (Ljava/lang/String;)V
    //   523: aload #19
    //   525: astore #6
    //   527: aload #18
    //   529: astore #7
    //   531: aload #13
    //   533: astore #11
    //   535: aload #17
    //   537: astore #9
    //   539: aload #16
    //   541: astore #8
    //   543: aload #15
    //   545: astore #10
    //   547: aload #14
    //   549: astore #12
    //   551: aload_0
    //   552: getfield httpsURLConnectionProvider : Lcom/adjust/sdk/network/UtilNetworking$IHttpsURLConnectionProvider;
    //   555: aload #24
    //   557: invokeinterface generateHttpsURLConnection : (Ljava/net/URL;)Ljavax/net/ssl/HttpsURLConnection;
    //   562: astore #24
    //   564: aload #19
    //   566: astore #6
    //   568: aload #18
    //   570: astore #7
    //   572: aload #13
    //   574: astore #11
    //   576: aload #17
    //   578: astore #9
    //   580: aload #16
    //   582: astore #8
    //   584: aload #15
    //   586: astore #10
    //   588: aload #14
    //   590: astore #12
    //   592: aload_0
    //   593: getfield connectionOptions : Lcom/adjust/sdk/network/UtilNetworking$IConnectionOptions;
    //   596: aload #24
    //   598: aload #23
    //   600: invokevirtual getClientSdk : ()Ljava/lang/String;
    //   603: invokeinterface applyConnectionOptions : (Ljavax/net/ssl/HttpsURLConnection;Ljava/lang/String;)V
    //   608: aload #21
    //   610: ifnull -> 651
    //   613: aload #19
    //   615: astore #6
    //   617: aload #18
    //   619: astore #7
    //   621: aload #13
    //   623: astore #11
    //   625: aload #17
    //   627: astore #9
    //   629: aload #16
    //   631: astore #8
    //   633: aload #15
    //   635: astore #10
    //   637: aload #14
    //   639: astore #12
    //   641: aload #24
    //   643: ldc_w 'Authorization'
    //   646: aload #21
    //   648: invokevirtual setRequestProperty : (Ljava/lang/String;Ljava/lang/String;)V
    //   651: iload_2
    //   652: ifeq -> 694
    //   655: aload #19
    //   657: astore #6
    //   659: aload #18
    //   661: astore #7
    //   663: aload #13
    //   665: astore #11
    //   667: aload #17
    //   669: astore #9
    //   671: aload #16
    //   673: astore #8
    //   675: aload #15
    //   677: astore #10
    //   679: aload #14
    //   681: astore #12
    //   683: aload_0
    //   684: aload #24
    //   686: invokespecial configConnectionForGET : (Ljavax/net/ssl/HttpsURLConnection;)Ljava/io/DataOutputStream;
    //   689: astore #5
    //   691: goto -> 767
    //   694: aload #19
    //   696: astore #6
    //   698: aload #18
    //   700: astore #7
    //   702: aload #13
    //   704: astore #11
    //   706: aload #17
    //   708: astore #9
    //   710: aload #16
    //   712: astore #8
    //   714: aload #15
    //   716: astore #10
    //   718: aload #14
    //   720: astore #12
    //   722: aload #22
    //   724: invokestatic extractEventCallbackId : (Ljava/util/Map;)V
    //   727: aload #19
    //   729: astore #6
    //   731: aload #18
    //   733: astore #7
    //   735: aload #13
    //   737: astore #11
    //   739: aload #17
    //   741: astore #9
    //   743: aload #16
    //   745: astore #8
    //   747: aload #15
    //   749: astore #10
    //   751: aload #14
    //   753: astore #12
    //   755: aload_0
    //   756: aload #24
    //   758: aload #22
    //   760: aload #20
    //   762: invokespecial configConnectionForPOST : (Ljavax/net/ssl/HttpsURLConnection;Ljava/util/Map;Ljava/util/Map;)Ljava/io/DataOutputStream;
    //   765: astore #5
    //   767: aload #5
    //   769: astore #6
    //   771: aload #5
    //   773: astore #7
    //   775: aload #5
    //   777: astore #11
    //   779: aload #5
    //   781: astore #9
    //   783: aload #5
    //   785: astore #8
    //   787: aload #5
    //   789: astore #10
    //   791: aload #5
    //   793: astore #12
    //   795: aload_0
    //   796: aload #24
    //   798: aload_1
    //   799: invokevirtual readConnectionResponse : (Ljavax/net/ssl/HttpsURLConnection;Lcom/adjust/sdk/ResponseData;)Ljava/lang/Integer;
    //   802: astore #13
    //   804: aload #5
    //   806: astore #6
    //   808: aload #5
    //   810: astore #7
    //   812: aload #5
    //   814: astore #11
    //   816: aload #5
    //   818: astore #9
    //   820: aload #5
    //   822: astore #8
    //   824: aload #5
    //   826: astore #10
    //   828: aload #5
    //   830: astore #12
    //   832: aload_1
    //   833: getfield jsonResponse : Ldbxyzptlk/WK/b;
    //   836: ifnull -> 923
    //   839: aload #5
    //   841: astore #6
    //   843: aload #5
    //   845: astore #7
    //   847: aload #5
    //   849: astore #11
    //   851: aload #5
    //   853: astore #9
    //   855: aload #5
    //   857: astore #8
    //   859: aload #5
    //   861: astore #10
    //   863: aload #5
    //   865: astore #12
    //   867: aload_1
    //   868: getfield retryIn : Ljava/lang/Long;
    //   871: ifnonnull -> 923
    //   874: aload #13
    //   876: ifnull -> 923
    //   879: aload #5
    //   881: astore #6
    //   883: aload #5
    //   885: astore #7
    //   887: aload #5
    //   889: astore #11
    //   891: aload #5
    //   893: astore #9
    //   895: aload #5
    //   897: astore #8
    //   899: aload #5
    //   901: astore #10
    //   903: aload #5
    //   905: astore #12
    //   907: aload #13
    //   909: invokevirtual intValue : ()I
    //   912: sipush #200
    //   915: if_icmpne -> 923
    //   918: iconst_1
    //   919: istore_3
    //   920: goto -> 925
    //   923: iconst_0
    //   924: istore_3
    //   925: aload #5
    //   927: astore #6
    //   929: aload #5
    //   931: astore #7
    //   933: aload #5
    //   935: astore #11
    //   937: aload #5
    //   939: astore #9
    //   941: aload #5
    //   943: astore #8
    //   945: aload #5
    //   947: astore #10
    //   949: aload #5
    //   951: astore #12
    //   953: aload_1
    //   954: iload_3
    //   955: putfield success : Z
    //   958: aload #5
    //   960: astore #6
    //   962: aload #5
    //   964: astore #7
    //   966: aload #5
    //   968: astore #11
    //   970: aload #5
    //   972: astore #9
    //   974: aload #5
    //   976: astore #8
    //   978: aload #5
    //   980: astore #10
    //   982: aload #5
    //   984: astore #12
    //   986: iload #4
    //   988: istore_3
    //   989: aload_1
    //   990: getfield jsonResponse : Ldbxyzptlk/WK/b;
    //   993: ifnull -> 1039
    //   996: aload #5
    //   998: astore #6
    //   1000: aload #5
    //   1002: astore #7
    //   1004: aload #5
    //   1006: astore #11
    //   1008: aload #5
    //   1010: astore #9
    //   1012: aload #5
    //   1014: astore #8
    //   1016: aload #5
    //   1018: astore #10
    //   1020: aload #5
    //   1022: astore #12
    //   1024: aload_1
    //   1025: getfield retryIn : Ljava/lang/Long;
    //   1028: ifnull -> 1037
    //   1031: iload #4
    //   1033: istore_3
    //   1034: goto -> 1039
    //   1037: iconst_0
    //   1038: istore_3
    //   1039: aload #5
    //   1041: astore #6
    //   1043: aload #5
    //   1045: astore #7
    //   1047: aload #5
    //   1049: astore #11
    //   1051: aload #5
    //   1053: astore #9
    //   1055: aload #5
    //   1057: astore #8
    //   1059: aload #5
    //   1061: astore #10
    //   1063: aload #5
    //   1065: astore #12
    //   1067: aload_1
    //   1068: iload_3
    //   1069: putfield willRetry : Z
    //   1072: aload #5
    //   1074: ifnull -> 1580
    //   1077: aload #5
    //   1079: invokevirtual flush : ()V
    //   1082: aload #5
    //   1084: invokevirtual close : ()V
    //   1087: goto -> 1580
    //   1090: astore #5
    //   1092: aload_0
    //   1093: aload #5
    //   1095: ldc_w 'Flushing and closing connection output stream'
    //   1098: aload_1
    //   1099: getfield activityPackage : Lcom/adjust/sdk/ActivityPackage;
    //   1102: invokespecial errorMessage : (Ljava/lang/Throwable;Ljava/lang/String;Lcom/adjust/sdk/ActivityPackage;)Ljava/lang/String;
    //   1105: astore_1
    //   1106: aload_0
    //   1107: getfield logger : Lcom/adjust/sdk/ILogger;
    //   1110: aload_1
    //   1111: iconst_0
    //   1112: anewarray java/lang/Object
    //   1115: invokeinterface error : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   1120: goto -> 1580
    //   1123: aload #6
    //   1125: astore #5
    //   1127: aload_0
    //   1128: aload #7
    //   1130: ldc_w 'Sending SDK package'
    //   1133: aload_1
    //   1134: invokespecial localError : (Ljava/lang/Throwable;Ljava/lang/String;Lcom/adjust/sdk/ResponseData;)V
    //   1137: aload #6
    //   1139: ifnull -> 1580
    //   1142: aload #6
    //   1144: invokevirtual flush : ()V
    //   1147: aload #6
    //   1149: invokevirtual close : ()V
    //   1152: goto -> 1580
    //   1155: astore #5
    //   1157: aload_0
    //   1158: aload #5
    //   1160: ldc_w 'Flushing and closing connection output stream'
    //   1163: aload_1
    //   1164: getfield activityPackage : Lcom/adjust/sdk/ActivityPackage;
    //   1167: invokespecial errorMessage : (Ljava/lang/Throwable;Ljava/lang/String;Lcom/adjust/sdk/ActivityPackage;)Ljava/lang/String;
    //   1170: astore_1
    //   1171: aload_0
    //   1172: getfield logger : Lcom/adjust/sdk/ILogger;
    //   1175: aload_1
    //   1176: iconst_0
    //   1177: anewarray java/lang/Object
    //   1180: invokeinterface error : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   1185: goto -> 1580
    //   1188: astore #6
    //   1190: goto -> 1581
    //   1193: aload #7
    //   1195: astore #5
    //   1197: aload_0
    //   1198: aload #6
    //   1200: ldc_w 'Request failed'
    //   1203: aload_1
    //   1204: invokespecial remoteError : (Ljava/lang/Throwable;Ljava/lang/String;Lcom/adjust/sdk/ResponseData;)V
    //   1207: aload #7
    //   1209: ifnull -> 1580
    //   1212: aload #7
    //   1214: invokevirtual flush : ()V
    //   1217: aload #7
    //   1219: invokevirtual close : ()V
    //   1222: goto -> 1580
    //   1225: astore #5
    //   1227: aload_0
    //   1228: aload #5
    //   1230: ldc_w 'Flushing and closing connection output stream'
    //   1233: aload_1
    //   1234: getfield activityPackage : Lcom/adjust/sdk/ActivityPackage;
    //   1237: invokespecial errorMessage : (Ljava/lang/Throwable;Ljava/lang/String;Lcom/adjust/sdk/ActivityPackage;)Ljava/lang/String;
    //   1240: astore_1
    //   1241: aload_0
    //   1242: getfield logger : Lcom/adjust/sdk/ILogger;
    //   1245: aload_1
    //   1246: iconst_0
    //   1247: anewarray java/lang/Object
    //   1250: invokeinterface error : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   1255: goto -> 1580
    //   1258: aload #11
    //   1260: astore #5
    //   1262: aload_0
    //   1263: aload #6
    //   1265: ldc_w 'Certificate failed'
    //   1268: aload_1
    //   1269: invokespecial remoteError : (Ljava/lang/Throwable;Ljava/lang/String;Lcom/adjust/sdk/ResponseData;)V
    //   1272: aload #11
    //   1274: ifnull -> 1580
    //   1277: aload #11
    //   1279: invokevirtual flush : ()V
    //   1282: aload #11
    //   1284: invokevirtual close : ()V
    //   1287: goto -> 1580
    //   1290: astore #5
    //   1292: aload_0
    //   1293: aload #5
    //   1295: ldc_w 'Flushing and closing connection output stream'
    //   1298: aload_1
    //   1299: getfield activityPackage : Lcom/adjust/sdk/ActivityPackage;
    //   1302: invokespecial errorMessage : (Ljava/lang/Throwable;Ljava/lang/String;Lcom/adjust/sdk/ActivityPackage;)Ljava/lang/String;
    //   1305: astore_1
    //   1306: aload_0
    //   1307: getfield logger : Lcom/adjust/sdk/ILogger;
    //   1310: aload_1
    //   1311: iconst_0
    //   1312: anewarray java/lang/Object
    //   1315: invokeinterface error : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   1320: goto -> 1580
    //   1323: aload #9
    //   1325: astore #5
    //   1327: aload_0
    //   1328: aload #6
    //   1330: ldc_w 'Request timed out'
    //   1333: aload_1
    //   1334: invokespecial remoteError : (Ljava/lang/Throwable;Ljava/lang/String;Lcom/adjust/sdk/ResponseData;)V
    //   1337: aload #9
    //   1339: ifnull -> 1580
    //   1342: aload #9
    //   1344: invokevirtual flush : ()V
    //   1347: aload #9
    //   1349: invokevirtual close : ()V
    //   1352: goto -> 1580
    //   1355: astore #5
    //   1357: aload_0
    //   1358: aload #5
    //   1360: ldc_w 'Flushing and closing connection output stream'
    //   1363: aload_1
    //   1364: getfield activityPackage : Lcom/adjust/sdk/ActivityPackage;
    //   1367: invokespecial errorMessage : (Ljava/lang/Throwable;Ljava/lang/String;Lcom/adjust/sdk/ActivityPackage;)Ljava/lang/String;
    //   1370: astore_1
    //   1371: aload_0
    //   1372: getfield logger : Lcom/adjust/sdk/ILogger;
    //   1375: aload_1
    //   1376: iconst_0
    //   1377: anewarray java/lang/Object
    //   1380: invokeinterface error : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   1385: goto -> 1580
    //   1388: aload #8
    //   1390: astore #5
    //   1392: aload_0
    //   1393: aload #6
    //   1395: ldc_w 'Protocol Error'
    //   1398: aload_1
    //   1399: invokespecial localError : (Ljava/lang/Throwable;Ljava/lang/String;Lcom/adjust/sdk/ResponseData;)V
    //   1402: aload #8
    //   1404: ifnull -> 1580
    //   1407: aload #8
    //   1409: invokevirtual flush : ()V
    //   1412: aload #8
    //   1414: invokevirtual close : ()V
    //   1417: goto -> 1580
    //   1420: astore #5
    //   1422: aload_0
    //   1423: aload #5
    //   1425: ldc_w 'Flushing and closing connection output stream'
    //   1428: aload_1
    //   1429: getfield activityPackage : Lcom/adjust/sdk/ActivityPackage;
    //   1432: invokespecial errorMessage : (Ljava/lang/Throwable;Ljava/lang/String;Lcom/adjust/sdk/ActivityPackage;)Ljava/lang/String;
    //   1435: astore_1
    //   1436: aload_0
    //   1437: getfield logger : Lcom/adjust/sdk/ILogger;
    //   1440: aload_1
    //   1441: iconst_0
    //   1442: anewarray java/lang/Object
    //   1445: invokeinterface error : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   1450: goto -> 1580
    //   1453: aload #10
    //   1455: astore #5
    //   1457: aload_0
    //   1458: aload #6
    //   1460: ldc_w 'Malformed URL'
    //   1463: aload_1
    //   1464: invokespecial localError : (Ljava/lang/Throwable;Ljava/lang/String;Lcom/adjust/sdk/ResponseData;)V
    //   1467: aload #10
    //   1469: ifnull -> 1580
    //   1472: aload #10
    //   1474: invokevirtual flush : ()V
    //   1477: aload #10
    //   1479: invokevirtual close : ()V
    //   1482: goto -> 1580
    //   1485: astore #5
    //   1487: aload_0
    //   1488: aload #5
    //   1490: ldc_w 'Flushing and closing connection output stream'
    //   1493: aload_1
    //   1494: getfield activityPackage : Lcom/adjust/sdk/ActivityPackage;
    //   1497: invokespecial errorMessage : (Ljava/lang/Throwable;Ljava/lang/String;Lcom/adjust/sdk/ActivityPackage;)Ljava/lang/String;
    //   1500: astore_1
    //   1501: aload_0
    //   1502: getfield logger : Lcom/adjust/sdk/ILogger;
    //   1505: aload_1
    //   1506: iconst_0
    //   1507: anewarray java/lang/Object
    //   1510: invokeinterface error : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   1515: goto -> 1580
    //   1518: aload #12
    //   1520: astore #5
    //   1522: aload_0
    //   1523: aload #6
    //   1525: ldc_w 'Failed to encode parameters'
    //   1528: aload_1
    //   1529: invokespecial localError : (Ljava/lang/Throwable;Ljava/lang/String;Lcom/adjust/sdk/ResponseData;)V
    //   1532: aload #12
    //   1534: ifnull -> 1580
    //   1537: aload #12
    //   1539: invokevirtual flush : ()V
    //   1542: aload #12
    //   1544: invokevirtual close : ()V
    //   1547: goto -> 1580
    //   1550: astore #5
    //   1552: aload_0
    //   1553: aload #5
    //   1555: ldc_w 'Flushing and closing connection output stream'
    //   1558: aload_1
    //   1559: getfield activityPackage : Lcom/adjust/sdk/ActivityPackage;
    //   1562: invokespecial errorMessage : (Ljava/lang/Throwable;Ljava/lang/String;Lcom/adjust/sdk/ActivityPackage;)Ljava/lang/String;
    //   1565: astore_1
    //   1566: aload_0
    //   1567: getfield logger : Lcom/adjust/sdk/ILogger;
    //   1570: aload_1
    //   1571: iconst_0
    //   1572: anewarray java/lang/Object
    //   1575: invokeinterface error : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   1580: return
    //   1581: aload #5
    //   1583: ifnull -> 1629
    //   1586: aload #5
    //   1588: invokevirtual flush : ()V
    //   1591: aload #5
    //   1593: invokevirtual close : ()V
    //   1596: goto -> 1629
    //   1599: astore #5
    //   1601: aload_0
    //   1602: aload #5
    //   1604: ldc_w 'Flushing and closing connection output stream'
    //   1607: aload_1
    //   1608: getfield activityPackage : Lcom/adjust/sdk/ActivityPackage;
    //   1611: invokespecial errorMessage : (Ljava/lang/Throwable;Ljava/lang/String;Lcom/adjust/sdk/ActivityPackage;)Ljava/lang/String;
    //   1614: astore_1
    //   1615: aload_0
    //   1616: getfield logger : Lcom/adjust/sdk/ILogger;
    //   1619: aload_1
    //   1620: iconst_0
    //   1621: anewarray java/lang/Object
    //   1624: invokeinterface error : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   1629: aload #6
    //   1631: athrow
    // Exception table:
    //   from	to	target	type
    //   49	55	406	java/io/UnsupportedEncodingException
    //   49	55	401	java/net/MalformedURLException
    //   49	55	396	java/net/ProtocolException
    //   49	55	391	java/net/SocketTimeoutException
    //   49	55	386	javax/net/ssl/SSLHandshakeException
    //   49	55	381	java/io/IOException
    //   49	55	376	finally
    //   83	88	406	java/io/UnsupportedEncodingException
    //   83	88	401	java/net/MalformedURLException
    //   83	88	396	java/net/ProtocolException
    //   83	88	391	java/net/SocketTimeoutException
    //   83	88	386	javax/net/ssl/SSLHandshakeException
    //   83	88	381	java/io/IOException
    //   83	88	376	finally
    //   116	126	406	java/io/UnsupportedEncodingException
    //   116	126	401	java/net/MalformedURLException
    //   116	126	396	java/net/ProtocolException
    //   116	126	391	java/net/SocketTimeoutException
    //   116	126	386	javax/net/ssl/SSLHandshakeException
    //   116	126	381	java/io/IOException
    //   116	126	376	finally
    //   154	160	406	java/io/UnsupportedEncodingException
    //   154	160	401	java/net/MalformedURLException
    //   154	160	396	java/net/ProtocolException
    //   154	160	391	java/net/SocketTimeoutException
    //   154	160	386	javax/net/ssl/SSLHandshakeException
    //   154	160	381	java/io/IOException
    //   154	160	376	finally
    //   188	201	406	java/io/UnsupportedEncodingException
    //   188	201	401	java/net/MalformedURLException
    //   188	201	396	java/net/ProtocolException
    //   188	201	391	java/net/SocketTimeoutException
    //   188	201	386	javax/net/ssl/SSLHandshakeException
    //   188	201	381	java/io/IOException
    //   188	201	376	finally
    //   229	238	406	java/io/UnsupportedEncodingException
    //   229	238	401	java/net/MalformedURLException
    //   229	238	396	java/net/ProtocolException
    //   229	238	391	java/net/SocketTimeoutException
    //   229	238	386	javax/net/ssl/SSLHandshakeException
    //   229	238	381	java/io/IOException
    //   229	238	376	finally
    //   266	271	406	java/io/UnsupportedEncodingException
    //   266	271	401	java/net/MalformedURLException
    //   266	271	396	java/net/ProtocolException
    //   266	271	391	java/net/SocketTimeoutException
    //   266	271	386	javax/net/ssl/SSLHandshakeException
    //   266	271	381	java/io/IOException
    //   266	271	376	finally
    //   320	325	406	java/io/UnsupportedEncodingException
    //   320	325	401	java/net/MalformedURLException
    //   320	325	396	java/net/ProtocolException
    //   320	325	391	java/net/SocketTimeoutException
    //   320	325	386	javax/net/ssl/SSLHandshakeException
    //   320	325	381	java/io/IOException
    //   320	325	376	finally
    //   353	373	406	java/io/UnsupportedEncodingException
    //   353	373	401	java/net/MalformedURLException
    //   353	373	396	java/net/ProtocolException
    //   353	373	391	java/net/SocketTimeoutException
    //   353	373	386	javax/net/ssl/SSLHandshakeException
    //   353	373	381	java/io/IOException
    //   353	373	376	finally
    //   439	455	406	java/io/UnsupportedEncodingException
    //   439	455	401	java/net/MalformedURLException
    //   439	455	396	java/net/ProtocolException
    //   439	455	391	java/net/SocketTimeoutException
    //   439	455	386	javax/net/ssl/SSLHandshakeException
    //   439	455	381	java/io/IOException
    //   439	455	376	finally
    //   483	488	406	java/io/UnsupportedEncodingException
    //   483	488	401	java/net/MalformedURLException
    //   483	488	396	java/net/ProtocolException
    //   483	488	391	java/net/SocketTimeoutException
    //   483	488	386	javax/net/ssl/SSLHandshakeException
    //   483	488	381	java/io/IOException
    //   483	488	376	finally
    //   516	523	406	java/io/UnsupportedEncodingException
    //   516	523	401	java/net/MalformedURLException
    //   516	523	396	java/net/ProtocolException
    //   516	523	391	java/net/SocketTimeoutException
    //   516	523	386	javax/net/ssl/SSLHandshakeException
    //   516	523	381	java/io/IOException
    //   516	523	376	finally
    //   551	564	406	java/io/UnsupportedEncodingException
    //   551	564	401	java/net/MalformedURLException
    //   551	564	396	java/net/ProtocolException
    //   551	564	391	java/net/SocketTimeoutException
    //   551	564	386	javax/net/ssl/SSLHandshakeException
    //   551	564	381	java/io/IOException
    //   551	564	376	finally
    //   592	608	406	java/io/UnsupportedEncodingException
    //   592	608	401	java/net/MalformedURLException
    //   592	608	396	java/net/ProtocolException
    //   592	608	391	java/net/SocketTimeoutException
    //   592	608	386	javax/net/ssl/SSLHandshakeException
    //   592	608	381	java/io/IOException
    //   592	608	376	finally
    //   641	651	406	java/io/UnsupportedEncodingException
    //   641	651	401	java/net/MalformedURLException
    //   641	651	396	java/net/ProtocolException
    //   641	651	391	java/net/SocketTimeoutException
    //   641	651	386	javax/net/ssl/SSLHandshakeException
    //   641	651	381	java/io/IOException
    //   641	651	376	finally
    //   683	691	406	java/io/UnsupportedEncodingException
    //   683	691	401	java/net/MalformedURLException
    //   683	691	396	java/net/ProtocolException
    //   683	691	391	java/net/SocketTimeoutException
    //   683	691	386	javax/net/ssl/SSLHandshakeException
    //   683	691	381	java/io/IOException
    //   683	691	376	finally
    //   722	727	406	java/io/UnsupportedEncodingException
    //   722	727	401	java/net/MalformedURLException
    //   722	727	396	java/net/ProtocolException
    //   722	727	391	java/net/SocketTimeoutException
    //   722	727	386	javax/net/ssl/SSLHandshakeException
    //   722	727	381	java/io/IOException
    //   722	727	376	finally
    //   755	767	406	java/io/UnsupportedEncodingException
    //   755	767	401	java/net/MalformedURLException
    //   755	767	396	java/net/ProtocolException
    //   755	767	391	java/net/SocketTimeoutException
    //   755	767	386	javax/net/ssl/SSLHandshakeException
    //   755	767	381	java/io/IOException
    //   755	767	376	finally
    //   795	804	406	java/io/UnsupportedEncodingException
    //   795	804	401	java/net/MalformedURLException
    //   795	804	396	java/net/ProtocolException
    //   795	804	391	java/net/SocketTimeoutException
    //   795	804	386	javax/net/ssl/SSLHandshakeException
    //   795	804	381	java/io/IOException
    //   795	804	376	finally
    //   832	839	406	java/io/UnsupportedEncodingException
    //   832	839	401	java/net/MalformedURLException
    //   832	839	396	java/net/ProtocolException
    //   832	839	391	java/net/SocketTimeoutException
    //   832	839	386	javax/net/ssl/SSLHandshakeException
    //   832	839	381	java/io/IOException
    //   832	839	376	finally
    //   867	874	406	java/io/UnsupportedEncodingException
    //   867	874	401	java/net/MalformedURLException
    //   867	874	396	java/net/ProtocolException
    //   867	874	391	java/net/SocketTimeoutException
    //   867	874	386	javax/net/ssl/SSLHandshakeException
    //   867	874	381	java/io/IOException
    //   867	874	376	finally
    //   907	918	406	java/io/UnsupportedEncodingException
    //   907	918	401	java/net/MalformedURLException
    //   907	918	396	java/net/ProtocolException
    //   907	918	391	java/net/SocketTimeoutException
    //   907	918	386	javax/net/ssl/SSLHandshakeException
    //   907	918	381	java/io/IOException
    //   907	918	376	finally
    //   953	958	406	java/io/UnsupportedEncodingException
    //   953	958	401	java/net/MalformedURLException
    //   953	958	396	java/net/ProtocolException
    //   953	958	391	java/net/SocketTimeoutException
    //   953	958	386	javax/net/ssl/SSLHandshakeException
    //   953	958	381	java/io/IOException
    //   953	958	376	finally
    //   989	996	406	java/io/UnsupportedEncodingException
    //   989	996	401	java/net/MalformedURLException
    //   989	996	396	java/net/ProtocolException
    //   989	996	391	java/net/SocketTimeoutException
    //   989	996	386	javax/net/ssl/SSLHandshakeException
    //   989	996	381	java/io/IOException
    //   989	996	376	finally
    //   1024	1031	406	java/io/UnsupportedEncodingException
    //   1024	1031	401	java/net/MalformedURLException
    //   1024	1031	396	java/net/ProtocolException
    //   1024	1031	391	java/net/SocketTimeoutException
    //   1024	1031	386	javax/net/ssl/SSLHandshakeException
    //   1024	1031	381	java/io/IOException
    //   1024	1031	376	finally
    //   1067	1072	406	java/io/UnsupportedEncodingException
    //   1067	1072	401	java/net/MalformedURLException
    //   1067	1072	396	java/net/ProtocolException
    //   1067	1072	391	java/net/SocketTimeoutException
    //   1067	1072	386	javax/net/ssl/SSLHandshakeException
    //   1067	1072	381	java/io/IOException
    //   1067	1072	376	finally
    //   1077	1087	1090	java/io/IOException
    //   1127	1137	1188	finally
    //   1142	1152	1155	java/io/IOException
    //   1197	1207	1188	finally
    //   1212	1222	1225	java/io/IOException
    //   1262	1272	1188	finally
    //   1277	1287	1290	java/io/IOException
    //   1327	1337	1188	finally
    //   1342	1352	1355	java/io/IOException
    //   1392	1402	1188	finally
    //   1407	1417	1420	java/io/IOException
    //   1457	1467	1188	finally
    //   1472	1482	1485	java/io/IOException
    //   1522	1532	1188	finally
    //   1537	1547	1550	java/io/IOException
    //   1586	1596	1599	java/io/IOException
  }
  
  private String urlWithExtraPathByActivityKind(ActivityKind paramActivityKind, String paramString) {
    if (paramActivityKind == ActivityKind.GDPR) {
      str = paramString;
      if (this.gdprPath != null) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(paramString);
        stringBuilder.append(this.gdprPath);
        str = stringBuilder.toString();
      } 
      return str;
    } 
    if (str == ActivityKind.SUBSCRIPTION) {
      String str1;
      str = paramString;
      if (this.subscriptionPath != null) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(paramString);
        stringBuilder.append(this.subscriptionPath);
        str1 = stringBuilder.toString();
      } 
      return str1;
    } 
    String str = paramString;
    if (this.basePath != null) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(paramString);
      stringBuilder.append(this.basePath);
      str = stringBuilder.toString();
    } 
    return str;
  }
  
  public Integer readConnectionResponse(HttpsURLConnection paramHttpsURLConnection, ResponseData paramResponseData) {
    // Byte code:
    //   0: new java/lang/StringBuilder
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore #7
    //   9: aconst_null
    //   10: astore #5
    //   12: aload #5
    //   14: astore #4
    //   16: aload_1
    //   17: invokevirtual connect : ()V
    //   20: aload #5
    //   22: astore #4
    //   24: aload_1
    //   25: invokevirtual getResponseCode : ()I
    //   28: istore_3
    //   29: aload #5
    //   31: astore #4
    //   33: iload_3
    //   34: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   37: astore #5
    //   39: iload_3
    //   40: sipush #400
    //   43: if_icmplt -> 68
    //   46: aload #5
    //   48: astore #4
    //   50: aload_1
    //   51: invokevirtual getErrorStream : ()Ljava/io/InputStream;
    //   54: astore #6
    //   56: goto -> 78
    //   59: astore_2
    //   60: goto -> 357
    //   63: astore #5
    //   65: goto -> 153
    //   68: aload #5
    //   70: astore #4
    //   72: aload_1
    //   73: invokevirtual getInputStream : ()Ljava/io/InputStream;
    //   76: astore #6
    //   78: aload #5
    //   80: astore #4
    //   82: new java/io/InputStreamReader
    //   85: astore #8
    //   87: aload #5
    //   89: astore #4
    //   91: aload #8
    //   93: aload #6
    //   95: invokespecial <init> : (Ljava/io/InputStream;)V
    //   98: aload #5
    //   100: astore #4
    //   102: new java/io/BufferedReader
    //   105: astore #6
    //   107: aload #5
    //   109: astore #4
    //   111: aload #6
    //   113: aload #8
    //   115: invokespecial <init> : (Ljava/io/Reader;)V
    //   118: aload #5
    //   120: astore #4
    //   122: aload #6
    //   124: invokevirtual readLine : ()Ljava/lang/String;
    //   127: astore #8
    //   129: aload #5
    //   131: astore #4
    //   133: aload #8
    //   135: ifnull -> 191
    //   138: aload #5
    //   140: astore #4
    //   142: aload #7
    //   144: aload #8
    //   146: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   149: pop
    //   150: goto -> 118
    //   153: aload_0
    //   154: aload #5
    //   156: ldc_w 'Connecting and reading response'
    //   159: aload_2
    //   160: getfield activityPackage : Lcom/adjust/sdk/ActivityPackage;
    //   163: invokespecial errorMessage : (Ljava/lang/Throwable;Ljava/lang/String;Lcom/adjust/sdk/ActivityPackage;)Ljava/lang/String;
    //   166: astore #5
    //   168: aload_0
    //   169: getfield logger : Lcom/adjust/sdk/ILogger;
    //   172: aload #5
    //   174: iconst_0
    //   175: anewarray java/lang/Object
    //   178: invokeinterface error : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   183: aload #4
    //   185: astore #5
    //   187: aload_1
    //   188: ifnull -> 199
    //   191: aload_1
    //   192: invokevirtual disconnect : ()V
    //   195: aload #4
    //   197: astore #5
    //   199: aload #7
    //   201: invokevirtual length : ()I
    //   204: ifne -> 226
    //   207: aload_0
    //   208: getfield logger : Lcom/adjust/sdk/ILogger;
    //   211: ldc_w 'Empty response string buffer'
    //   214: iconst_0
    //   215: anewarray java/lang/Object
    //   218: invokeinterface error : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   223: aload #5
    //   225: areturn
    //   226: aload #5
    //   228: invokevirtual intValue : ()I
    //   231: sipush #429
    //   234: if_icmpne -> 256
    //   237: aload_0
    //   238: getfield logger : Lcom/adjust/sdk/ILogger;
    //   241: ldc_w 'Too frequent requests to the endpoint (429)'
    //   244: iconst_0
    //   245: anewarray java/lang/Object
    //   248: invokeinterface error : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   253: aload #5
    //   255: areturn
    //   256: aload #7
    //   258: invokevirtual toString : ()Ljava/lang/String;
    //   261: astore_1
    //   262: aload_0
    //   263: getfield logger : Lcom/adjust/sdk/ILogger;
    //   266: ldc_w 'Response string: %s'
    //   269: iconst_1
    //   270: anewarray java/lang/Object
    //   273: dup
    //   274: iconst_0
    //   275: aload_1
    //   276: aastore
    //   277: invokeinterface debug : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   282: aload_0
    //   283: aload_2
    //   284: aload_1
    //   285: invokespecial parseResponse : (Lcom/adjust/sdk/ResponseData;Ljava/lang/String;)V
    //   288: aload_2
    //   289: getfield message : Ljava/lang/String;
    //   292: astore_1
    //   293: aload_1
    //   294: ifnonnull -> 300
    //   297: aload #5
    //   299: areturn
    //   300: aload #5
    //   302: invokevirtual intValue : ()I
    //   305: sipush #200
    //   308: if_icmpne -> 334
    //   311: aload_0
    //   312: getfield logger : Lcom/adjust/sdk/ILogger;
    //   315: ldc_w 'Response message: %s'
    //   318: iconst_1
    //   319: anewarray java/lang/Object
    //   322: dup
    //   323: iconst_0
    //   324: aload_1
    //   325: aastore
    //   326: invokeinterface info : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   331: goto -> 354
    //   334: aload_0
    //   335: getfield logger : Lcom/adjust/sdk/ILogger;
    //   338: ldc_w 'Response message: %s'
    //   341: iconst_1
    //   342: anewarray java/lang/Object
    //   345: dup
    //   346: iconst_0
    //   347: aload_1
    //   348: aastore
    //   349: invokeinterface error : (Ljava/lang/String;[Ljava/lang/Object;)V
    //   354: aload #5
    //   356: areturn
    //   357: aload_1
    //   358: ifnull -> 365
    //   361: aload_1
    //   362: invokevirtual disconnect : ()V
    //   365: aload_2
    //   366: athrow
    // Exception table:
    //   from	to	target	type
    //   16	20	63	java/io/IOException
    //   16	20	59	finally
    //   24	29	63	java/io/IOException
    //   24	29	59	finally
    //   33	39	63	java/io/IOException
    //   33	39	59	finally
    //   50	56	63	java/io/IOException
    //   50	56	59	finally
    //   72	78	63	java/io/IOException
    //   72	78	59	finally
    //   82	87	63	java/io/IOException
    //   82	87	59	finally
    //   91	98	63	java/io/IOException
    //   91	98	59	finally
    //   102	107	63	java/io/IOException
    //   102	107	59	finally
    //   111	118	63	java/io/IOException
    //   111	118	59	finally
    //   122	129	63	java/io/IOException
    //   122	129	59	finally
    //   142	150	63	java/io/IOException
    //   142	150	59	finally
    //   153	183	59	finally
  }
  
  public void sendActivityPackage(ActivityPackage paramActivityPackage, Map<String, String> paramMap, IActivityPackageSender.ResponseDataCallbackSubscriber paramResponseDataCallbackSubscriber) {
    this.executor.submit((Runnable)new a(this, paramResponseDataCallbackSubscriber, paramActivityPackage, paramMap));
  }
  
  public ResponseData sendActivityPackageSync(ActivityPackage paramActivityPackage, Map<String, String> paramMap) {
    while (true) {
      ResponseData responseData = ResponseData.buildResponseData(paramActivityPackage, paramMap);
      tryToGetResponse(responseData);
      if (!shouldRetryToSend(responseData))
        return responseData; 
    } 
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\adjust\sdk\network\ActivityPackageSender.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */