package com.adjust.sdk.network;

import com.adjust.sdk.ActivityPackage;
import com.adjust.sdk.ResponseData;
import java.util.Map;

public interface IActivityPackageSender {
  void sendActivityPackage(ActivityPackage paramActivityPackage, Map<String, String> paramMap, ResponseDataCallbackSubscriber paramResponseDataCallbackSubscriber);
  
  ResponseData sendActivityPackageSync(ActivityPackage paramActivityPackage, Map<String, String> paramMap);
  
  public static interface ResponseDataCallbackSubscriber {
    void onResponseDataCallback(ResponseData param1ResponseData);
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\adjust\sdk\network\IActivityPackageSender.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */