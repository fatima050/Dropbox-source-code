package com.adjust.sdk.network;

import com.adjust.sdk.ActivityKind;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class UrlStrategy {
  private static final String BASE_URL_CHINA = "https://app.adjust.world";
  
  private static final String BASE_URL_CN = "https://app.adjust.cn";
  
  private static final String BASE_URL_EU = "https://app.eu.adjust.com";
  
  private static final String BASE_URL_INDIA = "https://app.adjust.net.in";
  
  private static final String BASE_URL_TR = "https://app.tr.adjust.com";
  
  private static final String BASE_URL_US = "https://app.us.adjust.com";
  
  private static final String GDPR_URL_CHINA = "https://gdpr.adjust.world";
  
  private static final String GDPR_URL_CN = "https://gdpr.adjust.com";
  
  private static final String GDPR_URL_EU = "https://gdpr.eu.adjust.com";
  
  private static final String GDPR_URL_INDIA = "https://gdpr.adjust.net.in";
  
  private static final String GDPR_URL_TR = "https://gdpr.tr.adjust.com";
  
  private static final String GDPR_URL_US = "https://gdpr.us.adjust.com";
  
  private static final String SUBSCRIPTION_URL_CHINA = "https://subscription.adjust.world";
  
  private static final String SUBSCRIPTION_URL_CN = "https://subscription.adjust.com";
  
  private static final String SUBSCRIPTION_URL_EU = "https://subscription.eu.adjust.com";
  
  private static final String SUBSCRIPTION_URL_INDIA = "https://subscription.adjust.net.in";
  
  private static final String SUBSCRIPTION_URL_TR = "https://subscription.tr.adjust.com";
  
  private static final String SUBSCRIPTION_URL_US = "https://subscription.us.adjust.com";
  
  public final List<String> baseUrlChoicesList;
  
  private final String baseUrlOverwrite;
  
  public int choiceIndex;
  
  public final List<String> gdprUrlChoicesList;
  
  private final String gdprUrlOverwrite;
  
  public int startingChoiceIndex;
  
  public final List<String> subscriptionUrlChoicesList;
  
  private final String subscriptionUrlOverwrite;
  
  public boolean wasLastAttemptSuccess;
  
  public boolean wasLastAttemptWithOverwrittenUrl;
  
  public UrlStrategy(String paramString1, String paramString2, String paramString3, String paramString4) {
    this.baseUrlOverwrite = paramString1;
    this.gdprUrlOverwrite = paramString2;
    this.subscriptionUrlOverwrite = paramString3;
    this.baseUrlChoicesList = baseUrlChoices(paramString4);
    this.gdprUrlChoicesList = gdprUrlChoices(paramString4);
    this.subscriptionUrlChoicesList = subscriptionUrlChoices(paramString4);
    this.wasLastAttemptSuccess = false;
    this.choiceIndex = 0;
    this.startingChoiceIndex = 0;
    this.wasLastAttemptWithOverwrittenUrl = false;
  }
  
  private static List<String> baseUrlChoices(String paramString) {
    return "url_strategy_india".equals(paramString) ? Arrays.asList(new String[] { "https://app.adjust.net.in", "https://app.adjust.com" }) : ("url_strategy_china".equals(paramString) ? Arrays.asList(new String[] { "https://app.adjust.world", "https://app.adjust.com" }) : ("url_strategy_cn".equals(paramString) ? Arrays.asList(new String[] { "https://app.adjust.cn", "https://app.adjust.com" }) : ("data_residency_eu".equals(paramString) ? Collections.singletonList("https://app.eu.adjust.com") : ("data_residency_tr".equals(paramString) ? Collections.singletonList("https://app.tr.adjust.com") : ("data_residency_us".equals(paramString) ? Collections.singletonList("https://app.us.adjust.com") : Arrays.asList(new String[] { "https://app.adjust.com", "https://app.adjust.net.in", "https://app.adjust.world" }))))));
  }
  
  private static List<String> gdprUrlChoices(String paramString) {
    return "url_strategy_india".equals(paramString) ? Arrays.asList(new String[] { "https://gdpr.adjust.net.in", "https://gdpr.adjust.com" }) : ("url_strategy_china".equals(paramString) ? Arrays.asList(new String[] { "https://gdpr.adjust.world", "https://gdpr.adjust.com" }) : ("url_strategy_cn".equals(paramString) ? Arrays.asList(new String[] { "https://gdpr.adjust.com", "https://gdpr.adjust.com" }) : ("data_residency_eu".equals(paramString) ? Collections.singletonList("https://gdpr.eu.adjust.com") : ("data_residency_tr".equals(paramString) ? Collections.singletonList("https://gdpr.tr.adjust.com") : ("data_residency_us".equals(paramString) ? Collections.singletonList("https://gdpr.us.adjust.com") : Arrays.asList(new String[] { "https://gdpr.adjust.com", "https://gdpr.adjust.net.in", "https://gdpr.adjust.world" }))))));
  }
  
  private static List<String> subscriptionUrlChoices(String paramString) {
    return "url_strategy_india".equals(paramString) ? Arrays.asList(new String[] { "https://subscription.adjust.net.in", "https://subscription.adjust.com" }) : ("url_strategy_china".equals(paramString) ? Arrays.asList(new String[] { "https://subscription.adjust.world", "https://subscription.adjust.com" }) : ("url_strategy_cn".equals(paramString) ? Arrays.asList(new String[] { "https://subscription.adjust.com", "https://subscription.adjust.com" }) : ("data_residency_eu".equals(paramString) ? Collections.singletonList("https://subscription.eu.adjust.com") : ("data_residency_tr".equals(paramString) ? Collections.singletonList("https://subscription.tr.adjust.com") : ("data_residency_us".equals(paramString) ? Collections.singletonList("https://subscription.us.adjust.com") : Arrays.asList(new String[] { "https://subscription.adjust.com", "https://subscription.adjust.net.in", "https://subscription.adjust.world" }))))));
  }
  
  public void resetAfterSuccess() {
    this.startingChoiceIndex = this.choiceIndex;
    this.wasLastAttemptSuccess = true;
  }
  
  public boolean shouldRetryAfterFailure(ActivityKind paramActivityKind) {
    List<String> list;
    boolean bool = false;
    this.wasLastAttemptSuccess = false;
    if (this.wasLastAttemptWithOverwrittenUrl)
      return false; 
    if (paramActivityKind == ActivityKind.GDPR) {
      list = this.gdprUrlChoicesList;
    } else if (list == ActivityKind.SUBSCRIPTION) {
      list = this.subscriptionUrlChoicesList;
    } else {
      list = this.baseUrlChoicesList;
    } 
    int i = list.size();
    i = (this.choiceIndex + 1) % i;
    this.choiceIndex = i;
    if (i != this.startingChoiceIndex)
      bool = true; 
    return bool;
  }
  
  public String targetUrlByActivityKind(ActivityKind paramActivityKind) {
    List<String> list2;
    if (paramActivityKind == ActivityKind.GDPR) {
      String str1 = this.gdprUrlOverwrite;
      if (str1 != null) {
        this.wasLastAttemptWithOverwrittenUrl = true;
        return str1;
      } 
      this.wasLastAttemptWithOverwrittenUrl = false;
      list2 = this.gdprUrlChoicesList;
      return list2.get(this.choiceIndex);
    } 
    if (list2 == ActivityKind.SUBSCRIPTION) {
      String str1 = this.subscriptionUrlOverwrite;
      if (str1 != null) {
        this.wasLastAttemptWithOverwrittenUrl = true;
        return str1;
      } 
      this.wasLastAttemptWithOverwrittenUrl = false;
      List<String> list = this.subscriptionUrlChoicesList;
      return list.get(this.choiceIndex);
    } 
    String str = this.baseUrlOverwrite;
    if (str != null) {
      this.wasLastAttemptWithOverwrittenUrl = true;
      return str;
    } 
    this.wasLastAttemptWithOverwrittenUrl = false;
    List<String> list1 = this.baseUrlChoicesList;
    return list1.get(this.choiceIndex);
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\adjust\sdk\network\UrlStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */