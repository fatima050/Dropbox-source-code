package com.adjust.sdk.network;

import com.adjust.sdk.AdjustFactory;
import com.adjust.sdk.ILogger;
import java.net.URL;
import javax.net.ssl.HttpsURLConnection;

public class UtilNetworking {
  private static String userAgent;
  
  public static IConnectionOptions createDefaultConnectionOptions() {
    return new a();
  }
  
  public static IHttpsURLConnectionProvider createDefaultHttpsURLConnectionProvider() {
    return new b();
  }
  
  public static Long extractJsonLong(dbxyzptlk.WK.b paramb, String paramString) {
    Object object = paramb.r(paramString);
    if (object instanceof Long)
      return (Long)object; 
    if (object instanceof Number)
      return Long.valueOf(((Number)object).longValue()); 
    if (object instanceof String)
      try {
        long l = (long)Double.parseDouble((String)object);
        return Long.valueOf(l);
      } catch (NumberFormatException numberFormatException) {} 
    return null;
  }
  
  public static String extractJsonString(dbxyzptlk.WK.b paramb, String paramString) {
    Object object = paramb.r(paramString);
    return (object instanceof String) ? (String)object : ((object != null) ? object.toString() : null);
  }
  
  private static ILogger getLogger() {
    return AdjustFactory.getLogger();
  }
  
  public static void setUserAgent(String paramString) {
    userAgent = paramString;
  }
  
  public static interface IConnectionOptions {
    void applyConnectionOptions(HttpsURLConnection param1HttpsURLConnection, String param1String);
  }
  
  public static interface IHttpsURLConnectionProvider {
    HttpsURLConnection generateHttpsURLConnection(URL param1URL);
  }
  
  public final class a implements IConnectionOptions {
    public final void applyConnectionOptions(HttpsURLConnection param1HttpsURLConnection, String param1String) {
      param1HttpsURLConnection.setRequestProperty("Client-SDK", param1String);
      param1HttpsURLConnection.setConnectTimeout(60000);
      param1HttpsURLConnection.setReadTimeout(60000);
      if (UtilNetworking.userAgent != null)
        param1HttpsURLConnection.setRequestProperty("User-Agent", UtilNetworking.userAgent); 
    }
  }
  
  public final class b implements IHttpsURLConnectionProvider {
    public final HttpsURLConnection generateHttpsURLConnection(URL param1URL) {
      return (HttpsURLConnection)param1URL.openConnection();
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\adjust\sdk\network\UtilNetworking.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */