package com.adjust.sdk;

import android.content.Context;
import com.adjust.sdk.scheduler.SingleThreadCachedScheduler;
import com.adjust.sdk.scheduler.ThreadExecutor;
import com.adjust.sdk.scheduler.TimerOnce;
import com.android.installreferrer.api.InstallReferrerStateListener;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.concurrent.atomic.AtomicBoolean;

public class InstallReferrer implements InvocationHandler {
  private static final String PACKAGE_BASE_NAME = "com.android.installreferrer.";
  
  private static final int STATUS_DEVELOPER_ERROR = 3;
  
  private static final int STATUS_FEATURE_NOT_SUPPORTED = 2;
  
  private static final int STATUS_OK = 0;
  
  private static final int STATUS_SERVICE_DISCONNECTED = -1;
  
  private static final int STATUS_SERVICE_UNAVAILABLE = 1;
  
  private Context context;
  
  private ThreadExecutor executor;
  
  private ILogger logger;
  
  private Object playInstallReferrer;
  
  private final InstallReferrerReadListener referrerCallback;
  
  private Object referrerClient;
  
  private int retries;
  
  private TimerOnce retryTimer;
  
  private int retryWaitTime = 3000;
  
  private final AtomicBoolean shouldTryToRead;
  
  public InstallReferrer(Context paramContext, InstallReferrerReadListener paramInstallReferrerReadListener) {
    ILogger iLogger = AdjustFactory.getLogger();
    this.logger = iLogger;
    this.playInstallReferrer = createInstallReferrer(paramContext, paramInstallReferrerReadListener, iLogger);
    this.context = paramContext;
    this.shouldTryToRead = new AtomicBoolean(true);
    this.retries = 0;
    this.retryTimer = new TimerOnce(new a(this), "InstallReferrer");
    this.referrerCallback = paramInstallReferrerReadListener;
    this.executor = (ThreadExecutor)new SingleThreadCachedScheduler("InstallReferrer");
  }
  
  private void closeReferrerClient() {
    Object object = this.referrerClient;
    if (object == null)
      return; 
    try {
      Reflection.invokeInstanceMethod(object, "endConnection", null, new Object[0]);
      this.logger.debug("Install Referrer API connection closed", new Object[0]);
    } catch (Exception exception) {
      this.logger.error("closeReferrerClient error (%s) thrown by (%s)", new Object[] { exception.getMessage(), exception.getClass().getCanonicalName() });
    } 
    this.referrerClient = null;
  }
  
  private Object createInstallReferrer(Context paramContext, InstallReferrerReadListener paramInstallReferrerReadListener, ILogger paramILogger) {
    return Reflection.createInstance("com.adjust.sdk.play.InstallReferrer", new Class[] { Context.class, InstallReferrerReadListener.class, ILogger.class }, new Object[] { paramContext, paramInstallReferrerReadListener, paramILogger });
  }
  
  private Object createInstallReferrerClient(Context paramContext) {
    try {
      return Reflection.invokeInstanceMethod(Reflection.invokeStaticMethod("com.android.installreferrer.api.InstallReferrerClient", "newBuilder", new Class[] { Context.class }, new Object[] { paramContext }), "build", null, new Object[0]);
    } catch (ClassNotFoundException classNotFoundException) {
      this.logger.warn("InstallReferrer not integrated in project (%s) thrown by (%s)", new Object[] { classNotFoundException.getMessage(), classNotFoundException.getClass().getCanonicalName() });
    } catch (Exception exception) {}
    return null;
  }
  
  private Object createProxyInstallReferrerStateListener(Class paramClass) {
    try {
      object = Proxy.newProxyInstance(paramClass.getClassLoader(), new Class[] { paramClass }, this);
    } catch (IllegalArgumentException null) {
      this.logger.error("InstallReferrer proxy violating parameter restrictions", new Object[0]);
      object = null;
    } catch (NullPointerException object) {
      this.logger.error("Null argument passed to InstallReferrer proxy", new Object[0]);
    } 
    return object;
  }
  
  private Boolean getBooleanGooglePlayInstantParam(Object paramObject) {
    if (paramObject == null)
      return null; 
    try {
      paramObject = Reflection.invokeInstanceMethod(paramObject, "getGooglePlayInstantParam", null, new Object[0]);
      paramObject.booleanValue();
      return (Boolean)paramObject;
    } catch (Exception exception) {
      return null;
    } 
  }
  
  private long getInstallBeginTimestampSeconds(Object paramObject) {
    if (paramObject == null)
      return -1L; 
    try {
      return ((Long)Reflection.invokeInstanceMethod(paramObject, "getInstallBeginTimestampSeconds", null, new Object[0])).longValue();
    } catch (Exception exception) {
      this.logger.error("getInstallBeginTimestampSeconds error (%s) thrown by (%s)", new Object[] { exception.getMessage(), exception.getClass().getCanonicalName() });
      return -1L;
    } 
  }
  
  private long getInstallBeginTimestampServerSeconds(Object paramObject) {
    long l = -1L;
    if (paramObject == null)
      return -1L; 
    try {
      long l1 = ((Long)Reflection.invokeInstanceMethod(paramObject, "getInstallBeginTimestampServerSeconds", null, new Object[0])).longValue();
      l = l1;
    } catch (Exception exception) {}
    return l;
  }
  
  private Object getInstallReferrer() {
    Object object = this.referrerClient;
    if (object == null)
      return null; 
    try {
      return Reflection.invokeInstanceMethod(object, "getInstallReferrer", null, new Object[0]);
    } catch (Exception exception) {
      this.logger.error("getInstallReferrer error (%s) thrown by (%s)", new Object[] { exception.getMessage(), exception.getClass().getCanonicalName() });
      return null;
    } 
  }
  
  private Class getInstallReferrerStateListenerClass() {
    return InstallReferrerStateListener.class;
  }
  
  private long getReferrerClickTimestampSeconds(Object paramObject) {
    if (paramObject == null)
      return -1L; 
    try {
      return ((Long)Reflection.invokeInstanceMethod(paramObject, "getReferrerClickTimestampSeconds", null, new Object[0])).longValue();
    } catch (Exception exception) {
      this.logger.error("getReferrerClickTimestampSeconds error (%s) thrown by (%s)", new Object[] { exception.getMessage(), exception.getClass().getCanonicalName() });
      return -1L;
    } 
  }
  
  private long getReferrerClickTimestampServerSeconds(Object paramObject) {
    long l = -1L;
    if (paramObject == null)
      return -1L; 
    try {
      long l1 = ((Long)Reflection.invokeInstanceMethod(paramObject, "getReferrerClickTimestampServerSeconds", null, new Object[0])).longValue();
      l = l1;
    } catch (Exception exception) {}
    return l;
  }
  
  private String getStringInstallReferrer(Object paramObject) {
    if (paramObject == null)
      return null; 
    try {
      return (String)Reflection.invokeInstanceMethod(paramObject, "getInstallReferrer", null, new Object[0]);
    } catch (Exception exception) {
      this.logger.error("getStringInstallReferrer error (%s) thrown by (%s)", new Object[] { exception.getMessage(), exception.getClass().getCanonicalName() });
      return null;
    } 
  }
  
  private String getStringInstallVersion(Object paramObject) {
    if (paramObject == null)
      return null; 
    try {
      return (String)Reflection.invokeInstanceMethod(paramObject, "getInstallVersion", null, new Object[0]);
    } catch (Exception exception) {
      return null;
    } 
  }
  
  private Object invokeI(Object paramObject, Method paramMethod, Object[] paramArrayOfObject) {
    if (paramMethod == null) {
      this.logger.error("InstallReferrer invoke method null", new Object[0]);
      return null;
    } 
    String str = paramMethod.getName();
    if (str == null) {
      this.logger.error("InstallReferrer invoke method name null", new Object[0]);
      return null;
    } 
    this.logger.debug("InstallReferrer invoke method name: %s", new Object[] { str });
    paramObject = paramArrayOfObject;
    if (paramArrayOfObject == null) {
      this.logger.warn("InstallReferrer invoke args null", new Object[0]);
      paramObject = new Object[0];
    } 
    int i = paramObject.length;
    for (byte b = 0; b < i; b++) {
      Object object = paramObject[b];
      this.logger.debug("InstallReferrer invoke arg: %s", new Object[] { object });
    } 
    if (str.equals("onInstallReferrerSetupFinished")) {
      if (paramObject.length != 1) {
        this.logger.error("InstallReferrer invoke onInstallReferrerSetupFinished args lenght not 1: %d", new Object[] { Integer.valueOf(paramObject.length) });
        return null;
      } 
      paramObject = paramObject[0];
      if (!(paramObject instanceof Integer)) {
        this.logger.error("InstallReferrer invoke onInstallReferrerSetupFinished arg not int", new Object[0]);
        return null;
      } 
      paramObject = paramObject;
      if (paramObject == null) {
        this.logger.error("InstallReferrer invoke onInstallReferrerSetupFinished responseCode arg is null", new Object[0]);
        return null;
      } 
      onInstallReferrerSetupFinishedIntI(paramObject.intValue());
    } else if (str.equals("onInstallReferrerServiceDisconnected")) {
      this.logger.debug("Connection to install referrer service was lost. Retrying ...", new Object[0]);
      retryI();
    } 
    return null;
  }
  
  private void onInstallReferrerSetupFinishedIntI(int paramInt) {
    if (paramInt != -1) {
      if (paramInt != 0) {
        if (paramInt != 1) {
          if (paramInt != 2) {
            if (paramInt != 3) {
              this.logger.debug("Unexpected response code of install referrer response: %d. Closing connection", new Object[] { Integer.valueOf(paramInt) });
            } else {
              this.logger.debug("Install Referrer API general errors caused by incorrect usage. Retrying...", new Object[0]);
              retryI();
            } 
          } else {
            this.logger.debug("Install Referrer API not supported by the installed Play Store app. Closing connection", new Object[0]);
          } 
        } else {
          this.logger.debug("Could not initiate connection to the Install Referrer service. Retrying...", new Object[0]);
          retryI();
        } 
      } else {
        try {
          Object object = getInstallReferrer();
          String str1 = getStringInstallReferrer(object);
          long l1 = getReferrerClickTimestampSeconds(object);
          long l4 = getInstallBeginTimestampSeconds(object);
          this.logger.debug("installReferrer: %s, clickTime: %d, installBeginTime: %d", new Object[] { str1, Long.valueOf(l1), Long.valueOf(l4) });
          String str2 = getStringInstallVersion(object);
          long l2 = getReferrerClickTimestampServerSeconds(object);
          long l3 = getInstallBeginTimestampServerSeconds(object);
          Boolean bool = getBooleanGooglePlayInstantParam(object);
          this.logger.debug("installVersion: %s, clickTimeServer: %d, installBeginServer: %d, googlePlayInstant: %b", new Object[] { str2, Long.valueOf(l2), Long.valueOf(l3), bool });
          this.logger.debug("Install Referrer read successfully. Closing connection", new Object[0]);
          object = new ReferrerDetails();
          super(str1, l1, l4, l2, l3, str2, bool);
          this.referrerCallback.onInstallReferrerRead((ReferrerDetails)object, "google");
          this.shouldTryToRead.set(false);
          closeReferrerClient();
        } catch (Exception exception) {
          this.logger.warn("Couldn't get install referrer from client (%s). Retrying...", new Object[] { exception.getMessage() });
          retryI();
        } 
        return;
      } 
    } else {
      this.logger.debug("Play Store service is not connected now. Retrying...", new Object[0]);
      retryI();
    } 
    this.shouldTryToRead.set(false);
    closeReferrerClient();
  }
  
  private void retryI() {
    if (!this.shouldTryToRead.get()) {
      this.logger.debug("Should not try to read Install referrer", new Object[0]);
      closeReferrerClient();
      return;
    } 
    if (this.retries + 1 > 2) {
      this.logger.debug("Limit number of retry of %d for install referrer surpassed", new Object[] { Integer.valueOf(2) });
      return;
    } 
    long l = this.retryTimer.getFireIn();
    if (l > 0L) {
      this.logger.debug("Already waiting to retry to read install referrer in %d milliseconds", new Object[] { Long.valueOf(l) });
      return;
    } 
    int i = this.retries + 1;
    this.retries = i;
    this.logger.debug("Retry number %d to connect to install referrer API", new Object[] { Integer.valueOf(i) });
    this.retryTimer.startIn(this.retryWaitTime);
  }
  
  private void startConnection(Class paramClass, Object paramObject) {
    try {
      Reflection.invokeInstanceMethod(this.referrerClient, "startConnection", new Class[] { paramClass }, new Object[] { paramObject });
    } catch (InvocationTargetException invocationTargetException) {
      if (Util.hasRootCause(invocationTargetException))
        this.logger.error("InstallReferrer encountered an InvocationTargetException %s", new Object[] { Util.getRootCause(invocationTargetException) }); 
    } catch (Exception exception) {}
  }
  
  public Object invoke(Object paramObject, Method paramMethod, Object[] paramArrayOfObject) {
    this.executor.submit(new b(this, paramObject, paramMethod, paramArrayOfObject));
    return null;
  }
  
  public void startConnection() {
    Object object1 = this.playInstallReferrer;
    if (object1 != null)
      try {
        Reflection.invokeInstanceMethod(object1, "startConnection", null, new Object[0]);
        return;
      } catch (Exception exception) {
        this.logger.error("Call to Play startConnection error: %s", new Object[] { exception.getMessage() });
      }  
    if (!AdjustFactory.getTryInstallReferrer())
      return; 
    closeReferrerClient();
    if (!this.shouldTryToRead.get()) {
      this.logger.debug("Should not try to read Install referrer", new Object[0]);
      return;
    } 
    object1 = this.context;
    if (object1 == null)
      return; 
    object1 = createInstallReferrerClient((Context)object1);
    this.referrerClient = object1;
    if (object1 == null)
      return; 
    object1 = getInstallReferrerStateListenerClass();
    if (object1 == null)
      return; 
    Object object2 = createProxyInstallReferrerStateListener((Class)object1);
    if (object2 == null)
      return; 
    startConnection((Class)object1, object2);
  }
  
  public final class a implements Runnable {
    public final InstallReferrer a;
    
    public a(InstallReferrer this$0) {}
    
    public final void run() {
      this.a.startConnection();
    }
  }
  
  public final class b implements Runnable {
    public final Object a;
    
    public final Method b;
    
    public final Object[] c;
    
    public final InstallReferrer d;
    
    public b(InstallReferrer this$0, Object param1Object, Method param1Method, Object[] param1ArrayOfObject) {}
    
    public final void run() {
      try {
        this.d.invokeI(this.a, this.b, this.c);
      } finally {
        Exception exception = null;
      } 
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\adjust\sdk\InstallReferrer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */