package com.adjust.sdk;

import android.content.Context;
import com.adjust.sdk.network.IActivityPackageSender;
import com.adjust.sdk.scheduler.SingleThreadCachedScheduler;
import com.adjust.sdk.scheduler.ThreadScheduler;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

public class PackageHandler implements IPackageHandler, IActivityPackageSender.ResponseDataCallbackSubscriber {
  private static final String PACKAGE_QUEUE_FILENAME = "AdjustIoPackageQueue";
  
  private static final String PACKAGE_QUEUE_NAME = "Package queue";
  
  private WeakReference<IActivityHandler> activityHandlerWeakRef;
  
  private IActivityPackageSender activityPackageSender;
  
  private BackoffStrategy backoffStrategy = AdjustFactory.getPackageHandlerBackoffStrategy();
  
  private BackoffStrategy backoffStrategyForInstallSession = AdjustFactory.getInstallSessionBackoffStrategy();
  
  private Context context;
  
  private AtomicBoolean isSending;
  
  private ILogger logger = AdjustFactory.getLogger();
  
  private List<ActivityPackage> packageQueue;
  
  private boolean paused;
  
  private ThreadScheduler scheduler = (ThreadScheduler)new SingleThreadCachedScheduler("PackageHandler");
  
  public PackageHandler(IActivityHandler paramIActivityHandler, Context paramContext, boolean paramBoolean, IActivityPackageSender paramIActivityPackageSender) {
    init(paramIActivityHandler, paramContext, paramBoolean, paramIActivityPackageSender);
    this.scheduler.submit(new a(this));
  }
  
  private void addI(ActivityPackage paramActivityPackage) {
    this.packageQueue.add(paramActivityPackage);
    this.logger.debug("Added package %d (%s)", new Object[] { Integer.valueOf(this.packageQueue.size()), paramActivityPackage });
    this.logger.verbose("%s", new Object[] { paramActivityPackage.getExtendedString() });
    writePackageQueueI();
  }
  
  public static Boolean deletePackageQueue(Context paramContext) {
    return Boolean.valueOf(paramContext.deleteFile("AdjustIoPackageQueue"));
  }
  
  public static void deleteState(Context paramContext) {
    deletePackageQueue(paramContext);
  }
  
  private void flushI() {
    this.packageQueue.clear();
    writePackageQueueI();
  }
  
  private Map<String, String> generateSendingParametersI() {
    HashMap<Object, Object> hashMap = new HashMap<>();
    long l = System.currentTimeMillis();
    PackageBuilder.addString((Map)hashMap, "sent_at", Util.dateFormatter.format(Long.valueOf(l)));
    int i = this.packageQueue.size() - 1;
    if (i > 0)
      PackageBuilder.addLong((Map)hashMap, "queue_size", i); 
    return (Map)hashMap;
  }
  
  private void initI() {
    this.isSending = new AtomicBoolean();
    readPackageQueueI();
  }
  
  private void readPackageQueueI() {
    try {
      this.packageQueue = Util.<List<ActivityPackage>>readObject(this.context, "AdjustIoPackageQueue", "Package queue", (Class)List.class);
    } catch (Exception exception) {
      this.logger.error("Failed to read %s file (%s)", new Object[] { "Package queue", exception.getMessage() });
      this.packageQueue = null;
    } 
    List<ActivityPackage> list = this.packageQueue;
    if (list != null) {
      this.logger.debug("Package handler read %d packages", new Object[] { Integer.valueOf(list.size()) });
    } else {
      this.packageQueue = new ArrayList<>();
    } 
  }
  
  private void sendFirstI() {
    if (this.packageQueue.isEmpty())
      return; 
    if (this.paused) {
      this.logger.debug("Package handler is paused", new Object[0]);
      return;
    } 
    if (this.isSending.getAndSet(true)) {
      this.logger.verbose("Package handler is already sending", new Object[0]);
      return;
    } 
    Map<String, String> map = generateSendingParametersI();
    ActivityPackage activityPackage = this.packageQueue.get(0);
    this.activityPackageSender.sendActivityPackage(activityPackage, map, this);
  }
  
  private void sendNextI() {
    if (this.packageQueue.isEmpty())
      return; 
    this.packageQueue.remove(0);
    writePackageQueueI();
    this.isSending.set(false);
    this.logger.verbose("Package handler can send", new Object[0]);
    sendFirstI();
  }
  
  private void writePackageQueueI() {
    Util.writeObject(this.packageQueue, this.context, "AdjustIoPackageQueue", "Package queue");
    this.logger.debug("Package handler wrote %d packages", new Object[] { Integer.valueOf(this.packageQueue.size()) });
  }
  
  public void addPackage(ActivityPackage paramActivityPackage) {
    this.scheduler.submit(new b(this, paramActivityPackage));
  }
  
  public void flush() {
    this.scheduler.submit((Runnable)new g(this));
  }
  
  public void init(IActivityHandler paramIActivityHandler, Context paramContext, boolean paramBoolean, IActivityPackageSender paramIActivityPackageSender) {
    this.activityHandlerWeakRef = new WeakReference<>(paramIActivityHandler);
    this.context = paramContext;
    this.paused = paramBoolean ^ true;
    this.activityPackageSender = paramIActivityPackageSender;
  }
  
  public void onResponseDataCallback(ResponseData paramResponseData) {
    BackoffStrategy backoffStrategy;
    this.logger.debug("Got response in PackageHandler", new Object[0]);
    IActivityHandler iActivityHandler = this.activityHandlerWeakRef.get();
    if (iActivityHandler != null && paramResponseData.trackingState == TrackingState.OPTED_OUT)
      iActivityHandler.gotOptOutResponse(); 
    if (!paramResponseData.willRetry) {
      this.scheduler.submit((Runnable)new d(this));
      if (iActivityHandler != null)
        iActivityHandler.finishedTrackingActivity(paramResponseData); 
      return;
    } 
    if (iActivityHandler != null)
      iActivityHandler.finishedTrackingActivity(paramResponseData); 
    e e = new e(this);
    ActivityPackage activityPackage = paramResponseData.activityPackage;
    if (activityPackage == null) {
      e.run();
      return;
    } 
    int i = activityPackage.increaseRetries();
    SharedPreferencesManager sharedPreferencesManager = SharedPreferencesManager.getDefaultInstance(this.context);
    if (paramResponseData.activityPackage.getActivityKind() == ActivityKind.SESSION && !sharedPreferencesManager.getInstallTracked()) {
      backoffStrategy = this.backoffStrategyForInstallSession;
    } else {
      backoffStrategy = this.backoffStrategy;
    } 
    long l = Util.getWaitingTime(i, backoffStrategy);
    double d = l / 1000.0D;
    String str = Util.SecondsDisplayFormat.format(d);
    this.logger.verbose("Waiting for %s seconds before retrying the %d time", new Object[] { str, Integer.valueOf(i) });
    this.scheduler.schedule((Runnable)e, l);
  }
  
  public void pauseSending() {
    this.paused = true;
  }
  
  public void resumeSending() {
    this.paused = false;
  }
  
  public void sendFirstPackage() {
    this.scheduler.submit(new c(this));
  }
  
  public void teardown() {
    this.logger.verbose("PackageHandler teardown", new Object[0]);
    ThreadScheduler threadScheduler = this.scheduler;
    if (threadScheduler != null)
      threadScheduler.teardown(); 
    WeakReference<IActivityHandler> weakReference = this.activityHandlerWeakRef;
    if (weakReference != null)
      weakReference.clear(); 
    List<ActivityPackage> list = this.packageQueue;
    if (list != null)
      list.clear(); 
    this.scheduler = null;
    this.activityHandlerWeakRef = null;
    this.packageQueue = null;
    this.isSending = null;
    this.context = null;
    this.logger = null;
    this.backoffStrategy = null;
  }
  
  public void updatePackages(SessionParameters paramSessionParameters) {
    if (paramSessionParameters != null) {
      paramSessionParameters = paramSessionParameters.deepCopy();
    } else {
      paramSessionParameters = null;
    } 
    this.scheduler.submit((Runnable)new f(this, paramSessionParameters));
  }
  
  public void updatePackagesI(SessionParameters paramSessionParameters) {
    if (paramSessionParameters == null)
      return; 
    this.logger.debug("Updating package handler queue", new Object[0]);
    this.logger.verbose("Session callback parameters: %s", new Object[] { paramSessionParameters.callbackParameters });
    this.logger.verbose("Session partner parameters: %s", new Object[] { paramSessionParameters.partnerParameters });
    for (ActivityPackage activityPackage : this.packageQueue) {
      Map<String, String> map = activityPackage.getParameters();
      PackageBuilder.addMapJson(map, "callback_params", Util.mergeParameters(paramSessionParameters.callbackParameters, activityPackage.getCallbackParameters(), "Callback"));
      PackageBuilder.addMapJson(map, "partner_params", Util.mergeParameters(paramSessionParameters.partnerParameters, activityPackage.getPartnerParameters(), "Partner"));
    } 
    writePackageQueueI();
  }
  
  public final class a implements Runnable {
    public final PackageHandler a;
    
    public a(PackageHandler this$0) {}
    
    public final void run() {
      this.a.initI();
    }
  }
  
  public final class b implements Runnable {
    public final ActivityPackage a;
    
    public final PackageHandler b;
    
    public b(PackageHandler this$0, ActivityPackage param1ActivityPackage) {}
    
    public final void run() {
      this.b.addI(this.a);
    }
  }
  
  public final class c implements Runnable {
    public final PackageHandler a;
    
    public c(PackageHandler this$0) {}
    
    public final void run() {
      this.a.sendFirstI();
    }
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\adjust\sdk\PackageHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */