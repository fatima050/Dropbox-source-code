package com.adjust.sdk;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import dbxyzptlk.WK.a;
import org.json.JSONException;

public class SharedPreferencesManager {
  private static final int INDEX_CLICK_TIME = 1;
  
  private static final int INDEX_IS_SENDING = 2;
  
  private static final int INDEX_RAW_REFERRER = 0;
  
  private static final String PREFS_KEY_DEEPLINK_CLICK_TIME = "deeplink_click_time";
  
  private static final String PREFS_KEY_DEEPLINK_URL = "deeplink_url";
  
  private static final String PREFS_KEY_DISABLE_THIRD_PARTY_SHARING = "disable_third_party_sharing";
  
  private static final String PREFS_KEY_GDPR_FORGET_ME = "gdpr_forget_me";
  
  private static final String PREFS_KEY_INSTALL_TRACKED = "install_tracked";
  
  private static final String PREFS_KEY_PREINSTALL_PAYLOAD_READ_STATUS = "preinstall_payload_read_status";
  
  private static final String PREFS_KEY_PREINSTALL_SYSTEM_INSTALLER_REFERRER = "preinstall_system_installer_referrer";
  
  private static final String PREFS_KEY_PUSH_TOKEN = "push_token";
  
  private static final String PREFS_KEY_RAW_REFERRERS = "raw_referrers";
  
  private static final String PREFS_NAME = "adjust_preferences";
  
  private static final int REFERRERS_COUNT = 10;
  
  private static SharedPreferencesManager defaultInstance;
  
  private static SharedPreferences sharedPreferences;
  
  private static SharedPreferences.Editor sharedPreferencesEditor;
  
  private SharedPreferencesManager(Context paramContext) {
    try {
      SharedPreferences sharedPreferences = paramContext.getSharedPreferences("adjust_preferences", 0);
      sharedPreferences = sharedPreferences;
      sharedPreferencesEditor = sharedPreferences.edit();
    } catch (Exception exception) {
      AdjustFactory.getLogger().error("Cannot access to SharedPreferences", new Object[] { exception.getMessage() });
      sharedPreferences = null;
      sharedPreferencesEditor = null;
    } 
  }
  
  private boolean getBoolean(String paramString, boolean paramBoolean) {
    /* monitor enter ThisExpression{ObjectType{com/adjust/sdk/SharedPreferencesManager}} */
    try {
      SharedPreferences sharedPreferences = sharedPreferences;
      if (sharedPreferences != null)
        try {
          boolean bool = sharedPreferences.getBoolean(paramString, paramBoolean);
          /* monitor exit ThisExpression{ObjectType{com/adjust/sdk/SharedPreferencesManager}} */
          return bool;
        } catch (ClassCastException classCastException) {
          /* monitor exit ThisExpression{ObjectType{com/adjust/sdk/SharedPreferencesManager}} */
          return paramBoolean;
        }  
    } finally {}
    /* monitor exit ThisExpression{ObjectType{com/adjust/sdk/SharedPreferencesManager}} */
    return paramBoolean;
  }
  
  public static SharedPreferencesManager getDefaultInstance(Context paramContext) {
    /* monitor enter TypeReferenceDotClassExpression{ObjectType{com/adjust/sdk/SharedPreferencesManager}} */
    try {
      if (defaultInstance == null) {
        SharedPreferencesManager sharedPreferencesManager1 = new SharedPreferencesManager();
        this(paramContext);
        defaultInstance = sharedPreferencesManager1;
      } 
    } finally {}
    SharedPreferencesManager sharedPreferencesManager = defaultInstance;
    /* monitor exit TypeReferenceDotClassExpression{ObjectType{com/adjust/sdk/SharedPreferencesManager}} */
    return sharedPreferencesManager;
  }
  
  private long getLong(String paramString, long paramLong) {
    /* monitor enter ThisExpression{ObjectType{com/adjust/sdk/SharedPreferencesManager}} */
    try {
      SharedPreferences sharedPreferences = sharedPreferences;
      if (sharedPreferences != null)
        try {
          long l = sharedPreferences.getLong(paramString, paramLong);
          /* monitor exit ThisExpression{ObjectType{com/adjust/sdk/SharedPreferencesManager}} */
          return l;
        } catch (ClassCastException classCastException) {
          /* monitor exit ThisExpression{ObjectType{com/adjust/sdk/SharedPreferencesManager}} */
          return paramLong;
        }  
    } finally {}
    /* monitor exit ThisExpression{ObjectType{com/adjust/sdk/SharedPreferencesManager}} */
    return paramLong;
  }
  
  private int getRawReferrerIndex(String paramString, long paramLong) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual getRawReferrerArray : ()Ldbxyzptlk/WK/a;
    //   6: astore #7
    //   8: iconst_0
    //   9: istore #4
    //   11: iload #4
    //   13: aload #7
    //   15: invokevirtual p : ()I
    //   18: if_icmpge -> 96
    //   21: aload #7
    //   23: iload #4
    //   25: invokevirtual j : (I)Ldbxyzptlk/WK/a;
    //   28: astore #8
    //   30: aload #8
    //   32: iconst_0
    //   33: aconst_null
    //   34: invokevirtual B : (ILjava/lang/String;)Ljava/lang/String;
    //   37: astore #9
    //   39: aload #9
    //   41: ifnull -> 86
    //   44: aload #9
    //   46: aload_1
    //   47: invokevirtual equals : (Ljava/lang/Object;)Z
    //   50: ifne -> 56
    //   53: goto -> 86
    //   56: aload #8
    //   58: iconst_1
    //   59: ldc2_w -1
    //   62: invokevirtual z : (IJ)J
    //   65: lstore #5
    //   67: lload #5
    //   69: lload_2
    //   70: lcmp
    //   71: ifeq -> 77
    //   74: goto -> 86
    //   77: aload_0
    //   78: monitorexit
    //   79: iload #4
    //   81: ireturn
    //   82: astore_1
    //   83: goto -> 92
    //   86: iinc #4, 1
    //   89: goto -> 11
    //   92: aload_0
    //   93: monitorexit
    //   94: aload_1
    //   95: athrow
    //   96: aload_0
    //   97: monitorexit
    //   98: iconst_m1
    //   99: ireturn
    //   100: astore_1
    //   101: goto -> 96
    // Exception table:
    //   from	to	target	type
    //   2	8	100	org/json/JSONException
    //   2	8	82	finally
    //   11	39	100	org/json/JSONException
    //   11	39	82	finally
    //   44	53	100	org/json/JSONException
    //   44	53	82	finally
    //   56	67	100	org/json/JSONException
    //   56	67	82	finally
    //   92	94	82	finally
  }
  
  private String getString(String paramString) {
    /* monitor enter ThisExpression{ObjectType{com/adjust/sdk/SharedPreferencesManager}} */
    try {
      SharedPreferences sharedPreferences = sharedPreferences;
      if (sharedPreferences != null)
        try {
          return str;
        } catch (ClassCastException classCastException) {
          return null;
        } finally {
          sharedPreferences = null;
          if (classCastException.equals("raw_referrers"))
            remove("raw_referrers"); 
          /* monitor exit ThisExpression{ObjectType{com/adjust/sdk/SharedPreferencesManager}} */
        }  
    } finally {}
    /* monitor exit ThisExpression{ObjectType{com/adjust/sdk/SharedPreferencesManager}} */
    return null;
  }
  
  private void remove(String paramString) {
    /* monitor enter ThisExpression{ObjectType{com/adjust/sdk/SharedPreferencesManager}} */
    try {
      SharedPreferences.Editor editor = sharedPreferencesEditor;
      if (editor != null)
        editor.remove(paramString).apply(); 
    } finally {}
    /* monitor exit ThisExpression{ObjectType{com/adjust/sdk/SharedPreferencesManager}} */
  }
  
  private void saveBoolean(String paramString, boolean paramBoolean) {
    /* monitor enter ThisExpression{ObjectType{com/adjust/sdk/SharedPreferencesManager}} */
    try {
      SharedPreferences.Editor editor = sharedPreferencesEditor;
      if (editor != null)
        editor.putBoolean(paramString, paramBoolean).apply(); 
    } finally {}
    /* monitor exit ThisExpression{ObjectType{com/adjust/sdk/SharedPreferencesManager}} */
  }
  
  private void saveInteger(String paramString, int paramInt) {
    /* monitor enter ThisExpression{ObjectType{com/adjust/sdk/SharedPreferencesManager}} */
    try {
      SharedPreferences.Editor editor = sharedPreferencesEditor;
      if (editor != null)
        editor.putInt(paramString, paramInt).apply(); 
    } finally {}
    /* monitor exit ThisExpression{ObjectType{com/adjust/sdk/SharedPreferencesManager}} */
  }
  
  private void saveLong(String paramString, long paramLong) {
    /* monitor enter ThisExpression{ObjectType{com/adjust/sdk/SharedPreferencesManager}} */
    try {
      SharedPreferences.Editor editor = sharedPreferencesEditor;
      if (editor != null)
        editor.putLong(paramString, paramLong).apply(); 
    } finally {}
    /* monitor exit ThisExpression{ObjectType{com/adjust/sdk/SharedPreferencesManager}} */
  }
  
  private void saveString(String paramString1, String paramString2) {
    /* monitor enter ThisExpression{ObjectType{com/adjust/sdk/SharedPreferencesManager}} */
    try {
      SharedPreferences.Editor editor = sharedPreferencesEditor;
      if (editor != null)
        editor.putString(paramString1, paramString2).apply(); 
    } finally {}
    /* monitor exit ThisExpression{ObjectType{com/adjust/sdk/SharedPreferencesManager}} */
  }
  
  public void clear() {
    /* monitor enter ThisExpression{ObjectType{com/adjust/sdk/SharedPreferencesManager}} */
    try {
      SharedPreferences.Editor editor = sharedPreferencesEditor;
      if (editor != null)
        editor.clear().apply(); 
    } finally {
      Exception exception;
    } 
    /* monitor exit ThisExpression{ObjectType{com/adjust/sdk/SharedPreferencesManager}} */
  }
  
  public long getDeeplinkClickTime() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: ldc 'deeplink_click_time'
    //   5: ldc2_w -1
    //   8: invokespecial getLong : (Ljava/lang/String;J)J
    //   11: lstore_1
    //   12: aload_0
    //   13: monitorexit
    //   14: lload_1
    //   15: lreturn
    //   16: astore_3
    //   17: aload_0
    //   18: monitorexit
    //   19: aload_3
    //   20: athrow
    // Exception table:
    //   from	to	target	type
    //   2	12	16	finally
    //   17	19	16	finally
  }
  
  public String getDeeplinkUrl() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: ldc 'deeplink_url'
    //   5: invokespecial getString : (Ljava/lang/String;)Ljava/lang/String;
    //   8: astore_1
    //   9: aload_0
    //   10: monitorexit
    //   11: aload_1
    //   12: areturn
    //   13: astore_1
    //   14: aload_0
    //   15: monitorexit
    //   16: aload_1
    //   17: athrow
    // Exception table:
    //   from	to	target	type
    //   2	9	13	finally
    //   14	16	13	finally
  }
  
  public boolean getDisableThirdPartySharing() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: ldc 'disable_third_party_sharing'
    //   5: iconst_0
    //   6: invokespecial getBoolean : (Ljava/lang/String;Z)Z
    //   9: istore_1
    //   10: aload_0
    //   11: monitorexit
    //   12: iload_1
    //   13: ireturn
    //   14: astore_2
    //   15: aload_0
    //   16: monitorexit
    //   17: aload_2
    //   18: athrow
    // Exception table:
    //   from	to	target	type
    //   2	10	14	finally
    //   15	17	14	finally
  }
  
  public boolean getGdprForgetMe() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: ldc 'gdpr_forget_me'
    //   5: iconst_0
    //   6: invokespecial getBoolean : (Ljava/lang/String;Z)Z
    //   9: istore_1
    //   10: aload_0
    //   11: monitorexit
    //   12: iload_1
    //   13: ireturn
    //   14: astore_2
    //   15: aload_0
    //   16: monitorexit
    //   17: aload_2
    //   18: athrow
    // Exception table:
    //   from	to	target	type
    //   2	10	14	finally
    //   15	17	14	finally
  }
  
  public boolean getInstallTracked() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: ldc 'install_tracked'
    //   5: iconst_0
    //   6: invokespecial getBoolean : (Ljava/lang/String;Z)Z
    //   9: istore_1
    //   10: aload_0
    //   11: monitorexit
    //   12: iload_1
    //   13: ireturn
    //   14: astore_2
    //   15: aload_0
    //   16: monitorexit
    //   17: aload_2
    //   18: athrow
    // Exception table:
    //   from	to	target	type
    //   2	10	14	finally
    //   15	17	14	finally
  }
  
  public long getPreinstallPayloadReadStatus() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: ldc 'preinstall_payload_read_status'
    //   5: lconst_0
    //   6: invokespecial getLong : (Ljava/lang/String;J)J
    //   9: lstore_1
    //   10: aload_0
    //   11: monitorexit
    //   12: lload_1
    //   13: lreturn
    //   14: astore_3
    //   15: aload_0
    //   16: monitorexit
    //   17: aload_3
    //   18: athrow
    // Exception table:
    //   from	to	target	type
    //   2	10	14	finally
    //   15	17	14	finally
  }
  
  public String getPreinstallReferrer() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: ldc 'preinstall_system_installer_referrer'
    //   5: invokespecial getString : (Ljava/lang/String;)Ljava/lang/String;
    //   8: astore_1
    //   9: aload_0
    //   10: monitorexit
    //   11: aload_1
    //   12: areturn
    //   13: astore_1
    //   14: aload_0
    //   15: monitorexit
    //   16: aload_1
    //   17: athrow
    // Exception table:
    //   from	to	target	type
    //   2	9	13	finally
    //   14	16	13	finally
  }
  
  public String getPushToken() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: ldc 'push_token'
    //   5: invokespecial getString : (Ljava/lang/String;)Ljava/lang/String;
    //   8: astore_1
    //   9: aload_0
    //   10: monitorexit
    //   11: aload_1
    //   12: areturn
    //   13: astore_1
    //   14: aload_0
    //   15: monitorexit
    //   16: aload_1
    //   17: athrow
    // Exception table:
    //   from	to	target	type
    //   2	9	13	finally
    //   14	16	13	finally
  }
  
  public a getRawReferrer(String paramString, long paramLong) {
    /* monitor enter ThisExpression{ObjectType{com/adjust/sdk/SharedPreferencesManager}} */
    try {
      int i = getRawReferrerIndex(paramString, paramLong);
      if (i >= 0)
        try {
          a a = getRawReferrerArray().j(i);
          /* monitor exit ThisExpression{ObjectType{com/adjust/sdk/SharedPreferencesManager}} */
          return a;
        } catch (JSONException jSONException) {} 
    } finally {}
    /* monitor exit ThisExpression{ObjectType{com/adjust/sdk/SharedPreferencesManager}} */
    return null;
  }
  
  public a getRawReferrerArray() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: ldc 'raw_referrers'
    //   5: invokespecial getString : (Ljava/lang/String;)Ljava/lang/String;
    //   8: astore_3
    //   9: aload_3
    //   10: ifnull -> 85
    //   13: new dbxyzptlk/WK/a
    //   16: astore_2
    //   17: aload_2
    //   18: aload_3
    //   19: invokespecial <init> : (Ljava/lang/String;)V
    //   22: aload_2
    //   23: invokevirtual p : ()I
    //   26: bipush #10
    //   28: if_icmple -> 72
    //   31: new dbxyzptlk/WK/a
    //   34: astore_3
    //   35: aload_3
    //   36: invokespecial <init> : ()V
    //   39: iconst_0
    //   40: istore_1
    //   41: iload_1
    //   42: bipush #10
    //   44: if_icmpge -> 63
    //   47: aload_3
    //   48: aload_2
    //   49: iload_1
    //   50: invokevirtual get : (I)Ljava/lang/Object;
    //   53: invokevirtual H : (Ljava/lang/Object;)Ldbxyzptlk/WK/a;
    //   56: pop
    //   57: iinc #1, 1
    //   60: goto -> 41
    //   63: aload_0
    //   64: aload_3
    //   65: invokevirtual saveRawReferrerArray : (Ldbxyzptlk/WK/a;)V
    //   68: aload_0
    //   69: monitorexit
    //   70: aload_3
    //   71: areturn
    //   72: new dbxyzptlk/WK/a
    //   75: dup
    //   76: aload_3
    //   77: invokespecial <init> : (Ljava/lang/String;)V
    //   80: astore_2
    //   81: aload_0
    //   82: monitorexit
    //   83: aload_2
    //   84: areturn
    //   85: new dbxyzptlk/WK/a
    //   88: dup
    //   89: invokespecial <init> : ()V
    //   92: astore_2
    //   93: aload_0
    //   94: monitorexit
    //   95: aload_2
    //   96: areturn
    //   97: astore_2
    //   98: aload_0
    //   99: monitorexit
    //   100: aload_2
    //   101: athrow
    //   102: astore_2
    //   103: goto -> 85
    // Exception table:
    //   from	to	target	type
    //   2	9	97	finally
    //   13	39	102	org/json/JSONException
    //   13	39	102	finally
    //   47	57	102	org/json/JSONException
    //   47	57	102	finally
    //   63	68	102	org/json/JSONException
    //   63	68	102	finally
    //   72	81	102	org/json/JSONException
    //   72	81	102	finally
    //   85	93	97	finally
    //   98	100	97	finally
  }
  
  public void removeDeeplink() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: ldc 'deeplink_url'
    //   5: invokespecial remove : (Ljava/lang/String;)V
    //   8: aload_0
    //   9: ldc 'deeplink_click_time'
    //   11: invokespecial remove : (Ljava/lang/String;)V
    //   14: aload_0
    //   15: monitorexit
    //   16: return
    //   17: astore_1
    //   18: aload_0
    //   19: monitorexit
    //   20: aload_1
    //   21: athrow
    // Exception table:
    //   from	to	target	type
    //   2	14	17	finally
    //   18	20	17	finally
  }
  
  public void removeDisableThirdPartySharing() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: ldc 'disable_third_party_sharing'
    //   5: invokespecial remove : (Ljava/lang/String;)V
    //   8: aload_0
    //   9: monitorexit
    //   10: return
    //   11: astore_1
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_1
    //   15: athrow
    // Exception table:
    //   from	to	target	type
    //   2	8	11	finally
    //   12	14	11	finally
  }
  
  public void removeGdprForgetMe() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: ldc 'gdpr_forget_me'
    //   5: invokespecial remove : (Ljava/lang/String;)V
    //   8: aload_0
    //   9: monitorexit
    //   10: return
    //   11: astore_1
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_1
    //   15: athrow
    // Exception table:
    //   from	to	target	type
    //   2	8	11	finally
    //   12	14	11	finally
  }
  
  public void removePreinstallReferrer() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: ldc 'preinstall_system_installer_referrer'
    //   5: invokespecial remove : (Ljava/lang/String;)V
    //   8: aload_0
    //   9: monitorexit
    //   10: return
    //   11: astore_1
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_1
    //   15: athrow
    // Exception table:
    //   from	to	target	type
    //   2	8	11	finally
    //   12	14	11	finally
  }
  
  public void removePushToken() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: ldc 'push_token'
    //   5: invokespecial remove : (Ljava/lang/String;)V
    //   8: aload_0
    //   9: monitorexit
    //   10: return
    //   11: astore_1
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_1
    //   15: athrow
    // Exception table:
    //   from	to	target	type
    //   2	8	11	finally
    //   12	14	11	finally
  }
  
  public void removeRawReferrer(String paramString, long paramLong) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_1
    //   3: ifnull -> 119
    //   6: aload_1
    //   7: invokevirtual length : ()I
    //   10: ifne -> 16
    //   13: goto -> 119
    //   16: aload_0
    //   17: aload_1
    //   18: lload_2
    //   19: invokespecial getRawReferrerIndex : (Ljava/lang/String;J)I
    //   22: istore #5
    //   24: iload #5
    //   26: ifge -> 32
    //   29: aload_0
    //   30: monitorexit
    //   31: return
    //   32: aload_0
    //   33: invokevirtual getRawReferrerArray : ()Ldbxyzptlk/WK/a;
    //   36: astore #8
    //   38: new dbxyzptlk/WK/a
    //   41: astore #7
    //   43: aload #7
    //   45: invokespecial <init> : ()V
    //   48: iconst_0
    //   49: istore #4
    //   51: aload #8
    //   53: invokevirtual p : ()I
    //   56: istore #6
    //   58: iload #4
    //   60: iload #6
    //   62: if_icmpge -> 101
    //   65: iload #4
    //   67: iload #5
    //   69: if_icmpne -> 75
    //   72: goto -> 95
    //   75: aload #7
    //   77: aload #8
    //   79: iload #4
    //   81: invokevirtual j : (I)Ldbxyzptlk/WK/a;
    //   84: invokevirtual H : (Ljava/lang/Object;)Ldbxyzptlk/WK/a;
    //   87: pop
    //   88: goto -> 95
    //   91: astore_1
    //   92: goto -> 115
    //   95: iinc #4, 1
    //   98: goto -> 51
    //   101: aload_0
    //   102: ldc 'raw_referrers'
    //   104: aload #7
    //   106: invokevirtual toString : ()Ljava/lang/String;
    //   109: invokespecial saveString : (Ljava/lang/String;Ljava/lang/String;)V
    //   112: aload_0
    //   113: monitorexit
    //   114: return
    //   115: aload_0
    //   116: monitorexit
    //   117: aload_1
    //   118: athrow
    //   119: aload_0
    //   120: monitorexit
    //   121: return
    //   122: astore_1
    //   123: goto -> 95
    // Exception table:
    //   from	to	target	type
    //   6	13	91	finally
    //   16	24	91	finally
    //   32	48	91	finally
    //   51	58	91	finally
    //   75	88	122	org/json/JSONException
    //   75	88	91	finally
    //   101	112	91	finally
    //   115	117	91	finally
  }
  
  public void saveDeeplink(Uri paramUri, long paramLong) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_1
    //   3: ifnonnull -> 9
    //   6: aload_0
    //   7: monitorexit
    //   8: return
    //   9: aload_0
    //   10: ldc 'deeplink_url'
    //   12: aload_1
    //   13: invokevirtual toString : ()Ljava/lang/String;
    //   16: invokespecial saveString : (Ljava/lang/String;Ljava/lang/String;)V
    //   19: aload_0
    //   20: ldc 'deeplink_click_time'
    //   22: lload_2
    //   23: invokespecial saveLong : (Ljava/lang/String;J)V
    //   26: aload_0
    //   27: monitorexit
    //   28: return
    //   29: astore_1
    //   30: aload_0
    //   31: monitorexit
    //   32: aload_1
    //   33: athrow
    // Exception table:
    //   from	to	target	type
    //   9	26	29	finally
    //   30	32	29	finally
  }
  
  public void savePreinstallReferrer(String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: ldc 'preinstall_system_installer_referrer'
    //   5: aload_1
    //   6: invokespecial saveString : (Ljava/lang/String;Ljava/lang/String;)V
    //   9: aload_0
    //   10: monitorexit
    //   11: return
    //   12: astore_1
    //   13: aload_0
    //   14: monitorexit
    //   15: aload_1
    //   16: athrow
    // Exception table:
    //   from	to	target	type
    //   2	9	12	finally
    //   13	15	12	finally
  }
  
  public void savePushToken(String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: ldc 'push_token'
    //   5: aload_1
    //   6: invokespecial saveString : (Ljava/lang/String;Ljava/lang/String;)V
    //   9: aload_0
    //   10: monitorexit
    //   11: return
    //   12: astore_1
    //   13: aload_0
    //   14: monitorexit
    //   15: aload_1
    //   16: athrow
    // Exception table:
    //   from	to	target	type
    //   2	9	12	finally
    //   13	15	12	finally
  }
  
  public void saveRawReferrer(String paramString, long paramLong) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: aload_1
    //   4: lload_2
    //   5: invokevirtual getRawReferrer : (Ljava/lang/String;J)Ldbxyzptlk/WK/a;
    //   8: astore #5
    //   10: aload #5
    //   12: ifnull -> 18
    //   15: aload_0
    //   16: monitorexit
    //   17: return
    //   18: aload_0
    //   19: invokevirtual getRawReferrerArray : ()Ldbxyzptlk/WK/a;
    //   22: astore #6
    //   24: aload #6
    //   26: invokevirtual p : ()I
    //   29: istore #4
    //   31: iload #4
    //   33: bipush #10
    //   35: if_icmpne -> 41
    //   38: aload_0
    //   39: monitorexit
    //   40: return
    //   41: new dbxyzptlk/WK/a
    //   44: astore #5
    //   46: aload #5
    //   48: invokespecial <init> : ()V
    //   51: aload #5
    //   53: iconst_0
    //   54: aload_1
    //   55: invokevirtual G : (ILjava/lang/Object;)Ldbxyzptlk/WK/a;
    //   58: pop
    //   59: aload #5
    //   61: iconst_1
    //   62: lload_2
    //   63: invokevirtual F : (IJ)Ldbxyzptlk/WK/a;
    //   66: pop
    //   67: aload #5
    //   69: iconst_2
    //   70: iconst_0
    //   71: invokevirtual E : (II)Ldbxyzptlk/WK/a;
    //   74: pop
    //   75: aload #6
    //   77: aload #5
    //   79: invokevirtual H : (Ljava/lang/Object;)Ldbxyzptlk/WK/a;
    //   82: pop
    //   83: aload_0
    //   84: aload #6
    //   86: invokevirtual saveRawReferrerArray : (Ldbxyzptlk/WK/a;)V
    //   89: goto -> 97
    //   92: astore_1
    //   93: aload_0
    //   94: monitorexit
    //   95: aload_1
    //   96: athrow
    //   97: aload_0
    //   98: monitorexit
    //   99: return
    //   100: astore_1
    //   101: goto -> 97
    // Exception table:
    //   from	to	target	type
    //   2	10	100	org/json/JSONException
    //   2	10	92	finally
    //   18	31	100	org/json/JSONException
    //   18	31	92	finally
    //   41	89	100	org/json/JSONException
    //   41	89	92	finally
    //   93	95	92	finally
  }
  
  public void saveRawReferrerArray(a parama) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: ldc 'raw_referrers'
    //   5: aload_1
    //   6: invokevirtual toString : ()Ljava/lang/String;
    //   9: invokespecial saveString : (Ljava/lang/String;Ljava/lang/String;)V
    //   12: goto -> 22
    //   15: astore_1
    //   16: aload_0
    //   17: ldc 'raw_referrers'
    //   19: invokespecial remove : (Ljava/lang/String;)V
    //   22: aload_0
    //   23: monitorexit
    //   24: return
    //   25: astore_1
    //   26: aload_0
    //   27: monitorexit
    //   28: aload_1
    //   29: athrow
    // Exception table:
    //   from	to	target	type
    //   2	12	15	finally
    //   16	22	25	finally
    //   26	28	25	finally
  }
  
  public void setDisableThirdPartySharing() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: ldc 'disable_third_party_sharing'
    //   5: iconst_1
    //   6: invokespecial saveBoolean : (Ljava/lang/String;Z)V
    //   9: aload_0
    //   10: monitorexit
    //   11: return
    //   12: astore_1
    //   13: aload_0
    //   14: monitorexit
    //   15: aload_1
    //   16: athrow
    // Exception table:
    //   from	to	target	type
    //   2	9	12	finally
    //   13	15	12	finally
  }
  
  public void setGdprForgetMe() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: ldc 'gdpr_forget_me'
    //   5: iconst_1
    //   6: invokespecial saveBoolean : (Ljava/lang/String;Z)V
    //   9: aload_0
    //   10: monitorexit
    //   11: return
    //   12: astore_1
    //   13: aload_0
    //   14: monitorexit
    //   15: aload_1
    //   16: athrow
    // Exception table:
    //   from	to	target	type
    //   2	9	12	finally
    //   13	15	12	finally
  }
  
  public void setInstallTracked() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: ldc 'install_tracked'
    //   5: iconst_1
    //   6: invokespecial saveBoolean : (Ljava/lang/String;Z)V
    //   9: aload_0
    //   10: monitorexit
    //   11: return
    //   12: astore_1
    //   13: aload_0
    //   14: monitorexit
    //   15: aload_1
    //   16: athrow
    // Exception table:
    //   from	to	target	type
    //   2	9	12	finally
    //   13	15	12	finally
  }
  
  public void setPreinstallPayloadReadStatus(long paramLong) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: ldc 'preinstall_payload_read_status'
    //   5: lload_1
    //   6: invokespecial saveLong : (Ljava/lang/String;J)V
    //   9: aload_0
    //   10: monitorexit
    //   11: return
    //   12: astore_3
    //   13: aload_0
    //   14: monitorexit
    //   15: aload_3
    //   16: athrow
    // Exception table:
    //   from	to	target	type
    //   2	9	12	finally
    //   13	15	12	finally
  }
  
  public void setSendingReferrersAsNotSent() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual getRawReferrerArray : ()Ldbxyzptlk/WK/a;
    //   6: astore #4
    //   8: iconst_0
    //   9: istore_1
    //   10: iconst_0
    //   11: istore_2
    //   12: iload_1
    //   13: aload #4
    //   15: invokevirtual p : ()I
    //   18: if_icmpge -> 60
    //   21: aload #4
    //   23: iload_1
    //   24: invokevirtual j : (I)Ldbxyzptlk/WK/a;
    //   27: astore_3
    //   28: aload_3
    //   29: iconst_2
    //   30: iconst_m1
    //   31: invokevirtual w : (II)I
    //   34: iconst_1
    //   35: if_icmpne -> 54
    //   38: aload_3
    //   39: iconst_2
    //   40: iconst_0
    //   41: invokevirtual E : (II)Ldbxyzptlk/WK/a;
    //   44: pop
    //   45: iconst_1
    //   46: istore_2
    //   47: goto -> 54
    //   50: astore_3
    //   51: goto -> 73
    //   54: iinc #1, 1
    //   57: goto -> 12
    //   60: iload_2
    //   61: ifeq -> 77
    //   64: aload_0
    //   65: aload #4
    //   67: invokevirtual saveRawReferrerArray : (Ldbxyzptlk/WK/a;)V
    //   70: goto -> 77
    //   73: aload_0
    //   74: monitorexit
    //   75: aload_3
    //   76: athrow
    //   77: aload_0
    //   78: monitorexit
    //   79: return
    //   80: astore_3
    //   81: goto -> 77
    // Exception table:
    //   from	to	target	type
    //   2	8	80	org/json/JSONException
    //   2	8	50	finally
    //   12	28	80	org/json/JSONException
    //   12	28	50	finally
    //   28	45	80	org/json/JSONException
    //   28	45	50	finally
    //   64	70	80	org/json/JSONException
    //   64	70	50	finally
    //   73	75	50	finally
  }
}


/* Location:              C:\Users\hp\Downloads\dex-tools-v2.4 (3)\dex-tools-v2.4\classes-dex2jar.jar!\com\adjust\sdk\SharedPreferencesManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */